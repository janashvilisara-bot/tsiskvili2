# Audit: add / edit / delete across the app, per role

## Goal
For every main module, confirm that each role (Admin, HR manager, Department manager, Employee) can do exactly what it should — no more, no less — and that every add / edit / delete either works or shows a clear Georgian error.

## Scope (modules)
Employees, Departments and Positions, Branches, Leave requests, Attendance, Work schedules / shift schedules / templates, Payroll, Contracts and Documents, Business trips, Expenses, Tasks, Announcements, Benefits, Training, Recognition.

## Expected role matrix
```text
                 Admin   HR     Dept manager          Employee
Employees        CRUD    CRUD   view own dept         view/edit own basic
Org structure    CRUD    CRUD   view                  view
Leave requests   all     all    approve own dept      create/view own
Attendance       all     all    view own dept         own check-in
Schedules        CRUD    CRUD   view own dept         view own
Payroll          CRUD    CRUD   none                  view own payslip
Documents        CRUD    CRUD   view own dept         own + sign
Tasks/Trips/Exp  all     all    own dept              own create
```
Any mismatch found is reported and fixed (database rules or hidden/shown buttons).

## Already found (to fix)
- Employee delete silently wipes attendance, leave, payroll, pension, contracts, evaluations without checking each step. If one step fails, the employee is half-deleted. Replace with: deactivate by default; permanent delete only via one safe server step that either succeeds fully or changes nothing, with a warning that payroll history is lost.
- Same for bulk delete.

## How the audit runs
1. Read each module's save/delete code and database access rules; list every action that ignores errors or has no permission check.
2. Compare database rules with the matrix above; fix gaps.
3. In the preview, sign in as Sara (admin) and Dante (employee) and click through add / edit / delete on test records only, deleting them afterwards. Sara's pending leave request is not touched. No real employee data is deleted.
4. Deliver a short Georgian report: what works, what was fixed, what is left.

## Technical details
- Static scan: `rg` for `.insert/.update/.delete` without `error` checks; list `pg_policies` per table vs matrix.
- New server function (or DB function, security definer, admin/HR only) `delete_employee_permanently(id)` in one transaction; UI uses soft delete (`deleted_at` / status inactive) by default.
- Hide action buttons using `userRole` where the database would reject the action anyway.
- Playwright sessions minted for the two accounts; test records prefixed `AUDIT-TEST`.
