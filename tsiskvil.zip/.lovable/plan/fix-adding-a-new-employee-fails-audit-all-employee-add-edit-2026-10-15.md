# Fix: adding a new employee fails + audit all employee add/edit/delete forms

## Confirmed root cause
Today's server logs (07:12 UTC, several attempts) show every "add employee" attempt rejected with "weak password". The Employees form sends the default temporary password `1111` when HR leaves the password field empty, and the login system now rejects passwords shorter than 6 characters or known leaked ones. The employee is never created, and the user sees only a generic error.

## Step 1 - Make adding work
- Replace the `1111` default with an automatically generated strong temporary password (12+ characters, letters + digits + symbol), generated inside the registration function on the server so it never depends on the browser.
- If HR types a custom password, check it before sending (min 8 chars, not trivial) and show a clear Georgian message under the field instead of a generic failure.
- Translate the "weak password", "email already registered" and "personal ID already exists" errors into clear Georgian messages in the form.
- After creation, the temporary password is still shown once to HR in the existing dialog (as today); the employee changes it on first login.

## Step 2 - Audit every employee form end-to-end
Check and fix add / edit / delete / status change in:
- Employees page (add, edit, deactivate, delete, bulk delete, role change)
- Employee details and Employee profile (edit fields, photo upload)
- Onboarding / Offboarding (creating/finishing employees)
- Bulk import (if it uses the same registration path)
- Branch transfers (changing an employee's branch)

For each: confirm the save reaches the database, errors show in Georgian, the list refreshes, and the new employee also gets: role, branch, schedule, benefits. Also fix the follow-up step after creation that looks up the new employee by email and silently ignores failures.

## Step 3 - Verify
- Add a small test for the password rule (empty -> generated strong password; `1111` rejected; valid custom accepted).
- In the preview as admin: add a test employee, edit them, deactivate, then delete the test record - no real employee data touched.

## Technical details
- `supabase/functions/register-employee/index.ts`: generate password with `crypto.getRandomValues` when none/weak supplied; return structured error codes (`weak_password`, `email_exists`) instead of 500.
- `src/pages/Employees.tsx` ~line 895: remove `customPassword || '1111'`; pre-validate custom password; map error codes to Georgian toasts; check errors on the post-create `update` and `saveBenefitEnrollments`.
- Shared `src/lib/tempPassword.ts` + `tempPassword.test.ts` (vitest).
- RLS on `employees` already allows admin/HR full access; no database changes expected.
