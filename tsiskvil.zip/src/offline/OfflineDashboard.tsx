import { useEffect, useState } from 'react';
import { Building2, CalendarDays, HardDrive, LogOut, Users, BriefcaseBusiness } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { getOfflineSeed, type OfflineSeed } from './localStore';

export default function OfflineDashboard() {
  const { signOut } = useAuth();
  const [seed, setSeed] = useState<OfflineSeed | null>(null);

  useEffect(() => {
    getOfflineSeed().then(setSeed);
  }, []);

  const employees = seed?.employees ?? [];
  const departments = seed?.departments ?? [];
  const schedules = seed?.workSchedules ?? [];
  const holidays = seed?.publicHolidays ?? [];
  const activeEmployees = employees.filter((employee) => employee.status === 'active').length;

  return (
    <main className="min-h-screen bg-background text-foreground">
      <header className="border-b bg-card/80 backdrop-blur supports-[backdrop-filter]:bg-card/70">
        <div className="mx-auto max-w-7xl px-6 py-5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
              <HardDrive className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-xl font-semibold">TalentOS Offline</h1>
              <p className="text-sm text-muted-foreground">ლოკალური standalone რეჟიმი · Cloud sync გამორთულია</p>
            </div>
          </div>
          <Button variant="outline" onClick={signOut} className="gap-2">
            <LogOut className="h-4 w-4" /> გასვლა
          </Button>
        </div>
      </header>

      <section className="mx-auto max-w-7xl px-6 py-8 space-y-8">
        <div className="grid gap-4 md:grid-cols-4">
          <Card><CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2"><Users className="h-4 w-4" /> თანამშრომლები</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold">{employees.length}</p><p className="text-xs text-muted-foreground">აქტიური: {activeEmployees}</p></CardContent></Card>
          <Card><CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2"><Building2 className="h-4 w-4" /> დეპარტამენტები</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold">{departments.length}</p><p className="text-xs text-muted-foreground">ძირითადი სტრუქტურა</p></CardContent></Card>
          <Card><CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2"><BriefcaseBusiness className="h-4 w-4" /> გრაფიკები</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold">{schedules.length}</p><p className="text-xs text-muted-foreground">ლოკალური ასლი</p></CardContent></Card>
          <Card><CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2"><CalendarDays className="h-4 w-4" /> უქმე დღეები</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold">{holidays.length}</p><p className="text-xs text-muted-foreground">კალენდარი</p></CardContent></Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
          <Card>
            <CardHeader><CardTitle>თანამშრომლების ძირითადი სია</CardTitle></CardHeader>
            <CardContent className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-muted-foreground border-b">
                  <tr><th className="py-3 pr-4">სახელი</th><th className="py-3 pr-4">დეპარტამენტი</th><th className="py-3 pr-4">პოზიცია</th><th className="py-3">სტატუსი</th></tr>
                </thead>
                <tbody className="divide-y">
                  {employees.slice(0, 20).map((employee, index) => (
                    <tr key={String(employee.id ?? index)}>
                      <td className="py-3 pr-4 font-medium">{String(employee.full_name ?? '-')}</td>
                      <td className="py-3 pr-4 text-muted-foreground">{String(employee.department ?? '-')}</td>
                      <td className="py-3 pr-4 text-muted-foreground">{String(employee.position ?? '-')}</td>
                      <td className="py-3">{String(employee.status ?? '-')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>ლოკალური საცავის მდგომარეობა</CardTitle></CardHeader>
            <CardContent className="space-y-4 text-sm text-muted-foreground">
              <p>მონაცემები ჩაიტვირთა ჩაშენებული export ფაილიდან და ბრაუზერის ლოკალურ საცავში ინახება.</p>
              <p>ამ პაკეტში არ არის შეტანილი ხელფასი, პირადი ნომერი, საბანკო მონაცემები, audit logs და დოკუმენტები.</p>
              <p className="text-foreground font-medium">Export: {seed?.exportedAt ? new Date(seed.exportedAt).toLocaleString('ka-GE') : 'იტვირთება...'}</p>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  );
}
