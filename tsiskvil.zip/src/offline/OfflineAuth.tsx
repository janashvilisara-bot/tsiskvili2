import { FormEvent, useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { ShieldCheck, Database, HardDrive, Cloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { connectCloudForHybridFeatures, createOfflineAdmin, getOfflineAdmin, getOfflineSession, getOfflineSeed, syncOfflineChangesToCloud } from './localStore';
import { useAuth } from '@/contexts/AuthContext';

export default function OfflineAuth() {
  const { signIn } = useAuth();
  const [hasAdmin, setHasAdmin] = useState(Boolean(getOfflineAdmin()));
  const [loading, setLoading] = useState(false);
  const [cloudLoading, setCloudLoading] = useState(false);
  const [counts, setCounts] = useState({ employees: 0, departments: 0, schedules: 0, holidays: 0 });

  useEffect(() => {
    getOfflineSeed().then((seed) => {
      setCounts({
        employees: seed.employees.length,
        departments: seed.departments.length,
        schedules: seed.workSchedules.length,
        holidays: seed.publicHolidays.length,
      });
    });
  }, []);

  if (getOfflineSession()) return <Navigate to="/employees" replace />;

  const handleSetup = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const fullName = String(form.get('fullName') || '').trim();
    const email = String(form.get('email') || '').trim();
    const password = String(form.get('password') || '');
    if (!fullName || !email.includes('@') || password.length < 8) {
      toast.error('შეავსეთ მონაცემები სწორად. პაროლი უნდა იყოს მინ. 8 სიმბოლო.');
      return;
    }
    setLoading(true);
    await createOfflineAdmin({ fullName, email, password });
    setHasAdmin(true);
    setLoading(false);
    toast.success('ლოკალური admin შეიქმნა');
    await signIn(email, password);
  };

  const handleLogin = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setLoading(true);
    try {
      await signIn(String(form.get('email') || ''), String(form.get('password') || ''));
    } catch {
      toast.error('ელ.ფოსტა ან პაროლი არასწორია');
    } finally {
      setLoading(false);
    }
  };

  const handleCloudConnect = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setCloudLoading(true);
    try {
      const result = await connectCloudForHybridFeatures(String(form.get('cloudEmail') || ''), String(form.get('cloudPassword') || ''));
      if (!result.ok) throw new Error(result.error);
      const sync = await syncOfflineChangesToCloud();
      toast.success(`Cloud ფუნქციები ჩართულია. აიტვირთა: ${sync.push.synced}, ჩამოიტვირთა: ${sync.pull.pulled}`);
    } catch (error: any) {
      toast.error(error?.message || 'Cloud კავშირი ვერ მოხერხდა');
    } finally {
      setCloudLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-background text-foreground grid lg:grid-cols-[0.95fr_1.05fr]">
      <section className="hidden lg:flex flex-col justify-between bg-sidebar text-sidebar-foreground p-12">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-lg bg-sidebar-primary/20 border border-sidebar-border flex items-center justify-center">
            <HardDrive className="h-5 w-5 text-sidebar-primary" />
          </div>
          <div>
            <p className="font-semibold">TalentOS Offline</p>
            <p className="text-sm text-sidebar-foreground/60">Standalone Windows Edition</p>
          </div>
        </div>
        <div className="space-y-6 max-w-lg">
          <h1 className="text-4xl font-bold leading-tight">მონაცემები ინახება ამ კომპიუტერზე</h1>
          <p className="text-sidebar-foreground/70 text-lg">ძირითადი მუშაობა ლოკალურია. Cloud ერთვება მხოლოდ SMS/Email, AI, Signify, backup და sync ფუნქციების გამოყენებისას.</p>
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-lg border border-sidebar-border bg-sidebar-accent/60 p-4"><p className="text-2xl font-bold">{counts.employees}</p><p className="text-sm text-sidebar-foreground/60">თანამშრომელი</p></div>
            <div className="rounded-lg border border-sidebar-border bg-sidebar-accent/60 p-4"><p className="text-2xl font-bold">{counts.departments}</p><p className="text-sm text-sidebar-foreground/60">დეპარტამენტი</p></div>
            <div className="rounded-lg border border-sidebar-border bg-sidebar-accent/60 p-4"><p className="text-2xl font-bold">{counts.schedules}</p><p className="text-sm text-sidebar-foreground/60">გრაფიკი</p></div>
            <div className="rounded-lg border border-sidebar-border bg-sidebar-accent/60 p-4"><p className="text-2xl font-bold">{counts.holidays}</p><p className="text-sm text-sidebar-foreground/60">უქმე დღე</p></div>
          </div>
        </div>
        <p className="text-xs text-sidebar-foreground/50">Hybrid Cloud · Local-first · Sync queue</p>
      </section>

      <section className="flex items-center justify-center p-6">
        <Card className="w-full max-w-md shadow-xl">
          <CardHeader>
            <div className="h-12 w-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-2">
              {hasAdmin ? <ShieldCheck className="h-6 w-6" /> : <Database className="h-6 w-6" />}
            </div>
            <CardTitle>{hasAdmin ? 'Offline შესვლა' : 'პირველი admin-ის შექმნა'}</CardTitle>
            <CardDescription>{hasAdmin ? 'შედით ლოკალური admin ანგარიშით.' : 'ეს ანგარიში შეინახება მხოლოდ ამ კომპიუტერზე.'}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <form className="space-y-4" onSubmit={hasAdmin ? handleLogin : handleSetup}>
              {!hasAdmin && (
                <div className="space-y-2">
                  <Label htmlFor="fullName">სახელი და გვარი</Label>
                  <Input id="fullName" name="fullName" autoComplete="name" />
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="email">ელ.ფოსტა</Label>
                <Input id="email" name="email" type="email" autoComplete="email" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">პაროლი</Label>
                <Input id="password" name="password" type="password" autoComplete={hasAdmin ? 'current-password' : 'new-password'} />
              </div>
              <Button className="w-full" disabled={loading}>{loading ? 'მუშავდება...' : hasAdmin ? 'შესვლა' : 'admin-ის შექმნა'}</Button>
            </form>
            {hasAdmin && (
              <form className="space-y-3 border-t border-border pt-5" onSubmit={handleCloudConnect}>
                <div className="flex items-center gap-2 text-sm font-medium text-foreground"><Cloud className="h-4 w-4 text-primary" /> Cloud ფუნქციების ჩართვა</div>
                <p className="text-xs text-muted-foreground">საჭიროა მხოლოდ SMS/Email, AI, Signify, backup და sync ფუნქციებისთვის.</p>
                <Input name="cloudEmail" type="email" placeholder="Cloud ელ.ფოსტა" autoComplete="email" />
                <Input name="cloudPassword" type="password" placeholder="Cloud პაროლი" autoComplete="current-password" />
                <Button type="submit" variant="outline" className="w-full" disabled={cloudLoading}>{cloudLoading ? 'უკავშირდება...' : 'Cloud-თან დაკავშირება'}</Button>
              </form>
            )}
          </CardContent>
        </Card>
      </section>
    </main>
  );
}
