export type OfflineAdmin = {
  fullName: string;
  email: string;
  passwordHash: string;
  salt: string;
  createdAt: string;
};

export type OfflineSession = {
  id: string;
  email: string;
  fullName: string;
  role: 'admin';
};

export type CloudLoginResult = {
  ok: boolean;
  user?: { id: string; email?: string };
  error?: string;
};

export type OfflineSeed = {
  exportedAt: string;
  source: string;
  tables?: Record<string, Array<Record<string, unknown>>>;
  storageObjects?: Array<Record<string, unknown>>;
  employees: Array<Record<string, unknown>>;
  departments: Array<Record<string, unknown>>;
  workSchedules: Array<Record<string, unknown>>;
  publicHolidays: Array<Record<string, unknown>>;
};

const ADMIN_KEY = 'talentos.offline.admin';
const SESSION_KEY = 'talentos.offline.session';
const SEED_KEY = 'talentos.offline.seed';

export const isOfflineStandalone = () =>
  window.location.protocol === 'file:' || import.meta.env.VITE_TALENTOS_OFFLINE === 'true';

const toHex = (buffer: ArrayBuffer) =>
  Array.from(new Uint8Array(buffer)).map((byte) => byte.toString(16).padStart(2, '0')).join('');

export const hashPassword = async (password: string, salt: string = crypto.randomUUID()) => {
  const data = new TextEncoder().encode(`${salt}:${password}`);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return { salt, passwordHash: toHex(digest) };
};

export const getOfflineAdmin = (): OfflineAdmin | null => {
  const raw = localStorage.getItem(ADMIN_KEY);
  return raw ? JSON.parse(raw) : null;
};

export const createOfflineAdmin = async (input: { fullName: string; email: string; password: string }) => {
  const credentials = await hashPassword(input.password);
  const admin: OfflineAdmin = {
    fullName: input.fullName.trim(),
    email: input.email.trim().toLowerCase(),
    ...credentials,
    createdAt: new Date().toISOString(),
  };
  localStorage.setItem(ADMIN_KEY, JSON.stringify(admin));
  return admin;
};

export const validateOfflineLogin = async (email: string, password: string) => {
  const admin = getOfflineAdmin();
  if (!admin || admin.email !== email.trim().toLowerCase()) return null;
  const credentials = await hashPassword(password, String(admin.salt));
  if (credentials.passwordHash !== admin.passwordHash) return null;
  const session: OfflineSession = {
    id: 'offline-admin',
    email: admin.email,
    fullName: admin.fullName,
    role: 'admin',
  };
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  return session;
};

export const getOfflineSession = (): OfflineSession | null => {
  const raw = localStorage.getItem(SESSION_KEY);
  return raw ? JSON.parse(raw) : null;
};

export const clearOfflineSession = () => {
  localStorage.removeItem(SESSION_KEY);
};

export const connectCloudForHybridFeatures = async (email: string, password: string): Promise<CloudLoginResult> => {
  const response = await fetch('/offline/v1/cloud-login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) return { ok: false, error: result.error || result.msg || 'Cloud კავშირი ვერ მოხერხდა' };
  return { ok: true, user: result.user };
};

export const syncOfflineChangesToCloud = async () => {
  const response = await fetch('/offline/v1/sync', { method: 'POST' });
  if (!response.ok) throw new Error('სინქრონიზაცია ვერ მოხერხდა');
  return response.json() as Promise<{
    ok: boolean;
    push: { synced: number; remaining: number };
    pull: { pulled: number; tables: number; requiresCloudLogin?: boolean };
  }>;
};

export const getOfflineSeed = async (): Promise<OfflineSeed> => {
  const cached = localStorage.getItem(SEED_KEY);
  if (cached) return JSON.parse(cached);
  const response = await fetch('./offline-seed.json');
  if (!response.ok) {
    return { exportedAt: new Date().toISOString(), source: 'empty', tables: {}, storageObjects: [], employees: [], departments: [], workSchedules: [], publicHolidays: [] };
  }
  const seed = await response.json();
  localStorage.setItem(SEED_KEY, JSON.stringify(seed));
  return seed;
};

export const getOfflineTable = async (table: string): Promise<Array<Record<string, unknown>>> => {
  const seed = await getOfflineSeed();
  if (seed.tables?.[table]) return seed.tables[table];
  if (table === 'employees') return seed.employees;
  if (table === 'departments') return seed.departments;
  if (table === 'work_schedules') return seed.workSchedules;
  if (table === 'public_holidays') return seed.publicHolidays;
  return [];
};

export const setOfflineTable = async (table: string, rows: Array<Record<string, unknown>>) => {
  const seed = await getOfflineSeed();
  const nextSeed = { ...seed, tables: { ...(seed.tables ?? {}), [table]: rows } };
  localStorage.setItem(SEED_KEY, JSON.stringify(nextSeed));
};
