import { ReactNode } from "react";
import { LucideIcon } from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { cn } from "@/lib/utils";

interface ReportPageShellProps {
  title: string;
  description?: string;
  icon: LucideIcon;
  /** Tailwind gradient classes, e.g. "from-violet-400 via-purple-500 to-fuchsia-500" */
  gradient: string;
  /** Tailwind shadow class, e.g. "shadow-purple-500/30" */
  shadow?: string;
  actions?: ReactNode;
  children: ReactNode;
}

export function ReportPageShell({
  title,
  description,
  icon: Icon,
  gradient,
  shadow = "shadow-primary/30",
  actions,
  children,
}: ReportPageShellProps) {
  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div
                className={cn(
                  "p-4 rounded-2xl bg-gradient-to-br shadow-xl animate-scale-in",
                  gradient,
                  shadow
                )}
              >
                <Icon className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-5xl font-bold bg-gradient-to-r from-foreground via-foreground/90 to-foreground/70 bg-clip-text text-transparent">
                  {title}
                </h1>
                {description && (
                  <p className="text-muted-foreground mt-1 text-base md:text-lg">
                    {description}
                  </p>
                )}
              </div>
            </div>
            {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
          </div>

          {children}
        </div>
      </div>
    </PageTransition>
  );
}
