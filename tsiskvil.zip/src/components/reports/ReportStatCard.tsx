import { LucideIcon, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface ReportStatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  /** Tailwind gradient, e.g. "from-violet-500 to-purple-600" */
  gradient: string;
  /** Background tint, e.g. "bg-violet-500/10" */
  bgColor: string;
  trend?: string;
  trendUp?: boolean;
  description?: string;
  index?: number;
}

export function ReportStatCard({
  title,
  value,
  icon: Icon,
  gradient,
  bgColor,
  trend,
  trendUp = true,
  description,
  index = 0,
}: ReportStatCardProps) {
  return (
    <Card
      className={cn(
        "group relative overflow-hidden border-border/50 bg-card/80 backdrop-blur-xl",
        "hover:shadow-2xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-2",
        "animate-fade-in"
      )}
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

      <CardContent className="p-6 relative">
        <div className="flex items-start justify-between mb-4">
          <div
            className={cn(
              "p-3 rounded-xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-3",
              bgColor
            )}
          >
            <Icon className="h-6 w-6 text-primary" />
          </div>

          {trend && (
            <div
              className={cn(
                "flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full transition-all duration-300",
                trendUp
                  ? "text-emerald-600 bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-400"
                  : "text-amber-600 bg-amber-100 dark:bg-amber-950/50 dark:text-amber-400"
              )}
            >
              {trendUp ? (
                <ArrowUpRight className="h-3 w-3" />
              ) : (
                <ArrowDownRight className="h-3 w-3" />
              )}
              <span>{trend}</span>
            </div>
          )}
        </div>

        <div className="space-y-1">
          <div className="text-2xl md:text-3xl font-bold tracking-tight group-hover:scale-105 transition-transform duration-300 origin-left">
            {value}
          </div>
          <div className="text-sm text-muted-foreground font-medium">
            {title}
          </div>
          {description && (
            <div className="text-xs text-muted-foreground/70">{description}</div>
          )}
        </div>

        <div
          className={cn(
            "absolute -right-8 -bottom-8 w-32 h-32 rounded-full blur-3xl opacity-0 group-hover:opacity-30 transition-opacity duration-500 bg-gradient-to-br",
            gradient
          )}
        />
      </CardContent>
    </Card>
  );
}
