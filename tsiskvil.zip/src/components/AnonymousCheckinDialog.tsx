import { useState } from "react";
import { Smile, Meh, Frown, Lock, Send, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";
import { markCheckedInToday } from "@/lib/dailyCheckin";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const TEXT = {
  ka: {
    title: "როგორ გრძნობ თავს დღეს?",
    subtitle: "თქვენი კეთილდღეობის ყოველდღიური შეფასება",
    anon: "ეს გამოკითხვა სრულიად ანონიმურია. თქვენი სახელი და გვარი არავის უჩანს - არც HR-ს, არც ადმინისტრატორს.",
    stress: "სტრესის დონე (1-5)",
    notes: "დამატებითი კომენტარი (არასავალდებულო)...",
    submit: "გაგზავნა და გასვლა",
    cancel: "გაუქმება (დარჩენა სისტემაში)",
    failed: "გაგზავნა ვერ მოხერხდა, სცადეთ თავიდან",
    moods: ["შესანიშნავი", "კარგი", "ნორმალური", "ცუდი", "ძალიან ცუდი"],
  },
  en: {
    title: "How are you feeling today?",
    subtitle: "Your daily well-being check",
    anon: "This survey is completely anonymous. Your name is not visible to anyone - not HR, not administrators.",
    stress: "Stress level (1-5)",
    notes: "Additional comment (optional)...",
    submit: "Send and sign out",
    cancel: "Cancel (stay signed in)",
    failed: "Could not send, please try again",
    moods: ["Excellent", "Good", "Okay", "Bad", "Very bad"],
  },
} as const;

const MOODS = [
  { value: 5, icon: Smile, color: "text-emerald-500" },
  { value: 4, icon: Smile, color: "text-teal-500" },
  { value: 3, icon: Meh, color: "text-amber-500" },
  { value: 2, icon: Frown, color: "text-orange-500" },
  { value: 1, icon: Frown, color: "text-red-500" },
];

interface Props {
  open: boolean;
  onCancel: () => void;
  onDone: () => void;
}

export function AnonymousCheckinDialog({ open, onCancel, onDone }: Props) {
  const { language } = useLanguage();
  const txt = TEXT[language === "en" ? "en" : "ka"];
  const [mood, setMood] = useState<number | null>(null);
  const [stress, setStress] = useState<number | null>(null);
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const submit = async () => {
    if (mood === null) return;
    setSubmitting(true);
    const { error } = await supabase.from("wellness_checkins").insert({
      employee_id: null,
      is_anonymous: true,
      checkin_date: new Date().toISOString().split("T")[0],
      mood_rating: mood,
      stress_level: stress,
      notes: notes.trim() || null,
    });
    setSubmitting(false);
    if (error) {
      console.error("anonymous check-in failed", error.code);
      toast.error(txt.failed);
      return;
    }
    markCheckedInToday();
    setMood(null);
    setStress(null);
    setNotes("");
    onDone();
  };

  return (
    <Dialog open={open}>
      <DialogContent
        className="max-w-lg max-h-[90dvh] overflow-y-auto [&>button]:hidden"
        onInteractOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
      >
        <DialogHeader className="text-center sm:text-center">
          <DialogTitle className="text-2xl">{txt.title}</DialogTitle>
          <DialogDescription>{txt.subtitle}</DialogDescription>
        </DialogHeader>

        <div className="flex items-start gap-2.5 rounded-xl border border-primary/30 bg-primary/10 p-3 text-sm text-foreground">
          <Lock className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
          <p className="font-medium">{txt.anon}</p>
        </div>

        <div className="flex justify-between gap-1">
          {MOODS.map((m, i) => (
            <button
              key={m.value}
              type="button"
              onClick={() => setMood(m.value)}
              aria-pressed={mood === m.value}
              className={cn(
                "flex flex-1 min-w-0 flex-col items-center gap-1.5 px-0.5 py-2 rounded-2xl border-2 transition-all",
                mood === m.value ? "border-primary bg-primary/5 scale-105 shadow-md" : "border-transparent hover:border-border",
                m.color
              )}
            >
              <m.icon className="h-8 w-8 sm:h-9 sm:w-9" />
              <span className="text-[10px] sm:text-[11px] font-medium text-center leading-tight break-words">{txt.moods[i]}</span>
            </button>
          ))}
        </div>

        <div className="space-y-2">
          <p className="text-sm font-medium text-center">{txt.stress}</p>
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((level) => (
              <button
                key={level}
                type="button"
                onClick={() => setStress(level)}
                className={cn(
                  "w-11 h-11 rounded-xl font-bold text-lg transition-all",
                  stress === level ? "bg-primary text-primary-foreground scale-105 shadow-md" : "bg-muted hover:bg-muted/80"
                )}
              >
                {level}
              </button>
            ))}
          </div>
        </div>

        <Textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder={txt.notes}
          maxLength={1000}
          className="resize-none"
          rows={3}
        />

        <div className="flex flex-col gap-2">
          <Button onClick={submit} disabled={mood === null || submitting} size="lg" className="w-full">
            {submitting ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Send className="h-4 w-4 mr-2" />}
            {txt.submit}
          </Button>
          <Button variant="ghost" onClick={onCancel} disabled={submitting} className="w-full">
            {txt.cancel}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
