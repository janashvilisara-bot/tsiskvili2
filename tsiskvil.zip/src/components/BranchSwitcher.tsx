import { Building2, Check, ChevronsUpDown, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { useBranch } from "@/contexts/BranchContext";
import { useState } from "react";
import { cn } from "@/lib/utils";

export function BranchSwitcher() {
  const { branches, activeBranch, canViewAll, hasMultipleBranches, setActiveBranchId, isLoading } =
    useBranch();
  const [open, setOpen] = useState(false);

  // Hide switcher when only one branch is accessible and user can't view all
  if (isLoading || (!hasMultipleBranches && !canViewAll)) return null;

  const label = activeBranch ? activeBranch.name : "ყველა ფილიალი";

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          aria-label="ფილიალის არჩევა"
          className="h-9 w-full sm:w-auto sm:min-w-[180px] sm:max-w-[240px] justify-between gap-2"
        >
          <div className="flex items-center gap-2 truncate">
            {activeBranch ? (
              <Building2 className="h-4 w-4 text-primary shrink-0" />
            ) : (
              <Globe className="h-4 w-4 text-primary shrink-0" />
            )}
            <span className="truncate text-sm font-medium">{label}</span>
          </div>
          <ChevronsUpDown className="h-4 w-4 opacity-50 shrink-0" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[260px] p-0" align="end">
        <Command>
          <CommandInput placeholder="ფილიალის ძიება..." />
          <CommandList>
            <CommandEmpty>ფილიალი ვერ მოიძებნა</CommandEmpty>
            {canViewAll && (
              <CommandGroup heading="ხედვა">
                <CommandItem
                  value="__all__"
                  onSelect={() => {
                    setActiveBranchId(null);
                    setOpen(false);
                  }}
                >
                  <Globe className="mr-2 h-4 w-4 text-primary" />
                  <span className="flex-1">ყველა ფილიალი</span>
                  <Check
                    className={cn(
                      "ml-2 h-4 w-4",
                      activeBranch === null ? "opacity-100" : "opacity-0"
                    )}
                  />
                </CommandItem>
              </CommandGroup>
            )}
            <CommandGroup heading="ფილიალები">
              {branches.map((branch) => (
                <CommandItem
                  key={branch.id}
                  value={branch.name}
                  onSelect={() => {
                    setActiveBranchId(branch.id);
                    setOpen(false);
                  }}
                >
                  <Building2 className="mr-2 h-4 w-4 text-muted-foreground" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{branch.name}</div>
                    {branch.city && (
                      <div className="text-xs text-muted-foreground truncate">
                        {branch.city}
                      </div>
                    )}
                  </div>
                  <Check
                    className={cn(
                      "ml-2 h-4 w-4",
                      activeBranch?.id === branch.id ? "opacity-100" : "opacity-0"
                    )}
                  />
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
