import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { CheckCircle, XCircle, Smartphone } from "lucide-react";
import GlobalCellLogo from "./GlobalCellLogo";
import { formatters } from "@/lib/dateUtils";
import { useAuth } from "@/contexts/AuthContext";

interface EsimRequest {
  id: string;
  status: string;
  notes: string | null;
  rejection_reason: string | null;
  created_at: string;
  trip_id: string;
  plan_id: string;
  employee_id: string;
  esim_plans: {
    region: string;
    data_gb: number;
    validity_days: number;
    price: number;
    description: string | null;
  };
  employees: {
    full_name: string;
  };
  business_trip_requests: {
    destination: string;
    start_date: string;
    end_date: string;
  };
}

const EsimRequestsTab = () => {
  const { user } = useAuth();
  const [requests, setRequests] = useState<EsimRequest[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    try {
      const { data, error } = await supabase
        .from("esim_requests")
        .select(`
          *,
          esim_plans (region, data_gb, validity_days, price, description),
          employees (full_name),
          business_trip_requests (destination, start_date, end_date)
        `)
        .order("created_at", { ascending: false });
      if (error) throw error;
      setRequests((data || []) as unknown as EsimRequest[]);
    } catch {
      toast.error("eSIM მოთხოვნების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (id: string, status: string, rejectionReason?: string) => {
    try {
      // Get current employee for approved_by
      const { data: empData } = await supabase
        .from("employees")
        .select("id")
        .eq("email", user?.email)
        .maybeSingle();

      const updateData: any = { 
        status, 
        approved_by: empData?.id,
        approved_at: new Date().toISOString(),
      };
      if (rejectionReason) updateData.rejection_reason = rejectionReason;

      const { error } = await supabase.from("esim_requests").update(updateData).eq("id", id);
      if (error) throw error;
      toast.success(`eSIM მოთხოვნა ${status === "approved" ? "დამტკიცდა" : "უარყოფილია"}`);
      fetchRequests();
    } catch {
      toast.error("სტატუსის განახლება ვერ მოხერხდა");
    }
  };

  const getStatusBadge = (status: string) => {
    const map: Record<string, { variant: any; label: string }> = {
      pending: { variant: "secondary", label: "მოლოდინში" },
      approved: { variant: "default", label: "დამტკიცებული" },
      rejected: { variant: "destructive", label: "უარყოფილი" },
    };
    const c = map[status] || map.pending;
    return <Badge variant={c.variant}>{c.label}</Badge>;
  };

  if (loading) {
    return <div className="flex justify-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" /></div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GlobalCellLogo className="h-6 w-auto" />
          eSIM მოთხოვნები
        </CardTitle>
      </CardHeader>
      <CardContent>
        {requests.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">eSIM მოთხოვნები არ მოიძებნა</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>თანამშრომელი</TableHead>
                  <TableHead>მივლინება</TableHead>
                  <TableHead>პაკეტი</TableHead>
                  <TableHead>ფასი</TableHead>
                  <TableHead>სტატუსი</TableHead>
                  <TableHead>თარიღი</TableHead>
                  <TableHead>მოქმედება</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {requests.map(req => (
                  <TableRow key={req.id}>
                    <TableCell className="font-medium">{req.employees?.full_name}</TableCell>
                    <TableCell>{req.business_trip_requests?.destination}</TableCell>
                    <TableCell>
                      {req.esim_plans?.region} - {req.esim_plans?.data_gb}GB / {req.esim_plans?.validity_days} დღე
                    </TableCell>
                    <TableCell className="font-semibold">{req.esim_plans?.price}₾</TableCell>
                    <TableCell>{getStatusBadge(req.status)}</TableCell>
                    <TableCell className="text-muted-foreground">{formatters.shortDate(req.created_at)}</TableCell>
                    <TableCell>
                      {req.status === "pending" && (
                        <div className="flex gap-1">
                          <Button size="sm" variant="default" className="h-7 text-xs gap-1" onClick={() => handleUpdate(req.id, "approved")}>
                            <CheckCircle className="h-3 w-3" /> დამტკიცება
                          </Button>
                          <Button size="sm" variant="destructive" className="h-7 text-xs gap-1" onClick={() => {
                            const reason = prompt("უარყოფის მიზეზი:");
                            if (reason) handleUpdate(req.id, "rejected", reason);
                          }}>
                            <XCircle className="h-3 w-3" /> უარყოფა
                          </Button>
                        </div>
                      )}
                      {req.rejection_reason && (
                        <p className="text-xs text-destructive mt-1">{req.rejection_reason}</p>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default EsimRequestsTab;
