import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Smartphone, Wifi, Check, CheckCircle, XCircle, ExternalLink } from "lucide-react";
import GlobalCellLogo from "./GlobalCellLogo";
import { useAuth } from "@/contexts/AuthContext";

interface EsimPlan {
  id: string;
  region: string;
  country: string | null;
  data_gb: number;
  validity_days: number;
  price: number;
  currency: string;
  description: string | null;
}

interface EsimOfferSectionProps {
  tripId: string;
  employeeId: string;
  userId: string;
  destination: string;
  existingRequest?: any;
  onRequestUpdated?: () => void;
}

const EsimOfferSection = ({ tripId, employeeId, userId, destination, existingRequest, onRequestUpdated }: EsimOfferSectionProps) => {
  const { userRole } = useAuth();
  const [plans, setPlans] = useState<EsimPlan[]>([]);
  const [selectedRegion, setSelectedRegion] = useState<string>("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchPlans();
  }, []);

  const fetchPlans = async () => {
    const { data } = await supabase
      .from("esim_plans")
      .select("*")
      .eq("is_active", true)
      .order("region")
      .order("price");
    if (data) setPlans(data as EsimPlan[]);
  };

  const regions = [...new Set(plans.map(p => p.region))];
  const filteredPlans = selectedRegion ? plans.filter(p => p.region === selectedRegion) : plans;

  const handleRequest = async (planId: string) => {
    setLoading(true);
    try {
      const { error } = await supabase.from("esim_requests").insert({
        trip_id: tripId,
        plan_id: planId,
        employee_id: employeeId,
        user_id: userId,
        status: "pending",
      });
      if (error) throw error;
      toast.success("eSIM მოთხოვნა გაიგზავნა HR-ის დასამტკიცებლად");
    } catch {
      toast.error("eSIM მოთხოვნის გაგზავნა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const isAdminOrHr = userRole === "admin" || userRole === "hr_manager";

  const handleApproveReject = async (status: string, rejectionReason?: string) => {
    try {
      const { data: authData } = await supabase.auth.getUser();
      const { data: empData } = await supabase
        .from("employees").select("id").eq("email", authData.user?.email ?? "").maybeSingle();
      
      const updateData: any = { status, approved_by: empData?.id, approved_at: new Date().toISOString() };
      if (rejectionReason) updateData.rejection_reason = rejectionReason;
      
      
      const { error, data } = await supabase.from("esim_requests").update(updateData).eq("id", existingRequest.id).select();
      
      
      if (error) throw error;
      if (!data || data.length === 0) throw new Error("No rows updated - possible RLS issue");
      
      toast.success(`eSIM მოთხოვნა ${status === "approved" ? "დამტკიცდა" : "უარყოფილია"}`);
      onRequestUpdated?.();
    } catch (err: any) {
      console.error("eSIM update error:", err);
      toast.error("სტატუსის განახლება ვერ მოხერხდა: " + (err?.message || ""));
    }
  };

  if (existingRequest) {
    return (
      <div className="mt-3 p-3 rounded-lg border border-primary/20 bg-primary/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm">
            <GlobalCellLogo className="h-5 w-auto" />
            <span className="font-medium">eSIM</span>
            <Badge variant={existingRequest.status === "approved" ? "default" : existingRequest.status === "rejected" ? "destructive" : "secondary"}>
              {existingRequest.status === "approved" ? "დამტკიცებული" : existingRequest.status === "rejected" ? "უარყოფილი" : "მოლოდინში"}
            </Badge>
          </div>
          {isAdminOrHr && existingRequest.status === "pending" && (
            <div className="flex gap-1">
              <Button size="sm" variant="default" className="h-7 text-xs gap-1" onClick={() => handleApproveReject("approved")}>
                <CheckCircle className="h-3 w-3" /> დამტკიცება
              </Button>
              <Button size="sm" variant="destructive" className="h-7 text-xs gap-1" onClick={() => {
                const reason = prompt("უარყოფის მიზეზი:");
                if (reason) handleApproveReject("rejected", reason);
              }}>
                <XCircle className="h-3 w-3" /> უარყოფა
              </Button>
            </div>
          )}
        </div>
        {existingRequest.status === "approved" && (
          <div className="mt-2 p-2 rounded-md bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
            <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
              <Check className="h-3 w-3 text-green-600" /> მოთხოვნა დამტკიცებულია - შეგიძლიათ შეიძინოთ eSIM
            </p>
            <Button
              size="sm"
              variant="default"
              className="h-8 text-xs gap-2"
              onClick={() => window.open("https://globalcell.ge", "_blank")}
            >
              <ExternalLink className="h-3 w-3" />
              შეიძინეთ Global Cell-ზე
            </Button>
          </div>
        )}
        {existingRequest.rejection_reason && (
          <p className="text-xs text-destructive mt-1">მიზეზი: {existingRequest.rejection_reason}</p>
        )}
      </div>
    );
  }

  return (
    <div className="mt-3 p-4 rounded-lg border border-primary/20 bg-gradient-to-r from-primary/5 to-accent/5">
      <div className="flex items-center gap-2 mb-3">
        <GlobalCellLogo className="h-6 w-auto" />
        <h4 className="font-semibold text-sm">eSIM - შპს გლობალ სელი</h4>
      </div>
      <p className="text-xs text-muted-foreground mb-3">
        მივლინებისთვის ({destination}) აირჩიეთ eSIM პაკეტი:
      </p>

      <Select value={selectedRegion} onValueChange={setSelectedRegion}>
        <SelectTrigger className="mb-3 h-8 text-xs">
          <SelectValue placeholder="აირჩიეთ რეგიონი" />
        </SelectTrigger>
        <SelectContent>
          {regions.map(r => (
            <SelectItem key={r} value={r}>{r}</SelectItem>
          ))}
        </SelectContent>
      </Select>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {filteredPlans.slice(0, 6).map(plan => (
          <div key={plan.id} className="flex items-center justify-between p-2 rounded-md border bg-background text-xs">
            <div>
              <p className="font-medium">{plan.data_gb}GB - {plan.validity_days} დღე</p>
              <p className="text-muted-foreground">{plan.region}</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-primary">{plan.price}₾</span>
              <Button size="sm" variant="outline" className="h-7 text-xs" disabled={loading} onClick={() => handleRequest(plan.id)}>
                მოთხოვნა
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EsimOfferSection;
