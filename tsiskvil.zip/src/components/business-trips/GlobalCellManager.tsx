import { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Smartphone, Wifi, DollarSign, Package, Phone, RefreshCw, QrCode, Plus, CreditCard, Loader2, ArrowLeft, Clock, Search, ChevronRight, ShoppingCart } from "lucide-react";
import GlobalCellLogo from "./GlobalCellLogo";

interface AccountInfo {
  accountName: string;
  accountId: string;
  accountBalance: number;
  esimCost: number;
  numbersCostByCountryCode: Array<{ countryCode: string; cost: number }>;
  topUpServiceCommissionPercent: number;
  packageTypesAllowed: string[];
}

interface PackageItem {
  packageId: number;
  name: string;
  countryOrZone?: string;
  partnerCost: number;
  retailPrice: number;
}

interface MyEsim {
  esimId: string;
  iccid: string;
  msisdn?: string;
  status: string;
}

interface MyNumber {
  msisdn: string;
  status: string;
  iccid?: string;
}

// USD to GEL approximate rate
const USD_TO_GEL = 2.75;
const toGel = (usd: number) => (usd * USD_TO_GEL).toFixed(2);

// Country name → flag emoji mapping
const countryFlags: Record<string, string> = {
  Afghanistan: "🇦🇫", Albania: "🇦🇱", Algeria: "🇩🇿", Anguilla: "🇦🇮",
  Antiguaandbarbuda: "🇦🇬", Argentina: "🇦🇷", Armenia: "🇦🇲",
  Australia: "🇦🇺", Austria: "🇦🇹", Azerbaijan: "🇦🇿", Bahamas: "🇧🇸",
  Bahrain: "🇧🇭", Bangladesh: "🇧🇩", Barbados: "🇧🇧", Belarus: "🇧🇾",
  Belgium: "🇧🇪", Belize: "🇧🇿", Benin: "🇧🇯", Bermuda: "🇧🇲",
  Bhutan: "🇧🇹", Bolivia: "🇧🇴", Bosnia: "🇧🇦", Botswana: "🇧🇼",
  Brazil: "🇧🇷", Brunei: "🇧🇳", Bulgaria: "🇧🇬", Burkinafaso: "🇧🇫",
  Cambodia: "🇰🇭", Cameroon: "🇨🇲", Canada: "🇨🇦", Capeverde: "🇨🇻",
  Chad: "🇹🇩", Chile: "🇨🇱", China: "🇨🇳", Colombia: "🇨🇴",
  Congo: "🇨🇬", Costarica: "🇨🇷", Croatia: "🇭🇷", Cuba: "🇨🇺",
  Cyprus: "🇨🇾", Czech: "🇨🇿", Czechrepublic: "🇨🇿", Denmark: "🇩🇰",
  Dominica: "🇩🇲", Dominicanrepublic: "🇩🇴", Ecuador: "🇪🇨",
  Egypt: "🇪🇬", Elsalvador: "🇸🇻", Estonia: "🇪🇪", Ethiopia: "🇪🇹",
  Fiji: "🇫🇯", Finland: "🇫🇮", France: "🇫🇷", Gabon: "🇬🇦",
  Gambia: "🇬🇲", Georgia: "🇬🇪", Germany: "🇩🇪", Ghana: "🇬🇭",
  Greece: "🇬🇷", Grenada: "🇬🇩", Guatemala: "🇬🇹", Guinea: "🇬🇳",
  Guyana: "🇬🇾", Haiti: "🇭🇹", Honduras: "🇭🇳", Hongkong: "🇭🇰",
  Hungary: "🇭🇺", Iceland: "🇮🇸", India: "🇮🇳", Indonesia: "🇮🇩",
  Iran: "🇮🇷", Iraq: "🇮🇶", Ireland: "🇮🇪", Israel: "🇮🇱",
  Italy: "🇮🇹", Jamaica: "🇯🇲", Japan: "🇯🇵", Jordan: "🇯🇴",
  Kazakhstan: "🇰🇿", Kenya: "🇰🇪", Kosovo: "🇽🇰", Kuwait: "🇰🇼",
  Kyrgyzstan: "🇰🇬", Laos: "🇱🇦", Latvia: "🇱🇻", Lebanon: "🇱🇧",
  Liberia: "🇱🇷", Libya: "🇱🇾", Liechtenstein: "🇱🇮", Lithuania: "🇱🇹",
  Luxembourg: "🇱🇺", Macao: "🇲🇴", Madagascar: "🇲🇬", Malawi: "🇲🇼",
  Malaysia: "🇲🇾", Maldives: "🇲🇻", Mali: "🇲🇱", Malta: "🇲🇹",
  Mauritius: "🇲🇺", Mexico: "🇲🇽", Moldova: "🇲🇩", Monaco: "🇲🇨",
  Mongolia: "🇲🇳", Montenegro: "🇲🇪", Morocco: "🇲🇦", Mozambique: "🇲🇿",
  Myanmar: "🇲🇲", Namibia: "🇳🇦", Nepal: "🇳🇵", Netherlands: "🇳🇱",
  Newzealand: "🇳🇿", Nicaragua: "🇳🇮", Niger: "🇳🇪", Nigeria: "🇳🇬",
  Northmacedonia: "🇲🇰", Norway: "🇳🇴", Oman: "🇴🇲", Pakistan: "🇵🇰",
  Palestine: "🇵🇸", Panama: "🇵🇦", Paraguay: "🇵🇾", Peru: "🇵🇪",
  Philippines: "🇵🇭", Poland: "🇵🇱", Portugal: "🇵🇹", Puertorico: "🇵🇷",
  Qatar: "🇶🇦", Romania: "🇷🇴", Russia: "🇷🇺", Rwanda: "🇷🇼",
  Saudiarabia: "🇸🇦", Senegal: "🇸🇳", Serbia: "🇷🇸", Seychelles: "🇸🇨",
  Singapore: "🇸🇬", Slovakia: "🇸🇰", Slovenia: "🇸🇮", Southafrica: "🇿🇦",
  Southkorea: "🇰🇷", Spain: "🇪🇸", Srilanka: "🇱🇰", Sudan: "🇸🇩",
  Sweden: "🇸🇪", Switzerland: "🇨🇭", Taiwan: "🇹🇼", Tajikistan: "🇹🇯",
  Tanzania: "🇹🇿", Thailand: "🇹🇭", Togo: "🇹🇬", Trinidad: "🇹🇹",
  Tunisia: "🇹🇳", Turkey: "🇹🇷", Turkmenistan: "🇹🇲", Uganda: "🇺🇬",
  Ukraine: "🇺🇦", Unitedarabemirates: "🇦🇪", Unitedkingdom: "🇬🇧",
  Unitedstates: "🇺🇸", Uruguay: "🇺🇾", Uzbekistan: "🇺🇿",
  Venezuela: "🇻🇪", Vietnam: "🇻🇳", Zambia: "🇿🇲", Zimbabwe: "🇿🇼",
  Ausnz: "🌏", Africa: "🌍", America: "🌎", Asia: "🌏",
  Europe: "🌍", Latinamerica: "🌎", Middleeast: "🌍",
  Global: "🌐", World: "🌐", Worldwide: "🌐",
};

// Country name → ISO 3166-1 alpha-2 for flag images
const countryToIso: Record<string, string> = {
  Afghanistan:"af",Albania:"al",Algeria:"dz",Andorra:"ad",Angola:"ao",Anguilla:"ai",
  "Antigua & Barbuda":"ag",Argentina:"ar",Armenia:"am",Australia:"au",Austria:"at",
  Azerbaijan:"az",Bahamas:"bs",Bahrain:"bh",Bangladesh:"bd",Barbados:"bb",Belarus:"by",
  Belgium:"be",Belize:"bz",Benin:"bj",Bermuda:"bm",Bhutan:"bt",Bolivia:"bo",
  "Bosnia":"ba",Botswana:"bw",Brazil:"br",Brunei:"bn",Bulgaria:"bg","Burkina Faso":"bf",
  Cambodia:"kh",Cameroon:"cm",Canada:"ca","Cape Verde":"cv",Chad:"td",Chile:"cl",
  China:"cn",Colombia:"co",Congo:"cg","Costa Rica":"cr",Croatia:"hr",Cuba:"cu",
  Cyprus:"cy",Czech:"cz","Czech Republic":"cz",Denmark:"dk",Dominica:"dm",
  "Dominican Republic":"do",Ecuador:"ec",Egypt:"eg","El Salvador":"sv",Estonia:"ee",
  Ethiopia:"et",Fiji:"fj",Finland:"fi",France:"fr",Gabon:"ga",Gambia:"gm",
  Georgia:"ge",Germany:"de",Ghana:"gh",Greece:"gr",Grenada:"gd",Guatemala:"gt",
  Guinea:"gn",Guyana:"gy",Haiti:"ht",Honduras:"hn","Hong Kong":"hk",Hungary:"hu",
  Iceland:"is",India:"in",Indonesia:"id",Iran:"ir",Iraq:"iq",Ireland:"ie",
  Israel:"il",Italy:"it",Jamaica:"jm",Japan:"jp",Jordan:"jo",Kazakhstan:"kz",
  Kenya:"ke",Kosovo:"xk",Kuwait:"kw",Kyrgyzstan:"kg",Laos:"la",Latvia:"lv",
  Lebanon:"lb",Liberia:"lr",Libya:"ly",Liechtenstein:"li",Lithuania:"lt",
  Luxembourg:"lu",Macao:"mo",Madagascar:"mg",Malawi:"mw",Malaysia:"my",
  Maldives:"mv",Mali:"ml",Malta:"mt",Mauritius:"mu",Mexico:"mx",Moldova:"md",
  Monaco:"mc",Mongolia:"mn",Montenegro:"me",Morocco:"ma",Mozambique:"mz",
  Myanmar:"mm",Namibia:"na",Nepal:"np",Netherlands:"nl","New Zealand":"nz",
  Nicaragua:"ni",Niger:"ne",Nigeria:"ng","North Macedonia":"mk",Norway:"no",
  Oman:"om",Pakistan:"pk",Palestine:"ps",Panama:"pa",Paraguay:"py",Peru:"pe",
  Philippines:"ph",Poland:"pl",Portugal:"pt","Puerto Rico":"pr",Qatar:"qa",
  Romania:"ro",Russia:"ru",Rwanda:"rw","Saudi Arabia":"sa",Senegal:"sn",
  Serbia:"rs",Seychelles:"sc",Singapore:"sg",Slovakia:"sk",Slovenia:"si",
  "South Africa":"za","South Korea":"kr",Spain:"es","Sri Lanka":"lk",Sudan:"sd",
  Sweden:"se",Switzerland:"ch",Taiwan:"tw",Tajikistan:"tj",Tanzania:"tz",
  Thailand:"th",Togo:"tg",Trinidad:"tt",Tunisia:"tn",Turkey:"tr",
  Turkmenistan:"tm",Uganda:"ug",Ukraine:"ua","United Arab Emirates":"ae",
  "United Kingdom":"gb","United States":"us",Uruguay:"uy",Uzbekistan:"uz",
  Venezuela:"ve",Vietnam:"vn",Zambia:"zm",Zimbabwe:"zw",
};

const getFlagIso = (country: string): string | null => {
  const iso = countryToIso[country];
  if (iso) return iso;
  for (const [name, code] of Object.entries(countryToIso)) {
    if (name.toLowerCase().replace(/[\s&-]/g, "") === country.toLowerCase().replace(/[\s&-]/g, "")) {
      return code;
    }
  }
  return null;
};

const getFlagUrl = (country: string) => {
  const iso = getFlagIso(country);
  return iso ? `https://flagcdn.com/h80/${iso}.png` : null;
};

const regionNames = typeof Intl !== "undefined"
  ? new Intl.DisplayNames(["en"], { type: "region" })
  : null;

const isoCodeToFlag = (code: string) => {
  const normalized = code.trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(normalized)) return null;
  return String.fromCodePoint(...Array.from(normalized).map(char => 127397 + char.charCodeAt(0)));
};

const normalizeLabel = (value: string) => value.trim().replace(/[_-]+/g, " ").replace(/\s+/g, " ");

const toTitleCase = (value: string) => normalizeLabel(value)
  .split(" ")
  .filter(Boolean)
  .map(word => word === "&" ? "&" : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
  .join(" ");

const getCountryDisplayName = (countryOrZone?: string) => {
  if (!countryOrZone) return "";

  // Strip common prefixes/suffixes: "Lz 795 C Afghanistan 93 20260223" → "Afghanistan"
  const cleaned = normalizeLabel(countryOrZone);
  const upper = cleaned.toUpperCase();

  if (["GLOBAL", "WORLD", "WORLDWIDE"].includes(upper)) return "Global";
  if (/^[A-Z]{2}$/.test(upper)) return regionNames?.of(upper) || upper;

  // Extract only alphabetic words with 3+ chars (skip codes like "Lz", "C", numbers)
  const words = cleaned.split(/\s+/).filter(w => /^[A-Za-z]{3,}$/.test(w));
  if (words.length > 0) {
    return toTitleCase(words.join(" ").replace(/\bAND\b/gi, "&"));
  }

  return toTitleCase(cleaned.replace(/\bAND\b/gi, "&"));
};

const getFlag = (country: string) => {
  const isoFlag = isoCodeToFlag(country);
  if (isoFlag) return isoFlag;

  const normalized = country.replace(/[\s&-]/g, "");
  const capitalized = normalized.charAt(0).toUpperCase() + normalized.slice(1).toLowerCase();
  return countryFlags[country] || countryFlags[capitalized] || countryFlags[normalized] || "🌐";
};

const extractCountryFromPackageName = (name: string) => {
  // Handle both underscore-separated and space-separated formats
  // e.g. "AFGHANISTAN_1GB_7Days_9.72USD_795" or "Lz 795 C Afghanistan 93 20260223"
  const parts = name.includes("_") ? name.split("_").filter(Boolean) : name.split(/\s+/).filter(Boolean);
  const countryParts: string[] = [];

  for (const part of parts) {
    // Skip numeric codes, data sizes, days, prices, and short prefix codes like "Lz", "C"
    if (/^\d+(GB|MB)$/i.test(part) || /^\d+Days?$/i.test(part) || /USD$/i.test(part) || /^\d+(\.\d+)?$/i.test(part)) break;
    if (/^\d+$/.test(part)) continue; // skip pure numbers like "795", "93", "20260223"
    if (/^[A-Z]{1,2}$/i.test(part) && part.length <= 2) continue; // skip short codes like "Lz", "C"
    // Only keep words that look like country names (3+ chars, alphabetic)
    if (/^[A-Za-z]{3,}$/.test(part)) {
      countryParts.push(part);
    }
  }

  return countryParts.length > 0 ? toTitleCase(countryParts.join(" ").replace(/\bAND\b/gi, "&")) : "";
};

// Parse package name like "AFGHANISTAN_1GB_7Days_9.72USD_795"
const parsePackageName = (pkgOrName: PackageItem | string) => {
  const pkg = typeof pkgOrName === "string"
    ? ({ name: pkgOrName, countryOrZone: "", packageId: 0, partnerCost: 0, retailPrice: 0 } as PackageItem)
    : pkgOrName;

  const parts = pkg.name.split("_").filter(Boolean);
  let data = "";
  let validity = "";

  for (const part of parts) {
    if (/^\d+(GB|MB)$/i.test(part)) data = part.toUpperCase();
    if (/^\d+Days?$/i.test(part)) {
      const days = part.match(/\d+/)?.[0];
      validity = days ? `${days} დღე` : part;
    }
  }

  const country = getCountryDisplayName(pkg.countryOrZone) || extractCountryFromPackageName(pkg.name) || "Global";

  return { country, data, validity };
};

// Group packages by country
const groupByCountry = (packages: PackageItem[]) => {
  const groups: Record<string, PackageItem[]> = {};
  for (const pkg of packages) {
    const { country } = parsePackageName(pkg);
    if (!groups[country]) groups[country] = [];
    groups[country].push(pkg);
  }
  return groups;
};

type PackageView = "list" | "detail" | "purchase";

const GlobalCellManager = () => {
  const [loading, setLoading] = useState(false);
  const [accountInfo, setAccountInfo] = useState<AccountInfo | null>(null);
  const [packages, setPackages] = useState<PackageItem[]>([]);
  const [myEsims, setMyEsims] = useState<MyEsim[]>([]);
  const [myNumbers, setMyNumbers] = useState<MyNumber[]>([]);
  const [orderQuantity, setOrderQuantity] = useState(1);
  const [selectedTab, setSelectedTab] = useState("overview");
  const [apiConfigured, setApiConfigured] = useState<boolean | null>(null);

  // Package flow states
  const [packageView, setPackageView] = useState<PackageView>("list");
  const [selectedCountry, setSelectedCountry] = useState<string>("");
  const [selectedPackage, setSelectedPackage] = useState<PackageItem | null>(null);
  const [packageSearch, setPackageSearch] = useState("");
  const [selectedEsimForPackage, setSelectedEsimForPackage] = useState<string>("");
  const [purchaseMode, setPurchaseMode] = useState<"existing" | "new">("new");
  const [numberSearch, setNumberSearch] = useState("");
  const [availableNumbers, setAvailableNumbers] = useState<MyNumber[]>([]);
  const [selectedNumber, setSelectedNumber] = useState<string>("");
  const [selectedBalance, setSelectedBalance] = useState<number>(5);
  const [purchasing, setPurchasing] = useState(false);

  const balanceOptions = [5, 10, 20, 30, 50, 100, 150, 200, 300, 500, 1000, 1500];

  useEffect(() => {
    checkApiKey();
  }, []);

  const checkApiKey = async () => {
    const { data } = await supabase
      .from("integration_settings")
      .select("settings")
      .eq("provider", "globalcell")
      .maybeSingle();
    const settings = data?.settings as Record<string, any> | null;
    setApiConfigured(!!settings?.api_key);
    if (settings?.api_key) {
      fetchAccountInfo();
    }
  };

  const callApi = async (endpoint: string, body?: any, iccid?: string) => {
    const params = new URLSearchParams({ endpoint });
    if (iccid) params.set("iccid", iccid);

    const { data, error } = await supabase.functions.invoke("globalcell-api?" + params.toString(), {
      method: "POST",
      body: body ?? {},
    });

    if (error) {
      let detailedMessage = error.message;
      const context = (error as { context?: Response }).context;
      if (context) {
        try {
          const payload = await context.clone().json();
          detailedMessage = payload?.error || payload?.message || payload?.detail || detailedMessage;
        } catch {
          try {
            const textPayload = await context.text();
            if (textPayload) detailedMessage = textPayload;
          } catch {}
        }
      }
      throw new Error(detailedMessage);
    }
    if (data?.error) throw new Error(data.error);
    return data;
  };

  const fetchAccountInfo = async () => {
    setLoading(true);
    try {
      const data = await callApi("account-info");
      setAccountInfo(data);
    } catch (err: any) {
      if (err.message?.includes("not configured")) {
        setApiConfigured(false);
      } else {
        toast.error("ანგარიშის ინფორმაცია ვერ ჩაიტვირთა: " + err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchPackages = async () => {
    setLoading(true);
    try {
      const data = await callApi("packages-list");
      const pkgList = Array.isArray(data) ? data : (data?.packages || data?.list || data?.data || []);
      setPackages(pkgList);
      if (pkgList.length === 0) {
        toast.info("პაკეტები ვერ მოიძებნა. API-დან ცარიელი პასუხი დაბრუნდა.");
      }
    } catch (err: any) {
      toast.error("პაკეტების ჩატვირთვა ვერ მოხერხდა: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchMyEsims = async () => {
    setLoading(true);
    try {
      const data = await callApi("my-esims");
      setMyEsims(data.esims || []);
    } catch (err: any) {
      toast.error("eSIM-ების ჩატვირთვა ვერ მოხერხდა: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchMyNumbers = async () => {
    setLoading(true);
    try {
      const data = await callApi("my-numbers");
      setMyNumbers(data.numbers || []);
    } catch (err: any) {
      toast.error("ნომრების ჩატვირთვა ვერ მოხერხდა: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchAvailableNumbers = async () => {
    setLoading(true);
    try {
      const data = await callApi("numbers-list");
      // API may return array directly or nested
      const numList = Array.isArray(data) ? data : (data?.numbers || data?.list || data?.data || []);
      // Normalize to MyNumber shape
      const normalized: MyNumber[] = numList.map((n: any) => ({
        msisdn: n.msisdn || n.number || n.phoneNumber || String(n),
        status: n.status || "available",
        iccid: n.iccid,
      }));
      setAvailableNumbers(normalized);
      if (normalized.length === 0) {
      }
    } catch (err: any) {
      console.error("Available numbers fetch error:", err.message);
      toast.error("ნომრების ბაზის ჩატვირთვა ვერ მოხერხდა: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleOrderEsims = async () => {
    if (orderQuantity < 1) return;
    setLoading(true);
    try {
      const result = await callApi("order-esims", { quantity: orderQuantity });
      toast.success(`შეკვეთა წარმატებულია! მიღებულია ${result.fulfilledQuantity}/${result.requestedQuantity} eSIM`);
      if (result.note) toast.info(result.note);
      fetchMyEsims();
      fetchAccountInfo();
    } catch (err: any) {
      toast.error("eSIM შეკვეთა ვერ მოხერხდა: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (tab: string) => {
    setSelectedTab(tab);
    if (tab === "packages" && packages.length === 0) fetchPackages();
    if (tab === "esims" && myEsims.length === 0) fetchMyEsims();
    if (tab === "numbers" && myNumbers.length === 0) fetchMyNumbers();
  };

  // Package flow
  const grouped = useMemo(() => groupByCountry(packages), [packages]);

  const filteredCountries = useMemo(() => {
    const countries = Object.keys(grouped).sort();
    if (!packageSearch.trim()) return countries;
    const q = packageSearch.toLowerCase();
    return countries.filter(c => c.toLowerCase().includes(q));
  }, [grouped, packageSearch]);

  const countryPackages = useMemo(() => {
    if (!selectedCountry || !grouped[selectedCountry]) return [];
    return grouped[selectedCountry];
  }, [grouped, selectedCountry]);

  // Get unique data sizes for the selected country
  const dataSizes = useMemo(() => {
    const sizes = new Set<string>();
    countryPackages.forEach(pkg => {
      const { data } = parsePackageName(pkg);
      if (data) sizes.add(data);
    });
    return Array.from(sizes).sort((a, b) => {
      const numA = parseInt(a);
      const numB = parseInt(b);
      return numA - numB;
    });
  }, [countryPackages]);

  const openCountryDetail = (country: string) => {
    setSelectedCountry(country);
    setSelectedPackage(grouped[country]?.[0] ?? null);
    setPackageView("detail");
  };

  const openPurchaseFlow = () => {
    setPackageView("purchase");
    setPurchaseMode("new");
    setSelectedNumber("");
    setSelectedBalance(5);
    // Load available numbers for purchase
    if (availableNumbers.length === 0) {
      fetchAvailableNumbers();
    }
  };

  const handlePurchase = async () => {
    if (!selectedPackage) return;
    setPurchasing(true);
    try {
      if (purchaseMode === "new") {
        // Order new eSIM first
        const esimResult = await callApi("order-esims", { quantity: 1 });
        if (!esimResult.esims || esimResult.esims.length === 0) {
          throw new Error("eSIM შექმნა ვერ მოხერხდა");
        }
        const newIccid = esimResult.esims[0].iccid;

        // Add package to the new eSIM
        await callApi("esim-add-package", { packageId: selectedPackage.packageId }, newIccid);

        // Add number if selected
        if (selectedNumber) {
          await callApi("esim-add-number", { msisdn: selectedNumber }, newIccid);
        }

        // Add balance
        if (selectedBalance > 0) {
          await callApi("esim-add-balance", { amount: selectedBalance }, newIccid);
        }

        toast.success("eSIM წარმატებით შეიქმნა პაკეტით!");
      } else {
        // Add package to existing eSIM
        if (!selectedEsimForPackage) {
          toast.error("გთხოვთ აირჩიოთ eSIM");
          setPurchasing(false);
          return;
        }
        await callApi("esim-add-package", { packageId: selectedPackage.packageId }, selectedEsimForPackage);
        toast.success("პაკეტი წარმატებით დაემატა!");
      }

      fetchAccountInfo();
      fetchMyEsims();
      setPackageView("list");
    } catch (err: any) {
      toast.error("შეძენა ვერ მოხერხდა: " + err.message);
    } finally {
      setPurchasing(false);
    }
  };

  // Render package cards (list view)
  const renderPackagesList = () => {
    if (packages.length === 0) {
      return (
        <p className="text-center text-muted-foreground py-6">
          {loading ? "იტვირთება..." : "პაკეტები არ მოიძებნა"}
        </p>
      );
    }

    return (
      <div className="space-y-4">
        {/* Header with count + search */}
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm font-medium">
            <Wifi className="h-4 w-4 text-primary" />
            <span>ხელმისაწვდომი პაკეტები</span>
            <Badge variant="secondary" className="text-xs">
              {packages.length}
            </Badge>
          </div>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="ძებნა / Search..."
              value={packageSearch}
              onChange={e => setPackageSearch(e.target.value)}
              className="pl-9 h-9"
            />
          </div>
        </div>

        {/* Country cards grid - GlobalCell style */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredCountries.map(country => {
            const pkgs = grouped[country];
            const flagUrl = getFlagUrl(country);
            // Get cheapest package for price display
            const cheapest = pkgs.reduce((min, p) => p.partnerCost < min.partnerCost ? p : min, pkgs[0]);
            const parsed = parsePackageName(cheapest);

            return (
              <Card
                key={country}
                className="cursor-pointer hover:shadow-lg hover:border-primary/40 transition-all group bg-muted/30"
                onClick={() => openCountryDetail(country)}
              >
                <CardContent className="p-5">
                  {/* Flag - round */}
                  <div className="mb-3 w-12 h-12 rounded-full border-2 border-border shadow-sm overflow-hidden bg-muted flex items-center justify-center text-2xl">
                    {flagUrl ? (
                      <img
                        src={flagUrl}
                        alt={country}
                        className="w-full h-full object-cover"
                        loading="lazy"
                        onError={(e) => {
                          const target = e.currentTarget;
                          target.style.display = 'none';
                          target.parentElement!.textContent = getFlag(country);
                        }}
                      />
                    ) : (
                      getFlag(country)
                    )}
                  </div>

                  {/* Country name */}
                  <h3 className="font-bold text-base text-foreground mb-3 group-hover:text-primary transition-colors">
                    {country}
                  </h3>

                  {/* Price row */}
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-muted-foreground">ფასი</span>
                    <span className="font-semibold text-foreground">{toGel(cheapest.partnerCost)} ₾ / {parsed.data || "1 GB"}</span>
                  </div>

                  {/* Validity row */}
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">ვადა</span>
                    <span className="font-semibold text-foreground">{parsed.validity || "7 - 90 დღე"}</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredCountries.length === 0 && (
          <p className="text-center text-muted-foreground py-4">
            ქვეყანა ვერ მოიძებნა
          </p>
        )}
      </div>
    );
  };

  // Render package detail view (like image-305)
  const renderPackageDetail = () => {
    if (!selectedCountry) return null;

    const pkgs = grouped[selectedCountry] || [];
    const currentParsed = selectedPackage ? parsePackageName(selectedPackage) : null;

    return (
      <div className="space-y-4">
        {/* Back button */}
        <Button variant="ghost" size="sm" className="gap-2" onClick={() => { setPackageView("list"); setSelectedPackage(null); }}>
          <ArrowLeft className="h-4 w-4" /> უკან
        </Button>

        {/* Country header */}
        <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/30 border">
          <span className="text-2xl">{getFlag(selectedCountry)}</span>
          <h2 className="text-lg font-semibold">{selectedCountry}</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Left: Selected package info */}
          <div className="space-y-4">
            <h3 className="font-medium text-sm text-muted-foreground">პაკეტი</h3>

            {selectedPackage && (
              <Card className="border-primary/30 bg-primary/5">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{getFlag(selectedCountry)}</span>
                      <span className="font-semibold">{selectedCountry}</span>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-primary">{toGel(selectedPackage.partnerCost)} ₾</p>
                      <p className="text-xs text-muted-foreground">{toGel(selectedPackage.partnerCost)} ₾ / {currentParsed?.data || "pack"}</p>
                    </div>
                  </div>

                  <div className="space-y-3 mt-4">
                    {currentParsed?.data && (
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-primary/10">
                          <Wifi className="h-4 w-4 text-primary" />
                        </div>
                        <span className="font-medium text-primary">{currentParsed.data}</span>
                      </div>
                    )}
                    {currentParsed?.validity && (
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-accent">
                          <Clock className="h-4 w-4 text-accent-foreground" />
                        </div>
                        <span className="font-medium text-accent-foreground">{currentParsed.validity}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Buy button */}
            <Button className="w-full gap-2 h-11" size="lg" onClick={openPurchaseFlow}>
              <ShoppingCart className="h-4 w-4" />
              შეიძინეთ ახლავე
            </Button>
          </div>

          {/* Right: Data & validity options */}
          <div className="space-y-4">
            {/* Data size selector */}
            <div>
              <h3 className="font-medium text-sm text-muted-foreground mb-2">Data</h3>
              <div className="flex flex-wrap gap-2">
                {dataSizes.map(size => {
                  const matchPkg = pkgs.find(p => parsePackageName(p).data === size);
                  const isSelected = selectedPackage?.packageId === matchPkg?.packageId;

                  return (
                    <button
                      key={size}
                      onClick={() => matchPkg && setSelectedPackage(matchPkg)}
                      className={`px-4 py-3 rounded-lg border text-sm font-medium transition-all ${
                        isSelected
                          ? "bg-primary/10 border-primary text-primary"
                          : "bg-background hover:bg-muted border-border text-foreground"
                      }`}
                    >
                      {size}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Validity */}
            {currentParsed?.validity && (
              <div>
                <h3 className="font-medium text-sm text-muted-foreground mb-2">ვადა</h3>
                <div className="flex flex-wrap gap-2">
                  <div className="px-4 py-3 rounded-lg border bg-primary/10 border-primary text-primary text-sm font-medium">
                    {currentParsed.validity}
                  </div>
                </div>
              </div>
            )}

            {/* All packages for this country */}
            <div>
              <h3 className="font-medium text-sm text-muted-foreground mb-2">ყველა პაკეტი</h3>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {pkgs.map(pkg => {
                  const p = parsePackageName(pkg);
                  const isSelected = selectedPackage?.packageId === pkg.packageId;
                  return (
                    <button
                      key={pkg.packageId}
                      onClick={() => setSelectedPackage(pkg)}
                      className={`w-full text-left p-3 rounded-lg border text-sm transition-all ${
                        isSelected ? "bg-primary/10 border-primary" : "hover:bg-muted"
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span>{p.data} · {p.validity || "-"}</span>
                        <span className="font-bold text-primary">{toGel(pkg.partnerCost)} ₾</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Render purchase flow (like image-306)
  const renderPurchaseFlow = () => {
    if (!selectedPackage) return null;
    const parsed = parsePackageName(selectedPackage);

    return (
      <div className="space-y-4">
        {/* Back */}
        <Button variant="ghost" size="sm" className="gap-2" onClick={() => setPackageView("detail")}>
          <ArrowLeft className="h-4 w-4" /> უკან
        </Button>

        {/* Selected package summary */}
        <Card className="border-primary/20">
          <CardContent className="p-4">
            <h3 className="font-medium text-sm text-muted-foreground mb-2">თქვენი პაკეტი</h3>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-xl">{getFlag(selectedCountry)}</span>
                <div>
                  <p className="font-semibold">{selectedCountry}</p>
                  <p className="text-xs text-muted-foreground">
                    {parsed.data} · {parsed.validity}
                  </p>
                </div>
              </div>
              <p className="font-bold text-lg text-primary">{toGel(selectedPackage.partnerCost)} ₾</p>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left: SIM/eSIM selection (2 cols) */}
          <div className="md:col-span-2 space-y-6">
            {/* Mode tabs */}
            <div className="grid grid-cols-2 gap-0 border rounded-lg overflow-hidden">
              <button
                className={`py-3 text-sm font-medium transition-colors ${
                  purchaseMode === "new"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted/50 text-muted-foreground hover:bg-muted"
                }`}
                onClick={() => setPurchaseMode("new")}
              >
                იყიდეთ ახალი eSIM
              </button>
              <button
                className={`py-3 text-sm font-medium transition-colors ${
                  purchaseMode === "existing"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted/50 text-muted-foreground hover:bg-muted"
                }`}
                onClick={() => setPurchaseMode("existing")}
              >
                არსებული eSIM
              </button>
            </div>

            {purchaseMode === "existing" && (
              <div className="space-y-3">
                <h3 className="font-semibold text-base">აირჩიეთ არსებული eSIM</h3>
                <Input
                  placeholder="eSIM ICCID ჩაწერეთ ან აირჩიეთ..."
                  value={selectedEsimForPackage}
                  onChange={e => setSelectedEsimForPackage(e.target.value)}
                  className="font-mono text-sm"
                />
                {myEsims.length > 0 && (
                  <div className="space-y-1.5 max-h-48 overflow-y-auto">
                    {myEsims.map(esim => (
                      <button
                        key={esim.iccid}
                        onClick={() => setSelectedEsimForPackage(esim.iccid)}
                        className={`w-full text-left p-3 rounded-lg border text-sm transition-all ${
                          selectedEsimForPackage === esim.iccid ? "bg-primary/10 border-primary" : "hover:bg-muted"
                        }`}
                      >
                        <span className="font-mono text-xs">{esim.iccid}</span>
                        <Badge variant={esim.status === "Active" ? "default" : "secondary"} className="ml-2 text-xs">
                          {esim.status === "Active" ? "აქტიური" : esim.status}
                        </Badge>
                      </button>
                    ))}
                  </div>
                )}
                {myEsims.length === 0 && (
                  <p className="text-sm text-muted-foreground">eSIM-ები არ მოიძებნა. ჩაწერეთ ICCID ხელით ან იყიდეთ ახალი.</p>
                )}
              </div>
            )}

            {purchaseMode === "new" && (
              <div className="space-y-6">
                {/* Number selection */}
                <div>
                  <h3 className="font-semibold text-base mb-3">აირჩიეთ ნომერი თქვენი eSIM-ისთვის</h3>
                  <div className="flex items-center gap-2 mb-4">
                    <div className="flex items-center gap-2 border rounded-lg px-3 py-2 bg-muted/30">
                      <img src="https://flagcdn.com/w40/ge.png" alt="GE" className="w-6 h-4 object-cover rounded-sm" />
                      <span className="font-medium text-sm">+995</span>
                      <span className="text-muted-foreground text-sm">559</span>
                    </div>
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="xxxxxxxxx"
                        value={numberSearch}
                        onChange={e => setNumberSearch(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                  </div>

                  {availableNumbers.length === 0 && !loading && (
                    <Button variant="outline" size="sm" className="mb-3" onClick={fetchAvailableNumbers}>
                      <RefreshCw className="h-3.5 w-3.5 mr-2" />
                      ნომრების ჩატვირთვა
                    </Button>
                  )}

                  {loading && availableNumbers.length === 0 && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground py-4">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      ნომრები იტვირთება...
                    </div>
                  )}

                  {/* Balance selection */}
                  <div className="mb-4">
                    <h3 className="font-semibold text-base mb-3">აირჩიეთ ფასი</h3>
                    <div className="flex flex-wrap gap-2">
                      {balanceOptions.map(amount => (
                        <button
                          key={amount}
                          onClick={() => setSelectedBalance(amount)}
                          className={`px-4 py-2 rounded-full border text-sm font-medium transition-all ${
                            selectedBalance === amount
                              ? "bg-primary text-primary-foreground border-primary shadow-sm"
                              : "hover:bg-muted border-border"
                          }`}
                        >
                          {amount} ₾
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Numbers grid */}
                  {availableNumbers.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-base mb-3 uppercase tracking-wide">STANDARD</h4>
                      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 max-h-80 overflow-y-auto pr-1">
                        {availableNumbers
                          .filter(n => !numberSearch || n.msisdn.includes(numberSearch))
                          .map(num => {
                            const displayNum = num.msisdn.startsWith('+') ? num.msisdn : `+${num.msisdn}`;
                            return (
                              <button
                                key={num.msisdn}
                                onClick={() => setSelectedNumber(num.msisdn)}
                                className={`py-4 px-3 rounded-xl border-2 text-center transition-all ${
                                  selectedNumber === num.msisdn
                                    ? "bg-primary/10 border-primary ring-2 ring-primary/20 shadow-md"
                                    : "border-border hover:border-primary/40 hover:shadow-sm"
                                }`}
                              >
                                <div className="flex items-center justify-center gap-2 mb-2">
                                  <img src="https://flagcdn.com/w20/ge.png" alt="GE" className="w-5 h-3.5 rounded-sm shrink-0" />
                                  <span className="font-mono text-sm font-medium">{displayNum}</span>
                                </div>
                                <p className="text-sm text-primary font-semibold">
                                  ფასი ~{selectedBalance} ₾
                                </p>
                              </button>
                            );
                          })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Right: Order summary */}
          <div>
            <Card className="sticky top-4">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">შეკვეთის დეტალები</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">პაკეტი - {selectedCountry}</span>
                    <span>{toGel(selectedPackage.partnerCost)} ₾</span>
                  </div>
                  {purchaseMode === "new" && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">eSIM</span>
                        <span>{accountInfo ? toGel(accountInfo.esimCost) : "0.00"} ₾</span>
                      </div>
                      {selectedNumber && (
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">ნომერი</span>
                          <span className="font-mono text-xs">{selectedNumber}</span>
                        </div>
                      )}
                    </>
                  )}
                  <div className="border-t pt-2 flex justify-between font-bold">
                    <span>ჯამი</span>
                    <span className="text-primary">
                      {toGel(selectedPackage.partnerCost + (purchaseMode === "new" ? (accountInfo?.esimCost || 0) : 0))} ₾
                    </span>
                  </div>
                </div>

                {accountInfo && (
                  <p className="text-xs text-muted-foreground">
                    ბალანსი: {toGel(accountInfo.accountBalance)} ₾
                  </p>
                )}

                <Button
                  className="w-full gap-2"
                  onClick={handlePurchase}
                  disabled={purchasing || (purchaseMode === "existing" && !selectedEsimForPackage)}
                >
                  {purchasing ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />}
                  გაფორმება
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  };

  if (apiConfigured === false) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <GlobalCellLogo className="h-10 w-auto mx-auto mb-4" />
          <p className="text-muted-foreground mb-2">Global Cell API არ არის კონფიგურირებული</p>
          <p className="text-sm text-muted-foreground">გადადით პარამეტრები → ინტეგრაციები → Global Cell სექციაში API გასაღების შესაყვანად</p>
        </CardContent>
      </Card>
    );
  }

  if (apiConfigured === null) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Account Overview */}
      {accountInfo && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <GlobalCellLogo className="h-6 w-auto" />
                <span className="text-base">{accountInfo.accountName}</span>
              </div>
              <Button variant="ghost" size="sm" onClick={fetchAccountInfo} disabled={loading}>
                <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-lg bg-primary/5 border">
                <p className="text-xs text-muted-foreground">ბალანსი</p>
                <p className="text-lg font-bold text-primary">{toGel(accountInfo.accountBalance)} ₾</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50 border">
                <p className="text-xs text-muted-foreground">eSIM ფასი</p>
                <p className="text-lg font-bold">{toGel(accountInfo.esimCost)} ₾</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50 border">
                <p className="text-xs text-muted-foreground">საკომისიო</p>
                <p className="text-lg font-bold">{accountInfo.topUpServiceCommissionPercent}%</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50 border">
                <p className="text-xs text-muted-foreground">ID</p>
                <p className="text-sm font-mono font-bold">{accountInfo.accountId}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tabs */}
      <Tabs value={selectedTab} onValueChange={handleTabChange}>
        <TabsList className="w-full flex-wrap h-auto gap-1">
          <TabsTrigger value="overview" className="gap-1 text-xs">
            <DollarSign className="h-3 w-3" /> მიმოხილვა
          </TabsTrigger>
          <TabsTrigger value="packages" className="gap-1 text-xs">
            <Package className="h-3 w-3" /> პაკეტები
          </TabsTrigger>
          <TabsTrigger value="esims" className="gap-1 text-xs">
            <Smartphone className="h-3 w-3" /> eSIM-ები
          </TabsTrigger>
          <TabsTrigger value="numbers" className="gap-1 text-xs">
            <Phone className="h-3 w-3" /> ნომრები
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Plus className="h-4 w-4" /> eSIM შეკვეთა
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-3">
                <div className="flex-1">
                  <label className="text-sm text-muted-foreground mb-1 block">რაოდენობა</label>
                  <Input
                    type="number"
                    min={1}
                    max={100}
                    value={orderQuantity}
                    onChange={e => setOrderQuantity(parseInt(e.target.value) || 1)}
                    className="h-9"
                  />
                </div>
                <div className="text-sm text-muted-foreground pb-2">
                  ≈ {accountInfo ? toGel(orderQuantity * accountInfo.esimCost) : "..."} ₾
                </div>
                <Button onClick={handleOrderEsims} disabled={loading} className="gap-2">
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />}
                  შეკვეთა
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="packages" className="mt-4">
          {packageView !== "list" && (
            <Card className="mb-4">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">
                  {packageView === "detail" && `${selectedCountry} - პაკეტები`}
                  {packageView === "purchase" && "შეძენა"}
                </CardTitle>
              </CardHeader>
            </Card>
          )}
          {packageView === "list" && (
            <div className="flex items-center justify-end mb-2">
              <Button variant="ghost" size="sm" onClick={fetchPackages} disabled={loading}>
                <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              </Button>
            </div>
          )}
          {packageView === "list" && renderPackagesList()}
          {packageView === "detail" && <Card><CardContent className="pt-6">{renderPackageDetail()}</CardContent></Card>}
          {packageView === "purchase" && <Card><CardContent className="pt-6">{renderPurchaseFlow()}</CardContent></Card>}
        </TabsContent>

        <TabsContent value="esims" className="mt-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center justify-between">
                <span>ჩემი eSIM-ები</span>
                <Button variant="ghost" size="sm" onClick={fetchMyEsims} disabled={loading}>
                  <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {myEsims.length === 0 ? (
                <p className="text-center text-muted-foreground py-6">
                  {loading ? "იტვირთება..." : "eSIM-ები არ მოიძებნა"}
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>eSIM ID</TableHead>
                        <TableHead>ICCID</TableHead>
                        <TableHead>MSISDN</TableHead>
                        <TableHead>სტატუსი</TableHead>
                        <TableHead>მოქმედება</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {myEsims.map(esim => (
                        <TableRow key={esim.iccid}>
                          <TableCell className="font-mono text-xs">{esim.esimId}</TableCell>
                          <TableCell className="font-mono text-xs">{esim.iccid}</TableCell>
                          <TableCell>{esim.msisdn || "-"}</TableCell>
                          <TableCell>
                            <Badge variant={esim.status === "Active" ? "default" : "secondary"}>
                              {esim.status === "Active" ? "აქტიური" : "არააქტიური"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 text-xs gap-1"
                              onClick={async () => {
                                try {
                                  const details = await callApi("esim-details", undefined, esim.iccid);
                                  if (details.qrCode) {
                                    window.open(details.qrCode, "_blank");
                                  }
                                  toast.success("აქტივაციის კოდი: " + (details.activationCode || "N/A"));
                                } catch (err: any) {
                                  toast.error(err.message);
                                }
                              }}
                            >
                              <QrCode className="h-3 w-3" /> QR კოდი
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="numbers" className="mt-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center justify-between">
                <span>ჩემი ნომრები</span>
                <Button variant="ghost" size="sm" onClick={fetchMyNumbers} disabled={loading}>
                  <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {myNumbers.length === 0 ? (
                <p className="text-center text-muted-foreground py-6">
                  {loading ? "იტვირთება..." : "ნომრები არ მოიძებნა"}
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ნომერი</TableHead>
                        <TableHead>სტატუსი</TableHead>
                        <TableHead>ICCID</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {myNumbers.map(num => (
                        <TableRow key={num.msisdn}>
                          <TableCell className="font-mono">{num.msisdn}</TableCell>
                          <TableCell>
                            <Badge variant={num.status === "available" ? "default" : num.status === "affected" ? "secondary" : "destructive"}>
                              {num.status === "available" ? "ხელმისაწვდომი" : num.status === "affected" ? "მინიჭებული" : "ვადაგასული"}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-mono text-xs">{num.iccid || "-"}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default GlobalCellManager;
