import { useState } from "react";
import { useLocation } from "react-router-dom";
import { HelpCircle, X, ChevronRight, Play, BookOpen, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { motion, AnimatePresence } from "framer-motion";

interface HelpItem {
  title: string;
  description: string;
  steps?: string[];
  tips?: string[];
  videoId?: string;
}

const pageHelp: Record<string, { title: string; items: HelpItem[] }> = {
  "/": {
    title: "თანამშრომლის პორტალი",
    items: [
      {
        title: "რა არის პორტალი?",
        description: "თქვენი პირადი სამუშაო სივრცე, სადაც ხედავთ თქვენს მონაცემებს, შვებულებებს და დავალებებს.",
        tips: ["გამოიყენეთ ზედა მენიუ სხვადასხვა სექციაზე გადასასვლელად", "პროფილის სურათზე დაჭერით შეძლებთ პარამეტრების შეცვლას"],
      },
    ],
  },
  "/dashboard": {
    title: "დეშბორდი",
    items: [
      {
        title: "სტატისტიკის ბარათები",
        description: "აქ ნაჩვენებია ძირითადი მეტრიკები - თანამშრომლების რაოდენობა, მომლოდინე მოთხოვნები და აქტიურობა.",
        tips: ["ბარათებზე დაჭერით გადახვალთ შესაბამის გვერდზე", "გრაფიკები ავტომატურად განახლდება"],
      },
      {
        title: "სწრაფი მოქმედებები",
        description: "ხშირად გამოყენებული ფუნქციების სწრაფი წვდომა.",
        steps: ["აირჩიეთ სასურველი მოქმედება", "შეავსეთ საჭირო ველები", "დააჭირეთ შენახვას"],
      },
    ],
  },
  "/employees": {
    title: "თანამშრომლები",
    items: [
      {
        title: "თანამშრომლის დამატება",
        description: "ახალი თანამშრომლის სისტემაში რეგისტრაცია.",
        steps: [
          "დააჭირეთ 'ახალი თანამშრომელი' ღილაკს",
          "შეავსეთ სახელი, ელ-ფოსტა, დეპარტამენტი",
          "აირჩიეთ სამუშაო გრაფიკი",
          "დააჭირეთ 'რეგისტრაცია'",
        ],
        tips: ["თანამშრომელს ავტომატურად ეგზავნება პაროლი", "Excel-იდან მასობრივი იმპორტიც შესაძლებელია"],
      },
      {
        title: "ფილტრაცია და ძიება",
        description: "გამოიყენეთ საძიებო ველი სახელით, დეპარტამენტით ან პოზიციით მოსაძებნად.",
      },
    ],
  },
  "/leave-requests": {
    title: "შვებულებები",
    items: [
      {
        title: "შვებულების მოთხოვნა",
        description: "შვებულების ან მივლინების მოთხოვნის გაკეთება.",
        steps: [
          "აირჩიეთ შვებულების ტიპი",
          "მიუთითეთ დაწყებისა და დასრულების თარიღი",
          "დაამატეთ კომენტარი (სურვილისამებრ)",
          "გაგზავნეთ მოთხოვნა",
        ],
        tips: ["24 კალენდარული დღე წელიწადში ანაზღაურებადია", "მოთხოვნა ავტომატურად მიდის HR-თან"],
      },
    ],
  },
  "/attendance": {
    title: "დასწრება",
    items: [
      {
        title: "შესვლა/გასვლა",
        description: "სამუშაო დროის აღრიცხვა ავტომატურად ან ხელით.",
        tips: ["GPS ლოკაცია ავტომატურად ფიქსირდება", "დაგვიანების მიზეზის მითითება შესაძლებელია"],
      },
    ],
  },
  "/payroll": {
    title: "ხელფასები",
    items: [
      {
        title: "ხელფასის დაანგარიშება",
        description: "ყოველთვიური ხელფასის ავტომატური გამოთვლა.",
        steps: [
          "აირჩიეთ თვე და წელი",
          "დააჭირეთ 'დაანგარიშება'",
          "შეამოწმეთ გამოთვლები",
          "დაამტკიცეთ ან შეცვალეთ",
        ],
        tips: ["საშემოსავლო გადასახადი (20%) ავტომატურად გამოიქვითება", "საპენსიო შენატანი (2%+2%) ავტომატურადაა"],
      },
    ],
  },
  "/documents": {
    title: "დოკუმენტები",
    items: [
      {
        title: "დოკუმენტის ატვირთვა",
        description: "კომპანიის ან თანამშრომლის დოკუმენტის ატვირთვა.",
        tips: ["მაქს. ზომა: 10MB", "მხარდაჭერილი ფორმატები: PDF, DOCX, XLSX, JPG, PNG"],
      },
    ],
  },
  "/tasks": {
    title: "დავალებები",
    items: [
      {
        title: "Kanban დაფა",
        description: "დავალებების ვიზუალური მართვა სვეტებით.",
        steps: [
          "შექმენით ახალი დავალება '+' ღილაკით",
          "გადაათრიეთ ბარათი სასურველ სვეტში",
          "მიამაგრეთ თანამშრომელი და ვადა",
        ],
        tips: ["პრიორიტეტი ფერით განსხვავდება", "ვადაგადასული დავალებები წითლად ჩანს"],
      },
    ],
  },
  "/training": {
    title: "ტრენინგები",
    items: [
      {
        title: "ტრენინგის მართვა",
        description: "თანამშრომლების პროფესიული განვითარების ტრეკინგი.",
      },
    ],
  },
  "/settings": {
    title: "პარამეტრები",
    items: [
      {
        title: "პროფილის მართვა",
        description: "შეცვალეთ თქვენი პირადი ინფორმაცია და პრეფერენციები.",
      },
    ],
  },
  "/client-admin": {
    title: "სერვერის პანელი",
    items: [
      {
        title: "სისტემის მონიტორინგი",
        description: "რეალურ დროში ნახეთ სერვერის მდგომარეობა - CPU, RAM, დისკი.",
        tips: ["მეტრიკები ყოველ 3 წამში განახლდება", "ბაზის სტატისტიკა რეალურ მონაცემებზეა დაფუძნებული"],
      },
    ],
  },
};

// Default help for unknown pages
const defaultHelp: { title: string; items: HelpItem[] } = {
  title: "დახმარება",
  items: [
    {
      title: "საჭიროებთ დახმარებას?",
      description: "გამოიყენეთ Nina AI ჩატბოტი (ქვედა მარჯვენა კუთხე) ნებისმიერი კითხვისთვის, ან დაწერეთ საპორტ ტიკეტი.",
      tips: ["Nina 24/7 პასუხობს თქვენს კითხვებს", "ვიდეო ტუტორიალები ხელმისაწვდომია ტრენინგების სექციაში"],
    },
  ],
};

export default function ContextualHelp() {
  const [isOpen, setIsOpen] = useState(false);
  const [expandedItem, setExpandedItem] = useState<number | null>(null);
  const location = useLocation();

  // Match exact or prefix
  const currentPath = location.pathname;
  const helpData = pageHelp[currentPath] || 
    Object.entries(pageHelp).find(([path]) => currentPath.startsWith(path) && path !== "/")?.[1] ||
    (currentPath === "/" ? pageHelp["/"] : defaultHelp);

  return (
    <>
      {/* Floating ? button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            className="fixed hidden sm:block sm:top-16 right-4 z-40"
          >
            <Button
              onClick={() => setIsOpen(true)}
              size="icon"
              className="h-10 w-10 sm:h-11 sm:w-11 rounded-full bg-primary shadow-lg hover:shadow-xl hover:scale-110 transition-all duration-200"
            >
              <HelpCircle className="h-5 w-5" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Help panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, x: -300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -300 }}
            transition={{ type: "spring", damping: 25 }}
            className="fixed top-28 right-4 z-50 w-80 max-h-[70vh] bg-card border border-border rounded-xl shadow-2xl flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-border bg-primary/5">
              <div className="flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-primary" />
                <h3 className="font-semibold text-sm">{helpData.title}</h3>
              </div>
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setIsOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Content */}
            <ScrollArea className="flex-1 max-h-[50vh]">
              <div className="p-3 space-y-2">
                {helpData.items.map((item, idx) => (
                  <div
                    key={idx}
                    className="border border-border/50 rounded-lg overflow-hidden bg-background/50"
                  >
                    <button
                      onClick={() => setExpandedItem(expandedItem === idx ? null : idx)}
                      className="w-full flex items-center justify-between p-3 text-left hover:bg-muted/50 transition-colors"
                    >
                      <span className="text-sm font-medium">{item.title}</span>
                      <ChevronRight
                        className={`h-4 w-4 text-muted-foreground transition-transform ${expandedItem === idx ? "rotate-90" : ""}`}
                      />
                    </button>
                    <AnimatePresence>
                      {expandedItem === idx && (
                        <motion.div
                          initial={{ height: 0 }}
                          animate={{ height: "auto" }}
                          exit={{ height: 0 }}
                          className="overflow-hidden"
                        >
                          <div className="px-3 pb-3 space-y-2">
                            <p className="text-xs text-muted-foreground">{item.description}</p>
                            
                            {item.steps && (
                              <div className="space-y-1">
                                <p className="text-xs font-medium text-primary">ნაბიჯები:</p>
                                {item.steps.map((step, i) => (
                                  <div key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                                    <Badge variant="outline" className="h-4 w-4 min-w-[16px] flex items-center justify-center text-[10px] p-0 rounded-full">
                                      {i + 1}
                                    </Badge>
                                    <span>{step}</span>
                                  </div>
                                ))}
                              </div>
                            )}

                            {item.tips && (
                              <div className="space-y-1 bg-primary/5 rounded-md p-2">
                                <p className="text-xs font-medium text-primary">რჩევები:</p>
                                {item.tips.map((tip, i) => (
                                  <p key={i} className="text-xs text-muted-foreground">• {tip}</p>
                                ))}
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))}
              </div>
            </ScrollArea>

            {/* Footer */}
            <div className="p-3 border-t border-border bg-muted/30">
              <p className="text-[10px] text-muted-foreground text-center">
                ვერ იპოვეთ პასუხი? ესაუბრეთ <strong>ნინას</strong>
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
