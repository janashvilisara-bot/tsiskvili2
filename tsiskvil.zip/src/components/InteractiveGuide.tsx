import { useState } from "react";
import { 
  Users, Calendar, Clock, DollarSign, BarChart3, Settings, 
  CheckCircle2, AlertCircle, Lightbulb, ChevronRight, PlayCircle
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";

interface Step {
  title: string;
  description: string;
  action?: string;
  screenshot?: string;
  tip?: string;
  warning?: string;
}

interface Guide {
  id: string;
  title: string;
  description: string;
  icon: any;
  color: string;
  steps: Step[];
  estimatedTime: string;
}

export const InteractiveGuide = () => {
  const [activeGuide, setActiveGuide] = useState<string | null>(null);

  const guides: Guide[] = [
    {
      id: "employee-registration",
      title: "თანამშრომლის რეგისტრაცია",
      description: "ახალი თანამშრომლის სისტემაში დამატების პროცესი",
      icon: Users,
      color: "bg-blue-500",
      estimatedTime: "5 წუთი",
      steps: [
        {
          title: "გადადით თანამშრომლების გვერდზე",
          description: "მენიუდან აირჩიეთ 'თანამშრომლები' ან გამოიყენეთ ნავიგაციის ზოლი",
          action: "მენიუ → თანამშრომლები",
          tip: "შეგიძლიათ გამოიყენოთ კლავიატურის shortcut: Ctrl + E"
        },
        {
          title: "დააჭირეთ 'დამატება' ღილაკს",
          description: "გვერდის ზედა მარჯვენა კუთხეში მოძებნეთ ლურჯი 'დამატება' ღილაკი",
          action: "დააჭირეთ '+ დამატება' ღილაკს"
        },
        {
          title: "შეავსეთ პირადი ინფორმაცია",
          description: "შეიყვანეთ თანამშრომლის სახელი, გვარი, პირადი ნომერი და საკონტაქტო ინფორმაცია",
          warning: "პირადი ნომერი უნდა იყოს 11 ციფრი",
          tip: "ყველა ველი ვარსკვლავით (*) არის სავალდებულო"
        },
        {
          title: "აირჩიეთ დეპარტამენტი და პოზიცია",
          description: "dropdown მენიუდან აირჩიეთ შესაბამისი დეპარტამენტი და პოზიცია",
          action: "დეპარტამენტი → პოზიცია"
        },
        {
          title: "მიუთითეთ სამუშაოს დაწყების თარიღი",
          description: "კალენდრიდან აირჩიეთ თარიღი როდესაც თანამშრომელი იწყებს მუშაობას",
          tip: "თარიღი არ უნდა იყოს წარსულში 6 თვეზე მეტი"
        },
        {
          title: "ატვირთეთ დოკუმენტები (არასავალდებულო)",
          description: "შეგიძლიათ ატვირთოთ CV, ხელშეკრულება და სხვა დოკუმენტები",
          tip: "მხარდაჭერილი ფორმატები: PDF, DOC, DOCX, JPG, PNG"
        },
        {
          title: "შეინახეთ მონაცემები",
          description: "გადაამოწმეთ ყველა ველი და დააჭირეთ 'შენახვა' ღილაკს",
          action: "დააჭირეთ 'შენახვა'"
        }
      ]
    },
    {
      id: "work-schedules",
      title: "სამუშაო გრაფიკების შექმნა",
      description: "გრაფიკის შაბლონის შექმნა და თანამშრომლებზე მინიჭება",
      icon: Calendar,
      color: "bg-green-500",
      estimatedTime: "8 წუთი",
      steps: [
        {
          title: "გადადით გრაფიკების გვერდზე",
          description: "მენიუდან აირჩიეთ 'სამუშაო გრაფიკები'",
          action: "მენიუ → სამუშაო გრაფიკები"
        },
        {
          title: "შექმენით გრაფიკის შაბლონი",
          description: "დააჭირეთ 'შაბლონების მართვა' და შემდეგ '+ ახალი შაბლონი'",
          action: "შაბლონების მართვა → + ახალი შაბლონი"
        },
        {
          title: "მიუთითეთ შაბლონის დასახელება",
          description: "მიეცით შაბლონს აღწერითი სახელი, მაგ: 'ოფისის სტანდარტული გრაფიკი'",
          tip: "გამოიყენეთ ცხადი სახელები შემდგომი მოხერხებულობისთვის"
        },
        {
          title: "დააყენეთ სამუშაო საათები თითოეული დღისთვის",
          description: "მიუთითეთ დაწყების და დასრულების დრო კვირის თითოეული დღისთვის",
          warning: "შეამოწმეთ რომ დაწყების დრო უფრო ადრეა ვიდრე დასრულების დრო"
        },
        {
          title: "მონიშნეთ დასვენების დღეები",
          description: "მონიშნეთ checkbox-ები იმ დღეებისთვის რომლებიც არის დასვენების",
          tip: "ჩვეულებრივ შაბათი და კვირა არის დასვენების დღეები"
        },
        {
          title: "შეინახეთ შაბლონი",
          description: "დააჭირეთ 'შენახვა' ღილაკს შაბლონის დასამახსოვრებლად",
          action: "დააჭირეთ 'შენახვა'"
        },
        {
          title: "მიანიჭეთ გრაფიკი თანამშრომლებს",
          description: "აირჩიეთ თანამშრომელი და მიუთითეთ შექმნილი შაბლონი",
          action: "თანამშრომლის არჩევა → შაბლონის არჩევა → მინიჭება"
        }
      ]
    },
    {
      id: "attendance-tracking",
      title: "დასწრების აღრიცხვა",
      description: "ყოველდღიური დასწრების მონიტორინგი და რეგისტრაცია",
      icon: Clock,
      color: "bg-purple-500",
      estimatedTime: "6 წუთი",
      steps: [
        {
          title: "გადადით დასწრების გვერდზე",
          description: "მენიუდან აირჩიეთ 'დასწრება'",
          action: "მენიუ → დასწრება"
        },
        {
          title: "აირჩიეთ თარიღი",
          description: "კალენდრიდან აირჩიეთ თარიღი რომლის დასწრებასაც აღირიცხავთ",
          tip: "შეგიძლიათ დააჭიროთ 'დღეს' ღილაკს მიმდინარე დღის სანახავად"
        },
        {
          title: "დააფიქსირეთ თანამშრომლის მოსვლა",
          description: "მოძებნეთ თანამშრომელი სიიდან და დააჭირეთ 'მოსვლა' ღილაკს",
          action: "თანამშრომელი → მოსვლა",
          warning: "დარწმუნდით რომ სწორ თანამშრომელს ირჩევთ"
        },
        {
          title: "მიუთითეთ მოსვლის დრო",
          description: "თუ საჭიროა, შეცვალეთ ავტომატურად გენერირებული დრო",
          tip: "ავტომატურად ივსება მიმდინარე დროით"
        },
        {
          title: "აღნიშნეთ დაგვიანება (თუ არის)",
          description: "თუ თანამშრომელი დაგვიანებულია, მონიშნეთ 'დაგვიანება' checkbox",
          action: "მონიშნეთ 'დაგვიანება' და მიუთითეთ მიზეზი"
        },
        {
          title: "დააფიქსირეთ წასვლა (დღის ბოლოს)",
          description: "სამუშაო დღის დასრულებისას დააჭირეთ 'წასვლა' ღილაკს",
          action: "თანამშრომელი → წასვლა"
        },
        {
          title: "ნახეთ დასწრების ანგარიში",
          description: "დააჭირეთ 'ანგარიშები' ღილაკს დასწრების სტატისტიკის სანახავად",
          tip: "შეგიძლიათ გაფილტროთ პერიოდით და დეპარტამენტით"
        }
      ]
    },
    {
      id: "payroll-processing",
      title: "ხელფასების დარიცხვა",
      description: "ყოველთვიური ხელფასების გაანგარიშება და დარიცხვა",
      icon: DollarSign,
      color: "bg-orange-500",
      estimatedTime: "12 წუთი",
      steps: [
        {
          title: "გადადით ხელფასების გვერდზე",
          description: "მენიუდან აირჩიეთ 'ხელფასები'",
          action: "მენიუ → ხელფასები"
        },
        {
          title: "აირჩიეთ დარიცხვის თვე",
          description: "dropdown-დან აირჩიეთ თვე რომლის ხელფასებსაც დაარიცხავთ",
          warning: "დარწმუნდით რომ ყველა დასწრება და გრაფიკი აღრიცხულია"
        },
        {
          title: "დააჭირეთ 'ხელფასების გაანგარიშება'",
          description: "სისტემა ავტომატურად გაანგარიშებს ხელფასებს დასწრებისა და გრაფიკების მიხედვით",
          action: "დააჭირეთ 'გაანგარიშება'",
          tip: "პროცესი შეიძლება გასტანოს 1-2 წუთი"
        },
        {
          title: "გადაამოწმეთ გაანგარიშებები",
          description: "შეამოწმეთ თითოეული თანამშრომლის ხელფასი, სამუშაო საათები და გამოქვითვები",
          warning: "ყურადღებით შეამოწმეთ ზეგანაკვეთური და ბონუსები"
        },
        {
          title: "დაამატეთ ბონუსები და კომპენსაციები",
          description: "საჭიროების შემთხვევაში დაამატეთ ინდივიდუალური ბონუსები ან კომპენსაციები",
          action: "თანამშრომელი → დამატება → ბონუსი/კომპენსაცია"
        },
        {
          title: "დაუმტკიცეთ ხელფასები",
          description: "დააჭირეთ 'დამტკიცება' ღილაკს ხელფასების დასადასტურებლად",
          warning: "დამტკიცების შემდეგ ცვლილებები შეზღუდულია"
        },
        {
          title: "გენერირება და ექსპორტი",
          description: "გენერირება შეგიძლიათ Excel ან PDF ფორმატში ხელფასების უწყისი",
          action: "ექსპორტი → Excel/PDF",
          tip: "შეინახეთ ფაილი არქივისთვის"
        }
      ]
    },
    {
      id: "leave-management",
      title: "შვებულებების მართვა",
      description: "შვებულების მოთხოვნების დამუშავება და დამტკიცება",
      icon: Calendar,
      color: "bg-indigo-500",
      estimatedTime: "7 წუთი",
      steps: [
        {
          title: "გადადით შვებულებების გვერდზე",
          description: "მენიუდან აირჩიეთ 'შვებულებები'",
          action: "მენიუ → შვებულებები"
        },
        {
          title: "ნახეთ ახალი მოთხოვნები",
          description: "გამოჩნდება ყველა დაუმტკიცებელი შვებულების მოთხოვნა",
          tip: "გამოიყენეთ ფილტრები სპეციფიკური მოთხოვნების სანახავად"
        },
        {
          title: "გახსენით მოთხოვნის დეტალები",
          description: "დააჭირეთ მოთხოვნას სრული ინფორმაციის სანახავად",
          action: "დააჭირეთ მოთხოვნას"
        },
        {
          title: "შეამოწმეთ შვებულების ბალანსი",
          description: "დარწმუნდით რომ თანამშრომელს აქვს საკმარისი შვებულების დღეები",
          warning: "ბალანსი უნდა იყოს საკმარისი მოთხოვნილი დღეების დასაფარად"
        },
        {
          title: "შეამოწმეთ გრაფიკი",
          description: "დარწმუნდით რომ შვებულება არ ეწინააღმდეგება სამუშაო გრაფიკს",
          tip: "გაითვალისწინეთ დეპარტამენტის დატვირთვა"
        },
        {
          title: "დაამტკიცეთ ან უარყავით",
          description: "დააჭირეთ 'დამტკიცება' ან 'უარყოფა' ღილაკს",
          action: "დამტკიცება/უარყოფა + კომენტარი",
          tip: "უარყოფის შემთხვევაში აუცილებლად მიუთითეთ მიზეზი"
        },
        {
          title: "გაგზავნეთ შეტყობინება",
          description: "თანამშრომელს ავტომატურად გაეგზავნება შეტყობინება გადაწყვეტილების შესახებ",
          tip: "შეტყობინება შეიცავს დამატებით კომენტარებს თუ დაამატეთ"
        }
      ]
    },
    {
      id: "financial-reports",
      title: "ფინანსური ანგარიშები",
      description: "ანგარიშების გენერირება და ექსპორტი",
      icon: BarChart3,
      color: "bg-red-500",
      estimatedTime: "9 წუთი",
      steps: [
        {
          title: "გადადით ფინანსურ ანგარიშებზე",
          description: "მენიუდან აირჩიეთ 'ფინანსური ანგარიშები'",
          action: "მენიუ → ფინანსური ანგარიშები"
        },
        {
          title: "აირჩიეთ პერიოდი",
          description: "მიუთითეთ დაწყებისა და დასრულების თარიღები ანგარიშისთვის",
          tip: "შეგიძლიათ აირჩიოთ სწრაფი ფილტრები: ბოლო თვე, კვარტალი, წელი"
        },
        {
          title: "აირჩიეთ ანგარიშის ტიპი",
          description: "dropdown-დან აირჩიეთ სასურველი ანგარიში",
          action: "ანგარიშის ტიპი: ხელფასები/კომპენსაციები/პენსია/ყველა"
        },
        {
          title: "გამოიყენეთ ფილტრები (არასავალდებულო)",
          description: "შეგიძლიათ გაფილტროთ დეპარტამენტით, პოზიციით ან თანამშრომლით",
          tip: "ფილტრები დაგეხმარებათ უფრო დეტალური ანალიზისთვის"
        },
        {
          title: "ნახეთ წინასწარი ხედი",
          description: "დააჭირეთ 'ნახვა' ღილაკს ანგარიშის preview-სთვის",
          action: "დააჭირეთ 'ნახვა'"
        },
        {
          title: "გადაამოწმეთ მონაცემები",
          description: "შეამოწმეთ ყველა ციფრი და გაანგარიშება სისწორეზე",
          warning: "დარწმუნდით რომ ყველა საჭირო მონაცემი ჩართულია"
        },
        {
          title: "ექსპორტი Excel-ში",
          description: "დააჭირეთ 'Excel-ში ექსპორტი' სრული ანგარიშის ჩამოსატვირთად",
          action: "დააჭირეთ 'Excel-ში ექსპორტი'",
          tip: "Excel ფაილი შეიცავს ყველა ტაბულას და დიაგრამას"
        },
        {
          title: "ან ექსპორტი PDF-ში",
          description: "ხელმოწერისთვის ან პრინტისთვის გამოიყენეთ PDF ფორმატი",
          action: "დააჭირეთ 'PDF-ში ექსპორტი'",
          tip: "PDF შეიცავს კომპანიის ლოგოს და ხელმოწერის ველებს"
        }
      ]
    },
    {
      id: "role-management",
      title: "როლების მართვა",
      description: "თანამშრომლების როლების და უფლებების მართვა",
      icon: Settings,
      color: "bg-purple-500",
      estimatedTime: "5 წუთი",
      steps: [
        {
          title: "გადადით როლების მართვის გვერდზე",
          description: "მენიუდან აირჩიეთ 'როლების მართვა'",
          action: "მენიუ → სისტემა → როლების მართვა"
        },
        {
          title: "მოძებნეთ თანამშრომელი",
          description: "გამოიყენეთ ძიების ველი ან ფილტრები",
          tip: "შეგიძლიათ მოძებნოთ სახელით, ელ.ფოსტით ან როლით"
        },
        {
          title: "მიანიჭეთ სისტემური როლი",
          description: "აირჩიეთ სასურველი სისტემური როლი პირველი dropdown მენიუდან (ადმინისტრატორი, HR მენეჯერი, დეპარტამენტის მენეჯერი)",
          warning: "ყურადღებით მიანიჭეთ ადმინისტრატორის როლი"
        },
        {
          title: "მიანიჭეთ Custom როლი",
          description: "აირჩიეთ Custom როლი მეორე dropdown მენიუდან. Custom როლები იქმნება Custom როლების მართვის გვერდზე.",
          tip: "Custom როლებს აქვთ მოვისფრო ბორდერი და მათი უფლებები განისაზღვრება Custom როლების მართვაში"
        },
        {
          title: "წაშალეთ როლი",
          description: "როლის წასაშლელად დააჭირეთ 'X' ღილაკს როლის badge-ზე",
          warning: "თითოეულ მომხმარებელს უნდა ჰქონდეს მინიმუმ ერთი როლი"
        }
      ]
    },
    {
      id: "custom-roles",
      title: "Custom როლების მართვა",
      description: "მორგებული როლების შექმნა და ფუნქციონალების მართვა",
      icon: Settings,
      color: "bg-pink-500",
      estimatedTime: "6 წუთი",
      steps: [
        {
          title: "გადადით Custom როლების მართვის გვერდზე",
          description: "მენიუდან აირჩიეთ 'Custom როლების მართვა'",
          action: "მენიუ → სისტემა → Custom როლების მართვა"
        },
        {
          title: "შექმენით ახალი Custom როლი",
          description: "დააჭირეთ '+ შექმენი ახალი როლი' ღილაკს",
          tip: "Custom როლები საშუალებას გაძლევთ შექმნათ მორგებული უფლებების ნაკრები"
        },
        {
          title: "დაარქვით სახელი როლს",
          description: "შეიყვანეთ გასაგები და აღწერითი სახელი როლისთვის",
          tip: "გამოიყენეთ მკაფიო სახელი, მაგ: 'საბუღალტრო მენეჯერი', 'HR ასისტენტი'"
        },
        {
          title: "აღწერეთ როლი (არასავალდებულო)",
          description: "დაამატეთ დეტალური აღწერა იმის შესახებ, თუ როგორ უნდა იქნას გამოყენებული ეს როლი",
          tip: "ეს დაგეხმარებათ სხვა ადმინისტრატორებს გაიგონ როლის დანიშნულება"
        },
        {
          title: "აირჩიეთ ფუნქციონალები",
          description: "მონიშნეთ ის ფუნქციონალები, რომელთა წვდომაც უნდა ჰქონდეს ამ როლის მქონე მომხმარებლებს",
          warning: "ყურადღებით მიანიჭეთ ფინანსურ და ადმინისტრაციულ ფუნქციონალებზე წვდომა"
        },
        {
          title: "გამოიყენეთ კატეგორიების ჩვენება/დამალვა",
          description: "დააჭირეთ კატეგორიის სახელს რომ ნახოთ ან დამალოთ მისი ქვე-ელემენტები",
          tip: "შეგიძლიათ სწრაფად მონიშნოთ/მოხსნათ მთელი კატეგორია checkbox-ის გამოყენებით"
        },
        {
          title: "შეინახეთ როლი",
          description: "დააჭირეთ 'შექმნა' ღილაკს როლის შესანახად",
          action: "როლი ხელმისაწვდომი იქნება როლების მართვის გვერდზე"
        },
        {
          title: "დაარედაქტირეთ ან წაშალეთ როლი",
          description: "გამოიყენეთ შესაბამისი ღილაკები როლების სიაში",
          warning: "როლის წაშლა წაშლის ყველა მომხმარებლის მინიჭებას ამ როლისთვის"
        }
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {guides.map((guide) => {
          const Icon = guide.icon;
          const isActive = activeGuide === guide.id;
          
          return (
            <Card 
              key={guide.id}
              className={`cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 ${
                isActive ? 'ring-2 ring-primary shadow-lg' : ''
              }`}
              onClick={() => setActiveGuide(isActive ? null : guide.id)}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className={`w-12 h-12 rounded-lg ${guide.color} flex items-center justify-center text-white animate-scale-in`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    <Clock className="h-3 w-3 mr-1" />
                    {guide.estimatedTime}
                  </Badge>
                </div>
                <CardTitle className="flex items-center gap-2 mt-4">
                  {guide.title}
                  {isActive && <ChevronRight className="h-5 w-5 text-primary rotate-90 transition-transform" />}
                </CardTitle>
                <CardDescription>{guide.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  variant={isActive ? "default" : "outline"} 
                  className="w-full gap-2"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveGuide(isActive ? null : guide.id);
                  }}
                >
                  <PlayCircle className="h-4 w-4" />
                  {isActive ? 'გაიდის დახურვა' : 'გაიდის გახსნა'}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {activeGuide && (
        <Card className="animate-fade-in border-primary/20">
          <CardHeader className="bg-gradient-to-r from-primary/5 to-accent/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {(() => {
                  const guide = guides.find(g => g.id === activeGuide);
                  if (!guide) return null;
                  const Icon = guide.icon;
                  return (
                    <>
                      <div className={`w-12 h-12 rounded-lg ${guide.color} flex items-center justify-center text-white`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <div>
                        <CardTitle className="text-2xl">{guide.title}</CardTitle>
                        <CardDescription className="text-base mt-1">
                          ნაბიჯ-ნაბიჯ ინსტრუქცია • {guide.steps.length} ნაბიჯი
                        </CardDescription>
                      </div>
                    </>
                  );
                })()}
              </div>
              <Button 
                variant="ghost" 
                onClick={() => setActiveGuide(null)}
              >
                დახურვა
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <Accordion type="single" collapsible className="w-full space-y-2">
              {guides.find(g => g.id === activeGuide)?.steps.map((step, index) => (
                <AccordionItem 
                  key={index} 
                  value={`step-${index}`}
                  className="border rounded-lg px-4 hover:border-primary/30 transition-colors"
                >
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-center gap-3 text-left">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold text-sm">
                        {index + 1}
                      </div>
                      <span className="font-medium">{step.title}</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 pb-2 space-y-4">
                    <p className="text-muted-foreground leading-relaxed">
                      {step.description}
                    </p>
                    
                    {step.action && (
                      <Alert className="border-primary/20 bg-primary/5">
                        <CheckCircle2 className="h-4 w-4 text-primary" />
                        <AlertDescription className="ml-2">
                          <strong>მოქმედება:</strong> {step.action}
                        </AlertDescription>
                      </Alert>
                    )}
                    
                    {step.tip && (
                      <Alert className="border-blue-500/20 bg-blue-500/5">
                        <Lightbulb className="h-4 w-4 text-blue-500" />
                        <AlertDescription className="ml-2">
                          <strong>რჩევა:</strong> {step.tip}
                        </AlertDescription>
                      </Alert>
                    )}
                    
                    {step.warning && (
                      <Alert className="border-orange-500/20 bg-orange-500/5">
                        <AlertCircle className="h-4 w-4 text-orange-500" />
                        <AlertDescription className="ml-2">
                          <strong>გაფრთხილება:</strong> {step.warning}
                        </AlertDescription>
                      </Alert>
                    )}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>

            <div className="mt-6 p-4 bg-gradient-to-r from-green-500/5 to-blue-500/5 rounded-lg border border-green-500/10">
              <div className="flex items-center gap-2 text-green-600 dark:text-green-400 mb-2">
                <CheckCircle2 className="h-5 w-5" />
                <span className="font-semibold">გილოცავთ!</span>
              </div>
              <p className="text-sm text-muted-foreground">
                თუ გაიარეთ ყველა ნაბიჯი, წარმატებით დაეუფლეთ ამ ფუნქციონალს. 
                საჭიროების შემთხვევაში ნებისმიერ დროს შეგიძლიათ დაუბრუნდეთ ამ გაიდს.
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
