import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { formatters } from "@/lib/dateUtils";
import { Plus, FolderKanban, Calendar, Users, Trash2 } from "lucide-react";

interface Project {
  id: string;
  name: string;
  description: string | null;
  status: string;
  color: string;
  department_id: string | null;
  start_date: string | null;
  end_date: string | null;
  created_at: string;
  departments?: { name: string } | null;
  task_count?: number;
  completed_count?: number;
}

interface ProjectsManagerProps {
  onProjectSelect?: (projectId: string | null) => void;
  selectedProjectId?: string | null;
  departments: any[];
}

const projectColors = [
  "#3b82f6", "#8b5cf6", "#ec4899", "#f59e0b", "#10b981", "#06b6d4", "#ef4444", "#6366f1"
];

export default function ProjectsManager({ onProjectSelect, selectedProjectId, departments }: ProjectsManagerProps) {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedColor, setSelectedColor] = useState(projectColors[0]);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    const { data: projectsData } = await supabase
      .from("projects")
      .select("*, departments(name)")
      .order("created_at", { ascending: false });

    if (projectsData) {
      // Get task counts for each project
      const withCounts = await Promise.all(
        projectsData.map(async (p) => {
          const { count: taskCount } = await supabase
            .from("tasks")
            .select("*", { count: "exact", head: true })
            .eq("project_id", p.id)
            .is("parent_task_id", null);

          const { count: completedCount } = await supabase
            .from("tasks")
            .select("*", { count: "exact", head: true })
            .eq("project_id", p.id)
            .eq("status", "completed")
            .is("parent_task_id", null);

          return { ...p, task_count: taskCount || 0, completed_count: completedCount || 0 };
        })
      );
      setProjects(withCounts);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const { error } = await supabase.from("projects").insert({
        name: formData.get("name") as string,
        description: (formData.get("description") as string) || null,
        color: selectedColor,
        department_id: (formData.get("department_id") as string) || null,
        start_date: (formData.get("start_date") as string) || null,
        end_date: (formData.get("end_date") as string) || null,
        created_by: user?.id,
      });

      if (error) throw error;
      toast.success("პროექტი შეიქმნა");
      setIsDialogOpen(false);
      fetchProjects();
    } catch (error: any) {
      toast.error("პროექტის შექმნა ვერ მოხერხდა");
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("წავშალოთ პროექტი?")) return;
    const { error } = await supabase.from("projects").delete().eq("id", id);
    if (error) {
      toast.error("წაშლა ვერ მოხერხდა");
    } else {
      toast.success("პროექტი წაიშალა");
      if (selectedProjectId === id) onProjectSelect?.(null);
      fetchProjects();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold flex items-center gap-2">
          <FolderKanban className="h-4 w-4" />
          პროექტები
        </h3>
        <Button size="sm" variant="outline" onClick={() => setIsDialogOpen(true)}>
          <Plus className="h-3 w-3 mr-1" />
          ახალი
        </Button>
      </div>

      {/* All tasks button */}
      <Card
        className={`cursor-pointer transition-all hover:shadow-sm ${
          !selectedProjectId ? "ring-2 ring-primary" : ""
        }`}
        onClick={() => onProjectSelect?.(null)}
      >
        <CardContent className="p-3">
          <p className="font-medium text-sm">ყველა დავალება</p>
        </CardContent>
      </Card>

      {/* Project list */}
      <div className="space-y-2">
        {projects.map((project) => {
          const progress = project.task_count! > 0
            ? Math.round((project.completed_count! / project.task_count!) * 100)
            : 0;

          return (
            <Card
              key={project.id}
              className={`cursor-pointer transition-all hover:shadow-sm ${
                selectedProjectId === project.id ? "ring-2 ring-primary" : ""
              }`}
              onClick={() => onProjectSelect?.(project.id)}
            >
              <CardContent className="p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full shrink-0"
                    style={{ backgroundColor: project.color }}
                  />
                  <p className="font-medium text-sm flex-1 truncate">{project.name}</p>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100"
                    onClick={(e) => { e.stopPropagation(); handleDelete(project.id); }}
                  >
                    <Trash2 className="h-3 w-3 text-muted-foreground" />
                  </Button>
                </div>

                {project.task_count! > 0 && (
                  <div className="space-y-1">
                    <Progress value={progress} className="h-1.5" />
                    <div className="flex justify-between text-[10px] text-muted-foreground">
                      <span>{project.completed_count}/{project.task_count} დავალება</span>
                      <span>{progress}%</span>
                    </div>
                  </div>
                )}

                {project.departments?.name && (
                  <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    {project.departments.name}
                  </p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Create Project Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ახალი პროექტი</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>სახელი *</Label>
              <Input name="name" required placeholder="პროექტის სახელი" />
            </div>
            <div className="space-y-2">
              <Label>აღწერა</Label>
              <Textarea name="description" rows={2} placeholder="რას ეხება პროექტი" />
            </div>
            <div className="space-y-2">
              <Label>ფერი</Label>
              <div className="flex gap-2">
                {projectColors.map((c) => (
                  <button
                    key={c}
                    type="button"
                    className={`w-7 h-7 rounded-full border-2 transition-all ${
                      selectedColor === c ? "border-foreground scale-110" : "border-transparent"
                    }`}
                    style={{ backgroundColor: c }}
                    onClick={() => setSelectedColor(c)}
                  />
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>დეპარტამენტი</Label>
                <Select name="department_id">
                  <SelectTrigger>
                    <SelectValue placeholder="აირჩიეთ" />
                  </SelectTrigger>
                  <SelectContent>
                    {departments.map((d) => (
                      <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>დაწყება</Label>
                <Input name="start_date" type="date" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>დასრულება</Label>
              <Input name="end_date" type="date" />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>გაუქმება</Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? "იქმნება..." : "შექმნა"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
