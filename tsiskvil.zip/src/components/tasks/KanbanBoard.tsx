import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Calendar, GripVertical, AlertCircle } from "lucide-react";
import { formatters } from "@/lib/dateUtils";

interface KanbanTask {
  id: string;
  title: string;
  description: string | null;
  priority: string;
  status: string;
  due_date: string | null;
  assigned_to: string | null;
  project_id: string | null;
  employees?: { full_name: string } | null;
  progress?: number;
}

interface KanbanBoardProps {
  tasks: KanbanTask[];
  onStatusChange: (taskId: string, newStatus: string) => void;
  onTaskClick: (task: KanbanTask) => void;
}

const columns = [
  { id: "submitted", title: "📋 შესასრულებელი", color: "border-t-blue-500" },
  { id: "in_progress", title: "🔄 მიმდინარე", color: "border-t-amber-500" },
  { id: "completed", title: "✅ დასრულებული", color: "border-t-emerald-500" },
];

const priorityColors: Record<string, string> = {
  low: "bg-muted text-muted-foreground",
  medium: "bg-blue-500/10 text-blue-600",
  high: "bg-orange-500/10 text-orange-600",
  urgent: "bg-destructive/10 text-destructive",
};

const priorityLabels: Record<string, string> = {
  low: "დაბალი",
  medium: "საშუალო",
  high: "მაღალი",
  urgent: "გადაუდებელი",
};

export default function KanbanBoard({ tasks, onStatusChange, onTaskClick }: KanbanBoardProps) {
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null);

  const getColumnTasks = (columnId: string) => {
    // Map approved tasks to submitted column for kanban view
    return tasks.filter((t) => {
      if (columnId === "submitted") return t.status === "submitted" || t.status === "approved" || t.status === "pending";
      if (columnId === "in_progress") return t.status === "in_progress";
      if (columnId === "completed") return t.status === "completed";
      return false;
    });
  };

  const handleDragStart = (e: React.DragEvent, taskId: string) => {
    setDraggedTaskId(taskId);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent, columnId: string) => {
    e.preventDefault();
    setDragOverColumn(columnId);
  };

  const handleDragLeave = () => {
    setDragOverColumn(null);
  };

  const handleDrop = (e: React.DragEvent, columnId: string) => {
    e.preventDefault();
    setDragOverColumn(null);
    if (draggedTaskId) {
      const statusMap: Record<string, string> = {
        submitted: "submitted",
        in_progress: "in_progress",
        completed: "completed",
      };
      onStatusChange(draggedTaskId, statusMap[columnId]);
      setDraggedTaskId(null);
    }
  };

  const isOverdue = (dueDate: string | null) => {
    if (!dueDate) return false;
    return new Date(dueDate) < new Date();
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 min-h-[500px]">
      {columns.map((column) => {
        const columnTasks = getColumnTasks(column.id);
        return (
          <div
            key={column.id}
            className={`rounded-xl border-t-4 ${column.color} bg-muted/30 p-3 transition-colors ${
              dragOverColumn === column.id ? "bg-primary/5 ring-2 ring-primary/20" : ""
            }`}
            onDragOver={(e) => handleDragOver(e, column.id)}
            onDragLeave={handleDragLeave}
            onDrop={(e) => handleDrop(e, column.id)}
          >
            <div className="flex items-center justify-between mb-3 px-1">
              <h3 className="font-semibold text-sm">{column.title}</h3>
              <Badge variant="secondary" className="text-xs">
                {columnTasks.length}
              </Badge>
            </div>

            <div className="space-y-2">
              {columnTasks.map((task) => (
                <Card
                  key={task.id}
                  draggable
                  onDragStart={(e) => handleDragStart(e, task.id)}
                  onClick={() => onTaskClick(task)}
                  className={`cursor-grab active:cursor-grabbing hover:shadow-md transition-all ${
                    draggedTaskId === task.id ? "opacity-50" : ""
                  }`}
                >
                  <CardContent className="p-3 space-y-2">
                    <div className="flex items-start gap-2">
                      <GripVertical className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0 opacity-50" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm leading-tight truncate">{task.title}</p>
                        {task.description && (
                          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                            {task.description}
                          </p>
                        )}
                      </div>
                    </div>

                    {task.progress !== undefined && task.progress > 0 && (
                      <div className="w-full bg-muted rounded-full h-1.5">
                        <div
                          className="bg-primary h-1.5 rounded-full transition-all"
                          style={{ width: `${task.progress}%` }}
                        />
                      </div>
                    )}

                    <div className="flex items-center justify-between gap-2">
                      <Badge className={`${priorityColors[task.priority] || priorityColors.medium} text-[10px] px-1.5 py-0`}>
                        {priorityLabels[task.priority] || task.priority}
                      </Badge>

                      <div className="flex items-center gap-2">
                        {task.due_date && (
                          <span className={`flex items-center gap-1 text-[10px] ${
                            isOverdue(task.due_date) && column.id !== "completed"
                              ? "text-destructive font-medium"
                              : "text-muted-foreground"
                          }`}>
                            {isOverdue(task.due_date) && column.id !== "completed" && (
                              <AlertCircle className="h-3 w-3" />
                            )}
                            <Calendar className="h-3 w-3" />
                            {formatters.shortDate(task.due_date)}
                          </span>
                        )}

                        {task.employees?.full_name && (
                          <Avatar className="h-5 w-5">
                            <AvatarFallback className="text-[8px] bg-primary/10 text-primary">
                              {task.employees.full_name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {columnTasks.length === 0 && (
                <div className="text-center py-8 text-muted-foreground text-xs">
                  ცარიელია
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
