import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { formatters } from "@/lib/dateUtils";
import {
  CheckCircle, XCircle, Send, Plus, MessageSquare, Calendar,
  User, Building2, Clock, ListTodo
} from "lucide-react";

interface SubTask {
  id: string;
  title: string;
  status: string;
  priority: string;
  due_date: string | null;
  assigned_to: string | null;
  employees?: { full_name: string } | null;
}

interface Comment {
  id: string;
  comment: string;
  user_id: string;
  created_at: string;
  user_email?: string;
  employee_name?: string;
}

interface TaskDetailEnhancedProps {
  task: any;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStatusChange: (taskId: string, status: string) => void;
  isAssignee: boolean;
  canManage: boolean;
  employees: any[];
  statusOptions: any[];
  priorityOptions: any[];
  taskTypes: any[];
}

export default function TaskDetailEnhanced({
  task, open, onOpenChange, onStatusChange,
  isAssignee, canManage, employees, statusOptions, priorityOptions, taskTypes
}: TaskDetailEnhancedProps) {
  const { user } = useAuth();
  const [subtasks, setSubtasks] = useState<SubTask[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState("");
  const [newSubtask, setNewSubtask] = useState("");
  const [showAddSubtask, setShowAddSubtask] = useState(false);
  const [sendingComment, setSendingComment] = useState(false);

  useEffect(() => {
    if (task && open) {
      fetchSubtasks();
      fetchComments();
    }
  }, [task?.id, open]);

  const fetchSubtasks = async () => {
    if (!task) return;
    const { data } = await supabase
      .from("tasks")
      .select("id, title, status, priority, due_date, assigned_to")
      .eq("parent_task_id", task.id)
      .order("created_at");

    if (data) {
      const withEmployees = await Promise.all(
        data.map(async (st) => {
          if (st.assigned_to) {
            const { data: emp } = await supabase
              .from("employees").select("full_name").eq("id", st.assigned_to).single();
            return { ...st, employees: emp };
          }
          return { ...st, employees: null };
        })
      );
      setSubtasks(withEmployees);
    }
  };

  const fetchComments = async () => {
    if (!task) return;
    const { data } = await supabase
      .from("task_comments")
      .select("*")
      .eq("task_id", task.id)
      .order("created_at", { ascending: true });

    if (data) {
      const withNames = await Promise.all(
        data.map(async (c) => {
          const { data: emp } = await supabase
            .from("employees").select("full_name").eq("user_id", c.user_id).maybeSingle();
          return { ...c, employee_name: emp?.full_name || "უცნობი" };
        })
      );
      setComments(withNames);
    }
  };

  const handleAddSubtask = async () => {
    if (!newSubtask.trim() || !task) return;
    const { data: currentEmployee } = await supabase
      .from("employees").select("id").eq("user_id", user?.id).single();

    const { error } = await supabase.from("tasks").insert({
      title: newSubtask.trim(),
      task_type: "other",
      status: "submitted",
      priority: task.priority || "medium",
      parent_task_id: task.id,
      project_id: task.project_id,
      assigned_to: task.assigned_to,
      assigned_by: currentEmployee?.id,
    });

    if (error) {
      toast.error("ქვე-დავალების დამატება ვერ მოხერხდა");
    } else {
      setNewSubtask("");
      setShowAddSubtask(false);
      fetchSubtasks();
      toast.success("ქვე-დავალება დაემატა");
    }
  };

  const handleToggleSubtask = async (subtask: SubTask) => {
    const newStatus = subtask.status === "completed" ? "submitted" : "completed";
    await supabase.from("tasks").update({
      status: newStatus,
      completed_at: newStatus === "completed" ? new Date().toISOString() : null,
      updated_at: new Date().toISOString(),
    }).eq("id", subtask.id);
    fetchSubtasks();
    updateParentProgress();
  };

  const updateParentProgress = async () => {
    if (!task) return;
    const { data: allSubs } = await supabase
      .from("tasks").select("status").eq("parent_task_id", task.id);
    if (allSubs && allSubs.length > 0) {
      const completed = allSubs.filter(s => s.status === "completed").length;
      const progress = Math.round((completed / allSubs.length) * 100);
      await supabase.from("tasks").update({ progress, updated_at: new Date().toISOString() }).eq("id", task.id);
    }
  };

  const handleAddComment = async () => {
    if (!newComment.trim() || !task || !user) return;
    setSendingComment(true);
    const { error } = await supabase.from("task_comments").insert({
      task_id: task.id,
      user_id: user.id,
      comment: newComment.trim(),
    });
    if (error) {
      toast.error("კომენტარის დამატება ვერ მოხერხდა");
    } else {
      setNewComment("");
      fetchComments();
    }
    setSendingComment(false);
  };

  if (!task) return null;

  const status = statusOptions.find((s: any) => s.value === task.status);
  const priority = priorityOptions.find((p: any) => p.value === task.priority);
  const taskType = taskTypes.find((t: any) => t.value === task.task_type);
  const completedSubtasks = subtasks.filter(s => s.status === "completed").length;
  const subtaskProgress = subtasks.length > 0 ? Math.round((completedSubtasks / subtasks.length) * 100) : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">{task.title}</DialogTitle>
          <div className="flex items-center gap-2 mt-2">
            {status && (
              <Badge className={`${status.color} flex items-center gap-1`}>
                <status.icon className="h-3 w-3" />
                {isAssignee && task.status === "submitted" ? "მიღებული" : status.label}
              </Badge>
            )}
            {priority && <Badge className={priority.color}>{priority.label}</Badge>}
          </div>
        </DialogHeader>

        <div className="space-y-5">
          {/* Description */}
          {task.description && (
            <div className="p-3 rounded-lg bg-muted/50">
              <p className="text-xs font-medium text-muted-foreground mb-1">აღწერა</p>
              <p className="text-sm whitespace-pre-wrap">{task.description}</p>
            </div>
          )}

          {/* Meta info */}
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-muted-foreground text-xs">პასუხისმგებელი</p>
                <p className="font-medium">{task.employees?.full_name || "-"}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-muted-foreground text-xs">დეპარტამენტი</p>
                <p className="font-medium">{task.departments?.name || "-"}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-muted-foreground text-xs">ვადა</p>
                <p className="font-medium">{task.due_date ? formatters.shortDate(task.due_date) : "-"}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-muted-foreground text-xs">ტიპი</p>
                <p className="font-medium">{taskType?.label || "-"}</p>
              </div>
            </div>
          </div>

          {/* Subtasks */}
          <Separator />
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <ListTodo className="h-4 w-4 text-muted-foreground" />
                <h4 className="font-semibold text-sm">ქვე-დავალებები</h4>
                {subtasks.length > 0 && (
                  <span className="text-xs text-muted-foreground">
                    {completedSubtasks}/{subtasks.length}
                  </span>
                )}
              </div>
              {(canManage || isAssignee) && (
                <Button size="sm" variant="ghost" onClick={() => setShowAddSubtask(!showAddSubtask)}>
                  <Plus className="h-3 w-3 mr-1" />
                  დამატება
                </Button>
              )}
            </div>

            {subtasks.length > 0 && (
              <Progress value={subtaskProgress} className="h-2 mb-3" />
            )}

            {showAddSubtask && (
              <div className="flex gap-2 mb-3">
                <Input
                  value={newSubtask}
                  onChange={(e) => setNewSubtask(e.target.value)}
                  placeholder="ქვე-დავალების სახელი..."
                  onKeyDown={(e) => e.key === "Enter" && handleAddSubtask()}
                  className="h-8 text-sm"
                />
                <Button size="sm" onClick={handleAddSubtask} className="h-8">
                  <Plus className="h-3 w-3" />
                </Button>
              </div>
            )}

            <div className="space-y-1">
              {subtasks.map((st) => (
                <div
                  key={st.id}
                  className="flex items-center gap-2 p-2 rounded-md hover:bg-muted/50 group"
                >
                  <Checkbox
                    checked={st.status === "completed"}
                    onCheckedChange={() => handleToggleSubtask(st)}
                    disabled={!canManage && !isAssignee}
                  />
                  <span className={`flex-1 text-sm ${st.status === "completed" ? "line-through text-muted-foreground" : ""}`}>
                    {st.title}
                  </span>
                  {st.employees?.full_name && (
                    <Avatar className="h-5 w-5">
                      <AvatarFallback className="text-[8px]">
                        {st.employees.full_name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
              {subtasks.length === 0 && !showAddSubtask && (
                <p className="text-xs text-muted-foreground text-center py-2">ქვე-დავალებები არ არის</p>
              )}
            </div>
          </div>

          {/* Comments */}
          <Separator />
          <div>
            <div className="flex items-center gap-2 mb-3">
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
              <h4 className="font-semibold text-sm">კომენტარები</h4>
              <span className="text-xs text-muted-foreground">({comments.length})</span>
            </div>

            <div className="space-y-3 max-h-48 overflow-y-auto mb-3">
              {comments.map((c) => (
                <div key={c.id} className="flex gap-2">
                  <Avatar className="h-7 w-7 mt-0.5">
                    <AvatarFallback className="text-[9px] bg-primary/10 text-primary">
                      {(c.employee_name || "?").split(" ").map(n => n[0]).join("").slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium">{c.employee_name}</span>
                      <span className="text-[10px] text-muted-foreground">
                        {formatters.shortDate(c.created_at)}
                      </span>
                    </div>
                    <p className="text-sm text-foreground/90 mt-0.5">{c.comment}</p>
                  </div>
                </div>
              ))}
              {comments.length === 0 && (
                <p className="text-xs text-muted-foreground text-center py-2">კომენტარები არ არის</p>
              )}
            </div>

            <div className="flex gap-2">
              <Textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="დაწერეთ კომენტარი..."
                rows={2}
                className="text-sm"
              />
              <Button
                size="sm"
                onClick={handleAddComment}
                disabled={!newComment.trim() || sendingComment}
                className="self-end"
              >
                <Send className="h-3 w-3" />
              </Button>
            </div>
          </div>

          {/* Notes */}
          {task.notes && (
            <>
              <Separator />
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs font-medium text-muted-foreground mb-1">შენიშვნები</p>
                <p className="text-sm whitespace-pre-wrap">{task.notes}</p>
              </div>
            </>
          )}

          {/* Action buttons */}
          {task.status === "submitted" && isAssignee && (
            <div className="flex gap-2 pt-2 border-t">
              <Button
                className="flex-1"
                onClick={() => { onStatusChange(task.id, "completed"); onOpenChange(false); }}
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                შესრულებულია
              </Button>
              <Button
                variant="destructive"
                className="flex-1"
                onClick={() => { onStatusChange(task.id, "rejected"); onOpenChange(false); }}
              >
                <XCircle className="h-4 w-4 mr-2" />
                უარყოფა
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
