import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, ExternalLink } from "lucide-react";

interface Advertisement {
  id: string;
  title: string;
  description: string | null;
  image_url: string | null;
  link_url: string | null;
  ad_type: string;
}

const POPUP_COOLDOWN_KEY = "ad_popup_last_shown";
const COOLDOWN_HOURS = 24; // Show popup max once per 24 hours

export const AdPopup = () => {
  const [isOpen, setIsOpen] = useState(false);

  const { data: ad } = useQuery({
    queryKey: ["advertisement", "popup"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("advertisements")
        .select("*")
        .eq("placement", "popup")
        .eq("is_active", true)
        .order("priority", { ascending: false })
        .limit(1)
        .single();
      
      if (error && error.code !== "PGRST116") throw error;
      return data as Advertisement | null;
    },
  });

  // Track view
  const viewMutation = useMutation({
    mutationFn: async (adId: string) => {
      const { error } = await supabase
        .from("advertisements")
        .update({ view_count: 1 }) // This will be handled properly with RPC
        .eq("id", adId);
    },
  });

  // Track click
  const clickMutation = useMutation({
    mutationFn: async (adId: string) => {
      const { error } = await supabase
        .from("advertisements")
        .update({ click_count: 1 }) // This will be handled properly with RPC
        .eq("id", adId);
    },
  });

  useEffect(() => {
    if (ad) {
      const lastShown = localStorage.getItem(POPUP_COOLDOWN_KEY);
      const now = Date.now();
      
      if (!lastShown || now - parseInt(lastShown) > COOLDOWN_HOURS * 60 * 60 * 1000) {
        // Wait a bit before showing popup
        const timer = setTimeout(() => {
          setIsOpen(true);
          localStorage.setItem(POPUP_COOLDOWN_KEY, now.toString());
          viewMutation.mutate(ad.id);
        }, 3000);
        
        return () => clearTimeout(timer);
      }
    }
  }, [ad]);

  const handleClick = () => {
    if (ad) {
      clickMutation.mutate(ad.id);
      if (ad.link_url) {
        window.open(ad.link_url, "_blank", "noopener,noreferrer");
      }
    }
    setIsOpen(false);
  };

  if (!ad) return null;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden">
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 z-10"
          onClick={() => setIsOpen(false)}
        >
          <X className="h-4 w-4" />
        </Button>

        <div 
          className="cursor-pointer group"
          onClick={handleClick}
        >
          {ad.image_url && (
            <div className="relative">
              <img 
                src={ad.image_url} 
                alt={ad.title}
                className="w-full h-48 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            </div>
          )}
          
          <div className="p-6">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-xl font-bold">{ad.title}</h3>
              {ad.ad_type === "external" && (
                <span className="text-xs px-2 py-0.5 rounded bg-muted text-muted-foreground">
                  Sponsored
                </span>
              )}
            </div>
            
            {ad.description && (
              <p className="text-muted-foreground mb-4">{ad.description}</p>
            )}
            
            {ad.link_url && (
              <Button className="w-full gap-2 group-hover:gap-3 transition-all">
                გაიგე მეტი
                <ExternalLink className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AdPopup;
