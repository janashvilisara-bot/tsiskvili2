import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { X, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
interface Advertisement {
  id: string;
  title: string;
  description: string | null;
  image_url: string | null;
  link_url: string | null;
  ad_type: string;
  placement: string;
  view_count: number;
  click_count: number;
}
interface AdBannerProps {
  placement: "dashboard" | "sidebar" | "popup" | "custom";
  className?: string;
  showCloseButton?: boolean;
  onClose?: () => void;
}
export const AdBanner = ({
  placement,
  className,
  showCloseButton = false,
  onClose
}: AdBannerProps) => {
  const [dismissed, setDismissed] = useState(false);
  const {
    data: ad
  } = useQuery({
    queryKey: ["advertisement", placement],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("advertisements").select("*").eq("placement", placement).eq("is_active", true).order("priority", {
        ascending: false
      }).limit(1).single();
      if (error && error.code !== "PGRST116") throw error;
      return data as Advertisement | null;
    },
    staleTime: 60000
  });

  // Track view
  const viewMutation = useMutation({
    mutationFn: async (adId: string) => {
      const currentAd = ad;
      if (currentAd) {
        await supabase.from("advertisements").update({
          view_count: currentAd.view_count + 1
        }).eq("id", adId);
      }
    }
  });

  // Track click
  const clickMutation = useMutation({
    mutationFn: async (adId: string) => {
      const currentAd = ad;
      if (currentAd) {
        await supabase.from("advertisements").update({
          click_count: currentAd.click_count + 1
        }).eq("id", adId);
      }
    }
  });
  useEffect(() => {
    if (ad) {
      viewMutation.mutate(ad.id);
    }
  }, [ad?.id]);
  const handleClick = () => {
    if (ad) {
      clickMutation.mutate(ad.id);
      if (ad.link_url) {
        window.open(ad.link_url, "_blank", "noopener,noreferrer");
      }
    }
  };
  const handleDismiss = () => {
    setDismissed(true);
    onClose?.();
  };
  if (!ad || dismissed) return null;
  return <div className={cn("relative group cursor-pointer rounded-lg overflow-hidden transition-all duration-300 hover:shadow-lg", "bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10", "border border-primary/20", className)} onClick={handleClick}>
      {showCloseButton && <Button variant="ghost" size="icon" className="absolute top-2 right-2 z-10 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity" onClick={e => {
      e.stopPropagation();
      handleDismiss();
    }}>
          <X className="h-4 w-4" />
        </Button>}

      <div className="flex items-center gap-4 p-4">
        {ad.image_url && <img src={ad.image_url} alt={ad.title} className="w-20 h-auto max-h-24 sm:w-28 sm:max-h-28 rounded-lg object-contain flex-shrink-0" />}
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-sm sm:text-base truncate">{ad.title}</h3>
            {ad.ad_type === "external" && <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                Ad
              </span>}
          </div>
          {ad.description && <p className="text-xs sm:text-sm line-clamp-2 mt-1 text-primary-foreground">
              {ad.description}
            </p>}
        </div>

        {ad.link_url && <ExternalLink className="h-4 w-4 text-muted-foreground flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" />}
      </div>
    </div>;
};
export default AdBanner;