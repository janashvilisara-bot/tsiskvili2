import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ExternalLink, Megaphone } from "lucide-react";
import { cn } from "@/lib/utils";

interface Advertisement {
  id: string;
  title: string;
  description: string | null;
  image_url: string | null;
  link_url: string | null;
  ad_type: string;
}

interface SidebarAdProps {
  className?: string;
}

export const SidebarAd = ({ className }: SidebarAdProps) => {
  const { data: ad } = useQuery({
    queryKey: ["advertisement", "sidebar"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("advertisements")
        .select("*")
        .eq("placement", "sidebar")
        .eq("is_active", true)
        .order("priority", { ascending: false })
        .limit(1)
        .single();
      
      if (error && error.code !== "PGRST116") throw error;
      return data as Advertisement | null;
    },
    staleTime: 60000,
  });

  // Track click
  const clickMutation = useMutation({
    mutationFn: async (adId: string) => {
      await supabase
        .from("advertisements")
        .update({ click_count: 1 })
        .eq("id", adId);
    },
  });

  const handleClick = () => {
    if (ad) {
      clickMutation.mutate(ad.id);
      if (ad.link_url) {
        window.open(ad.link_url, "_blank", "noopener,noreferrer");
      }
    }
  };

  if (!ad) return null;

  return (
    <div 
      className={cn(
        "p-3 rounded-lg cursor-pointer transition-all duration-200",
        "bg-sidebar-accent/50 hover:bg-sidebar-accent",
        "border border-sidebar-border/50",
        "group",
        className
      )}
      onClick={handleClick}
    >
      <div className="flex items-center gap-2 mb-2">
        <Megaphone className="h-3.5 w-3.5 text-sidebar-foreground/70" />
        {ad.ad_type === "external" && (
          <span className="text-[9px] px-1 py-0.5 rounded bg-sidebar-accent text-sidebar-foreground/60">
            Ad
          </span>
        )}
      </div>
      
      {ad.image_url && (
        <img 
          src={ad.image_url} 
          alt={ad.title}
          className="w-full h-20 object-cover rounded mb-2"
        />
      )}
      
      <h4 className="text-xs font-medium text-sidebar-foreground line-clamp-2 group-hover:text-sidebar-primary transition-colors">
        {ad.title}
      </h4>
      
      {ad.description && (
        <p className="text-[10px] text-sidebar-foreground/60 line-clamp-2 mt-1">
          {ad.description}
        </p>
      )}
      
      {ad.link_url && (
        <div className="flex items-center gap-1 mt-2 text-[10px] text-sidebar-primary opacity-0 group-hover:opacity-100 transition-opacity">
          <span>გაიგე მეტი</span>
          <ExternalLink className="h-2.5 w-2.5" />
        </div>
      )}
    </div>
  );
};

export default SidebarAd;
