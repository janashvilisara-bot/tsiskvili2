import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Clock, Save, Loader2, CalendarClock } from "lucide-react";

interface BackupSchedule {
  id: string;
  is_enabled: boolean;
  frequency: string;
  selected_tables: string[];
  send_email: boolean;
  last_backup_at: string | null;
  next_backup_at: string | null;
}

interface Props {
  selectedTables: string[];
}

export default function BackupScheduleConfig({ selectedTables }: Props) {
  const [schedule, setSchedule] = useState<BackupSchedule | null>(null);
  const [isEnabled, setIsEnabled] = useState(false);
  const [frequency, setFrequency] = useState("weekly");
  const [sendEmail, setSendEmail] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadSchedule();
  }, []);

  const loadSchedule = async () => {
    try {
      const { data, error } = await supabase
        .from("backup_schedules")
        .select("*")
        .limit(1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setSchedule(data as BackupSchedule);
        setIsEnabled(data.is_enabled);
        setFrequency(data.frequency);
        setSendEmail(data.send_email);
      }
    } catch (err: any) {
      console.error("Error loading schedule:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const calculateNextBackup = (freq: string): string => {
    const now = new Date();
    switch (freq) {
      case "daily":
        now.setDate(now.getDate() + 1);
        now.setHours(3, 0, 0, 0);
        break;
      case "weekly":
        now.setDate(now.getDate() + 7);
        now.setHours(3, 0, 0, 0);
        break;
      case "monthly":
        now.setMonth(now.getMonth() + 1);
        now.setDate(1);
        now.setHours(3, 0, 0, 0);
        break;
    }
    return now.toISOString();
  };

  const handleSave = async () => {
    if (isEnabled && selectedTables.length === 0) {
      toast.error("აირჩიეთ მინიმუმ ერთი ცხრილი ავტომატური ბექაფისთვის");
      return;
    }

    setIsSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const payload = {
        is_enabled: isEnabled,
        frequency,
        selected_tables: selectedTables,
        send_email: sendEmail,
        next_backup_at: isEnabled ? calculateNextBackup(frequency) : null,
        updated_at: new Date().toISOString(),
      };

      if (schedule) {
        const { error } = await supabase
          .from("backup_schedules")
          .update(payload)
          .eq("id", schedule.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("backup_schedules")
          .insert({ ...payload, created_by: user?.id });
        if (error) throw error;
      }

      toast.success("ბექაფის გრაფიკი შეინახა!");
      await loadSchedule();
    } catch (err: any) {
      console.error("Save error:", err);
      toast.error("შენახვა ვერ მოხერხდა: " + err.message);
    } finally {
      setIsSaving(false);
    }
  };

  const frequencyLabel: Record<string, string> = {
    daily: "ყოველდღე",
    weekly: "ყოველ კვირას",
    monthly: "ყოველთვიურად",
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return "-";
    return new Date(dateStr).toLocaleString("ka-GE", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 flex justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <CalendarClock className="h-5 w-5" />
          ავტომატური ბექაფი
        </CardTitle>
        <CardDescription>
          დააყენეთ ავტომატური ბექაფის გრაფიკი - სისტემა თავად შეინახავს ბექაფს Storage-ში
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* Enable/Disable */}
        <div className="flex items-center justify-between">
          <div>
            <p className="font-medium text-sm">ავტომატური ბექაფი</p>
            <p className="text-xs text-muted-foreground">ჩართეთ რეგულარული ბექაფის შექმნა</p>
          </div>
          <Switch checked={isEnabled} onCheckedChange={setIsEnabled} />
        </div>

        {isEnabled && (
          <>
            {/* Frequency */}
            <div className="space-y-2">
              <label className="text-sm font-medium">სიხშირე</label>
              <Select value={frequency} onValueChange={setFrequency}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">ყოველდღე (03:00)</SelectItem>
                  <SelectItem value="weekly">ყოველ კვირას (ორშაბათი, 03:00)</SelectItem>
                  <SelectItem value="monthly">ყოველთვე (1 რიცხვი, 03:00)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Email notification */}
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-sm">შეტყობინება</p>
                <p className="text-xs text-muted-foreground">ადმინებს ეცნობათ ბექაფის შედეგი</p>
              </div>
              <Switch checked={sendEmail} onCheckedChange={setSendEmail} />
            </div>

            {/* Selected tables count */}
            <div className="bg-muted/50 rounded-lg p-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">არჩეული ცხრილები:</span>
                <Badge variant={selectedTables.length > 0 ? "default" : "destructive"}>
                  {selectedTables.length}
                </Badge>
              </div>
              {selectedTables.length === 0 && (
                <p className="text-xs text-destructive mt-1">
                  ⬆️ აირჩიეთ ცხრილები ექსპორტის სექციაში
                </p>
              )}
            </div>
          </>
        )}

        {/* Status info */}
        {schedule && (
          <div className="bg-muted/50 rounded-lg p-3 space-y-1.5 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">სტატუსი:</span>
              <Badge variant={schedule.is_enabled ? "default" : "secondary"}>
                {schedule.is_enabled ? "აქტიური" : "გამორთული"}
              </Badge>
            </div>
            {schedule.is_enabled && (
              <>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">სიხშირე:</span>
                  <span>{frequencyLabel[schedule.frequency] || schedule.frequency}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ბოლო ბექაფი:</span>
                  <span>{formatDate(schedule.last_backup_at)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">შემდეგი ბექაფი:</span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {formatDate(schedule.next_backup_at)}
                  </span>
                </div>
              </>
            )}
          </div>
        )}

        <Button
          onClick={handleSave}
          disabled={isSaving}
          className="w-full gap-2"
        >
          {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          {isSaving ? "ინახება..." : "შენახვა"}
        </Button>
      </CardContent>
    </Card>
  );
}
