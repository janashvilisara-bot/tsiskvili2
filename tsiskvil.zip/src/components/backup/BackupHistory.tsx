import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { History, Download, Loader2, CheckCircle, XCircle, Clock } from "lucide-react";
import { toast } from "sonner";

interface BackupRecord {
  id: string;
  backup_type: string;
  status: string;
  file_path: string | null;
  file_size_bytes: number | null;
  tables_included: string[];
  total_rows: number;
  error_message: string | null;
  created_at: string;
}

export default function BackupHistory() {
  const [history, setHistory] = useState<BackupRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      const { data, error } = await supabase
        .from("backup_history")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20);

      if (error) throw error;
      setHistory((data || []) as BackupRecord[]);
    } catch (err: any) {
      console.error("Error loading history:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownload = async (filePath: string) => {
    try {
      const { data, error } = await supabase.storage
        .from("database-backups")
        .download(filePath);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement("a");
      a.href = url;
      a.download = filePath.split("/").pop() || "backup.json";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success("ბექაფი ჩამოიტვირთა!");
    } catch (err: any) {
      toast.error("ჩამოტვირთვა ვერ მოხერხდა: " + err.message);
    }
  };

  const formatSize = (bytes: number | null) => {
    if (!bytes) return "-";
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleString("ka-GE", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive"; icon: any }> = {
    completed: { label: "წარმატებული", variant: "default", icon: CheckCircle },
    failed: { label: "ვერ მოხერხდა", variant: "destructive", icon: XCircle },
    in_progress: { label: "მიმდინარეობს", variant: "secondary", icon: Clock },
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 flex justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <History className="h-5 w-5" />
          ბექაფის ისტორია
        </CardTitle>
        <CardDescription>ბოლო 20 ბექაფი</CardDescription>
      </CardHeader>
      <CardContent>
        {history.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            ბექაფის ისტორია ცარიელია
          </p>
        ) : (
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {history.map((record) => {
              const config = statusConfig[record.status] || statusConfig.completed;
              const StatusIcon = config.icon;
              return (
                <div
                  key={record.id}
                  className="flex items-center justify-between py-2 px-3 rounded-lg bg-muted/50 text-sm"
                >
                  <div className="flex items-center gap-3">
                    <StatusIcon className={`h-4 w-4 ${record.status === 'completed' ? 'text-green-500' : record.status === 'failed' ? 'text-destructive' : 'text-muted-foreground'}`} />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{formatDate(record.created_at)}</span>
                        <Badge variant="outline" className="text-xs">
                          {record.backup_type === "scheduled" ? "ავტომატური" : "ხელით"}
                        </Badge>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {record.tables_included.length} ცხრილი · {record.total_rows} ჩანაწერი · {formatSize(record.file_size_bytes)}
                      </span>
                    </div>
                  </div>
                  {record.file_path && record.status === "completed" && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDownload(record.file_path!)}
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
