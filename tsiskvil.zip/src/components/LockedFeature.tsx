import { Lock, ArrowUpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface LockedFeatureProps {
  featureName: string;
  packageName?: string;
}

export function LockedFeature({ featureName, packageName = "Professional" }: LockedFeatureProps) {
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <Card className="max-w-md w-full border-dashed">
        <CardContent className="flex flex-col items-center py-12 text-center">
          <div className="p-4 rounded-full bg-muted mb-4">
            <Lock className="h-8 w-8 text-muted-foreground" />
          </div>
          <h2 className="text-xl font-semibold mb-2">
            {featureName}
          </h2>
          <p className="text-muted-foreground mb-6">
            ეს ფუნქცია ხელმისაწვდომია <strong>{packageName}</strong> პაკეტში.
            დაუკავშირდით ადმინისტრატორს პაკეტის განახლებისთვის.
          </p>
          <Button variant="outline" className="gap-2">
            <ArrowUpCircle className="h-4 w-4" />
            პაკეტის განახლება
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
