import { ReactNode } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Card, CardContent } from "@/components/ui/card";
import { Table } from "@/components/ui/table";

interface ResponsiveTableProps {
  children: ReactNode;
  mobileCards?: (item: any, index: number) => ReactNode;
  data?: any[];
  className?: string;
}

export function ResponsiveTable({ 
  children, 
  mobileCards, 
  data = [], 
  className = "" 
}: ResponsiveTableProps) {
  const isMobile = useIsMobile();

  if (isMobile && mobileCards && data.length > 0) {
    return (
      <div className="space-y-3">
        {data.map((item, index) => mobileCards(item, index))}
      </div>
    );
  }

  return (
    <div className="overflow-x-auto -mx-4 sm:mx-0">
      <div className="inline-block min-w-full align-middle">
        <Table className={className}>{children}</Table>
      </div>
    </div>
  );
}

interface MobileCardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}

export function MobileCard({ children, className = "", onClick }: MobileCardProps) {
  return (
    <Card className={`touch-manipulation ${className} ${onClick ? 'cursor-pointer hover:shadow-md transition-shadow' : ''}`} onClick={onClick}>
      <CardContent className="p-4 space-y-3">
        {children}
      </CardContent>
    </Card>
  );
}

interface MobileCardRowProps {
  label: string;
  value: ReactNode;
}

export function MobileCardRow({ label, value }: MobileCardRowProps) {
  return (
    <div className="flex items-center justify-between gap-3 min-h-[32px]">
      <span className="text-sm font-medium text-muted-foreground shrink-0">
        {label}:
      </span>
      <div className="text-sm text-right truncate">{value}</div>
    </div>
  );
}
