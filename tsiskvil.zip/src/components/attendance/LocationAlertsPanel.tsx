import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { MapPin, AlertTriangle, CheckCircle, XCircle, Clock, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { formatDistance } from "@/lib/geofencing";
import { format } from "date-fns";
import { ka } from "date-fns/locale";

interface LocationAlert {
  id: string;
  attendance_id: string;
  employee_id: string;
  expected_location: string | null;
  actual_location: string | null;
  distance_meters: number | null;
  status: string;
  review_notes: string | null;
  created_at: string;
  employees: {
    first_name: string;
    last_name: string;
    position: string | null;
    departments: { name: string } | null;
  } | null;
}

export default function LocationAlertsPanel() {
  const [alerts, setAlerts] = useState<LocationAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAlert, setSelectedAlert] = useState<LocationAlert | null>(null);
  const [reviewNotes, setReviewNotes] = useState("");
  const [showDialog, setShowDialog] = useState(false);

  useEffect(() => {
    fetchAlerts();
    
    // Subscribe to realtime updates
    const channel = supabase
      .channel('location_alerts_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'location_alerts',
        },
        () => {
          fetchAlerts();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchAlerts = async () => {
    try {
      const { data, error } = await supabase
        .from("location_alerts")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) throw error;
      
      // Fetch employee details separately
      const alertsWithEmployees = await Promise.all(
        (data || []).map(async (alert) => {
          const { data: emp } = await supabase
            .from("employees")
            .select("first_name, last_name, position, department_id")
            .eq("id", alert.employee_id)
            .single();
          return { ...alert, employees: emp };
        })
      );
      
      setAlerts(alertsWithEmployees as any);
    } catch (error: any) {
      console.error("Error fetching location alerts:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleReview = async (status: 'approved' | 'flagged') => {
    if (!selectedAlert) return;

    try {
      const { error } = await supabase
        .from("location_alerts")
        .update({
          status,
          review_notes: reviewNotes.trim() || null,
          reviewed_at: new Date().toISOString(),
          reviewed_by: (await supabase.auth.getUser()).data.user?.id,
        })
        .eq("id", selectedAlert.id);

      if (error) throw error;

      toast.success(status === 'approved' ? "დამტკიცებულია" : "მონიშნულია როგორც საეჭვო");
      setShowDialog(false);
      setSelectedAlert(null);
      setReviewNotes("");
      fetchAlerts();
    } catch (error: any) {
      toast.error(error.message || "შეცდომა მოხდა");
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-500/10 text-yellow-600 border-yellow-500/30">მოლოდინში</Badge>;
      case 'approved':
        return <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/30">დამტკიცებული</Badge>;
      case 'flagged':
        return <Badge variant="destructive">საეჭვო</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const pendingCount = alerts.filter(a => a.status === 'pending').length;

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            ლოკაციის გაფრთხილებები
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">იტვირთება...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            ლოკაციის გაფრთხილებები
            {pendingCount > 0 && (
              <Badge variant="destructive" className="ml-2">{pendingCount} ახალი</Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {alerts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle className="h-12 w-12 mx-auto mb-2 text-green-500" />
              <p>საეჭვო ლოკაციები არ არის</p>
            </div>
          ) : (
            <div className="space-y-3">
              {alerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`p-4 rounded-lg border ${
                    alert.status === 'pending' 
                      ? 'bg-yellow-500/5 border-yellow-500/30' 
                      : alert.status === 'flagged'
                      ? 'bg-destructive/5 border-destructive/30'
                      : 'bg-muted/50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">
                          {alert.employees?.first_name} {alert.employees?.last_name}
                        </span>
                        {getStatusBadge(alert.status)}
                      </div>
                      
                      <div className="text-sm text-muted-foreground space-y-1">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {format(new Date(alert.created_at), "d MMMM, HH:mm", { locale: ka })}
                        </div>
                        
                        {alert.expected_location && (
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            მოსალოდნელი: {alert.expected_location}
                          </div>
                        )}
                        
                        {alert.distance_meters && (
                          <div className="flex items-center gap-1 text-destructive">
                            <AlertTriangle className="h-3 w-3" />
                            დაშორება: {formatDistance(alert.distance_meters)}
                          </div>
                        )}

                        {alert.review_notes && (
                          <div className="mt-2 p-2 bg-muted rounded text-foreground">
                            შენიშვნა: {alert.review_notes}
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {alert.status === 'pending' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedAlert(alert);
                          setShowDialog(true);
                        }}
                      >
                        განხილვა
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ლოკაციის განხილვა</DialogTitle>
          </DialogHeader>
          
          {selectedAlert && (
            <div className="space-y-4">
              <div className="p-3 bg-muted rounded-lg">
                <p className="font-medium">
                  {selectedAlert.employees?.first_name} {selectedAlert.employees?.last_name}
                </p>
                <p className="text-sm text-muted-foreground">
                  {selectedAlert.employees?.position}
                </p>
                {selectedAlert.distance_meters && (
                  <p className="text-sm text-destructive mt-2">
                    ოფისიდან {formatDistance(selectedAlert.distance_meters)} მოშორებით
                  </p>
                )}
              </div>

              <Textarea
                placeholder="დაამატეთ შენიშვნა (არასავალდებულო)"
                value={reviewNotes}
                onChange={(e) => setReviewNotes(e.target.value)}
                rows={3}
              />
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => handleReview('approved')}
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              დასაშვებია
            </Button>
            <Button
              variant="destructive"
              onClick={() => handleReview('flagged')}
            >
              <XCircle className="h-4 w-4 mr-2" />
              საეჭვოა
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
