import { useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  LineChart, Line, Legend, PieChart, Pie, Cell,
} from "recharts";
import { format, eachDayOfInterval, parseISO } from "date-fns";
import { ka } from "date-fns/locale";

interface Record {
  id: string;
  employee_id: string;
  date: string;
  check_in: string | null;
  check_out: string | null;
  scheduled_start?: string;
  scheduled_end?: string;
  department?: string | null;
  employee_name: string;
}

interface Props {
  records: Record[];
  totalEmployees: number;
  startDate: string;
  endDate: string;
}

const COLORS = ["hsl(var(--primary))", "hsl(var(--destructive))", "hsl(var(--muted-foreground))"];

const toMin = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};

const AttendanceAnalyticsCharts = ({ records, totalEmployees, startDate, endDate }: Props) => {
  const data = useMemo(() => {
    // ---- 1. Overall attendance %
    const presentDays = records.filter(r => r.check_in).length;
    const lateDays = records.filter(r => r.check_in && r.scheduled_start && r.check_in.substring(0,5) > r.scheduled_start).length;
    const onTime = presentDays - lateDays;

    // determine date range
    let from: Date | null = null;
    let to: Date | null = null;
    try {
      if (startDate) from = parseISO(startDate);
      if (endDate) to = parseISO(endDate);
      if (!from || !to) {
        const dates = records.map(r => r.date).sort();
        if (dates.length) {
          from = from || parseISO(dates[0]);
          to = to || parseISO(dates[dates.length - 1]);
        }
      }
    } catch {}

    let workingDays = 0;
    let dayList: Date[] = [];
    if (from && to && from <= to) {
      dayList = eachDayOfInterval({ start: from, end: to });
      workingDays = dayList.filter(d => d.getDay() !== 0 && d.getDay() !== 6).length;
    }

    const expectedAttendance = workingDays * (totalEmployees || 0);
    const attendancePct = expectedAttendance > 0
      ? Math.min(100, Math.round((presentDays / expectedAttendance) * 100))
      : 0;
    const absences = Math.max(0, expectedAttendance - presentDays);

    // ---- 2. Daily trend
    const dayMap = new Map<string, { present: number; late: number }>();
    dayList.forEach(d => {
      const key = format(d, "yyyy-MM-dd");
      dayMap.set(key, { present: 0, late: 0 });
    });
    records.forEach(r => {
      if (!r.check_in) return;
      const entry = dayMap.get(r.date) || { present: 0, late: 0 };
      entry.present += 1;
      if (r.scheduled_start && r.check_in.substring(0,5) > r.scheduled_start) entry.late += 1;
      dayMap.set(r.date, entry);
    });
    const trend = Array.from(dayMap.entries())
      .sort(([a],[b]) => a.localeCompare(b))
      .map(([date, v]) => {
        const expected = totalEmployees || 0;
        return {
          date: format(parseISO(date), "dd MMM", { locale: ka }),
          present: v.present,
          absent: Math.max(0, expected - v.present),
          late: v.late,
        };
      });

    // ---- 3. Department comparison
    const deptMap = new Map<string, { present: number; late: number; total: number }>();
    records.forEach(r => {
      const dept = r.department || "სხვა";
      const entry = deptMap.get(dept) || { present: 0, late: 0, total: 0 };
      entry.total += 1;
      if (r.check_in) entry.present += 1;
      if (r.check_in && r.scheduled_start && r.check_in.substring(0,5) > r.scheduled_start) entry.late += 1;
      deptMap.set(dept, entry);
    });
    const departments = Array.from(deptMap.entries()).map(([name, v]) => ({
      name,
      attendance: v.total > 0 ? Math.round((v.present / v.total) * 100) : 0,
      lateRate: v.total > 0 ? Math.round((v.late / v.total) * 100) : 0,
    }));

    // ---- 4. Most frequent lateness by employee
    const empLateMap = new Map<string, { name: string; count: number; totalMin: number }>();
    records.forEach(r => {
      if (!r.check_in || !r.scheduled_start) return;
      const ci = r.check_in.substring(0,5);
      if (ci <= r.scheduled_start) return;
      const diff = toMin(ci) - toMin(r.scheduled_start);
      const entry = empLateMap.get(r.employee_id) || { name: r.employee_name, count: 0, totalMin: 0 };
      entry.count += 1;
      entry.totalMin += diff;
      empLateMap.set(r.employee_id, entry);
    });
    const topLate = Array.from(empLateMap.values())
      .sort((a,b) => b.count - a.count)
      .slice(0, 10)
      .map(e => ({ name: e.name, count: e.count, avg: Math.round(e.totalMin / e.count) }));

    // ---- 5. Lateness by hour-of-day distribution
    const hourBuckets = new Map<string, number>();
    records.forEach(r => {
      if (!r.check_in || !r.scheduled_start) return;
      const ci = r.check_in.substring(0,5);
      if (ci <= r.scheduled_start) return;
      const hour = ci.substring(0,2) + ":00";
      hourBuckets.set(hour, (hourBuckets.get(hour) || 0) + 1);
    });
    const lateByHour = Array.from(hourBuckets.entries())
      .sort(([a],[b]) => a.localeCompare(b))
      .map(([hour, count]) => ({ hour, count }));

    return {
      attendancePct, presentDays, lateDays, onTime, absences,
      expectedAttendance, trend, departments, topLate, lateByHour,
      pieData: [
        { name: "დროულად", value: onTime },
        { name: "დაგვიანებით", value: lateDays },
        { name: "გაცდენა", value: absences },
      ],
    };
  }, [records, totalEmployees, startDate, endDate]);

  return (
    <div className="space-y-4">
      {/* KPI Row */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">დასწრების %</CardTitle></CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{data.attendancePct}%</div>
            <p className="text-xs text-muted-foreground">მოსალოდნელი: {data.expectedAttendance}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">დროზე მოსვლა</CardTitle></CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{data.onTime}</div>
            <p className="text-xs text-muted-foreground">ჩანაწერი</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">დაგვიანებები</CardTitle></CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-600">{data.lateDays}</div>
            <p className="text-xs text-muted-foreground">ჩანაწერი</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">გაცდენები</CardTitle></CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-destructive">{data.absences}</div>
            <p className="text-xs text-muted-foreground">დღე</p>
          </CardContent>
        </Card>
      </div>

      {/* Trend */}
      <Card>
        <CardHeader>
          <CardTitle>გაცდენების და დაგვიანებების ტენდენცია</CardTitle>
          <CardDescription>დღიური დინამიკა არჩეულ პერიოდში</CardDescription>
        </CardHeader>
        <CardContent>
          {data.trend.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">მონაცემები არ მოიძებნა</p>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={data.trend}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }} />
                <Legend />
                <Line type="monotone" dataKey="present" name="დასწრება" stroke="hsl(var(--primary))" strokeWidth={2} />
                <Line type="monotone" dataKey="absent" name="გაცდენა" stroke="hsl(var(--destructive))" strokeWidth={2} />
                <Line type="monotone" dataKey="late" name="დაგვიანება" stroke="#f59e0b" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Departments */}
        <Card>
          <CardHeader>
            <CardTitle>დეპარტამენტების შედარება</CardTitle>
            <CardDescription>დასწრების და დაგვიანების მაჩვენებლები</CardDescription>
          </CardHeader>
          <CardContent>
            {data.departments.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">მონაცემები არ მოიძებნა</p>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={data.departments}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                  <YAxis unit="%" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }} />
                  <Legend />
                  <Bar dataKey="attendance" name="დასწრება %" fill="hsl(var(--primary))" radius={[4,4,0,0]} />
                  <Bar dataKey="lateRate" name="დაგვიანება %" fill="#f59e0b" radius={[4,4,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Pie */}
        <Card>
          <CardHeader>
            <CardTitle>დასწრების სტრუქტურა</CardTitle>
            <CardDescription>დროულად / დაგვიანებით / გაცდენა</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={data.pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                  {data.pieData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Top late employees */}
        <Card>
          <CardHeader>
            <CardTitle>ყველაზე ხშირი დაგვიანებები</CardTitle>
            <CardDescription>ტოპ 10 თანამშრომელი</CardDescription>
          </CardHeader>
          <CardContent>
            {data.topLate.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">დაგვიანებები არ მოიძებნა</p>
            ) : (
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={data.topLate} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis type="category" dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} width={120} />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}
                    formatter={(v: any, name: string) => name === "avg" ? [`${v} წთ`, "საშ. დაგვიანება"] : [v, "შემთხვევა"]} />
                  <Bar dataKey="count" name="დაგვიანებები" fill="#f59e0b" radius={[0,4,4,0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Lateness by hour */}
        <Card>
          <CardHeader>
            <CardTitle>დაგვიანების დროის განაწილება</CardTitle>
            <CardDescription>რომელ საათში ხდება ყველაზე ხშირი დაგვიანებები</CardDescription>
          </CardHeader>
          <CardContent>
            {data.lateByHour.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">მონაცემები არ მოიძებნა</p>
            ) : (
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={data.lateByHour}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="hour" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }} />
                  <Bar dataKey="count" name="დაგვიანებები" fill="hsl(var(--primary))" radius={[4,4,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AttendanceAnalyticsCharts;
