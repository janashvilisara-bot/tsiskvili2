import { Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLanguage } from "@/contexts/LanguageContext";

export function LanguageSelector() {
  const { language, setLanguage } = useLanguage();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Globe className="h-5 w-5" />
          <span className="sr-only">ენის არჩევა</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        align="end" 
        className="z-[100] bg-background/95 backdrop-blur-sm border shadow-lg"
      >
        <DropdownMenuItem
          onClick={() => setLanguage('ka')}
          className={`cursor-pointer ${
            language === 'ka' ? 'bg-accent font-medium' : ''
          }`}
        >
          <span className="flex items-center gap-2">
            <span className="text-lg">🇬🇪</span>
            <span>ქართული</span>
          </span>
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setLanguage('en')}
          className={`cursor-pointer ${
            language === 'en' ? 'bg-accent font-medium' : ''
          }`}
        >
          <span className="flex items-center gap-2">
            <span className="text-lg">🇬🇧</span>
            <span>English</span>
          </span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
