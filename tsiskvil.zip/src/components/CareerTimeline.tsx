import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Briefcase, TrendingUp, ArrowRightLeft, DollarSign, UserPlus, UserMinus, Plus, Trash2 } from "lucide-react";

interface CareerEvent {
  id: string;
  employee_id: string;
  event_type: string;
  event_date: string;
  position_title: string | null;
  department_name: string | null;
  salary: number | null;
  previous_salary: number | null;
  notes: string | null;
}

const EVENT_TYPES = [
  { value: "hired", ka: "დაქირავება", en: "Hired", icon: UserPlus, color: "hsl(142 71% 45%)" },
  { value: "promotion", ka: "დაწინაურება", en: "Promotion", icon: TrendingUp, color: "hsl(45 93% 47%)" },
  { value: "transfer", ka: "გადაყვანა", en: "Transfer", icon: ArrowRightLeft, color: "hsl(217 91% 60%)" },
  { value: "salary_change", ka: "ხელფასის ცვლილება", en: "Salary Change", icon: DollarSign, color: "hsl(280 84% 60%)" },
  { value: "role_change", ka: "როლის ცვლილება", en: "Role Change", icon: Briefcase, color: "hsl(25 95% 53%)" },
  { value: "left", ka: "გასვლა", en: "Left", icon: UserMinus, color: "hsl(0 84% 60%)" },
];

interface Props {
  employeeId: string;
  userId?: string | null;
  canEdit?: boolean;
}

export default function CareerTimeline({ employeeId, userId, canEdit = false }: Props) {
  const { language } = useLanguage();
  const { toast } = useToast();
  const tr = (ka: string, en: string) => (language === "en" ? en : ka);

  const [events, setEvents] = useState<CareerEvent[]>([]);
  const [open, setOpen] = useState(false);
  const [eventType, setEventType] = useState("promotion");
  const [eventDate, setEventDate] = useState("");
  const [positionTitle, setPositionTitle] = useState("");
  const [deptName, setDeptName] = useState("");
  const [salary, setSalary] = useState("");
  const [prevSalary, setPrevSalary] = useState("");
  const [notes, setNotes] = useState("");

  const load = async () => {
    const { data } = await supabase
      .from("career_events" as any)
      .select("*")
      .eq("employee_id", employeeId)
      .order("event_date", { ascending: false });
    if (data) setEvents(data as any);
  };

  useEffect(() => {
    if (employeeId) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [employeeId]);

  const addEvent = async () => {
    if (!eventDate) return;
    const { error } = await supabase.from("career_events" as any).insert({
      employee_id: employeeId,
      user_id: userId ?? null,
      event_type: eventType,
      event_date: eventDate,
      position_title: positionTitle || null,
      department_name: deptName || null,
      salary: salary ? Number(salary) : null,
      previous_salary: prevSalary ? Number(prevSalary) : null,
      notes: notes || null,
    } as any);
    if (error) {
      toast({ title: tr("შეცდომა", "Error"), variant: "destructive" });
    } else {
      toast({ title: tr("დამატებულია", "Added") });
      setOpen(false);
      setPositionTitle("");
      setDeptName("");
      setSalary("");
      setPrevSalary("");
      setNotes("");
      setEventDate("");
      load();
    }
  };

  const removeEvent = async (id: string) => {
    if (!confirm(tr("წავშალოთ?", "Delete?"))) return;
    await supabase.from("career_events" as any).delete().eq("id", id);
    load();
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <CardTitle className="flex items-center gap-2">
            <Briefcase className="h-5 w-5 text-primary" />
            {tr("კარიერული ისტორია", "Career Timeline")}
          </CardTitle>
          {canEdit && (
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline">
                  <Plus className="h-3 w-3 mr-1" />
                  {tr("მოვლენა", "Event")}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{tr("ახალი მოვლენა", "New Event")}</DialogTitle>
                </DialogHeader>
                <div className="space-y-3">
                  <div>
                    <Label>{tr("ტიპი", "Type")}</Label>
                    <Select value={eventType} onValueChange={setEventType}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {EVENT_TYPES.map((t) => (
                          <SelectItem key={t.value} value={t.value}>{tr(t.ka, t.en)}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>{tr("თარიღი", "Date")}</Label>
                    <Input type="date" value={eventDate} onChange={(e) => setEventDate(e.target.value)} />
                  </div>
                  <div>
                    <Label>{tr("პოზიცია", "Position")}</Label>
                    <Input value={positionTitle} onChange={(e) => setPositionTitle(e.target.value)} />
                  </div>
                  <div>
                    <Label>{tr("დეპარტამენტი", "Department")}</Label>
                    <Input value={deptName} onChange={(e) => setDeptName(e.target.value)} />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label>{tr("ძველი ხელფასი", "Previous Salary")}</Label>
                      <Input type="number" value={prevSalary} onChange={(e) => setPrevSalary(e.target.value)} />
                    </div>
                    <div>
                      <Label>{tr("ახალი ხელფასი", "New Salary")}</Label>
                      <Input type="number" value={salary} onChange={(e) => setSalary(e.target.value)} />
                    </div>
                  </div>
                  <div>
                    <Label>{tr("შენიშვნა", "Notes")}</Label>
                    <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={addEvent}>{tr("შენახვა", "Save")}</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {events.length === 0 ? (
          <p className="text-sm text-muted-foreground py-8 text-center">
            {tr("ჯერ ჩანაწერები არ არის", "No career events yet")}
          </p>
        ) : (
          <div className="relative pl-8 space-y-6">
            <div className="absolute left-[15px] top-2 bottom-2 w-0.5 bg-border" />
            {events.map((e) => {
              const meta = EVENT_TYPES.find((t) => t.value === e.event_type);
              const Icon = meta?.icon || Briefcase;
              const diff = e.salary != null && e.previous_salary != null ? e.salary - e.previous_salary : null;
              return (
                <div key={e.id} className="relative">
                  <div
                    className="absolute -left-8 top-0 h-8 w-8 rounded-full flex items-center justify-center ring-4 ring-background"
                    style={{ background: meta?.color || "hsl(var(--primary))" }}
                  >
                    <Icon className="h-4 w-4 text-white" />
                  </div>
                  <div className="bg-card border border-border rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="outline" style={{ borderColor: meta?.color }}>
                            {meta ? tr(meta.ka, meta.en) : e.event_type}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {new Date(e.event_date).toLocaleDateString(language === "en" ? "en-US" : "ka-GE", {
                              year: "numeric",
                              month: "long",
                              day: "numeric",
                            })}
                          </span>
                        </div>
                        {e.position_title && <p className="font-semibold mt-2">{e.position_title}</p>}
                        {e.department_name && <p className="text-sm text-muted-foreground">{e.department_name}</p>}
                        {e.salary != null && (
                          <div className="mt-2 flex items-center gap-2 text-sm">
                            <span className="font-medium">{e.salary} ₾</span>
                            {diff != null && diff !== 0 && (
                              <Badge variant={diff > 0 ? "default" : "destructive"} className="text-xs">
                                {diff > 0 ? "+" : ""}{diff} ₾
                              </Badge>
                            )}
                          </div>
                        )}
                        {e.notes && <p className="text-sm text-muted-foreground mt-2">{e.notes}</p>}
                      </div>
                      {canEdit && (
                        <Button variant="ghost" size="icon" onClick={() => removeEvent(e.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
