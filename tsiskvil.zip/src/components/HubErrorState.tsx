import { AlertCircle, RefreshCw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface HubErrorStateProps {
  onRetry?: () => void;
}

/**
 * Shared error state for hub landing pages: shows a friendly message
 * and an optional retry button when the initial stats fetch fails.
 */
export default function HubErrorState({ onRetry }: HubErrorStateProps) {
  return (
    <Card className="border-destructive/40">
      <CardContent className="py-10 text-center space-y-3">
        <AlertCircle className="h-10 w-10 mx-auto text-destructive" />
        <p className="text-sm text-muted-foreground">მონაცემების ჩატვირთვა ვერ მოხერხდა</p>
        {onRetry && (
          <Button variant="outline" size="sm" onClick={onRetry} className="gap-2">
            <RefreshCw className="h-4 w-4" />
            ხელახლა ცდა
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
