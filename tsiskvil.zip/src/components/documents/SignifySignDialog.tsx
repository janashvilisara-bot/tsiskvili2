import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { FileSignature, Plus, Trash2, Send, CheckCircle, AlertCircle, Loader2, ArrowLeft, Download } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface Recipient {
  name: string;
  mobileNumber: string;
  email: string;
  recipientCode: string;
}

interface SignifyRecipientResult {
  id: number;
  name: string;
  recipientCode: string;
}

interface SignifySignDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  document?: {
    id: string;
    title: string;
    file_path: string;
  } | null;
  employees: Array<{ id: string; email: string; full_name: string; phone?: string | null }>;
  /** When provided, skip to iframe mode directly for signing an existing request */
  existingSigningUrl?: string | null;
  existingSignerName?: string | null;
  existingSignifyDocId?: number | null;
  existingRecipientCode?: string | null;
  onSigningComplete?: () => void;
}

type Step = 'configure' | 'sending' | 'signing' | 'iframe' | 'completed';

export default function SignifySignDialog({ open, onOpenChange, document, employees, existingSigningUrl, existingSignerName, existingSignifyDocId, existingRecipientCode, onSigningComplete }: SignifySignDialogProps) {
  const { user } = useAuth();

  // Find the current user's employee record to pre-fill as initiator
  const currentEmployee = useMemo(() => {
    if (!user?.email) return null;
    return employees.find(e => e.email === user.email) || null;
  }, [user?.email, employees]);

  const getInitialRecipient = useCallback((): Recipient => {
    if (currentEmployee) {
      return {
        name: currentEmployee.full_name,
        mobileNumber: currentEmployee.phone || '',
        email: currentEmployee.email || '',
        recipientCode: 'signer_1',
      };
    }
    return { name: '', mobileNumber: '', email: '', recipientCode: 'signer_1' };
  }, [currentEmployee]);

  const [recipients, setRecipients] = useState<Recipient[]>([getInitialRecipient()]);
  const [step, setStep] = useState<Step>('configure');
  const [isLoading, setIsLoading] = useState(false);
  const [isCheckingStatus, setIsCheckingStatus] = useState(false);
  const [isConnected, setIsConnected] = useState<boolean | null>(null);

  // Signing state
  const [signifyDocumentId, setSignifyDocumentId] = useState<number | null>(null);
  const [signifyRecipients, setSignifyRecipients] = useState<SignifyRecipientResult[]>([]);
  const [signingUrls, setSigningUrls] = useState<Record<string, string>>({});
  const [signedRecipients, setSignedRecipients] = useState<Set<string>>(new Set());
  const [activeSignerCode, setActiveSignerCode] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [signedFilePath, setSignedFilePath] = useState<string | null>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (open) {
      if (existingSigningUrl) {
        // Direct signing mode - skip to iframe
        setStep('iframe');
        setActiveSignerCode(existingRecipientCode || 'signer_1');
        setSigningUrls({ [existingRecipientCode || 'signer_1']: existingSigningUrl });
        setSignifyDocumentId(existingSignifyDocId || null);
        if (existingSignerName) {
          setSignifyRecipients([{ id: 0, name: existingSignerName, recipientCode: existingRecipientCode || 'signer_1' }]);
        }
        setIsConnected(true);
      } else {
        checkSignifyStatus();
        resetState();
      }
    }
  }, [open, existingSigningUrl]);

  // Listen for iframe messages (sign/reject events from Signify)
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'sign' && activeSignerCode) {
        setSignedRecipients(prev => new Set([...prev, activeSignerCode]));
        toast.success('დოკუმენტი წარმატებით ხელმოწერილია!');
        setActiveSignerCode(null);
        setStep('signing');

        // Check if all signed
        const newSigned = new Set([...signedRecipients, activeSignerCode]);
        if (newSigned.size === signifyRecipients.length) {
          setStep('completed');
        }
      } else if (event.data?.type === 'reject' && activeSignerCode) {
        toast.error('ხელმომწერმა უარყო ხელმოწერა');
        setActiveSignerCode(null);
        setStep('signing');
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [activeSignerCode, signedRecipients, signifyRecipients.length]);

  const resetState = () => {
    setStep('configure');
    setRecipients([getInitialRecipient()]);
    setSignifyDocumentId(null);
    setSignifyRecipients([]);
    setSigningUrls({});
    setSignedRecipients(new Set());
    setActiveSignerCode(null);
    setIsDownloading(false);
    setSignedFilePath(null);
  };

  const checkSignifyStatus = async () => {
    setIsCheckingStatus(true);
    try {
      const { data, error } = await supabase.functions.invoke('signify-sign', {
        body: { action: 'check-status' },
      });
      if (error) throw error;
      setIsConnected(data?.ok !== false && data?.connected === true);
    } catch {
      setIsConnected(false);
    } finally {
      setIsCheckingStatus(false);
    }
  };

  const addRecipient = () => {
    const code = `signer_${recipients.length + 1}`;
    setRecipients([...recipients, { name: '', mobileNumber: '', email: '', recipientCode: code }]);
  };

  const removeRecipient = (index: number) => {
    if (recipients.length > 1) {
      const updated = recipients.filter((_, i) => i !== index);
      setRecipients(updated.map((r, i) => ({ ...r, recipientCode: `signer_${i + 1}` })));
    }
  };

  const updateRecipient = (index: number, field: keyof Recipient, value: string) => {
    const updated = [...recipients];
    updated[index] = { ...updated[index], [field]: value };
    setRecipients(updated);
  };

  const selectEmployee = (employeeId: string, index: number) => {
    const emp = employees.find(e => e.id === employeeId);
    if (emp) {
      const updated = [...recipients];
      updated[index] = {
        ...updated[index],
        name: emp.full_name,
        mobileNumber: emp.phone || '',
        email: emp.email || '',
      };
      setRecipients(updated);
    }
  };

  const formatPhoneNumber = (phone: string): string => {
    let cleaned = phone.replace(/[\s\-\(\)]/g, '');
    // Remove leading + if present for uniform processing
    if (cleaned.startsWith('+')) {
      cleaned = cleaned.substring(1);
    }
    // Handle double prefix: 995995XXXXXXXXX or 995 followed by 10+ digits
    if (cleaned.startsWith('995995')) {
      cleaned = cleaned.substring(3); // remove first 995
    }
    // If starts with 995 and has correct length (12 digits total), add +
    if (cleaned.startsWith('995') && cleaned.length === 12) {
      return '+' + cleaned;
    }
    // If starts with 5 and is 9 digits (Georgian mobile without prefix)
    if (cleaned.startsWith('5') && cleaned.length === 9) {
      return '+995' + cleaned;
    }
    // If it's just digits starting with 995 but wrong length, try to extract
    if (cleaned.startsWith('995')) {
      // Take last 9 digits as the local number
      const localPart = cleaned.substring(cleaned.length - 9);
      if (localPart.startsWith('5')) {
        return '+995' + localPart;
      }
      return '+' + cleaned;
    }
    return '+' + cleaned;
  };

  const handleSend = async () => {
    if (!document) return;

    const validRecipients = recipients.filter(r => r.name.trim() && r.mobileNumber.trim());
    if (validRecipients.length === 0) {
      toast.error('გთხოვთ მიუთითოთ მინიმუმ ერთი ხელმომწერი');
      return;
    }

    const invalidPhone = validRecipients.find(r => {
      const formatted = formatPhoneNumber(r.mobileNumber);
      return !formatted.match(/^\+995\d{9}$/);
    });
    if (invalidPhone) {
      toast.error(`არასწორი ტელეფონის ნომერი: ${invalidPhone.mobileNumber}`);
      return;
    }

    setIsLoading(true);
    setStep('sending');

    try {
      // Download file and convert to base64
      const { data: fileData, error: fileError } = await supabase.storage
        .from('documents')
        .download(document.file_path);
      if (fileError) throw new Error('ფაილის ჩატვირთვა ვერ მოხერხდა');

      const arrayBuffer = await fileData.arrayBuffer();
      const base64 = btoa(
        new Uint8Array(arrayBuffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
      );
      const extension = document.file_path.split('.').pop()?.toLowerCase() || 'pdf';

      // Create document on Signify
      const { data: createResult, error: createError } = await supabase.functions.invoke('signify-sign', {
        body: {
          action: 'create-document',
          documentName: document.title,
          extension,
          fileBase64: base64,
        },
      });
      if (createError || createResult?.ok === false) {
        throw new Error(createResult?.error || 'დოკუმენტის შექმნა ვერ მოხერხდა');
      }

      const docId = createResult.documentId;
      setSignifyDocumentId(docId);

      // Set document details with recipients
      const sigFieldWidth = 150;
      const sigFieldHeight = 60;
      const startLeft = 50;
      const spacing = Math.min(200, (500 - startLeft) / validRecipients.length);

      const apiRecipients = validRecipients.map((r, index) => ({
        name: r.name.trim(),
        mobileNumber: formatPhoneNumber(r.mobileNumber),
        recipientContactType: 'LINK',
        role: 'SIGNER',
        possibleSignatureTypes: ['SMS_OTP'],
        recipientCode: r.recipientCode,
        fields: [
          {
            type: 'SIGNATURE',
            page: -1,
            left: Math.round(startLeft + index * spacing),
            top: 680,
            width: sigFieldWidth,
            height: sigFieldHeight,
          },
        ],
      }));

      const { data: detailsResult, error: detailsError } = await supabase.functions.invoke('signify-sign', {
        body: {
          action: 'set-document-details',
          documentId: docId,
          workflowType: 'PARALLEL',
          recipients: apiRecipients,
        },
      });
      if (detailsError || detailsResult?.ok === false) {
        throw new Error(detailsResult?.error || 'დეტალების დაყენება ვერ მოხერხდა');
      }

      const returnedRecipients: SignifyRecipientResult[] = (detailsResult.recipients || []).map((r: any) => ({
        id: r.id,
        name: r.name,
        recipientCode: r.recipientCode,
      }));
      setSignifyRecipients(returnedRecipients);

      // Generate signing links for each recipient
      const urls: Record<string, string> = {};
      for (const recipient of returnedRecipients) {
        const { data: linkResult, error: linkError } = await supabase.functions.invoke('signify-sign', {
          body: {
            action: 'generate-document-link',
            documentId: docId,
            recipientId: recipient.id,
          },
        });
        if (linkError || linkResult?.ok === false) {
          console.error(`ლინკის გენერაცია ვერ მოხერხდა ${recipient.name}-ისთვის`, linkResult);
          continue;
        }
        urls[recipient.recipientCode] = linkResult.url;
      }

      setSigningUrls(urls);

      // Save signing requests to database
      for (const recipient of validRecipients) {
        const returnedRecipient = returnedRecipients.find(r => r.recipientCode === recipient.recipientCode);
        const { error: saveErr } = await supabase.from('signify_signing_requests').insert({
          document_id: document.id,
          signify_document_id: docId,
          initiated_by: user?.id,
          recipient_name: recipient.name.trim(),
          recipient_email: recipient.email.trim() || null,
          recipient_code: recipient.recipientCode,
          signify_recipient_id: returnedRecipient?.id || null,
          signing_url: urls[recipient.recipientCode] || null,
          status: 'pending',
        } as any);
        if (saveErr) {
          console.error('Signing request save error:', saveErr);
          toast.error(`${recipient.name.trim()}-ის ხელმოწერის მოთხოვნა ბაზაში ვერ შეინახა`);
        }
      }

      // Send email notifications to OTHER recipients (not the initiator)
      for (let i = 1; i < validRecipients.length; i++) {
        const recipient = validRecipients[i];
        const signingUrl = urls[recipient.recipientCode];
        const recipientEmail = recipient.email.trim();
        if (recipientEmail) {
          try {
            await supabase.functions.invoke('send-signify-signature-email', {
              body: {
                documentId: document.id,
                recipientCode: recipient.recipientCode,
              },
            });
            toast.success(`ემეილი გაიგზავნა: ${recipientEmail}`);
          } catch (emailErr) {
            console.error(`ემეილის გაგზავნა ვერ მოხერხდა ${recipientEmail}-ზე:`, emailErr);
          }
        }
      }

      // Show intermediate signing screen (not auto-open iframe)
      setStep('signing');
      toast.success('დოკუმენტი მომზადდა! სხვა ხელმომწერებს ემეილი გაეგზავნათ.');

    } catch (error: any) {
      console.error('Signify send error:', error);
      toast.error(error.message || 'შეცდომა');
      setStep('configure');
    } finally {
      setIsLoading(false);
    }
  };

  const openSignerIframe = (recipientCode: string) => {
    const url = signingUrls[recipientCode];
    if (url) {
      setActiveSignerCode(recipientCode);
      setStep('iframe');
    }
  };

  const getIframeUrl = () => {
    if (!activeSignerCode || !signingUrls[activeSignerCode]) return '';
    return signingUrls[activeSignerCode] + '?hideThumbnails=true&hideHeader=true&hideClose=true';
  };

  const downloadSignedDocument = async () => {
    if (!signifyDocumentId || !document) return;
    setIsDownloading(true);
    try {
      const { data, error } = await supabase.functions.invoke('signify-sign', {
        body: {
          action: 'download-document',
          documentId: signifyDocumentId,
          originalDocumentId: document.id,
          originalFilePath: document.file_path,
        },
      });

      if (error || data?.ok === false) {
        throw new Error(data?.error || 'გადმოწერა ვერ მოხერხდა');
      }

      if (data.storagePath) {
        setSignedFilePath(data.storagePath);
        toast.success('ხელმოწერილი დოკუმენტი შენახულია სისტემაში!');
      }

      // Also trigger browser download
      if (data.fileBase64) {
        const binaryStr = atob(data.fileBase64);
        const bytes = new Uint8Array(binaryStr.length);
        for (let i = 0; i < binaryStr.length; i++) {
          bytes[i] = binaryStr.charCodeAt(i);
        }
        const blob = new Blob([bytes], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        const a = window.document.createElement('a');
        a.href = url;
        a.download = data.fileName || `${document.title}_signed.pdf`;
        a.click();
        URL.revokeObjectURL(url);
      }
    } catch (err: any) {
      console.error('Download error:', err);
      toast.error(err.message || 'გადმოწერა ვერ მოხერხდა');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    setRecipients([getInitialRecipient()]);
    resetState();
    onSigningComplete?.();
  };

  const activeSignerName = activeSignerCode
    ? signifyRecipients.find(r => r.recipientCode === activeSignerCode)?.name
    : '';

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className={step === 'iframe' ? 'max-w-5xl h-[95vh] flex flex-col overflow-hidden p-2 sm:p-6' : 'max-w-lg max-h-[90vh] overflow-y-auto'}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSignature className="h-5 w-5 text-primary" />
            ელექტრონული ხელმოწერა - Signify
          </DialogTitle>
          <DialogDescription>
            {step === 'configure' && 'გაგზავნეთ დოკუმენტი ელექტრონული ხელმოწერისთვის SMS OTP-ით'}
            {step === 'sending' && 'მიმდინარეობს დოკუმენტის მომზადება...'}
            {step === 'signing' && 'აირჩიეთ ხელმომწერი ხელმოწერის დასაწყებად'}
            {step === 'iframe' && `${activeSignerName} - ხელმოწერის პროცესი`}
            {step === 'completed' && 'ყველა ხელმომწერმა მოაწერა ხელი დოკუმენტს'}
          </DialogDescription>
        </DialogHeader>

        {/* Connection status */}
        {step !== 'iframe' && (
          <div className="flex items-center gap-2 p-3 rounded-lg border bg-muted/30">
            {isCheckingStatus ? (
              <><Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /><span className="text-sm text-muted-foreground">კავშირის შემოწმება...</span></>
            ) : isConnected ? (
              <><CheckCircle className="h-4 w-4 text-green-500" /><span className="text-sm text-green-700 dark:text-green-400">Signify API დაკავშირებულია</span></>
            ) : (
              <><AlertCircle className="h-4 w-4 text-amber-500" /><span className="text-sm text-amber-700 dark:text-amber-400">Signify API არ არის კონფიგურირებული</span></>
            )}
          </div>
        )}

        {/* Document info */}
        {document && step !== 'iframe' && (
          <div className="p-3 rounded-lg border bg-card">
            <p className="text-sm font-medium">დოკუმენტი:</p>
            <p className="text-sm text-muted-foreground">{document.title}</p>
          </div>
        )}

        {/* ─── Step: Configure ─── */}
        {step === 'configure' && (
          <>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium">ხელმომწერები</Label>
                <Button type="button" variant="outline" size="sm" onClick={addRecipient}>
                  <Plus className="h-3.5 w-3.5 mr-1" /> დამატება
                </Button>
              </div>

              {recipients.map((recipient, index) => (
                <div key={index} className="flex items-end gap-2 p-3 rounded-lg border bg-muted/20">
                  <div className="flex-1 space-y-2">
                    <Select onValueChange={(val) => selectEmployee(val, index)}>
                      <SelectTrigger className="h-8 text-sm">
                        <SelectValue placeholder="აირჩიეთ თანამშრომელი..." />
                      </SelectTrigger>
                      <SelectContent>
                        {employees.map(emp => (
                          <SelectItem key={emp.id} value={emp.id}>
                            {emp.full_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        placeholder="სახელი გვარი"
                        value={recipient.name}
                        onChange={(e) => updateRecipient(index, 'name', e.target.value)}
                        className="h-8 text-sm"
                      />
                      <Input
                        placeholder="+995XXXXXXXXX"
                        value={recipient.mobileNumber}
                        onChange={(e) => updateRecipient(index, 'mobileNumber', e.target.value)}
                        className="h-8 text-sm"
                      />
                    </div>
                    <Input
                      placeholder="ელ-ფოსტა (მაგ: example@mail.com)"
                      type="email"
                      value={recipient.email}
                      onChange={(e) => updateRecipient(index, 'email', e.target.value)}
                      className="h-8 text-sm"
                    />
                    <Badge variant="default" className="text-xs">
                      ✍️ ხელმომწერი #{index + 1} (SMS OTP)
                    </Badge>
                  </div>
                  {recipients.length > 1 && (
                    <Button type="button" variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => removeRecipient(index)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                გაუქმება
              </Button>
              <Button onClick={handleSend} disabled={isLoading || !isConnected || !document} className="gap-2">
                <Send className="h-4 w-4" />
                ხელმოწერის ინიცირება
              </Button>
            </div>
          </>
        )}

        {/* ─── Step: Sending ─── */}
        {step === 'sending' && (
          <div className="flex flex-col items-center justify-center py-8 gap-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">დოკუმენტი მზადდება Signify-ზე...</p>
          </div>
        )}

        {/* ─── Step: Signing (intermediate success screen) ─── */}
        {step === 'signing' && (
          <div className="space-y-4">
            <div className="flex flex-col items-center gap-3 py-4">
              <CheckCircle className="h-10 w-10 text-green-500" />
              <p className="text-base font-medium text-center">დოკუმენტი წარმატებით გაიგზავნა!</p>
              <p className="text-sm text-muted-foreground text-center">
                {recipients.length > 1
                  ? `სხვა ხელმომწერებს (${recipients.length - 1}) ემეილი გაეგზავნათ ხელმოწერის ბმულით.`
                  : 'დოკუმენტი მზადაა თქვენი ხელმოწერისთვის.'}
              </p>
            </div>

            {/* Initiator signing button */}
            {signifyRecipients.filter(r => r.recipientCode === 'signer_1').map((recipient) => {
              const isSigned = signedRecipients.has(recipient.recipientCode);
              const hasUrl = !!signingUrls[recipient.recipientCode];

              return (
                <div
                  key={recipient.id}
                  className="flex items-center justify-between p-4 rounded-lg border bg-card"
                >
                  <div className="flex items-center gap-2">
                    {isSigned ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <FileSignature className="h-5 w-5 text-primary" />
                    )}
                    <div>
                      <span className="text-sm font-medium">{recipient.name}</span>
                      <span className="text-xs text-muted-foreground ml-2">(ინიციატორი)</span>
                    </div>
                    {isSigned && (
                      <Badge variant="secondary" className="text-xs">ხელმოწერილია</Badge>
                    )}
                  </div>
                  {!isSigned && hasUrl && (
                    <Button
                      size="sm"
                      onClick={() => openSignerIframe(recipient.recipientCode)}
                      className="gap-1"
                    >
                      <FileSignature className="h-3.5 w-3.5" />
                      ახლავე ხელმოწერა
                    </Button>
                  )}
                </div>
              );
            })}

            <p className="text-xs text-muted-foreground text-center">
              💡 ხელმოწერა ასევე შეგიძლიათ მოგვიანებით - „ხელმოწერები" ტაბიდან
            </p>

            <div className="flex justify-end gap-2 pt-2">
              <Button
                onClick={downloadSignedDocument}
                disabled={isDownloading}
                variant="outline"
                className="gap-2"
              >
                {isDownloading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Download className="h-4 w-4" />
                )}
                {isDownloading ? 'მიმდინარეობს...' : 'ჩამოტვირთვა და შენახვა'}
              </Button>
              <Button variant="outline" onClick={handleClose}>
                დახურვა
              </Button>
            </div>
          </div>
        )}

        {/* ─── Step: Iframe (embedded signing) ─── */}
        {step === 'iframe' && (
          <div className="flex-1 flex flex-col min-h-0">
            <div className="flex items-center gap-2 mb-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  if (existingSigningUrl) {
                    handleClose();
                  } else {
                    setActiveSignerCode(null);
                    setStep('signing');
                  }
                }}
                className="gap-1"
              >
                <ArrowLeft className="h-4 w-4" />
                {existingSigningUrl ? 'დახურვა' : 'უკან'}
              </Button>
              <span className="text-sm text-muted-foreground flex-1">
                ხელმომწერი: <strong>{activeSignerName}</strong>
              </span>
              <Button
                size="sm"
                variant="default"
                onClick={async () => {
                  // Mark this signer as signed in the DB
                  if (activeSignerCode && signifyDocumentId) {
                    const { error: markErr } = await supabase
                      .from('signify_signing_requests' as any)
                      .update({ status: 'signed', signed_at: new Date().toISOString() } as any)
                      .eq('signify_document_id', signifyDocumentId)
                      .eq('recipient_code', activeSignerCode);
                    if (markErr) {
                      console.error('Mark signed error:', markErr);
                      toast.error('ხელმოწერის სტატუსი ვერ შეინახა. სცადეთ თავიდან');
                      return;
                    }
                    
                    setSignedRecipients(prev => new Set([...prev, activeSignerCode]));
                    toast.success('ხელმოწერა დაფიქსირდა!');
                    onSigningComplete?.();
                  }
                  setActiveSignerCode(null);
                  // Always show completed step with download button
                  setStep('completed');
                }}
                className="gap-1"
              >
                <CheckCircle className="h-3.5 w-3.5" />
                ხელმოწერა დასრულდა
              </Button>
            </div>
            <div className="flex-1 rounded-lg border overflow-hidden bg-background min-h-[400px] -webkit-overflow-scrolling-touch">
              <iframe
                ref={iframeRef}
                src={getIframeUrl()}
                className="w-full h-full border-0"
                style={{ minHeight: '70vh', WebkitOverflowScrolling: 'touch' }}
                allow="camera; microphone"
                scrolling="yes"
              />
            </div>
          </div>
        )}

        {/* ─── Step: Completed ─── */}
        {step === 'completed' && (
          <div className="flex flex-col items-center justify-center py-8 gap-4">
            <CheckCircle className="h-12 w-12 text-green-500" />
            <p className="text-base font-medium">ყველა ხელმომწერმა მოაწერა ხელი!</p>
            <p className="text-sm text-muted-foreground">დოკუმენტი წარმატებით ხელმოწერილია</p>
            {signedFilePath && (
              <Badge variant="secondary" className="text-xs">
                ✅ შენახულია სისტემაში
              </Badge>
            )}
            <div className="flex gap-2">
              <Button
                onClick={downloadSignedDocument}
                disabled={isDownloading}
                className="gap-2"
              >
                {isDownloading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Download className="h-4 w-4" />
                )}
                {isDownloading ? 'მიმდინარეობს...' : 'ჩამოტვირთვა და შენახვა'}
              </Button>
              <Button variant="outline" onClick={handleClose}>დახურვა</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
