import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  PhoneOff,
  Monitor,
  MonitorOff,
  Radio,
  Users,
  Settings,
  Minimize2,
  Maximize2,
  MessageSquare,
  Send,
  X,
} from "lucide-react";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";

interface EnhancedVideoCallProps {
  roomId: string;
  userId: string;
  remoteUserIds: string[];
  onEnd: () => void;
  isInitiator?: boolean;
  initialSignal?: any;
}

interface Participant {
  id: string;
  stream?: MediaStream;
  name?: string;
  avatar?: string;
  isMuted?: boolean;
  isVideoOff?: boolean;
}

interface ChatMessage {
  id: string;
  sender_id: string;
  receiver_id: string | null;
  content: string;
  created_at: string;
  room_id: string;
  type: string;
  file_name: string | null;
  file_size: number | null;
  file_type: string | null;
  file_url: string | null;
}

interface ChatWindow {
  participantId: string;
  isOpen: boolean;
  messages: ChatMessage[];
  newMessage: string;
}

export default function EnhancedVideoCall({ 
  roomId, 
  userId, 
  remoteUserIds, 
  onEnd,
  isInitiator = true,
  initialSignal 
}: EnhancedVideoCallProps) {
  const { toast } = useToast();
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideosRef = useRef<Map<string, HTMLVideoElement>>(new Map());
  const peerConnections = useRef<Map<string, RTCPeerConnection>>(new Map());
  const localStreamRef = useRef<MediaStream | null>(null);
  const channelRef = useRef<RealtimeChannel | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [callId, setCallId] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(true);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [showParticipants, setShowParticipants] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPiP, setIsPiP] = useState(false);
  const [chatWindows, setChatWindows] = useState<ChatWindow[]>([]);
  const incomingCallAudioRef = useRef<HTMLAudioElement | null>(null);
  const endCallAudioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Initialize audio elements with better quality sounds
    incomingCallAudioRef.current = new Audio();
    incomingCallAudioRef.current.src = 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3'; // Ringtone
    
    endCallAudioRef.current = new Audio();
    endCallAudioRef.current.src = 'https://assets.mixkit.co/active_storage/sfx/2363/2363-preview.mp3'; // End call beep
    
    initializeCall();
    return () => {
      cleanup();
    };
  }, [roomId, userId]);

  // Play ringtone on mount with user interaction
  const playRingtone = () => {
    if (incomingCallAudioRef.current && isConnecting) {
      incomingCallAudioRef.current.loop = true;
      incomingCallAudioRef.current.volume = 0.5;
    }
  };

  const initializeCall = async () => {
    try {
      
      // Get local media stream
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 1280, height: 720 },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      localStreamRef.current = stream;
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      // Fetch participant details with avatars
      const { data: employeeData } = await supabase
        .from("employees")
        .select("id, user_id, full_name, avatar_url")
        .in("user_id", remoteUserIds);

      if (employeeData) {
        const participantsData = employeeData.map((emp) => ({
          id: emp.user_id,
          name: emp.full_name,
          avatar: emp.avatar_url || undefined,
        }));
        setParticipants(participantsData);
      }

      // Create call record (initiator only)
      if (isInitiator) {
        const { data: call, error } = await supabase
          .from("video_calls")
          .insert({
            room_id: roomId,
            started_by: userId,
            status: "active",
          })
          .select()
          .maybeSingle();
        
        if (error) throw error;
        if (call) {
          setCallId(call.id);
          
          // Add self as participant
          await supabase
            .from("video_call_participants")
            .insert({
              call_id: call.id,
              user_id: userId,
              is_host: true,
            });
        }
      }

      // Setup WebRTC for each remote user
      for (const remoteUserId of remoteUserIds) {
        await setupPeerConnection(stream, remoteUserId);
      }
      
      // Setup signaling channel
      await setupSignalingChannel();
      
      // Stop ringtone when connected
      if (incomingCallAudioRef.current) {
        incomingCallAudioRef.current.pause();
        incomingCallAudioRef.current.currentTime = 0;
      }
      
      setIsConnecting(false);
    } catch (error) {
      console.error("Error initializing call:", error);
      toast({
        title: "შეცდომა",
        description: "ვიდეო ქოლის დაწყება ვერ მოხერხდა",
        variant: "destructive",
      });
      onEnd();
    }
  };

  const setupPeerConnection = async (stream: MediaStream, remoteUserId: string) => {
    const configuration = {
      iceServers: [
        { urls: "stun:stun.l.google.com:19302" },
        { urls: "stun:stun1.l.google.com:19302" }
      ],
    };

    const peerConnection = new RTCPeerConnection(configuration);
    peerConnections.current.set(remoteUserId, peerConnection);

    // Add local stream tracks
    stream.getTracks().forEach((track) => {
      peerConnection.addTrack(track, stream);
    });

    // Handle incoming tracks
    peerConnection.ontrack = (event) => {
      const videoElement = remoteVideosRef.current.get(remoteUserId);
      if (videoElement && event.streams[0]) {
        videoElement.srcObject = event.streams[0];
        // მნიშვნელოვანია: აუცილებლად გამოვიძახოთ play() რომ ვიდეო დაიწყოს
        setParticipants(prev => {
          const existing = prev.find(p => p.id === remoteUserId);
          if (existing) {
            return prev.map(p => p.id === remoteUserId ? { ...p, stream: event.streams[0] } : p);
          }
          return [...prev, { id: remoteUserId, stream: event.streams[0] }];
        });
      }
    };

    // Handle ICE candidates
    peerConnection.onicecandidate = async (event) => {
      if (event.candidate) {
        await sendSignal('ice-candidate', { candidate: event.candidate.toJSON() }, remoteUserId);
      }
    };

    // Handle connection state
    peerConnection.onconnectionstatechange = () => {
      if (peerConnection.connectionState === "connected") {
        setIsConnecting(false);
      }
    };
  };

  const setupSignalingChannel = async () => {
    
    const channel = supabase
      .channel(`webrtc:${roomId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'webrtc_signals',
          filter: `receiver_id=eq.${userId}`
        },
        async (payload) => {
          await handleSignal(payload.new);
        }
      )
      .on('broadcast', { event: 'signal' }, async ({ payload }) => {
        // Expect same shape as DB row
        if (!payload) return;
        await handleSignal(payload);
      })
      .subscribe((status) => {
      });

    channelRef.current = channel;

    if (isInitiator) {
      // Send offers to all remote users
      for (const remoteUserId of remoteUserIds) {
        const pc = peerConnections.current.get(remoteUserId);
        if (pc) {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          await sendSignal('offer', { sdp: offer }, remoteUserId);
        }
      }
    }
  };

  const sendSignal = async (type: string, data: any, receiverId: string) => {

    // 1) Try broadcast channel (no DB / RLS issues)
    if (channelRef.current) {
      const ok = await channelRef.current.send({
        type: 'broadcast',
        event: 'signal',
        payload: {
          room_id: roomId,
          sender_id: userId,
          receiver_id: receiverId,
          signal_type: type,
          signal_data: data,
        },
      });
    }

    // 2) Also persist to DB (optional)
    const { error } = await supabase
      .from('webrtc_signals')
      .insert({
        room_id: roomId,
        sender_id: userId,
        receiver_id: receiverId,
        signal_type: type,
        signal_data: data,
      });
    
    if (error) {
      console.error('Error sending signal (DB):', error);
    }
  };

  const handleSignal = async (signal: any) => {
    // Filter messages not intended for this client and avoid self-echo
    if (signal?.receiver_id && signal.receiver_id !== userId) return;
    if (signal?.sender_id === userId) return;

    let pc = peerConnections.current.get(signal.sender_id);
    if (!pc) {
      console.warn("No peer connection for sender, creating on the fly:", signal.sender_id);
      if (localStreamRef.current) {
        await setupPeerConnection(localStreamRef.current, signal.sender_id);
        pc = peerConnections.current.get(signal.sender_id)!;
      } else {
        console.error("Local stream missing; cannot create peer connection.");
        return;
      }
    }

    try {
      if (signal.signal_type === 'offer') {
        await pc.setRemoteDescription(new RTCSessionDescription(signal.signal_data.sdp));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        await sendSignal('answer', { sdp: answer }, signal.sender_id);
      } else if (signal.signal_type === 'answer') {
        await pc.setRemoteDescription(new RTCSessionDescription(signal.signal_data.sdp));
      } else if (signal.signal_type === 'ice-candidate') {
        await pc.addIceCandidate(new RTCIceCandidate(signal.signal_data.candidate));
      }
    } catch (error) {
      console.error("Error handling signal:", error);
    }
  };

  const toggleMute = () => {
    if (localStreamRef.current) {
      const audioTracks = localStreamRef.current.getAudioTracks();
      audioTracks.forEach((track) => {
        track.enabled = !track.enabled;
      });
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (localStreamRef.current) {
      const videoTracks = localStreamRef.current.getVideoTracks();
      videoTracks.forEach((track) => {
        track.enabled = !track.enabled;
      });
      setIsVideoOff(!isVideoOff);
    }
  };

  const toggleScreenShare = async () => {
    try {
      if (!isScreenSharing) {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
        });

        const screenTrack = screenStream.getVideoTracks()[0];
        
        // Replace video track for all peer connections
        peerConnections.current.forEach((pc) => {
          const sender = pc.getSenders().find((s) => s.track?.kind === "video");
          if (sender) {
            sender.replaceTrack(screenTrack);
          }
        });

        setIsScreenSharing(true);

        screenTrack.onended = () => {
          toggleScreenShare();
        };
      } else {
        const videoTrack = localStreamRef.current?.getVideoTracks()[0];
        
        // Restore camera track for all peer connections
        if (videoTrack) {
          peerConnections.current.forEach((pc) => {
            const sender = pc.getSenders().find((s) => s.track?.kind === "video");
            if (sender) {
              sender.replaceTrack(videoTrack);
            }
          });
        }
        
        setIsScreenSharing(false);
      }
    } catch (error) {
      console.error("Error toggling screen share:", error);
      toast({
        title: "შეცდომა",
        description: "ეკრანის გაზიარება ვერ მოხერხდა",
        variant: "destructive",
      });
    }
  };

  const startRecording = async () => {
    if (!localStreamRef.current) return;

    try {
      const mediaRecorder = new MediaRecorder(localStreamRef.current, {
        mimeType: 'video/webm;codecs=vp8,opus'
      });

      mediaRecorderRef.current = mediaRecorder;
      recordedChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        
        // Upload recording
        const fileName = `call-${callId}-${Date.now()}.webm`;
        const { error: uploadError } = await supabase.storage
          .from('documents')
          .upload(`recordings/${fileName}`, blob);

        if (!uploadError && callId) {
          const { data: signedData } = await supabase.storage
            .from('documents')
            .createSignedUrl(`recordings/${fileName}`, 60 * 60 * 24 * 365);

          await supabase.from('call_recordings').insert({
            call_id: callId,
            started_by: userId,
            file_url: signedData?.signedUrl ?? '',
            file_size: blob.size,
            status: 'completed',
          });

          toast({
            title: "ჩაწერა დასრულდა",
            description: "ვიდეო წარმატებით შეინახა",
          });
        }
      };

      mediaRecorder.start();
      setIsRecording(true);

      // Create recording entry
      if (callId) {
        await supabase.from('call_recordings').insert({
          call_id: callId,
          started_by: userId,
          status: 'recording',
        });
      }

      toast({
        title: "ჩაწერა დაიწყო",
        description: "ვიდეო ქოლი იწერება",
      });
    } catch (error) {
      console.error("Error starting recording:", error);
      toast({
        title: "შეცდომა",
        description: "ჩაწერის დაწყება ვერ მოხერხდა",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const endCall = async () => {
    if (isRecording) {
      stopRecording();
    }

    // Play end call sound
    if (endCallAudioRef.current) {
    }

    if (callId) {
      await supabase
        .from("video_calls")
        .update({ status: "ended", ended_at: new Date().toISOString() })
        .eq("id", callId);

      await supabase
        .from("video_call_participants")
        .update({ left_at: new Date().toISOString() })
        .eq("call_id", callId)
        .eq("user_id", userId);
    }
    cleanup();
    onEnd();
  };

  const cleanup = () => {
    // Stop ringtone if still playing
    if (incomingCallAudioRef.current) {
      incomingCallAudioRef.current.pause();
      incomingCallAudioRef.current.currentTime = 0;
    }
    
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
    }
    peerConnections.current.forEach((pc) => {
      pc.close();
    });
    peerConnections.current.clear();
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
    }
  };

  const togglePiP = async () => {
    if (!localVideoRef.current) return;
    
    try {
      if (!isPiP && document.pictureInPictureElement !== localVideoRef.current) {
        await localVideoRef.current.requestPictureInPicture();
        setIsPiP(true);
      } else if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setIsPiP(false);
      }
    } catch (error) {
      console.error("Error toggling PiP:", error);
    }
  };

  const openChatWithParticipant = (participantId: string) => {
    setChatWindows(prev => {
      const existing = prev.find(w => w.participantId === participantId);
      if (existing) {
        return prev.map(w => 
          w.participantId === participantId ? { ...w, isOpen: true } : w
        );
      }
      return [...prev, {
        participantId,
        isOpen: true,
        messages: [],
        newMessage: ''
      }];
    });

    // Load chat messages
    loadChatMessages(participantId);
  };

  const loadChatMessages = async (participantId: string) => {
    const { data, error } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('room_id', roomId)
      .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`)
      .or(`sender_id.eq.${participantId},receiver_id.eq.${participantId}`)
      .order('created_at', { ascending: true });

    if (!error && data) {
      setChatWindows(prev => prev.map(w => 
        w.participantId === participantId 
          ? { ...w, messages: data }
          : w
      ));
    }

    // Subscribe to new messages
    const channel = supabase
      .channel(`chat:${roomId}:${participantId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `room_id=eq.${roomId}`
        },
        (payload) => {
          const newMsg = payload.new as ChatMessage;
          if (
            (newMsg.sender_id === participantId && newMsg.receiver_id === userId) ||
            (newMsg.sender_id === userId && newMsg.receiver_id === participantId)
          ) {
            setChatWindows(prev => prev.map(w => 
              w.participantId === participantId 
                ? { ...w, messages: [...w.messages, newMsg] }
                : w
            ));
          }
        }
      )
      .subscribe();
  };

  const sendChatMessage = async (participantId: string) => {
    const chatWindow = chatWindows.find(w => w.participantId === participantId);
    if (!chatWindow || !chatWindow.newMessage.trim()) return;

    const { error } = await supabase
      .from('chat_messages')
      .insert({
        room_id: roomId,
        sender_id: userId,
        receiver_id: participantId,
        content: chatWindow.newMessage,
      });

    if (!error) {
      setChatWindows(prev => prev.map(w => 
        w.participantId === participantId 
          ? { ...w, newMessage: '' }
          : w
      ));
    }
  };

  const closeChatWindow = (participantId: string) => {
    setChatWindows(prev => prev.map(w => 
      w.participantId === participantId 
        ? { ...w, isOpen: false }
        : w
    ));
  };

  return (
    <>
      <div className={`${isFullscreen ? 'fixed inset-0 z-50' : 'fixed bottom-6 right-6 z-50 w-[600px] h-[550px]'} transition-all duration-300 ease-in-out`}>
        <Card className="h-full flex flex-col overflow-hidden border-2 border-primary/20 bg-gradient-to-br from-background to-muted/50 backdrop-blur-sm shadow-2xl">
        {isConnecting && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/50 backdrop-blur-sm">
            <Card className="p-6 text-center animate-fade-in">
              <div className="mb-4 text-lg font-semibold">შემომავალი ზარი...</div>
              <div className="h-2 w-64 overflow-hidden rounded-full bg-muted mb-4">
                <div className="h-full w-1/2 animate-pulse bg-primary" />
              </div>
              <Button 
                onClick={playRingtone}
                variant="outline"
                size="sm"
              >
                ხმის ჩართვა
              </Button>
            </Card>
          </div>
        )}

        {/* Header with fullscreen toggle */}
        <div className="flex items-center justify-between border-b border-border bg-card/80 backdrop-blur-sm px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
              <Video className="h-4 w-4 text-primary" />
            </div>
            <div>
              <div className="font-semibold text-foreground">ვიდეო ქოლი</div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                აქტიური
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isRecording && (
              <Badge variant="destructive" className="animate-pulse">
                <Radio className="mr-1 h-3 w-3" />
                ჩაწერა
              </Badge>
            )}
            <Button
              size="sm"
              variant="ghost"
              onClick={togglePiP}
              className="h-8 w-8 p-0 hover:bg-primary/10 transition-colors mr-1"
              title="Picture-in-Picture"
            >
              <Monitor className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="h-8 w-8 p-0 hover:bg-primary/10 transition-colors"
              title={isFullscreen ? "შემცირება" : "გაფართოება"}
            >
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {/* Main video grid */}
        <div className="flex-1 overflow-hidden p-3">
          <div className={`grid h-full gap-3 ${remoteUserIds.length > 1 ? 'grid-cols-2' : 'grid-cols-1'}`}>
            {/* Remote videos */}
            {remoteUserIds.map((remoteUserId) => (
              <Card key={remoteUserId} className="relative overflow-hidden bg-black shadow-xl rounded-xl">
                <video
                  ref={(el) => {
                    if (el) {
                      remoteVideosRef.current.set(remoteUserId, el);
                      // თუ უკვე არის srcObject, დავიწყოთ ვიდეო
                      if (el.srcObject) {
                      }
                    }
                  }}
                  autoPlay
                  playsInline
                  className="h-full w-full object-cover"
                />
                <div className="absolute bottom-3 left-3 flex items-center gap-2 animate-fade-in">
                  <Avatar className="h-9 w-9 border-2 border-white shadow-lg">
                    <AvatarFallback className="bg-primary text-primary-foreground text-sm">U</AvatarFallback>
                  </Avatar>
                  <Badge variant="secondary" className="bg-black/60 text-white backdrop-blur-md border border-white/20">
                    მონაწილე
                  </Badge>
                </div>
              </Card>
            ))}

            {/* Local video */}
            <Card className="relative overflow-hidden bg-black shadow-xl rounded-xl">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="h-full w-full object-cover"
              />
              <div className="absolute bottom-3 left-3 flex items-center gap-2 animate-fade-in">
                <Avatar className="h-9 w-9 border-2 border-white shadow-lg">
                  <AvatarFallback className="bg-primary text-primary-foreground text-sm">თქვენ</AvatarFallback>
                </Avatar>
                {isRecording && (
                  <Badge variant="destructive" className="flex items-center gap-1 shadow-lg animate-pulse">
                    <Radio className="h-3 w-3" />
                    ჩაწერა
                  </Badge>
                )}
              </div>
              {(isMuted || isVideoOff) && (
                <div className="absolute top-3 right-3 flex gap-2 animate-fade-in">
                  {isMuted && (
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-destructive/90 backdrop-blur-sm shadow-lg">
                      <MicOff className="h-4 w-4 text-white" />
                    </div>
                  )}
                  {isVideoOff && (
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-destructive/90 backdrop-blur-sm shadow-lg">
                      <VideoOff className="h-4 w-4 text-white" />
                    </div>
                  )}
                </div>
              )}
            </Card>
          </div>
        </div>

        {/* Controls */}
        <div className="shrink-0 border-t border-border bg-card/80 backdrop-blur-sm p-4">
          <div className="flex items-center justify-between">
            <div className="flex gap-2">
              <Button
                size="lg"
                variant={isMuted ? "destructive" : "secondary"}
                onClick={toggleMute}
                className="rounded-full shadow-md hover:shadow-lg transition-all hover:scale-105"
                title={isMuted ? "მიკროფონის ჩართვა" : "მიკროფონის გამორთვა"}
              >
                {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
              </Button>

              <Button
                size="lg"
                variant={isVideoOff ? "destructive" : "secondary"}
                onClick={toggleVideo}
                className="rounded-full shadow-md hover:shadow-lg transition-all hover:scale-105"
                title={isVideoOff ? "კამერის ჩართვა" : "კამერის გამორთვა"}
              >
                {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
              </Button>

              <Button
                size="lg"
                variant={isScreenSharing ? "default" : "secondary"}
                onClick={toggleScreenShare}
                className="rounded-full shadow-md hover:shadow-lg transition-all hover:scale-105"
                title={isScreenSharing ? "გაზიარების გაჩერება" : "ეკრანის გაზიარება"}
              >
                {isScreenSharing ? <MonitorOff className="h-5 w-5" /> : <Monitor className="h-5 w-5" />}
              </Button>

              <Button
                size="lg"
                variant={isRecording ? "destructive" : "secondary"}
                onClick={isRecording ? stopRecording : startRecording}
                className="rounded-full shadow-md hover:shadow-lg transition-all hover:scale-105"
                title={isRecording ? "ჩაწერის გაჩერება" : "ჩაწერის დაწყება"}
              >
                <Radio className={`h-5 w-5 ${isRecording ? 'animate-pulse' : ''}`} />
              </Button>
            </div>

            <div className="flex gap-2">
              <Button
                size="lg"
                variant="secondary"
                onClick={() => setShowParticipants(true)}
                className="rounded-full shadow-md hover:shadow-lg transition-all hover:scale-105"
                title="მონაწილეები"
              >
                <Users className="h-5 w-5" />
                <span className="ml-2 text-sm font-semibold">{remoteUserIds.length + 1}</span>
              </Button>

              <Button
                size="lg"
                variant="secondary"
                onClick={() => {
                  // Open chat with all participants
                  participants.forEach(p => openChatWithParticipant(p.id));
                }}
                className="rounded-full shadow-md hover:shadow-lg transition-all hover:scale-105"
                title="ჩატი"
              >
                <MessageSquare className="h-5 w-5" />
              </Button>

              <Button
                size="lg"
                variant="secondary"
                onClick={() => setShowSettings(true)}
                className="rounded-full shadow-md hover:shadow-lg transition-all hover:scale-105"
                title="პარამეტრები"
              >
                <Settings className="h-5 w-5" />
              </Button>

              <Button 
                size="lg" 
                variant="destructive" 
                onClick={endCall} 
                className="rounded-full shadow-md hover:shadow-lg transition-all hover:scale-105"
                title="ზარის დასრულება"
              >
                <PhoneOff className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Participants Dialog */}
        <Dialog open={showParticipants} onOpenChange={setShowParticipants}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                მონაწილეები ({remoteUserIds.length + 1})
              </DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-64 pr-4">
              <div className="space-y-2">
                <div className="flex items-center gap-3 rounded-lg border border-primary/20 bg-primary/5 p-3 transition-colors hover:bg-primary/10">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-primary text-primary-foreground">თქვენ</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="font-medium">თქვენ (მასპინძელი)</div>
                    <div className="text-xs text-muted-foreground">აქტიური</div>
                  </div>
                  <Badge variant="secondary" className="bg-green-500/10 text-green-700 border-green-500/20">
                    <div className="h-2 w-2 rounded-full bg-green-500 mr-1" />
                    Online
                  </Badge>
                </div>
                {participants.map((participant) => (
                  <div key={participant.id} className="flex items-center gap-3 rounded-lg border p-3 transition-colors hover:bg-muted/50">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={participant.avatar} />
                      <AvatarFallback>U</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="font-medium">{participant.name || 'მონაწილე'}</div>
                      <div className="text-xs text-muted-foreground">აქტიური</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="bg-green-500/10 text-green-700 border-green-500/20">
                        <div className="h-2 w-2 rounded-full bg-green-500 mr-1" />
                        Online
                      </Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => openChatWithParticipant(participant.id)}
                        className="h-8 w-8 p-0"
                        title="ჩატის დაწყება"
                      >
                        <MessageSquare className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>

        {/* Settings Dialog */}
        <Dialog open={showSettings} onOpenChange={setShowSettings}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-primary" />
                პარამეტრები
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <h3 className="mb-3 font-medium flex items-center gap-2">
                  <Mic className="h-4 w-4 text-muted-foreground" />
                  აუდიო
                </h3>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start hover:bg-muted">
                    მიკროფონი: ნაგულისხმევი
                  </Button>
                </div>
              </div>
              <div>
                <h3 className="mb-3 font-medium flex items-center gap-2">
                  <Video className="h-4 w-4 text-muted-foreground" />
                  ვიდეო
                </h3>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start hover:bg-muted">
                    კამერა: ნაგულისხმევი
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
        </Card>
      </div>

      {/* Chat Windows */}
      {chatWindows.filter(w => w.isOpen).map((chatWindow, index) => {
        const participant = participants.find(p => p.id === chatWindow.participantId);
        return (
          <Card 
            key={chatWindow.participantId}
            className="fixed bottom-6 z-50 w-80 h-96 flex flex-col border-2 border-primary/20 shadow-2xl"
            style={{ right: `${650 + (index * 330)}px` }}
          >
            {/* Chat Header */}
            <div className="flex items-center justify-between border-b bg-card px-4 py-3">
              <div className="flex items-center gap-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={participant?.avatar} />
                  <AvatarFallback>U</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-semibold text-sm">{participant?.name || 'მონაწილე'}</div>
                  <div className="text-xs text-muted-foreground">აქტიური</div>
                </div>
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => closeChatWindow(chatWindow.participantId)}
                className="h-6 w-6 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Chat Messages */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-3">
                {chatWindow.messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.sender_id === userId ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg px-3 py-2 ${
                        msg.sender_id === userId
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <p className="text-sm">{msg.content}</p>
                      <span className="text-xs opacity-70">
                        {new Date(msg.created_at).toLocaleTimeString('ka-GE', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            {/* Chat Input */}
            <div className="border-t p-3">
              <div className="flex gap-2">
                <Input
                  placeholder="შეტყობინება..."
                  value={chatWindow.newMessage}
                  onChange={(e) => 
                    setChatWindows(prev => prev.map(w => 
                      w.participantId === chatWindow.participantId 
                        ? { ...w, newMessage: e.target.value }
                        : w
                    ))
                  }
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      sendChatMessage(chatWindow.participantId);
                    }
                  }}
                  className="flex-1"
                />
                <Button
                  size="sm"
                  onClick={() => sendChatMessage(chatWindow.participantId)}
                  className="h-10 w-10 p-0"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        );
      })}
    </>
  );
}
