import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Plus, Edit, Trash2, Star, Globe, Phone, Mail, Building2, Scale, Check, X, Heart, Eye, Shield, Plane, Zap } from "lucide-react";

interface InsuranceCompany {
  id: string;
  company_name: string;
  company_type: string;
  logo_url: string | null;
  website: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  description: string | null;
  rating: number | null;
  health_coverage: boolean;
  dental_coverage: boolean;
  vision_coverage: boolean;
  life_insurance: boolean;
  accident_insurance: boolean;
  travel_insurance: boolean;
  min_monthly_premium: number;
  max_monthly_premium: number;
  group_discount_percent: number;
  min_contract_months: number;
  waiting_period_days: number;
  max_coverage_amount: number;
  copay_percent: number;
  partner_clinics_count: number;
  has_international_coverage: boolean;
  is_active: boolean;
  is_recommended: boolean;
  notes: string | null;
}

const defaultForm = {
  company_name: "",
  company_type: "health",
  website: "",
  phone: "",
  email: "",
  address: "",
  description: "",
  rating: 0,
  health_coverage: false,
  dental_coverage: false,
  vision_coverage: false,
  life_insurance: false,
  accident_insurance: false,
  travel_insurance: false,
  min_monthly_premium: 0,
  max_monthly_premium: 0,
  group_discount_percent: 0,
  min_contract_months: 12,
  waiting_period_days: 0,
  max_coverage_amount: 0,
  copay_percent: 0,
  partner_clinics_count: 0,
  has_international_coverage: false,
  is_active: true,
  is_recommended: false,
  notes: "",
};

export default function InsuranceCompaniesTab() {
  const [companies, setCompanies] = useState<InsuranceCompany[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCompany, setEditingCompany] = useState<InsuranceCompany | null>(null);
  const [formData, setFormData] = useState(defaultForm);
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [showCompare, setShowCompare] = useState(false);

  useEffect(() => {
    fetchCompanies();
  }, []);

  const fetchCompanies = async () => {
    const { data, error } = await supabase
      .from("insurance_companies")
      .select("*")
      .order("is_recommended", { ascending: false })
      .order("rating", { ascending: false, nullsFirst: false });

    if (error) {
      toast.error("შეცდომა კომპანიების ჩატვირთვისას");
    } else {
      setCompanies((data as unknown as InsuranceCompany[]) || []);
    }
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = { ...formData, rating: formData.rating || null };

    if (editingCompany) {
      const { error } = await supabase
        .from("insurance_companies")
        .update(payload as any)
        .eq("id", editingCompany.id);
      if (error) {
        toast.error("შეცდომა განახლებისას: " + error.message);
      } else {
        toast.success("კომპანია განახლდა");
        fetchCompanies();
        setIsDialogOpen(false);
      }
    } else {
      const { error } = await supabase
        .from("insurance_companies")
        .insert([payload] as any);
      if (error) {
        toast.error("შეცდომა დამატებისას: " + error.message);
      } else {
        toast.success("კომპანია დაემატა");
        fetchCompanies();
        setIsDialogOpen(false);
      }
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("დარწმუნებული ხართ?")) return;
    const { error } = await supabase.from("insurance_companies").delete().eq("id", id);
    if (error) toast.error("შეცდომა წაშლისას");
    else { toast.success("წაიშალა"); fetchCompanies(); }
  };

  const handleEdit = (c: InsuranceCompany) => {
    setEditingCompany(c);
    setFormData({
      company_name: c.company_name,
      company_type: c.company_type,
      website: c.website || "",
      phone: c.phone || "",
      email: c.email || "",
      address: c.address || "",
      description: c.description || "",
      rating: c.rating || 0,
      health_coverage: c.health_coverage,
      dental_coverage: c.dental_coverage,
      vision_coverage: c.vision_coverage,
      life_insurance: c.life_insurance,
      accident_insurance: c.accident_insurance,
      travel_insurance: c.travel_insurance,
      min_monthly_premium: c.min_monthly_premium,
      max_monthly_premium: c.max_monthly_premium,
      group_discount_percent: c.group_discount_percent,
      min_contract_months: c.min_contract_months,
      waiting_period_days: c.waiting_period_days,
      max_coverage_amount: c.max_coverage_amount,
      copay_percent: c.copay_percent,
      partner_clinics_count: c.partner_clinics_count,
      has_international_coverage: c.has_international_coverage,
      is_active: c.is_active,
      is_recommended: c.is_recommended,
      notes: c.notes || "",
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setEditingCompany(null);
    setFormData(defaultForm);
  };

  const toggleCompare = (id: string) => {
    setCompareIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : prev.length < 4 ? [...prev, id] : prev
    );
  };

  const comparedCompanies = companies.filter(c => compareIds.includes(c.id));

  const coverageIcons = [
    { key: "health_coverage", label: "ჯანდაცვა", icon: Heart },
    { key: "dental_coverage", label: "სტომატოლოგია", icon: Zap },
    { key: "vision_coverage", label: "მხედველობა", icon: Eye },
    { key: "life_insurance", label: "სიცოცხლე", icon: Shield },
    { key: "accident_insurance", label: "უბედურობა", icon: Shield },
    { key: "travel_insurance", label: "სამოგზაურო", icon: Plane },
  ] as const;

  const renderStars = (rating: number | null) => {
    if (!rating) return <span className="text-muted-foreground text-sm">არ არის</span>;
    return (
      <div className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map(i => (
          <Star key={i} className={`h-3.5 w-3.5 ${i <= rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/30"}`} />
        ))}
        <span className="ml-1 text-sm font-medium">{rating}</span>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <p className="text-muted-foreground text-sm">
            სადაზღვევო კომპანიების კატალოგი - შეადარეთ პირობები და აირჩიეთ საუკეთესო
          </p>
        </div>
        <div className="flex gap-2">
          {compareIds.length >= 2 && (
            <Button variant="outline" onClick={() => setShowCompare(!showCompare)}>
              <Scale className="mr-2 h-4 w-4" />
              შედარება ({compareIds.length})
            </Button>
          )}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm}>
                <Plus className="mr-2 h-4 w-4" />
                კომპანიის დამატება
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingCompany ? "კომპანიის რედაქტირება" : "ახალი სადაზღვევო კომპანია"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>კომპანიის სახელი *</Label>
                    <Input value={formData.company_name} onChange={e => setFormData({ ...formData, company_name: e.target.value })} required />
                  </div>
                  <div className="space-y-2">
                    <Label>რეიტინგი (0-5)</Label>
                    <Input type="number" min={0} max={5} step={0.1} value={formData.rating} onChange={e => setFormData({ ...formData, rating: Number(e.target.value) })} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>ვებსაიტი</Label>
                    <Input value={formData.website} onChange={e => setFormData({ ...formData, website: e.target.value })} placeholder="https://..." />
                  </div>
                  <div className="space-y-2">
                    <Label>ტელეფონი</Label>
                    <Input value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>ელ. ფოსტა</Label>
                    <Input type="email" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <Label>მისამართი</Label>
                    <Input value={formData.address} onChange={e => setFormData({ ...formData, address: e.target.value })} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>აღწერა</Label>
                  <Textarea value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} rows={2} />
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-semibold">დაფარვის ტიპები</Label>
                  <div className="grid grid-cols-3 gap-3">
                    {coverageIcons.map(({ key, label }) => (
                      <div key={key} className="flex items-center gap-2">
                        <Checkbox
                          checked={formData[key as keyof typeof formData] as boolean}
                          onCheckedChange={checked => setFormData({ ...formData, [key]: !!checked })}
                        />
                        <span className="text-sm">{label}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>მინ. თვიური პრემია (₾)</Label>
                    <Input type="number" value={formData.min_monthly_premium} onChange={e => setFormData({ ...formData, min_monthly_premium: Number(e.target.value) })} />
                  </div>
                  <div className="space-y-2">
                    <Label>მაქს. თვიური პრემია (₾)</Label>
                    <Input type="number" value={formData.max_monthly_premium} onChange={e => setFormData({ ...formData, max_monthly_premium: Number(e.target.value) })} />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>ჯგუფური ფასდაკლება (%)</Label>
                    <Input type="number" value={formData.group_discount_percent} onChange={e => setFormData({ ...formData, group_discount_percent: Number(e.target.value) })} />
                  </div>
                  <div className="space-y-2">
                    <Label>მინ. კონტრაქტი (თვე)</Label>
                    <Input type="number" value={formData.min_contract_months} onChange={e => setFormData({ ...formData, min_contract_months: Number(e.target.value) })} />
                  </div>
                  <div className="space-y-2">
                    <Label>ლოდინის პერიოდი (დღე)</Label>
                    <Input type="number" value={formData.waiting_period_days} onChange={e => setFormData({ ...formData, waiting_period_days: Number(e.target.value) })} />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>მაქს. დაფარვა (₾)</Label>
                    <Input type="number" value={formData.max_coverage_amount} onChange={e => setFormData({ ...formData, max_coverage_amount: Number(e.target.value) })} />
                  </div>
                  <div className="space-y-2">
                    <Label>თანაგადახდა (%)</Label>
                    <Input type="number" value={formData.copay_percent} onChange={e => setFormData({ ...formData, copay_percent: Number(e.target.value) })} />
                  </div>
                  <div className="space-y-2">
                    <Label>პარტნიორი კლინიკები</Label>
                    <Input type="number" value={formData.partner_clinics_count} onChange={e => setFormData({ ...formData, partner_clinics_count: Number(e.target.value) })} />
                  </div>
                </div>

                <div className="flex gap-6">
                  <div className="flex items-center gap-2">
                    <Switch checked={formData.has_international_coverage} onCheckedChange={checked => setFormData({ ...formData, has_international_coverage: checked })} />
                    <Label>საერთაშორისო დაფარვა</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch checked={formData.is_recommended} onCheckedChange={checked => setFormData({ ...formData, is_recommended: checked })} />
                    <Label>რეკომენდებული</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch checked={formData.is_active} onCheckedChange={checked => setFormData({ ...formData, is_active: checked })} />
                    <Label>აქტიური</Label>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>შენიშვნები</Label>
                  <Textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} rows={2} />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>გაუქმება</Button>
                  <Button type="submit">{editingCompany ? "განახლება" : "დამატება"}</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Comparison view */}
      {showCompare && comparedCompanies.length >= 2 && (
        <Card className="p-6 border-primary/20 bg-primary/5">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold text-lg">კომპანიების შედარება</h3>
            <Button variant="ghost" size="sm" onClick={() => { setShowCompare(false); setCompareIds([]); }}>
              <X className="h-4 w-4 mr-1" /> დახურვა
            </Button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 pr-4 font-medium text-muted-foreground">პარამეტრი</th>
                  {comparedCompanies.map(c => (
                    <th key={c.id} className="text-left py-2 px-3 font-semibold">{c.company_name}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y">
                <tr>
                  <td className="py-2 pr-4 text-muted-foreground">რეიტინგი</td>
                  {comparedCompanies.map(c => <td key={c.id} className="py-2 px-3">{renderStars(c.rating)}</td>)}
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-muted-foreground">თვიური პრემია</td>
                  {comparedCompanies.map(c => <td key={c.id} className="py-2 px-3">{c.min_monthly_premium}–{c.max_monthly_premium} ₾</td>)}
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-muted-foreground">მაქს. დაფარვა</td>
                  {comparedCompanies.map(c => <td key={c.id} className="py-2 px-3">{c.max_coverage_amount?.toLocaleString()} ₾</td>)}
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-muted-foreground">თანაგადახდა</td>
                  {comparedCompanies.map(c => <td key={c.id} className="py-2 px-3">{c.copay_percent}%</td>)}
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-muted-foreground">ჯგუფური ფასდაკლება</td>
                  {comparedCompanies.map(c => <td key={c.id} className="py-2 px-3">{c.group_discount_percent}%</td>)}
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-muted-foreground">მინ. კონტრაქტი</td>
                  {comparedCompanies.map(c => <td key={c.id} className="py-2 px-3">{c.min_contract_months} თვე</td>)}
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-muted-foreground">ლოდინის პერიოდი</td>
                  {comparedCompanies.map(c => <td key={c.id} className="py-2 px-3">{c.waiting_period_days} დღე</td>)}
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-muted-foreground">პარტნიორი კლინიკები</td>
                  {comparedCompanies.map(c => <td key={c.id} className="py-2 px-3">{c.partner_clinics_count}</td>)}
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-muted-foreground">საერთაშორისო</td>
                  {comparedCompanies.map(c => <td key={c.id} className="py-2 px-3">{c.has_international_coverage ? <Check className="h-4 w-4 text-green-500" /> : <X className="h-4 w-4 text-muted-foreground/40" />}</td>)}
                </tr>
                {coverageIcons.map(({ key, label }) => (
                  <tr key={key}>
                    <td className="py-2 pr-4 text-muted-foreground">{label}</td>
                    {comparedCompanies.map(c => (
                      <td key={c.id} className="py-2 px-3">
                        {(c as any)[key] ? <Check className="h-4 w-4 text-green-500" /> : <X className="h-4 w-4 text-muted-foreground/40" />}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Company cards */}
      {loading ? (
        <div className="text-center py-12 text-muted-foreground">იტვირთება...</div>
      ) : companies.length === 0 ? (
        <Card className="p-12 text-center">
          <Building2 className="mx-auto h-12 w-12 text-muted-foreground/40 mb-3" />
          <p className="text-muted-foreground">სადაზღვევო კომპანიები არ მოიძებნა</p>
          <p className="text-sm text-muted-foreground/60 mt-1">დაამატეთ პირველი კომპანია ზემოთ მოცემული ღილაკით</p>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {companies.map(company => (
            <Card key={company.id} className={`p-5 relative transition-all ${!company.is_active ? "opacity-60" : ""} ${compareIds.includes(company.id) ? "ring-2 ring-primary" : ""}`}>
              {company.is_recommended && (
                <Badge className="absolute top-3 right-3 bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
                  <Star className="h-3 w-3 mr-1 fill-current" /> რეკომენდებული
                </Badge>
              )}

              <div className="space-y-3">
                <div>
                  <h3 className="font-semibold text-lg">{company.company_name}</h3>
                  {renderStars(company.rating)}
                </div>

                {company.description && (
                  <p className="text-sm text-muted-foreground line-clamp-2">{company.description}</p>
                )}

                <div className="flex flex-wrap gap-1.5">
                  {coverageIcons.map(({ key, label, icon: Icon }) =>
                    (company as any)[key] ? (
                      <Badge key={key} variant="secondary" className="text-xs gap-1">
                        <Icon className="h-3 w-3" /> {label}
                      </Badge>
                    ) : null
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">პრემია:</span>
                    <p className="font-medium">{company.min_monthly_premium}–{company.max_monthly_premium} ₾/თვე</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">მაქს. დაფარვა:</span>
                    <p className="font-medium">{company.max_coverage_amount?.toLocaleString()} ₾</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">თანაგადახდა:</span>
                    <p className="font-medium">{company.copay_percent}%</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">კლინიკები:</span>
                    <p className="font-medium">{company.partner_clinics_count}</p>
                  </div>
                </div>

                {company.group_discount_percent > 0 && (
                  <Badge variant="outline" className="text-green-600 border-green-500/30">
                    ჯგუფური ფასდაკლება: {company.group_discount_percent}%
                  </Badge>
                )}

                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  {company.phone && <span className="flex items-center gap-1"><Phone className="h-3 w-3" />{company.phone}</span>}
                  {company.email && <span className="flex items-center gap-1"><Mail className="h-3 w-3" />{company.email}</span>}
                </div>

                <div className="flex justify-between items-center pt-2 border-t">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      checked={compareIds.includes(company.id)}
                      onCheckedChange={() => toggleCompare(company.id)}
                    />
                    <span className="text-xs text-muted-foreground">შედარება</span>
                  </div>
                  <div className="flex gap-1">
                    {company.website && (
                      <Button variant="ghost" size="sm" asChild>
                        <a href={company.website} target="_blank" rel="noopener noreferrer"><Globe className="h-4 w-4" /></a>
                      </Button>
                    )}
                    <Button variant="ghost" size="sm" onClick={() => handleEdit(company)}><Edit className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDelete(company.id)}><Trash2 className="h-4 w-4" /></Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
