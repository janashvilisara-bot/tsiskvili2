import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { 
  Users, Calendar, DollarSign, TrendingUp, 
  Clock, AlertCircle, CheckCircle, Building2,
  FileText, UserCheck, Briefcase, Shield
} from "lucide-react";
import { cn } from "@/lib/utils";
import { OvertimeWidget } from "./OvertimeWidget";

interface DashboardStats {
  totalEmployees?: number;
  activeEmployees?: number;
  pendingLeaveRequests?: number;
  todayAttendance?: number;
  monthlyPayroll?: number;
  departmentEmployees?: number;
  myPendingTasks?: number;
  myUpcomingLeaves?: number;
  myDocuments?: number;
}

export function RoleBasedWidgets() {
  const { userRole, user } = useAuth();
  const [stats, setStats] = useState<DashboardStats>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      setLoading(true);
      try {
        if (userRole === 'admin' || userRole === 'hr_manager') {
          await fetchAdminStats();
        } else if (userRole === 'department_manager') {
          await fetchManagerStats();
        } else {
          await fetchEmployeeStats();
        }
      } catch (error) {
        console.error('Error fetching stats:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, [userRole, user]);

  const fetchAdminStats = async () => {
    const today = new Date().toISOString().split('T')[0];

    const [employees, pendingLeaves, attendance] = await Promise.all([
      supabase.from('employees').select('id, status', { count: 'exact' }),
      supabase.from('leave_requests').select('id', { count: 'exact' }).eq('status', 'pending'),
      supabase.from('attendance').select('id', { count: 'exact' }).eq('date', today)
    ]);

    const activeCount = employees.data?.filter(e => e.status === 'active').length || 0;

    setStats({
      totalEmployees: employees.count || 0,
      activeEmployees: activeCount,
      pendingLeaveRequests: pendingLeaves.count || 0,
      todayAttendance: attendance.count || 0,
      monthlyPayroll: 0 // Placeholder for now
    });
  };

  const fetchManagerStats = async () => {
    const { data: empData } = await supabase
      .from('employees')
      .select('id, department')
      .eq('user_id', user?.id)
      .maybeSingle();

    if (!empData?.department) return;

    const today = new Date().toISOString().split('T')[0];

    const [deptEmployees, attendance] = await Promise.all([
      supabase.from('employees').select('id', { count: 'exact' }).eq('department', empData.department).eq('status', 'active'),
      supabase.from('attendance').select('id', { count: 'exact' }).eq('date', today)
    ]);

    // Get leave requests for department employees
    const { data: deptEmpIds } = await supabase
      .from('employees')
      .select('id')
      .eq('department', empData.department);
    
    const empIds = deptEmpIds?.map(e => e.id) || [];
    const { count: pendingCount } = await supabase
      .from('leave_requests')
      .select('id', { count: 'exact' })
      .eq('status', 'pending')
      .in('employee_id', empIds);

    setStats({
      departmentEmployees: deptEmployees.count || 0,
      pendingLeaveRequests: pendingCount || 0,
      todayAttendance: attendance.count || 0
    });
  };

  const fetchEmployeeStats = async () => {
    const { data: empData } = await supabase
      .from('employees')
      .select('id')
      .eq('user_id', user?.id)
      .maybeSingle();

    if (!empData) return;

    const [tasks, leaves, documents] = await Promise.all([
      supabase.from('tasks').select('id', { count: 'exact' }).eq('assigned_to', empData.id).eq('status', 'pending'),
      supabase.from('leave_requests').select('id', { count: 'exact' }).eq('employee_id', empData.id).gte('start_date', new Date().toISOString().split('T')[0]).eq('status', 'approved'),
      supabase.from('documents').select('id', { count: 'exact' }).eq('employee_id', empData.id)
    ]);

    setStats({
      myPendingTasks: tasks.count || 0,
      myUpcomingLeaves: leaves.count || 0,
      myDocuments: documents.count || 0
    });
  };

  if (loading) {
    return (
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-20 bg-muted rounded" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  // Admin & HR Manager Widgets
  if (userRole === 'admin' || userRole === 'hr_manager') {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-semibold flex items-center gap-2">
          <Shield className="h-6 w-6 text-primary" />
          სისტემის სტატისტიკა
        </h2>
        
        <OvertimeWidget />
        
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="სულ თანამშრომელი"
            value={stats.totalEmployees || 0}
            subtitle={`${stats.activeEmployees || 0} აქტიური`}
            icon={Users}
            gradient="from-blue-500 to-blue-600"
            trend="+2.5%"
          />
          <StatCard
            title="დასწრება დღეს"
            value={stats.todayAttendance || 0}
            subtitle="დღევანდელი ჩანაწერი"
            icon={UserCheck}
            gradient="from-green-500 to-green-600"
            trend="+5.2%"
          />
          <StatCard
            title="მოლოდინში შვებულებები"
            value={stats.pendingLeaveRequests || 0}
            subtitle="საჭიროებს დამტკიცებას"
            icon={Calendar}
            gradient="from-orange-500 to-orange-600"
            alert={stats.pendingLeaveRequests! > 5}
          />
          <StatCard
            title="ხელფასის ბიუჯეტი"
            value={`₾${(stats.monthlyPayroll || 0).toLocaleString()}`}
            subtitle="მიმდინარე თვე"
            icon={DollarSign}
            gradient="from-emerald-500 to-emerald-600"
            trend="+3.1%"
          />
        </div>
      </div>
    );
  }

  // Department Manager Widgets
  if (userRole === 'department_manager') {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-semibold flex items-center gap-2">
          <Building2 className="h-6 w-6 text-primary" />
          დეპარტამენტის მეტრიკები
        </h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <StatCard
            title="დეპარტამენტის თანამშრომლები"
            value={stats.departmentEmployees || 0}
            subtitle="აქტიური თანამშრომლები"
            icon={Users}
            gradient="from-blue-500 to-blue-600"
          />
          <StatCard
            title="დასწრება დღეს"
            value={stats.todayAttendance || 0}
            subtitle="დღევანდელი ჩანაწერი"
            icon={Clock}
            gradient="from-green-500 to-green-600"
          />
          <StatCard
            title="შვებულების მოთხოვნები"
            value={stats.pendingLeaveRequests || 0}
            subtitle="საჭიროებს განხილვას"
            icon={Calendar}
            gradient="from-orange-500 to-orange-600"
            alert={stats.pendingLeaveRequests! > 3}
          />
        </div>
      </div>
    );
  }

  // Employee Widgets
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold flex items-center gap-2">
        <Briefcase className="h-6 w-6 text-primary" />
        ჩემი პირადი ინფორმაცია
      </h2>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <StatCard
          title="აქტიური დავალებები"
          value={stats.myPendingTasks || 0}
          subtitle="მოლოდინში"
          icon={CheckCircle}
          gradient="from-purple-500 to-purple-600"
          alert={stats.myPendingTasks! > 5}
        />
        <StatCard
          title="დაგეგმილი შვებულებები"
          value={stats.myUpcomingLeaves || 0}
          subtitle="მომავალი შვებულებები"
          icon={Calendar}
          gradient="from-blue-500 to-blue-600"
        />
        <StatCard
          title="ჩემი დოკუმენტები"
          value={stats.myDocuments || 0}
          subtitle="შენახული ფაილები"
          icon={FileText}
          gradient="from-cyan-500 to-cyan-600"
        />
      </div>
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: number | string;
  subtitle: string;
  icon: any;
  gradient: string;
  trend?: string;
  alert?: boolean;
}

function StatCard({ title, value, subtitle, icon: Icon, gradient, trend, alert }: StatCardProps) {
  return (
    <Card className={cn(
      "group relative overflow-hidden border-border/50 bg-card/95 backdrop-blur-sm",
      "transition-all duration-300 hover:shadow-xl hover:border-primary/30 hover:-translate-y-1",
      "animate-fade-in"
    )}>
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className={cn(
          "p-2 rounded-xl bg-gradient-to-br shadow-lg",
          "group-hover:scale-110 transition-transform duration-300",
          gradient
        )}>
          <Icon className="h-4 w-4 text-white" />
        </div>
      </CardHeader>
      
      <CardContent className="relative">
        <div className="flex flex-col space-y-1">
          <div className="flex items-baseline gap-2">
            <div className="text-3xl font-bold group-hover:scale-105 transition-transform duration-300 origin-left">
              {value}
            </div>
            {alert && (
              <AlertCircle className="h-5 w-5 text-orange-500 animate-pulse" />
            )}
            {trend && !alert && (
              <span className="text-sm font-medium text-green-500 flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />
                {trend}
              </span>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            {subtitle}
          </p>
        </div>
      </CardContent>
      
      <div className={cn(
        "absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r",
        gradient,
        "transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300"
      )} />
    </Card>
  );
}
