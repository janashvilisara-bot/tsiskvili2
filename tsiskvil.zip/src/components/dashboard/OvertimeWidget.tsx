import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { Clock, TrendingUp, TrendingDown, DollarSign } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useNavigate } from "react-router-dom";

interface OvertimeStats {
  totalHours: number;
  totalCost: number;
  employeeCount: number;
  previousMonthHours: number;
  trend: "up" | "down" | "same";
  trendPercentage: number;
}

export function OvertimeWidget() {
  const [stats, setStats] = useState<OvertimeStats | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchOvertimeStats();
  }, []);

  const fetchOvertimeStats = async () => {
    try {
      const now = new Date();
      const currentMonth = now.getMonth();
      const currentYear = now.getFullYear();
      
      const currentMonthStart = new Date(currentYear, currentMonth, 1);
      const currentMonthEnd = new Date(currentYear, currentMonth + 1, 0);
      
      const previousMonthStart = new Date(currentYear, currentMonth - 1, 1);
      const previousMonthEnd = new Date(currentYear, currentMonth, 0);

      // Current month overtime
      const { data: currentOvertimeData }: any = await supabase
        .from('overtime_requests' as any)
        .select(`
          *,
          employee:employees!inner(
            hourly_rate,
            salary
          )
        `)
        .eq('status', 'approved')
        .gte('date', currentMonthStart.toISOString().split('T')[0])
        .lte('date', currentMonthEnd.toISOString().split('T')[0]);

      // Previous month overtime
      const { data: previousOvertimeData }: any = await supabase
        .from('overtime_requests' as any)
        .select('hours')
        .eq('status', 'approved')
        .gte('date', previousMonthStart.toISOString().split('T')[0])
        .lte('date', previousMonthEnd.toISOString().split('T')[0]);

      const totalHours = currentOvertimeData?.reduce((sum: number, record: any) => sum + (record.hours || 0), 0) || 0;
      const previousMonthHours = previousOvertimeData?.reduce((sum: number, record: any) => sum + (record.hours || 0), 0) || 0;
      
      const totalCost = currentOvertimeData?.reduce((sum: number, record: any) => {
        const hourlyRate = record.employee?.hourly_rate || (record.employee?.salary ? record.employee.salary / 160 : 0);
        const overtimeRate = hourlyRate * 1.5;
        return sum + (record.hours || 0) * overtimeRate;
      }, 0) || 0;

      const uniqueEmployees = new Set(currentOvertimeData?.map((r: any) => r.employee_id)).size;

      let trend: "up" | "down" | "same" = "same";
      let trendPercentage = 0;

      if (previousMonthHours > 0) {
        const diff = totalHours - previousMonthHours;
        trendPercentage = Math.abs((diff / previousMonthHours) * 100);
        trend = diff > 0 ? "up" : diff < 0 ? "down" : "same";
      } else if (totalHours > 0) {
        trend = "up";
        trendPercentage = 100;
      }

      setStats({
        totalHours,
        totalCost,
        employeeCount: uniqueEmployees,
        previousMonthHours,
        trend,
        trendPercentage
      });
    } catch (error) {
      console.error('Error fetching overtime stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="col-span-full">
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-24 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!stats) return null;

  return (
    <Card 
      className="col-span-full hover:shadow-lg transition-all cursor-pointer border-l-4 border-l-primary"
      onClick={() => navigate('/overtime-reports')}
    >
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Clock className="w-5 h-5 text-primary" />
          ზეგანაკვეთური სამუშაო - მიმდინარე თვე
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">სულ საათები</p>
            <p className="text-2xl font-bold">{stats.totalHours.toFixed(1)}</p>
            <div className="flex items-center gap-1 text-xs">
              {stats.trend === "up" && (
                <>
                  <TrendingUp className="w-3 h-3 text-destructive" />
                  <span className="text-destructive">+{stats.trendPercentage.toFixed(1)}%</span>
                </>
              )}
              {stats.trend === "down" && (
                <>
                  <TrendingDown className="w-3 h-3 text-green-600" />
                  <span className="text-green-600">-{stats.trendPercentage.toFixed(1)}%</span>
                </>
              )}
              {stats.trend === "same" && (
                <span className="text-muted-foreground">უცვლელი</span>
              )}
            </div>
          </div>

          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">თანამშრომლები</p>
            <p className="text-2xl font-bold">{stats.employeeCount}</p>
            <p className="text-xs text-muted-foreground">აქტიური</p>
          </div>

          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">ფინანსური ხარჯი</p>
            <p className="text-2xl font-bold flex items-center gap-1">
              <DollarSign className="w-5 h-5" />
              {stats.totalCost.toFixed(2)}
            </p>
            <p className="text-xs text-muted-foreground">₾</p>
          </div>

          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">წინა თვე</p>
            <p className="text-2xl font-bold">{stats.previousMonthHours.toFixed(1)}</p>
            <p className="text-xs text-muted-foreground">საათი</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
