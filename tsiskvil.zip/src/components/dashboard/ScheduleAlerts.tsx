import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { validateEmployeeSchedules } from "@/lib/validateEmployeeSchedules";
import { AlertTriangle, Calendar } from "lucide-react";

export function ScheduleAlerts() {
  const [employeesWithoutSchedules, setEmployeesWithoutSchedules] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    checkSchedules();
  }, []);

  const checkSchedules = async () => {
    try {
      const result = await validateEmployeeSchedules();
      setEmployeesWithoutSchedules(result.employeesWithoutSchedules || []);
    } catch (error) {
      console.error('Error checking schedules:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading || employeesWithoutSchedules.length === 0) {
    return null;
  }

  return (
    <Card className="bg-card/95 backdrop-blur-sm border-border/50 border-orange-500/20">
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2 text-orange-600">
          <AlertTriangle className="h-5 w-5" />
          გრაფიკის გაფრთხილებები
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Alert variant="destructive" className="bg-orange-50 dark:bg-orange-950/20 border-orange-200 dark:border-orange-800">
          <Calendar className="h-4 w-4" />
          <AlertDescription className="text-sm">
            <strong>{employeesWithoutSchedules.length}</strong> თანამშრომელს არ აქვს აქტიური სამუშაო გრაფიკი
          </AlertDescription>
        </Alert>
        
        <div className="mt-4 space-y-2">
          <p className="text-sm text-muted-foreground">თანამშრომლები გრაფიკის გარეშე:</p>
          <div className="max-h-32 overflow-y-auto space-y-1">
            {employeesWithoutSchedules.slice(0, 5).map((emp) => (
              <div key={emp.id} className="text-xs p-2 bg-muted/50 rounded">
                {emp.full_name} - {emp.position}
              </div>
            ))}
            {employeesWithoutSchedules.length > 5 && (
              <p className="text-xs text-muted-foreground italic">
                და კიდევ {employeesWithoutSchedules.length - 5}...
              </p>
            )}
          </div>
        </div>

        <Button
          variant="outline"
          size="sm"
          className="w-full mt-4"
          onClick={() => navigate('/work-schedules')}
        >
          <Calendar className="h-4 w-4 mr-2" />
          გრაფიკების მართვა
        </Button>
      </CardContent>
    </Card>
  );
}
