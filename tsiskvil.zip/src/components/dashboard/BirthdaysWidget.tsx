import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { Cake } from "lucide-react";

interface Birthday {
  id: string;
  full_name: string;
  date_of_birth: string;
}

export function BirthdaysWidget() {
  const [birthdays, setBirthdays] = useState<Birthday[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUpcomingBirthdays();
  }, []);

  const fetchUpcomingBirthdays = async () => {
    try {
      const today = new Date();
      const currentMonth = today.getMonth() + 1;
      const currentDay = today.getDate();

      const { data, error } = await supabase
        .from('employees')
        .select('id, full_name, date_of_birth')
        .eq('status', 'active')
        .not('date_of_birth', 'is', null);

      if (error) throw error;

      // Filter birthdays for current week
      const upcomingBirthdays = (data || []).filter((emp) => {
        if (!emp.date_of_birth) return false;
        const birthDate = new Date(emp.date_of_birth);
        const birthMonth = birthDate.getMonth() + 1;
        const birthDay = birthDate.getDate();

        // Check if birthday is in current month
        if (birthMonth === currentMonth) {
          // Check if birthday is within next 7 days
          const daysUntilBirthday = birthDay - currentDay;
          return daysUntilBirthday >= 0 && daysUntilBirthday <= 7;
        }
        return false;
      });

      setBirthdays(upcomingBirthdays);
    } catch (error) {
      console.error('Error fetching birthdays:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="bg-card/95 backdrop-blur-sm border-border/50">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">დაბადების დღეები</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2].map((i) => (
              <div key={i} className="h-12 bg-muted/50 rounded animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card/95 backdrop-blur-sm border-border/50 hover:shadow-lg transition-all duration-300">
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Cake className="h-5 w-5 text-primary" />
          მომავალი დაბადების დღეები
        </CardTitle>
      </CardHeader>
      <CardContent>
        {birthdays.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            ამ კვირაში დაბადების დღეები არ არის
          </p>
        ) : (
          <div className="space-y-3">
            {birthdays.map((birthday) => {
              const birthDate = new Date(birthday.date_of_birth);
              const initials = birthday.full_name
                .split(' ')
                .map((n) => n[0])
                .join('')
                .toUpperCase();

              return (
                <div
                  key={birthday.id}
                  className="flex items-center gap-2 sm:gap-3 p-2 sm:p-3 rounded-lg hover:bg-muted/50 transition-colors touch-manipulation"
                >
                  <Avatar className="h-8 w-8 sm:h-10 sm:w-10 shrink-0">
                    <AvatarFallback className="bg-gradient-to-br from-pink-500 to-purple-600 text-white text-xs sm:text-sm">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-xs sm:text-sm truncate">{birthday.full_name}</p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground">
                      {birthDate.toLocaleDateString('ka-GE', { 
                        month: 'long', 
                        day: 'numeric' 
                      })}
                    </p>
                  </div>
                  <Cake className="h-4 w-4 sm:h-5 sm:w-5 text-pink-500 shrink-0" />
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
