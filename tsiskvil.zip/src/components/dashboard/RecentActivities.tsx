import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { formatDistanceToNow } from "date-fns";
import { ka } from "date-fns/locale";
import { Activity, Calendar, Clock, FileText, Users } from "lucide-react";

interface ActivityLog {
  id: string;
  action_type: string;
  resource_type: string;
  created_at: string;
  details?: any;
}

export function RecentActivities() {
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecentActivities();
  }, []);

  const fetchRecentActivities = async () => {
    try {
      const { data, error } = await supabase
        .from('audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) throw error;
      setActivities(data || []);
    } catch (error) {
      console.error('Error fetching activities:', error);
    } finally {
      setLoading(false);
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'employee':
        return Users;
      case 'leave_request':
        return Calendar;
      case 'attendance':
        return Clock;
      case 'document':
        return FileText;
      default:
        return Activity;
    }
  };

  const getActivityLabel = (type: string, action: string) => {
    const labels: Record<string, string> = {
      'create': 'შეიქმნა',
      'update': 'განახლდა',
      'delete': 'წაიშალა',
      'approve': 'დამტკიცდა',
      'reject': 'უარყო',
    };
    return labels[action] || action;
  };

  if (loading) {
    return (
      <Card className="bg-card/95 backdrop-blur-sm border-border/50">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">უახლესი აქტივობები</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-muted/50 rounded animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card/95 backdrop-blur-sm border-border/50 hover:shadow-lg transition-all duration-300">
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Activity className="h-5 w-5 text-primary" />
          უახლესი აქტივობები
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {activities.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              აქტივობები არ მოიძებნა
            </p>
          ) : (
            activities.map((activity) => {
              const Icon = getActivityIcon(activity.resource_type);
              return (
                <div
                  key={activity.id}
                  className="flex items-start gap-2 sm:gap-3 p-2 sm:p-3 rounded-lg hover:bg-muted/50 transition-colors touch-manipulation"
                >
                  <div className="p-1.5 sm:p-2 rounded-lg bg-primary/10 shrink-0">
                    <Icon className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                      <p className="text-xs sm:text-sm font-medium truncate">
                        {activity.resource_type}
                      </p>
                      <Badge variant="outline" className="text-[10px] sm:text-xs shrink-0">
                        {getActivityLabel(activity.resource_type, activity.action_type)}
                      </Badge>
                    </div>
                    <p className="text-[10px] sm:text-xs text-muted-foreground mt-0.5">
                      {formatDistanceToNow(new Date(activity.created_at), { 
                        addSuffix: true,
                        locale: ka 
                      })}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}
