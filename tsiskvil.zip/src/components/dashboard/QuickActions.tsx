import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  UserPlus, Calendar, FileText, Clock, 
  Briefcase, DollarSign, MessageSquare, Settings 
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export function QuickActions() {
  const navigate = useNavigate();
  const { userRole } = useAuth();

  const adminActions = [
    {
      icon: UserPlus,
      label: "დაამატე თანამშრომელი",
      path: "/employees",
      color: "from-blue-500 to-blue-600",
    },
    {
      icon: Calendar,
      label: "შექმენი შვებულება",
      path: "/leave-requests",
      color: "from-orange-500 to-orange-600",
    },
    {
      icon: FileText,
      label: "ატვირთე დოკუმენტი",
      path: "/documents",
      color: "from-cyan-500 to-cyan-600",
    },
    {
      icon: DollarSign,
      label: "ხელფასის გაანგარიშება",
      path: "/payroll",
      color: "from-emerald-500 to-emerald-600",
    },
  ];

  const employeeActions = [
    {
      icon: Clock,
      label: "დასწრების აღრიცხვა",
      path: "/attendance",
      color: "from-green-500 to-green-600",
    },
    {
      icon: Calendar,
      label: "შვებულების მოთხოვნა",
      path: "/leave-requests",
      color: "from-orange-500 to-orange-600",
    },
    {
      icon: MessageSquare,
      label: "ჩატი",
      path: "/chat",
      color: "from-purple-500 to-purple-600",
    },
    {
      icon: Settings,
      label: "პროფილი",
      path: "/employee-portal",
      color: "from-indigo-500 to-indigo-600",
    },
  ];

  const actions = userRole === 'admin' || userRole === 'hr_manager' 
    ? adminActions 
    : employeeActions;

  return (
    <Card className="bg-card border-border/70 hover:border-primary/30 transition-colors">
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
          სწრაფი ქმედებები
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-2 sm:gap-3">
          {actions.map((action, index) => (
            <Button
              key={index}
              variant="outline"
              className="h-auto flex-col gap-1.5 sm:gap-2 p-3 sm:p-4 border-border/70 hover:border-primary/50 hover:bg-transparent transition-colors touch-manipulation active:scale-95"
              onClick={() => navigate(action.path)}
            >
              <div className="p-2 sm:p-3 rounded-md bg-primary/10">
                <action.icon className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
              </div>
              <span className="text-[10px] sm:text-xs text-center leading-tight">{action.label}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
