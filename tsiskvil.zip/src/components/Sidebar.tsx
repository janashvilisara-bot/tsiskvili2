import { Link, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  Users, 
  Building2, 
  TrendingUp,
  Settings,
  LogOut,
  Calendar,
  Clock,
  Wallet,
  FileText,
  Bell,
  CalendarClock,
  BarChart3
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";

const navigation = [
  { name: "დაშბორდი", href: "/", icon: LayoutDashboard },
  { name: "თანამშრომლები", href: "/employees", icon: Users },
  { name: "CRM კონტაქტები", href: "/contacts", icon: Building2 },
  { name: "გარიგებები", href: "/deals", icon: TrendingUp },
  { name: "შვებულებები", href: "/leave-requests", icon: Calendar },
  { name: "დასწრება", href: "/attendance", icon: Clock },
  { name: "ხელფასები", href: "/payroll", icon: Wallet },
  { name: "დოკუმენტები", href: "/documents", icon: FileText },
  { name: "შეტყობინებები", href: "/notifications", icon: Bell },
  { name: "გრაფიკები", href: "/work-schedules", icon: CalendarClock },
  { name: "ანგარიშები", href: "/reports", icon: BarChart3 },
  { name: "ანალიტიკა", href: "/analytics", icon: BarChart3 },
  { name: "ორგანიზაცია", href: "/organizational-structure", icon: Building2 },
  { name: "პარამეტრები", href: "/settings", icon: Settings },
];

export default function Sidebar() {
  const location = useLocation();
  const { requestSignOut, user } = useAuth();

  return (
    <aside className="hidden">
      <div className="flex h-16 items-center border-b border-border px-6">
        <h1 className="bg-gradient-to-r from-primary to-accent bg-clip-text text-2xl font-bold text-transparent">
          HR & CRM Pro
        </h1>
      </div>
      {/* Sidebar menu deprecated in favor of TopNav */}
      <nav className="hidden p-4">
        {navigation.map((item) => null)}
      </nav>
      <div className="absolute bottom-0 left-0 right-0 border-t border-border p-4">
        <div className="mb-3 text-sm text-muted-foreground">
          {user?.email}
        </div>
        <Button
          onClick={() => requestSignOut()}
          variant="outline"
          className="w-full"
        >
          <LogOut className="mr-2 h-4 w-4" />
          გასვლა
        </Button>
      </div>
    </aside>
  );
}
