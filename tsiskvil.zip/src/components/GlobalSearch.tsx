import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { allSearchItems, searchItems, getCategories, SearchItem } from "@/lib/searchData";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { canRoleSeeUrl, routeLabel } from "@/lib/routeLabels";

interface GlobalSearchProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function GlobalSearch({ open, onOpenChange }: GlobalSearchProps) {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchItem[]>([]);

  const { userRole } = useAuth();
  const { language } = useLanguage();
  const en = language === "en";

  useEffect(() => {
    const base = query.trim() ? searchItems(query) : allSearchItems;
    setResults(base.filter(i => canRoleSeeUrl(userRole, i.url)));
  }, [query, userRole]);

  const handleSelect = useCallback((url: string) => {
    onOpenChange(false);
    setQuery("");
    navigate(url);
  }, [navigate, onOpenChange]);

  // Group results by category
  const groupedResults = results.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, SearchItem[]>);

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput 
        placeholder={en ? "Search features..." : "მოძებნე ფუნქციონალი..."} 
        value={query}
        onValueChange={setQuery}
      />
      <CommandList>
        <CommandEmpty>
          <div className="py-6 text-center">
            <p className="text-muted-foreground">{en ? "Nothing found" : "ვერაფერი მოიძებნა"}</p>
            <p className="text-xs text-muted-foreground mt-1">{en ? "Try another keyword" : "სცადე სხვა საძიებო სიტყვა"}</p>
          </div>
        </CommandEmpty>
        {Object.entries(groupedResults).map(([category, items]) => (
          <CommandGroup key={category} heading={category}>
            {items.map((item) => {
              const Icon = item.icon;
              return (
                <CommandItem
                  key={item.url}
                  value={`${item.name} ${item.description} ${item.keywords?.join(' ') || ''}`}
                  onSelect={() => handleSelect(item.url)}
                  className="flex items-center gap-3 py-3 cursor-pointer"
                >
                  <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary/10">
                    <Icon className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{routeLabel(item.url, en ? "en" : "ka") || item.name}</span>
                    </div>
                    <p className="text-xs text-muted-foreground truncate">
                      {item.description}
                    </p>
                  </div>
                  <Badge variant="outline" className="text-[10px] shrink-0">
                    {item.category}
                  </Badge>
                </CommandItem>
              );
            })}
          </CommandGroup>
        ))}
      </CommandList>
    </CommandDialog>
  );
}
