import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Globe, ExternalLink, Copy, Check, Send, Clock,
  CheckCircle2, AlertCircle, Pencil, RotateCcw,
} from "lucide-react";

interface JobBoard {
  id: string;
  name: string;
  url: string;
  submitUrl: string;
  logo: string;
  color: string;
  supportsAutoPost: boolean;
  description: string;
}

const JOB_BOARDS: JobBoard[] = [
  {
    id: "samushao",
    name: "Samushao.ge",
    url: "https://samushao.ge",
    submitUrl: "https://samushao.ge/add-new-job",
    logo: "💼",
    color: "bg-blue-500/10 text-blue-600 border-blue-500/20",
    supportsAutoPost: false,
    description: "ქართული სამუშაოს პორტალი - უფასო განცხადებები",
  },
  {
    id: "jobs_ge",
    name: "Jobs.ge",
    url: "https://jobs.ge",
    submitUrl: "https://jobs.ge/ge/?page=2&id=0",
    logo: "🏢",
    color: "bg-green-500/10 text-green-600 border-green-500/20",
    supportsAutoPost: false,
    description: "საქართველოს ყველაზე პოპულარული სამუშაოს საიტი",
  },
  {
    id: "hr_ge",
    name: "HR.ge",
    url: "https://hr.ge",
    submitUrl: "https://hr.ge/vacancy/add",
    logo: "👥",
    color: "bg-purple-500/10 text-purple-600 border-purple-500/20",
    supportsAutoPost: false,
    description: "HR პროფესიონალების პლატფორმა",
  },
  {
    id: "myjobs_ge",
    name: "MyJobs.ge",
    url: "https://myjobs.ge",
    submitUrl: "https://myjobs.ge/ka/announcements/add",
    logo: "🎯",
    color: "bg-orange-500/10 text-orange-600 border-orange-500/20",
    supportsAutoPost: false,
    description: "თანამედროვე სამუშაოს პორტალი",
  },
];

interface Vacancy {
  id: string;
  title: string;
  description?: string;
  requirements?: string;
  location?: string;
  salary_min?: number;
  salary_max?: number;
  employment_type?: string;
  experience_level?: string;
  department?: { name: string };
  position?: { title: string };
}

interface Posting {
  id: string;
  board_name: string;
  status: string;
  posted_at: string | null;
  external_url: string | null;
  notes: string | null;
}

interface JobBoardPublisherProps {
  vacancy: Vacancy | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function JobBoardPublisher({ vacancy, open, onOpenChange }: JobBoardPublisherProps) {
  const [postings, setPostings] = useState<Posting[]>([]);
  const [selectedBoards, setSelectedBoards] = useState<string[]>([]);
  const [copiedText, setCopiedText] = useState(false);
  const [activeTab, setActiveTab] = useState("publish");
  const [externalUrls, setExternalUrls] = useState<Record<string, string>>({});

  useEffect(() => {
    if (vacancy && open) {
      fetchPostings();
      setSelectedBoards([]);
      setCopiedText(false);
    }
  }, [vacancy, open]);

  const fetchPostings = async () => {
    if (!vacancy) return;
    const { data } = await supabase
      .from("job_board_postings" as any)
      .select("*")
      .eq("vacancy_id", vacancy.id)
      .order("created_at", { ascending: false });
    setPostings((data as any) || []);
  };

  const generateVacancyText = () => {
    if (!vacancy) return "";
    const lines: string[] = [];
    lines.push(`📌 ${vacancy.title}`);
    if (vacancy.department?.name) lines.push(`🏢 დეპარტამენტი: ${vacancy.department.name}`);
    if (vacancy.location) lines.push(`📍 ლოკაცია: ${vacancy.location}`);
    if (vacancy.employment_type) {
      const types: Record<string, string> = {
        full_time: "სრული განაკვეთი",
        part_time: "ნახევარი განაკვეთი",
        contract: "კონტრაქტი",
        internship: "სტაჟირება",
      };
      lines.push(`⏰ ტიპი: ${types[vacancy.employment_type] || vacancy.employment_type}`);
    }
    if (vacancy.salary_min || vacancy.salary_max) {
      const salary = vacancy.salary_min && vacancy.salary_max
        ? `${vacancy.salary_min} - ${vacancy.salary_max} ₾`
        : vacancy.salary_min ? `${vacancy.salary_min}₾-დან` : `${vacancy.salary_max}₾-მდე`;
      lines.push(`💰 ხელფასი: ${salary}`);
    }
    if (vacancy.experience_level) {
      const levels: Record<string, string> = {
        junior: "ჯუნიორი",
        mid: "საშუალო",
        senior: "სენიორი",
        lead: "ლიდი",
      };
      lines.push(`📊 გამოცდილება: ${levels[vacancy.experience_level] || vacancy.experience_level}`);
    }
    if (vacancy.description) {
      lines.push("");
      lines.push("📝 აღწერა:");
      lines.push(vacancy.description);
    }
    if (vacancy.requirements) {
      lines.push("");
      lines.push("✅ მოთხოვნები:");
      lines.push(vacancy.requirements);
    }
    lines.push("");
    lines.push(`🔗 აპლიკაცია: ${window.location.origin}/job-applications?vacancy=${vacancy.id}`);
    return lines.join("\n");
  };

  const copyVacancyText = async () => {
    try {
      await navigator.clipboard.writeText(generateVacancyText());
      setCopiedText(true);
      toast.success("ტექსტი დაკოპირდა");
      setTimeout(() => setCopiedText(false), 2000);
    } catch {
      toast.error("კოპირება ვერ მოხერხდა");
    }
  };

  const openBoardAndTrack = async (board: JobBoard) => {
    if (!vacancy) return;

    // Check if already posted
    const existing = postings.find((p) => p.board_name === board.id);
    if (existing && existing.status === "posted") {
      toast.info(`ვაკანსია უკვე გამოქვეყნებულია ${board.name}-ზე`);
      return;
    }

    // Copy text to clipboard first
    await navigator.clipboard.writeText(generateVacancyText());
    toast.success("ტექსტი დაკოპირდა - ჩასვით პლატფორმის ფორმაში");

    // Track as "in_progress"
    if (!existing) {
      await supabase.from("job_board_postings" as any).insert({
        vacancy_id: vacancy.id,
        board_name: board.id,
        board_url: board.submitUrl,
        status: "in_progress",
        created_by: (await supabase.auth.getUser()).data.user?.id,
      });
    } else {
      await supabase
        .from("job_board_postings" as any)
        .update({ status: "in_progress", updated_at: new Date().toISOString() })
        .eq("id", existing.id);
    }

    // Open board in new tab
    window.open(board.submitUrl, "_blank");
    fetchPostings();
  };

  const markAsPosted = async (boardId: string) => {
    const existing = postings.find((p) => p.board_name === boardId);
    if (!existing || !vacancy) return;

    const externalUrl = externalUrls[boardId] || null;
    await supabase
      .from("job_board_postings" as any)
      .update({
        status: "posted",
        posted_at: new Date().toISOString(),
        external_url: externalUrl,
        updated_at: new Date().toISOString(),
      })
      .eq("id", existing.id);

    toast.success("მონიშნულია როგორც გამოქვეყნებული");
    fetchPostings();
  };

  const publishToSelected = async () => {
    if (selectedBoards.length === 0) {
      toast.error("აირჩიეთ მინიმუმ ერთი პლატფორმა");
      return;
    }

    await navigator.clipboard.writeText(generateVacancyText());
    toast.success("ტექსტი დაკოპირდა");

    for (const boardId of selectedBoards) {
      const board = JOB_BOARDS.find((b) => b.id === boardId);
      if (!board) continue;

      const existing = postings.find((p) => p.board_name === boardId);
      if (!existing) {
        await supabase.from("job_board_postings" as any).insert({
          vacancy_id: vacancy!.id,
          board_name: boardId,
          board_url: board.submitUrl,
          status: "in_progress",
          created_by: (await supabase.auth.getUser()).data.user?.id,
        });
      }

      window.open(board.submitUrl, "_blank");
      // Small delay between tabs
      await new Promise((r) => setTimeout(r, 300));
    }

    fetchPostings();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "posted":
        return <Badge className="bg-green-500/10 text-green-600 border-green-500/20"><CheckCircle2 className="h-3 w-3 mr-1" />გამოქვეყნებული</Badge>;
      case "in_progress":
        return <Badge className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20"><Clock className="h-3 w-3 mr-1" />მიმდინარე</Badge>;
      default:
        return <Badge variant="outline"><AlertCircle className="h-3 w-3 mr-1" />დრაფტი</Badge>;
    }
  };

  if (!vacancy) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-primary" />
            ვაკანსიის გამოქვეყნება Job Board-ებზე
          </DialogTitle>
        </DialogHeader>

        <div className="mb-4">
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-4">
              <h3 className="font-semibold text-lg">{vacancy.title}</h3>
              <div className="flex gap-2 mt-1 flex-wrap">
                {vacancy.department?.name && (
                  <Badge variant="outline">{vacancy.department.name}</Badge>
                )}
                {vacancy.location && (
                  <Badge variant="outline">📍 {vacancy.location}</Badge>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="publish">
              <Send className="h-4 w-4 mr-2" />
              გამოქვეყნება
            </TabsTrigger>
            <TabsTrigger value="text">
              <Pencil className="h-4 w-4 mr-2" />
              ტექსტი
            </TabsTrigger>
            <TabsTrigger value="history">
              <RotateCcw className="h-4 w-4 mr-2" />
              ისტორია ({postings.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="publish" className="space-y-3 mt-4">
            <p className="text-sm text-muted-foreground">
              აირჩიეთ პლატფორმები და დააჭირეთ „გამოქვეყნება" - ტექსტი ავტომატურად დაკოპირდება და გაიხსნება თითოეული საიტის ფორმა.
            </p>

            <div className="grid gap-3">
              {JOB_BOARDS.map((board) => {
                const posting = postings.find((p) => p.board_name === board.id);
                const isPosted = posting?.status === "posted";
                const isSelected = selectedBoards.includes(board.id);

                return (
                  <Card
                    key={board.id}
                    className={`cursor-pointer transition-all ${
                      isSelected ? "ring-2 ring-primary border-primary" : "hover:border-primary/50"
                    } ${isPosted ? "opacity-70" : ""}`}
                    onClick={() => {
                      if (isPosted) return;
                      setSelectedBoards((prev) =>
                        prev.includes(board.id)
                          ? prev.filter((id) => id !== board.id)
                          : [...prev, board.id]
                      );
                    }}
                  >
                    <CardContent className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl ${board.color}`}>
                          {board.logo}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold">{board.name}</h4>
                            {posting && getStatusBadge(posting.status)}
                          </div>
                          <p className="text-xs text-muted-foreground">{board.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {posting?.status === "in_progress" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              markAsPosted(board.id);
                            }}
                          >
                            <CheckCircle2 className="h-3 w-3 mr-1" />
                            მონიშნე
                          </Button>
                        )}
                        {!isPosted && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              openBoardAndTrack(board);
                            }}
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        )}
                        {isPosted && posting?.external_url && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              window.open(posting.external_url!, "_blank");
                            }}
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                დახურვა
              </Button>
              <Button
                onClick={publishToSelected}
                disabled={selectedBoards.length === 0}
              >
                <Send className="h-4 w-4 mr-2" />
                გამოქვეყნება ({selectedBoards.length} პლატფორმა)
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="text" className="space-y-3 mt-4">
            <div className="flex items-center justify-between">
              <Label>ავტომატურად გენერირებული ტექსტი</Label>
              <Button size="sm" variant="outline" onClick={copyVacancyText}>
                {copiedText ? (
                  <><Check className="h-4 w-4 mr-1 text-green-600" />დაკოპირდა</>
                ) : (
                  <><Copy className="h-4 w-4 mr-1" />კოპირება</>
                )}
              </Button>
            </div>
            <Textarea
              value={generateVacancyText()}
              readOnly
              className="min-h-[300px] font-mono text-sm"
            />
          </TabsContent>

          <TabsContent value="history" className="space-y-3 mt-4">
            {postings.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Globe className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>ჯერ არცერთ პლატფორმაზე არ გამოქვეყნებულა</p>
              </div>
            ) : (
              <div className="space-y-3">
                {postings.map((posting) => {
                  const board = JOB_BOARDS.find((b) => b.id === posting.board_name);
                  return (
                    <Card key={posting.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-lg ${board?.color || ""}`}>
                              {board?.logo || "📋"}
                            </div>
                            <div>
                              <h4 className="font-medium">{board?.name || posting.board_name}</h4>
                              {posting.posted_at && (
                                <p className="text-xs text-muted-foreground">
                                  გამოქვეყნდა: {new Date(posting.posted_at).toLocaleDateString("ka-GE")}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {getStatusBadge(posting.status)}
                            {posting.status === "in_progress" && (
                              <div className="flex items-center gap-1">
                                <Input
                                  placeholder="ლინკი..."
                                  className="w-40 h-8 text-xs"
                                  value={externalUrls[posting.board_name] || ""}
                                  onChange={(e) =>
                                    setExternalUrls((prev) => ({
                                      ...prev,
                                      [posting.board_name]: e.target.value,
                                    }))
                                  }
                                />
                                <Button
                                  size="sm"
                                  onClick={() => markAsPosted(posting.board_name)}
                                >
                                  <CheckCircle2 className="h-3 w-3" />
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
