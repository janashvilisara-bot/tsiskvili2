import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { RefreshCw, Plus, X, ExternalLink, Loader2 } from "lucide-react";

interface HerioJob {
  id: string;
  herio_job_id: string;
  title: string;
  description: string | null;
  location: string | null;
  pay_rate: number | null;
  status: string;
  job_type: string;
  start_date: string | null;
  end_date: string | null;
  last_synced_at: string;
}

interface HerioCandidate {
  id: string;
  herio_candidate_id: string;
  herio_job_id: string;
  full_name: string;
  phone: string | null;
  photo_url: string | null;
  status: string | null;
  applied_at: string | null;
  rating: number | null;
}

const statusVariants: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  active: { label: "აქტიური", variant: "default" },
  filled: { label: "შევსებული", variant: "secondary" },
  cancelled: { label: "გაუქმებული", variant: "destructive" },
  pending: { label: "მოლოდინში", variant: "outline" },
};

export function HerioJobsTab() {
  const [jobs, setJobs] = useState<HerioJob[]>([]);
  const [candidates, setCandidates] = useState<HerioCandidate[]>([]);
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [pushing, setPushing] = useState(false);

  // Auto-open new-job dialog when ?new=1 is in URL
  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    if (params.get("new") === "1") {
      setDialogOpen(true);
      params.delete("new");
      const newSearch = params.toString();
      const newUrl = window.location.pathname + (newSearch ? `?${newSearch}` : "") + window.location.hash;
      window.history.replaceState({}, "", newUrl);
    }
  }, []);

  const [form, setForm] = useState({
    jobPossition: "",
    jobDescription: "",
    isRemote: false,
    city: "",
    street: "",
    workerCount: "1",
    hourlyRate: "",
    workerPay: "",
    currency: "GEL",
    unform: "Casual",
    experience: "Mid",
    projectLength: "Short",
    jobStartTime: "",
    jobEndTime: "",
    skills: "",
    languages: "",
  });

  const loadFromDb = async () => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }
    const [{ data: jobsData }, { data: candsData }] = await Promise.all([
      supabase.from("herio_jobs" as any).select("*").eq("user_id", user.id).order("created_at", { ascending: false }),
      supabase.from("herio_candidates" as any).select("*").eq("user_id", user.id).order("applied_at", { ascending: false, nullsFirst: false }),
    ]);
    setJobs((jobsData as any) ?? []);
    setCandidates((candsData as any) ?? []);
    setLoading(false);
  };

  const syncFromHerio = async () => {
    setSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke("herio-jobs-sync", {
        body: { action: "list" },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setJobs(data.jobs ?? []);
      setCandidates(data.candidates ?? []);
      const candMsg = data.candidates_total > 0
        ? `, ${data.candidates_total} კანდიდატი`
        : (data.candidates_endpoint ? "" : " (კანდიდატების API ვერ მოიძებნა)");
      toast.success(`სინქრონიზებულია ${data.jobs?.length ?? 0} ვაკანსია${candMsg}`);
    } catch (e: any) {
      toast.error(e.message ?? "სინქრონიზაცია ვერ მოხერხდა");
    } finally {
      setSyncing(false);
    }
  };

  const toIso = (v: string) => v ? new Date(v).toISOString() : "";

  // Duration in hours between start and end (0 if invalid)
  const durationHours = (() => {
    if (!form.jobStartTime || !form.jobEndTime) return 0;
    const s = new Date(form.jobStartTime).getTime();
    const e = new Date(form.jobEndTime).getTime();
    if (isNaN(s) || isNaN(e) || e <= s) return 0;
    return (e - s) / (1000 * 60 * 60);
  })();

  // Total pay calculation for regular (hourly) jobs: hours × rate × workers
  const totalPay = (() => {
    if (form.isRemote) return Number(form.workerPay || 0);
    const rate = Number(form.hourlyRate || 0);
    const workers = Number(form.workerCount || 1);
    if (!rate || !durationHours) return 0;
    return durationHours * rate * workers;
  })();

  // Street must contain a number (e.g. "ჭავჭავაძის გამზ. 12")
  const hasStreetNumber = /\d/.test(form.street);

  const handlePush = async () => {
    if (!form.jobPossition.trim()) { toast.error("პოზიცია სავალდებულოა"); return; }
    if (!form.jobStartTime || !form.jobEndTime) { toast.error("დაწყების და დასრულების დრო სავალდებულოა"); return; }
    if (durationHours <= 0) { toast.error("დასრულების დრო უნდა იყოს დაწყების დროზე გვიან"); return; }
    if (durationHours > 24) { toast.error("სამუშაოს ხანგრძლივობა არ უნდა აღემატებოდეს 24 საათს"); return; }
    if (!form.isRemote && (!form.city.trim() || !form.street.trim())) {
      toast.error("ქალაქი და ქუჩა სავალდებულოა"); return;
    }
    if (!form.isRemote && !hasStreetNumber) {
      toast.error("მისამართში აუცილებელია ქუჩის ნომერი (მაგ: ჭავჭავაძის გამზ. 12)"); return;
    }
    if (!form.isRemote && !form.hourlyRate) { toast.error("საათობრივი ანაზღაურება სავალდებულოა"); return; }
    if (form.isRemote && !form.workerPay) { toast.error("მთლიანი ანაზღაურება სავალდებულოა"); return; }

    setPushing(true);
    try {
      const skillsArr = form.skills.split(",").map(s => s.trim()).filter(Boolean);
      const langsArr = form.languages.split(",").map(s => s.trim()).filter(Boolean);
      if (skillsArr.length === 0) { toast.error("Skills სავალდებულოა (მძიმით გამოყავით)"); setPushing(false); return; }
      if (langsArr.length === 0) { toast.error("Languages სავალდებულოა (მძიმით გამოყავით)"); setPushing(false); return; }

      const job: Record<string, any> = {
        jobPossition: form.jobPossition,
        jobDescription: form.jobDescription || "",
        isRemote: form.isRemote,
        workerCount: Number(form.workerCount || 1),
        currency: form.currency,
        experience: form.experience,
        jobStartTime: toIso(form.jobStartTime),
        jobEndTime: toIso(form.jobEndTime),
        skills: skillsArr,
        languages: langsArr,
      };
      if (form.isRemote) {
        job.workerPay = Number(form.workerPay);
        job.projectLength = form.projectLength;
      } else {
        job.hourlyRate = Number(form.hourlyRate);
        job.city = form.city;
        job.street = form.street;
        job.unform = form.unform;
      }

      const { data, error } = await supabase.functions.invoke("herio-jobs-sync", {
        body: { action: "push", job },
      });
      // Supabase SDK swallows error body on non-2xx. Try to read it from context.
      if (error) {
        let detail = error.message ?? "Unknown error";
        try {
          const ctx: any = (error as any).context;
          if (ctx && typeof ctx.json === "function") {
            const body = await ctx.json();
            if (body?.error) detail = body.error;
          } else if (ctx && typeof ctx.text === "function") {
            const txt = await ctx.text();
            if (txt) detail = txt;
          }
        } catch { /* ignore */ }
        throw new Error(detail);
      }
      if (data?.error) throw new Error(data.error);
      toast.success("ვაკანსია გამოქვეყნდა Herio-ზე");
      setDialogOpen(false);
      setForm({
        jobPossition: "", jobDescription: "", isRemote: false,
        city: "", street: "", workerCount: "1",
        hourlyRate: "", workerPay: "", currency: "GEL",
        unform: "Casual", experience: "Mid", projectLength: "Short",
        jobStartTime: "", jobEndTime: "",
        skills: "", languages: "",
      });
      await syncFromHerio();
    } catch (e: any) {
      toast.error(e.message ?? "გამოქვეყნება ვერ მოხერხდა");
    } finally {
      setPushing(false);
    }
  };

  const handleCancel = async (herioJobId: string) => {
    if (!confirm("ნამდვილად გსურთ ვაკანსიის გაუქმება Herio-ზე?")) return;
    try {
      const { data, error } = await supabase.functions.invoke("herio-jobs-sync", {
        body: { action: "cancel", herio_job_id: herioJobId },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      toast.success("ვაკანსია გაუქმდა");
      await loadFromDb();
    } catch (e: any) {
      toast.error(e.message ?? "გაუქმება ვერ მოხერხდა");
    }
  };

  useEffect(() => { loadFromDb(); }, []);

  return (
    <Card>
      <CardHeader className="border-b bg-muted/20">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <CardTitle className="text-xl flex items-center gap-2">
              <ExternalLink className="h-5 w-5 text-primary" />
              Herio-ს ვაკანსიები
            </CardTitle>
            <CardDescription>
              Herio Business User პლატფორმაზე გამოქვეყნებული ვაკანსიები
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={syncFromHerio} disabled={syncing}>
              {syncing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
              სინქრონიზაცია
            </Button>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Herio-ზე გამოქვეყნება
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90dvh] overflow-hidden p-0">
                <DialogHeader className="px-6 pt-6">
                  <DialogTitle>ახალი ვაკანსია Herio-ზე</DialogTitle>
                </DialogHeader>
                <div className="overflow-y-auto px-6 pb-6 max-h-[calc(90dvh-5rem)]">
                  <div className="space-y-4 py-2 pr-1">
                    <div>
                      <Label>პოზიცია *</Label>
                      <Input
                        value={form.jobPossition}
                        onChange={(e) => setForm({ ...form, jobPossition: e.target.value })}
                        placeholder="მაგ: მიმტანი, კურიერი, ოფიციანტი"
                      />
                    </div>
                    <div>
                      <Label>აღწერა</Label>
                      <Textarea
                        value={form.jobDescription}
                        onChange={(e) => setForm({ ...form, jobDescription: e.target.value })}
                        rows={3}
                      />
                    </div>
                    <div className="flex items-center justify-between rounded-md border p-3">
                      <div>
                        <Label>დისტანციური ვაკანსია</Label>
                        <p className="text-xs text-muted-foreground">Remote job</p>
                      </div>
                      <Switch checked={form.isRemote} onCheckedChange={(v) => setForm({ ...form, isRemote: v })} />
                    </div>

                    {!form.isRemote && (
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>ქალაქი *</Label>
                          <Input
                            value={form.city}
                            onChange={(e) => setForm({ ...form, city: e.target.value })}
                            placeholder="თბილისი"
                          />
                        </div>
                        <div>
                          <Label>ქუჩა და ნომერი *</Label>
                          <Input
                            value={form.street}
                            onChange={(e) => setForm({ ...form, street: e.target.value })}
                            placeholder="ჭავჭავაძის გამზ. 12"
                            className={form.street && !hasStreetNumber ? "border-destructive" : ""}
                          />
                          {form.street && !hasStreetNumber && (
                            <p className="text-xs text-destructive mt-1">მისამართში აუცილებელია ნომერი</p>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label>დაწყების დრო *</Label>
                        <Input
                          type="datetime-local"
                          value={form.jobStartTime}
                          onChange={(e) => setForm({ ...form, jobStartTime: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label>დასრულების დრო *</Label>
                        <Input
                          type="datetime-local"
                          value={form.jobEndTime}
                          onChange={(e) => setForm({ ...form, jobEndTime: e.target.value })}
                        />
                      </div>
                    </div>
                    {durationHours > 0 && (
                      <p className={`text-xs ${durationHours > 24 ? "text-destructive font-medium" : "text-muted-foreground"}`}>
                        ხანგრძლივობა: {durationHours.toFixed(1)} სთ {durationHours > 24 && "- მაქს. 24 სთ!"}
                      </p>
                    )}

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label>თანამშრომელთა რაოდ.</Label>
                        <Input
                          type="number"
                          min="1"
                          value={form.workerCount}
                          onChange={(e) => setForm({ ...form, workerCount: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label>გამოცდილება</Label>
                        <Select value={form.experience} onValueChange={(v) => setForm({ ...form, experience: v })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Junior">Junior</SelectItem>
                            <SelectItem value="Mid">Mid</SelectItem>
                            <SelectItem value="Senior">Senior</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {form.isRemote ? (
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>მთლიანი ანაზღაურება *</Label>
                          <Input
                            type="number"
                            value={form.workerPay}
                            onChange={(e) => setForm({ ...form, workerPay: e.target.value })}
                            placeholder="500"
                          />
                        </div>
                        <div>
                          <Label>პროექტის ხანგრძლივობა</Label>
                          <Select value={form.projectLength} onValueChange={(v) => setForm({ ...form, projectLength: v })}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Short">მოკლე</SelectItem>
                              <SelectItem value="Medium">საშუალო</SelectItem>
                              <SelectItem value="Long">ხანგრძლივი</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>საათობრივი ანაზღ. *</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={form.hourlyRate}
                            onChange={(e) => setForm({ ...form, hourlyRate: e.target.value })}
                            placeholder="15"
                          />
                        </div>
                        <div>
                          <Label>ფორმა (Uniform)</Label>
                          <Select value={form.unform} onValueChange={(v) => setForm({ ...form, unform: v })}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Casual">Casual</SelectItem>
                              <SelectItem value="Formal">Formal</SelectItem>
                              <SelectItem value="Uniform">Uniform</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    )}

                    <div>
                      <Label>ვალუტა</Label>
                      <Select value={form.currency} onValueChange={(v) => setForm({ ...form, currency: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="GEL">₾ GEL</SelectItem>
                          <SelectItem value="USD">$ USD</SelectItem>
                          <SelectItem value="EUR">€ EUR</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {totalPay > 0 && (
                      <div className="rounded-md border bg-muted/30 p-3 flex items-center justify-between">
                        <div className="text-sm">
                          <p className="font-medium">ჯამური თანხა</p>
                          {!form.isRemote && (
                            <p className="text-xs text-muted-foreground">
                              {durationHours.toFixed(1)} სთ × {form.hourlyRate} × {form.workerCount} თან.
                            </p>
                          )}
                        </div>
                        <p className="text-lg font-bold text-primary">
                          {totalPay.toFixed(2)} {form.currency}
                        </p>
                      </div>
                    )}

                    <div>
                      <Label>Skills * <span className="text-xs text-muted-foreground">(მძიმით გამოყავით)</span></Label>
                      <Input
                        value={form.skills}
                        onChange={(e) => setForm({ ...form, skills: e.target.value })}
                        placeholder="Communication, Customer Service"
                      />
                    </div>
                    <div>
                      <Label>Languages * <span className="text-xs text-muted-foreground">(მძიმით გამოყავით)</span></Label>
                      <Input
                        value={form.languages}
                        onChange={(e) => setForm({ ...form, languages: e.target.value })}
                        placeholder="Georgian, English"
                      />
                    </div>

                    <Button onClick={handlePush} disabled={pushing} className="w-full">
                      {pushing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                      გამოქვეყნება Herio-ზე
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {loading ? (
          <div className="p-8 text-center text-muted-foreground">
            <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2" />
            იტვირთება...
          </div>
        ) : jobs.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">
            ვაკანსიები ჯერ არ გაქვთ. დააჭირეთ "სინქრონიზაცია" ან გამოაქვეყნეთ ახალი.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>სათაური</TableHead>
                <TableHead>ტიპი</TableHead>
                <TableHead>ლოკაცია</TableHead>
                <TableHead>ანაზღაურება</TableHead>
                <TableHead>სტატუსი</TableHead>
                <TableHead className="text-right">მოქმედებები</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {jobs.map((job) => {
                const status = statusVariants[job.status?.toLowerCase()] ?? { label: job.status, variant: "outline" as const };
                return (
                  <TableRow key={job.id}>
                    <TableCell className="font-medium">{job.title}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{job.job_type === "remote" ? "Remote" : "Regular"}</Badge>
                    </TableCell>
                    <TableCell>{job.location ?? "-"}</TableCell>
                    <TableCell>{job.pay_rate ? `₾${job.pay_rate}` : "-"}</TableCell>
                    <TableCell>
                      <Badge variant={status.variant}>{status.label}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {job.status?.toLowerCase() !== "cancelled" && (
                        <Button size="sm" variant="ghost" onClick={() => handleCancel(job.herio_job_id)}>
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </CardContent>

      {/* Candidates section */}
      <div className="border-t">
        <div className="px-6 py-4 bg-muted/10">
          <h3 className="font-semibold flex items-center gap-2">
            <ExternalLink className="h-4 w-4 text-primary" />
            Herio-ს კანდიდატები
          </h3>
          <p className="text-xs text-muted-foreground mt-1">
            {candidates.length > 0
              ? `სულ ${candidates.length} კანდიდატი - სინქრონიზდება ვაკანსიებთან ერთად`
              : "კანდიდატები ჯერ არ არის. დააჭირეთ „სინქრონიზაცია“."}
          </p>
        </div>
        {candidates.length > 0 && (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>სახელი</TableHead>
                <TableHead>ვაკანსია</TableHead>
                <TableHead>ტელეფონი</TableHead>
                <TableHead>სტატუსი</TableHead>
                <TableHead>რეიტინგი</TableHead>
                <TableHead>თარიღი</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {candidates.map((c) => {
                const job = jobs.find((j) => j.herio_job_id === c.herio_job_id);
                return (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {c.photo_url && (
                          <img src={c.photo_url} alt={c.full_name} className="h-7 w-7 rounded-full object-cover" />
                        )}
                        {c.full_name}
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{job?.title ?? c.herio_job_id}</TableCell>
                    <TableCell>{c.phone ?? "-"}</TableCell>
                    <TableCell><Badge variant="outline">{c.status ?? "-"}</Badge></TableCell>
                    <TableCell>{c.rating ? `★ ${c.rating}` : "-"}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {c.applied_at ? new Date(c.applied_at).toLocaleDateString("ka-GE") : "-"}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </div>
    </Card>
  );
}
