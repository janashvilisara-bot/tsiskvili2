import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Globe, ExternalLink, Copy, Check, Send, Clock,
  CheckCircle2, AlertCircle, Pencil, RotateCcw,
} from "lucide-react";

interface JobBoard {
  id: string;
  name: string;
  url: string;
  submitUrl: string;
  logo: string;
  color: string;
  description: string;
}

const JOB_BOARDS: JobBoard[] = [
  {
    id: "samushao",
    name: "Samushao.ge",
    url: "https://samushao.ge",
    submitUrl: "https://samushao.ge/add-new-job",
    logo: "💼",
    color: "bg-blue-500/10 text-blue-600 border-blue-500/20",
    description: "ქართული სამუშაოს პორტალი - უფასო განცხადებები",
  },
  {
    id: "jobs_ge",
    name: "Jobs.ge",
    url: "https://jobs.ge",
    submitUrl: "https://jobs.ge/ge/?page=2&id=0",
    logo: "🏢",
    color: "bg-green-500/10 text-green-600 border-green-500/20",
    description: "საქართველოს ყველაზე პოპულარული სამუშაოს საიტი",
  },
  {
    id: "hr_ge",
    name: "HR.ge",
    url: "https://hr.ge",
    submitUrl: "https://hr.ge/vacancy/add",
    logo: "👥",
    color: "bg-purple-500/10 text-purple-600 border-purple-500/20",
    description: "HR პროფესიონალების პლატფორმა",
  },
  {
    id: "myjobs_ge",
    name: "MyJobs.ge",
    url: "https://myjobs.ge",
    submitUrl: "https://myjobs.ge/ka/announcements/add",
    logo: "🎯",
    color: "bg-orange-500/10 text-orange-600 border-orange-500/20",
    description: "თანამედროვე სამუშაოს პორტალი",
  },
];

interface Vacancy {
  id: string;
  title: string;
  description?: string;
  requirements?: string;
  location?: string;
  salary_min?: number;
  salary_max?: number;
  employment_type?: string;
  experience_level?: string;
  department?: { name: string };
  position?: { title: string };
}

interface Posting {
  id: string;
  vacancy_id: string;
  board_name: string;
  status: string;
  posted_at: string | null;
  external_url: string | null;
}

interface JobBoardsTabProps {
  vacancies: Vacancy[];
}

export function JobBoardsTab({ vacancies }: JobBoardsTabProps) {
  const [postings, setPostings] = useState<Posting[]>([]);
  const [selectedVacancy, setSelectedVacancy] = useState<string>("");
  const [selectedBoards, setSelectedBoards] = useState<string[]>([]);
  const [copiedText, setCopiedText] = useState(false);
  const [externalUrls, setExternalUrls] = useState<Record<string, string>>({});

  useEffect(() => {
    fetchAllPostings();
  }, []);

  const fetchAllPostings = async () => {
    const { data } = await supabase
      .from("job_board_postings" as any)
      .select("*")
      .order("created_at", { ascending: false });
    setPostings((data as any) || []);
  };

  const getVacancy = (id: string) => vacancies.find((v) => v.id === id);

  const generateVacancyText = (vacancy: Vacancy) => {
    const lines: string[] = [];
    lines.push(`📌 ${vacancy.title}`);
    if (vacancy.department?.name) lines.push(`🏢 დეპარტამენტი: ${vacancy.department.name}`);
    if (vacancy.location) lines.push(`📍 ლოკაცია: ${vacancy.location}`);
    if (vacancy.employment_type) {
      const types: Record<string, string> = {
        full_time: "სრული განაკვეთი", part_time: "ნახევარი განაკვეთი",
        contract: "კონტრაქტი", internship: "სტაჟირება",
      };
      lines.push(`⏰ ტიპი: ${types[vacancy.employment_type] || vacancy.employment_type}`);
    }
    if (vacancy.salary_min || vacancy.salary_max) {
      const salary = vacancy.salary_min && vacancy.salary_max
        ? `${vacancy.salary_min} - ${vacancy.salary_max} ₾`
        : vacancy.salary_min ? `${vacancy.salary_min}₾-დან` : `${vacancy.salary_max}₾-მდე`;
      lines.push(`💰 ხელფასი: ${salary}`);
    }
    if (vacancy.description) { lines.push(""); lines.push("📝 აღწერა:"); lines.push(vacancy.description); }
    if (vacancy.requirements) { lines.push(""); lines.push("✅ მოთხოვნები:"); lines.push(vacancy.requirements); }
    lines.push("");
    lines.push(`🔗 აპლიკაცია: ${window.location.origin}/job-applications?vacancy=${vacancy.id}`);
    return lines.join("\n");
  };

  const publishToBoards = async () => {
    if (!selectedVacancy || selectedBoards.length === 0) {
      toast.error("აირჩიეთ ვაკანსია და პლატფორმა");
      return;
    }

    const vacancy = getVacancy(selectedVacancy);
    if (!vacancy) return;

    await navigator.clipboard.writeText(generateVacancyText(vacancy));
    toast.success("ტექსტი დაკოპირდა - ჩასვით პლატფორმის ფორმაში");

    const userId = (await supabase.auth.getUser()).data.user?.id;

    for (const boardId of selectedBoards) {
      const board = JOB_BOARDS.find((b) => b.id === boardId);
      if (!board) continue;

      const existing = postings.find((p) => p.board_name === boardId && p.vacancy_id === selectedVacancy);
      if (!existing) {
        await supabase.from("job_board_postings" as any).insert({
          vacancy_id: selectedVacancy,
          board_name: boardId,
          board_url: board.submitUrl,
          status: "in_progress",
          created_by: userId,
        });
      }

      window.open(board.submitUrl, "_blank");
      await new Promise((r) => setTimeout(r, 300));
    }

    fetchAllPostings();
    setSelectedBoards([]);
  };

  const markAsPosted = async (postingId: string, boardName: string) => {
    const externalUrl = externalUrls[boardName] || null;
    await supabase
      .from("job_board_postings" as any)
      .update({ status: "posted", posted_at: new Date().toISOString(), external_url: externalUrl })
      .eq("id", postingId);
    toast.success("მონიშნულია როგორც გამოქვეყნებული");
    fetchAllPostings();
  };

  const copyText = async (vacancyId: string) => {
    const vacancy = getVacancy(vacancyId);
    if (!vacancy) return;
    await navigator.clipboard.writeText(generateVacancyText(vacancy));
    setCopiedText(true);
    toast.success("ტექსტი დაკოპირდა");
    setTimeout(() => setCopiedText(false), 2000);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "posted":
        return <Badge className="bg-green-500/10 text-green-600 border-green-500/20"><CheckCircle2 className="h-3 w-3 mr-1" />გამოქვეყნებული</Badge>;
      case "in_progress":
        return <Badge className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20"><Clock className="h-3 w-3 mr-1" />მიმდინარე</Badge>;
      default:
        return <Badge variant="outline"><AlertCircle className="h-3 w-3 mr-1" />დრაფტი</Badge>;
    }
  };

  // Group postings by vacancy
  const postingsByVacancy = postings.reduce<Record<string, Posting[]>>((acc, p) => {
    if (!acc[p.vacancy_id]) acc[p.vacancy_id] = [];
    acc[p.vacancy_id].push(p);
    return acc;
  }, {});

  const activeVacancies = vacancies.filter((v) => (v as any).status === "open");

  return (
    <div className="space-y-6">
      {/* Publish Section */}
      <Card className="border-muted/50">
        <CardHeader className="border-b bg-muted/20">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-primary/10">
              <Globe className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-xl">გამოქვეყნება Job Board-ებზე</CardTitle>
              <CardDescription>აირჩიეთ ვაკანსია და პლატფორმები - ტექსტი ავტომატურად დაკოპირდება</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          {/* Vacancy Selector */}
          <div className="space-y-2">
            <Label className="font-semibold">ვაკანსია</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {activeVacancies.map((v) => {
                const isSelected = selectedVacancy === v.id;
                const boardCount = postings.filter((p) => p.vacancy_id === v.id && p.status === "posted").length;
                return (
                  <Card
                    key={v.id}
                    className={`cursor-pointer transition-all ${
                      isSelected ? "ring-2 ring-primary border-primary shadow-md" : "hover:border-primary/40"
                    }`}
                    onClick={() => setSelectedVacancy(v.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold text-sm">{v.title}</h4>
                          {v.department?.name && (
                            <p className="text-xs text-muted-foreground mt-0.5">{v.department.name}</p>
                          )}
                        </div>
                        {boardCount > 0 && (
                          <Badge variant="outline" className="text-xs">
                            {boardCount} საიტი
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
              {activeVacancies.length === 0 && (
                <p className="text-muted-foreground text-sm col-span-full py-4 text-center">ღია ვაკანსიები არ არის</p>
              )}
            </div>
          </div>

          {/* Board Selector */}
          {selectedVacancy && (
            <>
              <div className="space-y-2">
                <Label className="font-semibold">პლატფორმები</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {JOB_BOARDS.map((board) => {
                    const isPosted = postings.some(
                      (p) => p.vacancy_id === selectedVacancy && p.board_name === board.id && p.status === "posted"
                    );
                    const isSelected = selectedBoards.includes(board.id);

                    return (
                      <Card
                        key={board.id}
                        className={`cursor-pointer transition-all ${
                          isSelected ? "ring-2 ring-primary border-primary" : "hover:border-primary/40"
                        } ${isPosted ? "opacity-60" : ""}`}
                        onClick={() => {
                          if (isPosted) return;
                          setSelectedBoards((prev) =>
                            prev.includes(board.id) ? prev.filter((id) => id !== board.id) : [...prev, board.id]
                          );
                        }}
                      >
                        <CardContent className="p-4 flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl ${board.color}`}>
                            {board.logo}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <h4 className="font-semibold text-sm">{board.name}</h4>
                              {isPosted && (
                                <Badge className="bg-green-500/10 text-green-600 border-green-500/20 text-[10px]">
                                  <CheckCircle2 className="h-2.5 w-2.5 mr-0.5" />გამოქვეყნებული
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground">{board.description}</p>
                          </div>
                          {!isPosted && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={(e) => {
                                e.stopPropagation();
                                window.open(board.submitUrl, "_blank");
                              }}
                            >
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-3 pt-2">
                <Button onClick={publishToBoards} disabled={selectedBoards.length === 0}>
                  <Send className="h-4 w-4 mr-2" />
                  გამოქვეყნება ({selectedBoards.length} პლატფორმა)
                </Button>
                <Button variant="outline" onClick={() => copyText(selectedVacancy)}>
                  {copiedText ? <><Check className="h-4 w-4 mr-1" />დაკოპირდა</> : <><Copy className="h-4 w-4 mr-1" />ტექსტის კოპირება</>}
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* History Section */}
      <Card className="border-muted/50">
        <CardHeader className="border-b bg-muted/20">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-accent/10">
              <RotateCcw className="h-5 w-5 text-accent-foreground" />
            </div>
            <div>
              <CardTitle className="text-xl">გამოქვეყნების ისტორია</CardTitle>
              <CardDescription>ყველა ვაკანსიის გამოქვეყნების სტატუსი</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {Object.keys(postingsByVacancy).length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Globe className="h-10 w-10 mx-auto mb-3 opacity-40" />
              <p className="font-medium">ჯერ არაფერი გამოქვეყნებულა</p>
              <p className="text-sm mt-1">აირჩიეთ ვაკანსია და პლატფორმა ზემოთ</p>
            </div>
          ) : (
            <div className="space-y-6">
              {Object.entries(postingsByVacancy).map(([vacancyId, vPostings]) => {
                const vacancy = getVacancy(vacancyId);
                return (
                  <div key={vacancyId} className="space-y-3">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{vacancy?.title || "უცნობი ვაკანსია"}</h3>
                      <Badge variant="outline">{vPostings.length} საიტი</Badge>
                    </div>
                    <div className="grid gap-2">
                      {vPostings.map((posting) => {
                        const board = JOB_BOARDS.find((b) => b.id === posting.board_name);
                        return (
                          <div
                            key={posting.id}
                            className="flex items-center justify-between p-3 rounded-lg border bg-card"
                          >
                            <div className="flex items-center gap-3">
                              <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-lg ${board?.color || ""}`}>
                                {board?.logo || "📋"}
                              </div>
                              <div>
                                <p className="font-medium text-sm">{board?.name || posting.board_name}</p>
                                {posting.posted_at && (
                                  <p className="text-xs text-muted-foreground">
                                    {new Date(posting.posted_at).toLocaleDateString("ka-GE")}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {getStatusBadge(posting.status)}
                              {posting.status === "in_progress" && (
                                <div className="flex items-center gap-1">
                                  <Input
                                    placeholder="ლინკი..."
                                    className="w-36 h-7 text-xs"
                                    value={externalUrls[posting.board_name] || ""}
                                    onChange={(e) =>
                                      setExternalUrls((prev) => ({ ...prev, [posting.board_name]: e.target.value }))
                                    }
                                  />
                                  <Button size="sm" className="h-7" onClick={() => markAsPosted(posting.id, posting.board_name)}>
                                    <CheckCircle2 className="h-3 w-3" />
                                  </Button>
                                </div>
                              )}
                              {posting.external_url && (
                                <Button size="sm" variant="ghost" onClick={() => window.open(posting.external_url!, "_blank")}>
                                  <ExternalLink className="h-3.5 w-3.5" />
                                </Button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
