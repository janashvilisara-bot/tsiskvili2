import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Send, CheckCircle2, AlertCircle, RefreshCw, ExternalLink, Globe2, Clock,
} from "lucide-react";

interface Vacancy {
  id: string;
  title: string;
  status: string;
  external_talentos_id?: string | null;
  talentos_sync_status?: string | null;
  talentos_synced_at?: string | null;
  talentos_sync_error?: string | null;
  department?: { name: string };
}

interface WebhookEvent {
  id: string;
  event_type: string;
  external_application_id: string | null;
  payload: any;
  signature_valid: boolean;
  processed: boolean;
  error_message: string | null;
  created_at: string;
}

export function TalentosJobsTab() {
  const [vacancies, setVacancies] = useState<Vacancy[]>([]);
  const [events, setEvents] = useState<WebhookEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [publishingId, setPublishingId] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    const [vRes, eRes] = await Promise.all([
      supabase
        .from("job_vacancies")
        .select("id, title, status, external_talentos_id, talentos_sync_status, talentos_synced_at, talentos_sync_error, department:departments(name)")
        .order("created_at", { ascending: false }),
      supabase
        .from("talentos_webhook_events" as any)
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20),
    ]);
    setVacancies((vRes.data as any) || []);
    setEvents((eRes.data as any) || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const publishToTalentos = async (vacancyId: string, recreate = false) => {
    setPublishingId(vacancyId);
    try {
      const { data, error } = await supabase.functions.invoke("talentos-jobs-publish", {
        body: { vacancy_id: vacancyId, action: recreate ? "recreate" : "publish" },
      });
      if (error) throw error;
      const result = data as any;
      if (!result?.success) {
        const hint = result?.hint ? `\n${result.hint}` : "";
        const errMsg = typeof result?.error === "string" ? result.error : JSON.stringify(result?.error ?? "Unknown error");
        throw new Error(`${errMsg}${hint}`);
      }
      toast.success(recreate ? "ვაკანსია თავიდან შეიქმნა jobs.talentos.ge-ზე" : "ვაკანსია წარმატებით გაიგზავნა jobs.talentos.ge-ზე");
      fetchData();
    } catch (e: any) {
      toast.error("გაგზავნა ვერ მოხერხდა", { description: e.message ?? String(e), duration: 8000 });
    } finally {
      setPublishingId(null);
    }
  };

  const getStatusBadge = (vacancy: Vacancy) => {
    if (vacancy.talentos_sync_status === "synced") {
      return (
        <Badge className="bg-green-500/10 text-green-600 border-green-500/20">
          <CheckCircle2 className="h-3 w-3 mr-1" />გამოქვეყნებული
        </Badge>
      );
    }
    if (vacancy.talentos_sync_status === "error") {
      return (
        <Badge variant="destructive">
          <AlertCircle className="h-3 w-3 mr-1" />შეცდომა
        </Badge>
      );
    }
    return <Badge variant="outline">არ გაგზავნილა</Badge>;
  };

  const webhookUrl = `https://kiurxtmqgcjhxjvvynab.supabase.co/functions/v1/talentos-jobs-webhook`;

  return (
    <div className="space-y-6">
      {/* Setup info */}
      <Card className="border-primary/30 bg-primary/5">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-primary/10">
              <Globe2 className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-xl">jobs.talentos.ge ინტეგრაცია</CardTitle>
              <CardDescription>
                გამოაქვეყნე ვაკანსია jobs.talentos.ge-ზე და მიიღე კანდიდატები ავტომატურად
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div>
            <p className="font-semibold mb-1">Webhook URL (გადაეცი jobs.talentos.ge-ს):</p>
            <code className="block p-2 rounded bg-muted text-xs break-all">{webhookUrl}</code>
          </div>
          <div className="text-muted-foreground">
            <p>1. დაუკავშირდი <a href="mailto:partners@talentos.ge" className="underline text-primary">partners@talentos.ge</a> და მიიღე <code className="text-xs bg-muted px-1 rounded">partner_slug</code> + <code className="text-xs bg-muted px-1 rounded">webhook_secret</code></p>
            <p>2. გადაეცი მათ ზემოთ მითითებული webhook URL</p>
            <p>3. ადმინისტრატორმა უნდა შეიყვანოს credentials-ები სისტემის secrets-ში</p>
          </div>
        </CardContent>
      </Card>

      {/* Vacancies list */}
      <Card>
        <CardHeader className="border-b bg-muted/20 flex flex-row items-center justify-between">
          <div>
            <CardTitle>ვაკანსიების გამოქვეყნება</CardTitle>
            <CardDescription>აირჩიე ვაკანსია გასაგზავნად</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={fetchData} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} />განახლება
          </Button>
        </CardHeader>
        <CardContent className="p-6 space-y-3">
          {vacancies.length === 0 && (
            <p className="text-center text-muted-foreground py-8">ვაკანსიები არ არის</p>
          )}
          {vacancies.map((v) => (
            <div key={v.id} className="flex items-center justify-between p-4 rounded-lg border bg-card">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="font-semibold">{v.title}</h4>
                  {getStatusBadge(v)}
                  {v.status !== "open" && <Badge variant="secondary">{v.status}</Badge>}
                </div>
                {v.department?.name && (
                  <p className="text-xs text-muted-foreground mt-1">{v.department.name}</p>
                )}
                {v.talentos_synced_at && (
                  <p className="text-xs text-muted-foreground mt-1">
                    ბოლო სინქი: {new Date(v.talentos_synced_at).toLocaleString("ka-GE")}
                  </p>
                )}
                {v.talentos_sync_error && (
                  <p className="text-xs text-destructive mt-1">{v.talentos_sync_error}</p>
                )}
              </div>
              <Button
                size="sm"
                onClick={() => publishToTalentos(v.id, v.talentos_sync_status === "synced")}
                disabled={publishingId === v.id || v.status !== "open"}
              >
                <Send className="h-4 w-4 mr-1" />
                {publishingId === v.id ? "იგზავნება..." : v.talentos_sync_status === "synced" ? "თავიდან შექმნა" : "გამოქვეყნება"}
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Webhook event log */}
      <Card>
        <CardHeader className="border-b bg-muted/20">
          <CardTitle>შემოსული შეტყობინებები</CardTitle>
          <CardDescription>jobs.talentos.ge-დან მიღებული webhook ივენთები</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          {events.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">ჯერ არცერთი შეტყობინება არ მიღებულა</p>
          ) : (
            <div className="space-y-2">
              {events.map((e) => (
                <div key={e.id} className="flex items-start justify-between p-3 rounded-lg border bg-card text-sm">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium">{e.event_type}</span>
                      {e.signature_valid ? (
                        <Badge className="bg-green-500/10 text-green-600 border-green-500/20 text-[10px]">verified</Badge>
                      ) : (
                        <Badge variant="destructive" className="text-[10px]">invalid signature</Badge>
                      )}
                      {e.processed ? (
                        <Badge variant="outline" className="text-[10px]">
                          <CheckCircle2 className="h-2.5 w-2.5 mr-0.5" />პროცესი
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-[10px]">
                          <Clock className="h-2.5 w-2.5 mr-0.5" />მოლოდინი
                        </Badge>
                      )}
                    </div>
                    {e.payload?.data?.candidate?.full_name && (
                      <p className="text-xs text-muted-foreground mt-1">
                        კანდიდატი: {e.payload.data.candidate.full_name}
                        {e.payload?.data?.to_status && ` → ${e.payload.data.to_status}`}
                      </p>
                    )}
                    {e.error_message && (
                      <p className="text-xs text-destructive mt-1">{e.error_message}</p>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(e.created_at).toLocaleString("ka-GE")}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
