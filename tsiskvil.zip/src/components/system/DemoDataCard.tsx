import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { FlaskConical, Loader2, Trash2 } from "lucide-react";

export function DemoDataCard() {
  const { userRole } = useAuth();
  const [loading, setLoading] = useState<"seed" | "clear" | null>(null);

  if (userRole !== "admin") return null;

  const run = async (action: "seed" | "clear") => {
    setLoading(action);
    try {
      const { data, error } = await supabase.rpc(
        action === "seed" ? "seed_demo_data" : "clear_demo_data",
      );
      if (error) throw error;
      const result = data as { created?: number; deleted?: number } | null;
      if (action === "seed") {
        toast.success(`სატესტო მონაცემები დაემატა (${result?.created ?? 0} თანამშრომელი)`);
      } else {
        toast.success(`სატესტო მონაცემები წაიშალა (${result?.deleted ?? 0} თანამშრომელი)`);
      }
    } catch {
      toast.error("ოპერაცია ვერ შესრულდა. გთხოვთ, სცადოთ ხელახლა.");
    } finally {
      setLoading(null);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <FlaskConical className="h-5 w-5 text-primary" /> სატესტო მონაცემები
        </CardTitle>
        <CardDescription>
          პრეზენტაციისთვის - 9 სატესტო თანამშრომელი დასწრებებითა და ხელფასებით. ერთი ღილაკით დაემატება და წაიშლება.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-wrap gap-3">
        <Button onClick={() => run("seed")} disabled={loading !== null}>
          {loading === "seed" ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <FlaskConical className="h-4 w-4 mr-2" />}
          სატესტო მონაცემების დამატება
        </Button>
        <Button variant="outline" onClick={() => run("clear")} disabled={loading !== null}>
          {loading === "clear" ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Trash2 className="h-4 w-4 mr-2" />}
          სატესტო მონაცემების წაშლა
        </Button>
      </CardContent>
    </Card>
  );
}
