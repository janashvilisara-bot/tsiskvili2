import { Palette, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { SKINS, useSkin } from "@/contexts/SkinContext";

export function SkinPicker() {
  const { skin, setSkin } = useSkin();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="relative overflow-hidden border-primary/20 hover:border-primary/40 transition-all duration-300 shadow-md hover:shadow-glow"
          aria-label="აირჩიე სკინი"
        >
          <Palette className="h-[1.2rem] w-[1.2rem] text-primary" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel>სკინი</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {SKINS.map((s) => (
          <DropdownMenuItem
            key={s.id}
            onClick={() => setSkin(s.id)}
            className="flex items-center gap-2 cursor-pointer"
          >
            <span
              className="h-4 w-4 rounded-full ring-1 ring-border shrink-0"
              style={{ background: s.swatch }}
            />
            <span className="flex-1">{s.label}</span>
            {skin === s.id && <Check className="h-4 w-4 text-primary" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
