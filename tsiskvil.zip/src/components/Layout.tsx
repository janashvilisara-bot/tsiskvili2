import { ReactNode, lazy, Suspense, useState, useEffect } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { DynamicBreadcrumb } from "./DynamicBreadcrumb";
import { DemoBanner } from "./DemoBanner";
import { ThemeToggle } from "./ThemeToggle";
import { SkinPicker } from "./SkinPicker";
import { BranchSwitcher } from "./BranchSwitcher";
import { GuidedTour } from "./demo/GuidedTour";
import { DemoFloatingButton } from "./demo/DemoFloatingButton";
import { useDemoMode } from "@/contexts/DemoContext";
import { useSessionTimeout } from "@/hooks/useSessionTimeout";
import { useIsMobile } from "@/hooks/use-mobile";
const ContextualHelp = lazy(() => import("./ContextualHelp"));

interface LayoutProps {
  children: ReactNode;
}

const SIDEBAR_STATE_KEY = "talentos-sidebar-open";

export default function Layout({ children }: LayoutProps) {
  const { isDemoMode } = useDemoMode();

  useSessionTimeout({
    timeoutMinutes: 30,
    warningMinutes: 5,
    enabled: !isDemoMode,
  });

  const [sidebarOpen, setSidebarOpen] = useState<boolean>(() => {
    if (typeof window === "undefined") return true;
    const stored = localStorage.getItem(SIDEBAR_STATE_KEY);
    return stored === null ? true : stored === "true";
  });
  const isMobile = useIsMobile();

  useEffect(() => {
    try {
      localStorage.setItem(SIDEBAR_STATE_KEY, String(sidebarOpen));
    } catch {}
  }, [sidebarOpen]);

  return (
    <SidebarProvider open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <div className="h-[100dvh] flex w-full bg-background overflow-hidden">
          <AppSidebar />
          <div className="flex-1 flex flex-col min-w-0 min-h-0">
          {/* Clean Top Bar */}
          <header className="shrink-0 border-b border-border/60 bg-card/80 backdrop-blur-xl z-10 pt-[env(safe-area-inset-top)]">
            <div className="h-14 flex items-center gap-2 px-3 sm:px-4">
              <SidebarTrigger className="text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-200 shrink-0" />
              <div className="ml-1 sm:ml-3 flex-1 min-w-0 overflow-hidden">
                <DynamicBreadcrumb />
              </div>
              <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                {!isMobile && <BranchSwitcher />}
                <div className="hidden sm:block"><SkinPicker /></div>
                <ThemeToggle />
              </div>
            </div>
            {isMobile && <div className="px-3 pb-2"><BranchSwitcher /></div>}
          </header>

          {/* Demo Banner */}
          {isDemoMode && <DemoBanner />}
          
          <main className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden px-3 sm:px-6 md:px-8 pt-4 pb-24 sm:py-8 max-w-screen-2xl mx-auto w-full animate-fade-in" style={{ WebkitOverflowScrolling: 'touch' }}>
            {children}
          </main>
        </div>

        {/* Demo Mode Components */}
        {isDemoMode && (
          <>
            <GuidedTour />
            <DemoFloatingButton />
          </>
        )}

        {/* Contextual Help */}
        <Suspense fallback={null}><ContextualHelp /></Suspense>
      </div>
    </SidebarProvider>
  );
}
