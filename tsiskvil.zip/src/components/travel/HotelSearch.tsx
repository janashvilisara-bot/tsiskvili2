import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Search, Star, Phone, Globe, MapPin, Plus, CalendarCheck, Loader2, BedDouble } from "lucide-react";

export interface HotelResult {
  id: string;
  name: string;
  stars: number | null;
  address: string | null;
  phone: string | null;
  website: string | null;
  lat: number | null;
  lon: number | null;
  rooms: number | null;
  source: string;
}

interface Vendor {
  id: string;
  name: string;
  city: string;
  corporate_rate: number | null;
  is_active: boolean;
}

interface Props {
  vendors: Vendor[];
  canManage: boolean;
  onBook: (prefill: {
    vendor_id?: string;
    vendor_name_manual?: string;
    city: string;
    check_in_date: string;
    check_out_date: string;
    nightly_rate?: string;
  }) => void;
  onVendorsChanged: () => void;
}

const sourceLabels: Record<string, string> = {
  hotel: "სასტუმრო",
  hostel: "ჰოსტელი",
  guest_house: "სასტუმრო სახლი",
  apartment: "აპარტამენტი",
};

export default function HotelSearch({ vendors, canManage, onBook, onVendorsChanged }: Props) {
  const [city, setCity] = useState("");
  const [radius, setRadius] = useState("5000");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [results, setResults] = useState<HotelResult[]>([]);
  const [occupancy, setOccupancy] = useState<Record<string, number>>({});
  const [addingId, setAddingId] = useState<string | null>(null);

  const norm = (s: string) => s.trim().toLowerCase();

  const matchVendor = (hotel: HotelResult) =>
    vendors.find((v) => norm(v.name) === norm(hotel.name)) || null;

  const loadOccupancy = async () => {
    if (!checkIn || !checkOut) {
      setOccupancy({});
      return;
    }
    const { data, error } = await supabase
      .from("travel_bookings")
      .select("vendor_id, vendor_name_manual, status, travel_vendors(name)")
      .lt("check_in_date", checkOut)
      .gt("check_out_date", checkIn)
      .in("status", ["requested", "confirmed", "checked_in"]);
    if (error) return;
    const map: Record<string, number> = {};
    (data || []).forEach((b: any) => {
      const name = b.travel_vendors?.name || b.vendor_name_manual;
      if (!name) return;
      const key = norm(name);
      map[key] = (map[key] || 0) + 1;
    });
    setOccupancy(map);
  };

  const search = async () => {
    if (city.trim().length < 2) {
      toast.error("მიუთითეთ ქალაქი");
      return;
    }
    if (checkIn && checkOut && new Date(checkOut) < new Date(checkIn)) {
      toast.error("გასვლის თარიღი არ შეიძლება იყოს შესვლამდე");
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("hotel-search", {
        body: { city, radius: Number(radius) },
      });
      if (error) throw error;
      if (data?.error) {
        toast.error(data.error);
        setResults([]);
      } else {
        setResults(data?.hotels || []);
        if (!data?.hotels?.length) toast.info("ამ ქალაქში სასტუმროები ვერ მოიძებნა");
      }
      await loadOccupancy();
      setSearched(true);
    } catch {
      toast.error("ძიება ვერ შესრულდა, სცადეთ მოგვიანებით");
    } finally {
      setLoading(false);
    }
  };

  const addToCatalog = async (hotel: HotelResult) => {
    setAddingId(hotel.id);
    try {
      const { error } = await supabase.from("travel_vendors").insert({
        name: hotel.name,
        vendor_type: "hotel",
        city: city.trim(),
        country: "Georgia",
        address: hotel.address,
        contact_phone: hotel.phone,
        rating: hotel.stars,
        notes: hotel.website ? `ვებგვერდი: ${hotel.website}` : null,
      });
      if (error) throw error;
      toast.success("კატალოგში დაემატა");
      onVendorsChanged();
    } catch {
      toast.error("დამატება ვერ მოხერხდა");
    } finally {
      setAddingId(null);
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4 grid grid-cols-1 md:grid-cols-5 gap-3 items-end">
          <div className="md:col-span-2">
            <Label htmlFor="hs-city">ქალაქი</Label>
            <Input
              id="hs-city"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && search()}
              placeholder="მაგ. ბათუმი, Tbilisi, Yerevan"
            />
          </div>
          <div>
            <Label htmlFor="hs-in">შესვლა</Label>
            <Input id="hs-in" type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="hs-out">გასვლა</Label>
            <Input id="hs-out" type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} />
          </div>
          <div className="flex gap-2">
            <div className="flex-1">
              <Label>რადიუსი</Label>
              <Select value={radius} onValueChange={setRadius}>
                <SelectTrigger aria-label="ძიების რადიუსი">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2000">2 კმ</SelectItem>
                  <SelectItem value="5000">5 კმ</SelectItem>
                  <SelectItem value="10000">10 კმ</SelectItem>
                  <SelectItem value="20000">20 კმ</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={search} disabled={loading} className="self-end" aria-label="ძიება">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            </Button>
          </div>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground">
        მონაცემები: OpenStreetMap. ხელმისაწვდომობა გამოითვლება ჩვენი ჯავშნების მიხედვით მითითებულ თარიღებზე -
        კონტრაქტორი სასტუმროებისთვის ჩანს კორპორატიული ტარიფიც.
      </p>

      {searched && results.length === 0 && !loading && (
        <Card>
          <CardContent className="p-10 text-center text-muted-foreground">შედეგი არ მოიძებნა</CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {results.map((h) => {
          const vendor = matchVendor(h);
          const booked = occupancy[norm(h.name)] || 0;
          return (
            <Card key={h.id}>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-semibold truncate">{h.name}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {sourceLabels[h.source] || "სასტუმრო"}
                      {h.address ? ` · ${h.address}` : ""}
                    </p>
                  </div>
                  {h.stars != null && (
                    <Badge variant="outline" className="shrink-0 gap-1">
                      <Star className="h-3 w-3" /> {h.stars}
                    </Badge>
                  )}
                </div>

                <div className="flex flex-wrap gap-2 text-xs">
                  {vendor ? (
                    <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-500/30">
                      კონტრაქტორი
                      {vendor.corporate_rate ? ` · ${Number(vendor.corporate_rate).toFixed(0)} ₾/ღამე` : ""}
                    </Badge>
                  ) : (
                    <Badge variant="outline">კატალოგში არ არის</Badge>
                  )}
                  {checkIn && checkOut && (
                    <Badge
                      variant="outline"
                      className={
                        booked > 0
                          ? "bg-amber-500/15 text-amber-600 border-amber-500/30"
                          : "bg-emerald-500/15 text-emerald-600 border-emerald-500/30"
                      }
                    >
                      <BedDouble className="h-3 w-3 mr-1" />
                      {booked > 0 ? `${booked} ჩვენი ჯავშანი ამ თარიღებზე` : "თავისუფალია"}
                    </Badge>
                  )}
                  {h.rooms != null && <Badge variant="outline">{h.rooms} ოთახი</Badge>}
                </div>

                <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                  {h.phone && (
                    <span className="inline-flex items-center gap-1">
                      <Phone className="h-3 w-3" /> {h.phone}
                    </span>
                  )}
                  {h.website && (
                    <a
                      href={h.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 hover:text-foreground"
                    >
                      <Globe className="h-3 w-3" /> ვებგვერდი
                    </a>
                  )}
                  {h.lat != null && h.lon != null && (
                    <a
                      href={`https://www.openstreetmap.org/?mlat=${h.lat}&mlon=${h.lon}#map=17/${h.lat}/${h.lon}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 hover:text-foreground"
                    >
                      <MapPin className="h-3 w-3" /> რუკაზე
                    </a>
                  )}
                </div>

                {canManage && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    <Button
                      size="sm"
                      onClick={() =>
                        onBook({
                          vendor_id: vendor?.id,
                          vendor_name_manual: vendor ? undefined : h.name,
                          city: city.trim(),
                          check_in_date: checkIn,
                          check_out_date: checkOut,
                          nightly_rate: vendor?.corporate_rate ? String(vendor.corporate_rate) : undefined,
                        })
                      }
                    >
                      <CalendarCheck className="h-4 w-4 mr-2" /> დაჯავშნა
                    </Button>
                    {!vendor && (
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={addingId === h.id}
                        onClick={() => addToCatalog(h)}
                      >
                        {addingId === h.id ? (
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                          <Plus className="h-4 w-4 mr-2" />
                        )}
                        კატალოგში დამატება
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
