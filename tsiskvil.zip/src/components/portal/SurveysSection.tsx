import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { MessageSquare, Send, CheckCircle, Star } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";

interface Survey {
  id: string;
  title: string;
  description: string;
  survey_type: string;
  questions: Question[];
  is_anonymous: boolean;
  start_date: string;
  end_date: string;
}

interface Question {
  question: string;
  type: "rating" | "text" | "yes_no" | "multiple";
  options?: string[];
}

interface SurveyResponse {
  [key: string]: any;
}

export default function SurveysSection({ employeeId }: { employeeId: string }) {
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSurvey, setSelectedSurvey] = useState<Survey | null>(null);
  const [responses, setResponses] = useState<SurveyResponse>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchActiveSurveys();
  }, []);

  const fetchActiveSurveys = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("wellness_surveys")
        .select("*")
        .eq("is_active", true)
        .order("created_at", { ascending: false });

      if (error) throw error;

      // Check which surveys user has already completed
      const { data: completedData } = await supabase
        .from("wellness_survey_responses")
        .select("survey_id")
        .eq("employee_id", employeeId);

      const completedIds = new Set(completedData?.map(r => r.survey_id) || []);
      
      const activeSurveys = (data || [])
        .filter(s => !completedIds.has(s.id))
        .map(s => ({
          id: s.id,
          title: s.title,
          description: s.description || "",
          survey_type: s.survey_type || "pulse",
          questions: Array.isArray(s.questions) ? (s.questions as unknown as Question[]) : [],
          is_anonymous: !!s.is_anonymous,
          start_date: s.start_date,
          end_date: s.end_date,
        }));

      setSurveys(activeSurveys);
    } catch (error) {
      console.error("Error fetching surveys:", error);
      toast.error("კვლევების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const handleResponseChange = (questionIndex: number, value: any) => {
    setResponses(prev => ({
      ...prev,
      [questionIndex]: value,
    }));
  };

  const handleSubmit = async () => {
    if (!selectedSurvey) return;

    // Validate all questions are answered
    const unansweredQuestions = selectedSurvey.questions.filter(
      (_, idx) => responses[idx] === undefined || responses[idx] === ""
    );

    if (unansweredQuestions.length > 0) {
      toast.error("გთხოვთ უპასუხოთ ყველა კითხვას");
      return;
    }

    try {
      setSubmitting(true);
      const { error } = await supabase
        .from("wellness_survey_responses")
        .insert({
          survey_id: selectedSurvey.id,
          employee_id: selectedSurvey.is_anonymous ? null : employeeId,
          responses: responses,
          submitted_at: new Date().toISOString(),
        });

      if (error) throw error;

      toast.success("პასუხები წარმატებით გაიგზავნა! 🎉");
      setSelectedSurvey(null);
      setResponses({});
      fetchActiveSurveys();
    } catch (error) {
      console.error("Error submitting survey:", error);
      toast.error("პასუხების გაგზავნა ვერ მოხერხდა");
    } finally {
      setSubmitting(false);
    }
  };

  const renderQuestion = (question: Question, index: number) => {
    switch (question.type) {
      case "rating":
        return (
          <div className="space-y-3">
            <Label>{question.question}</Label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map(rating => (
                <Button
                  key={rating}
                  type="button"
                  variant={responses[index] === rating ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleResponseChange(index, rating)}
                  className="flex-1"
                >
                  <Star className={`h-4 w-4 ${responses[index] === rating ? "fill-current" : ""}`} />
                  {rating}
                </Button>
              ))}
            </div>
          </div>
        );

      case "text":
        return (
          <div className="space-y-2">
            <Label>{question.question}</Label>
            <Textarea
              value={responses[index] || ""}
              onChange={(e) => handleResponseChange(index, e.target.value)}
              placeholder="თქვენი პასუხი..."
              rows={4}
            />
          </div>
        );

      case "yes_no":
        return (
          <div className="space-y-3">
            <Label>{question.question}</Label>
            <RadioGroup
              value={responses[index]}
              onValueChange={(value) => handleResponseChange(index, value)}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id={`q${index}-yes`} />
                <Label htmlFor={`q${index}-yes`} className="cursor-pointer">კი</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id={`q${index}-no`} />
                <Label htmlFor={`q${index}-no`} className="cursor-pointer">არა</Label>
              </div>
            </RadioGroup>
          </div>
        );

      case "multiple":
        return (
          <div className="space-y-3">
            <Label>{question.question}</Label>
            <RadioGroup
              value={responses[index]}
              onValueChange={(value) => handleResponseChange(index, value)}
            >
              {(question.options || []).map((option, optIdx) => (
                <div key={optIdx} className="flex items-center space-x-2">
                  <RadioGroupItem value={option} id={`q${index}-opt${optIdx}`} />
                  <Label htmlFor={`q${index}-opt${optIdx}`} className="cursor-pointer">
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        );

      default:
        return null;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (selectedSurvey) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                {selectedSurvey.title}
              </CardTitle>
              <CardDescription>{selectedSurvey.description}</CardDescription>
            </div>
            {selectedSurvey.is_anonymous && (
              <Badge variant="secondary">ანონიმური</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {selectedSurvey.questions.map((question, index) => (
            <div key={index} className="p-4 rounded-lg border border-border/50 bg-muted/20">
              {renderQuestion(question, index)}
            </div>
          ))}

          <div className="flex gap-3 pt-4">
            <Button
              onClick={() => {
                setSelectedSurvey(null);
                setResponses({});
              }}
              variant="outline"
              className="flex-1"
            >
              გაუქმება
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="flex-1"
            >
              <Send className="h-4 w-4 mr-2" />
              {submitting ? "იგზავნება..." : "გაგზავნა"}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (surveys.length === 0) {
    return (
      <Card className="group relative overflow-hidden border-border/50 bg-card/95">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <MessageSquare className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold">აქტიური კვლევები</h3>
          </div>
          <div className="text-center py-8 text-muted-foreground">
            აქტიური კვლევები არ არის
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="group relative overflow-hidden border-border/50 bg-card/95">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold">აქტიური კვლევები</h3>
            {surveys.length > 0 && (
              <Badge variant="secondary" className="text-xs">
                {surveys.length}
              </Badge>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => window.location.href = '/pulse-surveys'}
            className="h-8"
          >
            ყველას ნახვა
          </Button>
        </div>

        {surveys.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            აქტიური კვლევები არ არის
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {surveys.slice(0, 6).map(survey => (
              <div 
                key={survey.id}
                className="p-4 rounded-lg border border-border/50 bg-muted/10 hover:bg-muted/20 transition-all"
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <h4 className="text-sm font-semibold line-clamp-1">{survey.title}</h4>
                  {survey.is_anonymous && (
                    <Badge variant="outline" className="shrink-0 text-xs">
                      ანონიმური
                    </Badge>
                  )}
                </div>
                {survey.description && (
                  <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                    {survey.description}
                  </p>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">
                    {survey.questions.length} კითხვა
                  </span>
                  <Button onClick={() => setSelectedSurvey(survey)} size="sm" className="h-7 text-xs">
                    დაწყება
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
