import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { Clock, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { formatters } from "@/lib/dateUtils";

interface AttendanceRecord {
  id: string;
  date: string;
  check_in: string | null;
  check_out: string | null;
  status: string;
  notes: string | null;
  check_in_method: string | null;
  lateness_justified: boolean | null;
}

export default function AttendanceHistory({ employeeId }: { employeeId: string }) {
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    fetchAttendance();
  }, [employeeId]);

  const fetchAttendance = async () => {
    try {
      const { data, error } = await supabase
        .from("attendance")
        .select("id, date, check_in, check_out, status, notes, check_in_method, lateness_justified")
        .eq("employee_id", employeeId)
        .is("deleted_at", null)
        .order("date", { ascending: false })
        .limit(30);

      if (error) throw error;
      setRecords(data || []);
    } catch (error) {
      console.error("Error fetching attendance:", error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "present":
        return <Badge className="bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20">დასწრებული</Badge>;
      case "late":
        return <Badge className="bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/20">დაგვიანებული</Badge>;
      case "absent":
        return <Badge className="bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20">არყოფნა</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatTime = (datetime: string | null) => {
    if (!datetime) return "-";
    const d = new Date(datetime);
    return `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}`;
  };

  if (loading) {
    return (
      <Card className="border-border/50 bg-card/95">
        <CardContent className="p-6">
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const displayRecords = showAll ? records : records.slice(0, 7);

  return (
    <Card className="group relative overflow-hidden border-border/50 bg-card/95">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold">ჩემი დასწრება</h3>
            {records.length > 0 && (
              <Badge variant="secondary" className="text-xs">
                {records.length} ჩანაწერი
              </Badge>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => window.location.href = '/attendance'}
            className="h-8"
          >
            სრულად ნახვა
          </Button>
        </div>

        {records.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Clock className="h-8 w-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm">დასწრების ჩანაწერები არ მოიძებნა</p>
          </div>
        ) : (
          <>
            <div className="space-y-2">
              {displayRecords.map((record) => (
                <div
                  key={record.id}
                  className="flex items-center gap-3 p-3 rounded-lg border border-border/50 bg-muted/10 hover:bg-muted/20 transition-all"
                >
                  <div className="shrink-0">
                    {record.status === "present" ? (
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    ) : record.status === "late" ? (
                      <AlertCircle className="h-4 w-4 text-amber-500" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-500" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium">
                        {formatters.shortDateWithMonth(record.date)}
                      </span>
                      {getStatusBadge(record.status)}
                      {record.lateness_justified && (
                        <Badge variant="outline" className="text-xs">გამართლებული</Badge>
                      )}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground text-right shrink-0">
                    <div>{formatTime(record.check_in)} - {formatTime(record.check_out)}</div>
                    {record.check_in_method && (
                      <div className="text-[10px] opacity-60">{record.check_in_method}</div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {records.length > 7 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowAll(!showAll)}
                className="w-full mt-3"
              >
                {showAll ? "ნაკლები" : `მეტის ნახვა (${records.length - 7})`}
              </Button>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}