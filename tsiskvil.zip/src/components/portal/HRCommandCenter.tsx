import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ClipboardCheck,
  CalendarClock,
  UserCheck,
  Rocket,
  Briefcase,
  ListTodo,
  ArrowRight,
  ShieldAlert,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";

interface ExceptionTile {
  key: string;
  count: number;
  urgent: number;
  navigateTo: string;
}

/**
 * HR Command Center - exception-first block for admins/HR.
 * Answers "What requires my attention today?" instead of showing generic stats.
 */
export default function HRCommandCenter() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [isHrRole, setIsHrRole] = useState<boolean | null>(null);
  const [tiles, setTiles] = useState<ExceptionTile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function resolveRole() {
      if (!supabase) return;
      const { data: { user } } = await supabase.auth.getUser();
      if (!user || cancelled) return setIsHrRole(false);
      const { data: roles } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id);
      const has = roles?.some((r: any) => r.role === "admin" || r.role === "hr_manager");
      if (!cancelled) setIsHrRole(!!has);
    }
    resolveRole();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!isHrRole) return;
    let cancelled = false;
    async function loadExceptions() {
      setLoading(true);
      const now = new Date();
      const in60 = new Date(now);
      in60.setDate(in60.getDate() + 60);
      const in30 = new Date(now);
      in30.setDate(in30.getDate() + 30);
      const today = now.toISOString().split("T")[0];
      const in30s = in30.toISOString().split("T")[0];
      const in60s = in60.toISOString().split("T")[0];

      const [pendingLeaves, overdueTasks, expiringContracts, probation, activeOnboarding, openVacancies] =
        await Promise.all([
          supabase.from("leave_requests").select("id", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("tasks").select("id, due_date", { count: "exact" }).neq("status", "completed").lt("due_date", today),
          supabase.from("contracts").select("id, end_date", { count: "exact" }).eq("status", "active").gte("end_date", today).lte("end_date", in60s),
          supabase.from("contracts").select("id, end_date", { count: "exact" }).eq("contract_type", "probation").eq("status", "active").gte("end_date", today).lte("end_date", in30s),
          supabase.from("employee_onboarding").select("id", { count: "exact", head: true }).not("status", "in", ["completed", "cancelled"]),
          supabase.from("job_vacancies").select("id", { count: "exact", head: true }).eq("status", "open"),
        ]);

      if (cancelled) return;
      const tiles: ExceptionTile[] = [
        {
          key: "pendingApprovals",
          count: pendingLeaves.count ?? 0,
          urgent: (pendingLeaves.count ?? 0) > 0 ? (pendingLeaves.count ?? 0) : 0,
          navigateTo: "/leave-requests",
        },
        {
          key: "overdueTasks",
          count: overdueTasks.count ?? 0,
          urgent: overdueTasks.data?.length ?? 0,
          navigateTo: "/tasks",
        },
        {
          key: "contractsExpiring",
          count: expiringContracts.count ?? 0,
          urgent: 0,
          navigateTo: "/employees",
        },
        {
          key: "probationEnding",
          count: probation.count ?? 0,
          urgent: probation.count ?? 0,
          navigateTo: "/employees",
        },
        {
          key: "activeOnboarding",
          count: activeOnboarding.count ?? 0,
          urgent: 0,
          navigateTo: "/onboarding",
        },
        {
          key: "openVacancies",
          count: openVacancies.count ?? 0,
          urgent: 0,
          navigateTo: "/vacancies",
        },
      ];
      setTiles(tiles);
      setLoading(false);
    }
    loadExceptions();
    return () => { cancelled = true; };
  }, [isHrRole]);

  if (isHrRole === null || !isHrRole) return null;

  const iconMap: Record<string, any> = {
    pendingApprovals: ClipboardCheck,
    overdueTasks: ListTodo,
    contractsExpiring: CalendarClock,
    probationEnding: UserCheck,
    activeOnboarding: Rocket,
    openVacancies: Briefcase,
  };

  const totalAttention = tiles.reduce((sum, tile) => sum + tile.count, 0);

  return (
    <Card className="border-border/70 bg-card shadow-sm">
      <CardContent className="p-3 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3 sm:mb-4">
          <div className="flex items-center gap-2 min-w-0">
            <div className="p-1.5 sm:p-2 rounded-md bg-primary/10 shrink-0">
              <ShieldAlert className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
            </div>
            <div className="min-w-0">
              <h3 className="font-display text-base sm:text-lg font-semibold leading-tight">
                {t("commandCenter.title")}
              </h3>
              <p className="text-xs sm:text-sm text-muted-foreground truncate">
                {t("commandCenter.subtitle")}
              </p>
            </div>
          </div>
          {totalAttention > 0 && (
            <Badge variant="outline" className="border-destructive/40 text-destructive shrink-0">
              {totalAttention} {t("commandCenter.needsAttention")}
            </Badge>
          )}
        </div>

        {loading ? (
          <div className="grid grid-cols-2 gap-2 sm:gap-3 lg:grid-cols-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-[76px] rounded-lg" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2 sm:gap-3 lg:grid-cols-6">
            {tiles.map((tile) => {
              const Icon = iconMap[tile.key];
              const hasAttention = tile.count > 0;
              return (
                <button
                  key={tile.key}
                  onClick={() => navigate(tile.navigateTo)}
                  className={`group text-left rounded-lg border transition-colors p-3 ${
                    hasAttention
                      ? "border-primary/40 bg-primary/[0.04] hover:border-primary/60"
                      : "border-border/70 hover:border-primary/30"
                  }`}
                >
                  <div className="flex items-start justify-between gap-1">
                    <Icon className="h-4 w-4 text-primary shrink-0" />
                    {hasAttention && tile.urgent > 0 ? (
                      <span className="h-2 w-2 rounded-full bg-destructive shrink-0" aria-label={t("commandCenter.urgent")} />
                    ) : null}
                  </div>
                  <div className="font-display text-xl sm:text-2xl font-bold text-foreground tabular-nums mt-1.5">
                    {tile.count}
                  </div>
                  <div className="flex items-center gap-1 min-w-0">
                    <span className="text-[11px] sm:text-xs text-muted-foreground leading-snug">
                      {t(`commandCenter.tiles.${tile.key}`)}
                    </span>
                    <ArrowRight className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
