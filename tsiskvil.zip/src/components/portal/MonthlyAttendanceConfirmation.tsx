import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { CalendarCheck, CheckCircle2, Clock, Loader2 } from "lucide-react";

interface Props {
  employeeId: string;
}

const MONTH_NAMES_KA = [
  "იანვარი", "თებერვალი", "მარტი", "აპრილი", "მაისი", "ივნისი",
  "ივლისი", "აგვისტო", "სექტემბერი", "ოქტომბერი", "ნოემბერი", "დეკემბერი",
];

export default function MonthlyAttendanceConfirmation({ employeeId }: Props) {
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [totalHours, setTotalHours] = useState(0);
  const [totalDays, setTotalDays] = useState(0);
  const [confirmedAt, setConfirmedAt] = useState<string | null>(null);
  const [note, setNote] = useState("");

  const today = new Date();
  const currentDay = today.getDate();
  // Previous month
  const prevMonthDate = new Date(today.getFullYear(), today.getMonth() - 1, 1);
  const periodYear = prevMonthDate.getFullYear();
  const periodMonth = prevMonthDate.getMonth() + 1;
  const periodLabel = `${MONTH_NAMES_KA[periodMonth - 1]} ${periodYear}`;

  // Available from day 3 of the current month
  const available = currentDay >= 3;

  useEffect(() => {
    if (!employeeId || !available) {
      setLoading(false);
      return;
    }
    void fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [employeeId]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const startDate = `${periodYear}-${String(periodMonth).padStart(2, "0")}-01`;
      const endDate = new Date(periodYear, periodMonth, 0).toISOString().split("T")[0];

      const [{ data: attendance }, { data: confirmation }] = await Promise.all([
        supabase
          .from("attendance")
          .select("date, check_in, check_out, break_duration")
          .eq("employee_id", employeeId)
          .gte("date", startDate)
          .lte("date", endDate)
          .is("deleted_at", null),
        supabase
          .from("attendance_confirmations")
          .select("confirmed_at, total_hours, total_days, note")
          .eq("employee_id", employeeId)
          .eq("period_year", periodYear)
          .eq("period_month", periodMonth)
          .maybeSingle(),
      ]);

      let hours = 0;
      let days = 0;
      (attendance || []).forEach((r: any) => {
        if (r.check_in && r.check_out) {
          const inT = new Date(r.check_in).getTime();
          const outT = new Date(r.check_out).getTime();
          const mins = (outT - inT) / 60000 - (r.break_duration || 0);
          if (mins > 0) {
            hours += mins / 60;
            days += 1;
          }
        }
      });

      if (confirmation) {
        setConfirmedAt(confirmation.confirmed_at);
        setTotalHours(Number(confirmation.total_hours) || hours);
        setTotalDays(confirmation.total_days || days);
        setNote(confirmation.note || "");
      } else {
        setTotalHours(hours);
        setTotalDays(days);
      }
    } catch (e) {
      console.error("Confirmation fetch error:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirm = async () => {
    setSubmitting(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      const { error } = await supabase.from("attendance_confirmations").insert({
        employee_id: employeeId,
        period_year: periodYear,
        period_month: periodMonth,
        total_hours: Number(totalHours.toFixed(2)),
        total_days: totalDays,
        note: note || null,
        confirmed_by: userData.user?.id,
      });
      if (error) throw error;
      toast.success("დასწრება დადასტურდა");
      await fetchData();
    } catch (e: any) {
      console.error(e);
      toast.error(`ვერ დადასტურდა: ${e?.message || "უცნობი შეცდომა"}`);
    } finally {
      setSubmitting(false);
    }
  };

  if (!available) return null;

  return (
    <Card className="border-border/50 bg-card/95">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <CalendarCheck className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold">გასული თვის დასწრების დადასტურება</h3>
          <Badge variant="secondary" className="text-xs">{periodLabel}</Badge>
          {confirmedAt && (
            <Badge className="bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20 ml-auto">
              <CheckCircle2 className="h-3 w-3 mr-1" /> დადასტურებული
            </Badge>
          )}
        </div>

        {loading ? (
          <div className="flex justify-center py-6">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="p-3 rounded-lg border bg-muted/20">
                <div className="text-xs text-muted-foreground">ნამუშევარი საათები</div>
                <div className="text-2xl font-bold flex items-center gap-1">
                  <Clock className="h-4 w-4 text-primary" />
                  {totalHours.toFixed(1)}
                </div>
              </div>
              <div className="p-3 rounded-lg border bg-muted/20">
                <div className="text-xs text-muted-foreground">სამუშაო დღეები</div>
                <div className="text-2xl font-bold">{totalDays}</div>
              </div>
            </div>

            {confirmedAt ? (
              <div className="text-sm text-muted-foreground">
                დადასტურდა: {new Date(confirmedAt).toLocaleString("ka-GE")}
                {note && <div className="mt-2 p-2 rounded bg-muted/30 text-foreground">{note}</div>}
              </div>
            ) : (
              <div className="space-y-3">
                <Textarea
                  placeholder="შენიშვნა (სურვილისამებრ)"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  rows={2}
                />
                <Button onClick={handleConfirm} disabled={submitting} className="w-full">
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <CheckCircle2 className="h-4 w-4 mr-2" />}
                  ვადასტურებ მონაცემებს
                </Button>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
