import { useState, useRef, useEffect } from "react";
import { cleanNinaText } from "@/lib/cleanNinaText";
import { Send, X, Loader2, User, Minimize2, CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import ninaAvatar from "@/assets/nina-avatar.png";
import { motion, AnimatePresence } from "framer-motion";

interface CopilotAction {
  tool: string;
  ok: boolean;
  message: string;
}

interface Message {
  role: "user" | "assistant";
  content: string;
  actions?: CopilotAction[];
}

const NinaChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "გამარჯობა! 👋 მე ვარ ნინა. რით შემიძლია დაგეხმაროთ?"
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput("");
    
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setIsLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('ai-assistant', {
        body: { question: userMessage, conversationHistory: messages }
      });

      if (error) throw error;

      const assistantResponse = data.response;
      const executedActions: CopilotAction[] | undefined = data.actions?.length ? data.actions : undefined;

      setMessages(prev => [...prev, {
        role: "assistant",
        content: cleanNinaText(assistantResponse),
        actions: executedActions
      }]);
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "შეცდომა",
        description: "პასუხის მიღება ვერ მოხერხდა",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 group"
          >
            <div className="relative">
              <Avatar className="h-12 w-12 sm:h-14 sm:w-14 ring-4 ring-primary/20 shadow-lg cursor-pointer transition-all duration-300 group-hover:ring-primary/40">
                <AvatarImage src={ninaAvatar} alt="ნინა" />
                <AvatarFallback className="bg-primary text-primary-foreground">ნი</AvatarFallback>
              </Avatar>
              {/* Pulse animation */}
              <span className="absolute -top-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-primary"></span>
              </span>
            </div>
            {/* Tooltip */}
            <div className="absolute bottom-full right-0 mb-2 px-3 py-1.5 bg-foreground text-background text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-lg">
              მეკითხე რამე! 💬
            </div>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Popup */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-6 right-6 z-50 w-[380px] max-w-[calc(100vw-3rem)] h-[500px] max-h-[calc(100vh-6rem)] bg-background border rounded-2xl shadow-2xl flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-primary/10 to-accent/10">
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={ninaAvatar} alt="ნინა" />
                  <AvatarFallback className="bg-primary/10 text-primary">ნი</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold text-foreground">ნინა</h3>
                  <p className="text-xs text-muted-foreground">AI ასისტენტი</p>
                </div>
              </div>
              <div className="flex gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setIsOpen(false)}
                >
                  <Minimize2 className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setIsOpen(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3" ref={scrollRef}>
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex gap-2 ${
                    message.role === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  {message.role === "assistant" && (
                    <Avatar className="h-7 w-7 flex-shrink-0">
                      <AvatarImage src={ninaAvatar} alt="ნინა" />
                      <AvatarFallback className="bg-primary/10 text-primary text-xs">ნი</AvatarFallback>
                    </Avatar>
                  )}
                  
                  <div
                    className={`rounded-2xl px-3 py-2 max-w-[75%] ${
                      message.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-foreground"
                    }`}
                  >
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">
                      {message.content}
                    </p>
                    {message.actions && message.actions.length > 0 && (
                      <div className="mt-2 space-y-1.5">
                        {message.actions.map((action, ai) => (
                          <div
                            key={ai}
                            className="flex items-start gap-1.5 rounded-lg bg-background/60 border border-border px-2 py-1.5"
                          >
                            {action.ok ? (
                              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 shrink-0 mt-0.5" />
                            ) : (
                              <XCircle className="h-3.5 w-3.5 text-destructive shrink-0 mt-0.5" />
                            )}
                            <span className="text-xs leading-snug break-words">
                              {action.message}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  {message.role === "user" && (
                    <Avatar className="h-7 w-7 flex-shrink-0">
                      <AvatarFallback className="bg-accent/10 text-accent">
                        <User className="h-3.5 w-3.5" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
              
              {isLoading && (
                <div className="flex gap-2 justify-start">
                  <Avatar className="h-7 w-7 flex-shrink-0">
                    <AvatarImage src={ninaAvatar} alt="ნინა" />
                    <AvatarFallback className="bg-primary/10 text-primary text-xs">ნი</AvatarFallback>
                  </Avatar>
                  <div className="rounded-2xl px-3 py-2 bg-muted">
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-3 border-t bg-muted/30">
              <form onSubmit={handleSubmit} className="flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="დაწერეთ შეკითხვა..."
                  disabled={isLoading}
                  className="flex-1 text-sm"
                />
                <Button 
                  type="submit" 
                  disabled={isLoading || !input.trim()}
                  size="icon"
                  className="shrink-0"
                >
                  {isLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default NinaChatWidget;
