import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { CalendarCheck, Activity } from "lucide-react";

interface AttendanceChartProps {
  data: Array<{
    date: string;
    present: number;
    absent: number;
    late: number;
  }>;
}

export function AttendanceChart({ data }: AttendanceChartProps) {
  return (
    <Card className="group relative overflow-hidden border-border/50 bg-card/95 backdrop-blur-sm hover:shadow-lg transition-all duration-300 animate-fade-in">
      <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      <CardHeader className="relative">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-green-500/10">
                <CalendarCheck className="h-5 w-5 text-green-500" />
              </div>
              დასწრების სტატისტიკა
            </CardTitle>
            <CardDescription>ბოლო 7 დღის დასწრების მონაცემები</CardDescription>
          </div>
          <Activity className="h-5 w-5 text-muted-foreground" />
        </div>
      </CardHeader>
      
      <CardContent className="relative">
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
            <XAxis 
              dataKey="date" 
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
              tickLine={false}
            />
            <YAxis 
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
              tickLine={false}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
              }}
            />
            <Legend 
              wrapperStyle={{
                paddingTop: '20px'
              }}
            />
            <Line 
              type="monotone" 
              dataKey="present" 
              stroke="hsl(142 76% 36%)" 
              name="დამსწრე"
              strokeWidth={3}
              dot={{ fill: 'hsl(142 76% 36%)', r: 4 }}
              activeDot={{ r: 6 }}
              animationDuration={1500}
            />
            <Line 
              type="monotone" 
              dataKey="absent" 
              stroke="hsl(0 84% 60%)" 
              name="არმყოფი"
              strokeWidth={3}
              dot={{ fill: 'hsl(0 84% 60%)', r: 4 }}
              activeDot={{ r: 6 }}
              animationDuration={1500}
            />
            <Line 
              type="monotone" 
              dataKey="late" 
              stroke="hsl(38 92% 50%)" 
              name="დაგვიანებული"
              strokeWidth={3}
              dot={{ fill: 'hsl(38 92% 50%)', r: 4 }}
              activeDot={{ r: 6 }}
              animationDuration={1500}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
