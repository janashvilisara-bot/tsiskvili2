import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Calendar } from "lucide-react";

interface LeaveBalanceChartProps {
  data: {
    annual: number;
    sick: number;
    personal: number;
    unpaid: number;
  };
}

export function LeaveBalanceChart({ data }: LeaveBalanceChartProps) {
  const chartData = [
    { name: 'ყოველწლიური', value: data.annual, color: 'hsl(var(--primary))' },
    { name: 'სამედიცინო', value: data.sick, color: 'hsl(142 76% 36%)' },
    { name: 'პირადი', value: data.personal, color: 'hsl(221 83% 53%)' },
    { name: 'უხელფასო', value: data.unpaid, color: 'hsl(var(--muted-foreground))' },
  ];

  const COLORS = chartData.map(item => item.color);

  return (
    <Card className="group relative overflow-hidden border-border/50 bg-card/95 backdrop-blur-sm hover:shadow-lg transition-all duration-300 animate-fade-in">
      <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      <CardHeader className="relative">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-orange-500/10">
            <Calendar className="h-5 w-5 text-orange-500" />
          </div>
          <div>
            <CardTitle>შვებულების ბალანსი</CardTitle>
            <CardDescription>დარჩენილი დღეების განაწილება</CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="relative">
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
              animationDuration={1000}
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
              }}
            />
            <Legend 
              wrapperStyle={{
                paddingTop: '20px'
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
