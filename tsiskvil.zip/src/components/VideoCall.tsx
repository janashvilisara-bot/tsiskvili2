import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  PhoneOff,
  Monitor,
  MonitorOff,
} from "lucide-react";
import type { RealtimeChannel } from "@supabase/supabase-js";

interface VideoCallProps {
  roomId: string;
  userId: string;
  remoteUserId: string;
  onEnd: () => void;
  isInitiator?: boolean;
  initialSignal?: any;
}

export default function VideoCall({ roomId, userId, remoteUserId, onEnd, isInitiator = true, initialSignal }: VideoCallProps) {
  const { toast } = useToast();
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const channelRef = useRef<RealtimeChannel | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [callId, setCallId] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(true);

  useEffect(() => {
    initializeCall();
    return () => {
      cleanup();
    };
  }, [roomId, userId, remoteUserId]);

  const initializeCall = async () => {
    try {
      
      // Get local media stream
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });

      localStreamRef.current = stream;
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      // Create call record (initiator only)
      if (isInitiator) {
        const { data: call, error } = await supabase
          .from("video_calls")
          .insert({
            room_id: roomId,
            started_by: userId,
            status: "active",
          })
          .select()
          .maybeSingle();
        if (error) throw error;
        if (call) setCallId(call.id);
      }

      // Setup WebRTC
      await setupPeerConnection(stream);
      
      // Setup signaling channel
      await setupSignalingChannel();
      
      setIsConnecting(false);
    } catch (error) {
      console.error("Error initializing call:", error);
      toast({
        title: "შეცდომა",
        description: "ვიდეო ქოლის დაწყება ვერ მოხერხდა",
        variant: "destructive",
      });
      onEnd();
    }
  };

  const setupPeerConnection = async (stream: MediaStream) => {
    const configuration = {
      iceServers: [
        { urls: "stun:stun.l.google.com:19302" },
        { urls: "stun:stun1.l.google.com:19302" }
      ],
    };

    const peerConnection = new RTCPeerConnection(configuration);
    peerConnectionRef.current = peerConnection;

    // Add local stream tracks to peer connection
    stream.getTracks().forEach((track) => {
      peerConnection.addTrack(track, stream);
    });

    // Handle incoming tracks
    peerConnection.ontrack = (event) => {
      if (remoteVideoRef.current && event.streams[0]) {
        remoteVideoRef.current.srcObject = event.streams[0];
      }
    };

    // Handle ICE candidates
    peerConnection.onicecandidate = async (event) => {
      if (event.candidate) {
        await sendSignal('ice-candidate', {
          candidate: event.candidate.toJSON()
        });
      }
    };

    // Handle connection state
    peerConnection.onconnectionstatechange = () => {
      if (peerConnection.connectionState === "connected") {
        setIsConnecting(false);
      }
    };
  };

  const setupSignalingChannel = async () => {
    
    // Subscribe to WebRTC signals
    const channel = supabase
      .channel(`webrtc:${roomId}:${userId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'webrtc_signals',
          filter: `receiver_id=eq.${userId}`
        },
        async (payload) => {
          await handleSignal(payload.new);
        }
      )
      .subscribe((status) => {
      });

    channelRef.current = channel;

    const pc = peerConnectionRef.current;

    if (isInitiator) {
      // Initiator creates and sends offer
      if (pc) {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        await sendSignal('offer', { sdp: offer });
      }
    } else if (initialSignal && initialSignal.signal_type === 'offer') {
      // Receiver handles initial offer immediately
      await handleSignal(initialSignal);
    }
  };

  const sendSignal = async (type: string, data: any) => {
    const { error } = await supabase
      .from('webrtc_signals')
      .insert({
        room_id: roomId,
        sender_id: userId,
        receiver_id: remoteUserId,
        signal_type: type,
        signal_data: data
      });
    
    if (error) {
      console.error("Error sending signal:", error);
    } else {
    }
  };

  const handleSignal = async (signal: any) => {
    const pc = peerConnectionRef.current;
    if (!pc) {
      console.error("No peer connection available");
      return;
    }

    try {
      
      if (signal.signal_type === 'offer') {
        await pc.setRemoteDescription(new RTCSessionDescription(signal.signal_data.sdp));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        await sendSignal('answer', { sdp: answer });
      } else if (signal.signal_type === 'answer') {
        await pc.setRemoteDescription(new RTCSessionDescription(signal.signal_data.sdp));
      } else if (signal.signal_type === 'ice-candidate') {
        await pc.addIceCandidate(new RTCIceCandidate(signal.signal_data.candidate));
      }
    } catch (error) {
      console.error("Error handling signal:", error);
    }
  };

  const toggleMute = () => {
    if (localStreamRef.current) {
      const audioTracks = localStreamRef.current.getAudioTracks();
      audioTracks.forEach((track) => {
        track.enabled = !track.enabled;
      });
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (localStreamRef.current) {
      const videoTracks = localStreamRef.current.getVideoTracks();
      videoTracks.forEach((track) => {
        track.enabled = !track.enabled;
      });
      setIsVideoOff(!isVideoOff);
    }
  };

  const toggleScreenShare = async () => {
    try {
      if (!isScreenSharing) {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
        });

        const screenTrack = screenStream.getVideoTracks()[0];
        const sender = peerConnectionRef.current
          ?.getSenders()
          .find((s) => s.track?.kind === "video");

        if (sender) {
          sender.replaceTrack(screenTrack);
          setIsScreenSharing(true);

          screenTrack.onended = () => {
            toggleScreenShare();
          };
        }
      } else {
        const videoTrack = localStreamRef.current?.getVideoTracks()[0];
        const sender = peerConnectionRef.current
          ?.getSenders()
          .find((s) => s.track?.kind === "video");

        if (sender && videoTrack) {
          sender.replaceTrack(videoTrack);
          setIsScreenSharing(false);
        }
      }
    } catch (error) {
      console.error("Error toggling screen share:", error);
      toast({
        title: "შეცდომა",
        description: "ეკრანის გაზიარება ვერ მოხერხდა",
        variant: "destructive",
      });
    }
  };

  const endCall = async () => {
    if (callId) {
      await supabase
        .from("video_calls")
        .update({ status: "ended", ended_at: new Date().toISOString() })
        .eq("id", callId);
    }
    cleanup();
    onEnd();
  };

  const cleanup = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
    }
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
    }
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background">
      {isConnecting && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/50">
          <div className="text-center text-white">
            <div className="mb-2">დაკავშირება...</div>
            <div className="h-1 w-48 overflow-hidden rounded-full bg-gray-700">
              <div className="h-full animate-pulse bg-primary" style={{ width: "50%" }} />
            </div>
          </div>
        </div>
      )}
      
      <div className="flex-1 overflow-hidden p-4">
        <div className="flex h-full gap-4">
          {/* Remote Video */}
          <Card className="relative flex-1 overflow-hidden bg-black">
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="h-full w-full object-cover"
            />
            <div className="absolute bottom-4 left-4 text-white">
              მოსაუბრე
            </div>
          </Card>

          {/* Local Video */}
          <Card className="relative h-48 w-64 shrink-0 overflow-hidden bg-black">
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className="h-full w-full object-cover"
            />
            <div className="absolute bottom-2 left-2 text-sm text-white">
              თქვენ
            </div>
          </Card>
        </div>
      </div>

      {/* Controls */}
      <div className="shrink-0 flex justify-center gap-4 border-t p-4 bg-background">
        <Button
          size="lg"
          variant={isMuted ? "destructive" : "secondary"}
          onClick={toggleMute}
        >
          {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
        </Button>

        <Button
          size="lg"
          variant={isVideoOff ? "destructive" : "secondary"}
          onClick={toggleVideo}
        >
          {isVideoOff ? (
            <VideoOff className="h-5 w-5" />
          ) : (
            <Video className="h-5 w-5" />
          )}
        </Button>

        <Button
          size="lg"
          variant={isScreenSharing ? "default" : "secondary"}
          onClick={toggleScreenShare}
        >
          {isScreenSharing ? (
            <MonitorOff className="h-5 w-5" />
          ) : (
            <Monitor className="h-5 w-5" />
          )}
        </Button>

        <Button size="lg" variant="destructive" onClick={endCall}>
          <PhoneOff className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
