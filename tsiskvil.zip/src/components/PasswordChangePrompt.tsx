import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  getPasswordStrength,
  isCommonPassword,
  strongPasswordSchema,
} from "@/lib/passwordValidation";

export function PasswordChangePrompt() {
  const { user } = useAuth();
  const [showPrompt, setShowPrompt] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const passwordStrength = getPasswordStrength(newPassword);

  useEffect(() => {
    const checkPasswordStatus = async () => {
      if (!user) return;

      const provider = user.app_metadata?.provider;
      if (provider && provider !== "email") return;

      const { data: employee, error } = await supabase
        .from("employees")
        .select("has_changed_password")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) {
        console.error("Password status check failed:", error);
        return;
      }

      if (employee && !employee.has_changed_password) {
        setShowPrompt(true);
      }
    };

    void checkPasswordStatus();
  }, [user]);

  const validatePassword = (): string | null => {
    if (newPassword !== confirmPassword) {
      return "პაროლები არ ემთხვევა";
    }

    const parsed = strongPasswordSchema.safeParse(newPassword);
    if (!parsed.success) {
      return parsed.error.issues[0]?.message ?? "პაროლი არ აკმაყოფილებს მოთხოვნებს";
    }

    if (isCommonPassword(newPassword)) {
      return "გთხოვთ გამოიყენოთ უფრო უნიკალური პაროლი";
    }

    return null;
  };

  const handlePasswordChange = async () => {
    if (!user?.id) {
      toast.error("სესია არ არის აქტიური, გთხოვთ შეხვიდეთ თავიდან");
      return;
    }

    const validationError = validatePassword();
    if (validationError) {
      toast.error(validationError);
      return;
    }

    try {
      setLoading(true);

      const { error: authError } = await supabase.auth.updateUser({
        password: newPassword,
      });

      if (authError) {
        const authMessage = authError.message?.toLowerCase() ?? "";

        if (authError.status === 422 && authMessage.includes("same")) {
          toast.error("ახალი პაროლი ძველ პაროლს არ უნდა ემთხვეოდეს");
        } else {
          toast.error("პაროლის შეცვლა ვერ მოხერხდა, სცადეთ უფრო ძლიერი პაროლი");
        }
        return;
      }

      const { error: dbError } = await (supabase as any).rpc("mark_password_changed");

      if (dbError) {
        console.error("Password flag update failed:", dbError);
      }

      toast.success("პაროლი წარმატებით შეიცვალა");
      setShowPrompt(false);
      setNewPassword("");
      setConfirmPassword("");
    } catch (error) {
      console.error("Password change error:", error);
      toast.error("პაროლის შეცვლა ვერ მოხერხდა, სცადეთ ხელახლა");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AlertDialog open={showPrompt} onOpenChange={setShowPrompt}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>პაროლის შეცვლა აუცილებელია</AlertDialogTitle>
          <AlertDialogDescription>
            უსაფრთხოების მიზნით, გთხოვთ შეცვალოთ თქვენი ნაგულისხმევი პაროლი.
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="new-password">ახალი პაროლი</Label>
            <Input
              id="new-password"
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="მინიმუმ 12 სიმბოლო"
            />
            {newPassword.length > 0 && (
              <>
                <p className={`text-xs ${passwordStrength.color}`}>
                  სიძლიერე: {passwordStrength.label}
                </p>
                <p className="text-xs text-muted-foreground">
                  მინ. 12 სიმბოლო • დიდი/პატარა ასო • ციფრი • სპეციალური სიმბოლო
                </p>
              </>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirm-password">გაიმეორეთ პაროლი</Label>
            <Input
              id="confirm-password"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="გაიმეორეთ პაროლი"
            />
            {confirmPassword.length > 0 && newPassword !== confirmPassword && (
              <p className="text-xs text-destructive">პაროლები არ ემთხვევა</p>
            )}
          </div>
        </div>

        <AlertDialogFooter>
          <Button
            onClick={handlePasswordChange}
            disabled={loading || !newPassword || !confirmPassword || newPassword !== confirmPassword}
          >
            {loading ? "იცვლება..." : "შენახვა"}
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
