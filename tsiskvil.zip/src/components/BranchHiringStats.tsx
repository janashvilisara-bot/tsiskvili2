import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { Building2, UserPlus, UserMinus, TrendingUp, TrendingDown } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

interface BranchRow {
  id: string;
  name: string;
  code: string;
  hired: number;
  terminated: number;
  active: number;
  net: number;
}

type Period = "30" | "90" | "180" | "365" | "ytd";

export function BranchHiringStats() {
  const [period, setPeriod] = useState<Period>("90");
  const [rows, setRows] = useState<BranchRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    void load();
  }, [period]);

  const getStartDate = (): string => {
    const now = new Date();
    if (period === "ytd") return new Date(now.getFullYear(), 0, 1).toISOString().split("T")[0];
    const d = new Date();
    d.setDate(d.getDate() - parseInt(period, 10));
    return d.toISOString().split("T")[0];
  };

  const load = async () => {
    setLoading(true);
    try {
      const startDate = getStartDate();

      const [{ data: branches }, { data: hired }, { data: terminated }, { data: active }] = await Promise.all([
        supabase.from("branches").select("id, name, code").eq("is_active", true).order("is_primary", { ascending: false }),
        supabase.from("employees").select("branch_id").gte("hire_date", startDate).is("deleted_at", null),
        supabase
          .from("employees")
          .select("branch_id")
          .not("termination_date", "is", null)
          .gte("termination_date", startDate),
        supabase.from("employees").select("branch_id").eq("status", "active").is("deleted_at", null),
      ]);

      const countBy = (arr: any[] | null, key = "branch_id") => {
        const map = new Map<string, number>();
        (arr || []).forEach((r) => {
          const k = r[key] || "__none__";
          map.set(k, (map.get(k) || 0) + 1);
        });
        return map;
      };

      const hiredMap = countBy(hired);
      const termMap = countBy(terminated);
      const activeMap = countBy(active);

      const result: BranchRow[] = (branches || []).map((b: any) => {
        const h = hiredMap.get(b.id) || 0;
        const t = termMap.get(b.id) || 0;
        return {
          id: b.id,
          name: b.name,
          code: b.code,
          hired: h,
          terminated: t,
          active: activeMap.get(b.id) || 0,
          net: h - t,
        };
      });

      // unassigned
      const unH = hiredMap.get("__none__") || 0;
      const unT = termMap.get("__none__") || 0;
      const unA = activeMap.get("__none__") || 0;
      if (unH || unT || unA) {
        result.push({
          id: "__none__",
          name: "ფილიალის გარეშე",
          code: "-",
          hired: unH,
          terminated: unT,
          active: unA,
          net: unH - unT,
        });
      }

      setRows(result);
    } finally {
      setLoading(false);
    }
  };

  const totals = rows.reduce(
    (a, r) => ({ hired: a.hired + r.hired, terminated: a.terminated + r.terminated, active: a.active + r.active }),
    { hired: 0, terminated: 0, active: 0 }
  );
  const netTotal = totals.hired - totals.terminated;

  return (
    <Card>
      <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-primary" />
            დანიშვნა / გათავისუფლება ფილიალების მიხედვით
          </CardTitle>
          <CardDescription>კადრების მოძრაობის სტატისტიკა არჩეულ პერიოდში</CardDescription>
        </div>
        <Select value={period} onValueChange={(v) => setPeriod(v as Period)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="30">ბოლო 30 დღე</SelectItem>
            <SelectItem value="90">ბოლო 90 დღე</SelectItem>
            <SelectItem value="180">ბოლო 6 თვე</SelectItem>
            <SelectItem value="365">ბოლო 1 წელი</SelectItem>
            <SelectItem value="ytd">წლის დასაწყისიდან</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Totals */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="rounded-lg border p-3 bg-emerald-500/5">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <UserPlus className="h-3.5 w-3.5" /> დანიშნული
            </div>
            <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">{totals.hired}</div>
          </div>
          <div className="rounded-lg border p-3 bg-rose-500/5">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <UserMinus className="h-3.5 w-3.5" /> გათავისუფლებული
            </div>
            <div className="text-2xl font-bold text-rose-600 dark:text-rose-400 mt-1">{totals.terminated}</div>
          </div>
          <div className="rounded-lg border p-3">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              {netTotal >= 0 ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />} წმინდა ცვლილება
            </div>
            <div className={`text-2xl font-bold mt-1 ${netTotal >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400"}`}>
              {netTotal > 0 ? "+" : ""}{netTotal}
            </div>
          </div>
          <div className="rounded-lg border p-3">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">აქტიური ჯამში</div>
            <div className="text-2xl font-bold mt-1">{totals.active}</div>
          </div>
        </div>

        {/* Per-branch table */}
        {loading ? (
          <div className="space-y-2">
            {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
          </div>
        ) : rows.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm">მონაცემები ვერ მოიძებნა</div>
        ) : (
          <div className="overflow-x-auto rounded-lg border">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr className="text-left">
                  <th className="px-3 py-2 font-medium">ფილიალი</th>
                  <th className="px-3 py-2 font-medium text-right">დანიშნული</th>
                  <th className="px-3 py-2 font-medium text-right">გათავისუფლებული</th>
                  <th className="px-3 py-2 font-medium text-right">წმინდა</th>
                  <th className="px-3 py-2 font-medium text-right">აქტიური</th>
                  <th className="px-3 py-2 font-medium text-right">Turnover</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => {
                  const turnover = r.active > 0 ? ((r.terminated / r.active) * 100).toFixed(1) : "0.0";
                  return (
                    <tr key={r.id} className="border-t hover:bg-muted/30">
                      <td className="px-3 py-2">
                        <div className="font-medium">{r.name}</div>
                        <div className="text-xs text-muted-foreground font-mono">{r.code}</div>
                      </td>
                      <td className="px-3 py-2 text-right text-emerald-600 dark:text-emerald-400 font-medium">{r.hired}</td>
                      <td className="px-3 py-2 text-right text-rose-600 dark:text-rose-400 font-medium">{r.terminated}</td>
                      <td className={`px-3 py-2 text-right font-semibold ${r.net >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400"}`}>
                        {r.net > 0 ? "+" : ""}{r.net}
                      </td>
                      <td className="px-3 py-2 text-right">{r.active}</td>
                      <td className="px-3 py-2 text-right text-muted-foreground">{turnover}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
