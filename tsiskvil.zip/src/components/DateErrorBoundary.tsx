import React, { Component, ReactNode } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/**
 * Error Boundary specifically for catching date formatting errors
 * Prevents the entire app from crashing when invalid dates are encountered
 */
export class DateErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  static getDerivedStateFromError(error: Error): State {
    // Check if it's a date-related error
    const isDateError = 
      error.message.includes('Invalid time value') ||
      error.message.includes('Invalid Date') ||
      error.message.includes('date') ||
      error.message.includes('format');

    if (isDateError) {
      return {
        hasError: true,
        error,
      };
    }

    // Re-throw non-date errors to be caught by parent error boundaries
    throw error;
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Log date errors for debugging
    console.error('Date formatting error caught:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      // Use custom fallback if provided
      if (this.props.fallback) {
        return this.props.fallback;
      }

      // Default fallback UI
      return (
        <Alert variant="destructive" className="my-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>თარიღის ფორმატირების შეცდომა</AlertTitle>
          <AlertDescription>
            თარიღის ფორმატირებისას მოხდა შეცდომა. გთხოვთ, განაახლოთ გვერდი.
          </AlertDescription>
        </Alert>
      );
    }

    return this.props.children;
  }
}

/**
 * Higher-order component to wrap components with DateErrorBoundary
 * 
 * @example
 * ```tsx
 * const SafeDateComponent = withDateErrorBoundary(MyDateComponent);
 * ```
 */
export function withDateErrorBoundary<P extends object>(
  Component: React.ComponentType<P>,
  fallback?: ReactNode
) {
  return function WithDateErrorBoundary(props: P) {
    return (
      <DateErrorBoundary fallback={fallback}>
        <Component {...props} />
      </DateErrorBoundary>
    );
  };
}
