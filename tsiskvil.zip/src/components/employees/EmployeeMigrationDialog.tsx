import { useMemo, useState } from 'react';
import { Upload, Loader2, Download, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useBranch } from '@/contexts/BranchContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { buildMigrationRows, migrationFields, readMigrationFile, suggestMapping, type MigrationMapping, type MigrationSheet } from '@/lib/employeeMigration';

export function EmployeeMigrationDialog({ onSuccess }: { onSuccess: () => void }) {
  const { language } = useLanguage();
  const tr = (ka: string, en: string) => language === 'ka' ? ka : en;
  const { user, userRole } = useAuth();
  const { branches, activeBranch } = useBranch();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [sheets, setSheets] = useState<MigrationSheet[]>([]);
  const [sheetIndex, setSheetIndex] = useState(0);
  const [mapping, setMapping] = useState<MigrationMapping>({});
  const [branchId, setBranchId] = useState('');
  const [source, setSource] = useState('other');
  const [existingEmails, setExistingEmails] = useState<string[]>([]);
  const [results, setResults] = useState<{ row: number; status: string }[] | null>(null);
  const sheet = sheets[sheetIndex];
  const rows = useMemo(() => sheet ? buildMigrationRows(sheet, mapping, existingEmails) : [], [sheet, mapping, existingEmails]);
  const valid = rows.filter(r => r.errors.length === 0);
  const canManage = userRole === 'admin' || userRole === 'hr_manager';
  const labels: Record<string, string> = {
    full_name: tr('სახელი და გვარი', 'Full name'), email: tr('ელ. ფოსტა', 'Email'), position: tr('პოზიცია', 'Position'),
    department: tr('დეპარტამენტი', 'Department'), phone: tr('ტელეფონი', 'Phone'), salary: tr('ხელფასი', 'Salary'),
    hire_date: tr('დაქირავების თარიღი', 'Hire date'), date_of_birth: tr('დაბადების თარიღი', 'Birth date'),
    gender: tr('სქესი', 'Gender'), status: tr('სტატუსი', 'Status'), duplicate: tr('დუბლირებული ელ. ფოსტა', 'Duplicate email'),
  };
  async function loadEmails() {
    const emails: string[] = [];
    for (let start = 0; ; start += 1000) {
      const { data, error } = await supabase.from('employees').select('email').order('id').range(start, start + 999);
      if (error) throw error;
      emails.push(...(data || []).map(r => r.email));
      if (!data || data.length < 1000) break;
    }
    return emails;
  }
  async function loadFile(file?: File) {
    if (!file) return;
    setBusy(true); setSheets([]); setResults(null);
    try {
      const [parsed, emails] = await Promise.all([readMigrationFile(file), loadEmails()]);
      if (!parsed.length || parsed.some(s => s.rows.length > 5000)) throw new Error('invalid_file');
      setSheets(parsed); setSheetIndex(0); setMapping(suggestMapping(parsed[0].headers)); setExistingEmails(emails);
    } catch {
      toast.error(tr('ფაილის წაკითხვა ვერ მოხერხდა. გამოიყენეთ Excel (.xlsx) ან CSV, მაქსიმუმ 10 MB და 5000 სტრიქონი.', 'Unable to read file. Use Excel (.xlsx) or CSV, up to 10 MB and 5,000 rows.'));
    } finally { setBusy(false); }
  }
  async function importRows() {
    if (!user || !canManage || !sheet || !branchId || busy || results) return;
    setBusy(true);
    const output: { row: number; status: string }[] = [];
    try {
      // Recheck immediately before writing; never update or re-register an existing employee.
      const freshRows = buildMigrationRows(sheet, mapping, await loadEmails());
      for (const row of freshRows) {
        if (row.errors.length) { output.push({ row: row.row, status: tr('გამოტოვებულია: ', 'Skipped: ') + row.errors.map(e => labels[e]).join(', ') }); continue; }
        const emp = row.employee;
        const { error } = await supabase.from('employees').insert({
          ...emp, department: emp.department || null, phone: emp.phone || null, salary: emp.salary ?? null,
          hire_date: emp.hire_date || new Date().toISOString().slice(0, 10), date_of_birth: emp.date_of_birth || null,
          gender: emp.gender || null, status: emp.status || 'active', branch_id: branchId, created_by: user.id,
        });
        output.push({ row: row.row, status: error ? tr('შენახვა ვერ მოხერხდა', 'Could not save') : tr('დამატებულია', 'Imported') });
        if (error) {
          // Stop on a server failure instead of flooding a failing service with the remaining rows.
          for (const remaining of freshRows.filter(r => r.row > row.row)) output.push({ row: remaining.row, status: tr('არ დამუშავებულა', 'Not processed') });
          break;
        }
      }
      setResults(output); onSuccess();
    } catch { toast.error(tr('იმპორტი ვერ შესრულდა. სცადეთ ხელახლა.', 'Import could not complete. Please try again.')); }
    finally { setBusy(false); }
  }
  function downloadResults() {
    if (!results) return;
    const csv = '\uFEFF' + [tr('სტრიქონი,შედეგი', 'Row,Result'), ...results.map(r => `${r.row},"${r.status.replace(/"/g, '""')}"`)].join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = 'migration-results.csv'; link.click(); URL.revokeObjectURL(url);
  }
  if (!canManage) return null;
  return <>
    <Button variant="outline" className="gap-2" onClick={() => { setOpen(true); setSheets([]); setResults(null); setBranchId(activeBranch?.id || branches[0]?.id || ''); }}><Upload className="h-4 w-4" />{tr('მონაცემების გადმოტანა', 'Migrate data')}</Button>
    <Dialog open={open} onOpenChange={value => { if (!busy) setOpen(value); }}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" onEscapeKeyDown={e => { if (busy) e.preventDefault(); }} onInteractOutside={e => { if (busy) e.preventDefault(); }}>
        <DialogHeader><DialogTitle>{tr('თანამშრომლების გადმოტანა', 'Employee migration')}</DialogTitle><DialogDescription>{tr('Excel / CSV - Self.HR, ILARIA, Aisitec ან სხვა სისტემის ექსპორტი', 'Excel / CSV - export from Self.HR, ILARIA, Aisitec or another system')}</DialogDescription></DialogHeader>
        <p className="text-sm text-muted-foreground">{tr('მხოლოდ თანამშრომლების ბარათები. არსებული ჩანაწერები უცვლელია. ანგარიშები არ იქმნება და SMS / ელ. ფოსტა არ იგზავნება.', 'Employee records only. Existing records remain unchanged. No login accounts, SMS or emails are created.')}</p>
        {!results ? <>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2"><Label>{tr('წყარო', 'Source')}</Label><Select value={source} onValueChange={setSource} disabled={busy}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{['Self.HR', 'ILARIA', 'Aisitec', 'other'].map(s => <SelectItem key={s} value={s}>{s === 'other' ? tr('სხვა / Excel', 'Other / Excel') : s}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-2"><Label>{tr('დანიშნულების ფილიალი', 'Destination branch')}</Label><Select value={branchId} onValueChange={setBranchId} disabled={busy}><SelectTrigger><SelectValue placeholder={tr('აირჩიეთ ფილიალი', 'Choose branch')} /></SelectTrigger><SelectContent>{branches.map(b => <SelectItem key={b.id} value={b.id}>{language === 'en' ? b.name_en || b.name : b.name}</SelectItem>)}</SelectContent></Select></div>
          </div>
          <Input type="file" aria-label={tr('Excel ან CSV ფაილი', 'Excel or CSV file')} accept=".xlsx,.csv" disabled={busy} onChange={e => { void loadFile(e.target.files?.[0]); e.target.value = ''; }} />
          {busy && <Loader2 className="h-5 w-5 animate-spin text-primary" />}
          {sheet && <>
            <Select value={String(sheetIndex)} disabled={busy} onValueChange={value => { const index = Number(value); setSheetIndex(index); setMapping(suggestMapping(sheets[index].headers)); }}><SelectTrigger aria-label={tr('ფურცელი', 'Worksheet')}><SelectValue /></SelectTrigger><SelectContent>{sheets.map((s, i) => <SelectItem value={String(i)} key={i}>{s.name}</SelectItem>)}</SelectContent></Select>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{Object.keys(migrationFields).map(key => {
              const field = key as keyof typeof migrationFields;
              return <div key={key} className="space-y-1"><Label>{labels[key]}{['full_name', 'email', 'position'].includes(key) ? ' *' : ''}</Label><Select disabled={busy} value={mapping[field] === undefined ? 'none' : String(mapping[field])} onValueChange={value => setMapping(prev => ({ ...prev, [field]: value === 'none' ? undefined : Number(value) }))}><SelectTrigger aria-label={labels[key]}><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">{tr('არ გადმოიტანო', 'Do not import')}</SelectItem>{sheet.headers.map((h, i) => <SelectItem key={i} value={String(i)}>{h || tr('უსათაურო', 'Untitled')} ({i + 1})</SelectItem>)}</SelectContent></Select></div>;
            })}</div>
            <div className="flex flex-wrap gap-4 text-sm font-medium"><span>{tr('მზადაა', 'Ready')}: {valid.length}</span><span className="text-destructive">{tr('გამოტოვდება', 'Will skip')}: {rows.length - valid.length}</span><span>{tr('სულ', 'Total')}: {rows.length}</span></div>
            <div className="max-h-64 overflow-auto border border-border rounded-md"><Table><TableHeader><TableRow><TableHead>#</TableHead><TableHead>{labels.full_name}</TableHead><TableHead>{labels.email}</TableHead><TableHead>{tr('შემოწმება', 'Validation')}</TableHead></TableRow></TableHeader><TableBody>{rows.slice(0, 100).map(r => <TableRow key={r.row}><TableCell>{r.row}</TableCell><TableCell>{r.employee.full_name}</TableCell><TableCell>{r.employee.email}</TableCell><TableCell className={r.errors.length ? 'text-destructive' : 'text-foreground'}>{r.errors.length ? r.errors.map(e => labels[e]).join(', ') : tr('მზადაა', 'Ready')}</TableCell></TableRow>)}</TableBody></Table></div>
            <Button disabled={busy || !valid.length || !branchId} onClick={importRows} className="gap-2">{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}{tr('გადმოტანა', 'Import')} ({valid.length})</Button>
          </>}
        </> : <>
          <div className="flex items-center gap-2 font-medium"><CheckCircle2 className="h-5 w-5 text-primary" />{tr('დამატებულია', 'Imported')}: {results.filter(r => r.status === tr('დამატებულია', 'Imported')).length} / {results.length}</div>
          <div className="max-h-64 overflow-auto"><Table><TableBody>{results.map(r => <TableRow key={r.row}><TableCell>{r.row}</TableCell><TableCell>{r.status}</TableCell></TableRow>)}</TableBody></Table></div>
          <Button variant="outline" className="gap-2" onClick={downloadResults}><Download className="h-4 w-4" />{tr('შედეგების ჩამოტვირთვა', 'Download results')}</Button>
        </>}
      </DialogContent>
    </Dialog>
  </>;
}