import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Loader2, Sparkles, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";
import { toast } from "sonner";
import { loadPerformanceInputs } from "@/hooks/usePerformanceData";
import { componentScores, performanceScore, performanceTrend, potentialScore, type PerformanceInput } from "@/lib/performanceScore";

export interface RoleMatch { role: string; department?: string; fit: number; reason: string; gaps: string; training: string }
export interface RoleFit { current_fit: number | null; summary: string | null; top_matches: RoleMatch[]; data_sufficient: boolean; created_at?: string }

export function EmployeePerformanceTab({ employeeId, userId }: { employeeId: string; userId?: string | null }) {
  const { language } = useLanguage();
  const L = (ka: string, en: string) => (language === "en" ? en : ka);
  const [input, setInput] = useState<PerformanceInput | null>(null);
  const [fit, setFit] = useState<RoleFit | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    loadPerformanceInputs([{ id: employeeId, user_id: userId }]).then((r) => setInput(r[employeeId]));
    supabase.from("employee_role_fit").select("*").eq("employee_id", employeeId).order("created_at", { ascending: false }).limit(1)
      .then(({ data }) => { if (data?.[0]) setFit(data[0] as unknown as RoleFit); });
  }, [employeeId, userId]);

  const runFit = async () => {
    setAiLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-role-fit", { body: { employee_id: employeeId } });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setFit(data);
    } catch (e: any) {
      toast.error(e?.message && /[ა-ჰ]/.test(e.message) ? e.message : L("AI ანალიზი ვერ მოხერხდა", "AI analysis failed"));
    } finally { setAiLoading(false); }
  };

  if (!input) return <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;

  const score = performanceScore(input);
  const potential = potentialScore(input);
  const trend = performanceTrend(input.evaluations);
  const c = componentScores(input);
  const chart = [...input.evaluations].sort((a, b) => a.evaluation_date.localeCompare(b.evaluation_date)).map((e: any) => ({
    date: e.evaluation_date,
    [L("ეფექტურობა", "Performance")]: e.performance_rating,
    [L("გუნდურობა", "Teamwork")]: e.teamwork_rating,
    [L("კომუნიკაცია", "Communication")]: e.communication_rating,
    [L("ლიდერობა", "Leadership")]: e.leadership_rating,
  }));
  const colors = ["hsl(var(--primary))", "hsl(var(--chart-2, var(--accent)))", "hsl(var(--chart-3, var(--secondary-foreground)))", "hsl(var(--chart-4, var(--muted-foreground)))"];
  const trendView = {
    improving: { icon: TrendingUp, label: L("იზრდება", "Improving"), v: "default" as const },
    stable: { icon: Minus, label: L("სტაბილური", "Stable"), v: "secondary" as const },
    declining: { icon: TrendingDown, label: L("ეცემა", "Declining"), v: "destructive" as const },
    unknown: { icon: Minus, label: L("ცოტა მონაცემი", "Not enough data"), v: "outline" as const },
  }[trend];
  const TrendIcon = trendView.icon;

  const rows: [string, number | null, string][] = [
    [L("შეფასებები", "Evaluations"), c.evaluations, L(`${input.evaluations.length} შეფასება`, `${input.evaluations.length} reviews`)],
    [L("დასწრება (90 დღე)", "Attendance (90 days)"), c.attendance, input.lateCount90d === null ? L("დასწრება არ ითვლება", "Not tracked") : L(`${input.lateCount90d} დაგვიანება`, `${input.lateCount90d} late arrivals`)],
    [L("ამოცანები", "Tasks"), c.tasks, L(`${input.tasksCompleted} დასრულებული, ${input.tasksOverdue} ვადაგადაცილებული`, `${input.tasksCompleted} done, ${input.tasksOverdue} overdue`)],
    [L("მიზნები", "Goals"), c.goals, L(`${input.goalProgress.length} მიზანი`, `${input.goalProgress.length} goals`)],
    [L("ტრენინგები", "Trainings"), c.training, `${input.trainingsCompleted}/${input.trainingsTotal}`],
  ];

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-3">
        <Card><CardContent className="pt-6">
          <p className="text-sm text-muted-foreground">{L("საერთო ქულა", "Overall score")}</p>
          <p className="text-4xl font-bold">{score ?? "—"}<span className="text-lg text-muted-foreground">/100</span></p>
        </CardContent></Card>
        <Card><CardContent className="pt-6">
          <p className="text-sm text-muted-foreground">{L("პოტენციალი", "Potential")}</p>
          <p className="text-4xl font-bold">{potential ?? "—"}<span className="text-lg text-muted-foreground">/100</span></p>
        </CardContent></Card>
        <Card><CardContent className="pt-6">
          <p className="text-sm text-muted-foreground mb-2">{L("ტენდენცია", "Trend")}</p>
          <Badge variant={trendView.v} className="gap-1 text-sm"><TrendIcon className="h-4 w-4" />{trendView.label}</Badge>
        </CardContent></Card>
      </div>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-base">{L("რისგან შედგება ქულა", "Score breakdown")}</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {rows.map(([label, v, sub]) => (
            <div key={label}>
              <div className="flex justify-between text-sm mb-1 gap-2">
                <span className="font-medium">{label} <span className="text-muted-foreground font-normal">· {sub}</span></span>
                <span>{v === null ? L("მონაცემი არ არის", "No data") : Math.round(v)}</span>
              </div>
              <Progress value={v ?? 0} className="h-2" />
            </div>
          ))}
        </CardContent>
      </Card>

      {chart.length > 0 && (
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-base">{L("შეფასებები დროში", "Ratings over time")}</CardTitle></CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chart}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="date" fontSize={11} />
                <YAxis domain={[0, 5]} fontSize={11} />
                <Tooltip /><Legend />
                {Object.keys(chart[0]).filter((k) => k !== "date").map((k, i) => (
                  <Line key={k} type="monotone" dataKey={k} stroke={colors[i]} strokeWidth={2} />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between gap-2 space-y-0">
          <CardTitle className="text-base">{L("სად იქნებოდა საუკეთესო?", "Where would they shine?")}</CardTitle>
          <Button size="sm" onClick={runFit} disabled={aiLoading} className="gap-2">
            {aiLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            {fit ? L("ხელახლა ანალიზი", "Re-analyse") : L("AI ანალიზი", "AI analysis")}
          </Button>
        </CardHeader>
        <CardContent className="space-y-3">
          {!fit && <p className="text-sm text-muted-foreground">{L("AI შეადარებს თანამშრომლის უნარებს და შეფასებებს კომპანიის ყველა პოზიციას და გეტყვით, რომელ როლში იქნებოდა ყველაზე ეფექტური. ეს მხოლოდ რჩევაა.", "AI compares this person's skills and reviews with every role in the company and suggests where they would be most effective. Advice only.")}</p>}
          {fit && (
            <>
              {fit.summary && <p className="text-sm">{fit.summary}</p>}
              {fit.data_sufficient && fit.current_fit !== null && (
                <div>
                  <div className="flex justify-between text-sm mb-1"><span>{L("ამჟამინდელ როლთან შესაბამისობა", "Fit with current role")}</span><span>{fit.current_fit}%</span></div>
                  <Progress value={fit.current_fit} className="h-2" />
                </div>
              )}
              {fit.top_matches.map((m, i) => (
                <div key={i} className="border rounded-lg p-3 space-y-1">
                  <div className="flex justify-between gap-2">
                    <span className="font-medium">{m.role}{m.department ? ` · ${m.department}` : ""}</span>
                    <Badge>{m.fit}%</Badge>
                  </div>
                  <p className="text-sm">{m.reason}</p>
                  <p className="text-sm text-muted-foreground">{L("რა აკლია:", "Gaps:")} {m.gaps}</p>
                  <p className="text-sm text-primary">{L("რეკომენდებული ტრენინგი:", "Suggested training:")} {m.training}</p>
                </div>
              ))}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
