import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, Gift, Pause, Trash2, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

interface BenefitType {
  id: string;
  name: string;
  name_ka: string | null;
}

interface EmployeeBenefit {
  id: string;
  employee_id: string;
  benefit_type_id: string | null;
  amount: number | null;
  start_date: string | null;
  end_date: string | null;
  is_active: boolean;
  notes: string | null;
  service_category: string;
  granted_by: string | null;
  granted_at: string | null;
  reference_url: string | null;
  benefit_type?: BenefitType | null;
}

const CATEGORY_LABELS: Record<string, string> = {
  benefit: "ბენეფიტი",
  service: "სერვისი",
  equipment: "ტექნიკა",
  other: "სხვა",
};

export const EmployeeBenefitsTab = ({ employeeId }: { employeeId: string }) => {
  const { user, userRole } = useAuth();
  const canManage = userRole === "admin" || userRole === "hr_manager";
  const [items, setItems] = useState<EmployeeBenefit[]>([]);
  const [types, setTypes] = useState<BenefitType[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    benefit_type_id: "",
    service_category: "benefit",
    amount: "",
    start_date: new Date().toISOString().split("T")[0],
    end_date: "",
    notes: "",
    reference_url: "",
  });

  const load = async () => {
    setLoading(true);
    const [b, t] = await Promise.all([
      supabase
        .from("employee_benefits")
        .select("*, benefit_type:benefit_types(id, name, name_ka)")
        .eq("employee_id", employeeId)
        .order("created_at", { ascending: false }),
      supabase.from("benefit_types").select("id, name, name_ka").eq("is_active", true).order("name"),
    ]);
    if (!b.error) setItems((b.data as any) || []);
    if (!t.error) setTypes((t.data as any) || []);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, [employeeId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload: any = {
      employee_id: employeeId,
      benefit_type_id: form.benefit_type_id || null,
      service_category: form.service_category,
      amount: form.amount ? parseFloat(form.amount) : null,
      start_date: form.start_date || null,
      end_date: form.end_date || null,
      notes: form.notes || null,
      reference_url: form.reference_url || null,
      is_active: true,
      granted_by: user?.id,
      granted_at: new Date().toISOString(),
    };
    const { error } = await supabase.from("employee_benefits").insert([payload]);
    if (error) {
      toast.error("შეცდომა: " + error.message);
      return;
    }
    toast.success("გაცემა მონიშნულია");
    setOpen(false);
    setForm({
      benefit_type_id: "",
      service_category: "benefit",
      amount: "",
      start_date: new Date().toISOString().split("T")[0],
      end_date: "",
      notes: "",
      reference_url: "",
    });
    load();
  };

  const handleStop = async (id: string) => {
    const today = new Date().toISOString().split("T")[0];
    const { error } = await supabase
      .from("employee_benefits")
      .update({ is_active: false, end_date: today } as any)
      .eq("id", id);
    if (error) toast.error("შეცდომა: " + error.message);
    else {
      toast.success("შეჩერებულია");
      load();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("წავშალო ჩანაწერი?")) return;
    const { error } = await supabase.from("employee_benefits").delete().eq("id", id);
    if (error) toast.error("შეცდომა: " + error.message);
    else {
      toast.success("წაიშალა");
      load();
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>გაცემული ბენეფიტები / სერვისები</CardTitle>
        {canManage && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                გაცემის მონიშვნა
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>გაცემული ბენეფიტი / სერვისი</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>კატეგორია *</Label>
                    <Select
                      value={form.service_category}
                      onValueChange={(v) => setForm({ ...form, service_category: v })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(CATEGORY_LABELS).map(([k, v]) => (
                          <SelectItem key={k} value={k}>
                            {v}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>ტიპი</Label>
                    <Select
                      value={form.benefit_type_id}
                      onValueChange={(v) => setForm({ ...form, benefit_type_id: v })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="აირჩიეთ ტიპი" />
                      </SelectTrigger>
                      <SelectContent>
                        {types.map((t) => (
                          <SelectItem key={t.id} value={t.id}>
                            {t.name_ka || t.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>თანხა (₾)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={form.amount}
                      onChange={(e) => setForm({ ...form, amount: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>დაწყება *</Label>
                    <Input
                      type="date"
                      required
                      value={form.start_date}
                      onChange={(e) => setForm({ ...form, start_date: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>დასრულება</Label>
                    <Input
                      type="date"
                      value={form.end_date}
                      onChange={(e) => setForm({ ...form, end_date: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>დაკავშირებული ბმული</Label>
                  <Input
                    type="url"
                    placeholder="https://..."
                    value={form.reference_url}
                    onChange={(e) => setForm({ ...form, reference_url: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>შენიშვნა</Label>
                  <Textarea
                    value={form.notes}
                    onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                    გაუქმება
                  </Button>
                  <Button type="submit">შენახვა</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-center text-muted-foreground py-8">იტვირთება...</p>
        ) : items.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">გაცემული ბენეფიტი არ მოიძებნა</p>
        ) : (
          <div className="space-y-3">
            {items.map((it) => (
              <Card key={it.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex gap-3">
                      <Gift className="h-5 w-5 mt-1 text-primary" />
                      <div>
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <h4 className="font-semibold">
                            {it.benefit_type?.name_ka || it.benefit_type?.name || "-"}
                          </h4>
                          <Badge variant="outline">
                            {CATEGORY_LABELS[it.service_category] || it.service_category}
                          </Badge>
                          {it.is_active ? (
                            <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-500/30">
                              აქტიური
                            </Badge>
                          ) : (
                            <Badge variant="secondary">დასრულებული</Badge>
                          )}
                        </div>
                        <div className="text-sm space-y-0.5 text-muted-foreground">
                          {it.amount != null && <p>თანხა: {it.amount} ₾</p>}
                          {it.start_date && (
                            <p>
                              პერიოდი: {format(new Date(it.start_date), "dd/MM/yyyy")}
                              {it.end_date && ` - ${format(new Date(it.end_date), "dd/MM/yyyy")}`}
                            </p>
                          )}
                          {it.notes && <p>შენიშვნა: {it.notes}</p>}
                          {it.reference_url && (
                            <a
                              href={it.reference_url}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1 text-primary hover:underline"
                            >
                              <ExternalLink className="h-3 w-3" /> ბმული
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                    {canManage && (
                      <div className="flex gap-2 shrink-0">
                        {it.is_active && (
                          <Button variant="outline" size="sm" onClick={() => handleStop(it.id)}>
                            <Pause className="h-3.5 w-3.5 mr-1" /> შეჩერება
                          </Button>
                        )}
                        <Button variant="ghost" size="sm" onClick={() => handleDelete(it.id)}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
