import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Lock, 
  Unlock, 
  Eye, 
  EyeOff, 
  Shield, 
  AlertTriangle,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  Banknote,
  User
} from "lucide-react";
import { useEncryptedData } from "@/hooks/useEncryptedData";
import { SENSITIVE_FIELDS, SensitiveField } from "@/lib/encryption";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface SensitiveDataViewerProps {
  employeeId: string;
  employeeName?: string;
  // Raw values from database (will be masked for non-admins)
  rawData?: {
    personal_id?: string;
    phone?: string;
    email?: string;
    address?: string;
    salary?: number;
    bank_account?: string;
    bonus?: number;
    pension_amount?: number;
  };
}

const fieldConfig: Record<SensitiveField, { label: string; icon: React.ReactNode }> = {
  personal_id: { label: "პირადი ნომერი", icon: <User className="h-4 w-4" /> },
  phone: { label: "ტელეფონი", icon: <Phone className="h-4 w-4" /> },
  email: { label: "ელ-ფოსტა", icon: <Mail className="h-4 w-4" /> },
  address: { label: "მისამართი", icon: <MapPin className="h-4 w-4" /> },
  salary: { label: "ხელფასი", icon: <Banknote className="h-4 w-4" /> },
  bank_account: { label: "საბანკო ანგარიში", icon: <CreditCard className="h-4 w-4" /> },
  bonus: { label: "ბონუსი", icon: <Banknote className="h-4 w-4" /> },
  pension_amount: { label: "საპენსიო შენატანი", icon: <Banknote className="h-4 w-4" /> },
};

export function SensitiveDataViewer({ 
  employeeId, 
  employeeName,
  rawData 
}: SensitiveDataViewerProps) {
  const [showValues, setShowValues] = useState(false);
  
  const {
    decryptedData,
    isDecrypting,
    isDecrypted,
    canDecrypt,
    decryptData,
    getMaskedValue,
    getDisplayValue
  } = useEncryptedData({ employeeId });

  const handleToggleVisibility = async () => {
    if (!isDecrypted && canDecrypt) {
      await decryptData();
      setShowValues(true);
    } else {
      setShowValues(!showValues);
    }
  };

  return (
    <Card className="border-amber-200 dark:border-amber-800 bg-gradient-to-br from-amber-50/50 to-orange-50/50 dark:from-amber-950/20 dark:to-orange-950/20">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-amber-600" />
            <CardTitle className="text-lg">დაცული მონაცემები</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            {canDecrypt ? (
              <Badge variant="outline" className="bg-green-100 text-green-700 border-green-300">
                <Unlock className="h-3 w-3 mr-1" />
                ადმინი
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-300">
                <Lock className="h-3 w-3 mr-1" />
                შეზღუდული
              </Badge>
            )}
          </div>
        </div>
        
        {!canDecrypt && (
          <div className="flex items-center gap-2 text-sm text-amber-700 dark:text-amber-400 mt-2">
            <AlertTriangle className="h-4 w-4" />
            <span>მხოლოდ ადმინისტრატორს შეუძლია მონაცემების გაშიფვრა</span>
          </div>
        )}
      </CardHeader>
      
      <CardContent className="space-y-4">
        {canDecrypt && (
          <Button
            onClick={handleToggleVisibility}
            variant="outline"
            className="w-full"
            disabled={isDecrypting}
          >
            {isDecrypting ? (
              <>
                <Lock className="h-4 w-4 mr-2 animate-pulse" />
                იშიფრება...
              </>
            ) : showValues && isDecrypted ? (
              <>
                <EyeOff className="h-4 w-4 mr-2" />
                დამალვა
              </>
            ) : (
              <>
                <Eye className="h-4 w-4 mr-2" />
                გაშიფვრა და ნახვა
              </>
            )}
          </Button>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {SENSITIVE_FIELDS.map((field) => {
            const config = fieldConfig[field];
            const rawValue = rawData?.[field as keyof typeof rawData];
            
            return (
              <div 
                key={field}
                className="flex items-center gap-3 p-3 rounded-lg bg-white/60 dark:bg-gray-900/40 border border-amber-100 dark:border-amber-900"
              >
                <div className="p-2 rounded-full bg-amber-100 dark:bg-amber-900/50 text-amber-600 dark:text-amber-400">
                  {config.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground">{config.label}</p>
                  <div className="flex items-center gap-2">
                    {isDecrypting ? (
                      <Skeleton className="h-5 w-24" />
                    ) : (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <p className="font-medium truncate">
                            {showValues && isDecrypted 
                              ? getDisplayValue(field)
                              : getMaskedValue(field, rawValue)
                            }
                          </p>
                        </TooltipTrigger>
                        {!canDecrypt && (
                          <TooltipContent>
                            <p>მონაცემები დაშიფრულია</p>
                          </TooltipContent>
                        )}
                      </Tooltip>
                    )}
                    {!showValues && (
                      <Lock className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-xs text-muted-foreground flex items-center gap-1 mt-4">
          <Shield className="h-3 w-3" />
          <span>End-to-End AES-256-GCM დაშიფვრა • მონაცემები ქლაუდში დაცულია</span>
        </div>
      </CardContent>
    </Card>
  );
}
