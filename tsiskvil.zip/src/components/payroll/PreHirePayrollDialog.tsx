import { useState, useEffect, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info, AlertTriangle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { calculateFullPayroll } from "@/lib/financialCalculations";

interface Employee {
  id: string;
  full_name: string;
  salary: number | null;
  hire_date: string | null;
  is_pension_payer: boolean | null;
  branch_id: string | null;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

type RateType = "hourly" | "daily";
type Mode = "lump" | "prorate";

function workingDaysInMonth(year: number, month0: number, from?: Date, to?: Date) {
  const start = new Date(year, month0, 1);
  const end = new Date(year, month0 + 1, 0);
  const lo = from && from > start ? from : start;
  const hi = to && to < end ? to : end;
  let count = 0;
  for (let d = new Date(lo); d <= hi; d.setDate(d.getDate() + 1)) {
    const dow = d.getDay();
    if (dow !== 0 && dow !== 6) count++;
  }
  return count;
}

export default function PreHirePayrollDialog({ open, onOpenChange, onSuccess }: Props) {
  const { user } = useAuth();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [employeeId, setEmployeeId] = useState<string>("");
  const [periodStart, setPeriodStart] = useState<string>("");
  const [periodEnd, setPeriodEnd] = useState<string>("");
  const [rateType, setRateType] = useState<RateType>("hourly");
  const [rate, setRate] = useState<string>("");
  const [quantity, setQuantity] = useState<string>("");
  const [bonuses, setBonuses] = useState<string>("0");
  const [deductions, setDeductions] = useState<string>("0");
  const [reason, setReason] = useState<string>("");
  const [mode, setMode] = useState<Mode>("lump");
  const [targetMonth, setTargetMonth] = useState<number>(new Date().getMonth() + 1);
  const [targetYear, setTargetYear] = useState<number>(new Date().getFullYear());
  const [saving, setSaving] = useState(false);

  const selectedEmployee = useMemo(
    () => employees.find((e) => e.id === employeeId),
    [employees, employeeId]
  );

  useEffect(() => {
    if (!open) return;
    (async () => {
      const { data } = await supabase
        .from("employees")
        .select("id, full_name, salary, hire_date, is_pension_payer, branch_id")
        .eq("status", "active")
        .order("full_name");
      setEmployees(data || []);
    })();
  }, [open]);

  useEffect(() => {
    if (!selectedEmployee) return;
    const salary = selectedEmployee.salary || 0;
    setRate(rateType === "hourly" ? (salary / 160).toFixed(2) : (salary / 20).toFixed(2));
    if (selectedEmployee.hire_date && !periodEnd) {
      const d = new Date(selectedEmployee.hire_date);
      d.setDate(d.getDate() - 1);
      setPeriodEnd(d.toISOString().slice(0, 10));
    }
  }, [selectedEmployee, rateType]);

  const totalAmount = useMemo(() => {
    const r = parseFloat(rate) || 0;
    const q = parseFloat(quantity) || 0;
    return r * q;
  }, [rate, quantity]);

  const handleSubmit = async () => {
    if (!selectedEmployee) return toast.error("აირჩიეთ თანამშრომელი");
    if (!periodStart || !periodEnd) return toast.error("მიუთითეთ პერიოდი");
    if (selectedEmployee.hire_date && periodEnd >= selectedEmployee.hire_date) {
      return toast.error("პერიოდი უნდა იყოს დანიშვნამდე");
    }
    if (totalAmount <= 0) return toast.error("მიუთითეთ ტარიფი და რაოდენობა");
    if (!reason.trim()) return toast.error("საფუძველი სავალდებულოა");

    setSaving(true);
    try {
      const manualBonuses = (parseFloat(bonuses) || 0) + totalAmount;
      const manualDeductions = parseFloat(deductions) || 0;
      const hasPension = !!selectedEmployee.is_pension_payer;

      const buildRow = (month: number, year: number, amount: number) => {
        const calc = calculateFullPayroll({
          baseSalary: 0,
          manualBonuses: amount + (parseFloat(bonuses) || 0),
          manualDeductions,
          overtimeHours: 0,
          holidayOvertimeHours: 0,
          hasPension,
          benefitsDeduction: 0,
        });
        return {
          employee_id: selectedEmployee.id,
          month,
          year,
          base_salary: 0,
          bonuses: calc.totalBonuses,
          deductions: calc.totalDeductions,
          gross_salary: calc.grossSalary,
          net_salary: calc.netSalary,
          status: "draft",
          created_by: user?.id,
          branch_id: selectedEmployee.branch_id,
          is_retroactive: true,
          retroactive_period_start: periodStart,
          retroactive_period_end: periodEnd,
          retroactive_reason: reason,
          notes: JSON.stringify({
            retroactive: true,
            rateType,
            rate: parseFloat(rate),
            quantity: parseFloat(quantity),
            retroactiveAmount: amount,
            pensionEmployee: calc.pensionEmployee,
            incomeTax: calc.incomeTax,
            netSalary: calc.netSalary,
          }),
        };
      };

      if (mode === "lump") {
        const { error } = await supabase.from("payroll").insert(buildRow(targetMonth, targetYear, totalAmount));
        if (error) throw error;
      } else {
        // Pro-rate by working days across months in [periodStart, periodEnd]
        const start = new Date(periodStart);
        const end = new Date(periodEnd);
        const buckets: { y: number; m: number; days: number }[] = [];
        let cursor = new Date(start.getFullYear(), start.getMonth(), 1);
        while (cursor <= end) {
          const y = cursor.getFullYear();
          const m0 = cursor.getMonth();
          const days = workingDaysInMonth(y, m0, start, end);
          if (days > 0) buckets.push({ y, m: m0 + 1, days });
          cursor.setMonth(cursor.getMonth() + 1);
        }
        const totalDays = buckets.reduce((s, b) => s + b.days, 0) || 1;
        const rows = buckets.map((b) => buildRow(b.m, b.y, (totalAmount * b.days) / totalDays));
        const { error } = await supabase.from("payroll").insert(rows);
        if (error) throw error;
      }

      toast.success("რეტროაქტიური გამომუშავება ასახულია");
      onOpenChange(false);
      onSuccess?.();
      // reset
      setEmployeeId("");
      setPeriodStart("");
      setPeriodEnd("");
      setQuantity("");
      setReason("");
    } catch (e: any) {
      console.error("Pre-hire payroll insert error:", e);
      toast.error(`ჩაწერა ვერ მოხერხდა: ${e?.message || e?.details || "უცნობი შეცდომა"}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>დანიშვნამდე გამომუშავების ასახვა</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              გამოიყენეთ მაშინ, როცა თანამშრომელმა ფაქტობრივად იმუშავა დანიშვნამდე და ეს პერიოდი უნდა ანაზღაურდეს რეტროაქტიულად.
            </AlertDescription>
          </Alert>

          <div>
            <Label>თანამშრომელი *</Label>
            <Select value={employeeId} onValueChange={setEmployeeId}>
              <SelectTrigger><SelectValue placeholder="აირჩიეთ" /></SelectTrigger>
              <SelectContent>
                {employees.map((e) => (
                  <SelectItem key={e.id} value={e.id}>
                    {e.full_name}{e.hire_date ? ` - დანიშვნა: ${e.hire_date}` : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>პერიოდის დაწყება *</Label>
              <Input type="date" value={periodStart} onChange={(e) => setPeriodStart(e.target.value)} />
            </div>
            <div>
              <Label>პერიოდის დასრულება *</Label>
              <Input type="date" value={periodEnd} onChange={(e) => setPeriodEnd(e.target.value)} />
            </div>
          </div>

          {selectedEmployee?.hire_date && periodEnd && periodEnd >= selectedEmployee.hire_date && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>პერიოდი უნდა იყოს დანიშვნამდე ({selectedEmployee.hire_date})</AlertDescription>
            </Alert>
          )}

          <div>
            <Label>ტარიფის ტიპი</Label>
            <RadioGroup value={rateType} onValueChange={(v) => setRateType(v as RateType)} className="flex gap-6 mt-2">
              <div className="flex items-center gap-2">
                <RadioGroupItem value="hourly" id="hourly" />
                <Label htmlFor="hourly" className="font-normal cursor-pointer">საათობრივი</Label>
              </div>
              <div className="flex items-center gap-2">
                <RadioGroupItem value="daily" id="daily" />
                <Label htmlFor="daily" className="font-normal cursor-pointer">დღიური</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>ტარიფი (₾)</Label>
              <Input type="number" step="0.01" value={rate} onChange={(e) => setRate(e.target.value)} />
            </div>
            <div>
              <Label>{rateType === "hourly" ? "საათები" : "დღეები"} *</Label>
              <Input type="number" step="0.5" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>დამატებითი ბონუსები (₾)</Label>
              <Input type="number" step="0.01" value={bonuses} onChange={(e) => setBonuses(e.target.value)} />
            </div>
            <div>
              <Label>დაკავებები (₾)</Label>
              <Input type="number" step="0.01" value={deductions} onChange={(e) => setDeductions(e.target.value)} />
            </div>
          </div>

          <div>
            <Label>ასახვის რეჟიმი</Label>
            <RadioGroup value={mode} onValueChange={(v) => setMode(v as Mode)} className="flex flex-col gap-2 mt-2">
              <div className="flex items-center gap-2">
                <RadioGroupItem value="lump" id="lump" />
                <Label htmlFor="lump" className="font-normal cursor-pointer">ერთჯერადი ჩანაწერი - ერთ თვეში</Label>
              </div>
              <div className="flex items-center gap-2">
                <RadioGroupItem value="prorate" id="prorate" />
                <Label htmlFor="prorate" className="font-normal cursor-pointer">პრო-რეიტი - გადანაწილდეს თვეებში სამუშაო დღეების მიხედვით</Label>
              </div>
            </RadioGroup>
          </div>

          {mode === "lump" && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>თვე</Label>
                <Select value={String(targetMonth)} onValueChange={(v) => setTargetMonth(parseInt(v))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
                      <SelectItem key={m} value={String(m)}>{m}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>წელი</Label>
                <Input type="number" value={targetYear} onChange={(e) => setTargetYear(parseInt(e.target.value))} />
              </div>
            </div>
          )}

          <div>
            <Label>საფუძველი / კომენტარი *</Label>
            <Textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="მაგ. ბრძანება №..., ფაქტობრივი მუშაობის დადასტურება" />
          </div>

          <div className="rounded-lg border p-3 bg-muted/30 text-sm">
            <div className="flex justify-between"><span>სულ რეტროაქტიური ანაზღაურება:</span><span className="font-semibold">{totalAmount.toFixed(2)} ₾</span></div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>გაუქმება</Button>
          <Button onClick={handleSubmit} disabled={saving}>{saving ? "ინახება..." : "ასახვა"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
