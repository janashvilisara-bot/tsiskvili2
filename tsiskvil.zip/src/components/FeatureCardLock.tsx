import { Lock } from "lucide-react";
import { useFeatureAccess, sidebarFeatureMap } from "@/hooks/useFeatureAccess";
import { toast } from "sonner";

/**
 * Hook that returns lock status for a given route URL based on the company's feature plan.
 */
export function useFeatureLock() {
  const { enabledFeatures, isLoading } = useFeatureAccess();

  const isLocked = (url: string): boolean => {
    if (isLoading) return false;
    if (enabledFeatures.includes('__all__')) return false;
    const featureKey = sidebarFeatureMap[url];
    if (!featureKey) return false;
    return !enabledFeatures.includes(featureKey);
  };

  const handleLockedClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toast.error('ეს ფუნქცია არ არის ხელმისაწვდომი თქვენს გეგმაში');
  };

  return { isLocked, handleLockedClick };
}

/**
 * Overlay component to show lock on a card. 
 * Wrap the Card's content or place as absolute overlay.
 */
export function FeatureLockOverlay() {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-background/60 backdrop-blur-[2px] rounded-lg cursor-not-allowed">
      <div className="flex flex-col items-center gap-1.5">
        <div className="p-2.5 rounded-full bg-muted/80 border border-border">
          <Lock className="h-5 w-5 text-muted-foreground" />
        </div>
        <span className="text-[11px] font-medium text-muted-foreground">დალუქული</span>
      </div>
    </div>
  );
}
