import { useState } from "react";
import { 
  Users, Calendar, Clock, DollarSign, PlayCircle, RotateCcw, 
  CheckCircle2, XCircle, Info, Award, TrendingUp
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EmployeeDemo } from "./EmployeeDemo";
import { AttendanceDemo } from "./AttendanceDemo";
import { PayrollDemo } from "./PayrollDemo";
import { LeaveDemo } from "./LeaveDemo";
import { RecruitmentDemo } from "./RecruitmentDemo";
import { TrainingDemo } from "./TrainingDemo";

interface DemoScenario {
  id: string;
  title: string;
  description: string;
  icon: any;
  color: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  estimatedTime: string;
  component: any;
}

export const DemoMode = () => {
  const [selectedDemo, setSelectedDemo] = useState<string | null>(null);
  const [demoProgress, setDemoProgress] = useState<Record<string, boolean>>({});

  const scenarios: DemoScenario[] = [
    {
      id: "employee-registration",
      title: "თანამშრომლის რეგისტრაცია",
      description: "სცადეთ ახალი თანამშრომლის დამატება ტესტ მონაცემებით",
      icon: Users,
      color: "bg-blue-500",
      difficulty: "beginner",
      estimatedTime: "3 წუთი",
      component: EmployeeDemo
    },
    {
      id: "attendance-tracking",
      title: "დასწრების აღრიცხვა",
      description: "დააფიქსირეთ მოსვლა-წასვლა და დაგვიანება",
      icon: Clock,
      color: "bg-purple-500",
      difficulty: "beginner",
      estimatedTime: "2 წუთი",
      component: AttendanceDemo
    },
    {
      id: "leave-approval",
      title: "შვებულების დამტკიცება",
      description: "გადაამოწმეთ და დაამტკიცეთ შვებულების მოთხოვნა",
      icon: Calendar,
      color: "bg-green-500",
      difficulty: "intermediate",
      estimatedTime: "4 წუთი",
      component: LeaveDemo
    },
    {
      id: "payroll-calculation",
      title: "ხელფასის გაანგარიშება",
      description: "გაანგარიშეთ ხელფასი დასწრებისა და ზეგანაკვეთურის მიხედვით",
      icon: DollarSign,
      color: "bg-orange-500",
      difficulty: "advanced",
      estimatedTime: "5 წუთი",
      component: PayrollDemo
    },
    {
      id: "recruitment",
      title: "რეკრუტინგის პროცესი",
      description: "გაიარეთ რეკრუტინგის სრული ციკლი - ვაკანსიიდან მიღებამდე",
      icon: Award,
      color: "bg-rose-500",
      difficulty: "intermediate",
      estimatedTime: "4 წუთი",
      component: RecruitmentDemo
    },
    {
      id: "training",
      title: "ტრენინგების მართვა",
      description: "შექმენით ტრენინგი, აირჩიეთ მონაწილეები და შეაფასეთ",
      icon: TrendingUp,
      color: "bg-teal-500",
      difficulty: "intermediate",
      estimatedTime: "3 წუთი",
      component: TrainingDemo
    }
  ];

  const completedCount = Object.values(demoProgress).filter(Boolean).length;
  const completionPercentage = (completedCount / scenarios.length) * 100;

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-500/10 text-green-600 border-green-500/20";
      case "intermediate": return "bg-yellow-500/10 text-yellow-600 border-yellow-500/20";
      case "advanced": return "bg-red-500/10 text-red-600 border-red-500/20";
      default: return "";
    }
  };

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "დამწყები";
      case "intermediate": return "საშუალო";
      case "advanced": return "მოწინავე";
      default: return "";
    }
  };

  const handleDemoComplete = (demoId: string) => {
    setDemoProgress(prev => ({ ...prev, [demoId]: true }));
  };

  const handleReset = () => {
    setDemoProgress({});
    setSelectedDemo(null);
  };

  const selectedScenario = scenarios.find(s => s.id === selectedDemo);

  return (
    <div className="space-y-6">
      <Alert className="border-blue-500/20 bg-blue-500/5">
        <Info className="h-4 w-4 text-blue-500" />
        <AlertDescription className="ml-2">
          <strong>დემო რეჟიმი:</strong> ეს არის სასწავლო გარემო სადაც ყველა ქმედება უსაფრთხოა და არ მოქმედებს რეალურ მონაცემებზე. 
          თამამად ცადეთ ყველა ფუნქციონალი!
        </AlertDescription>
      </Alert>

      {/* Progress Overview */}
      <Card className="border-primary/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Award className="h-6 w-6 text-primary" />
              </div>
              <div>
                <CardTitle>თქვენი პროგრესი</CardTitle>
                <CardDescription>გაიარეთ ყველა სიმულაცია ფუნქციონალის დასაუფლებლად</CardDescription>
              </div>
            </div>
            {completedCount > 0 && (
              <Button variant="outline" size="sm" onClick={handleReset}>
                <RotateCcw className="h-4 w-4 mr-2" />
                გადატვირთვა
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">დასრულებული სიმულაციები</span>
              <span className="font-semibold">{completedCount} / {scenarios.length}</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-primary to-green-500 transition-all duration-500 rounded-full"
                style={{ width: `${completionPercentage}%` }}
              />
            </div>
            {completionPercentage === 100 && (
              <div className="flex items-center gap-2 text-green-600 mt-3 animate-fade-in">
                <CheckCircle2 className="h-5 w-5" />
                <span className="font-semibold">მშვენიერია! გაიარეთ ყველა დემო სიმულაცია! 🎉</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {!selectedDemo ? (
        <div className="grid gap-4 md:grid-cols-2">
          {scenarios.map((scenario) => {
            const Icon = scenario.icon;
            const isCompleted = demoProgress[scenario.id];

            return (
              <Card 
                key={scenario.id}
                className={`cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 ${
                  isCompleted ? 'border-green-500/30 bg-green-500/5' : ''
                }`}
                onClick={() => setSelectedDemo(scenario.id)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className={`w-14 h-14 rounded-lg ${scenario.color} flex items-center justify-center text-white relative`}>
                      <Icon className="h-7 w-7" />
                      {isCompleted && (
                        <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
                          <CheckCircle2 className="h-4 w-4 text-white" />
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col gap-2">
                      <Badge variant="outline" className={getDifficultyColor(scenario.difficulty)}>
                        {getDifficultyLabel(scenario.difficulty)}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        <Clock className="h-3 w-3 mr-1" />
                        {scenario.estimatedTime}
                      </Badge>
                    </div>
                  </div>
                  <CardTitle className="mt-4">{scenario.title}</CardTitle>
                  <CardDescription>{scenario.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full gap-2"
                    variant={isCompleted ? "outline" : "default"}
                  >
                    <PlayCircle className="h-4 w-4" />
                    {isCompleted ? 'ხელახლა გაშვება' : 'დაწყება'}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card className="animate-fade-in">
          <CardHeader className="bg-gradient-to-r from-primary/5 to-accent/5 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {(() => {
                  const Icon = selectedScenario?.icon;
                  return (
                    <>
                      <div className={`w-12 h-12 rounded-lg ${selectedScenario?.color} flex items-center justify-center text-white`}>
                        {Icon && <Icon className="h-6 w-6" />}
                      </div>
                      <div>
                        <CardTitle className="text-2xl">{selectedScenario?.title}</CardTitle>
                        <CardDescription className="text-base mt-1">
                          ინტერაქტიული დემო სიმულაცია
                        </CardDescription>
                      </div>
                    </>
                  );
                })()}
              </div>
              <Button 
                variant="outline" 
                onClick={() => setSelectedDemo(null)}
              >
                უკან დაბრუნება
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            {selectedScenario && (
              <selectedScenario.component 
                onComplete={() => handleDemoComplete(selectedScenario.id)}
              />
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};
