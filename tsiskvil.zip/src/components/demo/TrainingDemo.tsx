import { useState } from "react";
import { CheckCircle2, GraduationCap, BookOpen, Award, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";

interface TrainingDemoProps {
  onComplete: () => void;
}

export const TrainingDemo = ({ onComplete }: TrainingDemoProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [trainingName, setTrainingName] = useState("");
  const [trainingType, setTrainingType] = useState("");
  const [participants, setParticipants] = useState<string[]>([]);
  const [feedback, setFeedback] = useState("");
  const [score, setScore] = useState("");
  const { toast } = useToast();

  const availableEmployees = [
    "გიორგი მელაძე", "ანა ბერიძე", "ნიკა გელაშვილი", 
    "მარიამ კაპანაძე", "დავით ჯანელიძე"
  ];

  const steps = [
    { title: "ტრენინგის შექმნა", icon: GraduationCap },
    { title: "მონაწილეების არჩევა", icon: Users },
    { title: "შეფასება და უკუკავშირი", icon: Award },
  ];

  const fillTestData = () => {
    setTrainingName("React Advanced Patterns");
    setTrainingType("technical");
    setParticipants(["გიორგი მელაძე", "ანა ბერიძე"]);
    toast({ title: "ტესტ მონაცემები შევსებულია" });
  };

  const toggleParticipant = (name: string) => {
    setParticipants(prev => 
      prev.includes(name) ? prev.filter(p => p !== name) : [...prev, name]
    );
  };

  const handleComplete = () => {
    setIsCompleted(true);
    onComplete();
    toast({
      title: "ტრენინგი წარმატებით დასრულდა! 🎓",
      description: `${participants.length} მონაწილე გაიარა ტრენინგი`,
    });
  };

  if (isCompleted) {
    return (
      <div className="text-center space-y-6 py-8">
        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center animate-scale-in">
            <CheckCircle2 className="h-12 w-12 text-green-500" />
          </div>
        </div>
        <h3 className="text-2xl font-bold">ტრენინგი დასრულდა!</h3>
        <Card className="p-4 bg-muted/50 max-w-md mx-auto text-left">
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">ტრენინგი:</span><span className="font-medium">{trainingName}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">მონაწილეები:</span><span className="font-medium">{participants.length}</span></div>
            {score && <div className="flex justify-between"><span className="text-muted-foreground">შეფასება:</span><Badge>{score}/10</Badge></div>}
          </div>
        </Card>
        <Button onClick={() => { setIsCompleted(false); setCurrentStep(0); }}>კიდევ ერთხელ ცდა</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Alert>
        {(() => { const Icon = steps[currentStep].icon; return <Icon className="h-4 w-4" />; })()}
        <AlertDescription className="ml-2">
          <strong>ნაბიჯი {currentStep + 1} / {steps.length}:</strong> {steps[currentStep].title}
        </AlertDescription>
      </Alert>

      <Progress value={((currentStep + 1) / steps.length) * 100} className="h-1.5" />

      <div className="space-y-4">
        {currentStep === 0 && (
          <div className="space-y-4 animate-fade-in">
            <Button type="button" variant="outline" onClick={fillTestData} className="w-full">ტესტ მონაცემების შევსება</Button>
            <div className="space-y-2">
              <Label>ტრენინგის სახელი *</Label>
              <Input value={trainingName} onChange={(e) => setTrainingName(e.target.value)} placeholder="მაგ: React Advanced Patterns" />
            </div>
            <div className="space-y-2">
              <Label>ტიპი *</Label>
              <Select value={trainingType} onValueChange={setTrainingType}>
                <SelectTrigger><SelectValue placeholder="აირჩიეთ" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="technical">ტექნიკური</SelectItem>
                  <SelectItem value="soft_skills">რბილი უნარები</SelectItem>
                  <SelectItem value="management">მენეჯმენტი</SelectItem>
                  <SelectItem value="compliance">კომპლაიანსი</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )}

        {currentStep === 1 && (
          <div className="space-y-4 animate-fade-in">
            <p className="text-sm text-muted-foreground">აირჩიეთ მონაწილეები ({participants.length} არჩეული)</p>
            <div className="space-y-2">
              {availableEmployees.map((name) => (
                <Card 
                  key={name}
                  className={`p-3 cursor-pointer transition-all ${participants.includes(name) ? 'border-primary bg-primary/5' : 'hover:bg-muted/50'}`}
                  onClick={() => toggleParticipant(name)}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${participants.includes(name) ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                      {participants.includes(name) ? <CheckCircle2 className="h-4 w-4" /> : <Users className="h-4 w-4" />}
                    </div>
                    <span className="font-medium text-sm">{name}</span>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-4 animate-fade-in">
            <div className="space-y-2">
              <Label>შეფასება (1-10) *</Label>
              <Input type="number" min="1" max="10" value={score} onChange={(e) => setScore(e.target.value)} placeholder="1-10" />
            </div>
            <div className="space-y-2">
              <Label>უკუკავშირი</Label>
              <Textarea value={feedback} onChange={(e) => setFeedback(e.target.value)} placeholder="ტრენინგის შეფასება..." rows={3} />
            </div>
          </div>
        )}
      </div>

      <div className="flex gap-2 pt-4">
        {currentStep > 0 && <Button variant="outline" onClick={() => setCurrentStep(currentStep - 1)} className="flex-1">უკან</Button>}
        {currentStep < steps.length - 1 ? (
          <Button onClick={() => setCurrentStep(currentStep + 1)} className="flex-1" disabled={currentStep === 1 && participants.length === 0}>შემდეგი</Button>
        ) : (
          <Button onClick={handleComplete} disabled={!score} className="flex-1">დასრულება</Button>
        )}
      </div>
    </div>
  );
};
