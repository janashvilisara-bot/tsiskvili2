import { useState } from "react";
import { CheckCircle2, DollarSign, TrendingUp, Clock, Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

interface PayrollDemoProps {
  onComplete: () => void;
}

export const PayrollDemo = ({ onComplete }: PayrollDemoProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [bonus, setBonus] = useState(0);
  const [overtime, setOvertime] = useState(0);
  const [calculated, setCalculated] = useState(false);
  const { toast } = useToast();

  const employee = {
    name: "დავით ხუციშვილი",
    position: "სპეციალისტი",
    baseSalary: 2000,
    workDays: 22,
    workedDays: 20,
    regularHours: 160,
    workedHours: 155,
    overtimeRate: 1.5,
  };

  const calculatePayroll = () => {
    const basePay = (employee.baseSalary / employee.workDays) * employee.workedDays;
    const overtimePay = (employee.baseSalary / employee.regularHours) * overtime * employee.overtimeRate;
    const totalGross = basePay + bonus + overtimePay;
    const tax = totalGross * 0.20; // 20% საშემოსავლო გადასახადი
    const pension = totalGross * 0.02; // 2% პენსია
    const totalNet = totalGross - tax - pension;

    return {
      basePay: basePay.toFixed(2),
      overtimePay: overtimePay.toFixed(2),
      totalGross: totalGross.toFixed(2),
      tax: tax.toFixed(2),
      pension: pension.toFixed(2),
      totalNet: totalNet.toFixed(2),
    };
  };

  const payroll = calculatePayroll();

  const steps = [
    {
      title: "შეამოწმეთ სამუშაო დღეები",
      description: "დარწმუნდით რომ სწორად არის აღრიცხული",
    },
    {
      title: "დაამატეთ დამატებითი გადასახდელები",
      description: "ბონუსები და ზეგანაკვეთური",
    },
    {
      title: "გაანგარიშება",
      description: "ავტომატური გაანგარიშება",
    },
  ];

  const handleCalculate = () => {
    setCalculated(true);
    onComplete();
    toast({
      title: "ხელფასი გაანგარიშებულია! 💰",
      description: "ყველა პარამეტრი გათვალისწინებულია",
    });
  };

  if (calculated) {
    return (
      <div className="space-y-6 py-8">
        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center animate-scale-in">
            <CheckCircle2 className="h-12 w-12 text-green-500" />
          </div>
        </div>
        <div className="text-center">
          <h3 className="text-2xl font-bold mb-2">ხელფასი წარმატებით გაანგარიშდა!</h3>
          <p className="text-muted-foreground">{employee.name} - {employee.position}</p>
        </div>

        <Card className="bg-muted/50">
          <CardContent className="pt-6 space-y-4">
            <div className="grid grid-cols-2 gap-4 pb-4 border-b">
              <div>
                <span className="text-sm text-muted-foreground">სამუშაო დღეები</span>
                <p className="font-medium">{employee.workedDays} / {employee.workDays}</p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">სამუშაო საათები</span>
                <p className="font-medium">{employee.workedHours} / {employee.regularHours}</p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">საბაზო ხელფასი:</span>
                <span className="font-medium">{payroll.basePay} ₾</span>
              </div>
              {bonus > 0 && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ბონუსი:</span>
                  <span className="font-medium text-green-600">+{bonus} ₾</span>
                </div>
              )}
              {overtime > 0 && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ზეგანაკვეთური ({overtime} სთ):</span>
                  <span className="font-medium text-green-600">+{payroll.overtimePay} ₾</span>
                </div>
              )}
              <div className="flex justify-between pt-3 border-t font-semibold">
                <span>ჯამური მთლიანი:</span>
                <span>{payroll.totalGross} ₾</span>
              </div>
            </div>

            <div className="space-y-3 pt-4 border-t">
              <div className="flex justify-between text-red-600">
                <span>საშემოსავლო გადასახადი (20%):</span>
                <span>-{payroll.tax} ₾</span>
              </div>
              <div className="flex justify-between text-red-600">
                <span>პენსია (2%):</span>
                <span>-{payroll.pension} ₾</span>
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t text-lg font-bold">
              <span>საბოლოო თანხა:</span>
              <span className="text-primary">{payroll.totalNet} ₾</span>
            </div>
          </CardContent>
        </Card>

        <Button className="w-full" onClick={() => {
          setCalculated(false);
          setCurrentStep(0);
          setBonus(0);
          setOvertime(0);
        }}>
          კიდევ ერთხელ ცდა
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Alert>
        <Calculator className="h-4 w-4" />
        <AlertDescription className="ml-2">
          <strong>ნაბიჯი {currentStep + 1} / {steps.length}:</strong> {steps[currentStep].description}
        </AlertDescription>
      </Alert>

      <Card className="bg-muted/30">
        <CardContent className="pt-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <DollarSign className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h4 className="font-semibold">{employee.name}</h4>
              <p className="text-sm text-muted-foreground">{employee.position}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">თვიური ხელფასი:</span>
              <p className="font-semibold text-lg">{employee.baseSalary} ₾</p>
            </div>
            <div>
              <span className="text-muted-foreground">საათობრივი განაკვეთი:</span>
              <p className="font-medium">{(employee.baseSalary / employee.regularHours).toFixed(2)} ₾</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {currentStep === 0 && (
          <div className="space-y-4 animate-fade-in">
            <Card>
              <CardContent className="pt-6 space-y-3">
                <div className="flex justify-between items-center">
                  <span>სამუშაო დღეები:</span>
                  <Badge variant="outline">
                    {employee.workedDays} / {employee.workDays}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>სამუშაო საათები:</span>
                  <Badge variant="outline">
                    {employee.workedHours} / {employee.regularHours}
                  </Badge>
                </div>
                {employee.workedDays < employee.workDays && (
                  <Alert className="border-orange-500/20 bg-orange-500/5">
                    <AlertDescription className="text-sm">
                      ⚠️ არ ყოფილა {employee.workDays - employee.workedDays} დღე - ანაზღაურება შემცირდება პროპორციულად
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {currentStep === 1 && (
          <div className="space-y-4 animate-fade-in">
            <div className="space-y-2">
              <Label htmlFor="bonus">ბონუსი (₾)</Label>
              <Input
                id="bonus"
                type="number"
                min="0"
                value={bonus}
                onChange={(e) => setBonus(Number(e.target.value))}
                placeholder="0"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="overtime">ზეგანაკვეთური საათები</Label>
              <Input
                id="overtime"
                type="number"
                min="0"
                value={overtime}
                onChange={(e) => setOvertime(Number(e.target.value))}
                placeholder="0"
              />
              {overtime > 0 && (
                <p className="text-xs text-muted-foreground">
                  ზეგანაკვეთური განაკვეთი: {employee.overtimeRate}x 
                  = {((employee.baseSalary / employee.regularHours) * employee.overtimeRate).toFixed(2)} ₾/სთ
                </p>
              )}
            </div>

            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => {
                setBonus(500);
                setOvertime(10);
              }}
            >
              ტესტ მონაცემების შევსება
            </Button>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-4 animate-fade-in">
            <Alert className="border-blue-500/20 bg-blue-500/5">
              <TrendingUp className="h-4 w-4 text-blue-500" />
              <AlertDescription className="ml-2">
                <strong>გაანგარიშების შემაჯამებელი:</strong>
                <div className="mt-2 space-y-1 text-sm">
                  <div>• საბაზო ხელფასი: {payroll.basePay} ₾</div>
                  {bonus > 0 && <div>• ბონუსი: +{bonus} ₾</div>}
                  {overtime > 0 && <div>• ზეგანაკვეთური: +{payroll.overtimePay} ₾</div>}
                  <div className="font-semibold pt-2">სულ: {payroll.totalGross} ₾</div>
                </div>
              </AlertDescription>
            </Alert>
          </div>
        )}
      </div>

      <div className="flex gap-2 pt-4">
        {currentStep > 0 && (
          <Button
            variant="outline"
            onClick={() => setCurrentStep(currentStep - 1)}
            className="flex-1"
          >
            უკან
          </Button>
        )}
        {currentStep < steps.length - 1 ? (
          <Button onClick={() => setCurrentStep(currentStep + 1)} className="flex-1">
            შემდეგი
          </Button>
        ) : (
          <Button onClick={handleCalculate} className="flex-1">
            გაანგარიშება
          </Button>
        )}
      </div>
    </div>
  );
};
