import { useState } from "react";
import { CheckCircle2, Briefcase, Search, UserPlus, Star, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

interface RecruitmentDemoProps {
  onComplete: () => void;
}

export const RecruitmentDemo = ({ onComplete }: RecruitmentDemoProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [vacancyTitle, setVacancyTitle] = useState("");
  const [department, setDepartment] = useState("");
  const [candidateName, setCandidateName] = useState("");
  const [candidateEmail, setCandidateEmail] = useState("");
  const [interviewNotes, setInterviewNotes] = useState("");
  const [decision, setDecision] = useState("");
  const { toast } = useToast();

  const steps = [
    { title: "ვაკანსიის შექმნა", description: "შექმენით ახალი სამუშაო ვაკანსია", icon: Briefcase },
    { title: "კანდიდატის დამატება", description: "დაამატეთ კანდიდატი ვაკანსიაზე", icon: UserPlus },
    { title: "გასაუბრების შეფასება", description: "შეაფასეთ კანდიდატი გასაუბრების შემდეგ", icon: MessageSquare },
    { title: "გადაწყვეტილება", description: "მიიღეთ გადაწყვეტილება კანდიდატის შესახებ", icon: Star },
  ];

  const fillTestData = () => {
    setVacancyTitle("Senior React Developer");
    setDepartment("IT");
    setCandidateName("ანა ბერიძე");
    setCandidateEmail("ana.beridze@example.ge");
    toast({ title: "ტესტ მონაცემები შევსებულია" });
  };

  const handleComplete = () => {
    setIsCompleted(true);
    onComplete();
    toast({
      title: "რეკრუტინგის პროცესი დასრულებულია! 🎉",
      description: `კანდიდატი ${candidateName} - ${decision === "hire" ? "მიღებულია" : "უარყოფილია"}`,
    });
  };

  if (isCompleted) {
    return (
      <div className="text-center space-y-6 py-8">
        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center animate-scale-in">
            <CheckCircle2 className="h-12 w-12 text-green-500" />
          </div>
        </div>
        <div>
          <h3 className="text-2xl font-bold mb-2">რეკრუტინგი დასრულდა!</h3>
          <p className="text-muted-foreground">სრული ციკლი წარმატებით გაიარეთ</p>
        </div>
        <Card className="p-4 bg-muted/50 max-w-md mx-auto text-left">
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">ვაკანსია:</span>
              <span className="font-medium">{vacancyTitle}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">კანდიდატი:</span>
              <span className="font-medium">{candidateName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">გადაწყვეტილება:</span>
              <Badge variant={decision === "hire" ? "default" : "destructive"}>
                {decision === "hire" ? "მიღებული" : "უარყოფილი"}
              </Badge>
            </div>
          </div>
        </Card>
        <Button onClick={() => { setIsCompleted(false); setCurrentStep(0); }}>
          კიდევ ერთხელ ცდა
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Alert>
        {(() => { const Icon = steps[currentStep].icon; return <Icon className="h-4 w-4" />; })()}
        <AlertDescription className="ml-2">
          <strong>ნაბიჯი {currentStep + 1} / {steps.length}:</strong> {steps[currentStep].description}
        </AlertDescription>
      </Alert>

      <div className="space-y-4">
        {currentStep === 0 && (
          <div className="space-y-4 animate-fade-in">
            <Button type="button" variant="outline" onClick={fillTestData} className="w-full">
              ტესტ მონაცემების შევსება
            </Button>
            <div className="space-y-2">
              <Label>ვაკანსიის სახელი *</Label>
              <Input value={vacancyTitle} onChange={(e) => setVacancyTitle(e.target.value)} placeholder="მაგ: Senior Developer" />
            </div>
            <div className="space-y-2">
              <Label>დეპარტამენტი *</Label>
              <Select value={department} onValueChange={setDepartment}>
                <SelectTrigger><SelectValue placeholder="აირჩიეთ" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="IT">IT დეპარტამენტი</SelectItem>
                  <SelectItem value="HR">HR დეპარტამენტი</SelectItem>
                  <SelectItem value="Finance">ფინანსები</SelectItem>
                  <SelectItem value="Sales">გაყიდვები</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )}

        {currentStep === 1 && (
          <div className="space-y-4 animate-fade-in">
            <Card className="bg-muted/30 p-4">
              <p className="text-sm text-muted-foreground mb-2">ვაკანსია: <strong>{vacancyTitle}</strong></p>
            </Card>
            <div className="space-y-2">
              <Label>კანდიდატის სახელი *</Label>
              <Input value={candidateName} onChange={(e) => setCandidateName(e.target.value)} placeholder="სახელი გვარი" />
            </div>
            <div className="space-y-2">
              <Label>ემაილი *</Label>
              <Input type="email" value={candidateEmail} onChange={(e) => setCandidateEmail(e.target.value)} placeholder="email@example.ge" />
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-4 animate-fade-in">
            <Card className="bg-muted/30 p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <UserPlus className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium">{candidateName}</p>
                  <p className="text-xs text-muted-foreground">{candidateEmail}</p>
                </div>
              </div>
            </Card>
            <div className="space-y-2">
              <Label>გასაუბრების შენიშვნები</Label>
              <Textarea
                value={interviewNotes}
                onChange={(e) => setInterviewNotes(e.target.value)}
                placeholder="შეაფასეთ კანდიდატის კომპეტენციები..."
                rows={4}
              />
            </div>
          </div>
        )}

        {currentStep === 3 && (
          <div className="space-y-4 animate-fade-in">
            <Card className="bg-muted/30 p-4">
              <div className="space-y-2 text-sm">
                <p><strong>ვაკანსია:</strong> {vacancyTitle}</p>
                <p><strong>კანდიდატი:</strong> {candidateName}</p>
                {interviewNotes && <p><strong>შენიშვნები:</strong> {interviewNotes}</p>}
              </div>
            </Card>
            <div className="space-y-2">
              <Label>გადაწყვეტილება *</Label>
              <Select value={decision} onValueChange={setDecision}>
                <SelectTrigger><SelectValue placeholder="აირჩიეთ" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="hire">✅ მიღება</SelectItem>
                  <SelectItem value="reject">❌ უარყოფა</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )}
      </div>

      <div className="flex gap-2 pt-4">
        {currentStep > 0 && (
          <Button type="button" variant="outline" onClick={() => setCurrentStep(currentStep - 1)} className="flex-1">
            უკან
          </Button>
        )}
        {currentStep < steps.length - 1 ? (
          <Button onClick={() => setCurrentStep(currentStep + 1)} className="flex-1">
            შემდეგი
          </Button>
        ) : (
          <Button onClick={handleComplete} disabled={!decision} className="flex-1">
            დასრულება
          </Button>
        )}
      </div>
    </div>
  );
};
