import { useState } from "react";
import { CheckCircle2, Calendar, User, Clock, FileText, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { format, addDays } from "date-fns";

interface LeaveDemoProps {
  onComplete: () => void;
}

export const LeaveDemo = ({ onComplete }: LeaveDemoProps) => {
  const [decision, setDecision] = useState<"approved" | "rejected" | null>(null);
  const [comment, setComment] = useState("");
  const { toast } = useToast();

  const leaveRequest = {
    employee: "ნინო გელაშვილი",
    position: "მენეჯერი",
    department: "გაყიდვების დეპარტამენტი",
    leaveType: "ანაზღაურებადი შვებულება",
    startDate: format(addDays(new Date(), 7), 'dd/MM/yyyy'),
    endDate: format(addDays(new Date(), 14), 'dd/MM/yyyy'),
    days: 7,
    reason: "ოჯახთან დასასვენებლად",
    balance: 15,
  };

  const handleApprove = () => {
    if (!comment.trim()) {
      toast({
        title: "შეცდომა",
        description: "გთხოვთ დაამატოთ კომენტარი",
        variant: "destructive",
      });
      return;
    }
    setDecision("approved");
    onComplete();
    toast({
      title: "შვებულება დამტკიცებულია! ✅",
      description: "თანამშრომელს გაეგზავნება შეტყობინება",
    });
  };

  const handleReject = () => {
    if (!comment.trim()) {
      toast({
        title: "შეცდომა",
        description: "უარყოფისას აუცილებელია მიზეზის მითითება",
        variant: "destructive",
      });
      return;
    }
    setDecision("rejected");
    onComplete();
    toast({
      title: "შვებულება უარყოფილია",
      description: "თანამშრომელს გაეგზავნება შეტყობინება უარყოფის მიზეზით",
    });
  };

  if (decision) {
    return (
      <div className="text-center space-y-6 py-8">
        <div className="flex justify-center">
          <div className={`w-20 h-20 rounded-full ${
            decision === "approved" ? "bg-green-500/10" : "bg-red-500/10"
          } flex items-center justify-center animate-scale-in`}>
            {decision === "approved" ? (
              <CheckCircle2 className="h-12 w-12 text-green-500" />
            ) : (
              <XCircle className="h-12 w-12 text-red-500" />
            )}
          </div>
        </div>
        <div>
          <h3 className="text-2xl font-bold mb-2">
            {decision === "approved" ? "შვებულება დამტკიცებულია!" : "შვებულება უარყოფილია"}
          </h3>
          <p className="text-muted-foreground">
            თანამშრომელს გაეგზავნა შეტყობინება თქვენი გადაწყვეტილების შესახებ
          </p>
        </div>
        <Card className="p-6 bg-muted/50 max-w-md mx-auto">
          <CardContent className="space-y-4 p-0">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">სტატუსი:</span>
              <Badge variant={decision === "approved" ? "default" : "destructive"}>
                {decision === "approved" ? "დამტკიცებული" : "უარყოფილი"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">თანამშრომელი:</span>
              <span className="font-medium">{leaveRequest.employee}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">პერიოდი:</span>
              <span className="font-medium">{leaveRequest.startDate} - {leaveRequest.endDate}</span>
            </div>
            <div className="text-left pt-3 border-t">
              <span className="text-sm text-muted-foreground">თქვენი კომენტარი:</span>
              <p className="text-sm mt-1">{comment}</p>
            </div>
          </CardContent>
        </Card>
        <Button onClick={() => {
          setDecision(null);
          setComment("");
        }}>
          კიდევ ერთხელ ცდა
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Alert className="border-blue-500/20 bg-blue-500/5">
        <Calendar className="h-4 w-4 text-blue-500" />
        <AlertDescription className="ml-2">
          გადაამოწმეთ შვებულების მოთხოვნა და მიიღეთ გადაწყვეტილება
        </AlertDescription>
      </Alert>

      <Card>
        <CardContent className="pt-6 space-y-4">
          <div className="flex items-center justify-between pb-4 border-b">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h4 className="font-semibold">{leaveRequest.employee}</h4>
                <p className="text-sm text-muted-foreground">{leaveRequest.position}</p>
              </div>
            </div>
            <Badge>{leaveRequest.leaveType}</Badge>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <span className="text-sm text-muted-foreground">დაწყების თარიღი</span>
              <p className="font-medium flex items-center gap-2 mt-1">
                <Calendar className="h-4 w-4" />
                {leaveRequest.startDate}
              </p>
            </div>
            <div>
              <span className="text-sm text-muted-foreground">დასრულების თარიღი</span>
              <p className="font-medium flex items-center gap-2 mt-1">
                <Calendar className="h-4 w-4" />
                {leaveRequest.endDate}
              </p>
            </div>
            <div>
              <span className="text-sm text-muted-foreground">დღეების რაოდენობა</span>
              <p className="font-medium flex items-center gap-2 mt-1">
                <Clock className="h-4 w-4" />
                {leaveRequest.days} დღე
              </p>
            </div>
            <div>
              <span className="text-sm text-muted-foreground">ხელმისაწვდომი ბალანსი</span>
              <p className={`font-medium flex items-center gap-2 mt-1 ${
                leaveRequest.balance >= leaveRequest.days ? "text-green-600" : "text-red-600"
              }`}>
                {leaveRequest.balance} დღე
              </p>
            </div>
          </div>

          <div className="pt-4 border-t">
            <span className="text-sm text-muted-foreground flex items-center gap-2 mb-2">
              <FileText className="h-4 w-4" />
              მოთხოვნის მიზეზი
            </span>
            <p className="text-sm bg-muted/50 p-3 rounded-lg">{leaveRequest.reason}</p>
          </div>

          {leaveRequest.balance < leaveRequest.days && (
            <Alert className="border-orange-500/20 bg-orange-500/5">
              <AlertDescription>
                ⚠️ გაფრთხილება: მოთხოვნილი დღეები აღემატება ხელმისაწვდომ ბალანსს
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="comment">კომენტარი *</Label>
          <Textarea
            id="comment"
            placeholder="დაამატეთ კომენტარი გადაწყვეტილების შესახებ..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            rows={4}
            maxLength={500}
          />
          <p className="text-xs text-muted-foreground">
            {comment.length}/500 სიმბოლო
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Button
            variant="outline"
            className="border-red-500/20 hover:bg-red-500/10 hover:text-red-600"
            onClick={handleReject}
          >
            <XCircle className="h-4 w-4 mr-2" />
            უარყოფა
          </Button>
          <Button
            className="bg-green-600 hover:bg-green-700"
            onClick={handleApprove}
          >
            <CheckCircle2 className="h-4 w-4 mr-2" />
            დამტკიცება
          </Button>
        </div>
      </div>
    </div>
  );
};
