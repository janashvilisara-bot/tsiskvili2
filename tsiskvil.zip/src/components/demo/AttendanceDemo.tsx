import { useState } from "react";
import { CheckCircle2, Clock, Calendar, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface AttendanceDemoProps {
  onComplete: () => void;
}

export const AttendanceDemo = ({ onComplete }: AttendanceDemoProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [arrivalTime, setArrivalTime] = useState("09:00");
  const [departureTime, setDepartureTime] = useState("18:00");
  const [isLate, setIsLate] = useState(false);
  const [lateReason, setLateReason] = useState("");
  const [isCompleted, setIsCompleted] = useState(false);
  const { toast } = useToast();

  const employee = {
    name: "გიორგი მელაძე",
    position: "დეველოპერი",
    department: "IT დეპარტამენტი",
    scheduledStart: "09:00",
    scheduledEnd: "18:00",
  };

  const steps = [
    {
      title: "აირჩიეთ თარიღი",
      description: "აირჩიეთ დასწრების რეგისტრაციის თარიღი",
    },
    {
      title: "დააფიქსირეთ მოსვლა",
      description: "შეიყვანეთ თანამშრომლის მოსვლის დრო",
    },
    {
      title: "დაგვიანების შემოწმება",
      description: "შეამოწმეთ არის თუ არა დაგვიანება",
    },
    {
      title: "დააფიქსირეთ წასვლა",
      description: "შეიყვანეთ თანამშრომლის წასვლის დრო",
    },
  ];

  const handleComplete = () => {
    setIsCompleted(true);
    onComplete();
    toast({
      title: "დასწრება აღრიცხულია! ✅",
      description: "თანამშრომლის დასწრება წარმატებით დაფიქსირდა",
    });
  };

  const checkIfLate = () => {
    const [schedHour, schedMin] = employee.scheduledStart.split(':').map(Number);
    const [arrHour, arrMin] = arrivalTime.split(':').map(Number);
    
    const schedMinutes = schedHour * 60 + schedMin;
    const arrMinutes = arrHour * 60 + arrMin;
    
    return arrMinutes > schedMinutes;
  };

  if (isCompleted) {
    const totalHours = (() => {
      const [arrHour, arrMin] = arrivalTime.split(':').map(Number);
      const [depHour, depMin] = departureTime.split(':').map(Number);
      const arrMinutes = arrHour * 60 + arrMin;
      const depMinutes = depHour * 60 + depMin;
      const diff = depMinutes - arrMinutes;
      return (diff / 60).toFixed(1);
    })();

    return (
      <div className="text-center space-y-6 py-8">
        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center animate-scale-in">
            <CheckCircle2 className="h-12 w-12 text-green-500" />
          </div>
        </div>
        <div>
          <h3 className="text-2xl font-bold mb-2">დასწრება აღრიცხულია!</h3>
          <p className="text-muted-foreground">
            წარმატებით დაფიქსირდა {employee.name}-ის დასწრება
          </p>
        </div>
        <Card className="p-6 bg-muted/50 max-w-md mx-auto">
          <CardContent className="space-y-4 p-0">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">თანამშრომელი:</span>
              <span className="font-medium">{employee.name}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">თარიღი:</span>
              <span className="font-medium">{format(new Date(), 'dd/MM/yyyy')}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">მოსვლა:</span>
              <span className="font-medium">{arrivalTime}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">წასვლა:</span>
              <span className="font-medium">{departureTime}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">სამუშაო საათები:</span>
              <span className="font-semibold text-primary">{totalHours} საათი</span>
            </div>
            {isLate && (
              <Alert className="border-orange-500/20 bg-orange-500/5">
                <AlertTriangle className="h-4 w-4 text-orange-500" />
                <AlertDescription className="ml-2 text-sm">
                  <strong>დაგვიანება:</strong> {lateReason}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
        <Button onClick={() => {
          setIsCompleted(false);
          setCurrentStep(0);
          setIsLate(false);
          setLateReason("");
        }}>
          კიდევ ერთხელ ცდა
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Alert>
        <Clock className="h-4 w-4" />
        <AlertDescription className="ml-2">
          <strong>ნაბიჯი {currentStep + 1} / {steps.length}:</strong> {steps[currentStep].description}
        </AlertDescription>
      </Alert>

      <Card className="bg-muted/30">
        <CardContent className="pt-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Clock className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h4 className="font-semibold">{employee.name}</h4>
              <p className="text-sm text-muted-foreground">{employee.position}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">გრაფიკის დაწყება:</span>
              <p className="font-medium">{employee.scheduledStart}</p>
            </div>
            <div>
              <span className="text-muted-foreground">გრაფიკის დასრულება:</span>
              <p className="font-medium">{employee.scheduledEnd}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {currentStep === 0 && (
          <div className="space-y-4 animate-fade-in">
            <div className="space-y-2">
              <Label>თარიღი</Label>
              <Input
                type="date"
                defaultValue={format(new Date(), 'yyyy-MM-dd')}
                disabled
              />
              <p className="text-xs text-muted-foreground">
                დემოსთვის გამოიყენება დღევანდელი თარიღი
              </p>
            </div>
          </div>
        )}

        {currentStep === 1 && (
          <div className="space-y-4 animate-fade-in">
            <div className="space-y-2">
              <Label htmlFor="arrival">მოსვლის დრო</Label>
              <Input
                id="arrival"
                type="time"
                value={arrivalTime}
                onChange={(e) => setArrivalTime(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                გრაფიკის მიხედვით: {employee.scheduledStart}
              </p>
            </div>
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => setArrivalTime("09:15")}
            >
              ტესტ დროის დაყენება (09:15 - დაგვიანებით)
            </Button>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-4 animate-fade-in">
            {checkIfLate() ? (
              <Alert className="border-orange-500/20 bg-orange-500/5">
                <AlertTriangle className="h-4 w-4 text-orange-500" />
                <AlertDescription className="ml-2">
                  <strong>დაგვიანება დაფიქსირდა!</strong><br />
                  თანამშრომელი მოვიდა {arrivalTime}-ზე, გრაფიკი იწყება {employee.scheduledStart}-ზე
                </AlertDescription>
              </Alert>
            ) : (
              <Alert className="border-green-500/20 bg-green-500/5">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <AlertDescription className="ml-2">
                  თანამშრომელი დროულად მოვიდა სამსახურში
                </AlertDescription>
              </Alert>
            )}

            {checkIfLate() && (
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="late"
                    checked={isLate}
                    onCheckedChange={(checked) => setIsLate(checked as boolean)}
                  />
                  <Label htmlFor="late">დააფიქსირე დაგვიანება</Label>
                </div>
                {isLate && (
                  <Textarea
                    placeholder="მიუთითეთ დაგვიანების მიზეზი..."
                    value={lateReason}
                    onChange={(e) => setLateReason(e.target.value)}
                    maxLength={200}
                  />
                )}
              </div>
            )}
          </div>
        )}

        {currentStep === 3 && (
          <div className="space-y-4 animate-fade-in">
            <div className="space-y-2">
              <Label htmlFor="departure">წასვლის დრო</Label>
              <Input
                id="departure"
                type="time"
                value={departureTime}
                onChange={(e) => setDepartureTime(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                გრაფიკის მიხედვით: {employee.scheduledEnd}
              </p>
            </div>
          </div>
        )}
      </div>

      <div className="flex gap-2 pt-4">
        {currentStep > 0 && (
          <Button
            type="button"
            variant="outline"
            onClick={() => setCurrentStep(currentStep - 1)}
            className="flex-1"
          >
            უკან
          </Button>
        )}
        {currentStep < steps.length - 1 ? (
          <Button
            onClick={() => setCurrentStep(currentStep + 1)}
            className="flex-1"
          >
            შემდეგი
          </Button>
        ) : (
          <Button onClick={handleComplete} className="flex-1">
            დასრულება
          </Button>
        )}
      </div>
    </div>
  );
};
