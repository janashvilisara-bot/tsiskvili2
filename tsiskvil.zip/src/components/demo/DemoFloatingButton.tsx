import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from "@/components/ui/popover";
import { 
  HelpCircle, 
  BookOpen, 
  RotateCcw, 
  LogOut,
  Gamepad2,
  Map
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useDemoMode } from "@/contexts/DemoContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export function DemoFloatingButton() {
  const navigate = useNavigate();
  const { isDemoMode, setDemoMode } = useDemoMode();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);

  if (!isDemoMode) return null;

  const handleExitDemo = async () => {
    await supabase.auth.signOut();
    setDemoMode(false);
    navigate("/demo-landing");
    toast({
      title: "დემო რეჟიმი დასრულდა",
      description: "მადლობა გამოცდისთვის!"
    });
  };

  const actions = [
    {
      icon: Map,
      label: "გაიდიანი ტური",
      description: "დაიწყეთ ტური თავიდან",
      onClick: () => {
        navigate("/dashboard");
        setIsOpen(false);
      }
    },
    {
      icon: Gamepad2,
      label: "სიმულატორი",
      description: "ინტერაქტიული სწავლება",
      onClick: () => {
        navigate("/simulator");
        setIsOpen(false);
      }
    },
    {
      icon: RotateCcw,
      label: "მონაცემების განახლება",
      description: "დაბრუნდით საწყის მდგომარეობაში",
      onClick: () => {
        toast({
          title: "მონაცემები განახლდა",
          description: "დემო მონაცემები აღდგენილია"
        });
        setIsOpen(false);
      }
    },
    {
      icon: LogOut,
      label: "დემოდან გამოსვლა",
      description: "დასრულეთ დემო სესია",
      onClick: handleExitDemo,
      variant: "destructive" as const
    }
  ];

  return (
    <div className="fixed bottom-4 left-4 z-50">
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button 
            size="lg"
            className="rounded-full h-14 w-14 shadow-xl bg-gradient-to-br from-primary to-accent hover:opacity-90"
          >
            <HelpCircle className="h-6 w-6" />
          </Button>
        </PopoverTrigger>
        <PopoverContent 
          side="top" 
          align="start" 
          className="w-72 p-2"
        >
          <div className="space-y-1">
            <div className="px-3 py-2 border-b mb-2">
              <p className="font-semibold text-sm">დემო რეჟიმი</p>
              <p className="text-xs text-muted-foreground">დამხმარე ინსტრუმენტები</p>
            </div>
            {actions.map((action, index) => {
              const Icon = action.icon;
              return (
                <Button
                  key={index}
                  variant={action.variant === "destructive" ? "destructive" : "ghost"}
                  className="w-full justify-start gap-3 h-auto py-3"
                  onClick={action.onClick}
                >
                  <Icon className="h-4 w-4 flex-shrink-0" />
                  <div className="text-left">
                    <p className="text-sm font-medium">{action.label}</p>
                    <p className="text-xs text-muted-foreground">{action.description}</p>
                  </div>
                </Button>
              );
            })}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
