import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { CheckCircle2, User, Mail, Phone, Building2, Briefcase, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

const employeeSchema = z.object({
  firstName: z.string().min(2, "სახელი უნდა იყოს მინიმუმ 2 სიმბოლო").max(50),
  lastName: z.string().min(2, "გვარი უნდა იყოს მინიმუმ 2 სიმბოლო").max(50),
  personalId: z.string().length(11, "პირადი ნომერი უნდა იყოს 11 ციფრი"),
  email: z.string().email("არასწორი ემაილის ფორმატი").max(100),
  phone: z.string().min(9, "ტელეფონის ნომერი უნდა იყოს მინიმუმ 9 ციფრი").max(15),
  department: z.string().min(1, "აირჩიეთ დეპარტამენტი"),
  position: z.string().min(1, "აირჩიეთ პოზიცია"),
  startDate: z.string().min(1, "აირჩიეთ დაწყების თარიღი"),
});

type EmployeeFormData = z.infer<typeof employeeSchema>;

interface EmployeeDemoProps {
  onComplete: () => void;
}

export const EmployeeDemo = ({ onComplete }: EmployeeDemoProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const { toast } = useToast();

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<EmployeeFormData>({
    resolver: zodResolver(employeeSchema),
  });

  const formData = watch();

  const steps = [
    {
      title: "პირადი ინფორმაცია",
      fields: ["firstName", "lastName", "personalId"],
      icon: User,
    },
    {
      title: "საკონტაქტო ინფორმაცია",
      fields: ["email", "phone"],
      icon: Mail,
    },
    {
      title: "სამსახურის ინფორმაცია",
      fields: ["department", "position", "startDate"],
      icon: Briefcase,
    },
  ];

  const testData = {
    firstName: "გიორგი",
    lastName: "მელაძე",
    personalId: "01024056789",
    email: "giorgi.meladze@example.ge",
    phone: "555123456",
  };

  const fillTestData = () => {
    Object.entries(testData).forEach(([key, value]) => {
      setValue(key as keyof EmployeeFormData, value);
    });
    toast({
      title: "ტესტ მონაცემები შევსებულია",
      description: "შეგიძლიათ დაარედაქტიროთ ან გააგრძელოთ შემდეგ ნაბიჯზე",
    });
  };

  const onSubmit = (data: EmployeeFormData) => {
    setIsCompleted(true);
    onComplete();
    toast({
      title: "წარმატება! 🎉",
      description: "თანამშრომელი წარმატებით დაემატა დემო სისტემაში",
    });
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  if (isCompleted) {
    return (
      <div className="text-center space-y-6 py-8">
        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center animate-scale-in">
            <CheckCircle2 className="h-12 w-12 text-green-500" />
          </div>
        </div>
        <div>
          <h3 className="text-2xl font-bold mb-2">მშვენიერია!</h3>
          <p className="text-muted-foreground">
            თქვენ წარმატებით დაამატეთ ახალი თანამშრომელი დემო სისტემაში
          </p>
        </div>
        <Card className="p-4 bg-muted/50 max-w-md mx-auto text-left">
          <h4 className="font-semibold mb-3">დამატებული თანამშრომელი:</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">სახელი, გვარი:</span>
              <span className="font-medium">{formData.firstName} {formData.lastName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">პირადი ნომერი:</span>
              <span className="font-medium">{formData.personalId}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">ემაილი:</span>
              <span className="font-medium">{formData.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">დეპარტამენტი:</span>
              <span className="font-medium">{formData.department}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">პოზიცია:</span>
              <span className="font-medium">{formData.position}</span>
            </div>
          </div>
        </Card>
        <Button onClick={() => {
          setIsCompleted(false);
          setCurrentStep(0);
        }}>
          კიდევ ერთხელ ცდა
        </Button>
      </div>
    );
  }

  const StepIcon = steps[currentStep].icon;

  return (
    <div className="space-y-6">
      <Alert>
        <StepIcon className="h-4 w-4" />
        <AlertDescription className="ml-2">
          <strong>ნაბიჯი {currentStep + 1} / {steps.length}:</strong> {steps[currentStep].title}
        </AlertDescription>
      </Alert>

      <div className="flex justify-between mb-4">
        {steps.map((step, index) => (
          <div key={index} className="flex items-center flex-1">
            <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all ${
              index === currentStep 
                ? 'border-primary bg-primary text-primary-foreground' 
                : index < currentStep 
                ? 'border-green-500 bg-green-500 text-white'
                : 'border-muted bg-background'
            }`}>
              {index < currentStep ? (
                <CheckCircle2 className="h-5 w-5" />
              ) : (
                <span className="text-sm font-semibold">{index + 1}</span>
              )}
            </div>
            {index < steps.length - 1 && (
              <div className={`flex-1 h-1 mx-2 ${
                index < currentStep ? 'bg-green-500' : 'bg-muted'
              }`} />
            )}
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {currentStep === 0 && (
          <div className="space-y-4 animate-fade-in">
            <Button 
              type="button" 
              variant="outline" 
              onClick={fillTestData}
              className="w-full"
            >
              ტესტ მონაცემების შევსება
            </Button>

            <div className="space-y-2">
              <Label htmlFor="firstName">სახელი *</Label>
              <Input
                id="firstName"
                placeholder="მაგ: გიორგი"
                {...register("firstName")}
              />
              {errors.firstName && (
                <p className="text-sm text-red-500">{errors.firstName.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="lastName">გვარი *</Label>
              <Input
                id="lastName"
                placeholder="მაგ: მელაძე"
                {...register("lastName")}
              />
              {errors.lastName && (
                <p className="text-sm text-red-500">{errors.lastName.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="personalId">პირადი ნომერი *</Label>
              <Input
                id="personalId"
                placeholder="11 ციფრი"
                maxLength={11}
                {...register("personalId")}
              />
              {errors.personalId && (
                <p className="text-sm text-red-500">{errors.personalId.message}</p>
              )}
            </div>
          </div>
        )}

        {currentStep === 1 && (
          <div className="space-y-4 animate-fade-in">
            <div className="space-y-2">
              <Label htmlFor="email">ემაილი *</Label>
              <Input
                id="email"
                type="email"
                placeholder="example@company.ge"
                {...register("email")}
              />
              {errors.email && (
                <p className="text-sm text-red-500">{errors.email.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">ტელეფონის ნომერი *</Label>
              <Input
                id="phone"
                placeholder="555123456"
                {...register("phone")}
              />
              {errors.phone && (
                <p className="text-sm text-red-500">{errors.phone.message}</p>
              )}
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-4 animate-fade-in">
            <div className="space-y-2">
              <Label htmlFor="department">დეპარტამენტი *</Label>
              <Select onValueChange={(value) => setValue("department", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="აირჩიეთ დეპარტამენტი" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="IT">IT დეპარტამენტი</SelectItem>
                  <SelectItem value="HR">HR დეპარტამენტი</SelectItem>
                  <SelectItem value="Finance">ფინანსური დეპარტამენტი</SelectItem>
                  <SelectItem value="Sales">გაყიდვების დეპარტამენტი</SelectItem>
                </SelectContent>
              </Select>
              {errors.department && (
                <p className="text-sm text-red-500">{errors.department.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="position">პოზიცია *</Label>
              <Select onValueChange={(value) => setValue("position", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="აირჩიეთ პოზიცია" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Developer">დეველოპერი</SelectItem>
                  <SelectItem value="Manager">მენეჯერი</SelectItem>
                  <SelectItem value="Analyst">ანალიტიკოსი</SelectItem>
                  <SelectItem value="Specialist">სპეციალისტი</SelectItem>
                </SelectContent>
              </Select>
              {errors.position && (
                <p className="text-sm text-red-500">{errors.position.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="startDate">დაწყების თარიღი *</Label>
              <Input
                id="startDate"
                type="date"
                {...register("startDate")}
              />
              {errors.startDate && (
                <p className="text-sm text-red-500">{errors.startDate.message}</p>
              )}
            </div>
          </div>
        )}

        <div className="flex gap-2 pt-4">
          {currentStep > 0 && (
            <Button type="button" variant="outline" onClick={prevStep} className="flex-1">
              უკან
            </Button>
          )}
          {currentStep < steps.length - 1 ? (
            <Button type="button" onClick={nextStep} className="flex-1">
              შემდეგი
            </Button>
          ) : (
            <Button type="submit" className="flex-1">
              დამატება
            </Button>
          )}
        </div>
      </form>
    </div>
  );
};
