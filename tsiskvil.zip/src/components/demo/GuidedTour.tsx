import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  X, 
  ChevronRight, 
  ChevronLeft,
  Users,
  Clock,
  FileText,
  DollarSign,
  BarChart3,
  Building2,
  Settings,
  CheckCircle2,
  ArrowRight
} from "lucide-react";
import { useDemoMode } from "@/contexts/DemoContext";

interface TourStep {
  id: string;
  title: string;
  description: string;
  path: string;
  icon: React.ElementType;
  tips: string[];
}

const tourSteps: TourStep[] = [
  {
    id: "dashboard",
    title: "მთავარი პანელი",
    description: "სისტემის მიმოხილვა და ძირითადი სტატისტიკა ერთ ადგილას",
    path: "/dashboard",
    icon: BarChart3,
    tips: [
      "ამ გვერდზე ნახავთ ყველა მნიშვნელოვან მეტრიკას",
      "ვიჯეტები ადაპტირებულია თქვენი როლის მიხედვით",
      "სწრაფი მოქმედებებით შეგიძლიათ ხშირი ამოცანების შესრულება"
    ]
  },
  {
    id: "employees",
    title: "თანამშრომლები",
    description: "თანამშრომლების სრული მართვა - დამატება, რედაქტირება, ისტორია",
    path: "/employees",
    icon: Users,
    tips: [
      "ფილტრები დაგეხმარებათ სწრაფ ძებნაში",
      "თითოეული თანამშრომლის დეტალური პროფილი ხელმისაწვდომია",
      "Excel ექსპორტი ყველა მონაცემით"
    ]
  },
  {
    id: "attendance",
    title: "დასწრების აღრიცხვა",
    description: "რეალურ დროში დასწრების მონიტორინგი და ისტორია",
    path: "/attendance",
    icon: Clock,
    tips: [
      "რეალურ დროში ხედავთ ვინ არის სამსახურში",
      "მობილური ჩეკ-ინი GPS ადგილმდებარეობით",
      "გვიანობების ავტომატური აღრიცხვა"
    ]
  },
  {
    id: "leave-requests",
    title: "შვებულებები",
    description: "შვებულების მოთხოვნების მართვა და ბალანსების კონტროლი",
    path: "/leave-requests",
    icon: FileText,
    tips: [
      "თანამშრომლებს შეუძლიათ მოთხოვნის გაგზავნა პორტალიდან",
      "მენეჯერებს ეცნობებათ ახალი მოთხოვნების შესახებ",
      "შვებულების ბალანსი ავტომატურად ითვლება"
    ]
  },
  {
    id: "payroll",
    title: "ხელფასები",
    description: "ავტომატური ხელფასის გაანგარიშება და გადახდა",
    path: "/payroll",
    icon: DollarSign,
    tips: [
      "ხელფასი ითვლება სამუშაო დროის მიხედვით",
      "პენსია და გადასახადები ავტომატურად",
      "ბონუსებისა და გამოქვითვების მართვა"
    ]
  },
  {
    id: "reports",
    title: "ანგარიშები",
    description: "დეტალური ანალიტიკა და Excel ექსპორტი",
    path: "/reports",
    icon: BarChart3,
    tips: [
      "ფინანსური ანგარიშები სრული დეტალებით",
      "სამუშაო დროის ანალიზი",
      "ყველა ანგარიში Excel-ში ექსპორტირებადია"
    ]
  },
  {
    id: "organization",
    title: "ორგანიზაცია",
    description: "ორგანიზაციული სტრუქტურა და დეპარტამენტები",
    path: "/organization",
    icon: Building2,
    tips: [
      "დეპარტამენტების იერარქიული სტრუქტურა",
      "პოზიციების მართვა",
      "მენეჯერების მინიჭება"
    ]
  },
  {
    id: "system",
    title: "სისტემის პარამეტრები",
    description: "კონფიგურაცია და ადმინისტრირება",
    path: "/system",
    icon: Settings,
    tips: [
      "კომპანიის პარამეტრების მართვა",
      "მომხმარებლების და როლების კონფიგურაცია",
      "უსაფრთხოების პარამეტრები"
    ]
  }
];

export function GuidedTour() {
  const navigate = useNavigate();
  const location = useLocation();
  const { isDemoMode } = useDemoMode();
  const [isOpen, setIsOpen] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);

  useEffect(() => {
    // Find current step based on path
    const stepIndex = tourSteps.findIndex(step => step.path === location.pathname);
    if (stepIndex !== -1) {
      setCurrentStepIndex(stepIndex);
      if (!completedSteps.includes(tourSteps[stepIndex].id)) {
        setCompletedSteps(prev => [...prev, tourSteps[stepIndex].id]);
      }
    }
  }, [location.pathname]);

  useEffect(() => {
    // Show tour panel after entering demo mode
    if (isDemoMode && location.pathname === "/dashboard") {
      const timer = setTimeout(() => setIsOpen(true), 1000);
      return () => clearTimeout(timer);
    }
  }, [isDemoMode, location.pathname]);

  if (!isDemoMode || !isOpen) return null;

  const currentStep = tourSteps[currentStepIndex];
  const progress = (completedSteps.length / tourSteps.length) * 100;
  const Icon = currentStep.icon;

  const goToStep = (index: number) => {
    setCurrentStepIndex(index);
    navigate(tourSteps[index].path);
  };

  const nextStep = () => {
    if (currentStepIndex < tourSteps.length - 1) {
      goToStep(currentStepIndex + 1);
    }
  };

  const prevStep = () => {
    if (currentStepIndex > 0) {
      goToStep(currentStepIndex - 1);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 w-96 max-w-[calc(100vw-2rem)]">
      <Card className="shadow-2xl border-primary/20 bg-card/95 backdrop-blur-lg">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <Badge variant="outline" className="text-primary border-primary">
              გაიდიანი ტური
            </Badge>
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex items-center gap-3 mt-2">
            <div className="p-2 rounded-lg bg-primary/10">
              <Icon className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg">{currentStep.title}</CardTitle>
              <CardDescription className="text-sm">
                ეტაპი {currentStepIndex + 1} / {tourSteps.length}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            {currentStep.description}
          </p>

          <div className="space-y-2">
            <p className="text-xs font-medium text-foreground">რჩევები:</p>
            {currentStep.tips.map((tip, index) => (
              <div key={index} className="flex items-start gap-2 text-xs text-muted-foreground">
                <CheckCircle2 className="h-3 w-3 mt-0.5 text-green-500 flex-shrink-0" />
                <span>{tip}</span>
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>პროგრესი</span>
              <span>{completedSteps.length} / {tourSteps.length}</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          <div className="flex flex-wrap gap-1">
            {tourSteps.map((step, index) => {
              const StepIcon = step.icon;
              const isCompleted = completedSteps.includes(step.id);
              const isCurrent = index === currentStepIndex;
              return (
                <Button
                  key={step.id}
                  variant={isCurrent ? "default" : isCompleted ? "secondary" : "ghost"}
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => goToStep(index)}
                  title={step.title}
                >
                  <StepIcon className="h-4 w-4" />
                </Button>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={prevStep}
              disabled={currentStepIndex === 0}
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              წინა
            </Button>
            
            {location.pathname !== currentStep.path && (
              <Button 
                size="sm"
                onClick={() => navigate(currentStep.path)}
                className="gap-1"
              >
                გადასვლა
                <ArrowRight className="h-4 w-4" />
              </Button>
            )}
            
            <Button 
              variant="outline" 
              size="sm"
              onClick={nextStep}
              disabled={currentStepIndex === tourSteps.length - 1}
            >
              შემდეგი
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
