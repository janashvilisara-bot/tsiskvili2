import { LucideIcon } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: number;
  description?: string;
  iconColor?: string;
  className?: string;
}

export default function StatCard({ title, value, icon: Icon, trend, description, iconColor, className }: StatCardProps) {
  return (
    <Card className={cn(
      "relative overflow-hidden group border-border/40 bg-card",
      "transition-all duration-300 hover:shadow-xl hover:shadow-primary/5 hover:border-primary/20 hover:-translate-y-1",
      className
    )}>
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-primary/8 to-accent/8 rounded-full blur-2xl -mr-16 -mt-16 group-hover:scale-125 transition-transform duration-700" />
      
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className={cn(
          "p-2.5 rounded-xl transition-all duration-300",
          "bg-primary/10 group-hover:bg-primary/15 group-hover:scale-105"
        )}>
          <Icon className={cn(
            "h-5 w-5 transition-colors duration-300",
            iconColor || "text-primary"
          )} />
        </div>
      </CardHeader>
      
      <CardContent className="relative z-10">
        <div className="flex items-baseline gap-2">
          <div className="text-3xl font-bold tracking-tight text-foreground">
            {value}
          </div>
          {trend && (
            <Badge 
              variant={trend > 0 ? "default" : "secondary"}
              className={cn(
                "text-xs font-semibold shadow-sm",
                trend > 0 ? "bg-success/90 hover:bg-success text-success-foreground" : ""
              )}
            >
              {trend > 0 ? "↗" : "↘"} {Math.abs(trend)}%
            </Badge>
          )}
        </div>
        
        {description && (
          <p className="text-xs text-muted-foreground mt-2 leading-relaxed">
            {description}
          </p>
        )}
      </CardContent>
      
      <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-primary to-accent scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
    </Card>
  );
}
