import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Save, CheckCircle, XCircle, Loader2, Eye, EyeOff, ArrowLeftRight } from "lucide-react";

const KursiSettings = () => {
  const [token, setToken] = useState("");
  const [baseUrl, setBaseUrl] = useState("https://api.kursi.ge");
  const [hasKey, setHasKey] = useState(false);
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [showKey, setShowKey] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  useEffect(() => { load(); }, []);

  const load = async () => {
    const { data } = await supabase
      .from("integration_settings")
      .select("settings")
      .eq("provider", "kursi")
      .maybeSingle();
    const s = data?.settings as Record<string, any> | null;
    if (s?.api_token) {
      setHasKey(true);
      setToken(s.api_token);
      if (s.base_url) setBaseUrl(s.base_url);
    }
  };

  const save = async () => {
    if (!token.trim()) { toast.error("გთხოვთ შეიყვანოთ Bearer ტოკენი"); return; }
    setLoading(true);
    try {
      const payload = { api_token: token.trim(), base_url: baseUrl.trim() || "https://api.kursi.ge" };
      const { data: existing } = await supabase
        .from("integration_settings")
        .select("id")
        .eq("provider", "kursi")
        .maybeSingle();
      if (existing) {
        const { error } = await supabase
          .from("integration_settings")
          .update({ settings: payload, is_active: true, updated_at: new Date().toISOString() })
          .eq("id", existing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("integration_settings")
          .insert({ provider: "kursi", settings: payload, is_active: true });
        if (error) throw error;
      }
      setHasKey(true);
      toast.success("Kursi.ge ინტეგრაცია შენახულია");
    } catch (e: any) {
      toast.error("შენახვა ვერ მოხერხდა: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  const test = async () => {
    setTesting(true); setTestResult(null);
    try {
      const { data, error } = await supabase.functions.invoke(
        "kursi-api?endpoint=get-settlements&page=0&size=1",
        { method: "POST" }
      );
      if (error) throw new Error(error.message);
      if (data?.error) throw new Error(data.error);
      setTestResult({ success: true, message: `კავშირი წარმატებულია - ${data?.total ?? 0} settlement` });
    } catch (e: any) {
      setTestResult({ success: false, message: e.message || "კავშირი ვერ მოხერხდა" });
    } finally {
      setTesting(false);
    }
  };

  const remove = async () => {
    if (!confirm("ნამდვილად გსურთ Kursi.ge გასაღების წაშლა?")) return;
    setLoading(true);
    try {
      await supabase
        .from("integration_settings")
        .update({ settings: {}, is_active: false, updated_at: new Date().toISOString() })
        .eq("provider", "kursi");
      setToken(""); setHasKey(false); setTestResult(null);
      toast.success("გასაღები წაშლილია");
    } finally { setLoading(false); }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
            <ArrowLeftRight className="h-5 w-5" />
          </div>
          <span>Kursi.ge Merchant ინტეგრაცია</span>
          {hasKey && <Badge variant="default" className="gap-1"><CheckCircle className="h-3 w-3" /> აქტიური</Badge>}
        </CardTitle>
        <CardDescription>
          ვალუტის კონვერტაცია, ორდერების და სეთლმენტების მართვა Kursi.ge Merchant API-ის გავლით.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="kursi-url">API საბაზო URL</Label>
            <Input id="kursi-url" value={baseUrl} onChange={e => setBaseUrl(e.target.value)} placeholder="https://api.kursi.ge" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="kursi-token">Bearer ტოკენი</Label>
            <div className="relative">
              <Input
                id="kursi-token"
                type={showKey ? "text" : "password"}
                value={token}
                onChange={e => setToken(e.target.value)}
                placeholder="eyJhbGciOi..."
                className="pr-10"
              />
              <button type="button" onClick={() => setShowKey(!showKey)} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button onClick={save} disabled={loading} className="gap-2">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            შენახვა
          </Button>
          {hasKey && (
            <>
              <Button variant="outline" onClick={test} disabled={testing} className="gap-2">
                {testing ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
                კავშირის ტესტი
              </Button>
              <Button variant="ghost" className="text-destructive gap-2" onClick={remove}>
                <XCircle className="h-4 w-4" /> წაშლა
              </Button>
            </>
          )}
        </div>

        {testResult && (
          <div className={`p-3 rounded-lg border text-sm ${testResult.success ? "bg-green-50 border-green-200 text-green-800 dark:bg-green-900/20 dark:border-green-800 dark:text-green-200" : "bg-destructive/10 border-destructive/20 text-destructive"}`}>
            {testResult.success ? <CheckCircle className="h-4 w-4 inline mr-2" /> : <XCircle className="h-4 w-4 inline mr-2" />}
            {testResult.message}
          </div>
        )}

        <div className="p-3 rounded-lg bg-muted/50 border text-xs text-muted-foreground space-y-1">
          <p><strong>დოკუმენტაცია:</strong> <a href="https://docs.kursi.ge/merchant/" target="_blank" rel="noopener" className="text-primary underline">docs.kursi.ge/merchant</a></p>
          <p>ტოკენი მიიღება Kursi.ge-ში მერჩანტის რეგისტრაციის შემდეგ.</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default KursiSettings;
