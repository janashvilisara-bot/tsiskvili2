import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Save, CheckCircle, XCircle, Loader2, Eye, EyeOff } from "lucide-react";
import GlobalCellLogo from "@/components/business-trips/GlobalCellLogo";

const GlobalCellSettings = () => {
  const [apiKey, setApiKey] = useState("");
  const [hasKey, setHasKey] = useState(false);
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [showKey, setShowKey] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    const { data } = await supabase
      .from("integration_settings")
      .select("settings")
      .eq("provider", "globalcell")
      .maybeSingle();

    const settings = data?.settings as Record<string, any> | null;
    if (settings?.api_key) {
      setHasKey(true);
      setApiKey(settings.api_key);
    }
  };

  const handleSave = async () => {
    if (!apiKey.trim()) {
      toast.error("გთხოვთ შეიყვანოთ API გასაღები");
      return;
    }

    setLoading(true);
    try {
      const { data: existing } = await supabase
        .from("integration_settings")
        .select("id")
        .eq("provider", "globalcell")
        .maybeSingle();

      if (existing) {
        const { error } = await supabase
          .from("integration_settings")
          .update({
            settings: { api_key: apiKey.trim() },
            updated_at: new Date().toISOString(),
          })
          .eq("id", existing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("integration_settings")
          .insert({
            provider: "globalcell",
            settings: { api_key: apiKey.trim() },
            is_active: true,
          });
        if (error) throw error;
      }

      setHasKey(true);
      toast.success("Global Cell API გასაღები შენახულია");
    } catch (err: any) {
      toast.error("შენახვა ვერ მოხერხდა: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const { data, error } = await supabase.functions.invoke("globalcell-api?endpoint=account-info", {
        method: "POST",
        body: {},
      });

      if (error) throw new Error(error.message);
      if (data?.error) throw new Error(data.error);

      setTestResult({
        success: true,
        message: `წარმატებით! ანგარიში: ${data.accountName}, ბალანსი: $${data.accountBalance?.toFixed(2)}`,
      });
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err.message || "კავშირი ვერ მოხერხდა",
      });
    } finally {
      setTesting(false);
    }
  };

  const handleRemove = async () => {
    if (!confirm("ნამდვილად გსურთ API გასაღების წაშლა?")) return;
    
    setLoading(true);
    try {
      await supabase
        .from("integration_settings")
        .update({
          settings: {},
          is_active: false,
          updated_at: new Date().toISOString(),
        })
        .eq("provider", "globalcell");

      setApiKey("");
      setHasKey(false);
      setTestResult(null);
      toast.success("API გასაღები წაიშალა");
    } catch (err: any) {
      toast.error("წაშლა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <GlobalCellLogo className="h-7 w-auto" />
          <span>Global Cell eSIM ინტეგრაცია</span>
          {hasKey && <Badge variant="default" className="gap-1"><CheckCircle className="h-3 w-3" /> აქტიური</Badge>}
        </CardTitle>
        <CardDescription>
          შეიყვანეთ Global Cell-ის B2B API გასაღები მივლინებებისთვის eSIM-ების ავტომატური მართვისთვის
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="gc-api-key">B2B API გასაღები</Label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Input
                id="gc-api-key"
                type={showKey ? "text" : "password"}
                value={apiKey}
                onChange={e => setApiKey(e.target.value)}
                placeholder="შეიყვანეთ API გასაღები..."
                className="pr-10"
              />
              <button
                type="button"
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                onClick={() => setShowKey(!showKey)}
              >
                {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <Button onClick={handleSave} disabled={loading} className="gap-2">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              შენახვა
            </Button>
          </div>
        </div>

        {hasKey && (
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleTest} disabled={testing} className="gap-2">
              {testing ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
              კავშირის ტესტი
            </Button>
            <Button variant="ghost" className="text-destructive gap-2" onClick={handleRemove}>
              <XCircle className="h-4 w-4" /> წაშლა
            </Button>
          </div>
        )}

        {testResult && (
          <div className={`p-3 rounded-lg border text-sm ${testResult.success ? "bg-green-50 border-green-200 text-green-800 dark:bg-green-900/20 dark:border-green-800 dark:text-green-200" : "bg-destructive/10 border-destructive/20 text-destructive"}`}>
            {testResult.success ? <CheckCircle className="h-4 w-4 inline mr-2" /> : <XCircle className="h-4 w-4 inline mr-2" />}
            {testResult.message}
          </div>
        )}

        <div className="p-3 rounded-lg bg-muted/50 border text-xs text-muted-foreground space-y-1">
          <p><strong>API დოკუმენტაცია:</strong> <a href="https://b2bapi.globalcell.mobi/b2b-api/swagger/ui" target="_blank" rel="noopener" className="text-primary underline">Swagger UI</a></p>
          <p>API გასაღების მისაღებად დაუკავშირდით Global Cell-ს: <a href="https://globalcell.ge" target="_blank" rel="noopener" className="text-primary underline">globalcell.ge</a></p>
        </div>
      </CardContent>
    </Card>
  );
};

export default GlobalCellSettings;
