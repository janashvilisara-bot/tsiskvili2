import { useCallback, useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { CheckCircle, Loader2, HardDrive, LogOut } from "lucide-react";

const CONNECTOR_ID = "google_drive";

function waitForOAuthCompletion(popup: Window) {
  return new Promise<void>((resolve, reject) => {
    let poll: number | undefined;
    const cleanup = () => {
      window.removeEventListener("message", onMessage);
      if (poll !== undefined) window.clearInterval(poll);
    };
    const onMessage = (event: MessageEvent) => {
      const type = event.data?.type;
      if (
        event.origin !== window.location.origin ||
        event.source !== popup ||
        event.data?.connectorId !== CONNECTOR_ID ||
        (type !== "appUserConnectorOAuthComplete" && type !== "appUserConnectorOAuthFailed")
      ) return;
      cleanup();
      if (type === "appUserConnectorOAuthComplete") {
        resolve();
        return;
      }
      popup.close();
      reject(new Error(event.data?.reason ?? "დაკავშირება ვერ მოხერხდა."));
    };
    window.addEventListener("message", onMessage);
    poll = window.setInterval(() => {
      if (!popup.closed) return;
      cleanup();
      reject(new Error("ფანჯარა დაიხურა დასრულებამდე."));
    }, 500);
  });
}

const GoogleDriveSettings = () => {
  const [connected, setConnected] = useState(false);
  const [account, setAccount] = useState<{ email?: string; name?: string } | null>(null);
  const [reconnectRequired, setReconnectRequired] = useState(false);
  const [loading, setLoading] = useState(true);
  const [connecting, setConnecting] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke("google-drive", { body: { action: "status" } });
      setConnected(Boolean(data?.connected));
      setAccount(data?.account ?? null);
      setReconnectRequired(Boolean(data?.reconnectRequired));
    } catch {
      setConnected(false);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  const connect = async () => {
    const popup = window.open("", "google-drive-oauth", "width=600,height=720");
    if (!popup) {
      toast.error("გთხოვთ დაუშვათ ამომხტარი ფანჯრები");
      return;
    }
    setConnecting(true);
    try {
      const { data, error } = await supabase.functions.invoke("app-user-oauth-start", {
        body: { origin: window.location.origin },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      const completion = waitForOAuthCompletion(popup);
      popup.location.href = data.authorizationUrl;
      await completion;
      toast.success("Google Drive დაკავშირებულია");
      await refresh();
    } catch (e: any) {
      popup.close();
      toast.error(e?.message || "დაკავშირება ვერ მოხერხდა");
    } finally {
      setConnecting(false);
    }
  };

  const disconnect = async () => {
    setConnecting(true);
    try {
      await supabase.functions.invoke("google-drive", { body: { action: "disconnect" } });
      toast.success("კავშირი გაუქმდა");
      await refresh();
    } finally {
      setConnecting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <HardDrive className="h-5 w-5" />
          Google Drive
          {connected && !reconnectRequired && <Badge variant="secondary">დაკავშირებულია</Badge>}
        </CardTitle>
        <CardDescription>
          დააჭირეთ ღილაკს, შედით თქვენი Google ანგარიშით და გენერირებული დოკუმენტები ავტომატურად
          შეინახება თქვენს Drive-ზე, თანამშრომლის სახელის საქაღალდეში.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {loading ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> იტვირთება…
          </div>
        ) : connected && !reconnectRequired ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm text-green-600">
              <CheckCircle className="h-4 w-4" />
              {account?.email ? `დაკავშირებულია: ${account.email}` : "დაკავშირებულია"}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={connect} disabled={connecting}>
                {connecting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                სხვა ანგარიშით შესვლა
              </Button>
              <Button variant="ghost" onClick={disconnect} disabled={connecting}>
                <LogOut className="h-4 w-4 mr-2" />
                გათიშვა
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {reconnectRequired && (
              <p className="text-sm text-destructive">
                წვდომის ვადა ამოიწურა - გთხოვთ, ხელახლა დაუკავშირდეთ.
              </p>
            )}
            <Button onClick={connect} disabled={connecting}>
              {connecting ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <HardDrive className="h-4 w-4 mr-2" />
              )}
              {reconnectRequired ? "ხელახლა დაკავშირება" : "Google-ით დაკავშირება"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default GoogleDriveSettings;
