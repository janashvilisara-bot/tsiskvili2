import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  CheckCircle,
  Eye,
  EyeOff,
  Loader2,
  Save,
  Send,
  XCircle,
  type LucideIcon,
} from "lucide-react";

export interface ChannelField {
  key: string;
  label: string;
  placeholder?: string;
  secret?: boolean;
  hint?: string;
}

interface ChannelIntegrationCardProps {
  provider: string;
  title: string;
  description: string;
  icon: LucideIcon;
  gradient: string;
  fields: ChannelField[];
  /** Messaging channels support a live test message through the dispatcher. */
  testable?: boolean;
  docsUrl?: string;
  setupHint?: string;
}

const ChannelIntegrationCard = ({
  provider,
  title,
  description,
  icon: Icon,
  gradient,
  fields,
  testable = false,
  docsUrl,
  setupHint,
}: ChannelIntegrationCardProps) => {
  const [values, setValues] = useState<Record<string, string>>({});
  const [isActive, setIsActive] = useState(false);
  const [configured, setConfigured] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(
    null,
  );

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      const { data } = await supabase
        .from("integration_settings")
        .select("settings, is_active")
        .eq("provider", provider)
        .maybeSingle();
      if (cancelled) return;
      const settings = (data?.settings ?? {}) as Record<string, string>;
      setValues(settings);
      setIsActive(Boolean(data?.is_active));
      setConfigured(Object.values(settings).some((v) => Boolean(v)));
      setLoading(false);
    };
    void load();
    return () => {
      cancelled = true;
    };
  }, [provider]);

  const persist = async (nextValues: Record<string, string>, nextActive: boolean) => {
    const { data: existing } = await supabase
      .from("integration_settings")
      .select("id")
      .eq("provider", provider)
      .maybeSingle();

    if (existing) {
      const { error } = await supabase
        .from("integration_settings")
        .update({
          settings: nextValues,
          is_active: nextActive,
          updated_at: new Date().toISOString(),
        })
        .eq("id", existing.id);
      if (error) throw error;
    } else {
      const { error } = await supabase
        .from("integration_settings")
        .insert({ provider, settings: nextValues, is_active: nextActive });
      if (error) throw error;
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      const trimmed = Object.fromEntries(
        fields.map((f) => [f.key, (values[f.key] ?? "").trim()]),
      );
      await persist(trimmed, isActive);
      setValues(trimmed);
      setConfigured(Object.values(trimmed).some((v) => Boolean(v)));
      toast.success(`${title} - პარამეტრები შენახულია`);
    } catch {
      toast.error("შენახვა ვერ მოხერხდა. გთხოვთ, სცადოთ ხელახლა.");
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (next: boolean) => {
    setIsActive(next);
    try {
      await persist(values, next);
    } catch {
      setIsActive(!next);
      toast.error("სტატუსის შეცვლა ვერ მოხერხდა.");
    }
  };

  const test = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const { data, error } = await supabase.functions.invoke(
        "send-channel-notification",
        {
          body: {
            channels: [provider],
            message: `TalentOS - სატესტო შეტყობინება (${title})`,
          },
        },
      );
      if (error) throw new Error(error.message);
      const result = (data?.results ?? {})[provider];
      if (!result?.ok) throw new Error(result?.error ?? data?.error ?? "unknown");
      setTestResult({ ok: true, message: "სატესტო შეტყობინება გაიგზავნა." });
    } catch {
      setTestResult({
        ok: false,
        message: "გაგზავნა ვერ მოხერხდა - შეამოწმეთ შევსებული მონაცემები.",
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-3">
              <div className={`p-2 rounded-lg text-primary-foreground ${gradient}`}>
                <Icon className="h-5 w-5" />
              </div>
              <span>{title}</span>
              {configured && isActive && (
                <Badge variant="default" className="gap-1">
                  <CheckCircle className="h-3 w-3" /> აქტიური
                </Badge>
              )}
              {configured && !isActive && <Badge variant="secondary">გამორთული</Badge>}
              {!configured && <Badge variant="outline">არ არის დაკავშირებული</Badge>}
            </CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
          <Switch
            checked={isActive}
            onCheckedChange={toggleActive}
            aria-label={`${title} ჩართვა`}
            disabled={loading}
          />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3 md:grid-cols-2">
          {fields.map((field) => (
            <div key={field.key} className="space-y-2">
              <Label htmlFor={`${provider}-${field.key}`}>{field.label}</Label>
              <div className="relative">
                <Input
                  id={`${provider}-${field.key}`}
                  type={field.secret && !revealed[field.key] ? "password" : "text"}
                  value={values[field.key] ?? ""}
                  placeholder={field.placeholder}
                  className={field.secret ? "pr-10" : undefined}
                  onChange={(e) =>
                    setValues((prev) => ({ ...prev, [field.key]: e.target.value }))
                  }
                />
                {field.secret && (
                  <button
                    type="button"
                    aria-label="მონაცემის ჩვენება"
                    onClick={() =>
                      setRevealed((prev) => ({ ...prev, [field.key]: !prev[field.key] }))
                    }
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {revealed[field.key] ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                )}
              </div>
              {field.hint && (
                <p className="text-xs text-muted-foreground">{field.hint}</p>
              )}
            </div>
          ))}
        </div>

        <div className="flex flex-wrap gap-2">
          <Button onClick={save} disabled={saving || loading} className="gap-2">
            {saving ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
            შენახვა
          </Button>
          {testable && (
            <Button
              variant="outline"
              onClick={test}
              disabled={testing || !configured}
              className="gap-2"
            >
              {testing ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              სატესტო შეტყობინება
            </Button>
          )}
        </div>

        {testResult && (
          <div
            className={`p-3 rounded-lg border text-sm ${
              testResult.ok
                ? "bg-primary/10 border-primary/20 text-primary"
                : "bg-destructive/10 border-destructive/20 text-destructive"
            }`}
          >
            {testResult.ok ? (
              <CheckCircle className="h-4 w-4 inline mr-2" />
            ) : (
              <XCircle className="h-4 w-4 inline mr-2" />
            )}
            {testResult.message}
          </div>
        )}

        {(setupHint || docsUrl) && (
          <div className="p-3 rounded-lg bg-muted/50 border text-xs text-muted-foreground space-y-1">
            {setupHint && <p>{setupHint}</p>}
            {docsUrl && (
              <p>
                <a
                  href={docsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary underline"
                >
                  ინსტრუქცია და დოკუმენტაცია
                </a>
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ChannelIntegrationCard;
