import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { DoorOpen, Plus, Trash2, Edit, Copy, Eye, EyeOff, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface TurnstileDevice {
  id: string;
  device_name: string;
  device_type: string;
  location: string | null;
  ip_address: string | null;
  is_active: boolean;
  api_key: string | null;
  device_model: string | null;
  notes: string | null;
  last_sync: string | null;
}

export default function TurnstileDevicesManager() {
  const [devices, setDevices] = useState<TurnstileDevice[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editingDevice, setEditingDevice] = useState<TurnstileDevice | null>(null);
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set());

  const [formData, setFormData] = useState({
    device_name: "",
    location: "",
    ip_address: "",
    device_model: "",
    notes: "",
    is_active: true,
  });

  const webhookUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/turnstile-webhook`;

  useEffect(() => {
    fetchDevices();
  }, []);

  const fetchDevices = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("attendance_devices")
      .select("*")
      .eq("device_type", "turnstile")
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("მოწყობილობების ჩატვირთვა ვერ მოხერხდა");
    } else {
      setDevices((data as TurnstileDevice[]) || []);
    }
    setLoading(false);
  };

  const generateApiKey = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let key = "dk_";
    for (let i = 0; i < 48; i++) {
      key += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return key;
  };

  const handleSave = async () => {
    if (!formData.device_name.trim()) {
      toast.error("მოწყობილობის სახელი სავალდებულოა");
      return;
    }

    const apiKey = editingDevice?.api_key || generateApiKey();

    const payload = {
      device_name: formData.device_name.trim(),
      device_type: "turnstile" as const,
      location: formData.location || null,
      ip_address: formData.ip_address || null,
      device_model: formData.device_model || null,
      notes: formData.notes || null,
      is_active: formData.is_active,
      api_key: apiKey,
    };

    if (editingDevice) {
      const { error } = await supabase
        .from("attendance_devices")
        .update(payload)
        .eq("id", editingDevice.id);

      if (error) {
        toast.error("განახლება ვერ მოხერხდა: " + error.message);
        return;
      }
      toast.success("მოწყობილობა განახლდა");
    } else {
      const { error } = await supabase
        .from("attendance_devices")
        .insert(payload);

      if (error) {
        toast.error("დამატება ვერ მოხერხდა: " + error.message);
        return;
      }
      toast.success("მოწყობილობა დაემატა");
    }

    setShowDialog(false);
    resetForm();
    fetchDevices();
  };

  const handleDelete = async (id: string) => {
    if (!confirm("ნამდვილად გსურთ მოწყობილობის წაშლა?")) return;

    const { error } = await supabase
      .from("attendance_devices")
      .delete()
      .eq("id", id);

    if (error) {
      toast.error("წაშლა ვერ მოხერხდა");
    } else {
      toast.success("მოწყობილობა წაიშალა");
      fetchDevices();
    }
  };

  const handleRegenerateKey = async (device: TurnstileDevice) => {
    if (!confirm("ახალი API გასაღების გენერირება? ძველი გასაღები აღარ იმუშავებს.")) return;

    const newKey = generateApiKey();
    const { error } = await supabase
      .from("attendance_devices")
      .update({ api_key: newKey })
      .eq("id", device.id);

    if (error) {
      toast.error("გასაღების განახლება ვერ მოხერხდა");
    } else {
      toast.success("ახალი API გასაღები დაგენერირდა");
      fetchDevices();
    }
  };

  const resetForm = () => {
    setEditingDevice(null);
    setFormData({
      device_name: "",
      location: "",
      ip_address: "",
      device_model: "",
      notes: "",
      is_active: true,
    });
  };

  const openEditDialog = (device: TurnstileDevice) => {
    setEditingDevice(device);
    setFormData({
      device_name: device.device_name,
      location: device.location || "",
      ip_address: device.ip_address || "",
      device_model: device.device_model || "",
      notes: device.notes || "",
      is_active: device.is_active,
    });
    setShowDialog(true);
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} დაკოპირდა`);
  };

  const toggleKeyVisibility = (id: string) => {
    setVisibleKeys((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <DoorOpen className="h-5 w-5" />
              ტურნიკეტის მოწყობილობები
            </span>
            <Button
              size="sm"
              onClick={() => {
                resetForm();
                setShowDialog(true);
              }}
            >
              <Plus className="h-4 w-4 mr-2" />
              დამატება
            </Button>
          </CardTitle>
          <CardDescription>
            ტურნიკეტის/რიდერის მოწყობილობების მართვა და API გასაღებების კონფიგურაცია
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Webhook URL */}
          <div className="rounded-lg border border-dashed p-4 bg-muted/30">
            <Label className="text-sm font-medium">Webhook URL (რიდერში გასაწერი)</Label>
            <div className="flex items-center gap-2 mt-1">
              <code className="flex-1 text-xs bg-muted px-3 py-2 rounded break-all">
                {webhookUrl}
              </code>
              <Button
                size="sm"
                variant="outline"
                onClick={() => copyToClipboard(webhookUrl, "Webhook URL")}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {loading ? (
            <p className="text-sm text-muted-foreground">იტვირთება...</p>
          ) : devices.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">
              მოწყობილობები არ არის დამატებული
            </p>
          ) : (
            devices.map((device) => (
              <div
                key={device.id}
                className="rounded-lg border p-4 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <DoorOpen className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{device.device_name}</p>
                      <p className="text-xs text-muted-foreground">
                        {device.device_model || "მოდელი არ არის მითითებული"}
                        {device.location && ` • ${device.location}`}
                        {device.ip_address && ` • ${device.ip_address}`}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={device.is_active ? "default" : "secondary"}>
                      {device.is_active ? "აქტიური" : "გამორთული"}
                    </Badge>
                    {device.last_sync && (
                      <span className="text-xs text-muted-foreground">
                        ბოლო სინქრონიზაცია: {new Date(device.last_sync).toLocaleString("ka-GE")}
                      </span>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => openEditDialog(device)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handleDelete(device.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* API Key section */}
                {device.api_key && (
                  <div className="rounded bg-muted/50 p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs font-medium">API გასაღები (x-device-key ჰედერში)</Label>
                      <div className="flex items-center gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => toggleKeyVisibility(device.id)}
                        >
                          {visibleKeys.has(device.id) ? (
                            <EyeOff className="h-3 w-3" />
                          ) : (
                            <Eye className="h-3 w-3" />
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(device.api_key!, "API გასაღები")}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleRegenerateKey(device)}
                        >
                          <RefreshCw className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <code className="text-xs break-all">
                      {visibleKeys.has(device.id)
                        ? device.api_key
                        : "dk_" + "•".repeat(40)}
                    </code>
                  </div>
                )}

                {/* Dahua configuration hint */}
                <div className="text-xs text-muted-foreground bg-muted/30 rounded p-3 space-y-1">
                  <strong>Dahua რიდერში გაწერეთ (HTTP Listening):</strong>
                  <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5 mt-1">
                    <span className="font-medium">Event Alarm IP/Domain Name:</span>
                    <code className="bg-muted px-1 rounded">kiurxtmqgcjhxjvvynab.supabase.co</code>
                    <span className="font-medium">URL:</span>
                    <code className="bg-muted px-1 rounded break-all">/functions/v1/turnstile-webhook?key={visibleKeys.has(device.id) ? device.api_key : "[API გასაღები]"}</code>
                    <span className="font-medium">Port:</span>
                    <code className="bg-muted px-1 rounded">443</code>
                    <span className="font-medium">Protocol:</span>
                    <code className="bg-muted px-1 rounded">HTTPS</code>
                  </div>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingDevice ? "მოწყობილობის რედაქტირება" : "ახალი მოწყობილობა"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="deviceName">მოწყობილობის სახელი *</Label>
              <Input
                id="deviceName"
                value={formData.device_name}
                onChange={(e) => setFormData({ ...formData, device_name: e.target.value })}
                placeholder="მაგ: მთავარი შესასვლელი"
              />
            </div>
            <div>
              <Label htmlFor="deviceModel">მოდელი</Label>
              <Input
                id="deviceModel"
                value={formData.device_model}
                onChange={(e) => setFormData({ ...formData, device_model: e.target.value })}
                placeholder="მაგ: DS-K1T805EX"
              />
            </div>
            <div>
              <Label htmlFor="deviceIp">IP მისამართი</Label>
              <Input
                id="deviceIp"
                value={formData.ip_address}
                onChange={(e) => setFormData({ ...formData, ip_address: e.target.value })}
                placeholder="მაგ: 192.168.88.114"
              />
            </div>
            <div>
              <Label htmlFor="deviceLocation">მდებარეობა</Label>
              <Input
                id="deviceLocation"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="მაგ: მთავარი ოფისი"
              />
            </div>
            <div>
              <Label htmlFor="deviceNotes">შენიშვნა</Label>
              <Input
                id="deviceNotes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="დამატებითი ინფორმაცია"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
              <Label>აქტიური</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              გაუქმება
            </Button>
            <Button onClick={handleSave}>შენახვა</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
