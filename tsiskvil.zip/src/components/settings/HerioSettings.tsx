import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Briefcase, CheckCircle2, XCircle, Loader2, RefreshCw, LogOut, AlertCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface HerioStatus {
  connected: boolean;
  email?: string; // stores phone number (legacy column name)
  phoneNumber?: string | null;
  herio_user_id?: string | null;
  last_login_at?: string | null;
  token_expires_at?: string | null;
  is_active?: boolean | null;
  last_error?: string | null;
}

export default function HerioSettings() {
  const [status, setStatus] = useState<HerioStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [password, setPassword] = useState("");
  const [showForm, setShowForm] = useState(false);

  const loadStatus = async () => {
    setLoading(true);
    const { data, error } = await supabase.functions.invoke("herio-auth", {
      body: { action: "status" },
    });
    if (error) {
      toast.error("Herio-ს სტატუსის წაკითხვა ვერ მოხერხდა");
    } else {
      setStatus(data);
      setShowForm(!data?.connected);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadStatus();
  }, []);

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPhone = phoneNumber.replace(/\D/g, "");
    if (!cleanPhone || !password) {
      toast.error("შეიყვანეთ ტელეფონი და პაროლი");
      return;
    }
    if (cleanPhone.length !== 9) {
      toast.error("ტელეფონი უნდა იყოს 9 ციფრი (ქართული ფორმატი, ქვეყნის კოდის გარეშე)");
      return;
    }
    setSubmitting(true);
    const { data, error } = await supabase.functions.invoke("herio-auth", {
      body: { action: "connect", phoneNumber: cleanPhone, password },
    });
    setSubmitting(false);
    if (error || data?.error) {
      toast.error(`Herio-სთან დაკავშირება ვერ მოხერხდა: ${data?.error || error?.message}`);
      return;
    }
    toast.success("Herio წარმატებით დაკავშირდა");
    setPassword("");
    setShowForm(false);
    loadStatus();
  };

  const handleRefresh = async () => {
    setSubmitting(true);
    const { data, error } = await supabase.functions.invoke("herio-auth", {
      body: { action: "refresh" },
    });
    setSubmitting(false);
    if (error || data?.error) {
      toast.error(`Token-ის განახლება ვერ მოხერხდა: ${data?.error || error?.message}`);
      return;
    }
    toast.success("Token განახლდა");
    loadStatus();
  };

  const handleDisconnect = async () => {
    if (!confirm("ნამდვილად გსურთ Herio-სთან კავშირის გათიშვა?")) return;
    setSubmitting(true);
    const { error } = await supabase.functions.invoke("herio-auth", {
      body: { action: "disconnect" },
    });
    setSubmitting(false);
    if (error) {
      toast.error("გათიშვა ვერ მოხერხდა");
      return;
    }
    toast.success("Herio კავშირი გათიშულია");
    setPhoneNumber("");
    setPassword("");
    loadStatus();
  };

  const displayedPhone = status?.phoneNumber || status?.email || "-";

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Briefcase className="h-5 w-5" />
          Herio ინტეგრაცია
          {status?.connected ? (
            <Badge variant="default" className="ml-2 gap-1">
              <CheckCircle2 className="h-3 w-3" />
              დაკავშირებულია
            </Badge>
          ) : (
            <Badge variant="secondary" className="ml-2 gap-1">
              <XCircle className="h-3 w-3" />
              გათიშულია
            </Badge>
          )}
        </CardTitle>
        <CardDescription>
          დააკავშირეთ თქვენი Herio Business ანგარიში - ვაკანსიების და კანდიდატების სამართავად პირდაპირ TalentOS-დან.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {loading ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            იტვირთება...
          </div>
        ) : status?.connected && !showForm ? (
          <div className="space-y-4">
            <div className="grid gap-3 md:grid-cols-2 text-sm">
              <div className="rounded-lg border p-3">
                <p className="text-muted-foreground">ტელეფონი</p>
                <p className="font-medium">{displayedPhone}</p>
              </div>
              <div className="rounded-lg border p-3">
                <p className="text-muted-foreground">Herio User ID</p>
                <p className="font-mono text-xs break-all">{status.herio_user_id || "-"}</p>
              </div>
              <div className="rounded-lg border p-3">
                <p className="text-muted-foreground">ბოლო შესვლა</p>
                <p className="font-medium">
                  {status.last_login_at
                    ? new Date(status.last_login_at).toLocaleString("ka-GE")
                    : "-"}
                </p>
              </div>
              <div className="rounded-lg border p-3">
                <p className="text-muted-foreground">Token-ის ვადა</p>
                <p className="font-medium">
                  {status.token_expires_at
                    ? new Date(status.token_expires_at).toLocaleString("ka-GE")
                    : "-"}
                </p>
              </div>
            </div>

            {status.last_error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>ბოლო შეცდომა</AlertTitle>
                <AlertDescription className="text-xs break-all">{status.last_error}</AlertDescription>
              </Alert>
            )}

            <div className="flex flex-wrap gap-2">
              <Button onClick={handleRefresh} disabled={submitting} variant="outline" size="sm">
                {submitting ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
                Token-ის განახლება
              </Button>
              <Button onClick={() => setShowForm(true)} variant="outline" size="sm">
                ანგარიშის შეცვლა
              </Button>
              <Button onClick={handleDisconnect} disabled={submitting} variant="destructive" size="sm">
                <LogOut className="h-4 w-4 mr-2" />
                გათიშვა
              </Button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleConnect} className="space-y-4">
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Herio API იყენებს ტელეფონის ნომერს + პაროლს ავტორიზაციისთვის (ისევე როგორც Herio აპლიკაციაში).
                შეიყვანეთ 9-ნიშნა ნომერი ქვეყნის კოდის გარეშე (მაგ. <code className="font-mono">555123456</code>).
                პაროლი შეინახება AES-256-GCM დაშიფრულად.
              </AlertDescription>
            </Alert>

            <div className="space-y-2">
              <Label htmlFor="herio-phone">Herio ტელეფონი</Label>
              <Input
                id="herio-phone"
                type="tel"
                inputMode="numeric"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="555123456"
                maxLength={12}
                autoComplete="off"
                required
              />
              <p className="text-xs text-muted-foreground">9 ციფრი, ქვეყნის კოდის (+995) გარეშე</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="herio-password">Herio პაროლი</Label>
              <Input
                id="herio-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="new-password"
                required
              />
            </div>

            <div className="flex gap-2">
              <Button type="submit" disabled={submitting}>
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                დაკავშირება
              </Button>
              {status?.connected && (
                <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>
                  გაუქმება
                </Button>
              )}
            </div>
          </form>
        )}
      </CardContent>
    </Card>
  );
}
