import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { MapPin, Plus, Trash2, Edit, Building2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface OfficeLocation {
  id: string;
  name: string;
  address: string | null;
  latitude: number;
  longitude: number;
  radius_meters: number;
  is_active: boolean;
}

export default function OfficeLocationsManager() {
  const [locations, setLocations] = useState<OfficeLocation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editingLocation, setEditingLocation] = useState<OfficeLocation | null>(null);
  
  const [formData, setFormData] = useState({
    name: "",
    address: "",
    latitude: "",
    longitude: "",
    radius_meters: "200",
    is_active: true,
  });

  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const { data, error } = await supabase
        .from("office_locations")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setLocations(data || []);
    } catch (error: any) {
      console.error("Error fetching office locations:", error);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      address: "",
      latitude: "",
      longitude: "",
      radius_meters: "200",
      is_active: true,
    });
    setEditingLocation(null);
  };

  const handleEdit = (location: OfficeLocation) => {
    setEditingLocation(location);
    setFormData({
      name: location.name,
      address: location.address || "",
      latitude: String(location.latitude),
      longitude: String(location.longitude),
      radius_meters: String(location.radius_meters),
      is_active: location.is_active,
    });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!formData.name || !formData.latitude || !formData.longitude) {
      toast.error("გთხოვთ შეავსოთ სავალდებულო ველები");
      return;
    }

    try {
      const locationData = {
        name: formData.name,
        address: formData.address || null,
        latitude: parseFloat(formData.latitude),
        longitude: parseFloat(formData.longitude),
        radius_meters: parseInt(formData.radius_meters) || 200,
        is_active: formData.is_active,
      };

      if (editingLocation) {
        const { error } = await supabase
          .from("office_locations")
          .update(locationData)
          .eq("id", editingLocation.id);

        if (error) throw error;
        toast.success("ოფისის ლოკაცია განახლდა");
      } else {
        const { error } = await supabase
          .from("office_locations")
          .insert([locationData]);

        if (error) throw error;
        toast.success("ოფისის ლოკაცია დაემატა");
      }

      setShowDialog(false);
      resetForm();
      fetchLocations();
    } catch (error: any) {
      toast.error(error.message || "შეცდომა მოხდა");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("დარწმუნებული ხართ?")) return;

    try {
      const { error } = await supabase
        .from("office_locations")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast.success("ოფისის ლოკაცია წაიშალა");
      fetchLocations();
    } catch (error: any) {
      toast.error(error.message || "შეცდომა მოხდა");
    }
  };

  const getCurrentLocation = () => {
    if (!("geolocation" in navigator)) {
      toast.error("თქვენი ბრაუზერი არ უჭერს მხარს ლოკაციის სერვისს");
      return;
    }

    toast.info("ლოკაციის მიღება მიმდინარეობს...");
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setFormData(prev => ({
          ...prev,
          latitude: String(position.coords.latitude.toFixed(6)),
          longitude: String(position.coords.longitude.toFixed(6)),
        }));
        toast.success("მიმდინარე ლოკაცია დაფიქსირდა");
      },
      (error) => {
        let errorMessage = "ლოკაციის მიღება ვერ მოხერხდა";
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "ლოკაციის ნებართვა უარყოფილია. გთხოვთ დაუშვათ ლოკაციის წვდომა ბრაუზერის პარამეტრებში.";
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = "ლოკაციის ინფორმაცია მიუწვდომელია";
            break;
          case error.TIMEOUT:
            errorMessage = "ლოკაციის მოთხოვნის დრო ამოიწურა";
            break;
        }
        toast.error(errorMessage);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>ოფისის ლოკაციები</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">იტვირთება...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                ოფისის ლოკაციები (Geofencing)
              </CardTitle>
              <CardDescription>
                განსაზღვრეთ ოფისების კოორდინატები მობილური დასწრების გადასამოწმებლად
              </CardDescription>
            </div>
            <Button onClick={() => { resetForm(); setShowDialog(true); }}>
              <Plus className="h-4 w-4 mr-2" />
              დამატება
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {locations.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <MapPin className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>ოფისის ლოკაციები არ არის დამატებული</p>
              <p className="text-sm mt-1">დაამატეთ ოფისი Geofencing-ის გასააქტიურებლად</p>
            </div>
          ) : (
            <div className="space-y-3">
              {locations.map((location) => (
                <div
                  key={location.id}
                  className={`p-4 rounded-lg border ${
                    location.is_active ? 'bg-card' : 'bg-muted/50 opacity-60'
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-primary" />
                        <span className="font-medium">{location.name}</span>
                        {!location.is_active && (
                          <span className="text-xs text-muted-foreground">(გამორთული)</span>
                        )}
                      </div>
                      {location.address && (
                        <p className="text-sm text-muted-foreground mt-1">{location.address}</p>
                      )}
                      <div className="text-xs text-muted-foreground mt-2 space-x-3">
                        <span>კოორდინატები: {location.latitude}, {location.longitude}</span>
                        <span>რადიუსი: {location.radius_meters}მ</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => handleEdit(location)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => handleDelete(location.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingLocation ? "ოფისის რედაქტირება" : "ოფისის დამატება"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>სახელი *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="მაგ: მთავარი ოფისი"
              />
            </div>

            <div>
              <Label>მისამართი</Label>
              <Input
                value={formData.address}
                onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                placeholder="მაგ: რუსთაველის გამზ. 1"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>განედი (Latitude) *</Label>
                <Input
                  type="number"
                  step="any"
                  value={formData.latitude}
                  onChange={(e) => setFormData(prev => ({ ...prev, latitude: e.target.value }))}
                  placeholder="41.7151"
                />
              </div>
              <div>
                <Label>გრძედი (Longitude) *</Label>
                <Input
                  type="number"
                  step="any"
                  value={formData.longitude}
                  onChange={(e) => setFormData(prev => ({ ...prev, longitude: e.target.value }))}
                  placeholder="44.8271"
                />
              </div>
            </div>

            <Button 
              type="button" 
              variant="outline" 
              className="w-full"
              onClick={getCurrentLocation}
            >
              <MapPin className="h-4 w-4 mr-2" />
              მიმდინარე ლოკაციის გამოყენება
            </Button>

            <div>
              <Label>რადიუსი (მეტრებში)</Label>
              <Input
                type="number"
                value={formData.radius_meters}
                onChange={(e) => setFormData(prev => ({ ...prev, radius_meters: e.target.value }))}
                placeholder="200"
              />
              <p className="text-xs text-muted-foreground mt-1">
                რამდენ მეტრში უნდა იყოს თანამშრომელი ოფისიდან check-in-ის დროს
              </p>
            </div>

            <div className="flex items-center justify-between">
              <Label>აქტიური</Label>
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              გაუქმება
            </Button>
            <Button onClick={handleSave}>
              შენახვა
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
