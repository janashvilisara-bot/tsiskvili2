import { Link, NavLink } from "react-router-dom";
import { Menubar, MenubarContent, MenubarItem, MenubarMenu, MenubarTrigger } from "@/components/ui/menubar";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Building2, MessageSquare, Home, Users, Clock, Smartphone, User, DollarSign, FileText, Calendar, Briefcase, BarChart3, Bell, Network, Settings, Shield, Cog, FileCheck, Car, Plane, ChevronRight } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { useSwipe } from "@/hooks/use-swipe";
import { Separator } from "@/components/ui/separator";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { ThemeToggle } from "@/components/ThemeToggle";
import { LanguageSelector } from "@/components/LanguageSelector";
import { playNotificationSound } from "@/lib/notificationSound";

export default function TopNav() {
  const { user, requestSignOut, userRole } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const isMobile = useIsMobile();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [pendingLeavesCount, setPendingLeavesCount] = useState(0);
  const prevUnreadCountRef = useRef<number | null>(null);

  const swipeHandlers = useSwipe({
    onSwipeRight: () => {
      if (isMobile && !mobileMenuOpen) {
        setMobileMenuOpen(true);
      }
    },
    onSwipeLeft: () => {
      if (isMobile && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    },
    minSwipeDistance: 60,
  });

  useEffect(() => {
    if (!user) return;
    
    fetchUnreadCount();
    fetchPendingLeavesCount();

    // Subscribe to realtime notifications (including public ones)
    const notifChannel = supabase
      .channel('notifications-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'notifications',
        },
        (payload) => {
          // Play sound on new notification INSERT
          if (payload.eventType === 'INSERT') {
            playNotificationSound();
          }
          fetchUnreadCount();
        }
      )
      .subscribe();

    // Subscribe to leave requests to update pending count
    const leaveChannel = supabase
      .channel('leave-requests-count')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'leave_requests' },
        () => {
          fetchPendingLeavesCount();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(notifChannel);
      supabase.removeChannel(leaveChannel);
    };
  }, [user, userRole]);

  const fetchUnreadCount = async () => {
    if (!user) return;
    
    try {
      const { count, error } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .or(`user_id.eq.${user.id},user_id.is.null`)
        .eq('is_read', false);

      if (error) {
        console.error('Error fetching unread count (TopNav):', error);
        return;
      }

      setUnreadCount(count || 0);
    } catch (error) {
      console.error('Error in fetchUnreadCount (TopNav):', error);
    }
  };

  const fetchPendingLeavesCount = async () => {
    if (!user) return;

    let query = supabase
      .from('leave_requests')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending');

    if (userRole === 'admin' || userRole === 'hr_manager') {
      // no extra filters
    } else {
      const { data: emp } = await supabase
        .from('employees')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();
      const empId = emp?.id;
      if (empId) {
        query = query.or(`manager_id.eq.${empId},user_id.eq.${user.id}`);
      } else {
        query = query.eq('user_id', user.id);
      }
    }

    const { count } = await query;
    setPendingLeavesCount(count || 0);
  };

  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    isActive ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground";

  const closeMobileMenu = () => setMobileMenuOpen(false);
  
  // Check if user can manage (admin, hr_manager, department_manager)
  const canManage = userRole === 'admin' || userRole === 'hr_manager' || userRole === 'department_manager';

  return (
    <header className="fixed inset-x-0 top-0 z-50 h-16 border-b border-primary/10 bg-card/80 backdrop-blur-xl shadow-lg supports-[backdrop-filter]:bg-card/60">
      <div className="mx-auto flex h-full max-w-screen-2xl items-center justify-between px-4">
        <Link
          to="/" 
          className="bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-xl font-bold text-transparent hover:scale-105 transition-transform duration-300"
        >
          {t('nav.brandName')}
        </Link>

        <Menubar className="hidden md:flex border-none bg-transparent shadow-none">
          {canManage && (
            <MenubarMenu>
              <MenubarTrigger className="cursor-pointer">{t('nav.companies')}</MenubarTrigger>
              <MenubarContent>
                <MenubarItem asChild>
                  <NavLink to="/contacts" className={getNavCls}>{t('nav.contacts')}</NavLink>
                </MenubarItem>
                <MenubarItem asChild>
                  <NavLink to="/deals" className={getNavCls}>{t('nav.deals')}</NavLink>
                </MenubarItem>
              </MenubarContent>
            </MenubarMenu>
          )}

          {canManage && (
            <MenubarMenu>
              <MenubarTrigger className="cursor-pointer">Teams</MenubarTrigger>
              <MenubarContent>
                <MenubarItem asChild>
                  <NavLink to="/chat" className={getNavCls}>ჩატი და ვიდეო</NavLink>
                </MenubarItem>
              </MenubarContent>
            </MenubarMenu>
          )}

          <MenubarMenu>
            <MenubarTrigger className="cursor-pointer">სტრუქტურა</MenubarTrigger>
            <MenubarContent>
              <MenubarItem asChild>
                <NavLink to="/" end className={getNavCls}>
                  <Home className="mr-2 h-4 w-4" />
                  მთავარი
                </NavLink>
              </MenubarItem>
              {canManage && (
                <MenubarItem asChild>
                  <NavLink to="/employees" className={getNavCls}>
                    <Users className="mr-2 h-4 w-4" />
                    {t('nav.employees')}
                  </NavLink>
                </MenubarItem>
              )}
              <MenubarItem asChild>
                <NavLink to="/attendance" className={getNavCls}>
                  <Clock className="mr-2 h-4 w-4" />
                  {t('nav.attendance')}
                </NavLink>
              </MenubarItem>
              <MenubarItem asChild>
                <NavLink to="/mobile-attendance" className={getNavCls}>
                  <Smartphone className="mr-2 h-4 w-4" />
                  მობილური აღრიცხვა
                </NavLink>
              </MenubarItem>
              <MenubarItem asChild>
                <NavLink to="/employee-portal" className={getNavCls}>
                  <User className="mr-2 h-4 w-4" />
                  ჩემი პორტალი
                </NavLink>
              </MenubarItem>
              {canManage && (
                <>
                  <MenubarItem asChild>
                    <NavLink to="/payroll" className={getNavCls}>
                      <DollarSign className="mr-2 h-4 w-4" />
                      {t('nav.payroll')}
                    </NavLink>
                  </MenubarItem>
                  <MenubarItem asChild>
                    <NavLink to="/documents" className={getNavCls}>
                      <FileText className="mr-2 h-4 w-4" />
                      {t('nav.documents')}
                    </NavLink>
                  </MenubarItem>
                  <MenubarItem asChild>
                    <NavLink to="/calendar" className={getNavCls}>
                      <Calendar className="mr-2 h-4 w-4" />
                      კალენდარი
                    </NavLink>
                  </MenubarItem>
                  <MenubarItem asChild>
                    <NavLink to="/work-schedules" className={getNavCls}>
                      <Calendar className="mr-2 h-4 w-4" />
                      {t('nav.schedules')}
                    </NavLink>
                  </MenubarItem>
                  <MenubarItem asChild>
                    <NavLink to="/vacancies" className={getNavCls}>
                      <Briefcase className="mr-2 h-4 w-4" />
                      {t('nav.vacancies')}
                    </NavLink>
                  </MenubarItem>
                  <MenubarItem asChild>
                    <NavLink to="/reports" className={getNavCls}>
                      <BarChart3 className="mr-2 h-4 w-4" />
                      {t('nav.reports')}
                    </NavLink>
                  </MenubarItem>
                </>
              )}
              <MenubarItem asChild>
                <NavLink to="/notifications" className={getNavCls}>
                  <div className="flex items-center gap-2">
                    <Bell className="mr-2 h-4 w-4" />
                    {t('nav.notifications')}
                    {unreadCount > 0 && (
                      <Badge variant="destructive" className="ml-auto h-5 min-w-[20px] rounded-full px-1 text-xs">
                        {unreadCount}
                      </Badge>
                    )}
                  </div>
                </NavLink>
              </MenubarItem>
            </MenubarContent>
          </MenubarMenu>

          {canManage && (
            <MenubarMenu>
              <MenubarTrigger className="cursor-pointer">ოპციები</MenubarTrigger>
              <MenubarContent>
                <MenubarItem asChild>
                  <NavLink to="/organizational-structure" className={getNavCls}>{t('nav.organization')}</NavLink>
                </MenubarItem>
                <MenubarItem asChild>
                  <NavLink to="/security" className={getNavCls}>უსაფრთხოება</NavLink>
                </MenubarItem>
                <MenubarItem asChild>
                  <NavLink to="/settings" className={getNavCls}>{t('nav.settings')}</NavLink>
                </MenubarItem>
              </MenubarContent>
            </MenubarMenu>
          )}

          <MenubarMenu>
            <MenubarTrigger className="cursor-pointer">{t('nav.requests')}</MenubarTrigger>
            <MenubarContent>
              <MenubarItem asChild>
                <NavLink to="/leave-requests" className={getNavCls}>
                  <div className="flex items-center gap-2">
                    {t('nav.leaveRequests')}
                    {pendingLeavesCount > 0 && (
                      <Badge variant="destructive" className="h-4 min-w-[18px] rounded-full px-1 text-[10px]">
                        {pendingLeavesCount}
                      </Badge>
                    )}
                  </div>
                </NavLink>
              </MenubarItem>
              {canManage && (
                <>
                  <MenubarItem asChild>
                    <NavLink to="/vehicle-requests" className={getNavCls}>{t('nav.vehicleRequests')}</NavLink>
                  </MenubarItem>
                  <MenubarItem asChild>
                    <NavLink to="/business-trip-requests" className={getNavCls}>{t('nav.businessTrips')}</NavLink>
                  </MenubarItem>
                </>
              )}
            </MenubarContent>
          </MenubarMenu>
        </Menubar>

        <div className="flex items-center gap-3">
          {user?.email && (
            <span className="hidden text-sm text-muted-foreground md:inline font-medium">{user.email}</span>
          )}
          
          <LanguageSelector />
          <ThemeToggle />
          
          {isMobile && (
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent 
                side="right" 
                className="w-[85vw] max-w-[320px] overflow-y-auto p-0 touch-pan-y"
                {...swipeHandlers}
              >
                <div className="p-6 border-b bg-gradient-to-br from-primary/5 to-accent/5">
                  <SheetTitle className="text-xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
                    {t('nav.brandName')}
                  </SheetTitle>
                  {user?.email && (
                    <p className="text-xs text-muted-foreground mt-2">{user.email}</p>
                  )}
                </div>
                
                <nav className="flex flex-col py-4">
                  {/* კომპანიები */}
                  {canManage && (
                    <>
                      <div className="px-4 mb-4">
                        <h3 className="px-3 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('nav.companies')}</h3>
                        <div className="space-y-1">
                          <NavLink 
                            to="/contacts" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <Building2 className="h-4 w-4" />
                            <span className="flex-1">{t('nav.contacts')}</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                          <NavLink 
                            to="/deals" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <Briefcase className="h-4 w-4" />
                            <span className="flex-1">{t('nav.deals')}</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                        </div>
                      </div>

                      <Separator className="my-2" />

                      {/* Teams */}
                      <div className="px-4 mb-4">
                        <h3 className="px-3 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Teams</h3>
                        <div className="space-y-1">
                          <NavLink 
                            to="/chat" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <MessageSquare className="h-4 w-4" />
                            <span className="flex-1">ჩატი და ვიდეო</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                        </div>
                      </div>

                      <Separator className="my-2" />
                    </>
                  )}

                  {/* სტრუქტურა */}
                  <div className="px-4 mb-4">
                    <h3 className="px-3 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">სტრუქტურა</h3>
                    <div className="space-y-1">
                      <NavLink 
                        to="/" 
                        end
                        className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                        onClick={closeMobileMenu}
                      >
                        <Home className="h-4 w-4" />
                        <span className="flex-1">მთავარი</span>
                        <ChevronRight className="h-4 w-4 opacity-50" />
                      </NavLink>
                      {canManage && (
                        <NavLink 
                          to="/employees" 
                          className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                          onClick={closeMobileMenu}
                        >
                          <Users className="h-4 w-4" />
                          <span className="flex-1">{t('nav.employees')}</span>
                          <ChevronRight className="h-4 w-4 opacity-50" />
                        </NavLink>
                      )}
                      <NavLink 
                        to="/attendance" 
                        className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                        onClick={closeMobileMenu}
                      >
                        <Clock className="h-4 w-4" />
                        <span className="flex-1">{t('nav.attendance')}</span>
                        <ChevronRight className="h-4 w-4 opacity-50" />
                      </NavLink>
                      <NavLink 
                        to="/mobile-attendance" 
                        className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                        onClick={closeMobileMenu}
                      >
                        <Smartphone className="h-4 w-4" />
                        <span className="flex-1">მობილური აღრიცხვა</span>
                        <ChevronRight className="h-4 w-4 opacity-50" />
                      </NavLink>
                      <NavLink 
                        to="/employee-portal" 
                        className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                        onClick={closeMobileMenu}
                      >
                        <User className="h-4 w-4" />
                        <span className="flex-1">ჩემი პორტალი</span>
                        <ChevronRight className="h-4 w-4 opacity-50" />
                      </NavLink>
                      {canManage && (
                        <>
                          <NavLink 
                            to="/payroll" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <DollarSign className="h-4 w-4" />
                            <span className="flex-1">{t('nav.payroll')}</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                          <NavLink 
                            to="/documents" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <FileText className="h-4 w-4" />
                            <span className="flex-1">{t('nav.documents')}</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                          <NavLink 
                            to="/calendar" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <Calendar className="h-4 w-4" />
                            <span className="flex-1">კალენდარი</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                          <NavLink 
                            to="/work-schedules" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <Calendar className="h-4 w-4" />
                            <span className="flex-1">{t('nav.schedules')}</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                          <NavLink 
                            to="/vacancies" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <Briefcase className="h-4 w-4" />
                            <span className="flex-1">{t('nav.vacancies')}</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                          <NavLink 
                            to="/reports" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <BarChart3 className="h-4 w-4" />
                            <span className="flex-1">{t('nav.reports')}</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                        </>
                      )}
                      <NavLink 
                        to="/notifications" 
                        className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                        onClick={closeMobileMenu}
                      >
                        <Bell className="h-4 w-4" />
                        <span className="flex-1">{t('nav.notifications')}</span>
                        {unreadCount > 0 && (
                          <Badge variant="destructive" className="h-5 min-w-[20px] rounded-full px-1 text-xs">
                            {unreadCount}
                          </Badge>
                        )}
                        <ChevronRight className="h-4 w-4 opacity-50" />
                      </NavLink>
                    </div>
                  </div>

                  {canManage && (
                    <>
                      <Separator className="my-2" />

                      {/* ოპციები */}
                      <div className="px-4 mb-4">
                        <h3 className="px-3 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">ოპციები</h3>
                        <div className="space-y-1">
                          <NavLink 
                            to="/organizational-structure" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <Network className="h-4 w-4" />
                            <span className="flex-1">{t('nav.organization')}</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                          <NavLink 
                            to="/security"
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <Shield className="h-4 w-4" />
                            <span className="flex-1">უსაფრთხოება</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                          <NavLink 
                            to="/settings" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <Settings className="h-4 w-4" />
                            <span className="flex-1">{t('nav.settings')}</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                        </div>
                      </div>
                    </>
                  )}

                  <Separator className="my-2" />

                  {/* მოთხოვნები */}
                  <div className="px-4 mb-4">
                    <h3 className="px-3 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t('nav.requests')}</h3>
                    <div className="space-y-1">
                      <NavLink 
                        to="/leave-requests" 
                        className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                        onClick={closeMobileMenu}
                      >
                        <FileCheck className="h-4 w-4" />
                        <span className="flex-1">{t('nav.leaveRequests')}</span>
                        {pendingLeavesCount > 0 && (
                          <Badge variant="destructive" className="h-5 min-w-[20px] rounded-full px-1 text-xs">
                            {pendingLeavesCount}
                          </Badge>
                        )}
                        <ChevronRight className="h-4 w-4 opacity-50" />
                      </NavLink>
                      {canManage && (
                        <>
                          <NavLink 
                            to="/vehicle-requests" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <Car className="h-4 w-4" />
                            <span className="flex-1">{t('nav.vehicleRequests')}</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                          <NavLink 
                            to="/business-trip-requests" 
                            className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-foreground hover:bg-accent/50'}`}
                            onClick={closeMobileMenu}
                          >
                            <Plane className="h-4 w-4" />
                            <span className="flex-1">{t('nav.businessTrips')}</span>
                            <ChevronRight className="h-4 w-4 opacity-50" />
                          </NavLink>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="px-4 pt-4 pb-6 border-t">
                    <Button 
                      variant="gradient" 
                      className="w-full" 
                      onClick={() => {
                        requestSignOut();
                        closeMobileMenu();
                      }}
                    >
                      {t('common.logout')}
                    </Button>
                  </div>
                </nav>
              </SheetContent>
            </Sheet>
          )}
          
          {!isMobile && (
            <Button variant="gradient" size="sm" onClick={() => requestSignOut()}>{t('common.logout')}</Button>
          )}
        </div>
      </div>
    </header>
  );
}
