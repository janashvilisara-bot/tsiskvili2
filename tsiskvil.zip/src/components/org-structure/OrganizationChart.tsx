import { useEffect, useMemo, useRef, useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Building2, ChevronDown, ChevronUp, Users, Minus, Plus, Maximize2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface Employee {
  id?: string;
  full_name: string;
  avatar_url: string | null;
}

interface Department {
  id: string;
  name: string;
  name_en: string | null;
  parent_department_id: string | null;
  manager_id: string | null;
  budget: number | null;
  headcount_limit: number | null;
  description: string | null;
  is_active: boolean;
  manager?: Employee;
  employee_count?: number;
  children?: Department[];
}

interface OrganizationChartProps {
  departments: Department[];
  onDepartmentClick?: (dept: Department) => void;
  rootLabel?: string;
}

const initials = (name: string) =>
  name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase();

const DepartmentNode = ({
  department,
  collapsed,
  toggle,
  onDepartmentClick,
}: {
  department: Department;
  collapsed: Set<string>;
  toggle: (id: string) => void;
  onDepartmentClick?: (dept: Department) => void;
}) => {
  const children = department.children ?? [];
  const hasChildren = children.length > 0;
  const isCollapsed = collapsed.has(department.id);

  return (
    <li>
      <div className="flex flex-col items-center">
        <Card
          onClick={() => onDepartmentClick?.(department)}
          className={cn(
            "relative w-[216px] cursor-pointer overflow-hidden border bg-card p-3 text-left shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-lg hover:border-primary/40",
            !department.is_active && "opacity-60"
          )}
        >
          <span className="absolute inset-x-0 top-0 h-1 bg-primary" />
          <div className="mt-1 flex items-start gap-2">
            <div className="shrink-0 rounded-lg bg-primary/10 p-1.5">
              <Building2 className="h-4 w-4 text-primary" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="text-sm font-semibold leading-tight text-foreground break-words">{department.name}</h3>
              {department.name_en && (
                <p className="truncate text-[11px] text-muted-foreground">{department.name_en}</p>
              )}
            </div>
            <span
              className={cn("mt-1 h-2 w-2 shrink-0 rounded-full", department.is_active ? "bg-primary" : "bg-muted-foreground")}
              title={department.is_active ? "აქტიური" : "არააქტიური"}
            />
          </div>

          <div className="mt-3 flex items-center gap-2 rounded-md bg-muted/60 p-1.5">
            {department.manager ? (
              <>
                <Avatar className="h-7 w-7 shrink-0">
                  <AvatarImage src={department.manager.avatar_url || undefined} />
                  <AvatarFallback className="text-[10px]">{initials(department.manager.full_name)}</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <p className="truncate text-xs font-medium text-foreground">{department.manager.full_name}</p>
                  <p className="text-[10px] text-muted-foreground">მენეჯერი</p>
                </div>
              </>
            ) : (
              <p className="px-1 py-1 text-xs text-muted-foreground">მენეჯერი არ არის</p>
            )}
          </div>

          <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <Users className="h-3.5 w-3.5" />
              <span className="font-semibold text-foreground">{department.employee_count || 0}</span>
              {department.headcount_limit ? <span>/ {department.headcount_limit}</span> : null}
            </span>
            {department.budget ? (
              <span className="font-medium text-foreground">
                {new Intl.NumberFormat("ka-GE", { style: "currency", currency: "GEL", maximumFractionDigits: 0 }).format(department.budget)}
              </span>
            ) : null}
          </div>
        </Card>

        {hasChildren && (
          <button
            type="button"
            aria-label={isCollapsed ? "გაშლა" : "ჩაკეცვა"}
            onClick={() => toggle(department.id)}
            className="relative z-10 -mt-3 inline-flex h-6 min-w-6 items-center justify-center gap-0.5 rounded-full border bg-background px-1.5 text-[11px] font-medium text-muted-foreground shadow-sm hover:border-primary hover:text-primary"
          >
            {isCollapsed ? <ChevronDown className="h-3 w-3" /> : <ChevronUp className="h-3 w-3" />}
            {isCollapsed && children.length}
          </button>
        )}
      </div>

      {hasChildren && !isCollapsed && (
        <ul>
          {children.map((child) => (
            <DepartmentNode key={child.id} department={child} collapsed={collapsed} toggle={toggle} onDepartmentClick={onDepartmentClick} />
          ))}
        </ul>
      )}
    </li>
  );
};

export const OrganizationChart = ({ departments, onDepartmentClick, rootLabel = "ორგანიზაცია" }: OrganizationChartProps) => {
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [zoom, setZoom] = useState(1);
  const scrollRef = useRef<HTMLDivElement>(null);

  const roots = useMemo(() => {
    const ids = new Set(departments.map((d) => d.id));
    const build = (parentId: string | null): Department[] =>
      departments
        .filter((d) => (parentId === null ? !d.parent_department_id || !ids.has(d.parent_department_id) : d.parent_department_id === parentId))
        .map((d) => ({ ...d, children: build(d.id) }))
        .sort((a, b) => a.name.localeCompare(b.name, "ka"));
    return build(null);
  }, [departments]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollLeft = (el.scrollWidth - el.clientWidth) / 2;
  }, [roots.length, zoom]);

  const totalEmployees = departments.reduce((s, d) => s + (d.employee_count || 0), 0);
  const parentIds = departments.filter((d) => departments.some((x) => x.parent_department_id === d.id)).map((d) => d.id);

  const toggle = (id: string) =>
    setCollapsed((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  if (roots.length === 0) {
    return (
      <Card className="p-12">
        <div className="text-center text-muted-foreground">
          <Building2 className="mx-auto mb-4 h-12 w-12 opacity-50" />
          <p>დეპარტამენტები არ არის</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b px-4 py-2">
        <p className="text-xs text-muted-foreground">დააჭირე დეპარტამენტს დეტალებისთვის · ისარი - ჩაკეცვა/გაშლა</p>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" onClick={() => setCollapsed(new Set(parentIds))}>ჩაკეცვა</Button>
          <Button variant="ghost" size="sm" onClick={() => setCollapsed(new Set())}>გაშლა</Button>
          <span className="mx-1 h-4 w-px bg-border" />
          <Button variant="outline" size="icon" className="h-8 w-8" aria-label="დაპატარავება" onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.1).toFixed(1)))}>
            <Minus className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8" aria-label="100%" onClick={() => setZoom(1)}>
            <Maximize2 className="h-3.5 w-3.5" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8" aria-label="გადიდება" onClick={() => setZoom((z) => Math.min(1.4, +(z + 0.1).toFixed(1)))}>
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div ref={scrollRef} className="overflow-auto bg-muted/20 p-6" style={{ maxHeight: "70vh" }}>
        <div className="org-tree mx-auto w-max min-w-full" style={{ zoom }}>
          <ul>
            <li>
              <div className="flex flex-col items-center">
                <div className="rounded-xl bg-primary px-6 py-3 text-center text-primary-foreground shadow-md">
                  <p className="text-sm font-semibold">{rootLabel}</p>
                  <p className="text-[11px] opacity-80">
                    {departments.length} დეპარტამენტი · {totalEmployees} თანამშრომელი
                  </p>
                </div>
              </div>
              <ul>
                {roots.map((dept) => (
                  <DepartmentNode key={dept.id} department={dept} collapsed={collapsed} toggle={toggle} onDepartmentClick={onDepartmentClick} />
                ))}
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </Card>
  );
};
