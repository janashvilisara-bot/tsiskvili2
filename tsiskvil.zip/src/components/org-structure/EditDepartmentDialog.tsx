import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Department {
  id: string;
  name: string;
  name_en: string | null;
  parent_department_id: string | null;
  manager_id: string | null;
  budget: number | null;
  headcount_limit: number | null;
  description: string | null;
  is_active: boolean;
}

interface EditDepartmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  department: Department | null;
  departments: Array<{ id: string; name: string }>;
  employees: Array<{ id: string; full_name: string }>;
  onSuccess?: () => void;
}

export const EditDepartmentDialog = ({
  open,
  onOpenChange,
  department,
  departments,
  employees,
  onSuccess
}: EditDepartmentDialogProps) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    name_en: '',
    parent_department_id: 'none',
    manager_id: 'none',
    budget: '',
    headcount_limit: '',
    description: '',
    is_active: true
  });

  useEffect(() => {
    if (department) {
      setFormData({
        name: department.name || '',
        name_en: department.name_en || '',
        parent_department_id: department.parent_department_id || 'none',
        manager_id: department.manager_id || 'none',
        budget: department.budget?.toString() || '',
        headcount_limit: department.headcount_limit?.toString() || '',
        description: department.description || '',
        is_active: department.is_active
      });
    }
  }, [department]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!department) return;
    
    setLoading(true);

    try {
      const { error } = await supabase
        .from('departments')
        .update({
          name: formData.name,
          name_en: formData.name_en || null,
          parent_department_id: formData.parent_department_id && formData.parent_department_id !== 'none' ? formData.parent_department_id : null,
          manager_id: formData.manager_id && formData.manager_id !== 'none' ? formData.manager_id : null,
          budget: formData.budget ? parseFloat(formData.budget) : null,
          headcount_limit: formData.headcount_limit ? parseInt(formData.headcount_limit) : null,
          description: formData.description || null,
          is_active: formData.is_active
        })
        .eq('id', department.id);

      if (error) throw error;

      toast.success('დეპარტამენტი წარმატებით განახლდა');
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>დეპარტამენტის რედაქტირება</DialogTitle>
          <DialogDescription>
            შეცვალეთ დეპარტამენტის ინფორმაცია
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">დასახელება (ქართული) *</Label>
              <Input
                id="name"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="მაგ: IT დეპარტამენტი"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name_en">დასახელება (ინგლისური)</Label>
              <Input
                id="name_en"
                value={formData.name_en}
                onChange={(e) => setFormData({ ...formData, name_en: e.target.value })}
                placeholder="e.g: IT Department"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="parent">მშობელი დეპარტამენტი</Label>
              <Select value={formData.parent_department_id} onValueChange={(value) => setFormData({ ...formData, parent_department_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="არჩევა..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">არცერთი</SelectItem>
                  {departments.filter(d => d.id !== department?.id).map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="manager">მენეჯერი</Label>
              <Select value={formData.manager_id} onValueChange={(value) => setFormData({ ...formData, manager_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="არჩევა..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">არჩევა...</SelectItem>
                  {employees.map((emp) => (
                    <SelectItem key={emp.id} value={emp.id}>
                      {emp.full_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="budget">ბიუჯეტი (₾)</Label>
              <Input
                id="budget"
                type="number"
                step="0.01"
                value={formData.budget}
                onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="headcount">საშტატო ლიმიტი</Label>
              <Input
                id="headcount"
                type="number"
                value={formData.headcount_limit}
                onChange={(e) => setFormData({ ...formData, headcount_limit: e.target.value })}
                placeholder="0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">აღწერა</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="დეპარტამენტის მოკლე აღწერა..."
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              გაუქმება
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'ინახება...' : 'შენახვა'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
