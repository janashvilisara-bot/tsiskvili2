import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { 
  LineChart, 
  Line, 
  AreaChart,
  Area,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { TrendingUp, TrendingDown, Calendar, Users, DollarSign } from "lucide-react";
import { toast } from "sonner";

interface TrendData {
  period: string;
  [key: string]: number | string;
}

interface DepartmentTrendsProps {
  departments: Array<{
    id: string;
    name: string;
  }>;
}

const COLORS = [
  'hsl(var(--primary))',
  'hsl(var(--secondary))',
  'hsl(var(--accent))',
  '#8884d8',
  '#82ca9d',
  '#ffc658',
  '#ff7c7c',
  '#a78bfa',
];

export const DepartmentTrends = ({ departments }: DepartmentTrendsProps) => {
  const [periodType, setPeriodType] = useState<'monthly' | 'quarterly' | 'yearly'>('monthly');
  const [selectedDepartments, setSelectedDepartments] = useState<string[]>([]);
  const [budgetTrends, setBudgetTrends] = useState<TrendData[]>([]);
  const [employeeTrends, setEmployeeTrends] = useState<TrendData[]>([]);
  const [salaryTrends, setSalaryTrends] = useState<TrendData[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (departments.length > 0 && selectedDepartments.length === 0) {
      // Auto-select top 3 departments
      setSelectedDepartments(departments.slice(0, 3).map(d => d.id));
    }
  }, [departments]);

  useEffect(() => {
    if (selectedDepartments.length > 0) {
      fetchTrendData();
    }
  }, [periodType, selectedDepartments]);

  const fetchTrendData = async () => {
    try {
      setLoading(true);
      
      // Generate periods for the last 12 months, 4 quarters, or 3 years
      const periods = generatePeriods(periodType);
      
      // Fetch budget trends
      const budgetData: TrendData[] = [];
      const employeeData: TrendData[] = [];
      const salaryData: TrendData[] = [];

      for (const period of periods) {
        const periodData: any = { period: period.label };
        const empPeriodData: any = { period: period.label };
        const salPeriodData: any = { period: period.label };

        for (const deptId of selectedDepartments) {
          const dept = departments.find(d => d.id === deptId);
          if (!dept) continue;

          // Fetch budget for period
          const { data: budgetPlans } = await supabase
            .from('budget_plans')
            .select('planned_amount, actual_amount')
            .eq('department_id', deptId)
            .gte('created_at', period.start)
            .lte('created_at', period.end);

          const totalBudget = budgetPlans?.reduce((sum, b) => sum + (b.actual_amount || b.planned_amount), 0) || 0;
          periodData[dept.name] = totalBudget;

          // Fetch employee count for period
          const { count: empCount } = await supabase
            .from('employees')
            .select('*', { count: 'exact', head: true })
            .eq('department', dept.name)
            .eq('status', 'active')
            .lte('hire_date', period.end);

          empPeriodData[dept.name] = empCount || 0;

          // Fetch average salary for period
          const { data: salaryData } = await supabase
            .from('employees')
            .select('salary')
            .eq('department', dept.name)
            .eq('status', 'active')
            .lte('hire_date', period.end)
            .not('salary', 'is', null);

          const avgSalary = salaryData && salaryData.length > 0
            ? salaryData.reduce((sum, e) => sum + (e.salary || 0), 0) / salaryData.length
            : 0;
          
          salPeriodData[dept.name] = Math.round(avgSalary);
        }

        budgetData.push(periodData);
        employeeData.push(empPeriodData);
        salaryData.push(salPeriodData);
      }

      setBudgetTrends(budgetData);
      setEmployeeTrends(employeeData);
      setSalaryTrends(salaryData);
    } catch (error: any) {
      console.error('Error fetching trends:', error);
      toast.error('ტრენდების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setLoading(false);
    }
  };

  const generatePeriods = (type: 'monthly' | 'quarterly' | 'yearly') => {
    const periods: Array<{ label: string; start: string; end: string }> = [];
    const now = new Date();

    if (type === 'monthly') {
      for (let i = 11; i >= 0; i--) {
        const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const endDate = new Date(date.getFullYear(), date.getMonth() + 1, 0);
        periods.push({
          label: date.toLocaleDateString('ka-GE', { year: 'numeric', month: 'short' }),
          start: date.toISOString().split('T')[0],
          end: endDate.toISOString().split('T')[0],
        });
      }
    } else if (type === 'quarterly') {
      for (let i = 7; i >= 0; i--) {
        const quarter = Math.floor((now.getMonth() - (i * 3)) / 3) % 4;
        const year = now.getFullYear() - Math.floor((now.getMonth() - (i * 3)) / 12);
        const startMonth = quarter * 3;
        const date = new Date(year, startMonth, 1);
        const endDate = new Date(year, startMonth + 3, 0);
        periods.push({
          label: `Q${quarter + 1} ${year}`,
          start: date.toISOString().split('T')[0],
          end: endDate.toISOString().split('T')[0],
        });
      }
    } else {
      for (let i = 2; i >= 0; i--) {
        const year = now.getFullYear() - i;
        periods.push({
          label: `${year}`,
          start: `${year}-01-01`,
          end: `${year}-12-31`,
        });
      }
    }

    return periods;
  };

  const calculateTrend = (data: TrendData[], deptName: string) => {
    if (data.length < 2) return 0;
    const latest = data[data.length - 1][deptName] as number || 0;
    const previous = data[data.length - 2][deptName] as number || 0;
    if (previous === 0) return 0;
    return ((latest - previous) / previous * 100);
  };

  const selectedDeptNames = selectedDepartments
    .map(id => departments.find(d => d.id === id)?.name)
    .filter(Boolean) as string[];

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4">
            <div>
              <CardTitle>დროის მიხედვით ტრენდები</CardTitle>
              <CardDescription>დეპარტამენტების მაჩვენებლების ცვლილება დროში</CardDescription>
            </div>
            <div className="flex items-center gap-3">
              <Select value={periodType} onValueChange={(v: any) => setPeriodType(v)}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      თვიური
                    </div>
                  </SelectItem>
                  <SelectItem value="quarterly">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      კვარტალური
                    </div>
                  </SelectItem>
                  <SelectItem value="yearly">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      წლიური
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <p className="text-sm font-medium">აირჩიეთ დეპარტამენტები (მაქს. 5)</p>
            <div className="flex flex-wrap gap-2">
              {departments.map((dept) => {
                const isSelected = selectedDepartments.includes(dept.id);
                return (
                  <Badge
                    key={dept.id}
                    variant={isSelected ? "default" : "outline"}
                    className="cursor-pointer hover:bg-primary/10 transition-colors"
                    onClick={() => {
                      if (isSelected) {
                        setSelectedDepartments(prev => prev.filter(id => id !== dept.id));
                      } else if (selectedDepartments.length < 5) {
                        setSelectedDepartments(prev => [...prev, dept.id]);
                      } else {
                        toast.warning('მაქსიმუმ 5 დეპარტამენტის არჩევა შეგიძლიათ');
                      }
                    }}
                  >
                    {dept.name}
                  </Badge>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {loading ? (
        <Card>
          <CardContent className="p-12 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">იტვირთება...</p>
          </CardContent>
        </Card>
      ) : selectedDepartments.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-muted-foreground">აირჩიეთ მინიმუმ 1 დეპარტამენტი</p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Trend Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {selectedDeptNames.map((deptName, index) => {
              const budgetTrend = calculateTrend(budgetTrends, deptName);
              const empTrend = calculateTrend(employeeTrends, deptName);
              const salaryTrend = calculateTrend(salaryTrends, deptName);

              return (
                <Card key={deptName}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">{deptName}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">ბიუჯეტი</span>
                      <div className="flex items-center gap-1">
                        {budgetTrend > 0 ? (
                          <TrendingUp className="h-4 w-4 text-green-600" />
                        ) : budgetTrend < 0 ? (
                          <TrendingDown className="h-4 w-4 text-red-600" />
                        ) : null}
                        <span className={`text-sm font-medium ${
                          budgetTrend > 0 ? 'text-green-600' : budgetTrend < 0 ? 'text-red-600' : 'text-muted-foreground'
                        }`}>
                          {budgetTrend > 0 ? '+' : ''}{budgetTrend.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">თანამშრომლები</span>
                      <div className="flex items-center gap-1">
                        {empTrend > 0 ? (
                          <TrendingUp className="h-4 w-4 text-green-600" />
                        ) : empTrend < 0 ? (
                          <TrendingDown className="h-4 w-4 text-red-600" />
                        ) : null}
                        <span className={`text-sm font-medium ${
                          empTrend > 0 ? 'text-green-600' : empTrend < 0 ? 'text-red-600' : 'text-muted-foreground'
                        }`}>
                          {empTrend > 0 ? '+' : ''}{empTrend.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">საშუალო ხელფასი</span>
                      <div className="flex items-center gap-1">
                        {salaryTrend > 0 ? (
                          <TrendingUp className="h-4 w-4 text-green-600" />
                        ) : salaryTrend < 0 ? (
                          <TrendingDown className="h-4 w-4 text-red-600" />
                        ) : null}
                        <span className={`text-sm font-medium ${
                          salaryTrend > 0 ? 'text-green-600' : salaryTrend < 0 ? 'text-red-600' : 'text-muted-foreground'
                        }`}>
                          {salaryTrend > 0 ? '+' : ''}{salaryTrend.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Budget Trend Chart */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <CardTitle>ბიუჯეტის ტრენდი</CardTitle>
              </div>
              <CardDescription>
                ბიუჯეტის ცვლილება {periodType === 'monthly' ? 'თვეების' : periodType === 'quarterly' ? 'კვარტალების' : 'წლების'} მიხედვით
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <AreaChart data={budgetTrends}>
                  <defs>
                    {selectedDeptNames.map((name, index) => (
                      <linearGradient key={name} id={`color${index}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={COLORS[index]} stopOpacity={0.3}/>
                        <stop offset="95%" stopColor={COLORS[index]} stopOpacity={0}/>
                      </linearGradient>
                    ))}
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="period" 
                    tick={{ fill: 'hsl(var(--foreground))' }}
                  />
                  <YAxis tick={{ fill: 'hsl(var(--foreground))' }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                    formatter={(value: number) => new Intl.NumberFormat('ka-GE', {
                      style: 'currency',
                      currency: 'GEL',
                      minimumFractionDigits: 0,
                    }).format(value)}
                  />
                  <Legend />
                  {selectedDeptNames.map((name, index) => (
                    <Area
                      key={name}
                      type="monotone"
                      dataKey={name}
                      stroke={COLORS[index]}
                      fillOpacity={1}
                      fill={`url(#color${index})`}
                    />
                  ))}
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Employee Count Trend Chart */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-blue-600" />
                <CardTitle>თანამშრომლების რაოდენობის ტრენდი</CardTitle>
              </div>
              <CardDescription>
                თანამშრომლების რაოდენობის ცვლილება {periodType === 'monthly' ? 'თვეების' : periodType === 'quarterly' ? 'კვარტალების' : 'წლების'} მიხედვით
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={employeeTrends}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="period" 
                    tick={{ fill: 'hsl(var(--foreground))' }}
                  />
                  <YAxis tick={{ fill: 'hsl(var(--foreground))' }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  {selectedDeptNames.map((name, index) => (
                    <Line
                      key={name}
                      type="monotone"
                      dataKey={name}
                      stroke={COLORS[index]}
                      strokeWidth={2}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Average Salary Trend Chart */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-purple-600" />
                <CardTitle>საშუალო ხელფასის ტრენდი</CardTitle>
              </div>
              <CardDescription>
                საშუალო ხელფასის ცვლილება {periodType === 'monthly' ? 'თვეების' : periodType === 'quarterly' ? 'კვარტალების' : 'წლების'} მიხედვით
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={salaryTrends}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="period" 
                    tick={{ fill: 'hsl(var(--foreground))' }}
                  />
                  <YAxis tick={{ fill: 'hsl(var(--foreground))' }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                    formatter={(value: number) => new Intl.NumberFormat('ka-GE', {
                      style: 'currency',
                      currency: 'GEL',
                      minimumFractionDigits: 0,
                    }).format(value)}
                  />
                  <Legend />
                  {selectedDeptNames.map((name, index) => (
                    <Line
                      key={name}
                      type="monotone"
                      dataKey={name}
                      stroke={COLORS[index]}
                      strokeWidth={2}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
};