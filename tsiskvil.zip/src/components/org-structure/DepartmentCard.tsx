import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Building2, Users, DollarSign, Pencil, Trash2, MoreVertical, Power } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

interface Employee {
  full_name: string;
  avatar_url: string | null;
}

interface Department {
  id: string;
  name: string;
  name_en: string | null;
  parent_department_id: string | null;
  manager_id: string | null;
  budget: number | null;
  headcount_limit: number | null;
  description: string | null;
  is_active: boolean;
  manager?: Employee;
  employee_count?: number;
}

interface DepartmentCardProps {
  department: Department;
  onEdit?: (dept: Department) => void;
  onDelete?: (deptId: string, deptName: string) => void;
  onToggleStatus?: (dept: Department) => void;
  canManage?: boolean;
  compact?: boolean;
}

export const DepartmentCard = ({ 
  department, 
  onEdit, 
  onDelete,
  onToggleStatus,
  canManage = false,
  compact = false
}: DepartmentCardProps) => {
  const navigate = useNavigate();

  if (compact) {
    return (
      <Card className="overflow-hidden transition-all hover:shadow-md cursor-pointer" onClick={() => navigate(`/department/${department.id}`)}>
        <div className="h-1.5 bg-gradient-to-r from-primary via-primary/70 to-primary/50" />
        
        <CardHeader className="pb-2 pt-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-start gap-2 flex-1">
              <div className="p-1.5 rounded-lg bg-primary/10">
                <Building2 className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-sm mb-0.5 line-clamp-1">{department.name}</h3>
                {department.name_en && (
                  <p className="text-xs text-muted-foreground line-clamp-1">{department.name_en}</p>
                )}
              </div>
            </div>
            
            {canManage && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-6 w-6"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <MoreVertical className="h-3 w-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={(e) => {
                    e.stopPropagation();
                    onEdit?.(department);
                  }}>
                    <Pencil className="h-4 w-4 mr-2" />
                    რედაქტირება
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={(e) => {
                    e.stopPropagation();
                    onToggleStatus?.(department);
                  }}>
                    <Power className="h-4 w-4 mr-2" />
                    {department.is_active ? 'გამორთვა' : 'ჩართვა'}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete?.(department.id, department.name);
                    }}
                    className="text-destructive"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    წაშლა
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </CardHeader>

        <CardContent className="pt-2 pb-3 space-y-2">
          {/* Manager - Compact */}
          {department.manager && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Users className="h-3 w-3" />
              <span className="line-clamp-1">{department.manager.full_name}</span>
            </div>
          )}

          {/* Stats - Compact Grid */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2 rounded-md bg-blue-500/10">
              <div className="flex items-center gap-1 mb-0.5">
                <Users className="h-3 w-3 text-blue-600" />
                <span className="font-medium text-blue-600">{department.employee_count || 0}</span>
              </div>
            </div>

            {department.budget !== null && (
              <div className="p-2 rounded-md bg-green-500/10">
                <div className="flex items-center gap-1 mb-0.5">
                  <DollarSign className="h-3 w-3 text-green-600" />
                  <span className="font-medium text-green-600">
                    {new Intl.NumberFormat('ka-GE', {
                      notation: 'compact',
                      compactDisplay: 'short',
                      maximumFractionDigits: 0,
                    }).format(department.budget)}₾
                  </span>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="group overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-blue-500/20 cursor-pointer border-blue-500/20 bg-gradient-to-br from-blue-500/5 via-background to-background backdrop-blur-sm" onClick={() => navigate(`/department/${department.id}`)}>
      <div className="h-2 bg-gradient-to-r from-blue-600 via-blue-500 to-blue-400 group-hover:h-3 transition-all" />
      
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 flex-1">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500/20 to-blue-500/10 backdrop-blur-sm border border-blue-500/30 group-hover:scale-110 transition-transform">
              <Building2 className="h-5 w-5 text-blue-600" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-lg mb-1 group-hover:text-blue-600 transition-colors">{department.name}</h3>
              {department.name_en && (
                <p className="text-sm text-muted-foreground">{department.name_en}</p>
              )}
              {department.description && (
                <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                  {department.description}
                </p>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant={department.is_active ? "default" : "secondary"} className={department.is_active ? "bg-gradient-to-r from-green-600 to-green-500" : ""}>
              {department.is_active ? 'აქტიური' : 'არააქტიური'}
            </Badge>
            
            {canManage && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 hover:bg-blue-500/10"
                  >
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={(e) => {
                    e.stopPropagation();
                    onEdit?.(department);
                  }}>
                    <Pencil className="h-4 w-4 mr-2" />
                    რედაქტირება
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={(e) => {
                    e.stopPropagation();
                    onToggleStatus?.(department);
                  }}>
                    <Power className="h-4 w-4 mr-2" />
                    {department.is_active ? 'გამორთვა' : 'ჩართვა'}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete?.(department.id, department.name);
                    }}
                    className="text-destructive"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    წაშლა
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Manager */}
        {department.manager && (
          <div className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-br from-blue-500/10 to-background border border-blue-500/20 backdrop-blur-sm">
            <Avatar className="h-10 w-10 ring-2 ring-blue-500/30">
              <AvatarImage src={department.manager.avatar_url || undefined} />
              <AvatarFallback className="bg-gradient-to-br from-blue-600 to-blue-400 text-white">
                {department.manager.full_name.split(' ').map(n => n[0]).join('').toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-sm">{department.manager.full_name}</p>
              <p className="text-xs text-muted-foreground">დეპარტამენტის მენეჯერი</p>
            </div>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="relative overflow-hidden p-3 rounded-xl bg-gradient-to-br from-blue-600/10 to-blue-400/5 border border-blue-500/30 backdrop-blur-sm group-hover:shadow-lg group-hover:shadow-blue-500/20 transition-all">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative">
              <div className="flex items-center gap-2 mb-1">
                <Users className="h-4 w-4 text-blue-600" />
                <span className="text-xs font-medium text-blue-600">თანამშრომლები</span>
              </div>
              <p className="text-2xl font-bold bg-gradient-to-br from-blue-600 to-blue-400 bg-clip-text text-transparent">
                {department.employee_count || 0}
                {department.headcount_limit && (
                  <span className="text-sm text-muted-foreground ml-1">
                    / {department.headcount_limit}
                  </span>
                )}
              </p>
              {department.headcount_limit && (
                <div className="mt-2 h-1.5 bg-blue-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-600 to-blue-400 rounded-full transition-all"
                    style={{ 
                      width: `${Math.min(((department.employee_count || 0) / department.headcount_limit) * 100, 100)}%` 
                    }}
                  />
                </div>
              )}
            </div>
          </div>

          {department.budget !== null && (
            <div className="relative overflow-hidden p-3 rounded-xl bg-gradient-to-br from-green-600/10 to-green-400/5 border border-green-500/30 backdrop-blur-sm group-hover:shadow-lg group-hover:shadow-green-500/20 transition-all">
              <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-1">
                  <DollarSign className="h-4 w-4 text-green-600" />
                  <span className="text-xs font-medium text-green-600">ბიუჯეტი</span>
                </div>
                <p className="text-lg font-bold bg-gradient-to-br from-green-600 to-green-400 bg-clip-text text-transparent">
                  {new Intl.NumberFormat('ka-GE', {
                    style: 'currency',
                    currency: 'GEL',
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 0,
                  }).format(department.budget)}
                </p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
