import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Sparkles, X } from "lucide-react";
import { cn } from "@/lib/utils";

const POSITION_TEMPLATES = [
  { title: "გენერალური დირექტორი", skills: ["ლიდერშიფი", "სტრატეგიული დაგეგმვა"], responsibilities: "კომპანიის საერთო მართვა და სტრატეგიული ხელმძღვანელობა" },
  { title: "ფინანსური დირექტორი", skills: ["ფინანსური ანალიზი", "ბიუჯეტირება"], responsibilities: "ფინანსური სტრატეგია და ანგარიშგება" },
  { title: "HR დირექტორი", skills: ["HR მართვა", "ორგანიზაციული განვითარება"], responsibilities: "ადამიანური რესურსების მართვა" },
  { title: "HR მენეჯერი", skills: ["რეკრუტინგი", "შრომითი ურთიერთობები"], responsibilities: "თანამშრომელთა მართვა და რეკრუტინგი" },
  { title: "IT დირექტორი", skills: ["IT ინფრასტრუქტურა", "პროექტის მართვა"], responsibilities: "IT სტრატეგია და ინფრასტრუქტურა" },
  { title: "პროექტ მენეჯერი", skills: ["Agile", "კომუნიკაცია"], responsibilities: "პროექტების დაგეგმვა და განხორციელება" },
  { title: "Frontend დეველოპერი", skills: ["React", "TypeScript", "CSS"], responsibilities: "ფრონტენდის შემუშავება" },
  { title: "Backend დეველოპერი", skills: ["Node.js", "PostgreSQL", "API"], responsibilities: "სერვერული ლოგიკა და API" },
  { title: "Full-stack დეველოპერი", skills: ["React", "Node.js", "PostgreSQL"], responsibilities: "სრული სტეკის შემუშავება" },
  { title: "UI/UX დიზაინერი", skills: ["Figma", "UI დიზაინი", "UX კვლევა"], responsibilities: "ინტერფეისისა და გამოცდილების დიზაინი" },
  { title: "მარკეტინგ მენეჯერი", skills: ["ციფრული მარკეტინგი", "ანალიტიკა"], responsibilities: "მარკეტინგული სტრატეგია" },
  { title: "გაყიდვების მენეჯერი", skills: ["B2B გაყიდვები", "CRM"], responsibilities: "გაყიდვების მართვა" },
  { title: "ბუღალტერი", skills: ["ბუღალტერია", "1C", "საგადასახადო"], responsibilities: "ფინანსური აღრიცხვა" },
  { title: "იურისტი", skills: ["სამართალი", "კონტრაქტები"], responsibilities: "იურიდიული კონსულტაცია" },
  { title: "ადმინისტრატორი", skills: ["ოფისის მართვა", "კომუნიკაცია"], responsibilities: "ოფისის ადმინისტრირება" },
  { title: "კლიენტთა მომსახურების სპეციალისტი", skills: ["კომუნიკაცია"], responsibilities: "კლიენტთა მხარდაჭერა" },
  { title: "DevOps ინჟინერი", skills: ["Docker", "CI/CD", "AWS"], responsibilities: "ინფრასტრუქტურის ავტომატიზაცია" },
  { title: "მონაცემთა ანალიტიკოსი", skills: ["SQL", "Python", "BI"], responsibilities: "მონაცემთა ანალიზი" },
  { title: "სისტემური ადმინისტრატორი", skills: ["Linux", "ქსელები"], responsibilities: "IT სისტემების მხარდაჭერა" },
  { title: "ლოჯისტიკის მენეჯერი", skills: ["მიწოდების ჯაჭვი"], responsibilities: "ლოჯისტიკური ოპერაციები" },
  { title: "უსაფრთხოების სპეციალისტი", skills: ["ინფორმაციული უსაფრთხოება"], responsibilities: "უსაფრთხოების მართვა" },
  { title: "QA ინჟინერი", skills: ["ტესტირება", "ავტომატიზაცია"], responsibilities: "ხარისხის კონტროლი და ტესტირება" },
  { title: "პროდუქტ მენეჯერი", skills: ["პროდუქტის სტრატეგია", "ანალიტიკა"], responsibilities: "პროდუქტის მართვა და განვითარება" },
  { title: "გრაფიკული დიზაინერი", skills: ["Adobe Suite", "ბრენდინგი"], responsibilities: "ვიზუალური კონტენტის შექმნა" },
];

interface AddPositionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  departments: Array<{ id: string; name: string }>;
  onSuccess?: () => void;
}

export const AddPositionDialog = ({
  open,
  onOpenChange,
  departments,
  onSuccess
}: AddPositionDialogProps) => {
  const [loading, setLoading] = useState(false);
  const [skillInput, setSkillInput] = useState('');
  const [formData, setFormData] = useState({
    title: '',
    department_id: 'none',
    level: 'none',
    min_salary: '',
    max_salary: '',
    headcount: '',
    filled_count: '0',
    required_skills: [] as string[],
    responsibilities: '',
    is_active: true
  });

  const handleSelectTemplate = (template: typeof POSITION_TEMPLATES[0]) => {
    setFormData({
      ...formData,
      title: template.title,
      required_skills: [...template.skills],
      responsibilities: template.responsibilities
    });
  };

  const handleAddSkill = () => {
    if (skillInput.trim()) {
      setFormData({
        ...formData,
        required_skills: [...formData.required_skills, skillInput.trim()]
      });
      setSkillInput('');
    }
  };

  const handleRemoveSkill = (index: number) => {
    setFormData({
      ...formData,
      required_skills: formData.required_skills.filter((_, i) => i !== index)
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from('positions')
        .insert({
          title: formData.title,
          department_id: formData.department_id && formData.department_id !== 'none' ? formData.department_id : null,
          level: formData.level && formData.level !== 'none' ? formData.level : null,
          min_salary: formData.min_salary ? parseFloat(formData.min_salary) : null,
          max_salary: formData.max_salary ? parseFloat(formData.max_salary) : null,
          headcount: parseInt(formData.headcount),
          filled_count: parseInt(formData.filled_count),
          required_skills: formData.required_skills.length > 0 ? formData.required_skills : null,
          responsibilities: formData.responsibilities || null,
          is_active: formData.is_active
        });

      if (error) throw error;

      toast.success('პოზიცია წარმატებით დაემატა');
      onOpenChange(false);
      onSuccess?.();
      
      setFormData({
        title: '',
        department_id: 'none',
        level: 'none',
        min_salary: '',
        max_salary: '',
        headcount: '',
        filled_count: '0',
        required_skills: [],
        responsibilities: '',
        is_active: true
      });
      setSkillInput('');
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>ახალი პოზიცია</DialogTitle>
          <DialogDescription>
            აირჩიეთ შაბლონიდან ან ხელით შეიყვანეთ პოზიციის სახელი
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Template chips */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Sparkles className="h-4 w-4" />
              <span>სწრაფი შაბლონები - დააკლიკეთ დასამატებლად</span>
            </div>
            <div className="flex flex-wrap gap-2 max-h-[200px] overflow-y-auto p-1">
              {POSITION_TEMPLATES.map((template) => (
                <button
                  key={template.title}
                  type="button"
                  onClick={() => handleSelectTemplate(template)}
                  className={cn(
                    "px-3 py-1.5 rounded-full text-sm font-medium border transition-all duration-200",
                    "hover:shadow-md hover:scale-[1.03] active:scale-95",
                    formData.title === template.title
                      ? "bg-primary text-primary-foreground border-primary shadow-sm"
                      : "bg-muted/50 text-foreground border-border hover:bg-muted hover:border-primary/40"
                  )}
                >
                  {template.title}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label htmlFor="title">თანამდებობა *</Label>
              <Input
                id="title"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="მაგ: Frontend დეველოპერი"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="department">დეპარტამენტი</Label>
              <Select value={formData.department_id} onValueChange={(value) => setFormData({ ...formData, department_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="არჩევა..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">არჩევა...</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="level">დონე</Label>
              <Select value={formData.level} onValueChange={(value) => setFormData({ ...formData, level: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="არჩევა..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">არჩევა...</SelectItem>
                  <SelectItem value="junior">ჯუნიორი</SelectItem>
                  <SelectItem value="middle">მიდლ</SelectItem>
                  <SelectItem value="senior">სენიორი</SelectItem>
                  <SelectItem value="lead">ლიდი</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="min_salary">მინ. ხელფასი (₾)</Label>
              <Input
                id="min_salary"
                type="number"
                step="0.01"
                value={formData.min_salary}
                onChange={(e) => setFormData({ ...formData, min_salary: e.target.value })}
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="max_salary">მაქს. ხელფასი (₾)</Label>
              <Input
                id="max_salary"
                type="number"
                step="0.01"
                value={formData.max_salary}
                onChange={(e) => setFormData({ ...formData, max_salary: e.target.value })}
                placeholder="0.00"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="headcount">საშტატო რაოდენობა *</Label>
              <Input
                id="headcount"
                type="number"
                required
                value={formData.headcount}
                onChange={(e) => setFormData({ ...formData, headcount: e.target.value })}
                placeholder="0"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="filled">დაკავებული</Label>
              <Input
                id="filled"
                type="number"
                value={formData.filled_count}
                onChange={(e) => setFormData({ ...formData, filled_count: e.target.value })}
                placeholder="0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="responsibilities">მოვალეობები</Label>
            <Textarea
              id="responsibilities"
              value={formData.responsibilities}
              onChange={(e) => setFormData({ ...formData, responsibilities: e.target.value })}
              placeholder="პოზიციის მთავარი მოვალეობები..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="skills">საჭირო უნარები</Label>
            <div className="flex gap-2">
              <Input
                id="skills"
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddSkill();
                  }
                }}
                placeholder="უნარის დასახელება..."
              />
              <Button type="button" onClick={handleAddSkill} variant="outline">
                დამატება
              </Button>
            </div>
            {formData.required_skills.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.required_skills.map((skill, index) => (
                  <Badge key={index} variant="secondary" className="pl-2 pr-1">
                    {skill}
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 ml-1"
                      onClick={() => handleRemoveSkill(index)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              გაუქმება
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'ინახება...' : 'დამატება'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};