import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Building2, Users, DollarSign, TrendingUp, Award } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

interface Department {
  id: string;
  name: string;
  budget: number | null;
  employee_count: number;
  avg_salary: number;
  total_salaries: number;
  manager?: {
    full_name: string;
    avatar_url: string | null;
  };
}

interface DepartmentAnalyticsProps {
  departments: Department[];
}

const COLORS = [
  'hsl(var(--primary))',
  'hsl(var(--secondary))',
  'hsl(var(--accent))',
  '#8884d8',
  '#82ca9d',
  '#ffc658',
  '#ff7c7c',
  '#a78bfa',
  '#fb923c',
  '#34d399'
];

export const DepartmentAnalytics = ({ departments }: DepartmentAnalyticsProps) => {
  // Sort departments by different metrics
  const topByBudget = [...departments]
    .filter(d => d.budget && d.budget > 0)
    .sort((a, b) => (b.budget || 0) - (a.budget || 0))
    .slice(0, 10);

  const topByEmployees = [...departments]
    .filter(d => d.employee_count > 0)
    .sort((a, b) => b.employee_count - a.employee_count)
    .slice(0, 10);

  const topBySalary = [...departments]
    .filter(d => d.avg_salary > 0)
    .sort((a, b) => b.avg_salary - a.avg_salary)
    .slice(0, 10);

  // Data for budget chart
  const budgetData = topByBudget.map(dept => ({
    name: dept.name.length > 15 ? dept.name.substring(0, 15) + '...' : dept.name,
    ბიუჯეტი: dept.budget,
  }));

  // Data for employees chart
  const employeesData = topByEmployees.map(dept => ({
    name: dept.name.length > 15 ? dept.name.substring(0, 15) + '...' : dept.name,
    თანამშრომლები: dept.employee_count,
  }));

  // Data for salary chart
  const salaryData = topBySalary.map(dept => ({
    name: dept.name.length > 15 ? dept.name.substring(0, 15) + '...' : dept.name,
    'საშუალო ხელფასი': Math.round(dept.avg_salary),
  }));

  // Pie chart data for budget distribution
  const budgetPieData = topByBudget.slice(0, 5).map(dept => ({
    name: dept.name,
    value: dept.budget || 0,
  }));

  // Calculate totals
  const totalBudget = departments.reduce((sum, d) => sum + (d.budget || 0), 0);
  const totalEmployees = departments.reduce((sum, d) => sum + d.employee_count, 0);
  const totalSalaries = departments.reduce((sum, d) => sum + d.total_salaries, 0);
  const overallAvgSalary = totalEmployees > 0 ? totalSalaries / totalEmployees : 0;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Building2 className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">დეპარტამენტები</p>
                <p className="text-2xl font-bold">{departments.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <DollarSign className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">სრული ბიუჯეტი</p>
                <p className="text-lg font-bold">
                  {new Intl.NumberFormat('ka-GE', {
                    style: 'currency',
                    currency: 'GEL',
                    minimumFractionDigits: 0,
                  }).format(totalBudget)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <Users className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">სულ თანამშრომელი</p>
                <p className="text-2xl font-bold">{totalEmployees}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/10">
                <TrendingUp className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">საშუალო ხელფასი</p>
                <p className="text-lg font-bold">
                  {new Intl.NumberFormat('ka-GE', {
                    style: 'currency',
                    currency: 'GEL',
                    minimumFractionDigits: 0,
                  }).format(overallAvgSalary)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Budget Chart */}
        <Card>
          <CardHeader>
            <CardTitle>ბიუჯეტი დეპარტამენტების მიხედვით</CardTitle>
            <CardDescription>Top 10 დეპარტამენტი ბიუჯეტის მიხედვით</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={budgetData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="name" 
                  tick={{ fill: 'hsl(var(--foreground))' }}
                  angle={-45}
                  textAnchor="end"
                  height={100}
                />
                <YAxis tick={{ fill: 'hsl(var(--foreground))' }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                  formatter={(value: number) => new Intl.NumberFormat('ka-GE', {
                    style: 'currency',
                    currency: 'GEL',
                    minimumFractionDigits: 0,
                  }).format(value)}
                />
                <Bar dataKey="ბიუჯეტი" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Budget Distribution Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle>ბიუჯეტის განაწილება</CardTitle>
            <CardDescription>Top 5 დეპარტამენტი</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={budgetPieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {budgetPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                  formatter={(value: number) => new Intl.NumberFormat('ka-GE', {
                    style: 'currency',
                    currency: 'GEL',
                    minimumFractionDigits: 0,
                  }).format(value)}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Employees Chart */}
        <Card>
          <CardHeader>
            <CardTitle>თანამშრომლები დეპარტამენტების მიხედვით</CardTitle>
            <CardDescription>Top 10 დეპარტამენტი თანამშრომლების რაოდენობით</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={employeesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="name" 
                  tick={{ fill: 'hsl(var(--foreground))' }}
                  angle={-45}
                  textAnchor="end"
                  height={100}
                />
                <YAxis tick={{ fill: 'hsl(var(--foreground))' }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="თანამშრომლები" fill="hsl(var(--secondary))" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Average Salary Chart */}
        <Card>
          <CardHeader>
            <CardTitle>საშუალო ხელფასი დეპარტამენტების მიხედვით</CardTitle>
            <CardDescription>Top 10 დეპარტამენტი საშუალო ხელფასის მიხედვით</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={salaryData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="name" 
                  tick={{ fill: 'hsl(var(--foreground))' }}
                  angle={-45}
                  textAnchor="end"
                  height={100}
                />
                <YAxis tick={{ fill: 'hsl(var(--foreground))' }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                  formatter={(value: number) => new Intl.NumberFormat('ka-GE', {
                    style: 'currency',
                    currency: 'GEL',
                    minimumFractionDigits: 0,
                  }).format(value)}
                />
                <Bar dataKey="საშუალო ხელფასი" fill="hsl(var(--accent))" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Top Performers Table */}
      <Card>
        <CardHeader>
          <CardTitle>დეტალური შედარება</CardTitle>
          <CardDescription>დეპარტამენტების სრული სტატისტიკა</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left p-3 font-semibold">დეპარტამენტი</th>
                  <th className="text-left p-3 font-semibold">მენეჯერი</th>
                  <th className="text-right p-3 font-semibold">თანამშრომლები</th>
                  <th className="text-right p-3 font-semibold">ბიუჯეტი</th>
                  <th className="text-right p-3 font-semibold">საშუალო ხელფასი</th>
                  <th className="text-right p-3 font-semibold">ხელფასების ჯამი</th>
                  <th className="text-center p-3 font-semibold">ეფექტურობა</th>
                </tr>
              </thead>
              <tbody>
                {departments
                  .filter(d => d.employee_count > 0)
                  .sort((a, b) => b.employee_count - a.employee_count)
                  .map((dept, index) => {
                    const efficiency = dept.budget && dept.total_salaries > 0 
                      ? ((dept.budget - dept.total_salaries) / dept.budget * 100)
                      : 0;
                    
                    return (
                      <tr key={dept.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <div className="p-1.5 rounded-lg bg-primary/10">
                              <Building2 className="h-4 w-4 text-primary" />
                            </div>
                            <span className="font-medium">{dept.name}</span>
                          </div>
                        </td>
                        <td className="p-3">
                          {dept.manager ? (
                            <div className="flex items-center gap-2">
                              <Avatar className="h-6 w-6">
                                <AvatarImage src={dept.manager.avatar_url || undefined} />
                                <AvatarFallback className="text-xs">
                                  {dept.manager.full_name.split(' ').map(n => n[0]).join('').toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <span className="text-sm">{dept.manager.full_name}</span>
                            </div>
                          ) : (
                            <span className="text-sm text-muted-foreground">-</span>
                          )}
                        </td>
                        <td className="p-3 text-right">
                          <Badge variant="secondary">{dept.employee_count}</Badge>
                        </td>
                        <td className="p-3 text-right font-medium">
                          {dept.budget ? new Intl.NumberFormat('ka-GE', {
                            style: 'currency',
                            currency: 'GEL',
                            minimumFractionDigits: 0,
                          }).format(dept.budget) : '-'}
                        </td>
                        <td className="p-3 text-right font-medium">
                          {dept.avg_salary > 0 ? new Intl.NumberFormat('ka-GE', {
                            style: 'currency',
                            currency: 'GEL',
                            minimumFractionDigits: 0,
                          }).format(dept.avg_salary) : '-'}
                        </td>
                        <td className="p-3 text-right font-medium">
                          {dept.total_salaries > 0 ? new Intl.NumberFormat('ka-GE', {
                            style: 'currency',
                            currency: 'GEL',
                            minimumFractionDigits: 0,
                          }).format(dept.total_salaries) : '-'}
                        </td>
                        <td className="p-3 text-center">
                          {efficiency > 0 ? (
                            <Badge 
                              variant={efficiency > 20 ? 'default' : efficiency > 0 ? 'secondary' : 'destructive'}
                            >
                              {efficiency.toFixed(0)}%
                            </Badge>
                          ) : (
                            <span className="text-sm text-muted-foreground">-</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Top 3 Departments */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-2 border-yellow-500/20 bg-yellow-500/5">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Award className="h-5 w-5 text-yellow-600" />
              <CardTitle className="text-lg">ყველაზე დიდი ბიუჯეტი</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {topByBudget.slice(0, 3).map((dept, index) => (
              <div key={dept.id} className="flex items-center gap-3 mb-3 last:mb-0">
                <div className={`flex items-center justify-center h-8 w-8 rounded-full font-bold text-sm ${
                  index === 0 ? 'bg-yellow-500 text-white' :
                  index === 1 ? 'bg-gray-400 text-white' :
                  'bg-orange-400 text-white'
                }`}>
                  {index + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{dept.name}</p>
                  <p className="text-sm font-bold text-primary">
                    {new Intl.NumberFormat('ka-GE', {
                      style: 'currency',
                      currency: 'GEL',
                      minimumFractionDigits: 0,
                    }).format(dept.budget || 0)}
                  </p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-2 border-blue-500/20 bg-blue-500/5">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-600" />
              <CardTitle className="text-lg">ყველაზე მეტი თანამშრომელი</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {topByEmployees.slice(0, 3).map((dept, index) => (
              <div key={dept.id} className="flex items-center gap-3 mb-3 last:mb-0">
                <div className={`flex items-center justify-center h-8 w-8 rounded-full font-bold text-sm ${
                  index === 0 ? 'bg-yellow-500 text-white' :
                  index === 1 ? 'bg-gray-400 text-white' :
                  'bg-orange-400 text-white'
                }`}>
                  {index + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{dept.name}</p>
                  <p className="text-sm font-bold text-primary">{dept.employee_count} თანამშრომელი</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-2 border-green-500/20 bg-green-500/5">
          <CardHeader>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              <CardTitle className="text-lg">უმაღლესი საშუალო ხელფასი</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {topBySalary.slice(0, 3).map((dept, index) => (
              <div key={dept.id} className="flex items-center gap-3 mb-3 last:mb-0">
                <div className={`flex items-center justify-center h-8 w-8 rounded-full font-bold text-sm ${
                  index === 0 ? 'bg-yellow-500 text-white' :
                  index === 1 ? 'bg-gray-400 text-white' :
                  'bg-orange-400 text-white'
                }`}>
                  {index + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{dept.name}</p>
                  <p className="text-sm font-bold text-primary">
                    {new Intl.NumberFormat('ka-GE', {
                      style: 'currency',
                      currency: 'GEL',
                      minimumFractionDigits: 0,
                    }).format(dept.avg_salary)}
                  </p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};