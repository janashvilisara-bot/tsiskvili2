import { Button } from "@/components/ui/button";
import { Download, FileSpreadsheet, FileText } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import ExcelJS from 'exceljs';

interface ExportMenuProps {
  data: any[];
  filename: string;
  type: 'departments' | 'positions' | 'budgets';
}

export const ExportMenu = ({ data, filename, type }: ExportMenuProps) => {
  const formatData = () => {
    if (type === 'departments') {
      return data.map(item => ({
        'დასახელება': item.name,
        'დასახელება (EN)': item.name_en || '',
        'მენეჯერი': item.manager?.full_name || '-',
        'ბიუჯეტი': item.budget || 0,
        'თანამშრომლების ლიმიტი': item.headcount_limit || 0,
        'აქტიური თანამშრომლები': item.employee_count || 0,
        'სტატუსი': item.is_active ? 'აქტიური' : 'არააქტიური',
        'აღწერა': item.description || ''
      }));
    } else if (type === 'positions') {
      return data.map(item => ({
        'პოზიცია': item.title,
        'დეპარტამენტი': item.department?.name || '-',
        'დონე': item.level || '-',
        'მინ. ხელფასი': item.min_salary || 0,
        'მაქს. ხელფასი': item.max_salary || 0,
        'საშტატო': item.headcount,
        'დაკავებული': item.filled_count,
        'ვაკანსიები': item.headcount - item.filled_count,
        'სტატუსი': item.is_active ? 'აქტიური' : 'არააქტიური'
      }));
    } else if (type === 'budgets') {
      return data.map(item => ({
        'დეპარტამენტი': item.department?.name || 'ყველა',
        'წელი': item.fiscal_year,
        'კვარტალი': item.fiscal_quarter || '-',
        'კატეგორია': item.category,
        'დაგეგმილი': item.planned_amount,
        'ფაქტიური': item.actual_amount,
        'ვარიაცია': item.variance || (item.actual_amount - item.planned_amount),
        'შენიშვნები': item.notes || ''
      }));
    }
    return [];
  };

  const exportToExcel = async () => {
    if (!data || data.length === 0) {
      toast.error('ექსპორტისთვის მონაცემები არ არის');
      return;
    }

    try {
      const formattedData = formatData();
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('მონაცემები');

      if (formattedData.length === 0) return;

      // Set up columns
      const headers = Object.keys(formattedData[0]);
      worksheet.columns = headers.map(header => ({
        header,
        key: header,
        width: Math.min(Math.max(header.length, 15), 50)
      }));

      // Add data rows
      formattedData.forEach(row => {
        worksheet.addRow(row);
      });

      // Style header row
      worksheet.getRow(1).font = { bold: true };
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFE0E0E0' }
      };

      // Download
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${filename}.xlsx`;
      link.click();
      window.URL.revokeObjectURL(url);

      toast.success('ფაილი წარმატებით ჩამოიტვირთა');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('ექსპორტის შეცდომა');
    }
  };

  const exportToCSV = () => {
    if (!data || data.length === 0) {
      toast.error('ექსპორტისთვის მონაცემები არ არის');
      return;
    }

    try {
      const formattedData = formatData();
      
      if (formattedData.length === 0) return;
      
      const headers = Object.keys(formattedData[0]);
      const csvRows = [
        headers.join(','),
        ...formattedData.map(row => 
          headers.map(header => {
            const value = String(row[header] || '');
            // Escape quotes and wrap in quotes if contains comma
            if (value.includes(',') || value.includes('"')) {
              return `"${value.replace(/"/g, '""')}"`;
            }
            return value;
          }).join(',')
        )
      ];
      
      const csv = csvRows.join('\n');
      const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `${filename}.csv`;
      link.click();
      
      toast.success('ფაილი წარმატებით ჩამოიტვირთა');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('ექსპორტის შეცდომა');
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm">
          <Download className="h-4 w-4 mr-2" />
          ექსპორტი
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={exportToExcel}>
          <FileSpreadsheet className="h-4 w-4 mr-2" />
          Excel (.xlsx)
        </DropdownMenuItem>
        <DropdownMenuItem onClick={exportToCSV}>
          <FileText className="h-4 w-4 mr-2" />
          CSV
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
