import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const DEPARTMENT_TEMPLATES = [
  { name: "ფინანსები", name_en: "Finance", description: "ფინანსური მართვა და ბუღალტერია" },
  { name: "ადამიანური რესურსები", name_en: "Human Resources", description: "HR მართვა და რეკრუტინგი" },
  { name: "IT დეპარტამენტი", name_en: "IT Department", description: "საინფორმაციო ტექნოლოგიები" },
  { name: "მარკეტინგი", name_en: "Marketing", description: "მარკეტინგი და კომუნიკაციები" },
  { name: "გაყიდვები", name_en: "Sales", description: "გაყიდვების მართვა" },
  { name: "ლოჯისტიკა", name_en: "Logistics", description: "ლოჯისტიკა და მიწოდების ჯაჭვი" },
  { name: "იურიდიული", name_en: "Legal", description: "იურიდიული საკითხები" },
  { name: "მომხმარებელთა მომსახურება", name_en: "Customer Service", description: "კლიენტთა მხარდაჭერა" },
  { name: "წარმოება", name_en: "Production", description: "საწარმოო პროცესები" },
  { name: "ხარისხის კონტროლი", name_en: "Quality Control", description: "ხარისხის მართვა" },
  { name: "შესყიდვები", name_en: "Procurement", description: "შესყიდვები და მომწოდებლების მართვა" },
  { name: "R&D (კვლევა და განვითარება)", name_en: "R&D", description: "კვლევა და ინოვაციები" },
  { name: "უსაფრთხოება", name_en: "Security", description: "ფიზიკური და ინფორმაციული უსაფრთხოება" },
  { name: "საზოგადოებასთან ურთიერთობა", name_en: "PR", description: "PR და კომუნიკაციები" },
  { name: "საერთაშორისო ოპერაციები", name_en: "International Operations", description: "საერთაშორისო საქმიანობის მართვა" },
  { name: "სტრატეგიული განვითარება", name_en: "Strategy", description: "სტრატეგიული დაგეგმვა" },
  { name: "ადმინისტრაცია", name_en: "Administration", description: "კომპანიის ადმინისტრაციული მართვა" },
  { name: "კომპლაიანსი და რეგულაციები", name_en: "Compliance", description: "მარეგულირებელი მოთხოვნების დაცვა" },
  { name: "მეთვალყურეობა", name_en: "Supervision", description: "ზედამხედველობა და მონიტორინგი" },
  { name: "ქეშ მენეჯმენტი", name_en: "Cash Management", description: "ფულადი ნაკადების მართვა" },
  { name: "ონლაინ გაიმინგი", name_en: "Online Gaming", description: "ონლაინ გეიმინგის მართვა" },
  { name: "ანტი-ფრაუდი", name_en: "Anti-Fraud", description: "თაღლითობის პრევენცია" },
  { name: "დილერთა სკოლა", name_en: "Dealer School", description: "დილერების მომზადება და ტრენინგი" },
  { name: "VIP სერვისი", name_en: "VIP Service", description: "VIP კლიენტების მომსახურება" },
  { name: "კვება და ბარი", name_en: "Food & Bar", description: "კვებითი მომსახურება" },
  { name: "გართობა და ივენთები", name_en: "Entertainment & Events", description: "გასართობი ღონისძიებები" },
  { name: "სალარო სერვისი", name_en: "Cashier Service", description: "სალაროს ოპერაციები" },
  { name: "სლოტ მანქანები", name_en: "Slot Machines", description: "სლოტ მანქანების მართვა" },
  { name: "ცოცხალი თამაშები", name_en: "Live Games", description: "ცოცხალი თამაშების მართვა" },
  { name: "დიზაინი", name_en: "Design", description: "UI/UX და გრაფიკული დიზაინი" },
  { name: "ოპერაციები", name_en: "Operations", description: "ოპერაციული მართვა" },
  { name: "პროდუქტი", name_en: "Product", description: "პროდუქტის მართვა და განვითარება" },
  { name: "ბუღალტერია", name_en: "Accounting", description: "საბუღალტრო აღრიცხვა" },
];

interface AddDepartmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  departments: Array<{ id: string; name: string }>;
  employees: Array<{ id: string; full_name: string }>;
  onSuccess?: () => void;
}

export const AddDepartmentDialog = ({
  open,
  onOpenChange,
  departments,
  employees,
  onSuccess
}: AddDepartmentDialogProps) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    name_en: '',
    parent_department_id: 'none',
    manager_id: 'none',
    budget: '',
    headcount_limit: '',
    description: '',
    is_active: true
  });

  const handleSelectTemplate = (template: typeof DEPARTMENT_TEMPLATES[0]) => {
    setFormData({
      ...formData,
      name: template.name,
      name_en: template.name_en,
      description: template.description
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from('departments')
        .insert({
          name: formData.name,
          name_en: formData.name_en || null,
          parent_department_id: formData.parent_department_id && formData.parent_department_id !== 'none' ? formData.parent_department_id : null,
          manager_id: formData.manager_id && formData.manager_id !== 'none' ? formData.manager_id : null,
          budget: formData.budget ? parseFloat(formData.budget) : null,
          headcount_limit: formData.headcount_limit ? parseInt(formData.headcount_limit) : null,
          description: formData.description || null,
          is_active: formData.is_active
        });

      if (error) throw error;

      toast.success('დეპარტამენტი წარმატებით დაემატა');
      onOpenChange(false);
      onSuccess?.();
      
      setFormData({
        name: '',
        name_en: '',
        parent_department_id: 'none',
        manager_id: 'none',
        budget: '',
        headcount_limit: '',
        description: '',
        is_active: true
      });
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>ახალი დეპარტამენტი</DialogTitle>
          <DialogDescription>
            აირჩიეთ შაბლონიდან ან ხელით შეიყვანეთ დეპარტამენტის სახელი
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Template chips */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Sparkles className="h-4 w-4" />
              <span>სწრაფი შაბლონები - დააკლიკეთ დასამატებლად</span>
            </div>
            <div className="flex flex-wrap gap-2 max-h-[200px] overflow-y-auto p-1">
              {DEPARTMENT_TEMPLATES.map((template) => (
                <button
                  key={template.name}
                  type="button"
                  onClick={() => handleSelectTemplate(template)}
                  className={cn(
                    "px-3 py-1.5 rounded-full text-sm font-medium border transition-all duration-200",
                    "hover:shadow-md hover:scale-[1.03] active:scale-95",
                    formData.name === template.name
                      ? "bg-primary text-primary-foreground border-primary shadow-sm"
                      : "bg-muted/50 text-foreground border-border hover:bg-muted hover:border-primary/40"
                  )}
                >
                  {template.name}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">დასახელება (ქართული) *</Label>
              <Input
                id="name"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="მაგ: IT დეპარტამენტი"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="name_en">დასახელება (ინგლისური)</Label>
              <Input
                id="name_en"
                value={formData.name_en}
                onChange={(e) => setFormData({ ...formData, name_en: e.target.value })}
                placeholder="e.g: IT Department"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="parent">მშობელი დეპარტამენტი</Label>
              <Select value={formData.parent_department_id} onValueChange={(value) => setFormData({ ...formData, parent_department_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="არჩევა..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">არცერთი</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="manager">მენეჯერი</Label>
              <Select value={formData.manager_id} onValueChange={(value) => setFormData({ ...formData, manager_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="არჩევა..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">არჩევა...</SelectItem>
                  {employees.map((emp) => (
                    <SelectItem key={emp.id} value={emp.id}>
                      {emp.full_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="budget">ბიუჯეტი (₾)</Label>
              <Input
                id="budget"
                type="number"
                step="0.01"
                value={formData.budget}
                onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="headcount">საშტატო ლიმიტი</Label>
              <Input
                id="headcount"
                type="number"
                value={formData.headcount_limit}
                onChange={(e) => setFormData({ ...formData, headcount_limit: e.target.value })}
                placeholder="0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">აღწერა</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="დეპარტამენტის მოკლე აღწერა..."
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              გაუქმება
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'ინახება...' : 'დამატება'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};