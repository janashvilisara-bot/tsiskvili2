import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Briefcase, Users, DollarSign, Pencil, Trash2, MoreVertical, Building2, Power } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

interface Position {
  id: string;
  title: string;
  department_id: string | null;
  level: string | null;
  min_salary: number | null;
  max_salary: number | null;
  required_skills: string[] | null;
  responsibilities: string | null;
  headcount: number;
  filled_count: number;
  is_active: boolean;
  department?: { name: string };
}

interface PositionCardProps {
  position: Position;
  onEdit?: (pos: Position) => void;
  onDelete?: (posId: string, posTitle: string) => void;
  onToggleStatus?: (pos: Position) => void;
  canManage?: boolean;
}

const getLevelColor = (level: string | null) => {
  switch (level) {
    case 'junior':
      return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
    case 'middle':
      return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
    case 'senior':
      return 'bg-orange-500/10 text-orange-600 border-orange-500/20';
    case 'lead':
      return 'bg-red-500/10 text-red-600 border-red-500/20';
    default:
      return 'bg-muted text-muted-foreground border-border';
  }
};

const getLevelLabel = (level: string | null) => {
  switch (level) {
    case 'junior':
      return 'ჯუნიორი';
    case 'middle':
      return 'მიდლ';
    case 'senior':
      return 'სენიორი';
    case 'lead':
      return 'ლიდი';
    default:
      return 'N/A';
  }
};

export const PositionCard = ({ 
  position, 
  onEdit, 
  onDelete,
  onToggleStatus,
  canManage = false 
}: PositionCardProps) => {
  const vacancies = position.headcount - position.filled_count;
  const fillPercentage = (position.filled_count / position.headcount) * 100;

  return (
    <Card className="group overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/20 border-purple-500/20 bg-gradient-to-br from-purple-500/5 via-background to-background backdrop-blur-sm">
      <div className="h-2 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-400 group-hover:h-3 transition-all" />
      
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 flex-1">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-purple-500/20 to-purple-500/10 backdrop-blur-sm border border-purple-500/30 group-hover:scale-110 transition-transform">
              <Briefcase className="h-5 w-5 text-purple-600" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-lg mb-1 group-hover:text-purple-600 transition-colors">{position.title}</h3>
              {position.department && (
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <Building2 className="h-3.5 w-3.5" />
                  <span>{position.department.name}</span>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge 
              variant="outline" 
              className={getLevelColor(position.level)}
            >
              {getLevelLabel(position.level)}
            </Badge>
            <Badge variant={position.is_active ? "default" : "secondary"} className={position.is_active ? "bg-gradient-to-r from-green-600 to-green-500" : ""}>
              {position.is_active ? 'აქტიური' : 'არააქტიური'}
            </Badge>
            
            {canManage && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-purple-500/10">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onEdit?.(position)}>
                    <Pencil className="h-4 w-4 mr-2" />
                    რედაქტირება
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onToggleStatus?.(position)}>
                    <Power className="h-4 w-4 mr-2" />
                    {position.is_active ? 'გამორთვა' : 'ჩართვა'}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={() => onDelete?.(position.id, position.title)}
                    className="text-destructive"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    წაშლა
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Responsibilities */}
        {position.responsibilities && (
          <p className="text-sm text-muted-foreground line-clamp-2">
            {position.responsibilities}
          </p>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="relative overflow-hidden p-3 rounded-xl bg-gradient-to-br from-blue-600/10 to-blue-400/5 border border-blue-500/30 backdrop-blur-sm group-hover:shadow-lg group-hover:shadow-blue-500/20 transition-all">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative">
              <div className="flex items-center gap-2 mb-1">
                <Users className="h-4 w-4 text-blue-600" />
                <span className="text-xs font-medium text-blue-600">საშტატო</span>
              </div>
              <p className="text-2xl font-bold bg-gradient-to-br from-blue-600 to-blue-400 bg-clip-text text-transparent">
                {position.filled_count}
                <span className="text-sm text-muted-foreground ml-1">
                  / {position.headcount}
                </span>
              </p>
              {vacancies > 0 && (
                <p className="text-xs text-orange-600 font-medium mt-1">
                  {vacancies} ვაკანსია
                </p>
              )}
              <div className="mt-2 h-1.5 bg-blue-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-blue-600 to-blue-400 rounded-full transition-all"
                  style={{ width: `${fillPercentage}%` }}
                />
              </div>
            </div>
          </div>

          {(position.min_salary || position.max_salary) && (
            <div className="relative overflow-hidden p-3 rounded-xl bg-gradient-to-br from-green-600/10 to-green-400/5 border border-green-500/30 backdrop-blur-sm group-hover:shadow-lg group-hover:shadow-green-500/20 transition-all">
              <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-1">
                  <DollarSign className="h-4 w-4 text-green-600" />
                  <span className="text-xs font-medium text-green-600">ხელფასი</span>
                </div>
                <div className="space-y-0.5">
                  {position.min_salary && (
                    <p className="text-sm font-semibold bg-gradient-to-br from-green-600 to-green-400 bg-clip-text text-transparent">
                      {new Intl.NumberFormat('ka-GE', {
                        style: 'currency',
                        currency: 'GEL',
                        minimumFractionDigits: 0,
                      }).format(position.min_salary)}
                    </p>
                  )}
                  {position.max_salary && (
                    <p className="text-sm font-semibold bg-gradient-to-br from-green-600 to-green-400 bg-clip-text text-transparent">
                      {new Intl.NumberFormat('ka-GE', {
                        style: 'currency',
                        currency: 'GEL',
                        minimumFractionDigits: 0,
                      }).format(position.max_salary)}
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Skills */}
        {position.required_skills && position.required_skills.length > 0 && (
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2">საჭირო უნარები</p>
            <div className="flex flex-wrap gap-1.5">
              {position.required_skills.slice(0, 5).map((skill, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {skill}
                </Badge>
              ))}
              {position.required_skills.length > 5 && (
                <Badge variant="outline" className="text-xs">
                  +{position.required_skills.length - 5}
                </Badge>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
