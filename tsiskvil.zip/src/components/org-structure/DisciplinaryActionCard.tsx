import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Pencil, Trash2, MoreVertical, Calendar, User } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";

interface Employee {
  full_name: string;
  avatar_url: string | null;
}

interface DisciplinaryAction {
  id: string;
  employee_id: string;
  action_type: string;
  reason: string;
  description: string | null;
  issued_by: string | null;
  issued_date: string;
  status: string;
  severity: string;
  follow_up_date: string | null;
  follow_up_notes: string | null;
  employee?: Employee;
  issuer?: Employee;
}

interface DisciplinaryActionCardProps {
  action: DisciplinaryAction;
  onEdit?: (action: DisciplinaryAction) => void;
  onDelete?: (action: DisciplinaryAction) => void;
  canManage?: boolean;
}

const getActionTypeLabel = (type: string) => {
  const labels: Record<string, string> = {
    'verbal_warning': 'სიტყვიერი გაფრთხილება',
    'written_warning': 'წერილობითი გაფრთხილება',
    'suspension': 'შეჩერება',
    'termination': 'გათავისუფლება',
    'other': 'სხვა'
  };
  return labels[type] || type;
};

const getSeverityColor = (severity: string) => {
  const colors: Record<string, string> = {
    'low': 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    'medium': 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
    'high': 'bg-orange-500/10 text-orange-600 border-orange-500/20',
    'critical': 'bg-red-500/10 text-red-600 border-red-500/20'
  };
  return colors[severity] || colors.low;
};

const getSeverityLabel = (severity: string) => {
  const labels: Record<string, string> = {
    'low': 'დაბალი',
    'medium': 'საშუალო',
    'high': 'მაღალი',
    'critical': 'კრიტიკული'
  };
  return labels[severity] || severity;
};

const getStatusColor = (status: string) => {
  const colors: Record<string, string> = {
    'active': 'default',
    'resolved': 'secondary',
    'appealed': 'outline'
  };
  return colors[status] || 'default';
};

const getStatusLabel = (status: string) => {
  const labels: Record<string, string> = {
    'active': 'აქტიური',
    'resolved': 'გადაწყვეტილი',
    'appealed': 'საჩივრის პროცესში'
  };
  return labels[status] || status;
};

export const DisciplinaryActionCard = ({ 
  action, 
  onEdit, 
  onDelete,
  canManage = false 
}: DisciplinaryActionCardProps) => {
  return (
    <Card className="overflow-hidden transition-all hover:shadow-md">
      <div className="h-2 bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500" />
      
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 flex-1">
            <div className="p-2.5 rounded-xl bg-red-500/10">
              <AlertTriangle className="h-5 w-5 text-red-600" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-semibold text-lg">{getActionTypeLabel(action.action_type)}</h3>
                <Badge 
                  variant="outline" 
                  className={getSeverityColor(action.severity)}
                >
                  {getSeverityLabel(action.severity)}
                </Badge>
              </div>
              <p className="text-sm font-medium text-muted-foreground">{action.reason}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant={getStatusColor(action.status) as any}>
              {getStatusLabel(action.status)}
            </Badge>
            
            {canManage && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onEdit?.(action)}>
                    <Pencil className="h-4 w-4 mr-2" />
                    რედაქტირება
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => onDelete?.(action)}
                    className="text-destructive"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    წაშლა
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Description */}
        {action.description && (
          <p className="text-sm text-muted-foreground">{action.description}</p>
        )}

        {/* Employee */}
        {action.employee && (
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
            <Avatar className="h-10 w-10">
              <AvatarImage src={action.employee.avatar_url || undefined} />
              <AvatarFallback>
                {action.employee.full_name.split(' ').map(n => n[0]).join('').toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-sm">{action.employee.full_name}</p>
              <p className="text-xs text-muted-foreground">თანამშრომელი</p>
            </div>
          </div>
        )}

        {/* Details Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
            <div className="flex items-center gap-2 mb-1">
              <Calendar className="h-4 w-4 text-blue-600" />
              <span className="text-xs font-medium text-blue-600">გამოცემის თარიღი</span>
            </div>
            <p className="text-sm font-semibold">
              {format(new Date(action.issued_date), 'dd.MM.yyyy')}
            </p>
          </div>

          {action.issuer && (
            <div className="p-3 rounded-lg bg-purple-500/10 border border-purple-500/20">
              <div className="flex items-center gap-2 mb-1">
                <User className="h-4 w-4 text-purple-600" />
                <span className="text-xs font-medium text-purple-600">გამომცემი</span>
              </div>
              <p className="text-sm font-semibold truncate">{action.issuer.full_name}</p>
            </div>
          )}
        </div>

        {/* Follow-up */}
        {action.follow_up_date && (
          <div className="p-3 rounded-lg border border-orange-500/20 bg-orange-500/5">
            <div className="flex items-center gap-2 mb-1">
              <Calendar className="h-4 w-4 text-orange-600" />
              <span className="text-xs font-medium text-orange-600">
                შემდგომი შემოწმება: {format(new Date(action.follow_up_date), 'dd.MM.yyyy')}
              </span>
            </div>
            {action.follow_up_notes && (
              <p className="text-sm text-muted-foreground mt-1">{action.follow_up_notes}</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
