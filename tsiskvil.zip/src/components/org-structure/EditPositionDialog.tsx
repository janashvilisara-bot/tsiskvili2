import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";

interface Position {
  id: string;
  title: string;
  department_id: string | null;
  level: string | null;
  min_salary: number | null;
  max_salary: number | null;
  required_skills: string[] | null;
  responsibilities: string | null;
  headcount: number;
  filled_count: number;
  is_active: boolean;
}

interface EditPositionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  position: Position | null;
  departments: Array<{ id: string; name: string }>;
  onSuccess?: () => void;
}

export const EditPositionDialog = ({
  open,
  onOpenChange,
  position,
  departments,
  onSuccess
}: EditPositionDialogProps) => {
  const [loading, setLoading] = useState(false);
  const [skillInput, setSkillInput] = useState('');
  const [formData, setFormData] = useState({
    title: '',
    department_id: 'none',
    level: 'none',
    min_salary: '',
    max_salary: '',
    headcount: '',
    filled_count: '',
    required_skills: [] as string[],
    responsibilities: '',
    is_active: true
  });

  useEffect(() => {
    if (position) {
      setFormData({
        title: position.title || '',
        department_id: position.department_id || 'none',
        level: position.level || 'none',
        min_salary: position.min_salary?.toString() || '',
        max_salary: position.max_salary?.toString() || '',
        headcount: position.headcount.toString(),
        filled_count: position.filled_count.toString(),
        required_skills: position.required_skills || [],
        responsibilities: position.responsibilities || '',
        is_active: position.is_active
      });
    }
  }, [position]);

  const handleAddSkill = () => {
    if (skillInput.trim()) {
      setFormData({
        ...formData,
        required_skills: [...formData.required_skills, skillInput.trim()]
      });
      setSkillInput('');
    }
  };

  const handleRemoveSkill = (index: number) => {
    setFormData({
      ...formData,
      required_skills: formData.required_skills.filter((_, i) => i !== index)
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!position) return;
    
    setLoading(true);

    try {
      const { error } = await supabase
        .from('positions')
        .update({
          title: formData.title,
          department_id: formData.department_id && formData.department_id !== 'none' ? formData.department_id : null,
          level: formData.level && formData.level !== 'none' ? formData.level : null,
          min_salary: formData.min_salary ? parseFloat(formData.min_salary) : null,
          max_salary: formData.max_salary ? parseFloat(formData.max_salary) : null,
          headcount: parseInt(formData.headcount),
          filled_count: parseInt(formData.filled_count),
          required_skills: formData.required_skills.length > 0 ? formData.required_skills : null,
          responsibilities: formData.responsibilities || null,
          is_active: formData.is_active
        })
        .eq('id', position.id);

      if (error) throw error;

      toast.success('პოზიცია წარმატებით განახლდა');
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>პოზიციის რედაქტირება</DialogTitle>
          <DialogDescription>
            შეცვალეთ პოზიციის ინფორმაცია
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label htmlFor="title">თანამდებობა *</Label>
              <Input
                id="title"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="მაგ: Frontend დეველოპერი"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="department">დეპარტამენტი</Label>
              <Select value={formData.department_id} onValueChange={(value) => setFormData({ ...formData, department_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="არჩევა..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">არჩევა...</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="level">დონე</Label>
              <Select value={formData.level} onValueChange={(value) => setFormData({ ...formData, level: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="არჩევა..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">არჩევა...</SelectItem>
                  <SelectItem value="junior">ჯუნიორი</SelectItem>
                  <SelectItem value="middle">მიდლ</SelectItem>
                  <SelectItem value="senior">სენიორი</SelectItem>
                  <SelectItem value="lead">ლიდი</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="min_salary">მინ. ხელფასი (₾)</Label>
              <Input
                id="min_salary"
                type="number"
                step="0.01"
                value={formData.min_salary}
                onChange={(e) => setFormData({ ...formData, min_salary: e.target.value })}
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="max_salary">მაქს. ხელფასი (₾)</Label>
              <Input
                id="max_salary"
                type="number"
                step="0.01"
                value={formData.max_salary}
                onChange={(e) => setFormData({ ...formData, max_salary: e.target.value })}
                placeholder="0.00"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="headcount">საშტატო რაოდენობა *</Label>
              <Input
                id="headcount"
                type="number"
                required
                value={formData.headcount}
                onChange={(e) => setFormData({ ...formData, headcount: e.target.value })}
                placeholder="0"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="filled">დაკავებული</Label>
              <Input
                id="filled"
                type="number"
                value={formData.filled_count}
                onChange={(e) => setFormData({ ...formData, filled_count: e.target.value })}
                placeholder="0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="responsibilities">მოვალეობები</Label>
            <Textarea
              id="responsibilities"
              value={formData.responsibilities}
              onChange={(e) => setFormData({ ...formData, responsibilities: e.target.value })}
              placeholder="პოზიციის მთავარი მოვალეობები..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="skills">საჭირო უნარები</Label>
            <div className="flex gap-2">
              <Input
                id="skills"
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddSkill();
                  }
                }}
                placeholder="უნარის დასახელება..."
              />
              <Button type="button" onClick={handleAddSkill} variant="outline">
                დამატება
              </Button>
            </div>
            {formData.required_skills.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.required_skills.map((skill, index) => (
                  <Badge key={index} variant="secondary" className="pl-2 pr-1">
                    {skill}
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 ml-1"
                      onClick={() => handleRemoveSkill(index)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              გაუქმება
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'ინახება...' : 'შენახვა'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
