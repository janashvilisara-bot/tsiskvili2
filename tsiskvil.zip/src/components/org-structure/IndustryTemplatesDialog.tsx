import { useState } from 'react';
import { Building2, Stethoscope, Store, Loader2, Layers } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useBranch } from '@/contexts/BranchContext';
import { industryPresets } from '@/lib/industryPresets';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export function IndustryTemplatesDialog({ onSuccess }: { onSuccess?: () => void }) {
  const { language } = useLanguage();
  const tr = (ka: string, en: string) => language === 'ka' ? ka : en;
  const { user, userRole } = useAuth();
  const { branches, activeBranch } = useBranch();
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState('hotel');
  const [branchId, setBranchId] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const preset = industryPresets.find(p => p.id === selected);
  const canManage = userRole === 'admin' || userRole === 'hr_manager';
  async function applyPreset() {
    if (!preset || !user || !canManage || !branchId || busy) return;
    setBusy(true);
    try {
      // Existing records are reused, including after a partially interrupted application.
      for (const dept of preset.departments) {
        const { data: found, error: readError } = await supabase.from('departments').select('id').eq('branch_id', branchId).eq('name', dept.name.ka).limit(1);
        if (readError) throw readError;
        let id = found?.[0]?.id;
        if (!id) {
          const { data, error } = await supabase.from('departments').insert({ name: dept.name.ka, name_en: dept.name.en, branch_id: branchId, created_by: user.id, is_active: true }).select('id').single();
          if (error) throw error;
          id = data.id;
        }
        for (const position of dept.positions) {
          const { data: existing, error: positionReadError } = await supabase.from('positions').select('id').eq('department_id', id).eq('title', position.ka).limit(1);
          if (positionReadError) throw positionReadError;
          if (!existing?.length) {
            const { error } = await supabase.from('positions').insert({ title: position.ka, department_id: id, branch_id: branchId, created_by: user.id, headcount: 0, filled_count: 0, is_active: true });
            if (error) throw error;
          }
        }
      }
      for (const schedule of preset.schedules) {
        const { data: existing, error: readError } = await supabase.from('schedule_templates').select('id').eq('name', schedule.name.ka).limit(1);
        if (readError) throw readError;
        if (!existing?.length) {
          const { error } = await supabase.from('schedule_templates').insert({
            name: schedule.name.ka, description: schedule.name.en, schedule_type: `${schedule.start} - ${schedule.end}`,
            schedule_category: schedule.category, start_time: schedule.start, end_time: schedule.end,
            break_duration: schedule.breakMinutes, is_default: false, created_by: user.id,
            work_days: schedule.category === 'full' ? ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'] : null,
            weekly_hours: null,
          });
          if (error) throw error;
        }
      }
      setDone(true); onSuccess?.(); toast.success(tr('ინდუსტრიული შაბლონი დაემატა', 'Industry template added'));
    } catch { toast.error(tr('შაბლონი სრულად ვერ დაემატა. უკვე დამატებული ჩანაწერები შენარჩუნებულია; ხელახლა ცდა დუბლირებას არ გამოიწვევს.', 'Template could not fully apply. Added items were kept; retrying will reuse them.')); }
    finally { setBusy(false); }
  }
  if (!canManage) return null;
  return <>
    <Button variant="outline" className="gap-2" onClick={() => { setOpen(true); setDone(false); setBranchId(activeBranch?.id || branches[0]?.id || ''); }}><Layers className="h-4 w-4" />{tr('ინდუსტრიული შაბლონები', 'Industry templates')}</Button>
    <Dialog open={open} onOpenChange={value => { if (!busy) setOpen(value); }}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" onEscapeKeyDown={e => { if (busy) e.preventDefault(); }} onInteractOutside={e => { if (busy) e.preventDefault(); }}>
        <DialogHeader><DialogTitle>{tr('ინდუსტრიული შაბლონები', 'Industry templates')}</DialogTitle><DialogDescription>{tr('სფეროები', 'Industries')}: {industryPresets.length}</DialogDescription></DialogHeader>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">{industryPresets.map((p, i) => { const Icon = [Building2, Stethoscope, Store][i] ?? Building2; return <Button key={p.id} variant={selected === p.id ? 'default' : 'outline'} disabled={busy} className="h-auto min-h-24 py-3 flex-col gap-2 whitespace-normal" onClick={() => { setSelected(p.id); setDone(false); }}><Icon className="h-5 w-5 shrink-0" />{p.name[language]}</Button>; })}</div>
        <div className="space-y-2"><Label>{tr('ფილიალი', 'Branch')}</Label><Select value={branchId} disabled={busy} onValueChange={value => { setBranchId(value); setDone(false); }}><SelectTrigger><SelectValue placeholder={tr('აირჩიეთ ფილიალი', 'Choose branch')} /></SelectTrigger><SelectContent>{branches.map(b => <SelectItem key={b.id} value={b.id}>{language === 'en' ? b.name_en || b.name : b.name}</SelectItem>)}</SelectContent></Select></div>
        <p className="text-sm text-muted-foreground">{tr('საწყისი ნიმუშები - არსებული სტრუქტურა და ხელფასები არ იცვლება. ცვლები თანამშრომლებს არ ენიჭება. სამუშაო დღეები და დასვენება ცალკე დაგეგმეთ.', 'Starter examples - existing structure and pay stay unchanged. Shifts are not assigned to staff. Plan working days and rest separately.')}</p>
        {preset && <div className="grid gap-5 sm:grid-cols-2"><section className="space-y-3"><h3 className="font-semibold">{tr('დეპარტამენტები და პოზიციები', 'Departments & positions')}</h3>{preset.departments.map(d => <div key={d.name.en} className="border-l-2 border-border pl-3"><p className="text-sm font-medium">{d.name[language]}</p><ul className="text-sm text-muted-foreground">{d.positions.map(p => <li key={p.en}>{p[language]}</li>)}</ul></div>)}</section><section className="space-y-3"><h3 className="font-semibold">{tr('გრაფიკის შაბლონები', 'Schedule templates')}</h3>{preset.schedules.map(s => <div key={s.name.en} className="border-l-2 border-border pl-3 text-sm"><p className="font-medium">{s.name[language]}</p><p>{s.start} - {s.end}</p><p className="text-muted-foreground">{tr('შესვენება', 'Break')}: {s.breakMinutes} {tr('წუთი', 'min')}</p></div>)}<p className="text-xs text-muted-foreground">{tr('გრაფიკის შაბლონები საერთოა ყველა ფილიალისთვის.', 'Schedule templates are shared across branches.')}</p></section></div>}
        <Button onClick={applyPreset} disabled={busy || !branchId || done} className="gap-2">{busy && <Loader2 className="h-4 w-4 animate-spin" />}{done ? tr('დამატებულია', 'Added') : tr('შაბლონის დამატება', 'Add template')}</Button>
      </DialogContent>
    </Dialog>
  </>;
}