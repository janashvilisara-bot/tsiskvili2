import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Upload, UserPlus, FileSpreadsheet, Download, FileText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { importCandidatesFromExcel, downloadCandidatesTemplate } from "@/lib/importCandidatesFromExcel";

interface Vacancy {
  id: string;
  title: string;
}

interface AddCandidateDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vacancies: Vacancy[];
  onSuccess: () => void;
}

export function AddCandidateDialog({ open, onOpenChange, vacancies, onSuccess }: AddCandidateDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [excelFile, setExcelFile] = useState<File | null>(null);
  const [selectedVacancy, setSelectedVacancy] = useState<string>("");
  const [importPreview, setImportPreview] = useState<any[]>([]);
  const formRef = useRef<HTMLFormElement>(null);

  const handleManualSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const formData = new FormData(e.currentTarget);

    try {
      let photoUrl = null;
      let resumePath = null;

      // Upload photo if provided
      if (photoFile) {
        const photoExt = photoFile.name.split('.').pop();
        const photoPath = `${Date.now()}_${Math.random().toString(36).substring(7)}.${photoExt}`;
        
        const { error: photoError } = await supabase.storage
          .from('candidate-photos')
          .upload(photoPath, photoFile);

        if (photoError) throw photoError;
        
        const { data: signedUrlData } = await supabase.storage
          .from('candidate-photos')
          .createSignedUrl(photoPath, 60 * 60 * 24 * 365); // 1 year
        
        photoUrl = signedUrlData?.signedUrl || null;
      }

      // Upload resume if provided
      if (resumeFile) {
        const resumeExt = resumeFile.name.split('.').pop();
        resumePath = `${Date.now()}_${Math.random().toString(36).substring(7)}.${resumeExt}`;
        
        const { error: resumeError } = await supabase.storage
          .from('candidate-resumes')
          .upload(resumePath, resumeFile);

        if (resumeError) throw resumeError;
      }

      const payload = {
        full_name: formData.get('full_name') as string,
        email: formData.get('email') as string,
        phone: formData.get('phone') as string || null,
        cover_letter: formData.get('cover_letter') as string || null,
        vacancy_id: selectedVacancy && selectedVacancy !== 'none' ? selectedVacancy : null,
        status: 'new',
        photo_url: photoUrl,
        resume_file_path: resumePath,
        source: formData.get('source') as string || 'manual',
      };

      const { error } = await supabase
        .from('candidates')
        .insert([payload]);

      if (error) throw error;

      toast.success('კანდიდატი წარმატებით დაემატა!');
      resetForm();
      onOpenChange(false);
      onSuccess();
    } catch (error: any) {
      console.error('Error:', error);
      toast.error(error.message || 'შეცდომა კანდიდატის დამატებისას');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExcelFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setExcelFile(file);
    
    try {
      const candidates = await importCandidatesFromExcel(file);
      setImportPreview(candidates);
    } catch (error) {
      console.error('Error parsing Excel:', error);
      toast.error('Excel ფაილის წაკითხვა ვერ მოხერხდა');
      setImportPreview([]);
    }
  };

  const handleExcelImport = async () => {
    if (importPreview.length === 0) {
      toast.error('იმპორტისთვის კანდიდატები არ არის');
      return;
    }

    setIsSubmitting(true);

    try {
      const candidatesToInsert = importPreview.map(c => ({
        full_name: c.full_name,
        email: c.email,
        phone: c.phone || null,
        cover_letter: c.cover_letter || null,
        vacancy_id: selectedVacancy && selectedVacancy !== 'none' ? selectedVacancy : null,
        status: 'new',
        source: c.source || 'excel_import',
      }));

      const { error } = await supabase
        .from('candidates')
        .insert(candidatesToInsert);

      if (error) throw error;

      toast.success(`${candidatesToInsert.length} კანდიდატი წარმატებით დაემატა!`);
      resetForm();
      onOpenChange(false);
      onSuccess();
    } catch (error: any) {
      console.error('Error:', error);
      if (error.message?.includes('duplicate')) {
        toast.error('ზოგიერთი ელ.ფოსტა უკვე არსებობს');
      } else {
        toast.error(error.message || 'შეცდომა იმპორტისას');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setPhotoFile(null);
    setResumeFile(null);
    setExcelFile(null);
    setSelectedVacancy("");
    setImportPreview([]);
    if (formRef.current) {
      formRef.current.reset();
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) resetForm(); onOpenChange(v); }}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>კანდიდატის დამატება</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="manual" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="manual" className="gap-2">
              <UserPlus className="h-4 w-4" />
              ხელით დამატება
            </TabsTrigger>
            <TabsTrigger value="excel" className="gap-2">
              <FileSpreadsheet className="h-4 w-4" />
              Excel იმპორტი
            </TabsTrigger>
          </TabsList>

          {/* ვაკანსიის არჩევა - საერთო */}
          <div className="mt-4 mb-4">
            <Label>ვაკანსია (არასავალდებულო)</Label>
            <Select value={selectedVacancy} onValueChange={setSelectedVacancy}>
              <SelectTrigger>
                <SelectValue placeholder="აირჩიეთ ვაკანსია" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">ვაკანსიის გარეშე</SelectItem>
                {vacancies.map((v) => (
                  <SelectItem key={v.id} value={v.id}>
                    {v.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <TabsContent value="manual">
            <form ref={formRef} onSubmit={handleManualSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="full_name">სახელი და გვარი *</Label>
                  <Input
                    id="full_name"
                    name="full_name"
                    required
                    placeholder="მაგ. გიორგი ბერიძე"
                  />
                </div>
                <div>
                  <Label htmlFor="email">ელ. ფოსტა *</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    required
                    placeholder="example@mail.com"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="phone">ტელეფონი</Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    placeholder="+995 555 123 456"
                  />
                </div>
                <div>
                  <Label htmlFor="source">წყარო</Label>
                  <Select name="source" defaultValue="manual">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manual">ხელით შეყვანა</SelectItem>
                      <SelectItem value="linkedin">LinkedIn</SelectItem>
                      <SelectItem value="facebook">Facebook</SelectItem>
                      <SelectItem value="hr.ge">HR.ge</SelectItem>
                      <SelectItem value="jobs.ge">Jobs.ge</SelectItem>
                      <SelectItem value="recommendation">რეკომენდაცია</SelectItem>
                      <SelectItem value="career_fair">კარიერის ფესტივალი</SelectItem>
                      <SelectItem value="university">უნივერსიტეტი</SelectItem>
                      <SelectItem value="other">სხვა</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="photo">ფოტო</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="photo"
                    type="file"
                    accept="image/*"
                    onChange={(e) => setPhotoFile(e.target.files?.[0] || null)}
                    className="cursor-pointer"
                  />
                  {photoFile && (
                    <Badge variant="secondary" className="shrink-0">
                      <Upload className="h-3 w-3 mr-1" />
                      {photoFile.name}
                    </Badge>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="resume">CV / რეზიუმე</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="resume"
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={(e) => setResumeFile(e.target.files?.[0] || null)}
                    className="cursor-pointer"
                  />
                  {resumeFile && (
                    <Badge variant="secondary" className="shrink-0">
                      <FileText className="h-3 w-3 mr-1" />
                      {resumeFile.name}
                    </Badge>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="cover_letter">შენიშვნა / კომენტარი</Label>
                <Textarea
                  id="cover_letter"
                  name="cover_letter"
                  rows={3}
                  placeholder="დამატებითი ინფორმაცია კანდიდატის შესახებ..."
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    resetForm();
                    onOpenChange(false);
                  }}
                >
                  გაუქმება
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'ემატება...' : 'დამატება'}
                </Button>
              </div>
            </form>
          </TabsContent>

          <TabsContent value="excel" className="space-y-4">
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={downloadCandidatesTemplate}
                className="gap-2"
              >
                <Download className="h-4 w-4" />
                შაბლონის ჩამოტვირთვა
              </Button>
              <p className="text-sm text-muted-foreground">
                ჩამოტვირთეთ შაბლონი და შეავსეთ კანდიდატების მონაცემები
              </p>
            </div>

            <div>
              <Label htmlFor="excel_file">Excel ფაილი</Label>
              <Input
                id="excel_file"
                type="file"
                accept=".xlsx,.xls"
                onChange={handleExcelFileChange}
                className="cursor-pointer"
              />
            </div>

            {importPreview.length > 0 && (
              <div className="border rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">წინასწარი ნახვა ({importPreview.length} კანდიდატი)</h4>
                  <Badge variant="secondary">{excelFile?.name}</Badge>
                </div>
                <div className="max-h-48 overflow-y-auto space-y-2">
                  {importPreview.slice(0, 10).map((c, i) => (
                    <div key={i} className="flex items-center gap-3 p-2 bg-muted/50 rounded text-sm">
                      <span className="font-medium">{c.full_name}</span>
                      <span className="text-muted-foreground">{c.email}</span>
                      {c.phone && <span className="text-muted-foreground">{c.phone}</span>}
                    </div>
                  ))}
                  {importPreview.length > 10 && (
                    <p className="text-sm text-muted-foreground text-center">
                      ... და კიდევ {importPreview.length - 10} კანდიდატი
                    </p>
                  )}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  resetForm();
                  onOpenChange(false);
                }}
              >
                გაუქმება
              </Button>
              <Button 
                onClick={handleExcelImport} 
                disabled={isSubmitting || importPreview.length === 0}
              >
                {isSubmitting ? 'იმპორტირდება...' : `${importPreview.length} კანდიდატის იმპორტი`}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
