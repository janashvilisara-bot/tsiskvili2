import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, UserCheck, Calendar, TrendingUp, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { StatCardsSkeleton } from "@/components/ui/skeleton-loader";
import { cn } from "@/lib/utils";

interface DashboardStatsData {
  totalEmployees: number;
  activeEmployees: number;
  pendingLeaves: number;
  newEmployees: number;
  todayAttendance: number;
  ongoingLeaves: number;
}

export function DashboardStats() {
  const [stats, setStats] = useState<DashboardStatsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();

    // Subscribe to realtime updates
    const channel = supabase
      .channel('dashboard-stats')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'employees'
        },
        () => {
          fetchStats();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'leave_requests'
        },
        () => {
          fetchStats();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'attendance'
        },
        () => {
          fetchStats();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);

      // Total employees
      const { count: totalCount } = await supabase
        .from('employees')
        .select('*', { count: 'exact', head: true });

      // Active employees
      const { count: activeCount } = await supabase
        .from('employees')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Pending leave requests
      const { count: pendingLeaves } = await supabase
        .from('leave_requests')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');

      // New employees (last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      const { count: newCount } = await supabase
        .from('employees')
        .select('*', { count: 'exact', head: true })
        .gte('hire_date', thirtyDaysAgo.toISOString());

      // Today's attendance
      const today = new Date().toISOString().split('T')[0];
      const { count: todayAttendanceCount } = await supabase
        .from('attendance')
        .select('*', { count: 'exact', head: true })
        .eq('date', today)
        .not('check_in', 'is', null);

      // Ongoing leaves (currently on leave)
      const todayDate = new Date().toISOString().split('T')[0];
      const { count: ongoingLeavesCount } = await supabase
        .from('leave_requests')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'approved')
        .lte('start_date', todayDate)
        .gte('end_date', todayDate);

      setStats({
        totalEmployees: totalCount || 0,
        activeEmployees: activeCount || 0,
        pendingLeaves: pendingLeaves || 0,
        newEmployees: newCount || 0,
        todayAttendance: todayAttendanceCount || 0,
        ongoingLeaves: ongoingLeavesCount || 0,
      });
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <StatCardsSkeleton count={6} />;
  }

  const statCards = [
    {
      icon: Users,
      value: stats?.totalEmployees || 0,
      label: "სულ თანამშრომელი",
      color: "from-blue-500 to-blue-600",
      bgColor: "bg-blue-500/10",
      trend: "+12%",
      trendUp: true,
    },
    {
      icon: UserCheck,
      value: stats?.activeEmployees || 0,
      label: "აქტიური თანამშრომელი",
      color: "from-green-500 to-green-600",
      bgColor: "bg-green-500/10",
      trend: "+5%",
      trendUp: true,
    },
    {
      icon: Calendar,
      value: stats?.pendingLeaves || 0,
      label: "მომლოდინე შვებულებები",
      color: "from-orange-500 to-orange-600",
      bgColor: "bg-orange-500/10",
      trend: "-3%",
      trendUp: false,
    },
    {
      icon: TrendingUp,
      value: stats?.newEmployees || 0,
      label: "ახალი (30 დღე)",
      color: "from-purple-500 to-purple-600",
      bgColor: "bg-purple-500/10",
      trend: "+8%",
      trendUp: true,
    },
    {
      icon: UserCheck,
      value: stats?.todayAttendance || 0,
      label: "დღევანდელი დასწრება",
      color: "from-cyan-500 to-cyan-600",
      bgColor: "bg-cyan-500/10",
      trend: `${stats?.activeEmployees ? Math.round((stats.todayAttendance / stats.activeEmployees) * 100) : 0}%`,
      trendUp: true,
    },
    {
      icon: Calendar,
      value: stats?.ongoingLeaves || 0,
      label: "მიმდინარე შვებულებები",
      color: "from-rose-500 to-rose-600",
      bgColor: "bg-rose-500/10",
      trend: "დღეს",
      trendUp: false,
    },
  ];

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 mb-8">
      {statCards.map((stat, index) => (
        <Card 
          key={index} 
          className="group relative overflow-hidden border-border/50 bg-card/95 backdrop-blur-sm hover:shadow-lg hover:border-primary/30 transition-all duration-300 hover:-translate-y-1 animate-fade-in"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          
          <CardContent className="p-6 relative">
            <div className="flex items-center justify-between mb-4">
              <div className={cn(
                "p-3 rounded-xl transition-all duration-300 group-hover:scale-110",
                stat.bgColor
              )}>
                <stat.icon className={cn(
                  "h-6 w-6 bg-gradient-to-br bg-clip-text text-transparent",
                  stat.color
                )} />
              </div>
              
              <div className={cn(
                "flex items-center gap-1 text-sm font-medium px-2 py-1 rounded-full",
                stat.trendUp ? "text-green-600 bg-green-50 dark:bg-green-950/20" : "text-red-600 bg-red-50 dark:bg-red-950/20"
              )}>
                {stat.trendUp ? (
                  <ArrowUpRight className="h-3 w-3" />
                ) : (
                  <ArrowDownRight className="h-3 w-3" />
                )}
                <span className="text-xs">{stat.trend}</span>
              </div>
            </div>
            
            <div>
              <div className="text-3xl font-bold mb-1 transition-all duration-300 group-hover:scale-105 origin-left">
                {stat.value}
              </div>
              <div className="text-sm text-muted-foreground font-medium">
                {stat.label}
              </div>
            </div>

            {/* Decorative element */}
            <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-gradient-to-br from-primary/5 to-accent/5 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
