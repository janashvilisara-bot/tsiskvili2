import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import confetti from "canvas-confetti";
import { Sparkles, Trophy, Award } from "lucide-react";

/**
 * Mounts globally (e.g. in App.tsx). Subscribes to point_transactions
 * and employee_badges inserts for the current user and shows a toast +
 * confetti animation whenever points are awarded or a new badge is unlocked.
 */
export function PointsRealtimeToast() {
  const { user } = useAuth();
  const employeeIdRef = useRef<string | null>(null);

  useEffect(() => {
    if (!user) return;
    let pointsChan: any;
    let badgesChan: any;
    let cancelled = false;

    (async () => {
      // Resolve employee_id for this user
      const { data: emp } = await supabase
        .from("employees")
        .select("id")
        .eq("user_id", user.id)
        .maybeSingle();

      if (cancelled || !emp?.id) return;
      employeeIdRef.current = emp.id;

      pointsChan = supabase
        .channel(`points-toast-${emp.id}`)
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "point_transactions",
            filter: `employee_id=eq.${emp.id}`,
          },
          (payload: any) => {
            const amount = payload?.new?.amount ?? 0;
            const description = payload?.new?.description ?? "";
            if (amount > 0) {
              toast.success(`+${amount} ქულა! 🎉`, {
                description: description || "ახალი ქულები დაგერიცხათ",
                icon: <Sparkles className="h-4 w-4 text-amber-500" />,
                duration: 4500,
              });
              fireConfetti();
            } else if (amount < 0) {
              toast.info(`${amount} ქულა`, {
                description: description || "ჯილდოს გამოსყიდვა",
                icon: <Award className="h-4 w-4" />,
              });
            }
          }
        )
        .subscribe();

      badgesChan = supabase
        .channel(`badges-toast-${emp.id}`)
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "employee_badges",
            filter: `employee_id=eq.${emp.id}`,
          },
          async (payload: any) => {
            const badgeId = payload?.new?.badge_id;
            let badgeName = "ახალი ბეჯი";
            if (badgeId) {
              const { data: b } = await supabase
                .from("badges")
                .select("name, icon")
                .eq("id", badgeId)
                .maybeSingle();
              if (b?.name) badgeName = b.name;
            }
            toast.success(`🏆 ბეჯი მოპოვებულია!`, {
              description: badgeName,
              icon: <Trophy className="h-4 w-4 text-amber-500" />,
              duration: 6000,
            });
            fireConfetti(true);
          }
        )
        .subscribe();
    })();

    return () => {
      cancelled = true;
      if (pointsChan) supabase.removeChannel(pointsChan);
      if (badgesChan) supabase.removeChannel(badgesChan);
    };
  }, [user]);

  return null;
}

function fireConfetti(big = false) {
  try {
    confetti({
      particleCount: big ? 160 : 80,
      spread: big ? 100 : 70,
      origin: { y: 0.6 },
      colors: ["#f59e0b", "#6366f1", "#10b981", "#ec4899"],
    });
  } catch {}
}

export default PointsRealtimeToast;
