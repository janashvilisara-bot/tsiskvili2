import { Info, X, BookOpen, Send } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDemoMode } from "@/contexts/DemoContext";

export function DemoBanner() {
  const [isVisible, setIsVisible] = useState(true);
  const navigate = useNavigate();
  const { isDemoMode } = useDemoMode();

  if (!isDemoMode || !isVisible) return null;

  return (
    <Alert className="rounded-none border-x-0 border-t-0 bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 backdrop-blur-sm relative">
      <Info className="h-4 w-4 text-primary" />
      <AlertDescription className="text-sm font-medium flex items-center justify-between">
        <div className="flex items-center gap-4">
          <span>
            <span className="text-primary font-semibold">დემო რეჟიმი:</span> თქვენ იყენებთ სისტემის სადემონსტრაციო ვერსიას. 
            ცვლილებები დროებითია.
          </span>
          <div className="hidden sm:flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="h-7 gap-1"
              onClick={() => navigate("/simulator")}
            >
              <BookOpen className="h-3 w-3" />
              გაიდი
            </Button>
            <Button 
              size="sm" 
              className="h-7 gap-1"
              onClick={() => navigate("/pricing-inquiry")}
            >
              <Send className="h-3 w-3" />
              შეთავაზების მოთხოვნა
            </Button>
          </div>
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-6 w-6 absolute right-2 top-1/2 -translate-y-1/2"
          onClick={() => setIsVisible(false)}
        >
          <X className="h-3 w-3" />
        </Button>
      </AlertDescription>
    </Alert>
  );
}
