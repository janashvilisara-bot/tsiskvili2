import { NavLink, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import companyLogo from "@/assets/company-logo.png";
import { useFeatureAccess, sidebarFeatureMap } from "@/hooks/useFeatureAccess";
import {
  Users,
  UserPlus,
  Building2,
  DollarSign,
  ArrowLeftRight,
  BarChart3,
  LayoutDashboard,
  LogOut,
  ChevronDown,
  User,
  Bell,
  Search,
  Home,
  GraduationCap,
  Cog,
  ChevronRight,
  Sparkles,
  ClipboardList,
  ShieldCheck,
  TicketCheck,
  FileSignature,
  Server,
  Heart,
  Activity,
  ArrowRightLeft,
  PieChart,
  Grid3X3,
  Lock,
  Trophy,
  Target,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { GlobalSearch } from "@/components/GlobalSearch";

const navigationGroups = [
  {
    label: "მთავარი",
    icon: Home,
    gradient: "from-blue-500 to-cyan-500",
    items: [
      { title: "თანამშრომლის პორტალი", url: "/", icon: User, hasBadge: false, adminOnly: false },
      { title: "შეტყობინებები", url: "/notifications", icon: Bell, hasBadge: true, adminOnly: false },
    ],
  },
  {
    label: "ხელმძღვანელის ბლოკი",
    icon: Users,
    gradient: "from-amber-500 to-orange-500",
    items: [
      { title: "ჩემი დეპარტამენტი", url: "/manager-dashboard", icon: LayoutDashboard, hasBadge: false, adminOnly: false, managerOnly: true },
      { title: "საშტატო ერთეულები", url: "/manager-headcount", icon: PieChart, hasBadge: false, adminOnly: false, managerOnly: true },
      { title: "გრაფიკების გაწერა", url: "/work-schedules", icon: ClipboardList, hasBadge: false, adminOnly: false, managerOnly: true },
      { title: "შვებულებები", url: "/leave-requests", icon: ClipboardList, hasBadge: true, adminOnly: false, managerOnly: true },
    ],
    subGroups: []
  },
  {
    label: "ჩემი სერვისები",
    icon: Grid3X3,
    gradient: "from-sky-500 to-indigo-500",
    items: [
      { title: "შვებულებები", url: "/leave-requests", icon: ClipboardList, hasBadge: false, adminOnly: false, employeeOnly: true },
      { title: "მივლინებები", url: "/business-trip-requests", icon: ArrowRightLeft, hasBadge: false, adminOnly: false, employeeOnly: true },
      { title: "ავტომობილი", url: "/vehicle-requests", icon: Activity, hasBadge: false, adminOnly: false, employeeOnly: true },
      { title: "დავალებები", url: "/tasks", icon: TicketCheck, hasBadge: true, adminOnly: false, employeeOnly: true },
      { title: "გრაფიკი/ცვლები", url: "/calendar", icon: LayoutDashboard, hasBadge: false, adminOnly: false, employeeOnly: true },
      { title: "გამოკითხვები", url: "/pulse-surveys", icon: PieChart, hasBadge: false, adminOnly: false, employeeOnly: true },
      { title: "ჩემი დასწრება", url: "/attendance", icon: ClipboardList, hasBadge: false, adminOnly: false, employeeOnly: true },
      { title: "პირადი ინფორმაცია", url: "/employee-profile", icon: User, hasBadge: false, adminOnly: false, employeeOnly: true },
      { title: "დოკუმენტები/ხელმოწერა", url: "/documents", icon: FileSignature, hasBadge: false, adminOnly: false, employeeOnly: true },
      { title: "თანამშრომელთა დირექტორია", url: "/employee-directory", icon: Users, hasBadge: false, adminOnly: false, employeeOnly: true },
      { title: "ჯილდოები და აღიარება", url: "/recognition", icon: Trophy, hasBadge: false, adminOnly: false, employeeOnly: true },

    ],
    subGroups: []
  },
  {
    label: "პერსონალი",
    icon: Users,
    gradient: "from-emerald-500 to-teal-500",
    items: [
      { title: "პერსონალის მიმოხილვა", url: "/personnel", icon: Users, hasBadge: false, adminOnly: false },
      { title: "თანამშრომლები", url: "/employees", icon: Users, hasBadge: false, adminOnly: true },
      { title: "დოკუმენტები", url: "/documents", icon: FileSignature, hasBadge: false, adminOnly: true },
      { title: "დისციპლინური", url: "/disciplinary", icon: ShieldCheck, hasBadge: false, adminOnly: true },
      { title: "ონბორდინგი", url: "/onboarding", icon: UserPlus, hasBadge: false, adminOnly: true },
      { title: "ოფბორდინგი", url: "/offboarding", icon: LogOut, hasBadge: false, adminOnly: true },
      { title: "ფილიალთაშორის გადაყვანა", url: "/branch-transfers", icon: ArrowRightLeft, hasBadge: false, adminOnly: true },
    ],
    subGroups: []
  },
  {
    label: "დრო და დასწრება",
    icon: ClipboardList,
    gradient: "from-emerald-500 to-teal-500",
    items: [
      { title: "დასწრება", url: "/attendance", icon: ClipboardList, hasBadge: false, adminOnly: true },
      { title: "სამუშაო დროის აღრიცხვა", url: "/work-time-tracking", icon: Activity, hasBadge: false, adminOnly: true },
      { title: "სამუშაო გრაფიკები", url: "/work-schedules", icon: LayoutDashboard, hasBadge: false, adminOnly: true },
      { title: "ცვლების გრაფიკი", url: "/shift-schedules", icon: Grid3X3, hasBadge: false, adminOnly: true },
      { title: "ზეგანაკვეთური", url: "/overtime-requests", icon: Activity, hasBadge: false, adminOnly: true },
      { title: "დასწრების ანალიტიკა", url: "/attendance-analytics", icon: PieChart, hasBadge: false, adminOnly: true },
      { title: "სამუშაო დროის ფორმები", url: "/work-time-form-generator", icon: FileSignature, hasBadge: false, adminOnly: true },
    ],
    subGroups: []
  },
  {
    label: "მოთხოვნები",
    icon: TicketCheck,
    gradient: "from-sky-500 to-indigo-500",
    items: [
      { title: "შვებულებები", url: "/leave-requests", icon: ClipboardList, hasBadge: true, adminOnly: true },
      { title: "მივლინებები", url: "/business-trip-requests", icon: ArrowRightLeft, hasBadge: false, adminOnly: true },
      { title: "მოგზაურობის ცენტრი", url: "/travel-desk", icon: ArrowRightLeft, hasBadge: false, adminOnly: true },
      { title: "ავტომობილი", url: "/vehicle-requests", icon: Activity, hasBadge: false, adminOnly: true },
    ],
    subGroups: []
  },
  {
    label: "ფინანსები",
    icon: DollarSign,
    gradient: "from-amber-500 to-orange-500",
    items: [
      { title: "ფინანსების მიმოხილვა", url: "/finance", icon: DollarSign, hasBadge: false, adminOnly: true },
      { title: "ხელფასები", url: "/payroll", icon: DollarSign, hasBadge: false, adminOnly: true },
      { title: "საპენსიო", url: "/pension-payments", icon: DollarSign, hasBadge: false, adminOnly: true },
      { title: "RS.ge რეესტრი", url: "/rsge-registry", icon: DollarSign, hasBadge: false, adminOnly: true },
      { title: "ბენეფიტები", url: "/benefits-admin", icon: Heart, hasBadge: false, adminOnly: true },
      { title: "ხელფასების ბენჩმარკინგი", url: "/salary-benchmarking", icon: BarChart3, hasBadge: false, adminOnly: true },
    ],
    subGroups: []
  },
  {
    label: "ტალანტი",
    icon: GraduationCap,
    gradient: "from-indigo-500 to-violet-500",
    items: [
      { title: "რეკრუტმენტი", url: "/recruitment", icon: UserPlus, hasBadge: false, adminOnly: true },
      { title: "განვითარება", url: "/development", icon: GraduationCap, hasBadge: false, adminOnly: false },
      { title: "შეფასებები", url: "/employee-evaluations", icon: Target, hasBadge: false, adminOnly: true },
      { title: "უნარების მატრიცა", url: "/skills-matrix", icon: Target, hasBadge: false, adminOnly: true },
      { title: "ტალანტების რუკა", url: "/talent-map", icon: Target, hasBadge: false, adminOnly: true },
      { title: "შიდა მობილობა", url: "/internal-mobility", icon: ArrowRightLeft, hasBadge: false, adminOnly: true },
      { title: "ჯილდოები და აღიარება", url: "/recognition", icon: Trophy, hasBadge: false, adminOnly: true },
    ],
    subGroups: []
  },
  {
    label: "კომუნიკაცია",
    icon: Bell,
    gradient: "from-sky-500 to-cyan-500",
    items: [
      { title: "მესენჯერი", url: "/chat", icon: Bell, hasBadge: false, adminOnly: true },
      { title: "დავალებები", url: "/tasks", icon: TicketCheck, hasBadge: false, adminOnly: true },
      { title: "გამოცხადებები", url: "/announcements", icon: Bell, hasBadge: false, adminOnly: true },
      { title: "გამოკითხვები", url: "/pulse-surveys", icon: PieChart, hasBadge: false, adminOnly: true },
      { title: "კონტაქტები", url: "/contacts", icon: Users, hasBadge: false, adminOnly: true },
      { title: "Wiki", url: "/wiki", icon: GraduationCap, hasBadge: false, adminOnly: true },
    ],
    subGroups: []
  },
  {
    label: "ანალიტიკა",
    icon: BarChart3,
    gradient: "from-purple-500 to-pink-500",
    items: [
      { title: "ანგარიშები", url: "/reports", icon: BarChart3, hasBadge: false, adminOnly: true },
      { title: "HR ანალიტიკა", url: "/hr-analytics", icon: PieChart, hasBadge: false, adminOnly: true },
      { title: "ჩართულობა", url: "/engagement-analytics", icon: Heart, hasBadge: false, adminOnly: true },
      { title: "საშტატო დაგეგმვა", url: "/headcount-planning", icon: Users, hasBadge: false, adminOnly: true },
      { title: "სხვა HR ინსტრუმენტები", url: "/hr-tools", icon: Sparkles, hasBadge: false, adminOnly: false },
    ],
    subGroups: []
  },
  {
    label: "ორგანიზაცია",
    icon: Building2,
    gradient: "from-cyan-500 to-blue-500",
    items: [
      { title: "ორგანიზაციის მიმოხილვა", url: "/organization", icon: Building2, hasBadge: false, adminOnly: false },
      { title: "კომპანია", url: "/company-settings", icon: Building2, hasBadge: false, adminOnly: true },
      { title: "ფილიალები", url: "/branches", icon: Building2, hasBadge: false, adminOnly: true },
      { title: "ორგანიზაციული სტრუქტურა", url: "/organizational-structure", icon: Users, hasBadge: false, adminOnly: true },
      { title: "პოზიციები და აღწერილობები", url: "/job-descriptions", icon: FileSignature, hasBadge: false, adminOnly: true },
      { title: "გრაფიკის შაბლონები", url: "/schedule-templates", icon: LayoutDashboard, hasBadge: false, adminOnly: true },
      { title: "შვებულების ტიპები", url: "/leave-types", icon: ClipboardList, hasBadge: false, adminOnly: true },
      { title: "დასვენების დღეები", url: "/public-holidays", icon: ClipboardList, hasBadge: false, adminOnly: true },
    ],
    subGroups: []
  },
  {
    label: "ავტომატიზაცია",
    icon: Sparkles,
    gradient: "from-violet-500 to-pink-500",
    items: [
      { title: "Workflow კონსტრუქტორი", url: "/workflow-builder", icon: Sparkles, hasBadge: false, adminOnly: true },
      { title: "დამტკიცების ჯაჭვები", url: "/approval-chains", icon: ArrowRightLeft, hasBadge: false, adminOnly: true },
      { title: "AI დოკუმენტები", url: "/ai-documents", icon: FileSignature, hasBadge: false, adminOnly: true },
    ],
    subGroups: []
  },
  {
    label: "სისტემა",
    icon: Cog,
    gradient: "from-slate-500 to-gray-500",
    items: [
      { title: "სისტემის მიმოხილვა", url: "/system", icon: Cog, hasBadge: false, adminOnly: false },
      { title: "პარამეტრები", url: "/settings", icon: Cog, hasBadge: false, adminOnly: true },
      { title: "როლები", url: "/role-management", icon: ShieldCheck, hasBadge: false, adminOnly: true },
      { title: "ინტეგრაციები", url: "/integrations", icon: ArrowLeftRight, hasBadge: false, adminOnly: true },
      { title: "უსაფრთხოება", url: "/security", icon: Lock, hasBadge: false, adminOnly: true },
      { title: "ცვლილებების მონიტორინგი", url: "/audit-logs", icon: Activity, hasBadge: false, adminOnly: true },
      { title: "დატვირთვის ტესტი", url: "/load-test", icon: Activity, hasBadge: false, adminOnly: true },
      { title: "მონაცემთა ბექაფი", url: "/database-backup", icon: Server, hasBadge: false, adminOnly: true },
    ],
    subGroups: []
  },
  {
    label: "დახმარება",
    icon: GraduationCap,
    gradient: "from-slate-500 to-gray-500",
    items: [
      { title: "ნინა და სახელმძღვანელოები", url: "/help", icon: Sparkles, hasBadge: false, adminOnly: false },
      { title: "სიმულატორი", url: "/simulator", icon: GraduationCap, hasBadge: false, adminOnly: true },
      { title: "საპორტ ტიკეტები", url: "/support-tickets", icon: TicketCheck, hasBadge: false, adminOnly: true },
      { title: "რა შეიცვალა?", url: "/changelog", icon: Bell, hasBadge: false, adminOnly: true },
    ],
    subGroups: []
  },
];

const MANAGER_HUBS = ['/personnel', '/finance', '/reports', '/recruitment', '/development', '/organization', '/system', '/hr-tools'];

export function AppSidebar() {
  const { state } = useSidebar();
  const location = useLocation();
  const { requestSignOut, user, userRole } = useAuth();
  const { enabledFeatures, isLoading: isFeaturesLoading } = useFeatureAccess();
  const currentPath = location.pathname;
  const collapsed = state === "collapsed";
  const [unreadCount, setUnreadCount] = useState(0);
  const [pendingLeavesCount, setPendingLeavesCount] = useState(0);
  const [userPermissions, setUserPermissions] = useState<string[]>([]);
  const [searchOpen, setSearchOpen] = useState(false);

  // Keyboard shortcut for global search (Cmd+K / Ctrl+K)
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setSearchOpen((open) => !open);
      }
    };

    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  useEffect(() => {
    if (!user) return;
    
    fetchUnreadCount();
    fetchPendingLeavesCount();
    fetchUserPermissions();

    const notifChannel = supabase
      .channel('notifications-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'notifications' },
        (payload) => {
          fetchUnreadCount();
        }
      )
      .subscribe();

    const leaveChannel = supabase
      .channel('leave-requests-count')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'leave_requests' },
        () => {
          fetchPendingLeavesCount();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(notifChannel);
      supabase.removeChannel(leaveChannel);
    };
  }, [user, userRole]);

  const fetchUnreadCount = async () => {
    if (!user) return;
    
    try {
      const { count, error } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .or(`user_id.eq.${user.id},user_id.is.null`)
        .eq('is_read', false);
      
      if (error) {
        console.error('Error fetching unread count:', error);
        return;
      }
      
      setUnreadCount(count || 0);
    } catch (error) {
      console.error('Error in fetchUnreadCount:', error);
    }
  };

  const fetchPendingLeavesCount = async () => {
    if (!user) return;
    let query = supabase
      .from('leave_requests')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending');

    if (userRole === 'admin' || userRole === 'hr_manager') {
      // no extra filters
    } else {
      const { data: emp } = await supabase
        .from('employees')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();
      const empId = emp?.id;
      if (empId) {
        query = query.or(`manager_id.eq.${empId},user_id.eq.${user.id}`);
      } else {
        query = query.eq('user_id', user.id);
      }
    }
    const { count } = await query;
    setPendingLeavesCount(count || 0);
  };

  const fetchUserPermissions = async () => {
    if (!user) return;

    try {
      const { data: userCustomRoles, error: userRolesError } = await supabase
        .from('user_custom_roles')
        .select('role_id')
        .eq('user_id', user.id);

      if (userRolesError) throw userRolesError;

      if (!userCustomRoles || userCustomRoles.length === 0) {
        setUserPermissions([]);
        return;
      }

      const roleIds = userCustomRoles.map(r => r.role_id);

      const { data: permissions, error: permissionsError } = await supabase
        .from('role_permissions')
        .select('permission_key')
        .in('role_id', roleIds);

      if (permissionsError) throw permissionsError;

      const permissionKeys = permissions?.map(p => p.permission_key) || [];
      setUserPermissions(permissionKeys);
    } catch (error) {
      console.error('Error fetching user permissions:', error);
    }
  };

  const hasPermissionForRoute = (url: string): boolean => {
    if (userRole === 'admin' || userRole === 'hr_manager') {
      return true;
    }

    // Base routes always accessible for all authenticated users
    const baseRoutes = ['/dashboard', '/employee-portal', '/calendar', '/chat', '/help', '/notifications', '/'];
    if (baseRoutes.includes(url)) {
      return true;
    }

    // Employee portal routes that must be visible right after registration
    const employeeRoutes = [
      '/leave-requests',
      '/business-trip-requests',
      '/vehicle-requests',
      '/tasks',
      '/calendar',
      '/pulse-surveys',
      '/attendance',
      '/employee-profile',
      '/documents',
    ];
    if (userRole === 'employee' && employeeRoutes.includes(url)) {
      return true;
    }

    // Hub/category pages accessible for department_manager or users with custom permissions
    const hubRoutes = ['/personnel', '/finance', '/reports', '/recruitment', '/development', '/organization', '/system', '/hr-tools'];
    if (hubRoutes.includes(url) && (userRole === 'department_manager' || userPermissions.length > 0)) {
      return true;
    }

    // Department manager workspace
    const managerRoutes = ['/manager-dashboard', '/manager-headcount', '/work-schedules', '/leave-requests', '/attendance', '/employees'];
    if (userRole === 'department_manager' && managerRoutes.includes(url)) {
      return true;
    }

    // If user has custom role permissions, check them
    if (userPermissions.length > 0) {
      const permissionKey = url.substring(1);
      return userPermissions.includes(permissionKey);
    }

    // No custom permissions and not a base route
    return false;
  };

  // Filter items based on user role
  const getFilteredGroups = () => {
    const canManage = userRole === 'admin' || userRole === 'hr_manager' || userRole === 'department_manager';
    
    return navigationGroups.map(group => {
      const filteredItems = group.items.filter(item => {
        if ((item as any).superAdminOnly && userRole !== 'admin') return false;
        if ((item as any).employeeOnly && userRole !== 'employee') return false;
        if ((item as any).managerOnly && userRole !== 'department_manager') return false;
        if (item.adminOnly && !canManage) return false;
        if (item.adminOnly && userRole === 'department_manager' && !MANAGER_HUBS.includes(item.url)) return false;
        if (!hasPermissionForRoute(item.url)) return false;
        return true;
      });

      let filteredSubGroups: typeof group.subGroups = [];
      if (group.subGroups) {
        filteredSubGroups = group.subGroups.map(subGroup => ({
          ...subGroup,
          items: subGroup.items.filter(item => {
            if (item.adminOnly && !canManage) return false;
            if (!hasPermissionForRoute(item.url)) return false;
            return true;
          })
        })).filter(sg => sg.items.length > 0);
      }

      return {
        ...group,
        items: filteredItems,
        subGroups: filteredSubGroups
      };
    }).filter(group => group.items.length > 0 || (group.subGroups && group.subGroups.length > 0));
  };

  return (
    <TooltipProvider delayDuration={0}>
      <Sidebar className={`${collapsed ? "w-16" : "w-64"} md:border-0`} collapsible="icon">
        <SidebarContent className="sidebar-glass-arc bg-sidebar md:rounded-r-2xl border border-sidebar-primary/40 transition-all duration-300">
          {/* Header with Logo */}
          <div className="p-4 border-b border-sidebar-border/40 flex items-center gap-3 transition-all duration-300">
            <div className="relative">
              <img 
                src={companyLogo} 
                alt="HR Management" 
                className={`relative ${collapsed ? 'h-8 w-8' : 'h-9 w-9'} transition-all duration-300`} 
              />
            </div>
            {!collapsed && (
              <div>
                <h2 className="text-sm font-semibold tracking-tight bg-gradient-to-r from-[hsl(var(--sidebar-primary))] to-[hsl(var(--primary-glow))] bg-clip-text text-transparent">
                  HR System
                </h2>
                <p className="text-[10px] font-medium tracking-wider uppercase text-[hsl(var(--sidebar-primary))]/70">
                  Enterprise
                </p>
              </div>
            )}
          </div>

          {/* User Info */}
          {!collapsed && user?.email && (
            <div className="px-4 py-3 border-b border-sidebar-border/40">
              <div className="flex items-center gap-3">
                <div className="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center">
                  <User className="h-4 w-4 text-sidebar-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-sidebar-foreground truncate font-medium">{user.email}</p>
                  <p className="text-[10px] text-sidebar-foreground/40 capitalize">{userRole || 'User'}</p>
                </div>
              </div>
            </div>
          )}

          {/* Search Bar */}
          {!collapsed && (
            <div className="p-3 border-b border-sidebar-border/40">
              <button
                onClick={() => setSearchOpen(true)}
                className="w-full flex items-center gap-2 pl-3 pr-3 py-2 text-sm bg-sidebar-accent/60 text-sidebar-foreground/50 rounded-lg hover:bg-sidebar-accent hover:text-sidebar-foreground/70 focus:outline-none transition-all duration-200"
              >
                <Search className="h-3.5 w-3.5" />
                <span className="flex-1 text-left text-xs">ძებნა...</span>
                <kbd className="pointer-events-none hidden sm:inline-flex h-5 select-none items-center gap-1 rounded border border-sidebar-border/50 bg-sidebar-accent/80 px-1.5 font-mono text-[10px] text-sidebar-foreground/40">
                  <span className="text-xs">⌘</span>K
                </kbd>
              </button>
            </div>
          )}

          {/* Navigation Groups */}
          <div className="flex-1 overflow-y-auto py-2">
            {getFilteredGroups().map((group, groupIndex) => {
              const hasActiveMainItem = group.items.some(
                (item) => currentPath === item.url
              );
              const hasActiveSubItem = group.subGroups?.some(sg => 
                sg.items.some(item => currentPath === item.url)
              ) || false;
              const hasActiveItem = hasActiveMainItem || hasActiveSubItem;

              const GroupIcon = group.icon;

              return (
                <Collapsible
                  key={group.label}
                  defaultOpen={hasActiveItem}
                  className="transition-all duration-200"
                >
                  <SidebarGroup>
                    <CollapsibleTrigger className="w-full group">
                      <SidebarGroupLabel className="flex items-center justify-between hover:bg-sidebar-accent/60 rounded-lg mx-2 px-3 py-2 cursor-pointer transition-all duration-200">
                        {collapsed ? (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="p-1.5 rounded-lg">
                                <GroupIcon className="h-4 w-4 text-sidebar-foreground/60" />
                              </div>
                            </TooltipTrigger>
                            <TooltipContent side="right" className="font-medium">
                              {group.label}
                            </TooltipContent>
                          </Tooltip>
                        ) : (
                          <>
                            <div className="flex items-center gap-2.5">
                              <GroupIcon className="h-4 w-4 text-sidebar-foreground/50" />
                              <span className="text-sidebar-foreground/70 font-medium text-xs uppercase tracking-wider">{group.label}</span>
                            </div>
                            <ChevronDown className="h-3.5 w-3.5 text-sidebar-foreground/30 transition-transform duration-200 group-data-[state=open]:rotate-180" />
                          </>
                        )}
                      </SidebarGroupLabel>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="animate-accordion-down">
                      <SidebarGroupContent>
                        <SidebarMenu className="px-2">
                          {/* Main items */}
                          {group.items.map((item) => {
                            const isActive = currentPath === item.url;
                            const featureKey = sidebarFeatureMap[item.url];
                            const isFeatureEnabledByPlan = !featureKey
                              || isFeaturesLoading
                              || enabledFeatures.includes('__all__')
                              || enabledFeatures.includes(featureKey);
                            const isLocked = !isFeatureEnabledByPlan;
                            const badgeCount = 
                              item.url === '/notifications' ? unreadCount :
                              item.url === '/leave-requests' ? pendingLeavesCount : 0;
                            
                            const menuItem = (
                              <SidebarMenuItem key={item.title}>
                                <SidebarMenuButton asChild>
                                  <NavLink
                                    to={item.url}
                                    end
                                    onClick={isLocked ? (e) => e.preventDefault() : undefined}
                                    className={`flex items-center gap-2.5 w-full text-[13px] py-2 px-3 rounded-lg transition-all duration-200 ${
                                      isLocked
                                        ? 'opacity-50 cursor-not-allowed text-sidebar-foreground/40'
                                        : isActive 
                                          ? 'bg-sidebar-primary/15 text-sidebar-primary-foreground font-medium border-l-2 border-sidebar-primary' 
                                          : 'hover:bg-sidebar-accent/60 text-sidebar-foreground/70 hover:text-sidebar-foreground'
                                    }`}
                                  >
                                    <item.icon className={`h-4 w-4 shrink-0 ${isActive && !isLocked ? 'text-sidebar-primary' : ''}`} />
                                    {!collapsed && (
                                      <span className="truncate flex-1">{item.title}</span>
                                    )}
                                    {!collapsed && isLocked && (
                                      <Lock className="h-3.5 w-3.5 text-sidebar-foreground/40 shrink-0" />
                                    )}
                                    {!collapsed && !isLocked && item.hasBadge && badgeCount > 0 && (
                                      <Badge 
                                        variant="destructive" 
                                        className="h-5 min-w-[20px] rounded-full px-1.5 text-[10px]"
                                      >
                                        {badgeCount}
                                      </Badge>
                                    )}
                                  </NavLink>
                                </SidebarMenuButton>
                              </SidebarMenuItem>
                            );

                            if (collapsed) {
                              return (
                                <Tooltip key={item.title}>
                                  <TooltipTrigger asChild>
                                    {menuItem}
                                  </TooltipTrigger>
                                  <TooltipContent side="right" className="flex items-center gap-2">
                                    {item.title}
                                    {isLocked && (
                                      <Lock className="h-3 w-3 text-muted-foreground" />
                                    )}
                                    {!isLocked && item.hasBadge && badgeCount > 0 && (
                                      <Badge variant="destructive" className="h-4 min-w-[16px] rounded-full px-1 text-[10px]">
                                        {badgeCount}
                                      </Badge>
                                    )}
                                  </TooltipContent>
                                </Tooltip>
                              );
                            }

                            return menuItem;
                          })}

                          {/* SubGroups */}
                          {!collapsed && group.subGroups && group.subGroups.map((subGroup) => (
                            <Collapsible key={subGroup.label} defaultOpen={false} className="ml-2">
                              <CollapsibleTrigger className="w-full group">
                                <div className="flex items-center gap-2 px-3 py-1.5 text-xs text-sidebar-foreground/50 hover:text-sidebar-foreground/70 hover:bg-sidebar-accent/40 rounded-lg transition-all duration-200 cursor-pointer">
                                  <ChevronRight className="h-3 w-3 transition-transform duration-200 group-data-[state=open]:rotate-90" />
                                  <span className="font-medium">{subGroup.label}</span>
                                </div>
                              </CollapsibleTrigger>
                              <CollapsibleContent className="ml-4 animate-accordion-down">
                                {subGroup.items.map((item) => {
                                  const isActive = currentPath === item.url;
                                  
                                  return (
                                    <SidebarMenuItem key={item.title}>
                                      <SidebarMenuButton asChild>
                                        <NavLink
                                          to={item.url}
                                          end
                                          className={`flex items-center gap-2 w-full text-[13px] py-1.5 px-3 rounded-lg transition-all duration-200 ${
                                            isActive 
                                              ? 'bg-sidebar-primary/15 text-sidebar-primary font-medium' 
                                              : 'hover:bg-sidebar-accent/40 text-sidebar-foreground/60 hover:text-sidebar-foreground/80'
                                          }`}
                                        >
                                          <item.icon className="h-3.5 w-3.5 shrink-0" />
                                          <span className="truncate flex-1">{item.title}</span>
                                        </NavLink>
                                      </SidebarMenuButton>
                                    </SidebarMenuItem>
                                  );
                                })}
                              </CollapsibleContent>
                            </Collapsible>
                          ))}
                        </SidebarMenu>
                      </SidebarGroupContent>
                    </CollapsibleContent>
                  </SidebarGroup>
                </Collapsible>
              );
            })}
          </div>

          {/* Logout Button */}
          <div className="p-3 border-t border-sidebar-border/40">
            {collapsed ? (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    onClick={requestSignOut}
                    variant="ghost"
                    size="icon"
                    className="w-full h-9 text-sidebar-foreground/50 hover:text-destructive hover:bg-destructive/10 transition-all duration-200"
                  >
                    <LogOut className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="right">გასვლა</TooltipContent>
              </Tooltip>
            ) : (
              <Button
                onClick={requestSignOut}
                variant="ghost"
                className="w-full justify-start gap-3 h-9 text-sidebar-foreground/50 hover:text-destructive hover:bg-destructive/10 transition-all duration-200 rounded-lg text-sm"
              >
                <LogOut className="h-4 w-4" />
                <span>გასვლა</span>
              </Button>
            )}
          </div>
        </SidebarContent>
        
        {/* Global Search Dialog */}
        <GlobalSearch open={searchOpen} onOpenChange={setSearchOpen} />
      </Sidebar>
    </TooltipProvider>
  );
}