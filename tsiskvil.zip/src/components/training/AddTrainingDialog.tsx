import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus } from "lucide-react";

const trainingSchema = z.object({
  title: z.string().min(3, "სათაური უნდა იყოს მინიმუმ 3 სიმბოლო").max(200),
  description: z.string().optional(),
  category: z.string().min(1, "კატეგორია აუცილებელია"),
  course_status: z.enum(["active", "upcoming", "completed", "cancelled"]),
  instructor_name: z.string().optional(),
  instructor_email: z.string().email("არასწორი ელ-ფოსტა").optional().or(z.literal("")),
  start_date: z.string().min(1, "დაწყების თარიღი აუცილებელია"),
  end_date: z.string().optional(),
  duration_weeks: z.coerce.number().int().positive().optional(),
  max_participants: z.coerce.number().int().positive().optional(),
  location: z.string().optional(),
  is_online: z.boolean().default(false),
  meeting_link: z.string().url("არასწორი ბმული").optional().or(z.literal("")),
  budget: z.coerce.number().positive().optional(),
});

type TrainingFormValues = z.infer<typeof trainingSchema>;

export function AddTrainingDialog() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  const form = useForm<TrainingFormValues>({
    resolver: zodResolver(trainingSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "",
      course_status: "upcoming",
      instructor_name: "",
      instructor_email: "",
      start_date: "",
      end_date: "",
      location: "",
      is_online: false,
      meeting_link: "",
    },
  });

  const onSubmit = async (data: TrainingFormValues) => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      
      const trainingData = {
        title: data.title,
        description: data.description || null,
        category: data.category,
        course_status: data.course_status,
        instructor_name: data.instructor_name || null,
        instructor_email: data.instructor_email || null,
        start_date: data.start_date,
        end_date: data.end_date || null,
        duration_weeks: data.duration_weeks || null,
        max_participants: data.max_participants || null,
        location: data.location || null,
        is_online: data.is_online,
        meeting_link: data.meeting_link || null,
        budget: data.budget || null,
        created_by: userData.user?.id,
      };

      const { error } = await supabase
        .from("training_courses")
        .insert(trainingData);

      if (error) throw error;

      toast({
        title: "წარმატება",
        description: "ტრენინგი წარმატებით დაემატა",
      });

      form.reset();
      setOpen(false);
      window.location.reload();
    } catch (error) {
      console.error("Error adding training:", error);
      toast({
        title: "შეცდომა",
        description: "ტრენინგის დამატება ვერ მოხერხდა",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          ახალი ტრენინგი
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>ახალი ტრენინგის დამატება</DialogTitle>
          <DialogDescription>
            შეავსეთ ინფორმაცია ახალი ტრენინგის შესაქმნელად
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>სათაური *</FormLabel>
                  <FormControl>
                    <Input placeholder="ტრენინგის სახელი" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>აღწერა</FormLabel>
                  <FormControl>
                    <Textarea placeholder="ტრენინგის აღწერა" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>კატეგორია *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="აირჩიეთ კატეგორია" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="IT">IT</SelectItem>
                        <SelectItem value="მენეჯმენტი">მენეჯმენტი</SelectItem>
                        <SelectItem value="გაყიდვები">გაყიდვები</SelectItem>
                        <SelectItem value="მარკეტინგი">მარკეტინგი</SelectItem>
                        <SelectItem value="ფინანსები">ფინანსები</SelectItem>
                        <SelectItem value="HR">HR</SelectItem>
                        <SelectItem value="სხვა">სხვა</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="course_status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>სტატუსი *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="upcoming">დაგეგმილი</SelectItem>
                        <SelectItem value="active">აქტიური</SelectItem>
                        <SelectItem value="completed">დასრულებული</SelectItem>
                        <SelectItem value="cancelled">გაუქმებული</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="instructor_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ინსტრუქტორი</FormLabel>
                    <FormControl>
                      <Input placeholder="ინსტრუქტორის სახელი" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="instructor_email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ინსტრუქტორის ელ-ფოსტა</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="email@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="start_date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>დაწყების თარიღი *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="end_date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>დასრულების თარიღი</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="duration_weeks"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ხანგრძლივობა (კვირები)</FormLabel>
                    <FormControl>
                      <Input type="number" min="1" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="max_participants"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>მაქს. მონაწილეები</FormLabel>
                    <FormControl>
                      <Input type="number" min="1" placeholder="ლიმიტი" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="budget"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ბიუჯეტი (₾)</FormLabel>
                    <FormControl>
                      <Input type="number" min="0" step="0.01" placeholder="0.00" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="is_online"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">ონლაინ ტრენინგი</FormLabel>
                    <div className="text-sm text-muted-foreground">
                      ტრენინგი იქნება დისტანციური
                    </div>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                </FormItem>
              )}
            />

            {form.watch("is_online") && (
              <FormField
                control={form.control}
                name="meeting_link"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>შეხვედრის ბმული</FormLabel>
                    <FormControl>
                      <Input type="url" placeholder="https://meet.google.com/..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {!form.watch("is_online") && (
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ადგილმდებარეობა</FormLabel>
                    <FormControl>
                      <Input placeholder="ოფისი, მისამართი" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <div className="flex gap-2 justify-end pt-4">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                გაუქმება
              </Button>
              <Button type="submit">დამატება</Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
