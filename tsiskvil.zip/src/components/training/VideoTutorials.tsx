import { useState, useEffect } from "react";
import { Play, Clock, Tag, Search } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface VideoTutorial {
  id: string;
  title: string;
  description: string;
  duration: string;
  category: string;
  video_url: string;
  thumbnail?: string;
}

const categories = ["ყველა", "თანამშრომლები", "დასწრება", "შვებულება", "ფინანსები", "გრაფიკები", "ანგარიშები"];

export function VideoTutorials() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("ყველა");
  const [selectedVideo, setSelectedVideo] = useState<VideoTutorial | null>(null);
  const [tutorials, setTutorials] = useState<VideoTutorial[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTutorials();
  }, []);

  const fetchTutorials = async () => {
    try {
      const { data, error } = await supabase
        .from("video_tutorials")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setTutorials(data || []);
    } catch (error) {
      console.error("Error fetching tutorials:", error);
      toast.error("ვიდეოების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const filteredTutorials = tutorials.filter((tutorial) => {
    const matchesSearch = tutorial.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tutorial.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "ყველა" || tutorial.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="ვიდეოს ძიება..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>

        <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
          <TabsList className="w-full justify-start overflow-x-auto flex-wrap h-auto">
            {categories.map((category) => (
              <TabsTrigger key={category} value={category}>
                {category}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>

      {selectedVideo ? (
        <div className="space-y-4">
          <button
            onClick={() => setSelectedVideo(null)}
            className="text-sm text-primary hover:underline"
          >
            ← უკან სიისთან
          </button>
          
          <Card>
            <CardHeader>
              <CardTitle>{selectedVideo.title}</CardTitle>
              <CardDescription>{selectedVideo.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="aspect-video w-full rounded-lg overflow-hidden bg-muted">
                <iframe
                  src={selectedVideo.video_url}
                  title={selectedVideo.title}
                  className="w-full h-full"
                  allowFullScreen
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                />
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {selectedVideo.duration}
                </div>
                <div className="flex items-center gap-1">
                  <Tag className="h-4 w-4" />
                  {selectedVideo.category}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : loading ? (
        <div className="text-center py-8">იტვირთება...</div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredTutorials.map((tutorial) => (
            <Card
              key={tutorial.id}
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setSelectedVideo(tutorial)}
            >
              <CardContent className="p-0">
                <div className="relative aspect-video bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center">
                  <Play className="h-12 w-12 text-primary" />
                  <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                    {tutorial.duration}
                  </div>
                </div>
                <div className="p-4 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-semibold line-clamp-2">{tutorial.title}</h3>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {tutorial.description}
                  </p>
                  <Badge variant="secondary" className="text-xs">
                    {tutorial.category}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {filteredTutorials.length === 0 && (
        <Card className="p-12">
          <div className="text-center text-muted-foreground">
            <Play className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>ვიდეო ტუტორიალები ვერ მოიძებნა</p>
          </div>
        </Card>
      )}
    </div>
  );
}
