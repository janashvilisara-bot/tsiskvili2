import { useEffect, useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, Search, Clock, History, LogOut, CalendarDays, ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";

const TOKEN_KEY = "findme_token";
const FINDME_SITE = "https://findme.ge";

interface Specialist {
  id: string;
  firstName: string;
  lastName: string;
  profession?: string;
  specialization?: string;
  bio?: string;
  experience?: string;
  languages?: string[];
  profileImage?: string;
  hourlyRate?: number;
  currency?: string;
  duration?: number;
}

type Lang = "ka" | "en";
const T = {
  ka: {
    search: "სპეციალისტის ძებნა...", book: "დაჯავშნა", min: "წთ", exp: "გამოცდილება", years: "წელი",
    slots: "თავისუფალი დრო", noSlots: "ამ პერიოდში თავისუფალი დრო არ არის", pay: "გადახდაზე გადასვლა",
    hold: "არჩეული დრო 30 წუთით დაიჯავშნება. ჯავშანი და ვიდეოზარის ბმული წარმატებული გადახდის შემდეგ ელფოსტაზე მოვა.",
    login: "FindMe-ში შესვლა", register: "რეგისტრაცია", verify: "ელფოსტის დადასტურება", email: "ელფოსტა",
    password: "პაროლი", confirm: "გაიმეორეთ პაროლი", first: "სახელი", last: "გვარი", code: "კოდი ელფოსტიდან",
    terms: "ვეთანხმები FindMe-ის წესებსა და პირობებს", readTerms: "წაკითხვა", submit: "გაგრძელება",
    haveAcc: "უკვე გაქვთ ანგარიში? შესვლა", noAcc: "არ გაქვთ ანგარიში? რეგისტრაცია", history: "ჩემი კონსულტაციები",
    logout: "FindMe-დან გასვლა", empty: "კონსულტაციები ჯერ არ გაქვთ", openFindme: "FindMe-ზე გახსნა",
    intro: "ონლაინ კონსულტაციები სპეციალისტებთან FindMe-ს პლატფორმაზე", connected: "FindMe-ზე შესული ხართ",
    pwMismatch: "პაროლები არ ემთხვევა", codeSent: "კოდი გაიგზავნა ელფოსტაზე", loggedIn: "წარმატებით შეხვედით",
    manage: "გაუქმება და კონსულტაციაში შესვლა ხდება FindMe-ზე, იმავე ანგარიშით.", error: "შეცდომა",
    e400: "მონაცემები არასწორია", e401: "გთხოვთ, თავიდან შეხვიდეთ FindMe-ში", e403: "ანგარიშზე წვდომა შეზღუდულია",
    e404: "ვერ მოიძებნა", e409: "ეს დრო უკვე დაკავებულია, აირჩიეთ სხვა", e429: "ძალიან ბევრი მოთხოვნაა, სცადეთ მოგვიანებით",
    e503: "FindMe დროებით მიუწვდომელია", eGen: "მოთხოვნა ვერ შესრულდა",
  },
  en: {
    search: "Search specialists...", book: "Book", min: "min", exp: "Experience", years: "years",
    slots: "Available times", noSlots: "No available times in this period", pay: "Continue to payment",
    hold: "The selected time is held for 30 minutes. The booking and video link arrive by email after successful payment.",
    login: "Sign in to FindMe", register: "Create account", verify: "Verify email", email: "Email",
    password: "Password", confirm: "Repeat password", first: "First name", last: "Last name", code: "Code from email",
    terms: "I accept FindMe terms and conditions", readTerms: "Read", submit: "Continue",
    haveAcc: "Already have an account? Sign in", noAcc: "No account? Register", history: "My consultations",
    logout: "Sign out of FindMe", empty: "No consultations yet", openFindme: "Open on FindMe",
    intro: "Online consultations with specialists on FindMe", connected: "Signed in to FindMe",
    pwMismatch: "Passwords do not match", codeSent: "Code sent to your email", loggedIn: "Signed in",
    manage: "Cancelling and joining sessions happens on FindMe with the same account.", error: "Error",
    e400: "Invalid data", e401: "Please sign in to FindMe again", e403: "Account access restricted",
    e404: "Not found", e409: "This time is already taken, choose another", e429: "Too many requests, try later",
    e503: "FindMe is temporarily unavailable", eGen: "Request failed",
  },
};

async function callFindMe(method: "GET" | "POST", path: string, opts: { query?: Record<string, string>; payload?: unknown } = {}) {
  const token = sessionStorage.getItem(TOKEN_KEY);
  const { data, error } = await supabase.functions.invoke("findme-proxy", {
    body: { method, path, ...opts },
    headers: token ? { "x-findme-token": token } : undefined,
  });
  if (error) return { status: 503, data: null as any };
  return data as { status: number; data: any };
}

export function FindMeConsultations() {
  const { language } = useLanguage();
  const t = T[(language as Lang) === "en" ? "en" : "ka"];
  const { toast } = useToast();

  const [specialists, setSpecialists] = useState<Specialist[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [token, setToken] = useState<string | null>(() => sessionStorage.getItem(TOKEN_KEY));

  const [selected, setSelected] = useState<Specialist | null>(null);
  const [slots, setSlots] = useState<string[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [slot, setSlot] = useState<string | null>(null);
  const [paying, setPaying] = useState(false);

  const [authOpen, setAuthOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [bookings, setBookings] = useState<any[]>([]);

  const errMsg = (s: number) => (t as any)[`e${s}`] ?? t.eGen;
  const fail = (s: number, data?: any) => {
    if (s === 401) { sessionStorage.removeItem(TOKEN_KEY); setToken(null); }
    const detail = typeof data?.error === "string" && s === 400 ? `: ${data.error}` : "";
    toast({ title: t.error, description: errMsg(s) + detail, variant: "destructive" });
  };

  useEffect(() => {
    callFindMe("GET", "specialists").then((r) => {
      if (r.status === 200) setSpecialists(r.data?.specialists ?? []);
      else fail(r.status);
      setLoading(false);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return specialists;
    return specialists.filter((s) =>
      `${s.firstName} ${s.lastName} ${s.profession ?? ""} ${s.specialization ?? ""}`.toLowerCase().includes(q));
  }, [specialists, query]);

  const openSpecialist = async (s: Specialist) => {
    setSelected(s); setSlot(null); setSlots([]); setSlotsLoading(true);
    const from = new Date(); const to = new Date(Date.now() + 14 * 86400000);
    const r = await callFindMe("GET", `specialists/${s.id}/slots`, { query: { from: from.toISOString(), to: to.toISOString() } });
    if (r.status === 200) setSlots(r.data?.slots ?? []); else fail(r.status);
    setSlotsLoading(false);
  };

  const slotsByDay = useMemo(() => {
    const m = new Map<string, string[]>();
    slots.forEach((iso) => {
      const day = new Date(iso).toLocaleDateString(language === "en" ? "en-GB" : "ka-GE", { weekday: "short", day: "numeric", month: "short", timeZone: "Asia/Tbilisi" });
      m.set(day, [...(m.get(day) ?? []), iso]);
    });
    return [...m.entries()];
  }, [slots, language]);

  const checkout = async () => {
    if (!selected || !slot) return;
    if (!token) { setAuthOpen(true); return; }
    setPaying(true);
    const r = await callFindMe("POST", "checkout", { payload: { specialistId: selected.id, scheduledAt: slot } });
    setPaying(false);
    if (r.status >= 200 && r.status < 300 && typeof r.data?.checkoutUrl === "string" && r.data.checkoutUrl.startsWith("https://")) {
      window.location.href = r.data.checkoutUrl;
    } else {
      fail(r.status === 200 ? 0 : r.status, r.data);
      if (r.status === 409) openSpecialist(selected);
      if (r.status === 401) setAuthOpen(true);
    }
  };

  const openHistory = async () => {
    setHistoryOpen(true);
    const r = await callFindMe("GET", "bookings");
    if (r.status === 200) setBookings(r.data?.bookings ?? (Array.isArray(r.data) ? r.data : []));
    else fail(r.status);
  };

  const imgUrl = (p?: string) => (!p ? undefined : p.startsWith("http") ? p : `${FINDME_SITE}${p}`);
  const fmt = (iso: string) => new Date(iso).toLocaleTimeString(language === "en" ? "en-GB" : "ka-GE", { hour: "2-digit", minute: "2-digit", hourCycle: "h23", timeZone: "Asia/Tbilisi" });

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <p className="text-sm text-muted-foreground">{t.intro}</p>
        <div className="flex flex-wrap gap-2">
          {token ? (
            <>
              <Badge variant="outline">{t.connected}</Badge>
              <Button variant="outline" size="sm" onClick={openHistory}><History className="mr-2 h-4 w-4" />{t.history}</Button>
              <Button variant="ghost" size="sm" onClick={() => { sessionStorage.removeItem(TOKEN_KEY); setToken(null); }}>
                <LogOut className="mr-2 h-4 w-4" />{t.logout}
              </Button>
            </>
          ) : (
            <Button variant="outline" size="sm" onClick={() => setAuthOpen(true)}>{t.login}</Button>
          )}
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input className="pl-9" placeholder={t.search} value={query} onChange={(e) => setQuery(e.target.value)} aria-label={t.search} />
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((s) => (
            <Card key={s.id} className="flex flex-col">
              <CardContent className="flex flex-1 flex-col gap-3 p-4">
                <div className="flex items-center gap-3">
                  {s.profileImage ? (
                    <img src={imgUrl(s.profileImage)} alt="" loading="lazy" className="h-14 w-14 rounded-full border object-cover" />
                  ) : (
                    <div className="flex h-14 w-14 items-center justify-center rounded-full border text-lg font-semibold">{s.firstName?.[0]}</div>
                  )}
                  <div className="min-w-0">
                    <h3 className="font-semibold leading-tight">{s.firstName} {s.lastName}</h3>
                    {s.profession && <p className="text-xs text-muted-foreground">{s.profession}</p>}
                  </div>
                </div>
                {s.specialization && <p className="line-clamp-2 text-sm">{s.specialization}</p>}
                <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                  {s.duration && <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{s.duration} {t.min}</span>}
                  {s.experience && <span>{t.exp}: {s.experience} {t.years}</span>}
                </div>
                <div className="mt-auto flex items-center justify-between pt-2">
                  <span className="font-semibold">{s.hourlyRate} {s.currency === "GEL" ? "₾" : s.currency}</span>
                  <Button size="sm" onClick={() => openSpecialist(s)}>{t.book}</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Specialist + slots */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-h-[90vh] max-w-2xl">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle>{selected.firstName} {selected.lastName}</DialogTitle>
                <DialogDescription>{selected.specialization}</DialogDescription>
              </DialogHeader>
              <div className="max-h-[60vh] overflow-y-auto pr-3">
                {selected.bio && <p className="mb-4 whitespace-pre-line text-sm text-muted-foreground">{selected.bio}</p>}
                <h4 className="mb-2 flex items-center gap-2 font-medium"><CalendarDays className="h-4 w-4" />{t.slots}</h4>
                {slotsLoading ? (
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                ) : slotsByDay.length === 0 ? (
                  <p className="text-sm text-muted-foreground">{t.noSlots}</p>
                ) : (
                  <div className="space-y-3">
                    {slotsByDay.map(([day, list]) => (
                      <div key={day}>
                        <p className="mb-1 text-xs font-medium text-muted-foreground">{day}</p>
                        <div className="flex flex-wrap gap-2">
                          {list.map((iso) => (
                            <Button key={iso} size="sm" variant={slot === iso ? "default" : "outline"} onClick={() => setSlot(iso)}>{fmt(iso)}</Button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <p className="text-xs text-muted-foreground">{t.hold}</p>
              <Button disabled={!slot || paying} onClick={checkout}>
                {paying && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {token ? t.pay : t.login}
              </Button>
            </>
          )}
        </DialogContent>
      </Dialog>

      <FindMeAuthDialog open={authOpen} onOpenChange={setAuthOpen} t={t} language={language === "en" ? "en" : "ka"}
        onFail={fail} onToken={(tok) => { sessionStorage.setItem(TOKEN_KEY, tok); setToken(tok); toast({ title: t.loggedIn }); }} />

      {/* History */}
      <Dialog open={historyOpen} onOpenChange={setHistoryOpen}>
        <DialogContent className="max-h-[90vh] max-w-lg">
          <DialogHeader>
            <DialogTitle>{t.history}</DialogTitle>
            <DialogDescription>{t.manage}</DialogDescription>
          </DialogHeader>
          <div className="max-h-[60vh] overflow-y-auto">
            {bookings.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">{t.empty}</p>
            ) : (
              <div className="space-y-2">
                {bookings.map((b, i) => {
                  const when = b.scheduledAt ?? b.startTime ?? b.date;
                  const name = b.specialist ? `${b.specialist.firstName ?? ""} ${b.specialist.lastName ?? ""}` : b.specialistName;
                  return (
                    <div key={b.id ?? i} className="flex items-center justify-between rounded-md border p-3 text-sm">
                      <div>
                        <p className="font-medium">{name || "FindMe"}</p>
                        {when && <p className="text-xs text-muted-foreground">{new Date(when).toLocaleString(language === "en" ? "en-GB" : "ka-GE", { timeZone: "Asia/Tbilisi" })}</p>}
                      </div>
                      {b.status && <Badge variant="outline">{b.status}</Badge>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <Button variant="outline" asChild>
            <a href={FINDME_SITE} target="_blank" rel="noopener noreferrer"><ExternalLink className="mr-2 h-4 w-4" />{t.openFindme}</a>
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function FindMeAuthDialog({ open, onOpenChange, t, language, onToken, onFail }: {
  open: boolean; onOpenChange: (o: boolean) => void; t: typeof T.ka; language: Lang;
  onToken: (t: string) => void; onFail: (s: number, d?: any) => void;
}) {
  const { toast } = useToast();
  const [mode, setMode] = useState<"login" | "register" | "verify">("login");
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState({ firstName: "", lastName: "", email: "", password: "", confirmPassword: "", code: "" });
  const [terms, setTerms] = useState<{ id: string; content: string } | null>(null);
  const [accepted, setAccepted] = useState(false);
  const [showTerms, setShowTerms] = useState(false);

  useEffect(() => {
    if (open && mode === "register" && !terms) {
      callFindMe("GET", "terms", { query: { language } }).then((r) => r.status === 200 && setTerms(r.data?.terms ?? null));
    }
  }, [open, mode, terms, language]);

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  const login = async () => {
    const r = await callFindMe("POST", "auth/login", { payload: { email: f.email.trim(), password: f.password } });
    if (r.status === 200 && r.data?.token) {
      onToken(r.data.token); setF({ ...f, password: "", confirmPassword: "", code: "" }); onOpenChange(false);
    } else onFail(r.status, r.data);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      if (mode === "login") await login();
      else if (mode === "register") {
        if (f.password !== f.confirmPassword) { toast({ title: t.pwMismatch, variant: "destructive" }); return; }
        if (!terms || !accepted) return;
        const r = await callFindMe("POST", "auth/register", { payload: {
          firstName: f.firstName.trim(), lastName: f.lastName.trim(), email: f.email.trim(),
          password: f.password, confirmPassword: f.confirmPassword, acceptedTermsVersionId: terms.id } });
        if (r.status >= 200 && r.status < 300) { toast({ title: t.codeSent }); setMode("verify"); }
        else onFail(r.status, r.data);
      } else {
        const r = await callFindMe("POST", "auth/verify-email", { payload: { email: f.email.trim(), code: f.code.trim() } });
        if (r.status >= 200 && r.status < 300) await login();
        else onFail(r.status, r.data);
      }
    } finally { setBusy(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-md overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mode === "login" ? t.login : mode === "register" ? t.register : t.verify}</DialogTitle>
          <DialogDescription>FindMe</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          {mode === "register" && (
            <div className="grid grid-cols-2 gap-2">
              <div><Label htmlFor="fm-first">{t.first}</Label><Input id="fm-first" required value={f.firstName} onChange={set("firstName")} /></div>
              <div><Label htmlFor="fm-last">{t.last}</Label><Input id="fm-last" required value={f.lastName} onChange={set("lastName")} /></div>
            </div>
          )}
          <div><Label htmlFor="fm-email">{t.email}</Label><Input id="fm-email" type="email" required value={f.email} onChange={set("email")} /></div>
          {mode !== "verify" && (
            <div><Label htmlFor="fm-pw">{t.password}</Label><Input id="fm-pw" type="password" required autoComplete={mode === "login" ? "current-password" : "new-password"} value={f.password} onChange={set("password")} /></div>
          )}
          {mode === "register" && (
            <>
              <div><Label htmlFor="fm-pw2">{t.confirm}</Label><Input id="fm-pw2" type="password" required autoComplete="new-password" value={f.confirmPassword} onChange={set("confirmPassword")} /></div>
              <div className="flex items-start gap-2">
                <Checkbox id="fm-terms" checked={accepted} onCheckedChange={(v) => setAccepted(!!v)} disabled={!terms} />
                <Label htmlFor="fm-terms" className="text-sm font-normal leading-snug">
                  {t.terms}{" "}
                  <button type="button" className="underline" onClick={() => setShowTerms((s) => !s)}>{t.readTerms}</button>
                </Label>
              </div>
              {showTerms && terms && (
                <ScrollArea className="h-48 rounded-md border p-3">
                  <div className="whitespace-pre-line text-xs">{terms.content.replace(/<[^>]+>/g, "\n").replace(/\n{2,}/g, "\n")}</div>
                </ScrollArea>
              )}
            </>
          )}
          {mode === "verify" && (
            <div><Label htmlFor="fm-code">{t.code}</Label><Input id="fm-code" inputMode="numeric" required maxLength={10} value={f.code} onChange={set("code")} /></div>
          )}
          <Button type="submit" className="w-full" disabled={busy || (mode === "register" && !accepted)}>
            {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}{t.submit}
          </Button>
          {mode !== "verify" && (
            <button type="button" className="w-full text-center text-sm text-muted-foreground underline"
              onClick={() => setMode(mode === "login" ? "register" : "login")}>
              {mode === "login" ? t.noAcc : t.haveAcc}
            </button>
          )}
        </form>
      </DialogContent>
    </Dialog>
  );
}
