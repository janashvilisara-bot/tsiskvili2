import { useEffect, useState } from "react";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Clock,
  ExternalLink,
  Search,
  Wifi,
  GraduationCap,
  Loader2,
  Tag,
  CheckCircle2,
  UserPlus,
  Gift,
  CreditCard,
  Phone,
  Mail,
  User,
  IdCard,
  Minus,
  Plus,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const enrollmentSchema = z.object({
  fullName: z.string().trim().min(2, "სახელი მინიმუმ 2 სიმბოლო").max(100),
  email: z.string().trim().email("არასწორი ელფოსტა").max(255),
  phone: z.string().trim().min(9, "ტელეფონი მინიმუმ 9 ციფრი").max(20),
  personalId: z
    .string()
    .trim()
    .regex(/^\d{11}$/, "პირადი ნომერი უნდა იყოს 11 ციფრი"),
  giftRecipientName: z.string().trim().max(100).optional(),
  promoCode: z.string().trim().max(50).optional(),
  notes: z.string().trim().max(500).optional(),
});

interface SmartCourse {
  id: number;
  title: string;
  slug: string;
  description: string;
  crop: string;
  poster: string;
  duration: string;
  price: {
    original: number;
    sale: number | null;
    final: number;
    currency: string;
    formatted: string;
  };
  online: boolean;
  link: string;
}

// Beautiful gradient placeholder based on course id
function CoursePlaceholder({ title }: { title: string }) {
  const gradients = [
    "from-indigo-500 via-purple-500 to-pink-500",
    "from-blue-500 via-cyan-500 to-teal-500",
    "from-orange-500 via-rose-500 to-fuchsia-500",
    "from-emerald-500 via-teal-500 to-cyan-500",
    "from-amber-500 via-orange-500 to-red-500",
    "from-violet-500 via-indigo-500 to-blue-500",
  ];
  const idx = title.length % gradients.length;
  return (
    <div
      className={`w-full h-full bg-gradient-to-br ${gradients[idx]} flex items-center justify-center relative overflow-hidden`}
    >
      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_30%_20%,white,transparent_60%)]" />
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_70%_80%,white,transparent_50%)]" />
      <GraduationCap className="h-20 w-20 text-white/90 drop-shadow-lg relative z-10" />
    </div>
  );
}

function CourseImage({
  course,
  preferPoster = false,
}: {
  course: SmartCourse;
  preferPoster?: boolean;
}) {
  const primary = preferPoster ? course.poster : course.crop;
  const secondary = preferPoster ? course.crop : course.poster;
  const [src, setSrc] = useState<string | null>(primary || secondary || null);
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return <CoursePlaceholder title={course.title} />;
  }

  return (
    <img
      src={src}
      alt={course.title}
      loading="lazy"
      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
      onError={() => {
        if (src === primary && secondary) {
          setSrc(secondary);
        } else {
          setFailed(true);
        }
      }}
    />
  );
}

export function SmartAcademyCourses() {
  const [courses, setCourses] = useState<SmartCourse[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<SmartCourse | null>(null);

  // Enrollment dialog state
  const [enrollOpen, setEnrollOpen] = useState(false);
  const [enrolling, setEnrolling] = useState(false);
  const [enrolledIds, setEnrolledIds] = useState<Set<number>>(new Set());

  // Form fields
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [personalId, setPersonalId] = useState("");
  const [paymentType, setPaymentType] = useState("full"); // full | installment
  const [cardType, setCardType] = useState("visa_mc_amex"); // visa_mc_amex | tbc_loyalty
  const [isGift, setIsGift] = useState(false);
  const [giftRecipientName, setGiftRecipientName] = useState("");
  const [promoCode, setPromoCode] = useState("");
  const [wantsConsultation, setWantsConsultation] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(true);
  const [notes, setNotes] = useState("");
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const load = async () => {
      try {
        const { data, error: fnError } = await supabase.functions.invoke(
          "smart-academy-proxy",
          { method: "GET" }
        );
        if (fnError) throw fnError;
        if (data?.success && Array.isArray(data.courses)) {
          setCourses(data.courses);
        } else {
          setError("მონაცემების ჩატვირთვა ვერ მოხერხდა");
        }
      } catch (e) {
        setError("ქსელის შეცდომა");
      } finally {
        setLoading(false);
      }
    };
    load();
    loadMyEnrollments();
  }, []);

  const loadMyEnrollments = async () => {
    const { data } = await supabase
      .from("smart_academy_enrollments")
      .select("external_course_id");
    if (data) {
      setEnrolledIds(new Set(data.map((d: any) => d.external_course_id)));
    }
  };

  const openEnrollment = () => {
    // Reset fields so user fills them manually
    setFullName("");
    setEmail("");
    setPhone("");
    setPersonalId("");
    setQuantity(1);
    setEnrollOpen(true);
  };

  const handleEnroll = async () => {
    if (!selected) return;

    // Validate
    const result = enrollmentSchema.safeParse({
      fullName,
      email,
      phone,
      personalId,
      giftRecipientName: isGift ? giftRecipientName : undefined,
      promoCode: promoCode || undefined,
      notes: notes || undefined,
    });

    if (!result.success) {
      const firstError = result.error.errors[0];
      toast.error(firstError.message);
      return;
    }

    if (!termsAccepted) {
      toast.error("გთხოვთ დაეთანხმოთ წესებსა და პირობებს");
      return;
    }

    setEnrolling(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        toast.error("გთხოვთ გაიაროთ ავტორიზაცია");
        return;
      }

      const { data: emp } = await supabase
        .from("employees")
        .select("id")
        .eq("user_id", user.id)
        .maybeSingle();

      const { error: insErr } = await supabase
        .from("smart_academy_enrollments")
        .insert({
          user_id: user.id,
          employee_id: emp?.id ?? null,
          external_course_id: selected.id,
          course_title: selected.title,
          course_link: selected.link,
          course_price: selected.price.final,
          course_duration: selected.duration,
          is_online: selected.online,
          full_name: fullName.trim(),
          email: email.trim(),
          phone: phone.trim(),
          personal_id: personalId.trim(),
          payment_type: paymentType,
          card_type: cardType,
          is_gift: isGift,
          gift_recipient_name: isGift ? giftRecipientName.trim() || null : null,
          promo_code: promoCode.trim() || null,
          wants_consultation: wantsConsultation,
          terms_accepted: termsAccepted,
          notes: notes.trim() || null,
          quantity: quantity,
        });

      if (insErr) throw insErr;

      // Send filled application data to Smart Academy via Lovable Emails (best-effort)
      const totalPrice = selected.price.final * quantity;
      try {
        await supabase.functions.invoke("send-academy-enrollment-email", {
          body: {
            enrollment: {
              fullName: fullName.trim(),
              email: email.trim(),
              phone: phone.trim(),
              personalId: personalId.trim(),
              courseTitle: selected.title,
              courseId: selected.id,
              courseFormat: selected.online ? "ონლაინ" : "დასწრებითი",
              courseDuration: selected.duration,
              unitPrice: selected.price.formatted,
              quantity,
              totalPrice: totalPrice.toLocaleString("ka-GE"),
              paymentType,
              cardType: cardType || undefined,
              isGift,
              giftRecipientName: isGift ? giftRecipientName.trim() : undefined,
              promoCode: promoCode.trim() || undefined,
              wantsConsultation,
              notes: notes.trim() || undefined,
              courseLink: selected.link,
            },
          },
        });
      } catch (emailErr) {
        console.error("Email notification failed", emailErr);
      }

      toast.success("განაცხადი გაიგზავნა! გადამისამართება გადახდაზე...");
      setEnrolledIds(new Set([...enrolledIds, selected.id]));
      setEnrollOpen(false);
      // Reset form
      setPromoCode("");
      setNotes("");
      setIsGift(false);
      setGiftRecipientName("");
      setWantsConsultation(false);
      setTermsAccepted(true);
      setQuantity(1);

      // Redirect to BOG payment page
      const paymentUrl =
        "https://payment.bog.ge/?order_id=17fdddfb-4594-44e9-b09e-7ecd7022be98&theme=light#reg";
      setTimeout(() => {
        window.open(paymentUrl, "_blank", "noopener,noreferrer");
      }, 600);
    } catch (e: any) {
      toast.error("განაცხადის გაგზავნა ვერ მოხერხდა");
    } finally {
      setEnrolling(false);
    }
  };

  const filtered = courses.filter((c) =>
    c.title.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <Card className="p-12 text-center text-muted-foreground">{error}</Card>
    );
  }

  const isEnrolled = selected ? enrolledIds.has(selected.id) : false;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg">
            <GraduationCap className="h-6 w-6 text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Smart Academy</h2>
            <p className="text-sm text-muted-foreground">
              გარე ტრენინგ-კურსები პარტნიორი აკადემიიდან
            </p>
          </div>
        </div>
        <div className="relative w-full md:w-72">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="კურსის ძიება..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <Card className="p-12 text-center text-muted-foreground">
          კურსები ვერ მოიძებნა
        </Card>
      ) : (
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((course) => {
            const enrolled = enrolledIds.has(course.id);
            return (
              <Card
                key={course.id}
                onClick={() => setSelected(course)}
                className="group overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col cursor-pointer"
              >
                <div className="relative aspect-video overflow-hidden bg-muted">
                  <CourseImage course={course} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
                  <div className="absolute top-3 left-3 flex gap-2">
                    {course.online && (
                      <Badge className="bg-emerald-500/90 hover:bg-emerald-500 text-white border-0 backdrop-blur-sm">
                        <Wifi className="h-3 w-3 mr-1" />
                        ონლაინ
                      </Badge>
                    )}
                    {enrolled && (
                      <Badge className="bg-blue-500/90 text-white border-0 backdrop-blur-sm">
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        განაცხადი გაგზავნილი
                      </Badge>
                    )}
                  </div>
                  <div className="absolute bottom-3 right-3">
                    <Badge variant="secondary" className="backdrop-blur-sm bg-background/80">
                      <Clock className="h-3 w-3 mr-1" />
                      {course.duration} სთ
                    </Badge>
                  </div>
                </div>

                <CardContent className="p-5 flex flex-col flex-1 gap-3">
                  <h3 className="font-semibold text-base line-clamp-2 min-h-[3rem]">
                    {course.title}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-3 flex-1">
                    {course.description}
                  </p>

                  <div className="flex items-center justify-between pt-3 border-t">
                    <div className="flex flex-col">
                      <span className="text-xs text-muted-foreground">ფასი</span>
                      <div className="flex items-baseline gap-2">
                        <span className="text-lg font-bold text-primary">
                          {course.price.formatted}
                        </span>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelected(course);
                      }}
                    >
                      დეტალები
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Course details dialog */}
      <Dialog
        open={!!selected && !enrollOpen}
        onOpenChange={(open) => !open && setSelected(null)}
      >
        <DialogContent className="max-w-3xl p-0 overflow-hidden max-h-[90vh] flex flex-col">
          {selected && (
            <>
              <div className="relative aspect-video w-full overflow-hidden bg-muted shrink-0">
                <CourseImage course={selected} preferPoster />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent pointer-events-none" />
                <div className="absolute top-4 left-4 flex gap-2">
                  {selected.online && (
                    <Badge className="bg-emerald-500/90 text-white border-0 backdrop-blur-sm">
                      <Wifi className="h-3 w-3 mr-1" />
                      ონლაინ
                    </Badge>
                  )}
                  <Badge variant="secondary" className="backdrop-blur-sm bg-background/80">
                    <Clock className="h-3 w-3 mr-1" />
                    {selected.duration} სთ
                  </Badge>
                </div>
              </div>

              <ScrollArea className="flex-1">
                <div className="p-6 space-y-4">
                  <DialogHeader className="text-left">
                    <DialogTitle className="text-2xl">{selected.title}</DialogTitle>
                    <DialogDescription className="flex items-center gap-2 text-xs">
                      <Tag className="h-3 w-3" />
                      Smart Academy · კურსი #{selected.id}
                    </DialogDescription>
                  </DialogHeader>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="rounded-lg border p-3">
                      <div className="text-xs text-muted-foreground">ხანგრძლივობა</div>
                      <div className="text-lg font-bold">{selected.duration} სთ</div>
                    </div>
                    <div className="rounded-lg border p-3">
                      <div className="text-xs text-muted-foreground">ფორმატი</div>
                      <div className="text-lg font-bold">
                        {selected.online ? "ონლაინ" : "დასწრებითი"}
                      </div>
                    </div>
                    <div className="rounded-lg border p-3 bg-primary/5">
                      <div className="text-xs text-muted-foreground">ფასი</div>
                      <div className="text-lg font-bold text-primary">
                        {selected.price.formatted}
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold mb-2">აღწერა</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
                      {selected.description}
                    </p>
                  </div>
                </div>
              </ScrollArea>

              <DialogFooter className="px-6 py-4 border-t bg-muted/30 shrink-0 gap-2 sm:gap-2">
                <Button variant="outline" onClick={() => setSelected(null)}>
                  დახურვა
                </Button>
                <Button
                  variant="outline"
                  onClick={() =>
                    window.open(selected.link, "_blank", "noopener,noreferrer")
                  }
                  className="gap-2"
                >
                  ვებგვერდზე ნახვა
                  <ExternalLink className="h-4 w-4" />
                </Button>
                <Button
                  onClick={openEnrollment}
                  disabled={isEnrolled}
                  className="gap-2"
                >
                  {isEnrolled ? (
                    <>
                      <CheckCircle2 className="h-4 w-4" />
                      უკვე გაგზავნილია
                    </>
                  ) : (
                    <>
                      <UserPlus className="h-4 w-4" />
                      რეგისტრაცია
                    </>
                  )}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Enrollment form dialog */}
      <Dialog open={enrollOpen} onOpenChange={setEnrollOpen}>
        <DialogContent className="max-w-2xl p-0 max-h-[92vh] flex flex-col overflow-hidden">
          <DialogHeader className="px-6 pt-6 pb-2 shrink-0">
            <DialogTitle className="flex items-center gap-2 text-xl">
              <UserPlus className="h-5 w-5 text-primary" />
              კურსზე რეგისტრაცია
            </DialogTitle>
            <DialogDescription className="text-left">
              {selected?.title}
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto px-6">
            <div className="space-y-5 py-3">
              {/* Course summary */}
              <div className="rounded-xl border bg-gradient-to-br from-primary/5 to-accent/5 p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <GraduationCap className="h-4 w-4 text-primary" />
                    <span className="text-xs font-medium text-muted-foreground">
                      Smart Academy · #{selected?.id}
                    </span>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {selected?.online ? "ონლაინ" : "დასწრებითი"}
                  </Badge>
                </div>
                <h4 className="font-semibold mb-3">{selected?.title}</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                    <span>{selected?.duration} სთ</span>
                  </div>
                  <div className="text-right font-bold text-primary text-base">
                    {selected?.price.formatted}
                  </div>
                </div>

                {/* Quantity selector */}
                <div className="mt-4 pt-4 border-t border-border/50 flex items-center justify-between">
                  <Label className="text-xs font-medium">რაოდენობა</Label>
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      disabled={quantity <= 1}
                    >
                      <Minus className="h-3.5 w-3.5" />
                    </Button>
                    <Input
                      type="number"
                      min={1}
                      max={50}
                      value={quantity}
                      onChange={(e) => {
                        const v = parseInt(e.target.value, 10);
                        if (!isNaN(v)) setQuantity(Math.max(1, Math.min(50, v)));
                      }}
                      className="h-8 w-16 text-center"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setQuantity((q) => Math.min(50, q + 1))}
                      disabled={quantity >= 50}
                    >
                      <Plus className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
                {quantity > 1 && selected && (
                  <div className="mt-2 flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">ჯამი:</span>
                    <span className="font-bold text-primary">
                      {(selected.price.final * quantity).toLocaleString("ka-GE")} ₾
                    </span>
                  </div>
                )}
              </div>

              {/* Personal data */}
              <div className="space-y-3">
                <h4 className="text-sm font-semibold flex items-center gap-2">
                  <User className="h-4 w-4" />
                  პერსონალური მონაცემები
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="fullName" className="text-xs">
                      სახელი, გვარი *
                    </Label>
                    <Input
                      id="fullName"
                      placeholder="გიორგი გიორგაძე"
                      value={fullName}
                      maxLength={100}
                      onChange={(e) => setFullName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="email" className="text-xs flex items-center gap-1">
                      <Mail className="h-3 w-3" /> ელ. ფოსტა *
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="example@mail.com"
                      value={email}
                      maxLength={255}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="phone" className="text-xs flex items-center gap-1">
                      <Phone className="h-3 w-3" /> ტელეფონი *
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+995 5XX XX XX XX"
                      value={phone}
                      maxLength={20}
                      onChange={(e) => setPhone(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="personalId" className="text-xs flex items-center gap-1">
                      <IdCard className="h-3 w-3" /> პირადი ნომერი *
                    </Label>
                    <Input
                      id="personalId"
                      placeholder="01001001001"
                      value={personalId}
                      maxLength={11}
                      inputMode="numeric"
                      onChange={(e) =>
                        setPersonalId(e.target.value.replace(/\D/g, ""))
                      }
                    />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Gift option */}
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <Checkbox
                    id="isGift"
                    checked={isGift}
                    onCheckedChange={(c) => setIsGift(c === true)}
                  />
                  <div className="grid gap-1 leading-none">
                    <Label
                      htmlFor="isGift"
                      className="text-sm font-medium flex items-center gap-1.5 cursor-pointer"
                    >
                      <Gift className="h-4 w-4 text-pink-500" />
                      კურსის ჩუქება
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      ვისთვისაც იძენთ კურსს
                    </p>
                  </div>
                </div>
                {isGift && (
                  <div className="space-y-1.5 pl-6">
                    <Label htmlFor="giftRecipient" className="text-xs">
                      მიმღების სახელი
                    </Label>
                    <Input
                      id="giftRecipient"
                      placeholder="სახელი, გვარი"
                      value={giftRecipientName}
                      maxLength={100}
                      onChange={(e) => setGiftRecipientName(e.target.value)}
                    />
                  </div>
                )}
              </div>

              <Separator />

              {/* Promo code */}
              <div className="space-y-1.5">
                <Label htmlFor="promo" className="text-xs">
                  პრომოკოდი (არასავალდებულო)
                </Label>
                <Input
                  id="promo"
                  placeholder="შეიყვანეთ პრომოკოდი"
                  value={promoCode}
                  maxLength={50}
                  onChange={(e) => setPromoCode(e.target.value)}
                />
              </div>

              <Separator />

              {/* Payment type */}
              <div className="space-y-3">
                <h4 className="text-sm font-semibold flex items-center gap-2">
                  <CreditCard className="h-4 w-4" />
                  გადახდის მეთოდი
                </h4>
                <RadioGroup value={paymentType} onValueChange={setPaymentType}>
                  <div className="grid grid-cols-2 gap-2">
                    <Label
                      htmlFor="pay-full"
                      className={`flex items-center gap-2 rounded-lg border p-3 cursor-pointer transition-colors ${
                        paymentType === "full"
                          ? "border-primary bg-primary/5"
                          : "hover:bg-muted/50"
                      }`}
                    >
                      <RadioGroupItem value="full" id="pay-full" />
                      <span className="text-sm">გადახდა</span>
                    </Label>
                    <Label
                      htmlFor="pay-installment"
                      className={`flex items-center gap-2 rounded-lg border p-3 cursor-pointer transition-colors ${
                        paymentType === "installment"
                          ? "border-primary bg-primary/5"
                          : "hover:bg-muted/50"
                      }`}
                    >
                      <RadioGroupItem value="installment" id="pay-installment" />
                      <span className="text-sm">განვადება</span>
                    </Label>
                  </div>
                </RadioGroup>

                <RadioGroup value={cardType} onValueChange={setCardType}>
                  <div className="space-y-2">
                    <Label
                      htmlFor="card-visa"
                      className="flex items-start gap-2 rounded-lg border p-3 cursor-pointer hover:bg-muted/50"
                    >
                      <RadioGroupItem value="visa_mc_amex" id="card-visa" className="mt-0.5" />
                      <div className="flex-1">
                        <div className="text-sm font-medium">
                          Visa, MC, Amex
                        </div>
                        <div className="text-xs text-muted-foreground">
                          ქართული და უცხოური ბარათები
                        </div>
                      </div>
                    </Label>
                    <Label
                      htmlFor="card-tbc"
                      className="flex items-start gap-2 rounded-lg border p-3 cursor-pointer hover:bg-muted/50"
                    >
                      <RadioGroupItem value="tbc_loyalty" id="card-tbc" className="mt-0.5" />
                      <div className="flex-1">
                        <div className="text-sm font-medium">
                          Visa, MC, TBC ერთგული ქულები
                        </div>
                      </div>
                    </Label>
                  </div>
                </RadioGroup>

                <div className="flex items-start gap-2">
                  <Checkbox
                    id="consultation"
                    checked={wantsConsultation}
                    onCheckedChange={(c) => setWantsConsultation(c === true)}
                  />
                  <Label
                    htmlFor="consultation"
                    className="text-sm cursor-pointer leading-none pt-0.5"
                  >
                    უფასო კონსულტაციაზე ჩაწერა
                  </Label>
                </div>
              </div>

              <Separator />

              {/* Notes */}
              <div className="space-y-1.5">
                <Label htmlFor="notes" className="text-xs">
                  დამატებითი კომენტარი (არასავალდებულო)
                </Label>
                <Textarea
                  id="notes"
                  placeholder="რატომ გსურთ ამ კურსის გავლა?"
                  value={notes}
                  maxLength={500}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                />
              </div>

              {/* Terms */}
              <div className="flex items-start gap-2 rounded-lg border bg-muted/30 p-3">
                <Checkbox
                  id="terms"
                  checked={termsAccepted}
                  onCheckedChange={(c) => setTermsAccepted(c === true)}
                  className="mt-0.5"
                />
                <Label
                  htmlFor="terms"
                  className="text-xs cursor-pointer leading-relaxed"
                >
                  ვეთანხმები{" "}
                  <span className="text-primary font-medium">წესებსა და პირობებს</span>
                  , თანახმა ვარ მივიღო SMS და ელ. ფოსტის სარეკლამო შეტყობინებები
                </Label>
              </div>
            </div>
          </div>

          <DialogFooter className="px-6 py-4 border-t bg-muted/30 shrink-0 gap-2">
            <Button
              variant="outline"
              onClick={() => setEnrollOpen(false)}
              disabled={enrolling}
            >
              გაუქმება
            </Button>
            <Button onClick={handleEnroll} disabled={enrolling} className="gap-2">
              {enrolling && <Loader2 className="h-4 w-4 animate-spin" />}
              <UserPlus className="h-4 w-4" />
              რეგისტრაცია
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
