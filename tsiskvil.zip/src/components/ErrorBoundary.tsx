import React, { Component, ErrorInfo, ReactNode } from "react";
import { AlertTriangle, RefreshCw, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getErrorBoundaryMessage } from "@/lib/errorHandler";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // ლოგირება მხოლოდ development-ში
    if (process.env.NODE_ENV === 'development') {
      console.error("ErrorBoundary caught an error:", error, errorInfo);
    }
    this.setState({
      error,
      errorInfo,
    });
  }

  private handleReset = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
    });
    window.location.href = "/";
  };

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      const errorMessage = this.state.error 
        ? getErrorBoundaryMessage(this.state.error)
        : { title: 'რაღაც შეცდომა მოხდა', description: 'გთხოვთ განაახლოთ გვერდი', showDetails: false };

      return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-background">
          <Card className="max-w-lg w-full shadow-glow">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mb-4">
                <AlertTriangle className="h-8 w-8 text-destructive" />
              </div>
              <CardTitle className="text-2xl">{errorMessage.title}</CardTitle>
              <CardDescription>
                {errorMessage.description}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* ტექნიკური დეტალები აღარ ჩანს მომხმარებელს */}
              <p className="text-center text-sm text-muted-foreground">
                ერორის კოდი: #{Date.now().toString(36).toUpperCase()}
              </p>
              
              <div className="flex gap-3 justify-center">
                <Button onClick={this.handleReset} variant="default" className="gap-2">
                  <Home className="h-4 w-4" />
                  მთავარ გვერდზე
                </Button>
                <Button onClick={this.handleReload} variant="outline" className="gap-2">
                  <RefreshCw className="h-4 w-4" />
                  განახლება
                </Button>
              </div>

              {/* Development-ში მხოლოდ */}
              {errorMessage.showDetails && this.state.error && (
                <details className="mt-4 p-4 bg-muted rounded-lg">
                  <summary className="cursor-pointer text-sm font-semibold mb-2 text-destructive">
                    🔧 დეველოპერისთვის (Production-ში არ ჩანს)
                  </summary>
                  <div className="space-y-2">
                    <p className="text-xs font-mono text-muted-foreground break-all">
                      {this.state.error.toString()}
                    </p>
                    {this.state.errorInfo && (
                      <pre className="text-xs overflow-auto max-h-48 text-muted-foreground">
                        {this.state.errorInfo.componentStack}
                      </pre>
                    )}
                  </div>
                </details>
              )}
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
