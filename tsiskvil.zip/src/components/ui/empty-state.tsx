import { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  actionLabel,
  onAction,
  className = "",
}: EmptyStateProps) {
  return (
    <Card className={cn(
      "flex flex-col items-center justify-center p-12 text-center gradient-card border-2",
      "animate-fade-in hover:shadow-2xl transition-all duration-500",
      className
    )}>
      <div className="rounded-full bg-gradient-to-br from-primary/15 to-accent/15 p-8 mb-8 shadow-lg hover:shadow-glow-lg transition-all duration-500 hover:scale-110 animate-bounce-in backdrop-blur-sm">
        <Icon className="h-16 w-16 text-primary animate-float" />
      </div>
      <h3 className="text-2xl font-bold mb-3 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-slide-up">
        {title}
      </h3>
      <p className="text-muted-foreground max-w-md mb-8 leading-relaxed animate-slide-up animation-delay-200">
        {description}
      </p>
      {actionLabel && onAction && (
        <Button 
          onClick={onAction} 
          variant="gradient" 
          size="lg" 
          className="animate-scale-in animation-delay-400"
        >
          {actionLabel}
        </Button>
      )}
    </Card>
  );
}
