import { useLocation, Link } from "react-router-dom";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Home } from "lucide-react";
import { routeLabel } from "@/lib/routeLabels";
import { useLanguage } from "@/contexts/LanguageContext";
import { allSearchItems } from "@/lib/searchData";


export function DynamicBreadcrumb() {
  const location = useLocation();
  const { language } = useLanguage();
  const lang = language === "en" ? "en" : "ka";
  const pathnames = location.pathname.split("/").filter((x) => x);

  if (
    location.pathname === "/auth" ||
    location.pathname.startsWith("/presentation")
  ) {
    return null;
  }

  return (
    <Breadcrumb className="min-w-0">
      <BreadcrumbList className="flex-nowrap min-w-0">
        <BreadcrumbItem className="inline-flex">
          <BreadcrumbLink asChild>
            <Link to="/" className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors">
              <Home className="h-3.5 w-3.5" />
              <span className="text-sm hidden sm:inline">{routeLabel("/", lang)}</span>
            </Link>
          </BreadcrumbLink>
        </BreadcrumbItem>

        {pathnames.map((pathname, index) => {
          const routeTo = `/${pathnames.slice(0, index + 1).join("/")}`;
          const isLast = index === pathnames.length - 1;
          const displayName = routeLabel(routeTo, lang) || (lang === "ka" ? allSearchItems.find(i => i.url === routeTo)?.name : undefined) || pathname.replace(/-/g, " ").replace(/^./, c => c.toUpperCase());

          return (
            <div key={routeTo} className="flex items-center gap-2 min-w-0">
              <BreadcrumbSeparator className="text-muted-foreground/40 block" />
              <BreadcrumbItem className="min-w-0">
                {isLast ? (
                  <BreadcrumbPage className="text-foreground font-medium text-sm truncate block">{displayName}</BreadcrumbPage>
                ) : (
                  <BreadcrumbLink asChild>
                    <Link to={routeTo} className="text-muted-foreground hover:text-foreground transition-colors text-sm">{displayName}</Link>
                  </BreadcrumbLink>
                )}
              </BreadcrumbItem>
            </div>
          );
        })}
      </BreadcrumbList>
    </Breadcrumb>
  );
}
