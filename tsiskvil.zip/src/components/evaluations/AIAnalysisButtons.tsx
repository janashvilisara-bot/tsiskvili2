import { useState } from "react";
import { Brain, AlertTriangle, Shield, TrendingDown, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface RiskFactor {
  factor: string;
  impact: string;
  description: string;
}

interface Recommendation {
  title: string;
  description: string;
  priority: string;
}

interface RiskAssessment {
  risk_score: number;
  risk_level: string;
  risk_factors: RiskFactor[];
  recommendations: Recommendation[];
}

export function RiskPredictionButton({ employeeId, employeeName }: { employeeId: string; employeeName: string }) {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<RiskAssessment | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const handleAnalyze = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("employee-risk-prediction", {
        body: { employee_id: employeeId },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setResult({
        risk_score: data.risk_score,
        risk_level: data.risk_level,
        risk_factors: data.risk_factors || [],
        recommendations: data.recommendations || [],
      });
    } catch (error: any) {
      toast.error(error.message || "რისკის ანალიზი ვერ მოხერხდა");
    } finally {
      setIsLoading(false);
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case "low": return "text-green-600";
      case "medium": return "text-yellow-600";
      case "high": return "text-orange-600";
      case "critical": return "text-red-600";
      default: return "text-muted-foreground";
    }
  };

  const getRiskBadgeVariant = (level: string) => {
    switch (level) {
      case "low": return "default" as const;
      case "medium": return "secondary" as const;
      case "high": return "destructive" as const;
      case "critical": return "destructive" as const;
      default: return "outline" as const;
    }
  };

  const getRiskLabel = (level: string) => {
    switch (level) {
      case "low": return "დაბალი";
      case "medium": return "საშუალო";
      case "high": return "მაღალი";
      case "critical": return "კრიტიკული";
      default: return level;
    }
  };

  const getImpactLabel = (impact: string) => {
    switch (impact) {
      case "low": return "დაბალი";
      case "medium": return "საშუალო";
      case "high": return "მაღალი";
      default: return impact;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2" onClick={() => { if (!result) handleAnalyze(); }}>
          <AlertTriangle className="h-4 w-4" />
          რისკის ანალიზი
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            რისკის ანალიზი - {employeeName}
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-3 text-muted-foreground">AI ანალიზი მიმდინარეობს...</span>
          </div>
        ) : result ? (
          <div className="space-y-6">
            {/* Score */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-muted-foreground">რისკის ქულა</p>
                    <p className={`text-4xl font-bold ${getRiskColor(result.risk_level)}`}>
                      {result.risk_score}/100
                    </p>
                  </div>
                  <Badge variant={getRiskBadgeVariant(result.risk_level)} className="text-base px-4 py-1">
                    {getRiskLabel(result.risk_level)}
                  </Badge>
                </div>
                <Progress value={result.risk_score} className="h-3" />
              </CardContent>
            </Card>

            {/* Factors */}
            {result.risk_factors.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <TrendingDown className="h-5 w-5" />
                    რისკის ფაქტორები
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {result.risk_factors.map((f, i) => (
                      <div key={i} className="border rounded-lg p-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">{f.factor}</span>
                          <Badge variant="outline">{getImpactLabel(f.impact)}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{f.description}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Recommendations */}
            {result.recommendations.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    რეკომენდაციები
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {result.recommendations.map((r, i) => (
                      <div key={i} className="border rounded-lg p-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">{r.title}</span>
                          <Badge variant={r.priority === "high" ? "destructive" : "secondary"}>
                            {getImpactLabel(r.priority)}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{r.description}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            <Button variant="outline" className="w-full" onClick={handleAnalyze} disabled={isLoading}>
              ხელახლა ანალიზი
            </Button>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

interface PerformanceAnalysis {
  overall_assessment: string;
  trend: string;
  strengths: { area: string; description: string }[];
  weaknesses: { area: string; description: string; suggestion: string }[];
  development_plan: { goal: string; timeline: string; actions: string }[];
}

export function PerformanceAIButton({ employeeId, employeeName }: { employeeId: string; employeeName: string }) {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<PerformanceAnalysis | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const handleAnalyze = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-performance-review", {
        body: { employee_id: employeeId },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setResult(data);
    } catch (error: any) {
      toast.error(error.message || "AI ანალიზი ვერ მოხერხდა");
    } finally {
      setIsLoading(false);
    }
  };

  const getTrendLabel = (trend: string) => {
    switch (trend) {
      case "improving": return "📈 გაუმჯობესება";
      case "stable": return "📊 სტაბილური";
      case "declining": return "📉 კლება";
      default: return trend;
    }
  };

  const getTrendVariant = (trend: string) => {
    switch (trend) {
      case "improving": return "default" as const;
      case "stable": return "secondary" as const;
      case "declining": return "destructive" as const;
      default: return "outline" as const;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2" onClick={() => { if (!result) handleAnalyze(); }}>
          <Brain className="h-4 w-4" />
          AI ანალიზი
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AI ეფექტურობის ანალიზი - {employeeName}
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-3 text-muted-foreground">AI ანალიზი მიმდინარეობს...</span>
          </div>
        ) : result ? (
          <div className="space-y-6">
            {/* Overall */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">ზოგადი შეფასება</CardTitle>
                  <Badge variant={getTrendVariant(result.trend)}>{getTrendLabel(result.trend)}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{result.overall_assessment}</p>
              </CardContent>
            </Card>

            {/* Strengths */}
            {result.strengths.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg text-green-600">💪 ძლიერი მხარეები</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {result.strengths.map((s, i) => (
                      <div key={i} className="border-l-4 border-green-500 pl-3">
                        <p className="font-medium">{s.area}</p>
                        <p className="text-sm text-muted-foreground">{s.description}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Weaknesses */}
            {result.weaknesses.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg text-orange-600">⚡ გასაუმჯობესებელი მხარეები</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {result.weaknesses.map((w, i) => (
                      <div key={i} className="border-l-4 border-orange-500 pl-3">
                        <p className="font-medium">{w.area}</p>
                        <p className="text-sm text-muted-foreground">{w.description}</p>
                        <p className="text-sm text-primary mt-1">{w.suggestion}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Development Plan */}
            {result.development_plan.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">🎯 განვითარების გეგმა</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {result.development_plan.map((d, i) => (
                      <div key={i} className="border rounded-lg p-3">
                        <p className="font-medium">{d.goal}</p>
                        <p className="text-xs text-muted-foreground mt-1">⏰ {d.timeline}</p>
                        <p className="text-sm mt-2">{d.actions}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            <Button variant="outline" className="w-full" onClick={handleAnalyze} disabled={isLoading}>
              ხელახლა ანალიზი
            </Button>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
