import { useEffect, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { z } from 'zod';
import { toast } from 'sonner';
import { Sparkles, CloudSun, CloudRain, Cloud, Sun, Snowflake, Quote, Lock, FileText, Cookie } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

import { ThemeToggle } from '@/components/ThemeToggle';
import techflowLogo from '@/assets/techflow-logo.png';

const MOTIVATIONAL_QUOTES = [
  { text: "წარმატება არის უნარი, წარუმატებლობიდან წარუმატებლობამდე იარო ენთუზიაზმის დაკარგვის გარეშე.", author: "უინსტონ ჩერჩილი" },
  { text: "მომავალი ეკუთვნის მათ, ვინც საკუთარ ოცნებებში იჯერებს.", author: "ელეანორ რუზველტი" },
  { text: "ერთადერთი გზა შესანიშნავი სამუშაოს შესასრულებლად არის ის, რომ გიყვარდეს ის რასაც აკეთებ.", author: "სტივ ჯობსი" },
  { text: "არასდროს არ არის გვიან იმისთვის, რომ იყო ის, ვინც შეიძლებოდა ყოფილიყავი.", author: "ჯორჯ ელიოტი" },
  { text: "დიდი საქმეები არასდროს კეთდება კომფორტის ზონაში.", author: "ბენ ფრანკლინი" },
  { text: "ყოველი დილა ახალი შესაძლებლობაა. გამოიყენე სრულად!", author: "უცნობი" },
  { text: "წარმატება არ არის საბოლოო, წარუმატებლობა არ არის ფატალური: მთავარია გაგრძელების გამბედაობა.", author: "უინსტონ ჩერჩილი" },
  { text: "შენი დრო შეზღუდულია, ნუ ხარჯავ მას სხვისი ცხოვრებით ცხოვრებაზე.", author: "სტივ ჯობსი" },
  { text: "რაც არ გკლავს, ის გაძლიერებს.", author: "ფრიდრიხ ნიცშე" },
  { text: "იყავი ცვლილება, რომლის ნახვაც გინდა ამ სამყაროში.", author: "მაჰათმა განდი" },
];

const signInSchema = z.object({
  email: z.string().email({ message: 'არასწორი ელ.ფოსტა' }),
  password: z.string().min(1, { message: 'შეიყვანეთ პაროლი' }),
});

const signUpSchema = z.object({
  email: z.string().email({ message: 'არასწორი ელ.ფოსტა' }),
  password: z.string().min(8, { message: 'პაროლი მინიმუმ 8 სიმბოლო' }),
  confirmPassword: z.string().min(1, { message: 'გაიმეორეთ პაროლი' }),
  fullName: z.string().min(2, { message: 'შეიყვანეთ სრული სახელი' }),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'პაროლები არ ემთხვევა',
  path: ['confirmPassword'],
});

export default function Auth() {
  const { signIn, signUp, user, loading } = useAuth();
  const navigate = useNavigate();
  const nextParam = new URLSearchParams(window.location.search).get('next');
  const safeNext = nextParam && nextParam.startsWith('/') && !nextParam.startsWith('//') ? nextParam : null;
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [forgotPasswordOpen, setForgotPasswordOpen] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [cookiesAccepted, setCookiesAccepted] = useState(false);

  // Redirect if already logged in
  useEffect(() => {
    if (!loading && user) {
      if (safeNext) { window.location.href = safeNext; return; }
      navigate('/', { replace: true });
    }
  }, [user, loading, navigate]);

  // Fresh installation (no administrator yet) -> first-run setup wizard
  useEffect(() => {
    let active = true;
    if (loading || user) return;
    (async () => {
      const { data, error } = await supabase.rpc('has_any_admin');
      if (!active || error) return;
      if (data !== true) navigate('/setup', { replace: true });
    })();
    return () => { active = false; };
  }, [user, loading, navigate]);

  const [weather, setWeather] = useState<{ temp: number; description: string; icon: string } | null>(null);
  const [slideIndex, setSlideIndex] = useState(0);

  const SLIDES = [
    "HR მართვა გამარტივებულად",
    "ხელფასების ავტომატიზაცია",
    "დასწრება და ცვლების კონტროლი",
    "CRM გაყიდვების თრექინგი",
    "ჭკვიანი ანგარიშები და ანალიტიკა",
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setSlideIndex(prev => (prev + 1) % 5);
    }, 5000);
    return () => clearInterval(timer);
  }, []);
  
  const dailyQuote = useMemo(() => {
    return MOTIVATIONAL_QUOTES[Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length)];
  }, []);

  useEffect(() => {
    fetch("https://api.open-meteo.com/v1/forecast?latitude=41.6941&longitude=44.8337&current=temperature_2m,weather_code&timezone=Asia/Tbilisi")
      .then(res => res.json())
      .then(data => {
        const code = data.current?.weather_code ?? 0;
        const temp = Math.round(data.current?.temperature_2m ?? 0);
        let description = "მოწმენდილი";
        let icon = "sun";
        if (code >= 71) { description = "თოვლი"; icon = "snow"; }
        else if (code >= 61) { description = "წვიმა"; icon = "rain"; }
        else if (code >= 45) { description = "ნისლი"; icon = "cloud"; }
        else if (code >= 2) { description = "მოღრუბლული"; icon = "cloudsun"; }
        setWeather({ temp, description, icon });
      })
      .catch(() => {});
  }, []);

  const getWeatherIcon = (icon: string) => {
    switch (icon) {
      case "rain": return <CloudRain className="h-5 w-5" />;
      case "snow": return <Snowflake className="h-5 w-5" />;
      case "cloud": return <Cloud className="h-5 w-5" />;
      case "cloudsun": return <CloudSun className="h-5 w-5" />;
      default: return <Sun className="h-5 w-5" />;
    }
  };

  const handleSignIn = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors({});
    const formData = new FormData(e.currentTarget);
    
    try {
      const data = signInSchema.parse({
        email: formData.get('email'),
        password: formData.get('password'),
      });
      
      setIsLoading(true);
      await signIn(data.email, data.password);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors({});

    if (!termsAccepted || !cookiesAccepted) {
      toast.error('გთხოვთ, დაეთანხმეთ მომსახურების პირობებს, კონფიდენციალურობის პოლიტიკას და ქუქი-ფაილების პოლიტიკას');
      return;
    }

    const formData = new FormData(e.currentTarget);

    try {
      const data = signUpSchema.parse({
        email: formData.get('email'),
        password: formData.get('password'),
        confirmPassword: formData.get('confirmPassword'),
        fullName: formData.get('fullName'),
      });

      setIsLoading(true);
      await signUp(data.email, data.password, data.fullName, 'employee');
    } catch (error) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!resetEmail || !resetEmail.includes('@')) {
      toast.error('გთხოვთ შეიყვანოთ სწორი ელ. ფოსტა');
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('password-reset', {
        body: { email: resetEmail, loginUrl: `${window.location.origin}/auth` }
      });

      if (error) throw error;

      if (data?.success) {
        toast.success('პაროლის აღდგენის ინსტრუქცია გამოგზავნილია!', {
          description: 'შეამოწმეთ თქვენი ელ. ფოსტა და ტელეფონი'
        });
        setForgotPasswordOpen(false);
        setResetEmail('');
      }
    } catch (error: any) {
      console.error('Password reset error:', error);
      toast.error('შეცდომა მოხდა', {
        description: error.message || 'სცადეთ თავიდან'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* Left branded panel */}
      <div className="hidden lg:flex lg:w-[42%] xl:w-[45%] relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[hsl(225,45%,13%)] via-[hsl(234,62%,25%)] to-[hsl(250,55%,20%)]" />
        <div className="absolute inset-0 opacity-[0.07]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '32px 32px' }} />
        
        {/* Animated floating shapes */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/4 animate-[float_8s_ease-in-out_infinite]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-accent/15 rounded-full blur-[100px] translate-y-1/3 -translate-x-1/4 animate-[float_10s_ease-in-out_infinite_reverse]" />
        <div className="absolute top-1/3 left-1/4 w-[200px] h-[200px] bg-blue-400/10 rounded-full blur-[80px] animate-[float_12s_ease-in-out_infinite_2s]" />
        
        {/* Floating geometric shapes */}
        <div className="absolute top-[15%] right-[20%] w-16 h-16 border border-white/10 rounded-2xl rotate-12 animate-[float_7s_ease-in-out_infinite]" />
        <div className="absolute bottom-[25%] right-[15%] w-10 h-10 border border-white/[0.07] rounded-xl -rotate-6 animate-[float_9s_ease-in-out_infinite_1s]" />
        <div className="absolute top-[60%] left-[10%] w-8 h-8 bg-white/[0.04] rounded-lg rotate-45 animate-[float_11s_ease-in-out_infinite_3s]" />
        <div className="absolute top-[10%] left-[40%] w-6 h-6 bg-white/[0.03] rounded-full animate-[float_6s_ease-in-out_infinite_2s]" />
        <div className="absolute bottom-[40%] left-[30%] w-12 h-12 border border-white/[0.05] rounded-full animate-[float_8s_ease-in-out_infinite_4s]" />
        
        <div className="relative z-10 flex flex-col justify-between p-12 xl:p-16 w-full">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="h-10 w-10 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center border border-white/10">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="text-white/90 font-semibold text-lg tracking-tight">HR & CRM Pro</span>
            </div>
          </div>
          
          <div className="space-y-6">
            {(() => {
              const now = new Date();
              const hour = now.getHours();
              const timeStr = now.toLocaleTimeString("ka-GE", { hour: "2-digit", minute: "2-digit" });
              const dateStr = now.toLocaleDateString("ka-GE", { weekday: "long", day: "numeric", month: "long" });
              const greetingText = hour < 6 ? "ღამე მშვიდობისა" : hour < 12 ? "დილა მშვიდობისა" : hour < 18 ? "შუადღე მშვიდობისა" : "საღამო მშვიდობისა";
              const greetingEmoji = hour < 6 ? "🌙✨" : hour < 12 ? "☀️" : hour < 18 ? "🌤️" : "🌅✨";
              return (
                <>
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <p className="text-white/50 text-sm uppercase tracking-widest">თბილისი · {timeStr}</p>
                      {weather && (
                        <div className="flex items-center gap-1.5 text-white/60 text-sm bg-white/[0.08] rounded-full px-3 py-1">
                          {getWeatherIcon(weather.icon)}
                          <span>{weather.temp}°C</span>
                          <span className="text-white/40">·</span>
                          <span>{weather.description}</span>
                        </div>
                      )}
                    </div>
                    <h1 className="text-3xl xl:text-4xl font-bold text-white leading-tight whitespace-nowrap">
                      {greetingText} <span>{greetingEmoji}</span>
                    </h1>
                    <p className="text-white/50 text-base">{dateStr}</p>
                  </div>
                </>
              );
            })()}

            {/* Daily Motivational Quote */}
            <div className="bg-white/[0.06] backdrop-blur-sm border border-white/[0.08] rounded-2xl p-6 max-w-md">
              <Quote className="h-5 w-5 text-white/30 mb-3" />
              <p className="text-white/80 text-base leading-relaxed italic">
                „{dailyQuote.text}"
              </p>
              <p className="text-white/40 text-sm mt-3">- {dailyQuote.author}</p>
            </div>
            
            {/* Feature Slider */}
            <div className="max-w-md space-y-3">
              <div className="h-10 flex items-center overflow-hidden">
                <p className="text-xl font-semibold text-white/90 transition-all duration-500 animate-fade-in" key={slideIndex}>
                  {SLIDES[slideIndex]}
                </p>
              </div>
              <div className="flex gap-0">
                {SLIDES.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setSlideIndex(i)}
                    aria-label={`სლაიდი ${i + 1}`}
                    className="relative flex items-center justify-center py-3 px-1.5"
                  >
                    <span className={`block h-1 rounded-full transition-all duration-500 ${i === slideIndex ? 'w-8 bg-white/70' : 'w-3 bg-white/20 hover:bg-white/30'}`} />
                  </button>
                ))}
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-6 pt-4">
              <div className="space-y-1">
                <div className="text-2xl font-bold text-white">500+</div>
                <div className="text-xs text-white/40 uppercase tracking-wider">მომხმარებელი</div>
              </div>
              <div className="space-y-1">
                <div className="text-2xl font-bold text-white">99.9%</div>
                <div className="text-xs text-white/40 uppercase tracking-wider">Uptime</div>
              </div>
              <div className="space-y-1">
                <div className="text-2xl font-bold text-white">24/7</div>
                <div className="text-xs text-white/40 uppercase tracking-wider">მხარდაჭერა</div>
              </div>
            </div>

            {/* Security Badge */}
            <div className="flex items-center gap-2 text-white/40 text-xs pt-2">
              <Lock className="h-3.5 w-3.5" />
              <span>ენკრიპცია</span>
              <span>•</span>
              <span>დაცული სერვერები</span>
              <span>•</span>
              <span>კონფიდენციალურობა</span>
            </div>
          </div>
          
          <p className="text-white/30 text-xs">© 2026 HR & CRM Pro. ყველა უფლება დაცულია.</p>
        </div>
      </div>
      
      {/* Right form panel */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-8 relative">
        <div className="absolute top-4 right-4">
          <ThemeToggle />
        </div>
        <div className="w-full max-w-[420px] flex flex-col items-center">
        <Card className="w-full border-0 shadow-none bg-transparent">
          <CardHeader className="text-center px-0 pt-0 pb-6">
            <div className="lg:hidden flex items-center justify-center gap-2 mb-4">
              <div className="h-9 w-9 rounded-xl gradient-primary flex items-center justify-center">
                <Sparkles className="h-4.5 w-4.5 text-white" />
              </div>
              <span className="font-semibold text-lg text-foreground">HR & CRM Pro</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground leading-none tracking-tight">
              {mode === 'login' ? 'მოგესალმებით 👋' : 'შექმენით ანგარიში 🚀'}
            </h1>
            <CardDescription className="text-sm text-muted-foreground mt-1">
              {mode === 'login' ? 'შეიყვანეთ თქვენი მონაცემები' : 'შეავსეთ ველები რეგისტრაციისთვის'}
            </CardDescription>
            {/* Mode toggle */}
            <div className="flex items-center justify-center gap-1 mt-4 bg-muted/60 rounded-lg p-1 w-fit mx-auto">
              <button
                type="button"
                onClick={() => { setMode('login'); setErrors({}); }}
                className={`px-4 py-1.5 text-sm rounded-md transition-all ${mode === 'login' ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
              >
                შესვლა
              </button>
              <button
                type="button"
                onClick={() => { setMode('register'); setErrors({}); setTermsAccepted(false); setCookiesAccepted(false); }}
                className={`px-4 py-1.5 text-sm rounded-md transition-all ${mode === 'register' ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
              >
                რეგისტრაცია
              </button>
            </div>
          </CardHeader>
          <CardContent className="relative z-10 px-0 pb-0">
            {mode === 'login' ? (
            <form onSubmit={handleSignIn} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="signin-email">ელ. ფოსტა</Label>
                <Input
                  id="signin-email"
                  name="email"
                  type="email"
                  placeholder="your@email.com"
                  autoComplete="username"
                  disabled={isLoading}
                  required
                />
                {errors.email && <p className="mt-1 text-sm text-destructive">{errors.email}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="signin-password">პაროლი</Label>
                <Input
                  id="signin-password"
                  name="password"
                  type="password"
                  placeholder="••••••"
                  autoComplete="current-password"
                  disabled={isLoading}
                  required
                />
                {errors.password && <p className="mt-1 text-sm text-destructive">{errors.password}</p>}
              </div>
              
              <div className="text-right">
                <Dialog open={forgotPasswordOpen} onOpenChange={setForgotPasswordOpen}>
                  <DialogTrigger asChild>
                    <Button type="button" variant="link" className="text-sm text-primary px-0 h-auto">
                      დაგავიწყდა პაროლი?
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>პაროლის აღდგენა</DialogTitle>
                      <DialogDescription>
                        შეიყვანეთ თქვენი ელ. ფოსტა და მიიღებთ პაროლის აღდგენის ინსტრუქციას როგორც მეილით, ისე SMS-ით
                      </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleForgotPassword} className="space-y-4 mt-4">
                      <div className="space-y-2">
                        <Label htmlFor="reset-email">ელ. ფოსტა</Label>
                        <Input
                          id="reset-email"
                          type="email"
                          placeholder="your@email.com"
                          value={resetEmail}
                          onChange={(e) => setResetEmail(e.target.value)}
                          disabled={isLoading}
                          required
                        />
                      </div>
                      <div className="flex gap-2 justify-end">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => {
                            setForgotPasswordOpen(false);
                            setResetEmail('');
                          }}
                          disabled={isLoading}
                        >
                          გაუქმება
                        </Button>
                        <Button type="submit" disabled={isLoading}>
                          {isLoading ? 'იგზავნება...' : 'გაგზავნა'}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
              
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'შესვლა...' : 'შესვლა'}
              </Button>
              
              <p className="text-center text-xs text-muted-foreground mt-4">
                სისტემაში შესვლით თანხმდებით{' '}
                <a href="/terms-of-service" className="text-primary hover:underline" onClick={(e) => { e.preventDefault(); window.location.href = '/terms-of-service'; }}>
                  მომსახურების პირობებს
                </a>,{' '}
                <a href="/privacy-policy" className="text-primary hover:underline" onClick={(e) => { e.preventDefault(); window.location.href = '/privacy-policy'; }}>
                  კონფიდენციალურობის პოლიტიკას
                </a>{' '}
                და{' '}
                <a href="/cookie-policy" className="text-primary hover:underline" onClick={(e) => { e.preventDefault(); window.location.href = '/cookie-policy'; }}>
                  ქუქი-ფაილების პოლიტიკას
                </a>
              </p>
            </form>
            ) : (
            <form onSubmit={handleSignUp} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="signup-fullName">სრული სახელი</Label>
                <Input
                  id="signup-fullName"
                  name="fullName"
                  type="text"
                  placeholder="გიორგი გიორგაძე"
                  autoComplete="name"
                  disabled={isLoading}
                  required
                />
                {errors.fullName && <p className="mt-1 text-sm text-destructive">{errors.fullName}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="signup-email">ელ. ფოსტა</Label>
                <Input
                  id="signup-email"
                  name="email"
                  type="email"
                  placeholder="your@email.com"
                  autoComplete="email"
                  disabled={isLoading}
                  required
                />
                {errors.email && <p className="mt-1 text-sm text-destructive">{errors.email}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="signup-password">პაროლი</Label>
                <Input
                  id="signup-password"
                  name="password"
                  type="password"
                  placeholder="••••••••"
                  autoComplete="new-password"
                  disabled={isLoading}
                  required
                />
                {errors.password && <p className="mt-1 text-sm text-destructive">{errors.password}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="signup-confirmPassword">პაროლის დადასტურება</Label>
                <Input
                  id="signup-confirmPassword"
                  name="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  autoComplete="new-password"
                  disabled={isLoading}
                  required
                />
              {errors.confirmPassword && <p className="mt-1 text-sm text-destructive">{errors.confirmPassword}</p>}
              </div>

              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <Checkbox
                    id="terms"
                    checked={termsAccepted}
                    onCheckedChange={(checked) => setTermsAccepted(checked === true)}
                    className="mt-0.5"
                  />
                  <label htmlFor="terms" className="text-xs text-muted-foreground leading-relaxed cursor-pointer">
                    ვეთანხმები{' '}
                    <a href="/terms-of-service" className="text-primary hover:underline" onClick={(e) => { e.preventDefault(); window.location.href = '/terms-of-service'; }}>
                      მომსახურების პირობებს
                    </a>{' '}
                    და{' '}
                    <a href="/privacy-policy" className="text-primary hover:underline" onClick={(e) => { e.preventDefault(); window.location.href = '/privacy-policy'; }}>
                      კონფიდენციალურობის პოლიტიკას
                    </a>
                  </label>
                </div>
                <div className="flex items-start gap-2">
                  <Checkbox
                    id="cookies"
                    checked={cookiesAccepted}
                    onCheckedChange={(checked) => setCookiesAccepted(checked === true)}
                    className="mt-0.5"
                  />
                  <label htmlFor="cookies" className="text-xs text-muted-foreground leading-relaxed cursor-pointer">
                    ვეთანხმები{' '}
                    <a href="/cookie-policy" className="text-primary hover:underline" onClick={(e) => { e.preventDefault(); window.location.href = '/cookie-policy'; }}>
                      ქუქი-ფაილების პოლიტიკას
                    </a>
                  </label>
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'რეგისტრაცია...' : 'რეგისტრაცია'}
              </Button>
              
            </form>
            )}
          </CardContent>
        </Card>

        <div className="flex flex-col items-center justify-center gap-1 mt-6">
          <span className="text-xs text-muted-foreground">powered by</span>
          <img src={techflowLogo} alt="TechFlow" className="h-10 w-auto" loading="lazy" />
        </div>
        </div>
      </div>
    </div>
  );
}
