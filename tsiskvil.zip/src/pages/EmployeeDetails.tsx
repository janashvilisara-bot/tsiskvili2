import { useState, useEffect } from "react";
import { getScheduleTypeLabel } from "@/lib/scheduleUtils";
import { calculateProfileCompletion } from "@/lib/profileCompletion";
import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import { EmployeePerformanceTab } from "@/components/employees/EmployeePerformanceTab";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { toast } from "sonner";
import { ArrowLeft, Plus, FileText, History, Calendar, Star, Upload, Download, Trash2, Sparkles, PenTool } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Progress } from "@/components/ui/progress";
import { SensitiveDataViewer } from "@/components/employees/SensitiveDataViewer";
import { EmployeeBenefitsTab } from "@/components/employees/EmployeeBenefitsTab";

interface Employee {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  position: string;
  department: string | null;
  salary: number | null;
  hire_date: string;
  status: string;
  work_schedule_id?: string | null;
  actual_address?: string | null;
  legal_address?: string | null;
  education?: string | null;
  education_level?: string | null;
  previous_experience?: string | null;
  emergency_contact_name?: string | null;
  emergency_contact_phone?: string | null;
  emergency_contact_relation?: string | null;
  bank_account_number?: string | null;
  bank_name?: string | null;
  tax_benefits?: string | null;
  personal_id_number?: string | null;
  date_of_birth?: string | null;
  gender?: string | null;
}

interface ScheduleTemplate {
  id: string;
  name: string;
  description: string | null;
  conditions: string | null;
  schedule_type: string;
  start_time: string | null;
  end_time: string | null;
  weekly_hours: number;
  break_duration: number;
  no_break: boolean;
}

interface EmployeeHistory {
  id: string;
  change_type: string;
  previous_position: string | null;
  new_position: string | null;
  previous_department: string | null;
  new_department: string | null;
  previous_salary: number | null;
  new_salary: number | null;
  effective_date: string;
  reason: string | null;
  notes: string | null;
  created_at: string;
  status?: string | null;
  applied_at?: string | null;
}

interface Contract {
  id: string;
  contract_type: string;
  contract_number: string | null;
  start_date: string;
  end_date: string | null;
  position: string;
  salary: number;
  terms: string | null;
  status: string;
  notification_sent: boolean;
  created_at: string;
  file_url?: string | null;
}

const EmployeeDetails = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { userRole } = useAuth();
  const { t } = useLanguage();
  const [employee, setEmployee] = useState<Employee | null>(null);
  const [history, setHistory] = useState<EmployeeHistory[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [positions, setPositions] = useState<any[]>([]);
  const [scheduleTemplate, setScheduleTemplate] = useState<ScheduleTemplate | null>(null);
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false);
  const [isContractDialogOpen, setIsContractDialogOpen] = useState(false);
  const [changeType, setChangeType] = useState("");
  const [contractType, setContractType] = useState("");
  const [uploadingFile, setUploadingFile] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [generatingContract, setGeneratingContract] = useState(false);
  const [generatedContract, setGeneratedContract] = useState("");
  const [isGenerateDialogOpen, setIsGenerateDialogOpen] = useState(false);
  const [contractToSign, setContractToSign] = useState<Contract | null>(null);
  const [signatureData, setSignatureData] = useState("");
  const [contractTemplates, setContractTemplates] = useState<any[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");

  const canManage = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    if (id) {
      fetchEmployee();
      fetchHistory();
      fetchContracts();
      fetchDepartments();
      fetchPositions();
      fetchContractTemplates();
    }
  }, [id]);

  useEffect(() => {
    if (employee?.work_schedule_id) {
      fetchScheduleTemplate();
    }
  }, [employee?.work_schedule_id]);

  const fetchEmployee = async () => {
    const { data, error } = await supabase
      .from('employees')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) {
      toast.error('შეცდომა: ' + error.message);
    } else {
      setEmployee(data as Employee);
    }
  };

  const fetchHistory = async () => {
    const { data, error } = await supabase
      .from('employee_history')
      .select('*')
      .eq('employee_id', id)
      .order('effective_date', { ascending: false });
    
    if (error) {
      toast.error('შეცდომა: ' + error.message);
    } else {
      setHistory(data || []);
    }
  };

  const fetchContracts = async () => {
    const { data, error } = await supabase
      .from('contracts')
      .select('*')
      .eq('employee_id', id)
      .order('start_date', { ascending: false });
    
    if (error) {
      toast.error('შეცდომა: ' + error.message);
    } else {
      setContracts(data || []);
    }
  };

  const fetchDepartments = async () => {
    try {
      const { data, error } = await supabase
        .from('departments')
        .select('id, name')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setDepartments(data || []);
    } catch (error: any) {
      console.error('დეპარტამენტების ჩატვირთვა ვერ მოხერხდა', error);
    }
  };

  const fetchPositions = async () => {
    try {
      const { data, error } = await supabase
        .from('positions')
        .select('id, title')
        .eq('is_active', true)
        .order('title');

      if (error) throw error;
      setPositions(data || []);
    } catch (error: any) {
      console.error('პოზიციების ჩატვირთვა ვერ მოხერხდა', error);
    }
  };

  const fetchScheduleTemplate = async () => {
    if (!employee?.work_schedule_id) return;
    
    const { data, error } = await supabase
      .from('schedule_templates')
      .select('*')
      .eq('id', employee.work_schedule_id)
      .single();
    
    if (error) {
      console.error('გრაფიკის ჩატვირთვა ვერ მოხერხდა', error);
    } else {
      setScheduleTemplate(data);
    }
  };

  const fetchContractTemplates = async () => {
    // @ts-ignore - contract_templates table exists in database
    const { data, error } = await supabase
      // @ts-ignore
      .from('contract_templates')
      .select('*')
      .eq('is_active', true)
      .order('name');

    if (error) {
      console.error('Error fetching templates:', error);
    } else {
      setContractTemplates(data || []);
    }
  };

  const handleAddHistory = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);

    const effectiveDate = formData.get('effective_date') as string;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const eff = new Date(effectiveDate); eff.setHours(0, 0, 0, 0);
    const isScheduled = eff.getTime() > today.getTime();

    const historyData: any = {
      employee_id: id,
      change_type: changeType,
      previous_position: formData.get('previous_position') as string || null,
      new_position: formData.get('new_position') as string || null,
      previous_department: formData.get('previous_department') as string || null,
      new_department: formData.get('new_department') as string || null,
      previous_salary: formData.get('previous_salary') ? parseFloat(formData.get('previous_salary') as string) : null,
      new_salary: formData.get('new_salary') ? parseFloat(formData.get('new_salary') as string) : null,
      effective_date: effectiveDate,
      reason: formData.get('reason') as string || null,
      notes: formData.get('notes') as string || null,
      status: isScheduled ? 'scheduled' : 'applied',
      applied_at: isScheduled ? null : new Date().toISOString(),
    };

    const { error } = await supabase
      .from('employee_history')
      .insert([historyData]);
    
    if (error) {
      toast.error(t('common.error') + ': ' + error.message);
    } else {
      toast.success(isScheduled ? 'ცვლილება დაგეგმილია' : t('employees.historyAdded'));
      fetchHistory();
      setIsHistoryDialogOpen(false);
      setChangeType("");
      
      if (!isScheduled) {
        // Update employee record only for immediate changes
        const updateData: any = {};
        if (historyData.new_position) updateData.position = historyData.new_position;
        if (historyData.new_department) updateData.department = historyData.new_department;
        if (historyData.new_salary) updateData.salary = historyData.new_salary;

        if (Object.keys(updateData).length > 0) {
          const { error: applyErr } = await supabase
            .from('employees')
            .update(updateData)
            .eq('id', id);
          if (applyErr) toast.error('ცვლილება ისტორიაში შეინახა, მაგრამ თანამშრომლის ბარათზე ვერ აისახა');
          fetchEmployee();
        }
      }
    }
  };

  const handleCancelScheduled = async (historyId: string) => {
    const { error } = await supabase
      .from('employee_history')
      .update({ status: 'cancelled' } as any)
      .eq('id', historyId);
    if (error) {
      toast.error(t('common.error') + ': ' + error.message);
    } else {
      toast.success('დაგეგმილი ცვლილება გაუქმდა');
      fetchHistory();
    }
  };

  const handleAddContract = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    let fileUrl = null;
    
    // Upload file if selected
    if (selectedFile) {
      setUploadingFile(true);
      const fileExt = selectedFile.name.split('.').pop();
      const fileName = `${id}_${Date.now()}.${fileExt}`;
      const filePath = `${id}/${fileName}`;
      
      const { error: uploadError } = await supabase.storage
        .from('employee-contracts')
        .upload(filePath, selectedFile);
      
      if (uploadError) {
        toast.error('ფაილის ატვირთვა ვერ მოხერხდა: ' + uploadError.message);
        setUploadingFile(false);
        return;
      }
      
      const { data: urlData } = supabase.storage
        .from('employee-contracts')
        .getPublicUrl(filePath);
      
      fileUrl = filePath;
      setUploadingFile(false);
    }
    
    // @ts-ignore - file_url field exists
    const contractData: any = {
      employee_id: id,
      contract_type: contractType,
      contract_number: formData.get('contract_number') as string || null,
      start_date: formData.get('start_date') as string,
      end_date: formData.get('end_date') as string || null,
      position: formData.get('position') as string,
      salary: parseFloat(formData.get('salary') as string),
      terms: formData.get('terms') as string || null,
      status: 'active',
      file_url: fileUrl,
    };

    // @ts-ignore - file_url field exists
    const { error } = await supabase
      .from('contracts')
      .insert([contractData]);
    
    if (error) {
      toast.error(t('common.error') + ': ' + error.message);
    } else {
      toast.success(t('employees.contractAdded'));
      fetchContracts();
      setIsContractDialogOpen(false);
      setContractType("");
      setSelectedFile(null);
    }
  };

  const handleDownloadContract = async (fileUrl: string) => {
    const { data, error } = await supabase.storage
      .from('employee-contracts')
      .download(fileUrl);
    
    if (error) {
      toast.error('ფაილის ჩამოტვირთვა ვერ მოხერხდა: ' + error.message);
      return;
    }
    
    const url = URL.createObjectURL(data);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileUrl.split('/').pop() || 'contract';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDeleteContractFile = async (contractId: string, fileUrl: string) => {
    const { error: deleteError } = await supabase.storage
      .from('employee-contracts')
      .remove([fileUrl]);
    
    if (deleteError) {
      toast.error('ფაილის წაშლა ვერ მოხერხდა: ' + deleteError.message);
      return;
    }
    
    // @ts-ignore - file_url field exists
    const { error: updateError } = await supabase
      .from('contracts')
      .update({ file_url: null } as any)
      .eq('id', contractId);
    
    if (updateError) {
      toast.error('შეცდომა: ' + updateError.message);
    } else {
      toast.success('ფაილი წარმატებით წაიშალა');
      fetchContracts();
    }
  };

  const handleGenerateContract = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    setGeneratingContract(true);
    
    try {
      // If template is selected (not 'no-template'), use it
      if (selectedTemplate && selectedTemplate !== 'no-template') {
        const template = contractTemplates.find(t => t.id === selectedTemplate);
        if (template) {
          let content = template.template_content;
          
          // Replace placeholders
          content = content
            .replace(/{employee_name}/g, employee?.full_name || '')
            .replace(/{position}/g, formData.get('gen_position') as string)
            .replace(/{salary}/g, formData.get('gen_salary') as string)
            .replace(/{start_date}/g, formData.get('gen_start_date') as string)
            .replace(/{end_date}/g, formData.get('gen_end_date') as string || '')
            .replace(/{additional_terms}/g, formData.get('gen_terms') as string || '')
            .replace(/{contract_number}/g, `${Date.now()}`)
            .replace(/{current_date}/g, new Date().toLocaleDateString('ka-GE'));
          
          setGeneratedContract(content);
          toast.success('ხელშეკრულება შაბლონიდან გენერირდა');
          setGeneratingContract(false);
          return;
        }
      }

      // Otherwise use AI generation
      const { data, error } = await supabase.functions.invoke('generate-contract', {
        body: {
          employeeId: id,
          contractType: formData.get('gen_contract_type'),
          position: formData.get('gen_position'),
          salary: formData.get('gen_salary'),
          startDate: formData.get('gen_start_date'),
          endDate: formData.get('gen_end_date') || null,
          additionalTerms: formData.get('gen_terms') || null,
        }
      });

      if (error) throw error;

      setGeneratedContract(data.contract);
      toast.success('ხელშეკრულება AI-ით გენერირდა');
    } catch (error: any) {
      console.error('Contract generation error:', error);
      toast.error('ხელშეკრულების გენერაცია ვერ მოხერხდა: ' + error.message);
    } finally {
      setGeneratingContract(false);
    }
  };

  const handleDownloadGeneratedContract = () => {
    if (!generatedContract) return;
    
    const blob = new Blob([generatedContract], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ხელშეკრულება_${employee?.full_name || 'თანამშრომელი'}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('ხელშეკრულება ჩამოიტვირთა');
  };

  const handleSaveGeneratedContract = async () => {
    const formData = new FormData(document.querySelector('#generate-contract-form') as HTMLFormElement);
    
    const contractData = {
      employee_id: id,
      contract_type: formData.get('gen_contract_type') as string,
      position: formData.get('gen_position') as string,
      salary: parseFloat(formData.get('gen_salary') as string),
      start_date: formData.get('gen_start_date') as string,
      end_date: formData.get('gen_end_date') as string || null,
      terms: generatedContract,
      status: 'active',
    };

    const { error } = await supabase
      .from('contracts')
      .insert([contractData]);
    
    if (error) {
      toast.error('შეცდომა: ' + error.message);
    } else {
      toast.success('ხელშეკრულება შენახულია');
      fetchContracts();
      setIsGenerateDialogOpen(false);
      setGeneratedContract("");
    }
  };

  const handleSignContract = async () => {
    if (!contractToSign || !signatureData) {
      toast.error('გთხოვთ მოაწეროთ ხელი');
      return;
    }

    const { error } = await supabase
      .from('contracts')
      .update({ 
        status: 'signed',
        signed_at: new Date().toISOString(),
        signature_data: signatureData,
      })
      .eq('id', contractToSign.id);
    
    if (error) {
      toast.error('ხელმოწერა ვერ მოხერხდა: ' + error.message);
    } else {
      toast.success('ხელშეკრულება ხელმოწერილია');
      fetchContracts();
      setContractToSign(null);
      setSignatureData("");
    }
  };

  const getChangeTypeText = (type: string) => {
    const types: Record<string, string> = {
      promotion: 'დაწინაურება',
      position_change: 'პოზიციის ცვლილება',
      salary_change: 'ხელფასის ცვლილება',
      department_change: 'დეპარტამენტის ცვლილება',
      termination: 'გათავისუფლება',
    };
    return types[type] || type;
  };

  const getContractTypeText = (type: string) => {
    const types: Record<string, string> = {
      permanent: 'უვადო',
      fixed_term: 'ვადიანი',
      probation: 'გამოსაცდელი',
      freelance: 'ფრილანსერი',
      intern: 'სტაჟიორი',
      service: 'მომსახურება',
    };
    return types[type] || type;
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, "default" | "secondary" | "destructive"> = {
      active: 'default',
      expired: 'secondary',
      terminated: 'destructive',
      renewed: 'default',
    };
    return colors[status] || 'secondary';
  };

  if (!employee) {
    return (
      <div className="p-8">
        <p>იტვირთება...</p>
      </div>
    );
  }

  return (
    <div className="p-8">
        <Button variant="ghost" onClick={() => navigate('/employees')} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          უკან
        </Button>

        <div className="mb-6 flex items-center justify-between">
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-white">{employee.full_name}</h1>
            <p className="text-lg font-bold text-red-500">{employee.position} • {employee.department}</p>
            <div className="mt-4 max-w-md">
              <div className="flex items-center gap-3">
                <Progress 
                  value={calculateProfileCompletion(employee)} 
                  className="flex-1 [&>div]:bg-gradient-to-r [&>div]:from-pink-500 [&>div]:via-purple-500 [&>div]:to-blue-500"
                  style={{
                    background: 'linear-gradient(to right, hsl(330 80% 90%), hsl(270 80% 90%), hsl(210 80% 90%))'
                  }}
                />
                <span className="text-sm font-bold bg-gradient-to-r from-green-500 to-emerald-500 bg-clip-text text-transparent">
                  {calculateProfileCompletion(employee)}%
                </span>
              </div>
              <p className="text-xs font-bold text-white mt-1">
                პროფილის შევსების პროცენტი
              </p>
            </div>
          </div>
          {(userRole === 'admin' || userRole === 'hr_manager') && (
            <Button onClick={() => navigate(`/employees/${id}/evaluations`)} className="gap-2">
              <Star className="h-4 w-4" />
              შეფასებები
            </Button>
          )}
        </div>

        <Tabs defaultValue={searchParams.get("tab") === "performance" && (userRole === "admin" || userRole === "hr_manager") ? "performance" : "info"} className="space-y-4">
          <TabsList>
            <TabsTrigger value="info">ძირითადი ინფორმაცია</TabsTrigger>
            <TabsTrigger value="history">ისტორია</TabsTrigger>
            <TabsTrigger value="contracts">ხელშეკრულებები</TabsTrigger>
            <TabsTrigger value="benefits">ბენეფიტები / სერვისები</TabsTrigger>
            {canManage && <TabsTrigger value="performance">პერფორმანსი</TabsTrigger>}
          </TabsList>

          <TabsContent value="info">
            <Card className="border-2 border-primary/10">
              <CardHeader className="bg-gradient-to-r from-teal-50 via-cyan-50 to-sky-50 dark:from-teal-950/20 dark:via-cyan-950/20 dark:to-sky-950/20">
                <CardTitle className="bg-gradient-to-r from-teal-600 via-cyan-600 to-sky-600 bg-clip-text text-transparent">
                  თანამშრომლის დეტალები
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* დაცული მონაცემები - E2E დაშიფვრით */}
                <SensitiveDataViewer
                  employeeId={employee.id}
                  employeeName={employee.full_name}
                  rawData={{
                    personal_id: employee.personal_id_number || undefined,
                    phone: employee.phone || undefined,
                    email: employee.email,
                    address: employee.actual_address || undefined,
                    salary: employee.salary || undefined,
                    bank_account: employee.bank_account_number || undefined,
                  }}
                />

                {/* არა-მგრძნობიარე ინფორმაცია */}
                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="p-3 rounded-lg bg-gradient-to-br from-indigo-50 to-indigo-100 dark:from-indigo-500/20 dark:to-indigo-400/20 border border-indigo-200/50 dark:border-indigo-400/40">
                    <Label className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">პოზიცია</Label>
                    <p className="mt-1 font-medium text-foreground">{employee.position}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-gradient-to-br from-violet-50 to-violet-100 dark:from-violet-500/20 dark:to-violet-400/20 border border-violet-200/50 dark:border-violet-400/40">
                    <Label className="text-xs font-semibold text-violet-700 dark:text-violet-300">დეპარტამენტი</Label>
                    <p className="mt-1 font-medium text-foreground">{employee.department || '-'}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-500/20 dark:to-emerald-400/20 border border-emerald-200/50 dark:border-emerald-400/40">
                    <Label className="text-xs font-semibold text-emerald-700 dark:text-emerald-300">დაბადების თარიღი</Label>
                    <p className="mt-1 font-medium text-foreground">{employee.date_of_birth && !isNaN(new Date(employee.date_of_birth).getTime()) 
                      ? format(new Date(employee.date_of_birth), 'dd/MM/yyyy')
                      : '-'}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-500/20 dark:to-blue-400/20 border border-blue-200/50 dark:border-blue-400/40">
                    <Label className="text-xs font-semibold text-blue-700 dark:text-blue-300">სქესი</Label>
                    <p className="mt-1 font-medium text-foreground">{employee.gender === 'male' ? 'მამრობითი' : employee.gender === 'female' ? 'მდედრობითი' : '-'}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-gradient-to-br from-cyan-50 to-cyan-100 dark:from-cyan-500/20 dark:to-cyan-400/20 border border-cyan-200/50 dark:border-cyan-400/40">
                    <Label className="text-xs font-semibold text-cyan-700 dark:text-cyan-300">დაქირავების თარიღი</Label>
                    <p className="mt-1 font-medium text-foreground">{employee.hire_date && !isNaN(new Date(employee.hire_date).getTime()) 
                      ? format(new Date(employee.hire_date), 'dd/MM/yyyy')
                      : "-"}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-500/20 dark:to-emerald-400/20 border border-emerald-200/50 dark:border-emerald-400/40">
                    <Label className="text-xs font-semibold text-emerald-700 dark:text-emerald-300">სტატუსი</Label>
                    <Badge className="mt-1" variant={employee.status === 'active' ? 'default' : 'secondary'}>
                      {employee.status === 'active' ? 'აქტიური' : 'არააქტიური'}
                    </Badge>
                  </div>
                </div>
                
                <div className="mt-6 pt-6 border-t border-pink-200/50">
                  <h3 className="text-lg font-bold mb-4 bg-gradient-to-r from-pink-600 via-rose-600 to-red-600 bg-clip-text text-transparent">
                    📍 მისამართები
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-gradient-to-br from-pink-50 to-rose-50 dark:from-pink-500/20 dark:to-rose-400/20 border border-pink-200/50 dark:border-pink-400/40">
                      <Label className="text-xs font-semibold text-pink-700 dark:text-pink-300">ფაქტიური მისამართი</Label>
                      <p className="mt-1 font-medium text-foreground">{employee.actual_address || '-'}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-gradient-to-br from-rose-50 to-red-50 dark:from-rose-500/20 dark:to-red-400/20 border border-rose-200/50 dark:border-rose-400/40">
                      <Label className="text-xs font-semibold text-rose-700 dark:text-rose-300">იურიდიული მისამართი</Label>
                      <p className="mt-1 font-medium text-foreground">{employee.legal_address || '-'}</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-blue-200/50">
                  <h3 className="text-lg font-bold mb-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
                    🎓 განათლება და გამოცდილება
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-500/20 dark:to-indigo-400/20 border border-blue-200/50 dark:border-blue-400/40">
                      <Label className="text-xs font-semibold text-blue-700 dark:text-blue-300">განათლების დონე</Label>
                      <p className="mt-1 font-medium text-foreground">{employee.education_level || '-'}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-500/20 dark:to-purple-400/20 border border-indigo-200/50 dark:border-indigo-400/40">
                      <Label className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">განათლება</Label>
                      <p className="mt-1 font-medium text-foreground whitespace-pre-wrap">{employee.education || '-'}</p>
                    </div>
                    <div className="col-span-2 p-3 rounded-lg bg-gradient-to-br from-purple-50 to-violet-50 dark:from-purple-500/20 dark:to-violet-400/20 border border-purple-200/50 dark:border-purple-400/40">
                      <Label className="text-xs font-semibold text-purple-700 dark:text-purple-300">წინა გამოცდილება</Label>
                      <p className="mt-1 font-medium text-foreground whitespace-pre-wrap">{employee.previous_experience || '-'}</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-orange-200/50">
                  <h3 className="text-lg font-bold mb-4 bg-gradient-to-r from-orange-600 via-amber-600 to-yellow-600 bg-clip-text text-transparent">
                    🚨 საგანგებო კონტაქტი
                  </h3>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="p-3 rounded-lg bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-500/20 dark:to-amber-400/20 border border-orange-200/50 dark:border-orange-400/40">
                      <Label className="text-xs font-semibold text-orange-700 dark:text-orange-300">სახელი</Label>
                      <p className="mt-1 font-medium text-foreground">{employee.emergency_contact_name || '-'}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-gradient-to-br from-amber-50 to-yellow-50 dark:from-amber-500/20 dark:to-yellow-400/20 border border-amber-200/50 dark:border-amber-400/40">
                      <Label className="text-xs font-semibold text-amber-700 dark:text-amber-300">ტელეფონი</Label>
                      <p className="mt-1 font-medium text-foreground">{employee.emergency_contact_phone || '-'}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-500/20 dark:to-orange-400/20 border border-yellow-200/50 dark:border-yellow-400/40">
                      <Label className="text-xs font-semibold text-yellow-700 dark:text-yellow-300">ურთიერთობა</Label>
                      <p className="mt-1 font-medium text-foreground">{employee.emergency_contact_relation || '-'}</p>
                    </div>
                  </div>
                </div>

                {/* ბანკის დასახელება და საშემოსავლო შეღავათი - არა-მგრძნობიარე */}
                <div className="mt-6 pt-6 border-t border-emerald-200/50">
                  <h3 className="text-lg font-bold mb-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 bg-clip-text text-transparent">
                    🏦 ბანკის ინფორმაცია
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-500/20 dark:to-teal-400/20 border border-emerald-200/50 dark:border-emerald-400/40">
                      <Label className="text-xs font-semibold text-emerald-700 dark:text-emerald-300">ბანკის დასახელება</Label>
                      <p className="mt-1 font-medium text-foreground">{employee.bank_name || '-'}</p>
                    </div>
                    <div className="col-span-1 p-3 rounded-lg bg-gradient-to-br from-cyan-50 to-emerald-50 dark:from-cyan-500/20 dark:to-emerald-400/20 border border-cyan-200/50 dark:border-cyan-400/40">
                      <Label className="text-xs font-semibold text-cyan-700 dark:text-cyan-300">საშემოსავლო შეღავათი</Label>
                      <p className="mt-1 font-medium text-foreground whitespace-pre-wrap">{employee.tax_benefits || '-'}</p>
                    </div>
                  </div>
                </div>
                
                {scheduleTemplate && (
                  <div className="mt-6 pt-6 border-t border-purple-200/50">
                    <h3 className="text-lg font-bold mb-4 bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-600 bg-clip-text text-transparent flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-purple-600" />
                      სამუშაო გრაფიკი
                    </h3>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="p-3 rounded-lg bg-gradient-to-br from-purple-50 to-fuchsia-50 dark:from-purple-500/20 dark:to-fuchsia-400/20 border border-purple-200/50 dark:border-purple-400/40">
                        <Label className="text-xs font-semibold text-purple-700 dark:text-purple-300">გრაფიკის ტიპი</Label>
                        <p className="mt-1 font-medium text-foreground">{getScheduleTypeLabel(scheduleTemplate.schedule_type)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-gradient-to-br from-pink-50 to-rose-50 dark:from-pink-500/20 dark:to-rose-400/20 border border-pink-200/50 dark:border-pink-400/40">
                        <Label className="text-xs font-semibold text-pink-700 dark:text-pink-300">შესვენება</Label>
                        <p className="mt-1 font-medium text-foreground">{scheduleTemplate.no_break ? 'შესვენების გარეშე' : `${scheduleTemplate.break_duration} წუთი`}</p>
                      </div>
                      {scheduleTemplate.start_time && scheduleTemplate.end_time && (
                        <div className="p-3 rounded-lg bg-gradient-to-br from-violet-50 to-purple-50 dark:from-violet-500/20 dark:to-purple-400/20 border border-violet-200/50 dark:border-violet-400/40">
                          <Label className="text-xs font-semibold text-violet-700 dark:text-violet-300">სამუშაო საათები</Label>
                          <p className="mt-1 font-medium text-foreground">{scheduleTemplate.start_time} - {scheduleTemplate.end_time}</p>
                        </div>
                      )}
                    </div>
                    {scheduleTemplate.description && (
                      <div className="mt-4 p-3 rounded-lg bg-gradient-to-br from-slate-50 to-gray-50 dark:from-slate-500/20 dark:to-gray-400/20 border border-slate-200/50 dark:border-slate-400/40">
                        <Label className="text-xs font-semibold text-slate-700 dark:text-slate-300">აღწერა</Label>
                        <p className="mt-1 text-sm text-foreground">{scheduleTemplate.description}</p>
                      </div>
                    )}
                    {scheduleTemplate.conditions && (
                      <div className="mt-4 p-3 rounded-lg bg-gradient-to-br from-zinc-50 to-slate-50 dark:from-zinc-500/20 dark:to-slate-400/20 border border-zinc-200/50 dark:border-zinc-400/40">
                        <Label className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">პირობები</Label>
                        <p className="mt-1 text-sm text-foreground whitespace-pre-line">{scheduleTemplate.conditions}</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>თანამშრომლის ისტორია</CardTitle>
                {canManage && (
                  <Dialog open={isHistoryDialogOpen} onOpenChange={setIsHistoryDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        ცვლილების დამატება
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>ცვლილების დამატება</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleAddHistory} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="change_type">ცვლილების ტიპი *</Label>
                            <Select value={changeType} onValueChange={setChangeType} required>
                              <SelectTrigger>
                                <SelectValue placeholder="აირჩიეთ ტიპი" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="promotion">დაწინაურება</SelectItem>
                                <SelectItem value="position_change">პოზიციის ცვლილება</SelectItem>
                                <SelectItem value="salary_change">ხელფასის ცვლილება</SelectItem>
                                <SelectItem value="department_change">დეპარტამენტის ცვლილება</SelectItem>
                                <SelectItem value="termination">გათავისუფლება</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="effective_date">ძალაში შესვლის თარიღი *</Label>
                            <Input id="effective_date" name="effective_date" type="date" required />
                            <p className="text-xs text-muted-foreground">
                              თუ თარიღი მომავალშია, ცვლილება დაიგეგმება და ავტომატურად გააქტიურდება ამ თარიღს.
                            </p>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="previous_position">მიმდინარე პოზიცია</Label>
                            <Select name="previous_position" defaultValue={employee.position}>
                              <SelectTrigger>
                                <SelectValue placeholder="აირჩიეთ პოზიცია" />
                              </SelectTrigger>
                              <SelectContent position="popper" className="max-h-[300px]">
                                {positions.map((pos) => (
                                  <SelectItem key={pos.id} value={pos.title}>
                                    {pos.title}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="new_position">ახალი პოზიცია</Label>
                            <Select name="new_position">
                              <SelectTrigger>
                                <SelectValue placeholder="აირჩიეთ პოზიცია" />
                              </SelectTrigger>
                              <SelectContent position="popper" className="max-h-[300px]">
                                {positions.map((pos) => (
                                  <SelectItem key={pos.id} value={pos.title}>
                                    {pos.title}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="previous_department">მიმდინარე დეპარტამენტი</Label>
                            <Select name="previous_department" defaultValue={employee.department || ""}>
                              <SelectTrigger>
                                <SelectValue placeholder="აირჩიეთ დეპარტამენტი" />
                              </SelectTrigger>
                              <SelectContent position="popper" className="max-h-[300px]">
                                {departments.map((dept) => (
                                  <SelectItem key={dept.id} value={dept.name}>
                                    {dept.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="new_department">ახალი დეპარტამენტი</Label>
                            <Select name="new_department">
                              <SelectTrigger>
                                <SelectValue placeholder="აირჩიეთ დეპარტამენტი" />
                              </SelectTrigger>
                              <SelectContent position="popper" className="max-h-[300px]">
                                {departments.map((dept) => (
                                  <SelectItem key={dept.id} value={dept.name}>
                                    {dept.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="previous_salary">წინა ხელფასი</Label>
                            <Input id="previous_salary" name="previous_salary" type="number" step="0.01" defaultValue={employee.salary || ''} />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="new_salary">ახალი ხელფასი</Label>
                            <Input id="new_salary" name="new_salary" type="number" step="0.01" />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="reason">მიზეზი</Label>
                          <Input id="reason" name="reason" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="notes">შენიშვნები</Label>
                          <Textarea id="notes" name="notes" />
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button type="button" variant="outline" onClick={() => setIsHistoryDialogOpen(false)}>
                            გაუქმება
                          </Button>
                          <Button type="submit">შენახვა</Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                )}
              </CardHeader>
              <CardContent>
                {(() => {
                  const scheduled = history.filter((h) => h.status === 'scheduled');
                  const others = history.filter((h) => h.status !== 'scheduled');
                  const renderItem = (item: EmployeeHistory) => {
                    const statusBadge =
                      item.status === 'scheduled' ? (
                        <Badge className="bg-blue-500/15 text-blue-600 border-blue-500/30">
                          <Calendar className="h-3 w-3 mr-1" /> დაგეგმილი
                        </Badge>
                      ) : item.status === 'cancelled' ? (
                        <Badge variant="secondary">გაუქმებული</Badge>
                      ) : (
                        <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-500/30">
                          გააქტიურებული
                        </Badge>
                      );
                    return (
                      <Card key={item.id}>
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex gap-4">
                              <History className="h-5 w-5 mt-1 text-muted-foreground" />
                              <div>
                                <div className="flex items-center gap-2 mb-1 flex-wrap">
                                  <h4 className="font-semibold">{getChangeTypeText(item.change_type)}</h4>
                                  <Badge variant="outline">
                                    {format(new Date(item.effective_date), 'dd/MM/yyyy')}
                                  </Badge>
                                  {statusBadge}
                                </div>
                                <div className="text-sm space-y-1">
                                  {item.previous_position && item.new_position && (
                                    <p>პოზიცია: {item.previous_position} → {item.new_position}</p>
                                  )}
                                  {item.previous_department && item.new_department && (
                                    <p>დეპარტამენტი: {item.previous_department} → {item.new_department}</p>
                                  )}
                                  {item.previous_salary && item.new_salary && (
                                    <p>ხელფასი: {item.previous_salary} ₾ → {item.new_salary} ₾</p>
                                  )}
                                  {item.reason && <p className="text-muted-foreground">მიზეზი: {item.reason}</p>}
                                  {item.notes && <p className="text-muted-foreground">შენიშვნა: {item.notes}</p>}
                                </div>
                              </div>
                            </div>
                            {canManage && item.status === 'scheduled' && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleCancelScheduled(item.id)}
                              >
                                გაუქმება
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  };

                  return (
                    <div className="space-y-6">
                      {scheduled.length > 0 && (
                        <div className="space-y-3">
                          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
                            მომავალი ცვლილებები ({scheduled.length})
                          </h3>
                          <div className="space-y-4">{scheduled.map(renderItem)}</div>
                        </div>
                      )}
                      <div className="space-y-3">
                        {scheduled.length > 0 && (
                          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
                            ისტორია
                          </h3>
                        )}
                        <div className="space-y-4">{others.map(renderItem)}</div>
                      </div>
                      {history.length === 0 && (
                        <p className="text-center text-muted-foreground py-8">
                          ცვლილებები არ მოიძებნა
                        </p>
                      )}
                    </div>
                  );
                })()}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="contracts" className="space-y-4">
            <Tabs defaultValue="list" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="list">სია</TabsTrigger>
                {canManage && <TabsTrigger value="generate">გენერაცია</TabsTrigger>}
                <TabsTrigger value="sign">ხელმოწერა</TabsTrigger>
              </TabsList>

              <TabsContent value="list">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>ხელშეკრულებები</CardTitle>
                    {canManage && (
                      <Dialog open={isContractDialogOpen} onOpenChange={setIsContractDialogOpen}>
                        <DialogTrigger asChild>
                          <Button>
                            <Plus className="h-4 w-4 mr-2" />
                            ახალი ხელშეკრულება
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>ახალი ხელშეკრულება</DialogTitle>
                          </DialogHeader>
                          <form onSubmit={handleAddContract} className="space-y-4">
                            <div className="space-y-2">
                              <Label htmlFor="contract_file">ხელშეკრულების ფაილი (Word/PDF)</Label>
                              <div className="flex items-center gap-2">
                                <Input
                                  id="contract_file"
                                  type="file"
                                  accept=".pdf,.doc,.docx"
                                  onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                                />
                                {selectedFile && (
                                  <Badge variant="outline" className="whitespace-nowrap">
                                    {selectedFile.name}
                                  </Badge>
                                )}
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="contract_type">ხელშეკრულების ტიპი</Label>
                                <Select name="contract_type" required>
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="permanent">უვადო</SelectItem>
                                    <SelectItem value="fixed_term">ვადიანი</SelectItem>
                                    <SelectItem value="probation">გამოსაცდელი</SelectItem>
                                    <SelectItem value="freelance">ფრილანსერი</SelectItem>
                                    <SelectItem value="intern">სტაჟიორი</SelectItem>
                                    <SelectItem value="service">მომსახურება</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="contract_number">ხელშეკრულების ნომერი</Label>
                                <Input id="contract_number" name="contract_number" />
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="start_date">დაწყების თარიღი</Label>
                                <Input id="start_date" name="start_date" type="date" required />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="end_date">დასრულების თარიღი</Label>
                                <Input id="end_date" name="end_date" type="date" />
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="position">პოზიცია</Label>
                                <Input id="position" name="position" defaultValue={employee?.position} required />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="salary">ხელფასი</Label>
                                <Input id="salary" name="salary" type="number" step="0.01" defaultValue={employee?.salary || ''} required />
                              </div>
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="terms">პირობები</Label>
                              <Textarea id="terms" name="terms" />
                            </div>
                            <div className="flex justify-end gap-2">
                              <Button type="button" variant="outline" onClick={() => setIsContractDialogOpen(false)}>
                                გაუქმება
                              </Button>
                              <Button type="submit" disabled={uploadingFile}>
                                {uploadingFile ? 'იტვირთება...' : 'შენახვა'}
                              </Button>
                            </div>
                          </form>
                        </DialogContent>
                      </Dialog>
                    )}
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {contracts.map((contract) => (
                        <Card key={contract.id}>
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex gap-4 flex-1">
                                <FileText className="h-5 w-5 mt-1 text-muted-foreground" />
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <h4 className="font-semibold">{getContractTypeText(contract.contract_type)}</h4>
                                    {contract.contract_number && (
                                      <span className="text-sm text-muted-foreground">№ {contract.contract_number}</span>
                                    )}
                                    <Badge variant={getStatusColor(contract.status)}>
                                      {contract.status === 'active' ? 'აქტიური' : contract.status === 'expired' ? 'ვადაგასული' : 'შეწყვეტილი'}
                                    </Badge>
                                  </div>
                                  <div className="text-sm space-y-1">
                                    <p>პოზიცია: {contract.position}</p>
                                    <p>ხელფასი: {contract.salary} ₾</p>
                                    <p>
                                      პერიოდი: {format(new Date(contract.start_date), 'dd/MM/yyyy')}
                                      {contract.end_date && ` - ${format(new Date(contract.end_date), 'dd/MM/yyyy')}`}
                                    </p>
                                    {contract.terms && <p className="text-muted-foreground">{contract.terms}</p>}
                                    {contract.file_url && (
                                      <div className="flex items-center gap-2 mt-2">
                                        <Badge variant="outline" className="gap-1">
                                          <FileText className="h-3 w-3" />
                                          ფაილი მიმაგრებულია
                                        </Badge>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                              {contract.file_url && (
                                <div className="flex flex-wrap gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleDownloadContract(contract.file_url!)}
                                  >
                                    <Download className="h-4 w-4" />
                                  </Button>
                                  {canManage && (
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => handleDeleteContractFile(contract.id, contract.file_url!)}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  )}
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                      {contracts.length === 0 && (
                        <p className="text-center text-muted-foreground py-8">
                          ხელშეკრულებები არ მოიძებნა
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {canManage && (
                <TabsContent value="generate">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Sparkles className="h-5 w-5" />
                        ხელშეკრულების AI გენერაცია
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <form id="generate-contract-form" onSubmit={handleGenerateContract} className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="template_select">შაბლონი (არასავალდებულო)</Label>
                          <Select 
                            value={selectedTemplate} 
                            onValueChange={setSelectedTemplate}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="აირჩიეთ შაბლონი ან გენერირება AI-ით" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="no-template">AI გენერაცია (შაბლონის გარეშე)</SelectItem>
                              {contractTemplates.map((template) => (
                                <SelectItem key={template.id} value={template.id}>
                                  {template.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {selectedTemplate && (
                            <p className="text-sm text-muted-foreground">
                              შაბლონი შეივსება ქვემოთ მითითებული მონაცემებით
                            </p>
                          )}
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="gen_contract_type">ხელშეკრულების ტიპი</Label>
                            <Select name="gen_contract_type" required>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="permanent">უვადო</SelectItem>
                                <SelectItem value="fixed_term">ვადიანი</SelectItem>
                                <SelectItem value="probation">გამოსაცდელი</SelectItem>
                                <SelectItem value="freelance">ფრილანსერი</SelectItem>
                                <SelectItem value="intern">სტაჟიორი</SelectItem>
                                <SelectItem value="service">მომსახურება</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="gen_position">პოზიცია</Label>
                            <Input id="gen_position" name="gen_position" defaultValue={employee?.position} required />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="gen_salary">ხელფასი</Label>
                            <Input id="gen_salary" name="gen_salary" type="number" step="0.01" defaultValue={employee?.salary || ''} required />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="gen_start_date">დაწყების თარიღი</Label>
                            <Input id="gen_start_date" name="gen_start_date" type="date" required />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="gen_end_date">დასრულების თარიღი (არასავალდებულო)</Label>
                          <Input id="gen_end_date" name="gen_end_date" type="date" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="gen_terms">დამატებითი პირობები (არასავალდებულო)</Label>
                          <Textarea id="gen_terms" name="gen_terms" rows={4} placeholder="მიუთითეთ დამატებითი პირობები რომლებიც უნდა შედიოდეს ხელშეკრულებაში..." />
                        </div>
                        <Button type="submit" disabled={generatingContract} className="w-full">
                          {generatingContract ? 'გენერირდება...' : selectedTemplate ? 'გენერაცია შაბლონიდან' : 'გენერაცია AI-ით'}
                        </Button>
                      </form>

                      {generatedContract && (
                        <div className="mt-6 space-y-4">
                          <div className="space-y-2">
                            <Label>გენერირებული ხელშეკრულება</Label>
                            <Textarea 
                              value={generatedContract} 
                              onChange={(e) => setGeneratedContract(e.target.value)}
                              rows={20}
                              className="font-mono text-sm"
                            />
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <Button onClick={handleSaveGeneratedContract} className="flex-1">
                              შენახვა
                            </Button>
                            <Button variant="outline" onClick={handleDownloadGeneratedContract} className="flex-1">
                              <Download className="h-4 w-4 mr-2" />
                              ჩამოტვირთვა
                            </Button>
                            <Button variant="outline" onClick={() => setGeneratedContract("")}>
                              გასუფთავება
                            </Button>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              )}

              <TabsContent value="sign">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <PenTool className="h-5 w-5" />
                      ხელშეკრულებაზე ხელმოწერა
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {contracts.filter(c => c.status === 'active').length === 0 ? (
                        <p className="text-center text-muted-foreground py-8">
                          ხელმოსაწერი აქტიური ხელშეკრულებები არ მოიძებნა
                        </p>
                      ) : (
                        contracts
                          .filter(c => c.status === 'active')
                          .map((contract) => (
                            <Card key={contract.id}>
                              <CardContent className="p-4">
                                <div className="space-y-4">
                                  <div>
                                    <h4 className="font-semibold">{getContractTypeText(contract.contract_type)}</h4>
                                    {contract.contract_number && (
                                      <span className="text-sm text-muted-foreground">№ {contract.contract_number}</span>
                                    )}
                                  </div>
                                  <div className="text-sm space-y-1">
                                    <p>პოზიცია: {contract.position}</p>
                                    <p>ხელფასი: {contract.salary} ₾</p>
                                    <p>თარიღი: {format(new Date(contract.start_date), 'dd/MM/yyyy')}</p>
                                    {contract.terms && (
                                      <div className="mt-2 p-3 bg-muted rounded-md">
                                        <p className="text-xs whitespace-pre-wrap">{contract.terms.substring(0, 300)}...</p>
                                      </div>
                                    )}
                                  </div>
                                  <Button 
                                    onClick={() => setContractToSign(contract)}
                                    className="w-full"
                                  >
                                    <PenTool className="h-4 w-4 mr-2" />
                                    ხელმოწერა
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          ))
                      )}
                    </div>

                    <Dialog open={!!contractToSign} onOpenChange={(open) => !open && setContractToSign(null)}>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>ხელშეკრულებაზე ხელმოწერა</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label>თქვენი ხელმოწერა</Label>
                            <Input 
                              placeholder="მოაწერეთ თქვენი სრული სახელი"
                              value={signatureData}
                              onChange={(e) => setSignatureData(e.target.value)}
                            />
                          </div>
                          <div className="text-sm text-muted-foreground">
                            ხელმოწერით თქვენ ადასტურებთ, რომ წაიკითხეთ და ეთანხმებით ხელშეკრულების პირობებს.
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <Button onClick={handleSignContract} disabled={!signatureData} className="flex-1">
                              დადასტურება
                            </Button>
                            <Button variant="outline" onClick={() => setContractToSign(null)}>
                              გაუქმება
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </TabsContent>

          {canManage && id && (
            <TabsContent value="performance">
              <EmployeePerformanceTab employeeId={id} userId={(employee as any)?.user_id} />
            </TabsContent>
          )}
          <TabsContent value="benefits">
            {id && <EmployeeBenefitsTab employeeId={id} />}
          </TabsContent>
        </Tabs>
      </div>
  );
};

export default EmployeeDetails;