import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { 
  Users, Calendar, FileText, Briefcase, DollarSign, 
  ListChecks, Clock, Banknote
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { PageTransition } from "@/components/PageTransition";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";

interface MenuItem {
  title: string;
  description: string;
  icon: any;
  path: string;
  color: string;
  adminOnly?: boolean;
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { userRole, user } = useAuth();
  const [salary, setSalary] = useState<number | null>(null);

  useEffect(() => {
    const fetchSalary = async () => {
      if (!user?.id) return;
      const { data } = await supabase
        .from('employees')
        .select('salary')
        .eq('user_id', user.id)
        .maybeSingle();
      if (data?.salary) setSalary(data.salary);
    };
    fetchSalary();
  }, [user?.id]);

  const menuItems: MenuItem[] = [
    {
      title: "თანამშრომლები",
      description: "მართეთ თქვენი გუნდის წევრები",
      icon: Users,
      path: "/employees",
      color: "from-blue-500 to-blue-600",
      adminOnly: true,
    },
    {
      title: "დასწრება",
      description: "დროის აღრიცხვა და მონიტორინგი",
      icon: Clock,
      path: "/attendance",
      color: "from-green-500 to-green-600",
    },
    {
      title: "დავალებები",
      description: "დავალებების მართვა",
      icon: ListChecks,
      path: "/tasks",
      color: "from-purple-500 to-purple-600",
    },
    {
      title: "შვებულებები",
      description: "შვებულების მოთხოვნები",
      icon: Calendar,
      path: "/leave-requests",
      color: "from-orange-500 to-orange-600",
    },
    {
      title: "ხელფასი",
      description: "ხელფასის გაანგარიშება",
      icon: DollarSign,
      path: "/payroll",
      color: "from-emerald-500 to-emerald-600",
      adminOnly: true,
    },
    {
      title: "დოკუმენტები",
      description: "ფაილების მართვა",
      icon: FileText,
      path: "/documents",
      color: "from-cyan-500 to-cyan-600",
      adminOnly: true,
    },
    {
      title: "ვაკანსიები",
      description: "ღია პოზიციები",
      icon: Briefcase,
      path: "/vacancies",
      color: "from-pink-500 to-pink-600",
      adminOnly: true,
    },
  ];

  const basicEmployeeItems = ['/leave-requests', '/attendance', '/tasks'];
  const canManage = userRole === 'admin' || userRole === 'hr_manager' || userRole === 'department_manager';

  const filteredMenuItems = menuItems.filter(item => {
    if (canManage) return true;
    return basicEmployeeItems.includes(item.path);
  });

  return (
    <PageTransition>
      <div className="space-y-6 sm:space-y-8 pb-6">
        {/* Welcome Banner */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[hsl(225,45%,13%)] via-[hsl(234,62%,25%)] to-[hsl(250,55%,20%)] p-6 sm:p-8 text-white">
          <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '24px 24px' }} />
          <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-blue-400/15 rounded-full blur-[80px] -translate-y-1/3 translate-x-1/4 animate-[float_8s_ease-in-out_infinite]" />
          <div className="absolute bottom-0 left-0 w-[200px] h-[200px] bg-violet-400/10 rounded-full blur-[60px] translate-y-1/3 -translate-x-1/4 animate-[float_10s_ease-in-out_infinite_reverse]" />
          
          <div className="relative z-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="space-y-2">
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                {new Date().getHours() < 12 ? 'დილა მშვიდობისა' : new Date().getHours() < 18 ? 'შუადღე მშვიდობისა' : 'საღამო მშვიდობისა'} 👋
              </h1>
              <p className="text-white/60 text-sm sm:text-base">
                {new Date().toLocaleDateString('ka-GE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} - აირჩიეთ სასურველი მოდული
              </p>
            </div>
            <div className="flex gap-3">
              <div className="px-4 py-2 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10 text-center">
                <div className="text-lg font-bold">{new Date().toLocaleTimeString('ka-GE', { hour: '2-digit', minute: '2-digit' })}</div>
                <div className="text-[10px] text-white/40 uppercase tracking-wider">დრო</div>
              </div>
            </div>
          </div>
        </div>

        {/* Salary Widget for employees */}
        {salary !== null && !canManage && (
          <Card className="border-border/40 bg-card overflow-hidden">
            <CardContent className="p-5">
              <div className="flex items-center gap-4">
                <div className="w-11 h-11 rounded-xl flex items-center justify-center bg-gradient-to-br from-emerald-500 to-emerald-600 shadow-sm">
                  <Banknote className="h-5 w-5 text-white" />
                </div>
                <div className="space-y-0.5">
                  <p className="text-xs text-muted-foreground">ჩემი ხელფასი</p>
                  <p className="text-xl font-bold text-foreground">
                    {new Intl.NumberFormat('ka-GE', { style: 'currency', currency: 'GEL', minimumFractionDigits: 0 }).format(salary)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Menu Grid */}
        <div>
          <h2 className="text-lg font-semibold mb-4 text-foreground">მოდულები</h2>
          <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredMenuItems.map((item) => (
              <Card
                key={item.path}
                className={cn(
                  "group relative overflow-hidden cursor-pointer border-border/40 bg-card",
                  "transition-all duration-300 hover:shadow-xl hover:shadow-primary/5 hover:border-primary/30 hover:-translate-y-1",
                  "active:scale-[0.97]"
                )}
                onClick={() => navigate(item.path)}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.03] to-accent/[0.03] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <CardContent className="p-5 relative">
                  <div className="flex items-start gap-4">
                    <div className={cn(
                      "w-11 h-11 rounded-xl flex items-center justify-center shrink-0",
                      "bg-gradient-to-br transition-all duration-300 shadow-sm",
                      "group-hover:scale-110 group-hover:shadow-lg",
                      item.color
                    )}>
                      <item.icon className="h-5 w-5 text-white" />
                    </div>
                    <div className="space-y-1.5 min-w-0 flex-1">
                      <h3 className="font-semibold text-sm leading-tight">{item.title}</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">{item.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
