import { useState, useEffect } from "react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Search, Activity, Calendar, Filter, Download } from "lucide-react";
import { format } from "date-fns";
import { XLSX } from '@/lib/xlsxCompat';

interface AuditLog {
  id: string;
  user_id: string | null;
  action_type: string;
  resource_type: string;
  resource_id: string | null;
  details: any;
  ip_address: string | null;
  user_agent: string | null;
  status: string;
  created_at: string;
  user_name: string | null;
  user_avatar: string | null;
}

const AuditLogs = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [actionFilter, setActionFilter] = useState<string>("all");
  const [resourceFilter, setResourceFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  useEffect(() => {
    fetchAuditLogs();
  }, []);

  const fetchAuditLogs = async () => {
    try {
      const { data, error } = await supabase
        .from("audit_logs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(500);

      if (error) throw error;
      
      // Get unique user IDs
      const userIds = [...new Set(data?.map(log => log.user_id).filter(Boolean))] as string[];
      
      // Fetch user data separately
      let userData: Record<string, { full_name: string; avatar_url: string | null }> = {};
      if (userIds.length > 0) {
        const { data: employees } = await supabase
          .from("employees")
          .select("user_id, full_name, avatar_url")
          .in("user_id", userIds);
        
        if (employees) {
          userData = employees.reduce((acc, emp) => ({
            ...acc,
            [emp.user_id]: { full_name: emp.full_name, avatar_url: emp.avatar_url }
          }), {});
        }
      }
      
      const formattedLogs = (data || []).map((log: any) => ({
        ...log,
        user_name: log.user_id && userData[log.user_id] ? userData[log.user_id].full_name : null,
        user_avatar: log.user_id && userData[log.user_id] ? userData[log.user_id].avatar_url : null,
      }));
      
      setLogs(formattedLogs);
    } catch (error: any) {
      toast.error("შეცდომა ლოგების ჩატვირთვისას");
    } finally {
      setLoading(false);
    }
  };

  const getActionBadgeVariant = (action: string) => {
    switch (action.toLowerCase()) {
      case "create":
      case "insert":
        return "default";
      case "update":
      case "edit":
        return "secondary";
      case "delete":
      case "remove":
        return "destructive";
      default:
        return "outline";
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    return status === "success" ? "default" : "destructive";
  };

  const getActionLabel = (action: string) => {
    const labels: Record<string, string> = {
      create: "შექმნა",
      insert: "დამატება",
      update: "განახლება",
      edit: "რედაქტირება",
      delete: "წაშლა",
      remove: "ამოღება",
      login: "შესვლა",
      logout: "გასვლა",
      view: "ნახვა",
      export: "ექსპორტი",
      import: "იმპორტი",
    };
    return labels[action.toLowerCase()] || action;
  };

  const getResourceLabel = (resource: string) => {
    const labels: Record<string, string> = {
      employees: "თანამშრომლები",
      attendance: "დასწრება",
      leaves: "შვებულებები",
      departments: "დეპარტამენტები",
      contracts: "კონტრაქტები",
      payroll: "ხელფასი",
      documents: "დოკუმენტები",
      vacancies: "ვაკანსიები",
      candidates: "კანდიდატები",
      budget: "ბიუჯეტი",
      assets: "აქტივები",
    };
    return labels[resource.toLowerCase()] || resource;
  };

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.user_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.action_type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.resource_type.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesAction = actionFilter === "all" || log.action_type.toLowerCase() === actionFilter;
    const matchesResource = resourceFilter === "all" || log.resource_type.toLowerCase() === resourceFilter;
    const matchesStatus = statusFilter === "all" || log.status === statusFilter;

    const logDate = new Date(log.created_at);
    const matchesStartDate = !startDate || logDate >= new Date(startDate);
    const matchesEndDate = !endDate || logDate <= new Date(endDate);

    return matchesSearch && matchesAction && matchesResource && matchesStatus && matchesStartDate && matchesEndDate;
  });

  const uniqueActions = Array.from(new Set(logs.map((log) => log.action_type.toLowerCase())));
  const uniqueResources = Array.from(new Set(logs.map((log) => log.resource_type.toLowerCase())));

  const exportToExcel = () => {
    if (filteredLogs.length === 0) {
      toast.error("ექსპორტისთვის მონაცემები არ არის");
      return;
    }

    const exportData = filteredLogs.map((log) => ({
      "მომხმარებელი": log.user_name || "სისტემა",
      "ქმედება": getActionLabel(log.action_type),
      "რესურსი": getResourceLabel(log.resource_type),
      "რესურსის ID": log.resource_id || "-",
      "სტატუსი": log.status === "success" ? "წარმატებული" : "შეცდომა",
      "თარიღი": log.created_at ? format(new Date(log.created_at), "dd/MM/yyyy HH:mm:ss") : "-",
      "IP მისამართი": log.ip_address || "-",
      "დეტალები": log.details?.message || "-"
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Audit Logs");
    XLSX.writeFile(wb, `audit_logs_${format(new Date(), "yyyy-MM-dd_HH-mm")}.xlsx`);
    toast.success(`${filteredLogs.length} ჩანაწერი ექსპორტირებულია`);
  };

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
          ცვლილებების მონიტორინგი
        </h1>
        <p className="text-muted-foreground">
          სისტემაში განხორციელებული ყველა ქმედების დეტალური ჩანაწერი
        </p>
      </div>

      <Card className="border-muted/40">
        <CardHeader className="border-b bg-muted/20">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Filter className="h-5 w-5" />
            ფილტრაცია
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-2">
              <Label>ძიება</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="მომხმარებელი, ქმედება..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>ქმედება</Label>
              <Select value={actionFilter} onValueChange={setActionFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  {uniqueActions.map((action) => (
                    <SelectItem key={action} value={action}>
                      {getActionLabel(action)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>რესურსი</Label>
              <Select value={resourceFilter} onValueChange={setResourceFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  {uniqueResources.map((resource) => (
                    <SelectItem key={resource} value={resource}>
                      {getResourceLabel(resource)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>სტატუსი</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  <SelectItem value="success">წარმატებული</SelectItem>
                  <SelectItem value="error">შეცდომა</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>დაწყების თარიღი</Label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>დასრულების თარიღი</Label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="border-b bg-muted/20">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                აქტივობების ისტორია
              </CardTitle>
              <CardDescription className="mt-1">
                სულ {filteredLogs.length} ჩანაწერი
              </CardDescription>
            </div>
            <Button onClick={exportToExcel} variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Excel ექსპორტი
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[200px]">მომხმარებელი</TableHead>
                  <TableHead>ქმედება</TableHead>
                  <TableHead>რესურსი</TableHead>
                  <TableHead>დეტალები</TableHead>
                  <TableHead>სტატუსი</TableHead>
                  <TableHead>თარიღი</TableHead>
                  <TableHead>IP მისამართი</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={log.user_avatar || undefined} />
                          <AvatarFallback>
                            {log.user_name?.charAt(0) || "?"}
                          </AvatarFallback>
                        </Avatar>
                        <span className="font-medium text-sm">
                          {log.user_name || "სისტემა"}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getActionBadgeVariant(log.action_type)}>
                        {getActionLabel(log.action_type)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm font-medium">
                        {getResourceLabel(log.resource_type)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">
                        {log.details?.message || "-"}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadgeVariant(log.status)}>
                        {log.status === "success" ? "✓" : "✗"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        {log.created_at && !isNaN(new Date(log.created_at).getTime()) 
                          ? format(new Date(log.created_at), "dd/MM/yyyy HH:mm")
                          : "-"}
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground font-mono">
                        {log.ip_address || "-"}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AuditLogs;
