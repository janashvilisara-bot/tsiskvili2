import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Building2, Edit, Plus, Star, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { PageTransition } from "@/components/PageTransition";
import { useBranch, Branch } from "@/contexts/BranchContext";
import { BranchHiringStats } from "@/components/BranchHiringStats";

const emptyForm = {
  name: "",
  name_en: "",
  code: "",
  city: "",
  address: "",
  phone: "",
  email: "",
  timezone: "Asia/Tbilisi",
  currency: "GEL",
  description: "",
  is_active: true,
  is_primary: false,
};

export default function BranchManagement() {
  const { refresh } = useBranch();
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editing, setEditing] = useState<Branch | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("branches")
        .select("*")
        .order("is_primary", { ascending: false })
        .order("created_at", { ascending: true });
      if (error) throw error;
      setBranches((data || []) as Branch[]);
    } catch (e: any) {
      toast.error("ფილიალების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const openNew = () => {
    setEditing(null);
    setForm(emptyForm);
    setShowDialog(true);
  };

  const openEdit = (b: Branch) => {
    setEditing(b);
    setForm({
      name: b.name,
      name_en: b.name_en || "",
      code: b.code,
      city: b.city || "",
      address: b.address || "",
      phone: b.phone || "",
      email: b.email || "",
      timezone: b.timezone || "Asia/Tbilisi",
      currency: b.currency || "GEL",
      description: b.description || "",
      is_active: b.is_active,
      is_primary: b.is_primary,
    });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.code.trim()) {
      toast.error("შეავსეთ სავალდებულო ველები");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        name_en: form.name_en.trim() || null,
        code: form.code.trim().toUpperCase(),
        city: form.city.trim() || null,
        address: form.address.trim() || null,
        phone: form.phone.trim() || null,
        email: form.email.trim() || null,
        timezone: form.timezone || "Asia/Tbilisi",
        currency: form.currency || "GEL",
        description: form.description.trim() || null,
        is_active: form.is_active,
        is_primary: form.is_primary,
      };

      if (form.is_primary) {
        await supabase
          .from("branches")
          .update({ is_primary: false })
          .neq("id", editing?.id || "00000000-0000-0000-0000-000000000000");
      }

      if (editing) {
        const { error } = await supabase
          .from("branches")
          .update(payload)
          .eq("id", editing.id);
        if (error) throw error;
        toast.success("ფილიალი განახლდა");
      } else {
        const { error } = await supabase.from("branches").insert([payload]);
        if (error) throw error;
        toast.success("ფილიალი დაემატა");
      }
      setShowDialog(false);
      await load();
      await refresh();
    } catch (e: any) {
      const msg = e?.message || "";
      if (msg.includes("duplicate")) {
        toast.error("ფილიალის კოდი უკვე გამოყენებულია");
      } else {
        toast.error("ფილიალის შენახვა ვერ მოხერხდა");
      }
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (b: Branch) => {
    if (b.is_primary) {
      toast.error("ძირითადი ფილიალის წაშლა შეუძლებელია");
      return;
    }
    if (!confirm(`დარწმუნებული ხართ რომ გსურთ "${b.name}"-ის წაშლა?`)) return;
    try {
      const { error } = await supabase.from("branches").delete().eq("id", b.id);
      if (error) throw error;
      toast.success("ფილიალი წაიშალა");
      await load();
      await refresh();
    } catch (e: any) {
      toast.error("წაშლა ვერ მოხერხდა - შესაძლოა აქვს დაკავშირებული მონაცემები");
    }
  };

  return (
    <PageTransition>
      <div className="p-4 md:p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Building2 className="h-7 w-7 text-primary" />
              ფილიალების მართვა
            </h1>
            <p className="text-muted-foreground mt-1">
              {branches.length} ფილიალი სისტემაში
            </p>
          </div>
          <Button onClick={openNew}>
            <Plus className="h-4 w-4 mr-2" />
            ახალი ფილიალი
          </Button>
        </div>

        <BranchHiringStats />

        {loading ? (
          <div className="text-center py-12 text-muted-foreground">იტვირთება...</div>
        ) : branches.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12 text-muted-foreground">
              <Building2 className="h-12 w-12 mx-auto mb-3 opacity-40" />
              ფილიალები ჯერ არ არის დამატებული
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {branches.map((b) => (
              <Card key={b.id} className={!b.is_active ? "opacity-60" : ""}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Building2 className="h-5 w-5 text-primary shrink-0" />
                        <span className="truncate">{b.name}</span>
                      </CardTitle>
                      <CardDescription className="mt-1 flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="font-mono text-xs">
                          {b.code}
                        </Badge>
                        {b.is_primary && (
                          <Badge className="bg-amber-500/15 text-amber-700 dark:text-amber-400 hover:bg-amber-500/15 gap-1">
                            <Star className="h-3 w-3" /> ძირითადი
                          </Badge>
                        )}
                        {!b.is_active && <Badge variant="secondary">გამორთული</Badge>}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  {b.city && (
                    <div className="text-muted-foreground">📍 {b.city}</div>
                  )}
                  {b.address && (
                    <div className="text-muted-foreground line-clamp-2">
                      {b.address}
                    </div>
                  )}
                  {b.phone && <div className="text-muted-foreground">📞 {b.phone}</div>}
                  {b.email && (
                    <div className="text-muted-foreground truncate">
                      ✉️ {b.email}
                    </div>
                  )}
                  <div className="flex gap-2 pt-3">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => openEdit(b)}
                    >
                      <Edit className="h-3.5 w-3.5 mr-1.5" />
                      რედაქტ.
                    </Button>
                    {!b.is_primary && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(b)}
                      >
                        <Trash2 className="h-3.5 w-3.5 text-destructive" />
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editing ? "ფილიალის რედაქტირება" : "ახალი ფილიალი"}
              </DialogTitle>
              <DialogDescription>
                შეიყვანეთ ფილიალის მონაცემები
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <Label>დასახელება *</Label>
                  <Input
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="მაგ: თბილისის ფილიალი"
                  />
                </div>
                <div>
                  <Label>დასახელება (EN)</Label>
                  <Input
                    value={form.name_en}
                    onChange={(e) => setForm({ ...form, name_en: e.target.value })}
                    placeholder="Tbilisi Branch"
                  />
                </div>
                <div>
                  <Label>კოდი *</Label>
                  <Input
                    value={form.code}
                    onChange={(e) => setForm({ ...form, code: e.target.value })}
                    placeholder="TBS"
                    className="font-mono uppercase"
                  />
                </div>
                <div>
                  <Label>ქალაქი</Label>
                  <Input
                    value={form.city}
                    onChange={(e) => setForm({ ...form, city: e.target.value })}
                    placeholder="თბილისი"
                  />
                </div>
                <div>
                  <Label>ტელეფონი</Label>
                  <Input
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="+995 32 ..."
                  />
                </div>
                <div className="col-span-2">
                  <Label>მისამართი</Label>
                  <Input
                    value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })}
                    placeholder="რუსთაველის გამზ. 1"
                  />
                </div>
                <div className="col-span-2">
                  <Label>ელფოსტა</Label>
                  <Input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="branch@company.ge"
                  />
                </div>
                <div>
                  <Label>საათობრივი სარტყელი</Label>
                  <Input
                    value={form.timezone}
                    onChange={(e) => setForm({ ...form, timezone: e.target.value })}
                  />
                </div>
                <div>
                  <Label>ვალუტა</Label>
                  <Input
                    value={form.currency}
                    onChange={(e) =>
                      setForm({ ...form, currency: e.target.value.toUpperCase() })
                    }
                  />
                </div>
                <div className="col-span-2">
                  <Label>აღწერა</Label>
                  <Textarea
                    value={form.description}
                    onChange={(e) =>
                      setForm({ ...form, description: e.target.value })
                    }
                    rows={2}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between rounded-lg border p-3">
                <div>
                  <Label className="text-sm">აქტიური</Label>
                  <p className="text-xs text-muted-foreground">
                    გამორთული ფილიალი დამალულია
                  </p>
                </div>
                <Switch
                  checked={form.is_active}
                  onCheckedChange={(c) => setForm({ ...form, is_active: c })}
                />
              </div>

              <div className="flex items-center justify-between rounded-lg border p-3">
                <div>
                  <Label className="text-sm flex items-center gap-1.5">
                    <Star className="h-3.5 w-3.5 text-amber-500" />
                    ძირითადი ფილიალი
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    ახალი მონაცემები ნაგულისხმევად აქ ჩაიწერება
                  </p>
                </div>
                <Switch
                  checked={form.is_primary}
                  onCheckedChange={(c) => setForm({ ...form, is_primary: c })}
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowDialog(false)}>
                გაუქმება
              </Button>
              <Button onClick={handleSave} disabled={saving}>
                {saving ? "ინახება..." : "შენახვა"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </PageTransition>
  );
}
