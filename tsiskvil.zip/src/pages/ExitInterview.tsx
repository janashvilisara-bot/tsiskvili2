import { useState, useEffect } from "react";
import {
  LogOut, ClipboardCheck, MessageSquare, Users, TrendingDown,
  Star, RefreshCw, Building2, Calendar, CheckCircle2, AlertTriangle,
  ChevronRight, Send, Plus, BarChart3
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

const EXIT_REASONS = [
  "უკეთესი ანაზღაურება", "კარიერული განვითარება", "სამუშაო გარემო",
  "მენეჯმენტი", "Work-Life Balance", "გადაადგილება", "პირადი მიზეზები", "სხვა"
];

const OFFBOARDING_CHECKLIST = [
  { id: "equipment", label: "აღჭურვილობის დაბრუნება (ლეპტოპი, ტელეფონი, ბეჯი)" },
  { id: "access", label: "სისტემის წვდომის გაუქმება" },
  { id: "email", label: "ელ-ფოსტის გადამისამართება" },
  { id: "knowledge", label: "ცოდნის გადაცემა / დოკუმენტაცია" },
  { id: "final_pay", label: "საბოლოო ანგარიშსწორება" },
  { id: "benefits", label: "ბენეფიტების შეწყვეტა" },
  { id: "interview", label: "გასვლის ინტერვიუ ჩატარება" },
  { id: "references", label: "რეფერენსის მომზადება" },
];

export default function ExitInterview() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ terminated: 0, exitInterviews: 0, avgRating: 0, topReason: "" });
  const [reasonStats, setReasonStats] = useState<{ reason: string; count: number; percentage: number }[]>([]);
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});
  const [interviewForm, setInterviewForm] = useState({
    employeeName: "", department: "", reason: "", rating: "3",
    whatLiked: "", whatImprove: "", recommendation: "", additionalNotes: ""
  });
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { count: terminatedCount } = await supabase
        .from('employees')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'terminated');

      const terminated = terminatedCount || 0;

      // Simulated exit interview analytics
      const reasons = EXIT_REASONS.map(reason => ({
        reason,
        count: Math.floor(Math.random() * Math.max(1, terminated / 3)) + 1,
        percentage: 0
      }));
      const totalReasons = reasons.reduce((s, r) => s + r.count, 0);
      reasons.forEach(r => r.percentage = Math.round((r.count / totalReasons) * 100));
      reasons.sort((a, b) => b.count - a.count);

      setReasonStats(reasons);
      setStats({
        terminated,
        exitInterviews: Math.floor(terminated * 0.7),
        avgRating: 3.2 + Math.random() * 0.8,
        topReason: reasons[0]?.reason || "N/A"
      });
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckItem = (id: string) => {
    setCheckedItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const completedSteps = Object.values(checkedItems).filter(Boolean).length;
  const totalSteps = OFFBOARDING_CHECKLIST.length;

  const handleSubmitInterview = () => {
    if (!interviewForm.employeeName || !interviewForm.reason) {
      toast({ title: "შეავსეთ სავალდებულო ველები", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      toast({ title: "გასვლის ინტერვიუ შენახულია ✅", description: `${interviewForm.employeeName}-ის ინტერვიუ წარმატებით დაფიქსირდა.` });
      setInterviewForm({ employeeName: "", department: "", reason: "", rating: "3", whatLiked: "", whatImprove: "", recommendation: "", additionalNotes: "" });
      setSubmitting(false);
    }, 500);
  };

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-orange-500 via-red-500 to-rose-600 shadow-xl shadow-red-500/30">
                <LogOut className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground">Offboarding</h1>
                <p className="text-muted-foreground mt-1">გასვლის ინტერვიუ და ოფბორდინგის პროცესი</p>
              </div>
            </div>
            <Button variant="outline" size="icon" onClick={fetchData}>
              <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
            </Button>
          </div>

          {/* KPIs */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { title: "გათავისუფლებული", value: stats.terminated, icon: Users, bgColor: "bg-red-500/10" },
              { title: "ინტერვიუ ჩატარებული", value: stats.exitInterviews, icon: MessageSquare, bgColor: "bg-blue-500/10" },
              { title: "საშ. შეფასება", value: stats.avgRating.toFixed(1) + "/5", icon: Star, bgColor: "bg-amber-500/10" },
              { title: "მთავარი მიზეზი", value: stats.topReason, icon: TrendingDown, bgColor: "bg-violet-500/10", isText: true },
            ].map((kpi, i) => (
              <Card key={i} className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in" style={{ animationDelay: `${i * 60}ms` }}>
                <CardContent className="p-5">
                  <div className={cn("p-2.5 rounded-xl w-fit mb-3", kpi.bgColor)}>
                    <kpi.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className={cn("font-bold", (kpi as any).isText ? "text-base" : "text-2xl")}>
                    {loading ? <div className="h-7 w-16 bg-muted animate-pulse rounded" /> : kpi.value}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{kpi.title}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Tabs defaultValue="analytics">
            <TabsList className="grid w-full grid-cols-3 max-w-lg">
              <TabsTrigger value="analytics">ანალიტიკა</TabsTrigger>
              <TabsTrigger value="interview">ინტერვიუ</TabsTrigger>
              <TabsTrigger value="checklist">ჩექლისტი</TabsTrigger>
            </TabsList>

            {/* Analytics */}
            <TabsContent value="analytics" className="space-y-6 mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5 text-primary" />
                      წასვლის მიზეზები
                    </CardTitle>
                    <CardDescription>გასვლის ინტერვიუების ანალიზი</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {loading ? Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="h-10 bg-muted animate-pulse rounded" />
                    )) : reasonStats.map((r, i) => (
                      <div key={i} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-medium">{r.reason}</span>
                          <span className="text-muted-foreground">{r.percentage}%</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div className={cn("h-2 rounded-full transition-all duration-700",
                            i === 0 ? "bg-red-500" : i < 3 ? "bg-amber-500" : "bg-muted-foreground/30"
                          )} style={{ width: `${r.percentage}%` }} />
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-amber-500" />
                      რეკომენდაციები
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {reasonStats.slice(0, 3).map((r, i) => (
                      <div key={i} className={cn("p-4 rounded-xl border",
                        i === 0 ? "border-red-200 bg-red-50/50 dark:border-red-900 dark:bg-red-950/20" :
                        "border-amber-200 bg-amber-50/50 dark:border-amber-900 dark:bg-amber-950/20"
                      )}>
                        <p className="font-medium text-sm mb-1">{r.reason} ({r.percentage}%)</p>
                        <p className="text-xs text-muted-foreground">
                          {r.reason === "უკეთესი ანაზღაურება" && "გადახედეთ საბაზრო ანაზღაურებას და კონკურენტულ კომპენსაციას."}
                          {r.reason === "კარიერული განვითარება" && "დანერგეთ კარიერული გზის პროგრამა და მენტორინგი."}
                          {r.reason === "სამუშაო გარემო" && "ჩაატარეთ სამუშაო გარემოს კმაყოფილების გამოკითხვა."}
                          {r.reason === "მენეჯმენტი" && "განახორციელეთ მენეჯერების ტრენინგი და 360° შეფასება."}
                          {r.reason === "Work-Life Balance" && "განიხილეთ მოქნილი გრაფიკის და ჰიბრიდული მუშაობის შესაძლებლობები."}
                          {!["უკეთესი ანაზღაურება", "კარიერული განვითარება", "სამუშაო გარემო", "მენეჯმენტი", "Work-Life Balance"].includes(r.reason) && "გააანალიზეთ ინდივიდუალური შემთხვევები და მოიძიეთ სისტემური პრობლემები."}
                        </p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Exit Interview Form */}
            <TabsContent value="interview" className="space-y-6 mt-6">
              <Card className="border-border/50 bg-card/80 backdrop-blur-xl max-w-2xl mx-auto">
                <CardHeader>
                  <CardTitle>გასვლის ინტერვიუ</CardTitle>
                  <CardDescription>შეავსეთ გათავისუფლებული თანამშრომლის ინტერვიუ</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>თანამშრომლის სახელი *</Label>
                      <Input value={interviewForm.employeeName} onChange={e => setInterviewForm(f => ({ ...f, employeeName: e.target.value }))} />
                    </div>
                    <div className="space-y-2">
                      <Label>დეპარტამენტი</Label>
                      <Input value={interviewForm.department} onChange={e => setInterviewForm(f => ({ ...f, department: e.target.value }))} />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>წასვლის მიზეზი *</Label>
                      <Select value={interviewForm.reason} onValueChange={v => setInterviewForm(f => ({ ...f, reason: v }))}>
                        <SelectTrigger><SelectValue placeholder="აირჩიეთ" /></SelectTrigger>
                        <SelectContent>
                          {EXIT_REASONS.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>საერთო შეფასება (1-5)</Label>
                      <Select value={interviewForm.rating} onValueChange={v => setInterviewForm(f => ({ ...f, rating: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {[1,2,3,4,5].map(n => <SelectItem key={n} value={n.toString()}>{n} - {n <= 2 ? 'ცუდი' : n === 3 ? 'საშუალო' : 'კარგი'}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>რა მოგწონდათ კომპანიაში?</Label>
                    <Textarea value={interviewForm.whatLiked} onChange={e => setInterviewForm(f => ({ ...f, whatLiked: e.target.value }))} rows={2} />
                  </div>
                  <div className="space-y-2">
                    <Label>რა უნდა გაუმჯობესდეს?</Label>
                    <Textarea value={interviewForm.whatImprove} onChange={e => setInterviewForm(f => ({ ...f, whatImprove: e.target.value }))} rows={2} />
                  </div>
                  <div className="space-y-2">
                    <Label>დამატებითი კომენტარი</Label>
                    <Textarea value={interviewForm.additionalNotes} onChange={e => setInterviewForm(f => ({ ...f, additionalNotes: e.target.value }))} rows={2} />
                  </div>

                  <Button onClick={handleSubmitInterview} disabled={submitting} className="w-full" size="lg">
                    <Send className="h-4 w-4 mr-2" /> შენახვა
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Offboarding Checklist */}
            <TabsContent value="checklist" className="space-y-6 mt-6">
              <Card className="border-border/50 bg-card/80 backdrop-blur-xl max-w-2xl mx-auto">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <ClipboardCheck className="h-5 w-5 text-primary" />
                        ოფბორდინგის ჩექლისტი
                      </CardTitle>
                      <CardDescription>თანამშრომლის გასვლის პროცესის ნაბიჯები</CardDescription>
                    </div>
                    <Badge variant={completedSteps === totalSteps ? "default" : "secondary"}>
                      {completedSteps}/{totalSteps}
                    </Badge>
                  </div>
                  {/* Progress */}
                  <div className="w-full bg-muted rounded-full h-2 mt-4">
                    <div className={cn("h-2 rounded-full transition-all duration-500",
                      completedSteps === totalSteps ? "bg-emerald-500" : "bg-primary"
                    )} style={{ width: `${(completedSteps / totalSteps) * 100}%` }} />
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  {OFFBOARDING_CHECKLIST.map((item) => (
                    <label
                      key={item.id}
                      className={cn(
                        "flex items-center gap-3 p-4 rounded-xl cursor-pointer transition-all",
                        checkedItems[item.id] ? "bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900" : "bg-muted/50 hover:bg-muted border border-transparent"
                      )}
                    >
                      <Checkbox
                        checked={!!checkedItems[item.id]}
                        onCheckedChange={() => handleCheckItem(item.id)}
                      />
                      <span className={cn("text-sm", checkedItems[item.id] && "line-through text-muted-foreground")}>
                        {item.label}
                      </span>
                      {checkedItems[item.id] && <CheckCircle2 className="h-4 w-4 text-emerald-500 ml-auto" />}
                    </label>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </PageTransition>
  );
}
