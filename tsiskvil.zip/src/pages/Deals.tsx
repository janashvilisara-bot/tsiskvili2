import { useState, useEffect } from "react";
import { Plus, Search, TrendingUp, Edit, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { z } from "zod";

const dealSchema = z.object({
  title: z.string().min(2, { message: "სათაური ძალიან მოკლეა" }),
  contact_id: z.string().uuid({ message: "აირჩიეთ კონტაქტი" }),
  amount: z.string().min(1, { message: "შეიყვანეთ თანხა" }),
  status: z.enum(['pending', 'in_progress', 'won', 'lost']),
  probability: z.string().optional(),
  expected_close_date: z.string().optional(),
  description: z.string().optional(),
});

interface Deal {
  id: string;
  title: string;
  contact_id: string;
  amount: number;
  status: string;
  probability: number | null;
  expected_close_date: string | null;
  description: string | null;
  contacts?: {
    company_name: string;
  };
}

interface Contact {
  id: string;
  company_name: string;
}

export default function Deals() {
  const { user, userRole } = useAuth();
  const [deals, setDeals] = useState<Deal[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [editingDeal, setEditingDeal] = useState<Deal | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const canManageAllDeals = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    fetchDeals();
    fetchContacts();
  }, []);

  const fetchDeals = async () => {
    try {
      const { data, error } = await supabase
        .from('deals')
        .select('*, contacts(company_name)')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDeals(data || []);
    } catch (error: any) {
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    }
  };

  const fetchContacts = async () => {
    try {
      const { data, error } = await supabase
        .from('contacts')
        .select('id, company_name')
        .eq('status', 'active')
        .order('company_name');

      if (error) throw error;
      setContacts(data || []);
    } catch (error: any) {
      console.error('Error fetching contacts:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors({});
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const data = dealSchema.parse({
        title: formData.get('title'),
        contact_id: formData.get('contact_id'),
        amount: formData.get('amount'),
        status: formData.get('status'),
        probability: formData.get('probability'),
        expected_close_date: formData.get('expected_close_date'),
        description: formData.get('description'),
      });

      const payload: any = {
        ...data,
        amount: parseFloat(data.amount),
        probability: data.probability ? parseInt(data.probability) : null,
        expected_close_date: data.expected_close_date || null,
        created_by: user?.id,
      };

      if (editingDeal) {
        const { error } = await supabase
          .from('deals')
          .update(payload)
          .eq('id', editingDeal.id);

        if (error) throw error;
        toast.success('გარიგება განახლდა');
      } else {
        const { error } = await supabase
          .from('deals')
          .insert([payload]);

        if (error) throw error;
        toast.success('გარიგება დამატებულია');
      }

      setIsDialogOpen(false);
      setEditingDeal(null);
      fetchDeals();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
      } else {
        toast.error(error.message || 'შეცდომა მოხდა');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('დარწმუნებული ხართ რომ გსურთ წაშლა?')) return;

    try {
      const { error } = await supabase
        .from('deals')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast.success('გარიგება წაიშალა');
      fetchDeals();
    } catch (error: any) {
      toast.error('წაშლა ვერ მოხერხდა');
    }
  };

  const filteredDeals = deals.filter((deal) =>
    deal.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (deal.contacts?.company_name || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalValue = filteredDeals.reduce((sum, deal) => sum + deal.amount, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">გარიგებები</h1>
          <p className="mt-2 text-muted-foreground">თვალყური ადევნეთ თქვენს სამომავლო პროექტებს</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) {
            setEditingDeal(null);
            setErrors({});
          }
        }}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              ახალი გარიგება
            </Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingDeal ? 'გარიგების რედაქტირება' : 'ახალი გარიგების დამატება'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">სათაური *</Label>
                <Input
                  id="title"
                  name="title"
                  defaultValue={editingDeal?.title}
                  placeholder="შეიყვანეთ გარიგების სათაური"
                  required
                />
                {errors.title && <p className="mt-1 text-sm text-destructive">{errors.title}</p>}
              </div>
              <div>
                <Label htmlFor="contact_id">კონტაქტი *</Label>
                <Select name="contact_id" defaultValue={editingDeal?.contact_id} required>
                  <SelectTrigger>
                    <SelectValue placeholder="აირჩიეთ კონტაქტი" />
                  </SelectTrigger>
                  <SelectContent>
                    {contacts.map((contact) => (
                      <SelectItem key={contact.id} value={contact.id}>
                        {contact.company_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.contact_id && <p className="mt-1 text-sm text-destructive">{errors.contact_id}</p>}
              </div>
              <div>
                <Label htmlFor="amount">ღირებულება (₾) *</Label>
                <Input
                  id="amount"
                  name="amount"
                  type="number"
                  step="0.01"
                  defaultValue={editingDeal?.amount}
                  placeholder="0.00"
                  required
                />
                {errors.amount && <p className="mt-1 text-sm text-destructive">{errors.amount}</p>}
              </div>
              <div>
                <Label htmlFor="status">სტატუსი *</Label>
                <Select name="status" defaultValue={editingDeal?.status || 'pending'}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">მოლოდინში</SelectItem>
                    <SelectItem value="in_progress">მიმდინარე</SelectItem>
                    <SelectItem value="won">მოგებული</SelectItem>
                    <SelectItem value="lost">დაკარგული</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="probability">ალბათობა (%)</Label>
                <Input
                  id="probability"
                  name="probability"
                  type="number"
                  min="0"
                  max="100"
                  defaultValue={editingDeal?.probability || ''}
                  placeholder="0-100"
                />
              </div>
              <div>
                <Label htmlFor="expected_close_date">მოსალოდნელი დახურვის თარიღი</Label>
                <Input
                  id="expected_close_date"
                  name="expected_close_date"
                  type="date"
                  defaultValue={editingDeal?.expected_close_date || ''}
                />
              </div>
              <div>
                <Label htmlFor="description">აღწერა</Label>
                <Textarea
                  id="description"
                  name="description"
                  defaultValue={editingDeal?.description || ''}
                  placeholder="დამატებითი ინფორმაცია..."
                  rows={3}
                />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'მიმდინარეობს...' : editingDeal ? 'განახლება' : 'დამატება'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="bg-gradient-to-br from-primary to-accent text-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <TrendingUp className="h-5 w-5" />
            სულ გარიგებები
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-4xl font-bold">₾{totalValue.toLocaleString()}</p>
          <p className="mt-2 text-white/80">{filteredDeals.length} აქტიური გარიგება</p>
        </CardContent>
      </Card>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="ძებნა გარიგებების მიხედვით..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {filteredDeals.map((deal) => (
          <Card key={deal.id} className="transition-all hover:shadow-lg">
            <CardContent className="p-6">
              <div className="mb-4 flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-semibold">{deal.title}</h3>
                  <p className="text-sm text-muted-foreground">{deal.contacts?.company_name}</p>
                </div>
                <span className={`rounded-full px-3 py-1 text-xs font-medium ${
                  deal.status === 'won' 
                    ? 'bg-green-100 text-green-700' 
                    : deal.status === 'in_progress'
                    ? 'bg-blue-100 text-blue-700'
                    : deal.status === 'pending'
                    ? 'bg-yellow-100 text-yellow-700'
                    : 'bg-red-100 text-red-700'
                }`}>
                  {deal.status === 'won' ? 'მოგებული' : deal.status === 'in_progress' ? 'მიმდინარე' : deal.status === 'pending' ? 'მოლოდინში' : 'დაკარგული'}
                </span>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">ღირებულება</span>
                  <span className="text-xl font-bold text-primary">₾{deal.amount.toLocaleString()}</span>
                </div>
                {deal.probability !== null && (
                  <>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">ალბათობა</span>
                      <span className="text-sm font-medium">{deal.probability}%</span>
                    </div>
                    <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted">
                      <div 
                        className="h-full bg-primary transition-all"
                        style={{ width: `${deal.probability}%` }}
                      />
                    </div>
                  </>
                )}
              </div>
              <div className="mt-4 flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    setEditingDeal(deal);
                    setIsDialogOpen(true);
                  }}
                >
                  <Edit className="mr-1 h-3 w-3" />
                  რედაქტირება
                </Button>
                {canManageAllDeals && (
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => handleDelete(deal.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredDeals.length === 0 && (
        <div className="flex h-64 items-center justify-center text-muted-foreground">
          გარიგებები არ მოიძებნა
        </div>
      )}
    </div>
  );
}
