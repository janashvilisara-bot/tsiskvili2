import { useEffect, useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Clock, Download, Search, AlertTriangle } from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import * as XLSX from "xlsx";

interface Row {
  id: string;
  date: string;
  check_in: string | null;
  check_out: string | null;
  status: string | null;
  employee_id: string;
  employee_name: string;
  department: string | null;
  position: string | null;
}

export default function AttendanceWithoutSchedule() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [from, setFrom] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().slice(0, 10);
  });
  const [to, setTo] = useState(() => new Date().toISOString().slice(0, 10));

  const load = async () => {
    setLoading(true);
    try {
      // Employees with NO work_schedules row
      const { data: schedEmpIds } = await supabase
        .from("work_schedules")
        .select("employee_id");
      const withSchedule = new Set((schedEmpIds || []).map((r: any) => r.employee_id));

      const { data: emps } = await supabase
        .from("employees")
        .select("id, full_name, department, position")
        .eq("status", "active");

      const noScheduleEmps = (emps || []).filter((e) => !withSchedule.has(e.id));
      if (noScheduleEmps.length === 0) {
        setRows([]);
        return;
      }

      const empMap = new Map(noScheduleEmps.map((e) => [e.id, e]));
      const ids = noScheduleEmps.map((e) => e.id);

      const { data: att } = await supabase
        .from("attendance")
        .select("id, date, check_in, check_out, status, employee_id")
        .in("employee_id", ids)
        .gte("date", from)
        .lte("date", to)
        .order("date", { ascending: false });

      const out: Row[] = (att || []).map((a: any) => {
        const e = empMap.get(a.employee_id) as any;
        return {
          id: a.id,
          date: a.date,
          check_in: a.check_in,
          check_out: a.check_out,
          status: a.status,
          employee_id: a.employee_id,
          employee_name: e?.full_name || "-",
          department: e?.department || null,
          position: e?.position || null,
        };
      });
      setRows(out);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [from, to]);

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter(
      (r) =>
        r.employee_name.toLowerCase().includes(s) ||
        (r.department || "").toLowerCase().includes(s) ||
        (r.position || "").toLowerCase().includes(s)
    );
  }, [rows, search]);

  const exportXlsx = () => {
    const data = filtered.map((r) => ({
      "თარიღი": r.date,
      "თანამშრომელი": r.employee_name,
      "დეპარტამენტი": r.department || "",
      "პოზიცია": r.position || "",
      "შემოსვლა": r.check_in || "",
      "გასვლა": r.check_out || "",
      "სტატუსი": r.status || "",
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "უგრაფიკოები");
    XLSX.writeFile(wb, `attendance_without_schedule_${from}_${to}.xlsx`);
  };

  const uniqueEmployees = new Set(filtered.map((r) => r.employee_id)).size;

  return (
    <PageTransition>
      <div className="container mx-auto py-6 space-y-6">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <AlertTriangle className="h-7 w-7 text-amber-500" />
              დასწრება გრაფიკის გარეშე
            </h1>
            <p className="text-muted-foreground mt-1">
              თანამშრომლების შემოსვლები/გასვლები, რომელთაც სამუშაო გრაფიკი არ აქვთ გაწერილი
            </p>
          </div>
          <Button onClick={exportXlsx} disabled={filtered.length === 0}>
            <Download className="h-4 w-4 mr-2" />
            Excel
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>სულ ჩანაწერი</CardDescription>
              <CardTitle className="text-3xl">{filtered.length}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>უნიკალური თანამშრომელი</CardDescription>
              <CardTitle className="text-3xl">{uniqueEmployees}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>პერიოდი</CardDescription>
              <CardTitle className="text-base font-medium">{from} → {to}</CardTitle>
            </CardHeader>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">ფილტრები</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 md:grid-cols-4">
              <div>
                <label className="text-xs text-muted-foreground">დან</label>
                <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">მდე</label>
                <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
              </div>
              <div className="md:col-span-2">
                <label className="text-xs text-muted-foreground">ძებნა</label>
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    className="pl-8"
                    placeholder="თანამშრომელი, დეპარტამენტი ან პოზიცია"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>თარიღი</TableHead>
                    <TableHead>თანამშრომელი</TableHead>
                    <TableHead>დეპარტამენტი</TableHead>
                    <TableHead>პოზიცია</TableHead>
                    <TableHead>შემოსვლა</TableHead>
                    <TableHead>გასვლა</TableHead>
                    <TableHead>სტატუსი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-10 text-muted-foreground">
                        იტვირთება...
                      </TableCell>
                    </TableRow>
                  ) : filtered.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-10 text-muted-foreground">
                        ჩანაწერი ვერ მოიძებნა - ყველა აქტიური თანამშრომელი გრაფიკით არის გაწერილი
                      </TableCell>
                    </TableRow>
                  ) : (
                    filtered.map((r) => (
                      <TableRow key={r.id}>
                        <TableCell className="font-mono">{r.date}</TableCell>
                        <TableCell className="font-medium">{r.employee_name}</TableCell>
                        <TableCell>{r.department || "-"}</TableCell>
                        <TableCell className="text-muted-foreground">{r.position || "-"}</TableCell>
                        <TableCell>{r.check_in || "-"}</TableCell>
                        <TableCell>{r.check_out || "-"}</TableCell>
                        <TableCell>
                          {r.status ? <Badge variant="outline">{r.status}</Badge> : "-"}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageTransition>
  );
}
