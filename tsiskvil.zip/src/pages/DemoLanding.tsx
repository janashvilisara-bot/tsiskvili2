import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Play, 
  BookOpen,
  Sparkles,
  Users,
  Clock,
  FileText,
  DollarSign,
  BarChart3,
  Building2,
  CheckCircle2,
  Shield,
  Briefcase,
  GraduationCap,
  Target,
  MessageSquare,
  ArrowRight,
  Zap,
  Globe
} from "lucide-react";
import { useDemoMode } from "@/contexts/DemoContext";
import { motion } from "framer-motion";

const DemoLanding = () => {
  const navigate = useNavigate();
  const { setDemoMode } = useDemoMode();
  const [isLoading, setIsLoading] = useState(false);

  const handleStartDemo = async () => {
    setIsLoading(true);
    await setDemoMode(true);
    navigate("/demo");
  };

  const modules = [
    { icon: Users, text: "თანამშრომლების მართვა", color: "from-blue-500 to-blue-600" },
    { icon: Clock, text: "დასწრების აღრიცხვა", color: "from-purple-500 to-purple-600" },
    { icon: FileText, text: "შვებულებების მართვა", color: "from-emerald-500 to-emerald-600" },
    { icon: DollarSign, text: "ხელფასები & ფინანსები", color: "from-amber-500 to-amber-600" },
    { icon: BarChart3, text: "ანალიტიკა & რეპორტები", color: "from-cyan-500 to-cyan-600" },
    { icon: Building2, text: "ორგ. სტრუქტურა", color: "from-indigo-500 to-indigo-600" },
    { icon: Briefcase, text: "რეკრუტინგი", color: "from-rose-500 to-rose-600" },
    { icon: GraduationCap, text: "ტრენინგები", color: "from-teal-500 to-teal-600" },
    { icon: Target, text: "OKR & მიზნები", color: "from-orange-500 to-orange-600" },
    { icon: Shield, text: "უსაფრთხოება", color: "from-red-500 to-red-600" },
    { icon: MessageSquare, text: "AI ასისტენტი ნინა", color: "from-violet-500 to-violet-600" },
    { icon: Globe, text: "მობილური დასწრება", color: "from-sky-500 to-sky-600" },
  ];

  const highlights = [
    { icon: Zap, text: "არანაირი რეგისტრაცია" },
    { icon: CheckCircle2, text: "სრული ფუნქციონალი" },
    { icon: Shield, text: "უსაფრთხო გარემო" },
    { icon: Sparkles, text: "AI ასისტენტი" },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.05 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-primary/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-accent/5 rounded-full blur-[100px]" />
        <div className="absolute top-1/3 right-0 w-[300px] h-[300px] bg-primary/3 rounded-full blur-[80px]" />
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 py-8 sm:py-12">
        {/* Hero Section */}
        <motion.div 
          className="text-center max-w-2xl mx-auto mb-8 sm:mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Badge variant="secondary" className="mb-4 gap-1.5 px-3 py-1">
            <Sparkles className="h-3 w-3" />
            უფასო დემო ვერსია
          </Badge>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-4">
            <span className="bg-gradient-to-r from-primary via-primary/80 to-accent bg-clip-text text-transparent">
              TalentOS
            </span>
          </h1>
          
          <p className="text-lg sm:text-xl text-muted-foreground max-w-lg mx-auto leading-relaxed">
            HR & CRM პლატფორმა, რომელიც აუტომატიზირებს პერსონალის მართვას
          </p>
        </motion.div>

        {/* Highlights Row */}
        <motion.div 
          className="flex flex-wrap justify-center gap-3 sm:gap-4 mb-8 sm:mb-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          {highlights.map((item, i) => {
            const Icon = item.icon;
            return (
              <div key={i} className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Icon className="h-4 w-4 text-primary" />
                <span>{item.text}</span>
              </div>
            );
          })}
        </motion.div>

        {/* CTA Buttons */}
        <motion.div 
          className="flex flex-col sm:flex-row gap-3 mb-10 sm:mb-14"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <Button 
            size="lg"
            className="gap-2 px-8 h-12 text-base shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all"
            onClick={handleStartDemo}
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <div className="h-4 w-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                მზადდება...
              </>
            ) : (
              <>
                <Play className="h-5 w-5" />
                დემოს დაწყება
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </Button>
          
          <Button 
            size="lg"
            variant="outline"
            className="gap-2 px-8 h-12 text-base"
            onClick={() => navigate("/simulator")}
          >
            <BookOpen className="h-5 w-5" />
            ინტერაქტიული გაიდი
          </Button>
        </motion.div>

        {/* Modules Grid */}
        <motion.div 
          className="w-full max-w-3xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <p className="text-center text-sm font-medium text-muted-foreground mb-4 uppercase tracking-wider">
            ხელმისაწვდომი მოდულები
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 sm:gap-3">
            {modules.map((module, index) => {
              const Icon = module.icon;
              return (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  className="group flex items-center gap-2.5 p-3 rounded-xl border border-border/50 bg-card/50 backdrop-blur-sm hover:bg-card hover:border-primary/20 hover:shadow-sm transition-all duration-200 cursor-default"
                >
                  <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${module.color} flex items-center justify-center shrink-0 shadow-sm`}>
                    <Icon className="h-4 w-4 text-white" />
                  </div>
                  <span className="text-xs sm:text-sm font-medium text-foreground/80 group-hover:text-foreground transition-colors">
                    {module.text}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Footer */}
        <motion.div 
          className="mt-10 sm:mt-14 text-center space-y-3"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <p className="text-xs text-muted-foreground">
            ცვლილებები დროებითია და არ შეინახება • წინასწარ შევსებული მონაცემები
          </p>
          <Button 
            variant="link" 
            className="text-sm text-primary px-0 h-auto"
            onClick={() => navigate("/auth")}
          >
            უკვე გაქვთ ანგარიში? შესვლა →
          </Button>
        </motion.div>
      </div>
    </div>
  );
};

export default DemoLanding;
