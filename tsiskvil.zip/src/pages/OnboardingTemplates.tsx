import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  Plus,
  Edit2,
  Trash2,
  FileText,
  BookOpen,
  Users,
  Wrench,
  UserPlus,
  AlertCircle,
  Save,
  X,
  ArrowUp,
  ArrowDown,
} from "lucide-react";

interface Template {
  id: string;
  name: string;
  description: string | null;
  position_type: string | null;
  duration_days: number | null;
  is_active: boolean | null;
  created_at: string | null;
}

interface Task {
  id: string;
  template_id: string | null;
  title: string;
  description: string | null;
  due_days: number;
  task_type: string;
  is_mandatory: boolean | null;
  order_index: number | null;
}

const taskTypeIcons: Record<string, any> = {
  administrative: FileText,
  training: BookOpen,
  team: Users,
  technical: Wrench,
  onboarding: UserPlus,
  other: AlertCircle,
};

const taskTypeLabels: Record<string, { ka: string; en: string }> = {
  administrative: { ka: "ადმინისტრაციული", en: "Administrative" },
  training: { ka: "ტრენინგი", en: "Training" },
  team: { ka: "გუნდი", en: "Team" },
  technical: { ka: "ტექნიკური", en: "Technical" },
  onboarding: { ka: "ონბორდინგი", en: "Onboarding" },
  other: { ka: "სხვა", en: "Other" },
};

export default function OnboardingTemplates() {
  const { userRole } = useAuth();
  const { language } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  
  // Template dialog state
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<Template | null>(null);
  const [templateForm, setTemplateForm] = useState({
    name: "",
    description: "",
    position_type: "",
    duration_days: 90,
    is_active: true,
  });

  // Task dialog state
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [taskForm, setTaskForm] = useState({
    title: "",
    description: "",
    due_days: 1,
    task_type: "onboarding",
    is_mandatory: true,
  });

  useEffect(() => {
    fetchTemplates();
  }, []);

  useEffect(() => {
    if (selectedTemplate) {
      fetchTasks(selectedTemplate.id);
    }
  }, [selectedTemplate]);

  const fetchTemplates = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("onboarding_templates")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setTemplates(data || []);
      
      if (data && data.length > 0 && !selectedTemplate) {
        setSelectedTemplate(data[0]);
      }
    } catch (error: any) {
      console.error("Error fetching templates:", error);
      toast.error(language === "ka" ? "შეცდომა თემპლეითების ჩატვირთვისას" : "Error loading templates");
    } finally {
      setLoading(false);
    }
  };

  const fetchTasks = async (templateId: string) => {
    try {
      const { data, error } = await supabase
        .from("onboarding_tasks")
        .select("*")
        .eq("template_id", templateId)
        .order("order_index", { ascending: true });

      if (error) throw error;
      setTasks(data || []);
    } catch (error: any) {
      console.error("Error fetching tasks:", error);
      toast.error(language === "ka" ? "შეცდომა დავალებების ჩატვირთვისას" : "Error loading tasks");
    }
  };

  const handleSaveTemplate = async () => {
    try {
      if (editingTemplate) {
        const { error } = await supabase
          .from("onboarding_templates")
          .update(templateForm)
          .eq("id", editingTemplate.id);

        if (error) throw error;
        toast.success(language === "ka" ? "თემპლეითი განახლდა" : "Template updated");
      } else {
        const { error } = await supabase
          .from("onboarding_templates")
          .insert([templateForm]);

        if (error) throw error;
        toast.success(language === "ka" ? "თემპლეითი შეიქმნა" : "Template created");
      }

      setTemplateDialogOpen(false);
      setEditingTemplate(null);
      setTemplateForm({
        name: "",
        description: "",
        position_type: "",
        duration_days: 90,
        is_active: true,
      });
      await fetchTemplates();
    } catch (error: any) {
      console.error("Error saving template:", error);
      toast.error(language === "ka" ? "შეცდომა თემპლეითის შენახვისას" : "Error saving template");
    }
  };

  const handleDeleteTemplate = async (id: string) => {
    if (!confirm(language === "ka" ? "დარწმუნებული ხართ?" : "Are you sure?")) return;

    try {
      const { error } = await supabase
        .from("onboarding_templates")
        .delete()
        .eq("id", id);

      if (error) throw error;
      
      toast.success(language === "ka" ? "თემპლეითი წაიშალა" : "Template deleted");
      
      if (selectedTemplate?.id === id) {
        setSelectedTemplate(null);
      }
      
      await fetchTemplates();
    } catch (error: any) {
      console.error("Error deleting template:", error);
      toast.error(language === "ka" ? "შეცდომა თემპლეითის წაშლისას" : "Error deleting template");
    }
  };

  const handleSaveTask = async () => {
    if (!selectedTemplate) return;

    try {
      const maxOrder = tasks.length > 0 ? Math.max(...tasks.map((t) => t.order_index || 0)) : 0;

      if (editingTask) {
        const { error } = await supabase
          .from("onboarding_tasks")
          .update(taskForm)
          .eq("id", editingTask.id);

        if (error) throw error;
        toast.success(language === "ka" ? "დავალება განახლდა" : "Task updated");
      } else {
        const { error } = await supabase
          .from("onboarding_tasks")
          .insert([{
            ...taskForm,
            template_id: selectedTemplate.id,
            order_index: maxOrder + 1,
          }]);

        if (error) throw error;
        toast.success(language === "ka" ? "დავალება შეიქმნა" : "Task created");
      }

      setTaskDialogOpen(false);
      setEditingTask(null);
      setTaskForm({
        title: "",
        description: "",
        due_days: 1,
        task_type: "onboarding",
        is_mandatory: true,
      });
      await fetchTasks(selectedTemplate.id);
    } catch (error: any) {
      console.error("Error saving task:", error);
      toast.error(language === "ka" ? "შეცდომა დავალების შენახვისას" : "Error saving task");
    }
  };

  const handleDeleteTask = async (id: string) => {
    if (!confirm(language === "ka" ? "დარწმუნებული ხართ?" : "Are you sure?")) return;

    try {
      const { error } = await supabase
        .from("onboarding_tasks")
        .delete()
        .eq("id", id);

      if (error) throw error;
      
      toast.success(language === "ka" ? "დავალება წაიშალა" : "Task deleted");
      
      if (selectedTemplate) {
        await fetchTasks(selectedTemplate.id);
      }
    } catch (error: any) {
      console.error("Error deleting task:", error);
      toast.error(language === "ka" ? "შეცდომა დავალების წაშლისას" : "Error deleting task");
    }
  };

  const moveTask = async (taskId: string, direction: "up" | "down") => {
    const taskIndex = tasks.findIndex((t) => t.id === taskId);
    if (
      (direction === "up" && taskIndex === 0) ||
      (direction === "down" && taskIndex === tasks.length - 1)
    ) {
      return;
    }

    const newTasks = [...tasks];
    const swapIndex = direction === "up" ? taskIndex - 1 : taskIndex + 1;
    [newTasks[taskIndex], newTasks[swapIndex]] = [newTasks[swapIndex], newTasks[taskIndex]];

    try {
      const updates = newTasks.map((task, index) => ({
        id: task.id,
        order_index: index,
      }));

      for (const update of updates) {
        await supabase
          .from("onboarding_tasks")
          .update({ order_index: update.order_index })
          .eq("id", update.id);
      }

      setTasks(newTasks);
    } catch (error: any) {
      console.error("Error reordering tasks:", error);
      toast.error(language === "ka" ? "შეცდომა დავალებების რეორგანიზაციისას" : "Error reordering tasks");
    }
  };

  const openEditTemplate = (template: Template) => {
    setEditingTemplate(template);
    setTemplateForm({
      name: template.name,
      description: template.description || "",
      position_type: template.position_type || "",
      duration_days: template.duration_days || 90,
      is_active: template.is_active ?? true,
    });
    setTemplateDialogOpen(true);
  };

  const openEditTask = (task: Task) => {
    setEditingTask(task);
    setTaskForm({
      title: task.title,
      description: task.description || "",
      due_days: task.due_days,
      task_type: task.task_type,
      is_mandatory: task.is_mandatory ?? true,
    });
    setTaskDialogOpen(true);
  };

  if (userRole !== "admin" && userRole !== "hr_manager") {
    return (
      <div className="flex items-center justify-center h-64">
        <Card className="max-w-md">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <AlertCircle className="h-12 w-12 text-destructive mb-4" />
            <h3 className="text-lg font-semibold mb-2">
              {language === "ka" ? "წვდომა აკრძალულია" : "Access Denied"}
            </h3>
            <p className="text-muted-foreground text-center">
              {language === "ka"
                ? "თქვენ არ გაქვთ უფლება ამ გვერდზე წვდომისთვის"
                : "You don't have permission to access this page"}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
          <p className="text-muted-foreground">{language === "ka" ? "იტვირთება..." : "Loading..."}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">
            {language === "ka" ? "ონბორდინგ თემპლეითები" : "Onboarding Templates"}
          </h1>
          <p className="text-muted-foreground mt-1">
            {language === "ka"
              ? "ონბორდინგის თემპლეითების და დავალებების მართვა"
              : "Manage onboarding templates and tasks"}
          </p>
        </div>
        <Dialog open={templateDialogOpen} onOpenChange={setTemplateDialogOpen}>
          <DialogTrigger asChild>
            <Button
              onClick={() => {
                setEditingTemplate(null);
                setTemplateForm({
                  name: "",
                  description: "",
                  position_type: "",
                  duration_days: 90,
                  is_active: true,
                });
              }}
            >
              <Plus className="h-4 w-4 mr-2" />
              {language === "ka" ? "ახალი თემპლეითი" : "New Template"}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingTemplate
                  ? language === "ka"
                    ? "თემპლეითის რედაქტირება"
                    : "Edit Template"
                  : language === "ka"
                  ? "ახალი თემპლეითი"
                  : "New Template"}
              </DialogTitle>
              <DialogDescription>
                {language === "ka"
                  ? "შეავსეთ თემპლეითის დეტალები"
                  : "Fill in the template details"}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">{language === "ka" ? "სახელი" : "Name"}</Label>
                <Input
                  id="name"
                  value={templateForm.name}
                  onChange={(e) => setTemplateForm({ ...templateForm, name: e.target.value })}
                  placeholder={language === "ka" ? "მაგ: Developer Onboarding" : "e.g. Developer Onboarding"}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="position_type">{language === "ka" ? "პოზიციის ტიპი" : "Position Type"}</Label>
                <Select
                  value={templateForm.position_type}
                  onValueChange={(value) => setTemplateForm({ ...templateForm, position_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={language === "ka" ? "აირჩიეთ ტიპი" : "Select type"} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="developer">{language === "ka" ? "დეველოპერი" : "Developer"}</SelectItem>
                    <SelectItem value="manager">{language === "ka" ? "მენეჯერი" : "Manager"}</SelectItem>
                    <SelectItem value="sales">{language === "ka" ? "გაყიდვები" : "Sales"}</SelectItem>
                    <SelectItem value="hr">{language === "ka" ? "HR" : "HR"}</SelectItem>
                    <SelectItem value="general">{language === "ka" ? "ზოგადი" : "General"}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="duration_days">{language === "ka" ? "ხანგრძლივობა (დღეები)" : "Duration (days)"}</Label>
                <Input
                  id="duration_days"
                  type="number"
                  value={templateForm.duration_days}
                  onChange={(e) => setTemplateForm({ ...templateForm, duration_days: parseInt(e.target.value) })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">{language === "ka" ? "აღწერა" : "Description"}</Label>
                <Textarea
                  id="description"
                  value={templateForm.description}
                  onChange={(e) => setTemplateForm({ ...templateForm, description: e.target.value })}
                  placeholder={language === "ka" ? "თემპლეითის აღწერა" : "Template description"}
                  rows={3}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_active"
                  checked={templateForm.is_active}
                  onCheckedChange={(checked) => setTemplateForm({ ...templateForm, is_active: checked })}
                />
                <Label htmlFor="is_active">{language === "ka" ? "აქტიური" : "Active"}</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setTemplateDialogOpen(false)}>
                <X className="h-4 w-4 mr-2" />
                {language === "ka" ? "გაუქმება" : "Cancel"}
              </Button>
              <Button onClick={handleSaveTemplate}>
                <Save className="h-4 w-4 mr-2" />
                {language === "ka" ? "შენახვა" : "Save"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Left: Templates List */}
        <div className="md:col-span-1 space-y-4">
          {templates.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">
                  {language === "ka" ? "თემპლეითები არ მოიძებნა" : "No Templates Found"}
                </h3>
                <p className="text-muted-foreground text-center text-sm">
                  {language === "ka" ? "დაიწყეთ ახალი თემპლეითის შექმნა" : "Start by creating a new template"}
                </p>
              </CardContent>
            </Card>
          ) : (
            templates.map((template) => (
              <Card
                key={template.id}
                className={`cursor-pointer transition-all hover:shadow-md ${
                  selectedTemplate?.id === template.id ? "ring-2 ring-primary" : ""
                }`}
                onClick={() => setSelectedTemplate(template)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-base">{template.name}</CardTitle>
                      {template.position_type && (
                        <CardDescription className="text-sm mt-1">{template.position_type}</CardDescription>
                      )}
                    </div>
                    <div className="flex gap-1">
                      {template.is_active ? (
                        <Badge variant="default">{language === "ka" ? "აქტიური" : "Active"}</Badge>
                      ) : (
                        <Badge variant="outline">{language === "ka" ? "არააქტიური" : "Inactive"}</Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <p className="text-sm text-muted-foreground line-clamp-2">{template.description}</p>
                  <div className="flex items-center justify-between pt-2">
                    <span className="text-xs text-muted-foreground">
                      {template.duration_days} {language === "ka" ? "დღე" : "days"}
                    </span>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          openEditTemplate(template);
                        }}
                      >
                        <Edit2 className="h-3 w-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteTemplate(template.id);
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Right: Template Tasks */}
        {selectedTemplate && (
          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{selectedTemplate.name}</CardTitle>
                    <CardDescription className="mt-1">{selectedTemplate.description}</CardDescription>
                  </div>
                  <Dialog open={taskDialogOpen} onOpenChange={setTaskDialogOpen}>
                    <DialogTrigger asChild>
                      <Button
                        size="sm"
                        onClick={() => {
                          setEditingTask(null);
                          setTaskForm({
                            title: "",
                            description: "",
                            due_days: 1,
                            task_type: "onboarding",
                            is_mandatory: true,
                          });
                        }}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        {language === "ka" ? "დავალება" : "Task"}
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>
                          {editingTask
                            ? language === "ka"
                              ? "დავალების რედაქტირება"
                              : "Edit Task"
                            : language === "ka"
                            ? "ახალი დავალება"
                            : "New Task"}
                        </DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="task-title">{language === "ka" ? "სათაური" : "Title"}</Label>
                          <Input
                            id="task-title"
                            value={taskForm.title}
                            onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="task-type">{language === "ka" ? "ტიპი" : "Type"}</Label>
                          <Select
                            value={taskForm.task_type}
                            onValueChange={(value) => setTaskForm({ ...taskForm, task_type: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.entries(taskTypeLabels).map(([key, label]) => (
                                <SelectItem key={key} value={key}>
                                  {label[language]}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="due-days">{language === "ka" ? "დღე (დაწყებიდან)" : "Day (from start)"}</Label>
                          <Input
                            id="due-days"
                            type="number"
                            min="1"
                            value={taskForm.due_days}
                            onChange={(e) => setTaskForm({ ...taskForm, due_days: parseInt(e.target.value) })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="task-description">{language === "ka" ? "აღწერა" : "Description"}</Label>
                          <Textarea
                            id="task-description"
                            value={taskForm.description}
                            onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
                            rows={3}
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch
                            id="is-mandatory"
                            checked={taskForm.is_mandatory}
                            onCheckedChange={(checked) => setTaskForm({ ...taskForm, is_mandatory: checked })}
                          />
                          <Label htmlFor="is-mandatory">{language === "ka" ? "სავალდებულო" : "Mandatory"}</Label>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setTaskDialogOpen(false)}>
                          <X className="h-4 w-4 mr-2" />
                          {language === "ka" ? "გაუქმება" : "Cancel"}
                        </Button>
                        <Button onClick={handleSaveTask}>
                          <Save className="h-4 w-4 mr-2" />
                          {language === "ka" ? "შენახვა" : "Save"}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {tasks.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">
                      {language === "ka" ? "დავალებები არ მოიძებნა" : "No Tasks Found"}
                    </h3>
                    <p className="text-muted-foreground text-center text-sm">
                      {language === "ka" ? "დაამატეთ დავალებები ამ თემპლეითისთვის" : "Add tasks to this template"}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {tasks.map((task, index) => {
                      const TaskIcon = taskTypeIcons[task.task_type] || AlertCircle;
                      return (
                        <div
                          key={task.id}
                          className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/30 transition-colors"
                        >
                          <div className="flex flex-col gap-1">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-6 w-6 p-0"
                              onClick={() => moveTask(task.id, "up")}
                              disabled={index === 0}
                            >
                              <ArrowUp className="h-3 w-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-6 w-6 p-0"
                              onClick={() => moveTask(task.id, "down")}
                              disabled={index === tasks.length - 1}
                            >
                              <ArrowDown className="h-3 w-3" />
                            </Button>
                          </div>
                          <TaskIcon className="h-5 w-5 text-primary shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-medium text-sm">{task.title}</p>
                              {task.is_mandatory && (
                                <Badge variant="destructive" className="text-xs">
                                  {language === "ka" ? "სავალდებულო" : "Required"}
                                </Badge>
                              )}
                            </div>
                            {task.description && (
                              <p className="text-xs text-muted-foreground line-clamp-1">{task.description}</p>
                            )}
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <Badge variant="outline" className="text-xs">
                              {language === "ka" ? "დღე" : "Day"} {task.due_days}
                            </Badge>
                            <Badge variant="secondary" className="text-xs">
                              {taskTypeLabels[task.task_type]?.[language] || task.task_type}
                            </Badge>
                            <Button size="sm" variant="ghost" onClick={() => openEditTask(task)}>
                              <Edit2 className="h-3 w-3" />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => handleDeleteTask(task.id)}>
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
