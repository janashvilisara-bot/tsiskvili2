import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useBranch } from "@/contexts/BranchContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Download, FileSpreadsheet, CheckCircle2 } from "lucide-react";
import { selectRows, buildCsv, buildXlsx, type RsgeEmployee, type RsgeType } from "@/lib/rsgeRegistry";

const month = new Date();
const first = new Date(month.getFullYear(), month.getMonth(), 1).toLocaleDateString("sv-SE");
const last = new Date(month.getFullYear(), month.getMonth() + 1, 0).toLocaleDateString("sv-SE");

export default function RsgeRegistry() {
  const { userRole } = useAuth();
  const { activeBranch } = useBranch();
  const { language } = useLanguage();
  const ka = language === "ka";
  const t = (k: string, e: string) => (ka ? k : e);
  const allowed = userRole === "admin" || userRole === "hr_manager";

  const [from, setFrom] = useState(first);
  const [to, setTo] = useState(last);
  const [type, setType] = useState<RsgeType>("both");
  const [employees, setEmployees] = useState<RsgeEmployee[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    let q = supabase
      .from("employees")
      .select("id, full_name, last_name, personal_id, position, hire_date, termination_date, salary")
      .is("deleted_at", null);
    if (activeBranch?.id) q = q.eq("branch_id", activeBranch.id);
    const [{ data, error }, h] = await Promise.all([
      q,
      supabase.from("rsge_exports").select("*").order("created_at", { ascending: false }).limit(20),
    ]);
    if (error) toast.error(t("მონაცემების ჩატვირთვა ვერ მოხერხდა", "Could not load data"));
    setEmployees((data as RsgeEmployee[]) || []);
    setHistory(h.data || []);
    setLoading(false);
  };

  useEffect(() => {
    if (allowed) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allowed, activeBranch?.id]);

  const rows = useMemo(() => selectRows(employees, type, from, to), [employees, type, from, to]);
  const valid = rows.filter((r) => !r.errors.length).length;

  const errLabel: Record<string, string> = {
    personal_id: t("პირადი ნომერი (11 ციფრი)", "Personal ID (11 digits)"),
    position: t("პოზიცია", "Position"),
    date: t("თარიღი", "Date"),
  };

  const download = async (fmt: "xlsx" | "csv") => {
    if (!valid) return toast.error(t("ფაილში შესატანი ჩანაწერი არ არის", "No valid rows to export"));
    const blob = fmt === "csv" ? new Blob([buildCsv(rows)], { type: "text/csv;charset=utf-8" }) : await buildXlsx(rows);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `rsge_${type}_${from}_${to}.${fmt}`;
    a.click();
    URL.revokeObjectURL(a.href);
    const { error } = await supabase.from("rsge_exports").insert({
      export_type: type, period_from: from, period_to: to, branch_id: activeBranch?.id ?? null, row_count: valid, file_format: fmt,
    });
    if (error) toast.error(t("ისტორიაში ჩაწერა ვერ მოხერხდა", "Could not save to history"));
    else load();
  };

  const markUploaded = async (id: string) => {
    const { error } = await supabase.from("rsge_exports").update({ uploaded_at: new Date().toISOString() }).eq("id", id);
    if (error) toast.error(t("განახლება ვერ მოხერხდა", "Update failed"));
    else load();
  };

  if (!allowed) return <div className="p-6 text-muted-foreground">{t("წვდომა მხოლოდ ადმინისა და HR-ისთვის", "Admin and HR only")}</div>;

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-6xl mx-auto">
      <div>
        <h1 className="text-2xl font-semibold">{t("RS.ge რეესტრი", "RS.ge registry")}</h1>
        <p className="text-sm text-muted-foreground">
          {t("დანიშვნისა და გათავისუფლების მზა ფაილი RS.ge-ზე ასატვირთად", "Ready file of hires and terminations to upload to RS.ge")}
        </p>
      </div>

      <Card>
        <CardContent className="pt-6 grid gap-4 sm:grid-cols-4 items-end">
          <div className="space-y-1"><Label>{t("დან", "From")}</Label><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
          <div className="space-y-1"><Label>{t("მდე", "To")}</Label><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
          <div className="space-y-1">
            <Label>{t("ტიპი", "Type")}</Label>
            <Select value={type} onValueChange={(v) => setType(v as RsgeType)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="both">{t("ორივე", "Both")}</SelectItem>
                <SelectItem value="hire">{t("დანიშნულები", "Hires")}</SelectItem>
                <SelectItem value="termination">{t("გათავისუფლებულები", "Terminations")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => download("xlsx")} className="flex-1"><FileSpreadsheet className="h-4 w-4 mr-1" />Excel</Button>
            <Button variant="outline" onClick={() => download("csv")}><Download className="h-4 w-4 mr-1" />CSV</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">{t("ჩანაწერები", "Records")}</CardTitle>
          <div className="flex gap-2 text-sm">
            <Badge variant="outline">{t("მზადაა", "Ready")}: {valid}</Badge>
            {rows.length - valid > 0 && <Badge variant="destructive">{t("გასასწორებელი", "Needs fixing")}: {rows.length - valid}</Badge>}
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          {loading ? <p className="text-sm text-muted-foreground">{t("იტვირთება...", "Loading...")}</p> : rows.length === 0 ? (
            <p className="text-sm text-muted-foreground">{t("ამ პერიოდში მოვლენები არ არის", "No events in this period")}</p>
          ) : (
            <Table>
              <TableHeader><TableRow>
                <TableHead>{t("თანამშრომელი", "Employee")}</TableHead>
                <TableHead>{t("პირადი ნომერი", "Personal ID")}</TableHead>
                <TableHead>{t("მოვლენა", "Event")}</TableHead>
                <TableHead>{t("თარიღი", "Date")}</TableHead>
                <TableHead>{t("პოზიცია", "Position")}</TableHead>
                <TableHead>{t("ხელფასი", "Salary")}</TableHead>
                <TableHead>{t("სტატუსი", "Status")}</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.employee.id + r.event} className={r.errors.length ? "bg-destructive/5" : ""}>
                    <TableCell className="whitespace-nowrap">{r.employee.full_name}</TableCell>
                    <TableCell>{r.employee.personal_id || "-"}</TableCell>
                    <TableCell>{r.event === "hire" ? t("დანიშვნა", "Hire") : t("გათავისუფლება", "Termination")}</TableCell>
                    <TableCell className="whitespace-nowrap">{r.date}</TableCell>
                    <TableCell>{r.employee.position || "-"}</TableCell>
                    <TableCell>{r.employee.salary ?? "-"}</TableCell>
                    <TableCell>
                      {r.errors.length ? (
                        <Link to={`/employees/${r.employee.id}`} className="text-destructive text-xs underline">
                          {t("აკლია", "Missing")}: {r.errors.map((e) => errLabel[e]).join(", ")}
                        </Link>
                      ) : <CheckCircle2 className="h-4 w-4 text-primary" />}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">{t("ექსპორტის ისტორია", "Export history")}</CardTitle></CardHeader>
        <CardContent>
          {history.length === 0 ? <p className="text-sm text-muted-foreground">{t("ჯერ ექსპორტი არ ყოფილა", "No exports yet")}</p> : (
            <div className="space-y-2">
              {history.map((h) => (
                <div key={h.id} className="flex flex-wrap items-center justify-between gap-2 border rounded-md p-3 text-sm">
                  <span>{new Date(h.created_at).toLocaleString(ka ? "ka-GE" : "en-GB")} · {h.period_from} – {h.period_to} · {h.row_count} {t("ჩანაწერი", "rows")} · {h.file_format.toUpperCase()}</span>
                  {h.uploaded_at ? <Badge variant="outline">{t("ატვირთულია RS.ge-ზე", "Uploaded to RS.ge")}</Badge> : (
                    <Button size="sm" variant="outline" onClick={() => markUploaded(h.id)}>{t("მოვნიშნო ატვირთულად", "Mark as uploaded")}</Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
