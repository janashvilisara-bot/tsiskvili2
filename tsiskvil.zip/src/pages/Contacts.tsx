import { useState, useEffect } from "react";
import { Plus, Search, Edit, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { z } from "zod";

const contactSchema = z.object({
  company_name: z.string().min(2, { message: "კომპანიის სახელი ძალიან მოკლეა" }),
  contact_person: z.string().min(2, { message: "სახელი ძალიან მოკლეა" }),
  email: z.string().email({ message: "არასწორი ელ.ფოსტა" }),
  phone: z.string().optional(),
  address: z.string().optional(),
  status: z.enum(['active', 'inactive', 'potential']),
  notes: z.string().optional(),
});

interface Contact {
  id: string;
  company_name: string;
  contact_person: string;
  email: string;
  phone: string | null;
  address: string | null;
  status: string;
  notes: string | null;
}

export default function Contacts() {
  const { user, userRole } = useAuth();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const canManageAllContacts = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    fetchContacts();
  }, []);

  const fetchContacts = async () => {
    try {
      const { data, error } = await supabase
        .from('contacts')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setContacts(data || []);
    } catch (error: any) {
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors({});
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const data = contactSchema.parse({
        company_name: formData.get('company_name'),
        contact_person: formData.get('contact_person'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        address: formData.get('address'),
        status: formData.get('status'),
        notes: formData.get('notes'),
      });

      const payload: any = {
        ...data,
        created_by: user?.id,
      };

      if (editingContact) {
        const { error } = await supabase
          .from('contacts')
          .update(payload)
          .eq('id', editingContact.id);

        if (error) throw error;
        toast.success('კონტაქტი განახლდა');
      } else {
        const { error } = await supabase
          .from('contacts')
          .insert([payload]);

        if (error) throw error;
        toast.success('კონტაქტი დამატებულია');
      }

      setIsDialogOpen(false);
      setEditingContact(null);
      fetchContacts();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
      } else {
        toast.error(error.message || 'შეცდომა მოხდა');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('დარწმუნებული ხართ რომ გსურთ წაშლა?')) return;

    try {
      const { error } = await supabase
        .from('contacts')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast.success('კონტაქტი წაიშალა');
      fetchContacts();
    } catch (error: any) {
      toast.error('წაშლა ვერ მოხერხდა');
    }
  };

  const filteredContacts = contacts.filter((contact) =>
    contact.company_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.contact_person.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">კომპანიები</h1>
          <p className="mt-2 text-muted-foreground">მართეთ თქვენი კლიენტები და პარტნიორები</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) {
            setEditingContact(null);
            setErrors({});
          }
        }}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              ახალი კონტაქტი
            </Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingContact ? 'კონტაქტის რედაქტირება' : 'ახალი კონტაქტის დამატება'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="company_name">კომპანია *</Label>
                <Input
                  id="company_name"
                  name="company_name"
                  defaultValue={editingContact?.company_name}
                  placeholder="შეიყვანეთ კომპანია"
                  required
                />
                {errors.company_name && <p className="mt-1 text-sm text-destructive">{errors.company_name}</p>}
              </div>
              <div>
                <Label htmlFor="contact_person">საკონტაქტო პირი *</Label>
                <Input
                  id="contact_person"
                  name="contact_person"
                  defaultValue={editingContact?.contact_person}
                  placeholder="შეიყვანეთ სახელი"
                  required
                />
                {errors.contact_person && <p className="mt-1 text-sm text-destructive">{errors.contact_person}</p>}
              </div>
              <div>
                <Label htmlFor="email">ელ. ფოსტა *</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  defaultValue={editingContact?.email}
                  placeholder="email@example.ge"
                  required
                />
                {errors.email && <p className="mt-1 text-sm text-destructive">{errors.email}</p>}
              </div>
              <div>
                <Label htmlFor="phone">ტელეფონი</Label>
                <Input
                  id="phone"
                  name="phone"
                  defaultValue={editingContact?.phone || ''}
                  placeholder="+995 555 000 000"
                />
              </div>
              <div>
                <Label htmlFor="address">მისამართი</Label>
                <Input
                  id="address"
                  name="address"
                  defaultValue={editingContact?.address || ''}
                  placeholder="შეიყვანეთ მისამართი"
                />
              </div>
              <div>
                <Label htmlFor="status">სტატუსი *</Label>
                <Select name="status" defaultValue={editingContact?.status || 'active'}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">აქტიური</SelectItem>
                    <SelectItem value="potential">პოტენციური</SelectItem>
                    <SelectItem value="inactive">არააქტიური</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="notes">შენიშვნები</Label>
                <Textarea
                  id="notes"
                  name="notes"
                  defaultValue={editingContact?.notes || ''}
                  placeholder="დამატებითი ინფორმაცია..."
                  rows={3}
                />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'მიმდინარეობს...' : editingContact ? 'განახლება' : 'დამატება'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="ძებნა კონტაქტების მიხედვით..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="rounded-lg border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>კომპანია</TableHead>
              <TableHead>საკონტაქტო პირი</TableHead>
              <TableHead>ელ. ფოსტა</TableHead>
              <TableHead>ტელეფონი</TableHead>
              <TableHead>სტატუსი</TableHead>
              <TableHead className="text-right">მოქმედებები</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredContacts.map((contact) => (
              <TableRow key={contact.id} className="transition-colors hover:bg-muted">
                <TableCell className="font-medium">{contact.company_name}</TableCell>
                <TableCell>{contact.contact_person}</TableCell>
                <TableCell>{contact.email}</TableCell>
                <TableCell>{contact.phone || '-'}</TableCell>
                <TableCell>
                  <span className={`inline-flex rounded-full px-3 py-1 text-xs font-medium ${
                    contact.status === 'active' 
                      ? 'bg-green-100 text-green-700' 
                      : contact.status === 'potential'
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}>
                    {contact.status === 'active' ? 'აქტიური' : contact.status === 'potential' ? 'პოტენციური' : 'არააქტიური'}
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setEditingContact(contact);
                        setIsDialogOpen(true);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    {canManageAllContacts && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(contact.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {filteredContacts.length === 0 && (
        <div className="flex h-64 items-center justify-center text-muted-foreground">
          კონტაქტები არ მოიძებნა
        </div>
      )}
    </div>
  );
}
