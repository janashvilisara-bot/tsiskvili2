import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, FileText, Search, Edit, Trash2, Eye } from "lucide-react";
import { z } from "zod";

interface JobDescription {
  id: string;
  position_id: string;
  title: string;
  summary: string | null;
  responsibilities: string;
  requirements: string;
  qualifications: string | null;
  skills: string | null;
  working_conditions: string | null;
  salary_range_min: number | null;
  salary_range_max: number | null;
  employment_type: string;
  experience_years: number | null;
  education_level: string | null;
  language_requirements: string | null;
  is_active: boolean;
  version: number;
  created_at: string;
  departments?: { name: string };
}

interface Department {
  id: string;
  name: string;
}

const JobDescriptions = () => {
  const [jobDescriptions, setJobDescriptions] = useState<JobDescription[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedJob, setSelectedJob] = useState<JobDescription | null>(null);
  const [formData, setFormData] = useState({
    position_id: "",
    title: "",
    summary: "",
    responsibilities: "",
    requirements: "",
    qualifications: "",
    skills: "",
    working_conditions: "",
    salary_range_min: "",
    salary_range_max: "",
    employment_type: "full_time",
    experience_years: "",
    education_level: "",
    language_requirements: "",
  });

  useEffect(() => {
    fetchJobDescriptions();
    fetchDepartments();
  }, []);

  const fetchJobDescriptions = async () => {
    try {
      const { data, error } = await (supabase as any)
        .from("job_descriptions")
        .select(`
          *,
          departments:position_id (name)
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setJobDescriptions(data || []);
    } catch (error: any) {
      toast.error("შეცდომა აღწერილობების ჩატვირთვისას");
    } finally {
      setLoading(false);
    }
  };

  const fetchDepartments = async () => {
    try {
      const { data, error } = await supabase
        .from("departments")
        .select("id, name")
        .eq("is_active", true)
        .order("name");

      if (error) throw error;
      setDepartments(data || []);
    } catch (error: any) {
      toast.error("შეცდომა პოზიციების ჩატვირთვისას");
    }
  };

  const jobDescriptionSchema = z.object({
    position_id: z.string().min(1, 'პოზიცია სავალდებულოა'),
    title: z.string().min(1, 'სათაური სავალდებულოა').max(200),
    summary: z.string().max(5000).optional(),
    description: z.string().min(10, 'აღწერილობა უნდა შეიცავდეს მინიმუმ 10 სიმბოლოს').max(5000).optional(),
    responsibilities: z.string().min(10, 'პასუხისმგებლობები სავალდებულოა').max(5000),
    requirements: z.string().min(10, 'მოთხოვნები სავალდებულოა').max(5000),
    qualifications: z.string().max(5000).optional(),
    skills: z.string().max(5000).optional(),
    working_conditions: z.string().max(2000).optional(),
    employment_type: z.string().min(1, 'დასაქმების ტიპი სავალდებულოა'),
    salary_range_min: z.number().min(0, 'ხელფასი არ შეიძლება იყოს უარყოფითი').optional(),
    salary_range_max: z.number().min(0, 'ხელფასი არ შეიძლება იყოს უარყოფითი').optional(),
    experience_years: z.number().min(0).max(50).optional(),
    education_level: z.string().max(100).optional(),
    language_requirements: z.string().max(500).optional(),
  }).refine((data) => {
    if (data.salary_range_min && data.salary_range_max) {
      return data.salary_range_max >= data.salary_range_min;
    }
    return true;
  }, { message: 'მაქსიმალური ხელფასი უნდა იყოს მინიმალურზე მეტი ან ტოლი', path: ['salary_range_max'] });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const validationData = {
        ...formData,
        summary: formData.summary || undefined,
        salary_range_min: formData.salary_range_min ? parseFloat(formData.salary_range_min) : undefined,
        salary_range_max: formData.salary_range_max ? parseFloat(formData.salary_range_max) : undefined,
        experience_years: formData.experience_years ? parseInt(formData.experience_years) : undefined,
        qualifications: formData.qualifications || undefined,
        skills: formData.skills || undefined,
        working_conditions: formData.working_conditions || undefined,
        education_level: formData.education_level || undefined,
        language_requirements: formData.language_requirements || undefined,
      };

      const result = jobDescriptionSchema.safeParse(validationData);
      if (!result.success) {
        const errors = result.error.flatten().fieldErrors;
        toast.error(Object.values(errors).flat()[0] || 'შეცდომა ვალიდაციისას');
        return;
      }

      const { error } = await (supabase as any).from("job_descriptions").insert({
        ...result.data,
        summary: result.data.summary || null,
        salary_range_min: result.data.salary_range_min || null,
        salary_range_max: result.data.salary_range_max || null,
        experience_years: result.data.experience_years || null,
        qualifications: result.data.qualifications || null,
        skills: result.data.skills || null,
        working_conditions: result.data.working_conditions || null,
        education_level: result.data.education_level || null,
        language_requirements: result.data.language_requirements || null,
      });

      if (error) throw error;

      toast.success("სამუშაო აღწერილობა წარმატებით დაემატა");
      setIsAddDialogOpen(false);
      resetForm();
      fetchJobDescriptions();
    } catch (error: any) {
      toast.error("შეცდომა დამატებისას: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedJob) return;

    setLoading(true);
    try {
      const { error } = await (supabase as any)
        .from("job_descriptions")
        .update({
          ...formData,
          salary_range_min: formData.salary_range_min ? parseFloat(formData.salary_range_min) : null,
          salary_range_max: formData.salary_range_max ? parseFloat(formData.salary_range_max) : null,
          experience_years: formData.experience_years ? parseInt(formData.experience_years) : null,
        })
        .eq("id", selectedJob.id);

      if (error) throw error;

      toast.success("სამუშაო აღწერილობა განახლდა");
      setIsEditDialogOpen(false);
      resetForm();
      fetchJobDescriptions();
    } catch (error: any) {
      toast.error("შეცდომა განახლებისას: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("დარწმუნებული ხართ, რომ გსურთ წაშლა?")) return;

    try {
      const { error } = await (supabase as any).from("job_descriptions").delete().eq("id", id);

      if (error) throw error;
      toast.success("სამუშაო აღწერილობა წაიშალა");
      fetchJobDescriptions();
    } catch (error: any) {
      toast.error("შეცდომა წაშლისას");
    }
  };

  const resetForm = () => {
    setFormData({
      position_id: "",
      title: "",
      summary: "",
      responsibilities: "",
      requirements: "",
      qualifications: "",
      skills: "",
      working_conditions: "",
      salary_range_min: "",
      salary_range_max: "",
      employment_type: "full_time",
      experience_years: "",
      education_level: "",
      language_requirements: "",
    });
    setSelectedJob(null);
  };

  const openEditDialog = (job: JobDescription) => {
    setSelectedJob(job);
    setFormData({
      position_id: job.position_id,
      title: job.title,
      summary: job.summary || "",
      responsibilities: job.responsibilities,
      requirements: job.requirements,
      qualifications: job.qualifications || "",
      skills: job.skills || "",
      working_conditions: job.working_conditions || "",
      salary_range_min: job.salary_range_min?.toString() || "",
      salary_range_max: job.salary_range_max?.toString() || "",
      employment_type: job.employment_type,
      experience_years: job.experience_years?.toString() || "",
      education_level: job.education_level || "",
      language_requirements: job.language_requirements || "",
    });
    setIsEditDialogOpen(true);
  };

  const filteredJobs = jobDescriptions.filter((job) =>
    job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.departments?.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      <div className="p-6 md:p-8 space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              სამუშაო აღწერილობები
            </h1>
            <p className="text-muted-foreground mt-1">
              პოზიციების დეტალური აღწერილობები და მოთხოვნები
            </p>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                ახალი აღწერილობა
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>ახალი სამუშაო აღწერილობა</DialogTitle>
                <DialogDescription>
                  შეავსეთ ინფორმაცია პოზიციის დეტალური აღწერილობისთვის
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label htmlFor="position_id">პოზიცია *</Label>
                    <Select
                      value={formData.position_id}
                      onValueChange={(value) => setFormData({ ...formData, position_id: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="აირჩიეთ პოზიცია" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((dept) => (
                          <SelectItem key={dept.id} value={dept.id}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="title">სათაური *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      required
                    />
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="summary">მოკლე აღწერა</Label>
                    <Textarea
                      id="summary"
                      value={formData.summary}
                      onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                      rows={2}
                    />
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="responsibilities">პასუხისმგებლობები *</Label>
                    <Textarea
                      id="responsibilities"
                      value={formData.responsibilities}
                      onChange={(e) => setFormData({ ...formData, responsibilities: e.target.value })}
                      rows={4}
                      required
                    />
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="requirements">მოთხოვნები *</Label>
                    <Textarea
                      id="requirements"
                      value={formData.requirements}
                      onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
                      rows={4}
                      required
                    />
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="qualifications">კვალიფიკაცია</Label>
                    <Textarea
                      id="qualifications"
                      value={formData.qualifications}
                      onChange={(e) => setFormData({ ...formData, qualifications: e.target.value })}
                      rows={3}
                    />
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="skills">უნარები</Label>
                    <Textarea
                      id="skills"
                      value={formData.skills}
                      onChange={(e) => setFormData({ ...formData, skills: e.target.value })}
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="salary_range_min">ხელფასი (მინ.)</Label>
                    <Input
                      id="salary_range_min"
                      type="number"
                      value={formData.salary_range_min}
                      onChange={(e) => setFormData({ ...formData, salary_range_min: e.target.value })}
                    />
                  </div>

                  <div>
                    <Label htmlFor="salary_range_max">ხელფასი (მაქს.)</Label>
                    <Input
                      id="salary_range_max"
                      type="number"
                      value={formData.salary_range_max}
                      onChange={(e) => setFormData({ ...formData, salary_range_max: e.target.value })}
                    />
                  </div>

                  <div>
                    <Label htmlFor="employment_type">დასაქმების ტიპი</Label>
                    <Select
                      value={formData.employment_type}
                      onValueChange={(value) => setFormData({ ...formData, employment_type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="full_time">სრული განაკვეთი</SelectItem>
                        <SelectItem value="part_time">ნაწილობრივი განაკვეთი</SelectItem>
                        <SelectItem value="contract">კონტრაქტი</SelectItem>
                        <SelectItem value="temporary">დროებითი</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="experience_years">გამოცდილება (წლები)</Label>
                    <Input
                      id="experience_years"
                      type="number"
                      value={formData.experience_years}
                      onChange={(e) => setFormData({ ...formData, experience_years: e.target.value })}
                    />
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="education_level">განათლების დონე</Label>
                    <Input
                      id="education_level"
                      value={formData.education_level}
                      onChange={(e) => setFormData({ ...formData, education_level: e.target.value })}
                    />
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="language_requirements">ენების ცოდნა</Label>
                    <Input
                      id="language_requirements"
                      value={formData.language_requirements}
                      onChange={(e) => setFormData({ ...formData, language_requirements: e.target.value })}
                      placeholder="მაგ: ქართული, ინგლისური"
                    />
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="working_conditions">სამუშაო პირობები</Label>
                    <Textarea
                      id="working_conditions"
                      value={formData.working_conditions}
                      onChange={(e) => setFormData({ ...formData, working_conditions: e.target.value })}
                      rows={3}
                    />
                  </div>
                </div>

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    გაუქმება
                  </Button>
                  <Button type="submit" disabled={loading}>
                    დამატება
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="ძიება პოზიციის ან სათაურის მიხედვით..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredJobs.map((job) => (
            <Card key={job.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="text-lg">{job.title}</CardTitle>
                    <CardDescription className="text-sm">
                      {job.departments?.name}
                    </CardDescription>
                  </div>
                  <Badge variant={job.is_active ? "default" : "secondary"}>
                    {job.is_active ? "აქტიური" : "არააქტიური"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {job.summary && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {job.summary}
                    </p>
                  )}
                  
                  <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                    {job.employment_type && (
                      <Badge variant="outline">
                        {job.employment_type === "full_time" ? "სრული" : job.employment_type}
                      </Badge>
                    )}
                    {job.experience_years && (
                      <Badge variant="outline">
                        {job.experience_years} წლის გამოცდილება
                      </Badge>
                    )}
                    {job.salary_range_min && job.salary_range_max && (
                      <Badge variant="outline">
                        ₾{job.salary_range_min} - ₾{job.salary_range_max}
                      </Badge>
                    )}
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setSelectedJob(job);
                        setIsViewDialogOpen(true);
                      }}
                      className="flex-1"
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      ნახვა
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openEditDialog(job)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(job.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Edit Dialog - Similar to Add Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>სამუშაო აღწერილობის რედაქტირება</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleUpdate} className="space-y-4">
              {/* Same form fields as Add Dialog */}
              <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label htmlFor="edit_position_id">პოზიცია *</Label>
                    <Select
                      value={formData.position_id}
                      onValueChange={(value) => setFormData({ ...formData, position_id: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="აირჩიეთ პოზიცია" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((dept) => (
                          <SelectItem key={dept.id} value={dept.id}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="edit_title">სათაური *</Label>
                    <Input
                      id="edit_title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      required
                    />
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="edit_summary">მოკლე აღწერა</Label>
                    <Textarea
                      id="edit_summary"
                      value={formData.summary}
                      onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                      rows={2}
                    />
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="edit_responsibilities">პასუხისმგებლობები *</Label>
                    <Textarea
                      id="edit_responsibilities"
                      value={formData.responsibilities}
                      onChange={(e) => setFormData({ ...formData, responsibilities: e.target.value })}
                      rows={4}
                      required
                    />
                  </div>

                  <div className="col-span-2">
                    <Label htmlFor="edit_requirements">მოთხოვნები *</Label>
                    <Textarea
                      id="edit_requirements"
                      value={formData.requirements}
                      onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
                      rows={4}
                      required
                    />
                  </div>
                </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  გაუქმება
                </Button>
                <Button type="submit" disabled={loading}>
                  განახლება
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* View Dialog */}
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedJob?.title}</DialogTitle>
              <DialogDescription>{selectedJob?.departments?.name}</DialogDescription>
            </DialogHeader>
            {selectedJob && (
              <div className="space-y-4">
                {selectedJob.summary && (
                  <div>
                    <h4 className="font-semibold mb-2">მოკლე აღწერა</h4>
                    <p className="text-sm text-muted-foreground">{selectedJob.summary}</p>
                  </div>
                )}
                
                <div>
                  <h4 className="font-semibold mb-2">პასუხისმგებლობები</h4>
                  <p className="text-sm text-muted-foreground whitespace-pre-line">
                    {selectedJob.responsibilities}
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">მოთხოვნები</h4>
                  <p className="text-sm text-muted-foreground whitespace-pre-line">
                    {selectedJob.requirements}
                  </p>
                </div>

                {selectedJob.qualifications && (
                  <div>
                    <h4 className="font-semibold mb-2">კვალიფიკაცია</h4>
                    <p className="text-sm text-muted-foreground whitespace-pre-line">
                      {selectedJob.qualifications}
                    </p>
                  </div>
                )}

                {selectedJob.skills && (
                  <div>
                    <h4 className="font-semibold mb-2">უნარები</h4>
                    <p className="text-sm text-muted-foreground whitespace-pre-line">
                      {selectedJob.skills}
                    </p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  {selectedJob.salary_range_min && selectedJob.salary_range_max && (
                    <div>
                      <h4 className="font-semibold mb-2">ხელფასი</h4>
                      <p className="text-sm text-muted-foreground">
                        ₾{selectedJob.salary_range_min} - ₾{selectedJob.salary_range_max}
                      </p>
                    </div>
                  )}

                  {selectedJob.experience_years && (
                    <div>
                      <h4 className="font-semibold mb-2">გამოცდილება</h4>
                      <p className="text-sm text-muted-foreground">
                        {selectedJob.experience_years} წელი
                      </p>
                    </div>
                  )}

                  {selectedJob.education_level && (
                    <div>
                      <h4 className="font-semibold mb-2">განათლება</h4>
                      <p className="text-sm text-muted-foreground">
                        {selectedJob.education_level}
                      </p>
                    </div>
                  )}

                  {selectedJob.language_requirements && (
                    <div>
                      <h4 className="font-semibold mb-2">ენები</h4>
                      <p className="text-sm text-muted-foreground">
                        {selectedJob.language_requirements}
                      </p>
                    </div>
                  )}
                </div>

                {selectedJob.working_conditions && (
                  <div>
                    <h4 className="font-semibold mb-2">სამუშაო პირობები</h4>
                    <p className="text-sm text-muted-foreground whitespace-pre-line">
                      {selectedJob.working_conditions}
                    </p>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default JobDescriptions;
