import { useState, useEffect } from "react";
import { Document as DocxDocument, Packer, Paragraph, TextRun } from "docx";
import { Upload, Search, FileText, Download, Trash2, FileSignature, Send, Plus, Edit, Eye, CheckCircle, Archive, Clock, RefreshCw, Loader2 } from "lucide-react";
import { usePersistedState } from "@/hooks/usePersistedState";
import SignifySignDialog from "@/components/documents/SignifySignDialog";
import JSZip from "jszip";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import { useLanguage } from "@/contexts/LanguageContext";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface Document {
  id: string;
  employee_id: string | null;
  title: string;
  description: string | null;
  file_path: string;
  file_type: string | null;
  file_size: number | null;
  category: string | null;
  created_at: string;
  employees: {
    full_name: string;
  } | null;
}

interface DocumentTemplate {
  id: string;
  name: string;
  template_type: string;
  description: string;
  content: string;
  requires_signature: boolean;
  is_active: boolean;
}

interface DocumentSignature {
  id: string;
  document_id: string;
  employee_id: string;
  signed_at: string | null;
  is_acknowledged: boolean;
  employees: {
    full_name: string;
  };
}

export default function Documents() {
  const { user, userRole } = useAuth();
  const { t } = useLanguage();
  const [documents, setDocuments] = useState<Document[]>([]);
  const [templates, setTemplates] = useState<DocumentTemplate[]>([]);
  const [signatures, setSignatures] = useState<DocumentSignature[]>([]);
  const [signifyRequests, setSignifyRequests] = useState<any[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = usePersistedState<string>("documents:search", "");
  const [contractTypeFilter, setContractTypeFilter] = usePersistedState<string>("documents:contractType", "all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  const [isGenerateDialogOpen, setIsGenerateDialogOpen] = useState(false);
  const [isSignDialogOpen, setIsSignDialogOpen] = useState(false);
  const [isSignifyDialogOpen, setIsSignifyDialogOpen] = useState(false);
  const [signifyDocument, setSignifyDocument] = useState<{ id: string; title: string; file_path: string } | null>(null);
  const [existingSigningUrl, setExistingSigningUrl] = useState<string | null>(null);
  const [existingSignerName, setExistingSignerName] = useState<string | null>(null);
  const [existingSignifyDocId, setExistingSignifyDocId] = useState<number | null>(null);
  const [existingRecipientCode, setExistingRecipientCode] = useState<string | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<DocumentTemplate | null>(null);
  const [selectedDocument, setSelectedDocument] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(true);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedDocuments, setSelectedDocuments] = useState<Set<string>>(new Set());

  const canManage = userRole === 'admin' || userRole === 'hr_manager';
  const myEmployeeId = employees.find(e => e.user_id === user?.id)?.id;
  const activeBranchId = useBranchFilter();

  useEffect(() => {
    fetchDocuments();
    fetchEmployees();
    fetchTemplates();
    fetchSignatures();
    fetchSignifyRequests();
  }, [activeBranchId]);

  const fetchEmployees = async () => {
    try {
      let q = supabase
        .from('employees')
        .select('id, user_id, email, full_name, position, department, salary, hire_date');
      if (activeBranchId) q = q.eq('branch_id', activeBranchId);
      const { data, error } = await q;

      if (error) throw error;
      setEmployees(data || []);
    } catch (error: any) {
      console.error('Error fetching employees:', error);
    }
  };

  const fetchDocuments = async () => {
    setIsFetching(true);
    try {
      let q = supabase
        .from('documents')
        .select('*, employees(full_name)')
        .order('created_at', { ascending: false });
      if (activeBranchId) q = q.eq('branch_id', activeBranchId);
      const { data, error } = await q;

      if (error) throw error;
      setDocuments(data || []);
    } catch (error: any) {
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsFetching(false);
    }
  };

  const fetchTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('document_templates')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setTemplates(data || []);
    } catch (error: any) {
      console.error('Error fetching templates:', error);
    }
  };

  const fetchSignatures = async () => {
    try {
      const { data, error } = await supabase
        .from('document_signatures')
        .select('*, employees(full_name)')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSignatures(data || []);
    } catch (error: any) {
      console.error('Error fetching signatures:', error);
    }
  };

  const fetchSignifyRequests = async () => {
    try {
      const { data, error } = await supabase
        .from('signify_signing_requests' as any)
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSignifyRequests(data || []);
    } catch (error: any) {
      console.error('Error fetching signify requests:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      if (!selectedFile) {
        toast.error('გთხოვთ აირჩიოთ ფაილი');
        return;
      }

      const fileExt = selectedFile.name.split('.').pop();
      const fileName = `${user?.id}/${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('documents')
        .upload(fileName, selectedFile);

      if (uploadError) throw uploadError;

      const payload = {
        employee_id: (formData.get('employee_id') as string) || null,
        title: formData.get('title') as string,
        description: (formData.get('description') as string) || null,
        file_path: fileName,
        file_type: selectedFile.type,
        file_size: selectedFile.size,
        category: (formData.get('category') as string) || null,
        uploaded_by: user?.id as string,
      };

      const { error } = await supabase
        .from('documents')
        .insert([payload]);

      if (error) throw error;
      toast.success(t('documents.documentAdded'));
      setIsDialogOpen(false);
      setSelectedFile(null);
      fetchDocuments();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleTemplateSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const payload = {
        name: formData.get('name') as string,
        template_type: formData.get('template_type') as string,
        description: (formData.get('description') as string) || null,
        content: formData.get('content') as string,
        requires_signature: formData.get('requires_signature') === 'true',
        is_active: true,
        created_by: user?.id,
      };

      if (selectedTemplate) {
        const { error } = await supabase
          .from('document_templates')
          .update(payload)
          .eq('id', selectedTemplate.id);
        if (error) throw error;
        toast.success('შაბლონი განახლდა');
      } else {
        const { error } = await supabase
          .from('document_templates')
          .insert([payload]);
        if (error) throw error;
        toast.success('შაბლონი შეიქმნა');
      }

      setIsTemplateDialogOpen(false);
      setSelectedTemplate(null);
      fetchTemplates();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateDocument = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      if (!user?.id) {
        toast.error('მომხმარებელი არ არის ავტორიზებული');
        return;
      }

      const templateId = formData.get('template_id');
      const template = templates.find(t => t.id === templateId);
      if (!template) {
        console.error('Template not found:', templateId);
        throw new Error('შაბლონი არ მოიძებნა');
      }

      const employeeId = formData.get('employee_id') as string;
      const employee = employees.find(e => e.id === employeeId);
      if (!employee) {
        console.error('Employee not found:', employeeId);
        throw new Error('თანამშრომელი არ მოიძებნა');
      }

      // Replace placeholders in template
      let content = template.content;
      content = content.replace(/\{სახელი\}/g, employee.full_name);
      content = content.replace(/\{პოზიცია\}/g, employee.position || '');
      content = content.replace(/\{დეპარტამენტი\}/g, employee.department || '');
      content = content.replace(/\{ხელფასი\}/g, employee.salary?.toString() || '');
      content = content.replace(/\{თარიღი\}/g, new Date().toLocaleDateString('ka-GE'));
      content = content.replace(/\{დაქირავების_თარიღი\}/g, employee.hire_date ? new Date(employee.hire_date).toLocaleDateString('ka-GE') : '');

      // Create Word document
      const paragraphs = content.split('\n').map(line => 
        new Paragraph({
          children: [new TextRun({ text: line, size: 24 })],
          spacing: { after: 200 }
        })
      );

      const doc = new DocxDocument({
        sections: [{
          properties: {},
          children: paragraphs
        }]
      });

      const blob = await Packer.toBlob(doc);
      
      // Sanitize filename to avoid Storage "Invalid key"
      const baseName = template.name.replace(/\s+/g, '_');
      const safeName = baseName
        .normalize('NFKD')
        .replace(/[^\x00-\x7F]/g, '') // remove non-ASCII
        .replace(/[^a-zA-Z0-9._-]/g, '_') // keep safe chars
        .slice(0, 80);
      // Use user's folder for proper RLS access
      const fileName = `${user.id}/generated_${Date.now()}_${safeName || 'document'}.docx`;
      
      const { error: uploadError } = await supabase.storage
        .from('documents')
        .upload(fileName, blob, {
          contentType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw uploadError;
      }

      const payload = {
        employee_id: employeeId,
        title: `${template.name} - ${employee.full_name}`,
        description: template.description,
        file_path: fileName,
        file_type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        file_size: blob.size,
        category: template.template_type,
        uploaded_by: user?.id as string,
      };

      const { data: docData, error: docError } = await supabase
        .from('documents')
        .insert([payload])
        .select()
        .single();

      if (docError) {
        console.error('Document insert error:', docError);
        toast.error(`დოკუმენტის შენახვა ვერ მოხერხდა: ${docError.message}`);
        throw docError;
      }


      // If requires signature, create signature request
      if (template.requires_signature) {
        const { error: sigError } = await supabase
          .from('document_signatures')
          .insert([{
            document_id: docData.id,
            employee_id: employeeId,
            is_acknowledged: false,
          }]);
        
        if (sigError) {
          console.error('Signature creation error:', sigError);
          toast.error(`ხელმოწერის მოთხოვნა ვერ შეიქმნა: ${sigError.message}`);
          throw sigError;
        }
      }

      toast.success('დოკუმენტი გენერირებულია');
      setIsGenerateDialogOpen(false);
      fetchDocuments();
      fetchSignatures();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSign = async (signatureId: string) => {
    try {
      const { error } = await supabase
        .from('document_signatures')
        .update({
          is_acknowledged: true,
          signed_at: new Date().toISOString(),
          signature_data: 'Electronic Signature',
          ip_address: 'Unknown',
        })
        .eq('id', signatureId);

      if (error) throw error;
      toast.success('დოკუმენტი ხელმოწერილია');
      fetchSignatures();
      setIsSignDialogOpen(false);
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    }
  };

  const handleDownload = async (filePath: string, title: string, documentId?: string) => {
    try {
      // Log document access
      if (documentId) {
        const { logSensitiveDataAccess } = await import('@/lib/securityLogger');
        await logSensitiveDataAccess('documents', documentId);
      }

      const { data, error } = await supabase.storage
        .from('documents')
        .download(filePath);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = title;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error: any) {
      toast.error('ჩამოტვირთვა ვერ მოხერხდა');
    }
  };

  const handleDelete = async (id: string, filePath: string) => {
    if (!canManage) {
      toast.error('არ გაქვთ უფლება');
      return;
    }

    if (!confirm('დარწმუნებული ხართ რომ გსურთ წაშლა?')) return;

    try {
      const { error: storageError } = await supabase.storage
        .from('documents')
        .remove([filePath]);

      if (storageError) throw storageError;

      const { error } = await supabase
        .from('documents')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast.success(t('documents.documentDeleted'));
      fetchDocuments();
    } catch (error: any) {
      toast.error('წაშლა ვერ მოხერხდა');
    }
  };

  const handleBulkDownload = async () => {
    if (selectedDocuments.size === 0) {
      toast.error('აირჩიეთ დოკუმენტები');
      return;
    }

    try {
      const zip = new JSZip();
      const docsToDownload = documents.filter(doc => selectedDocuments.has(doc.id));
      
      toast.info(`იტვირთება ${docsToDownload.length} დოკუმენტი...`);

      for (const doc of docsToDownload) {
        try {
          const { data, error } = await supabase.storage
            .from('documents')
            .download(doc.file_path);

          if (error) throw error;

          const fileExt = doc.file_path.split('.').pop() || 'bin';
          const sanitizedTitle = doc.title.replace(/[^a-zA-Z0-9_\u10A0-\u10FF]/g, '_');
          const fileName = `${sanitizedTitle}.${fileExt}`;
          
          zip.file(fileName, data);
        } catch (err) {
          console.error(`Error downloading ${doc.title}:`, err);
        }
      }

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = `documents_${new Date().toISOString().split('T')[0]}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success('დოკუმენტები ჩამოტვირთულია');
      setSelectedDocuments(new Set());
    } catch (error: any) {
      toast.error('ZIP ფაილის შექმნა ვერ მოხერხდა');
      console.error('Bulk download error:', error);
    }
  };

  const toggleDocumentSelection = (docId: string) => {
    const newSelection = new Set(selectedDocuments);
    if (newSelection.has(docId)) {
      newSelection.delete(docId);
    } else {
      newSelection.add(docId);
    }
    setSelectedDocuments(newSelection);
  };

  const toggleSelectAll = () => {
    if (selectedDocuments.size === filteredDocuments.length) {
      setSelectedDocuments(new Set());
    } else {
      setSelectedDocuments(new Set(filteredDocuments.map(doc => doc.id)));
    }
  };

  const filteredDocuments = documents.filter((doc) => {
    const matchesSearch = doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.employees?.full_name?.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (contractTypeFilter === "all") return matchesSearch;
    
    const titleLower = doc.title.toLowerCase();
    if (contractTypeFilter === "probation") {
      return matchesSearch && titleLower.includes("გამოსაცდელი");
    }
    if (contractTypeFilter === "internship") {
      return matchesSearch && titleLower.includes("სტაჟირება");
    }
    if (contractTypeFilter === "permanent") {
      return matchesSearch && (titleLower.includes("უვადო") || titleLower.includes("ხელშეკრულება"));
    }
    
    return matchesSearch;
  });

  const formatFileSize = (bytes: number | null) => {
    if (!bytes) return '-';
    const kb = bytes / 1024;
    if (kb < 1024) return `${kb.toFixed(2)} KB`;
    return `${(kb / 1024).toFixed(2)} MB`;
  };

  // Default templates
  const defaultTemplates = [
    {
      name: 'შრომითი ხელშეკრულება',
      type: 'contract',
      content: `შრომითი ხელშეკრულება

ხელშეკრულება დადებულია შემდეგ მხარეებს შორის:

დამსაქმებელი: [კომპანიის სახელი]
თანამშრომელი: {სახელი}

პოზიცია: {პოზიცია}
დეპარტამენტი: {დეპარტამენტი}
ხელფასი: {ხელფასი} ლარი
დაწყების თარიღი: {დაქირავების_თარიღი}

ხელშეკრულება ძალაშია {თარიღი}-დან.`
    },
    {
      name: 'ბრძანება ხელფასის ცვლილებაზე',
      type: 'order',
      content: `ბრძანება #___

თანამშრომლის: {სახელი}
პოზიცია: {პოზიცია}
დეპარტამენტი: {დეპარტამენტი}

ხელფასის ცვლილება:
ახალი ხელფასი: {ხელფასი} ლარი
ძალაშია: {თარიღი}-დან

დირექტორი: _______________
თარიღი: {თარიღი}`
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <FileText className="h-8 w-8" />
            {t('documents.title')}
          </h1>
          <p className="mt-2 text-muted-foreground">ელექტრონული დოკუმენტების მართვა, შაბლონები და ხელმოწერები</p>
        </div>
      </div>

      <Tabs defaultValue="documents" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="documents">დოკუმენტები</TabsTrigger>
          <TabsTrigger value="templates">შაბლონები</TabsTrigger>
          <TabsTrigger value="generate">გენერაცია</TabsTrigger>
          <TabsTrigger value="signatures">ხელმოწერები</TabsTrigger>
        </TabsList>

        {/* დოკუმენტები */}
        <TabsContent value="documents" className="space-y-4">
          <div className="flex gap-2 flex-col sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder={t('common.search')}
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={contractTypeFilter} onValueChange={setContractTypeFilter}>
              <SelectTrigger className="w-full sm:w-[240px]">
                <SelectValue placeholder="ხელშეკრულების ტიპი" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ყველა ტიპი</SelectItem>
                <SelectItem value="probation">გამოსაცდელი ვადით</SelectItem>
                <SelectItem value="internship">სტაჟირება</SelectItem>
                <SelectItem value="permanent">უვადო ხელშეკრულება</SelectItem>
              </SelectContent>
            </Select>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Upload className="h-4 w-4" />
                  ატვირთვა
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>დოკუმენტის ატვირთვა</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="title">დასახელება *</Label>
                    <Input id="title" name="title" required />
                  </div>
                  <div>
                    <Label htmlFor="employee_id">თანამშრომელი</Label>
                    <Select name="employee_id">
                      <SelectTrigger>
                        <SelectValue placeholder="არჩევითი" />
                      </SelectTrigger>
                      <SelectContent>
                        {employees.map((emp) => (
                          <SelectItem key={emp.id} value={emp.id}>
                            {emp.full_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="category">კატეგორია</Label>
                    <Select name="category">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="contract">ხელშეკრულება</SelectItem>
                        <SelectItem value="order">ბრძანება</SelectItem>
                        <SelectItem value="certificate">სერტიფიკატი</SelectItem>
                        <SelectItem value="report">ანგარიში</SelectItem>
                        <SelectItem value="other">სხვა</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="description">აღწერა</Label>
                    <Textarea id="description" name="description" />
                  </div>
                  <div>
                    <Label htmlFor="file">ფაილი *</Label>
                    <Input
                      id="file"
                      type="file"
                      required
                      onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? 'იტვირთება...' : 'ატვირთვა'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {filteredDocuments.length > 0 && (
            <div className="mb-4 flex items-center gap-4">
              <Button
                variant="outline"
                size="sm"
                onClick={toggleSelectAll}
              >
                <input
                  type="checkbox"
                  checked={selectedDocuments.size === filteredDocuments.length && filteredDocuments.length > 0}
                  onChange={toggleSelectAll}
                  className="mr-2 h-4 w-4"
                />
                ყველას არჩევა
              </Button>
              
              {selectedDocuments.size > 0 && (
                <Button
                  onClick={handleBulkDownload}
                  className="gap-2"
                >
                  <Archive className="h-4 w-4" />
                  ZIP ჩამოტვირთვა ({selectedDocuments.size})
                </Button>
              )}
            </div>
          )}

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredDocuments.map((doc) => (
              <Card key={doc.id} className="transition-all hover:shadow-lg">
                <CardContent className="p-6">
                  <div className="mb-4 flex items-start justify-between">
                    <div className="flex h-16 w-16 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent">
                      <FileText className="h-8 w-8 text-white" />
                    </div>
                    <input
                      type="checkbox"
                      checked={selectedDocuments.has(doc.id)}
                      onChange={() => toggleDocumentSelection(doc.id)}
                      className="h-5 w-5 cursor-pointer"
                    />
                  </div>
                  <h3 className="text-lg font-semibold">{doc.title}</h3>
                  {doc.employees && (
                    <p className="text-sm text-muted-foreground">{doc.employees.full_name}</p>
                  )}
                  {doc.category && (
                    <Badge variant="outline" className="mt-2">{doc.category}</Badge>
                  )}
                  <div className="mt-4 space-y-2 border-t border-border pt-4">
                    <p className="text-xs text-muted-foreground">
                      {new Date(doc.created_at).toLocaleDateString('ka-GE')}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(doc.file_size)}
                    </p>
                    {doc.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2">{doc.description}</p>
                    )}
                  </div>
                  <div className="mt-4 flex gap-2 flex-wrap">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => handleDownload(doc.file_path, doc.title, doc.id)}
                    >
                      <Download className="mr-1 h-3 w-3" />
                      ჩამოტვირთვა
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setSignifyDocument({ id: doc.id, title: doc.title, file_path: doc.file_path });
                        setIsSignifyDialogOpen(true);
                      }}
                      title="Signify ხელმოწერა"
                    >
                      <FileSignature className="h-3 w-3" />
                    </Button>
                    {canManage && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setSelectedDocument(doc);
                            setIsSignDialogOpen(true);
                          }}
                          title="შიდა ხელმოწერა"
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDelete(doc.id, doc.file_path)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {isFetching ? (
            <div className="flex h-64 items-center justify-center text-muted-foreground">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : filteredDocuments.length === 0 && (
            <div className="flex h-64 items-center justify-center text-muted-foreground">
              დოკუმენტები არ მოიძებნა
            </div>
          )}
        </TabsContent>

        {/* შაბლონები */}
        <TabsContent value="templates" className="space-y-4">
          {canManage && (
            <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2" onClick={() => setSelectedTemplate(null)}>
                  <Plus className="h-4 w-4" />
                  ახალი შაბლონი
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-3xl">
                <DialogHeader>
                  <DialogTitle>{selectedTemplate ? 'შაბლონის რედაქტირება' : 'ახალი შაბლონი'}</DialogTitle>
                  <DialogDescription>
                    გამოიყენეთ: {'{სახელი}'}, {'{პოზიცია}'}, {'{დეპარტამენტი}'}, {'{ხელფასი}'}, {'{თარიღი}'}, {'{დაქირავების_თარიღი}'}
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleTemplateSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="name">დასახელება *</Label>
                    <Input id="name" name="name" required defaultValue={selectedTemplate?.name} />
                  </div>
                  <div>
                    <Label htmlFor="template_type">ტიპი *</Label>
                    <Select name="template_type" defaultValue={selectedTemplate?.template_type}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="contract">ხელშეკრულება</SelectItem>
                        <SelectItem value="order">ბრძანება</SelectItem>
                        <SelectItem value="certificate">სერტიფიკატი</SelectItem>
                        <SelectItem value="notification">შეტყობინება</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="description">აღწერა</Label>
                    <Input id="description" name="description" defaultValue={selectedTemplate?.description || ''} />
                  </div>
                  <div>
                    <Label htmlFor="content">შაბლონის ტექსტი *</Label>
                    <Textarea 
                      id="content" 
                      name="content" 
                      required 
                      rows={10}
                      defaultValue={selectedTemplate?.content}
                      className="font-mono"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <input type="checkbox" id="requires_signature" name="requires_signature" value="true" defaultChecked={selectedTemplate?.requires_signature} />
                    <Label htmlFor="requires_signature">საჭიროებს ხელმოწერას</Label>
                  </div>
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? 'მიმდინარეობს...' : selectedTemplate ? 'განახლება' : 'შექმნა'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          )}

          <div className="grid gap-4 md:grid-cols-2">
            {templates.map((template) => (
              <Card key={template.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2">
                        {template.name}
                        {template.requires_signature && (
                          <Badge variant="secondary" className="text-xs">
                            <FileSignature className="h-3 w-3 mr-1" />
                            ხელმოწერა
                          </Badge>
                        )}
                      </CardTitle>
                      <CardDescription>{template.description}</CardDescription>
                    </div>
                    {canManage && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setSelectedTemplate(template);
                          setIsTemplateDialogOpen(true);
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <Badge variant="outline">{template.template_type}</Badge>
                  <pre className="mt-3 whitespace-pre-wrap rounded bg-muted p-3 text-xs font-mono max-h-32 overflow-auto">
                    {template.content.substring(0, 200)}...
                  </pre>
                </CardContent>
              </Card>
            ))}
          </div>

          {templates.length === 0 && canManage && (
            <Card className="p-8">
              <div className="text-center space-y-4">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground" />
                <div>
                  <h3 className="font-semibold mb-2">ნაგულისხმევი შაბლონების დამატება</h3>
                  <p className="text-sm text-muted-foreground mb-4">დაამატეთ შრომითი ხელშეკრულება და ბრძანება ხელფასის ცვლილებაზე</p>
                  <Button onClick={async () => {
                    setIsLoading(true);
                    try {
                      for (const tmpl of defaultTemplates) {
                        await supabase.from('document_templates').insert({
                          name: tmpl.name,
                          template_type: tmpl.type,
                          description: tmpl.name,
                          content: tmpl.content,
                          requires_signature: true,
                          is_active: true,
                          created_by: user?.id,
                        });
                      }
                      toast.success('შაბლონები დაემატა');
                      fetchTemplates();
                    } catch (error: any) {
                      toast.error('შეცდომა');
                    }
                    setIsLoading(false);
                  }}>
                    შაბლონების დამატება
                  </Button>
                </div>
              </div>
            </Card>
          )}
        </TabsContent>

        {/* გენერაცია */}
        <TabsContent value="generate" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>დოკუმენტის გენერაცია შაბლონიდან</CardTitle>
              <CardDescription>აირჩიეთ შაბლონი და თანამშრომელი დოკუმენტის ავტომატური გენერაციისთვის</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleGenerateDocument} className="space-y-4">
                <div>
                  <Label htmlFor="template_id">შაბლონი *</Label>
                  <Select name="template_id" required>
                    <SelectTrigger>
                      <SelectValue placeholder="აირჩიეთ შაბლონი" />
                    </SelectTrigger>
                    <SelectContent>
                      {templates.map((template) => (
                        <SelectItem key={template.id} value={template.id}>
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="employee_id">თანამშრომელი *</Label>
                  <Select name="employee_id" required>
                    <SelectTrigger>
                      <SelectValue placeholder="აირჩიეთ თანამშრომელი" />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.full_name} - {emp.position}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  <Send className="h-4 w-4 mr-2" />
                  {isLoading ? 'გენერირდება...' : 'დოკუმენტის გენერაცია'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ხელმოწერები */}
        <TabsContent value="signatures" className="space-y-4">
          {/* Signify ხელმოწერები */}
          {signifyRequests.length > 0 && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <FileSignature className="h-5 w-5 text-primary" />
                      Signify ხელმოწერები
                    </CardTitle>
                    <CardDescription>ელექტრონული ხელმოწერის მოთხოვნები</CardDescription>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={async () => {
                      // Get unique signify_document_ids that have pending requests
                      const pendingDocIds = [...new Set(
                        signifyRequests
                          .filter((r: any) => r.status === 'pending')
                          .map((r: any) => r.signify_document_id)
                      )];
                      if (!pendingDocIds.length) {
                        toast.info('ყველა ხელმოწერა უკვე დასრულებულია');
                        return;
                      }
                      try {
                        const { data, error } = await supabase.functions.invoke('signify-sign', {
                          body: {
                            action: 'get-documents-status',
                            documentIds: pendingDocIds,
                          },
                        });
                        if (error || data?.ok === false) throw new Error(data?.error || 'სტატუსის შემოწმება ვერ მოხერხდა');
                        
                        // Update local DB based on Signify response
                        const docs = data.documents || [];
                        let failedUpdates = 0;
                        for (const doc of docs) {
                          if (doc.recipients) {
                            for (const recipient of doc.recipients) {
                              if (recipient.status === 'SIGNED' || recipient.status === 'FINISHED') {
                                const { error: upErr } = await supabase
                                  .from('signify_signing_requests' as any)
                                  .update({ status: 'signed', signed_at: new Date().toISOString() } as any)
                                  .eq('signify_document_id', doc.documentId)
                                  .eq('signify_recipient_id', recipient.id);
                                if (upErr) failedUpdates++;
                              }
                            }
                          }
                          // If whole document is finished, mark all as signed
                          if (doc.documentStatus === 'FINISHED') {
                            const { error: upErr } = await supabase
                              .from('signify_signing_requests' as any)
                              .update({ status: 'signed', signed_at: new Date().toISOString() } as any)
                              .eq('signify_document_id', doc.documentId)
                              .eq('status', 'pending');
                            if (upErr) failedUpdates++;
                          }
                        }
                        
                        fetchSignifyRequests();
                        if (failedUpdates > 0) {
                          toast.error('სტატუსი ვერ განახლდა ბაზაში. სცადეთ თავიდან');
                          return;
                        }
                        toast.success('სტატუსი განახლდა');
                      } catch (err: any) {
                        console.error('Status check error:', err);
                        toast.error(err.message || 'შეცდომა');
                      }
                    }}
                    className="gap-1"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                    განახლება
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {(() => {
                  // Group signing requests by signify_document_id
                  const grouped = signifyRequests.reduce((acc: Record<string, any[]>, req: any) => {
                    const key = req.signify_document_id || req.id;
                    if (!acc[key]) acc[key] = [];
                    acc[key].push(req);
                    return acc;
                  }, {});

                  return Object.entries(grouped).map(([docId, reqs]: [string, any[]]) => {
                    const firstReq = reqs[0];
                    const doc = documents.find(d => d.id === firstReq.document_id);
                    const myEmail = employees.find((e: any) => e.user_id === user?.id)?.email;
                    const allSigned = reqs.every(r => r.status === 'signed');
                    // Prioritize finding request by email match (the user's own signing request)
                    // Only fall back to initiated_by if no email match exists
                    const myReq = reqs.find(r => r.recipient_email === myEmail) 
                      || reqs.find(r => r.initiated_by === user?.id && r.recipient_email === myEmail);

                    return (
                      <Card key={docId} className="border">
                        <CardContent className="p-4 space-y-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">{doc?.title || `დოკუმენტი #${docId}`}</p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(firstReq.created_at).toLocaleString('ka-GE')}
                              </p>
                            </div>
                            {allSigned ? (
                              <Badge className="gap-1 bg-green-600 text-white font-bold hover:bg-green-700">
                                <CheckCircle className="h-3 w-3" />
                                სრულად ხელმოწერილი
                              </Badge>
                            ) : (
                              <Badge variant="outline">მიმდინარე</Badge>
                            )}
                          </div>
                          <div className="space-y-2">
                            <p className="text-xs font-medium text-muted-foreground">ხელმომწერები:</p>
                            {reqs.map((req: any) => (
                              <div key={req.id} className="flex items-center justify-between rounded-md bg-muted/50 px-3 py-2">
                                <div className="flex items-center gap-2">
                                  {req.status === 'signed' ? (
                                    <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0" />
                                  ) : (
                                    <Clock className="h-4 w-4 text-muted-foreground shrink-0" />
                                  )}
                                  <div>
                                    <span className="text-sm">{req.recipient_name}</span>
                                    {req.recipient_email && (
                                      <span className="text-xs text-muted-foreground block">{req.recipient_email}</span>
                                    )}
                                  </div>
                                </div>
                                <span className="text-xs text-muted-foreground">
                                  {req.status === 'signed' 
                                    ? req.signed_at ? new Date(req.signed_at).toLocaleString('ka-GE') : 'ხელმოწერილი'
                                    : 'მოლოდინში'}
                                </span>
                              </div>
                            ))}
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {myReq && myReq.status === 'pending' && myReq.signing_url && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setExistingSigningUrl(myReq.signing_url);
                                  setExistingSignerName(myReq.recipient_name);
                                  setExistingSignifyDocId(Number(firstReq.signify_document_id));
                                  setExistingRecipientCode(myReq.recipient_code);
                                  if (doc) {
                                    setSignifyDocument({ id: doc.id, title: doc.title, file_path: doc.file_path });
                                  }
                                  setIsSignifyDialogOpen(true);
                                }}
                                className="gap-1 flex-1"
                              >
                                <FileSignature className="h-3 w-3" />
                                ხელმოწერა
                              </Button>
                            )}
                            {allSigned && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={async () => {
                                  try {
                                    const { data: sessionData } = await supabase.auth.getSession();
                                    const token = sessionData?.session?.access_token;
                                    if (!token) { toast.error('გაიარეთ ავტორიზაცია'); return; }
                                    
                                    toast.loading('ჩამოტვირთვა...', { id: 'sig-download' });
                                    
                                    const res = await fetch(
                                      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/signify-sign`,
                                      {
                                        method: 'POST',
                                        headers: {
                                          'Content-Type': 'application/json',
                                          'Authorization': `Bearer ${token}`,
                                        },
                                        body: JSON.stringify({
                                          action: 'download-document',
                                          documentId: Number(docId),
                                          originalDocumentId: firstReq.document_id,
                                          originalFilePath: doc?.file_path,
                                        }),
                                      }
                                    );
                                    const result = await res.json();
                                    
                                    if (!result.success || !result.fileBase64) {
                                      throw new Error(result.error || 'ჩამოტვირთვა ვერ მოხერხდა');
                                    }
                                    
                                    const byteChars = atob(result.fileBase64);
                                    const byteArray = new Uint8Array(byteChars.length);
                                    for (let i = 0; i < byteChars.length; i++) {
                                      byteArray[i] = byteChars.charCodeAt(i);
                                    }
                                    const blob = new Blob([byteArray], { type: 'application/pdf' });
                                    const url = URL.createObjectURL(blob);
                                    const a = document.createElement('a');
                                    a.href = url;
                                    a.download = result.fileName || `${doc?.title || 'document'}_signed.pdf`;
                                    document.body.appendChild(a);
                                    a.click();
                                    document.body.removeChild(a);
                                    URL.revokeObjectURL(url);
                                    
                                    toast.success('ხელმოწერილი დოკუმენტი ჩამოტვირთულია', { id: 'sig-download' });
                                  } catch (err: any) {
                                    console.error('Download error:', err);
                                    toast.error(err.message || 'ჩამოტვირთვა ვერ მოხერხდა', { id: 'sig-download' });
                                  }
                                }}
                                className="gap-1 flex-1"
                              >
                                <Download className="h-3 w-3" />
                                ჩამოტვირთვა
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  });
                })()}
              </CardContent>
            </Card>
          )}

          {/* შიდა ხელმოწერები */}
          <Card>
            <CardHeader>
              <CardTitle>შიდა ხელმოწერები</CardTitle>
              <CardDescription>დოკუმენტების დასტურის სტატუსი</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>თანამშრომელი</TableHead>
                    <TableHead>სტატუსი</TableHead>
                    <TableHead>თარიღი</TableHead>
                    <TableHead>მოქმედება</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {signatures.map((sig) => (
                    <TableRow key={sig.id}>
                      <TableCell className="font-medium">{sig.employees.full_name}</TableCell>
                      <TableCell>
                        {sig.is_acknowledged ? (
                          <Badge variant="secondary" className="gap-1">
                            <CheckCircle className="h-3 w-3" />
                            ხელმოწერილი
                          </Badge>
                        ) : (
                          <Badge variant="outline">მოლოდინში</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {sig.signed_at ? new Date(sig.signed_at).toLocaleString('ka-GE') : '-'}
                      </TableCell>
                      <TableCell>
                        {!sig.is_acknowledged && sig.employee_id === myEmployeeId && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleSign(sig.id)}
                            aria-label="ხელმოწერა"
                          >
                            <FileSignature className="h-3 w-3 mr-1" />
                            ხელმოწერა
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {signatures.length === 0 && signifyRequests.length === 0 && (
                <div className="flex h-32 items-center justify-center text-muted-foreground">
                  ხელმოწერები არ მოიძებნა
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* შიდა ხელმოწერის დიალოგი */}
      <Dialog open={isSignDialogOpen} onOpenChange={setIsSignDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="h-5 w-5 text-primary" />
              შიდა ხელმოწერა
            </DialogTitle>
            <DialogDescription>
              აირჩიეთ თანამშრომელი დოკუმენტის შიდა ხელმოწერისთვის
            </DialogDescription>
          </DialogHeader>

          {selectedDocument && (
            <div className="p-3 rounded-lg border bg-card">
              <p className="text-sm font-medium">დოკუმენტი:</p>
              <p className="text-sm text-muted-foreground">{selectedDocument.title}</p>
            </div>
          )}

          <form onSubmit={async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target as HTMLFormElement);
            const employeeId = formData.get('sign_employee_id') as string;
            if (!selectedDocument || !employeeId) return;
            
            setIsLoading(true);
            try {
              const { error } = await supabase
                .from('document_signatures')
                .insert([{
                  document_id: selectedDocument.id,
                  employee_id: employeeId,
                  is_acknowledged: false,
                }]);
              
              if (error) throw error;
              toast.success('ხელმოწერის მოთხოვნა გაიგზავნა');
              setIsSignDialogOpen(false);
              fetchSignatures();
            } catch (error: any) {
              toast.error('შეცდომა: ' + error.message);
            }
            setIsLoading(false);
          }} className="space-y-4">
            <div>
              <Label>თანამშრომელი *</Label>
              <Select name="sign_employee_id" required>
                <SelectTrigger>
                  <SelectValue placeholder="აირჩიეთ თანამშრომელი..." />
                </SelectTrigger>
                <SelectContent>
                  {employees.map(emp => (
                    <SelectItem key={emp.id} value={emp.id}>
                      {emp.full_name} ({emp.email || emp.position})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" type="button" onClick={() => setIsSignDialogOpen(false)}>
                გაუქმება
              </Button>
              <Button type="submit" disabled={isLoading}>
                <Send className="h-4 w-4 mr-2" />
                {isLoading ? 'იგზავნება...' : 'ხელმოწერის მოთხოვნა'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <SignifySignDialog
        open={isSignifyDialogOpen}
        onOpenChange={(open) => {
          setIsSignifyDialogOpen(open);
          if (!open) {
            setExistingSigningUrl(null);
            setExistingSignerName(null);
            setExistingSignifyDocId(null);
            setExistingRecipientCode(null);
          }
        }}
        document={signifyDocument}
        employees={employees}
        existingSigningUrl={existingSigningUrl}
        existingSignerName={existingSignerName}
        existingSignifyDocId={existingSignifyDocId}
        existingRecipientCode={existingRecipientCode}
        onSigningComplete={fetchSignifyRequests}
      />
    </div>
  );
}
