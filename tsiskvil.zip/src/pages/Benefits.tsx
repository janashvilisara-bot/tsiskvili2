import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Plus, Heart, Shield, Eye, Briefcase } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

interface BenefitPlan {
  id: string;
  plan_name: string;
  plan_type: string;
  provider_name: string;
  coverage_details: string;
  employee_contribution: number;
  employer_contribution: number;
  is_active: boolean;
  enrollment_start_date: string;
  enrollment_end_date: string;
}

interface EmployeeBenefit {
  id: string;
  employee_id: string;
  benefit_plan_id: string;
  enrollment_date: string;
  status: string;
  coverage_level: string;
  employee_contribution: number;
  employer_contribution: number;
  benefit_plans: BenefitPlan;
}

export default function Benefits() {
  const [benefitPlans, setBenefitPlans] = useState<BenefitPlan[]>([]);
  const [myBenefits, setMyBenefits] = useState<EmployeeBenefit[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBenefitPlans();
    fetchMyBenefits();
  }, []);

  const fetchBenefitPlans = async () => {
    const { data, error } = await supabase
      .from("benefit_plans" as any)
      .select("*")
      .eq("is_active", true)
      .order("plan_name");
    
    if (error) {
      toast.error("შეცდომა სარგებლების ჩატვირთვისას");
    } else {
      setBenefitPlans(data as any || []);
    }
    setLoading(false);
  };

  const fetchMyBenefits = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: employee } = await supabase
      .from("employees")
      .select("id")
      .eq("user_id", user.id)
      .single();

    if (!employee) return;

    const { data, error } = await supabase
      .from("employee_benefit_enrollments")
      .select(`
        *,
        benefit_plans (*)
      `)
      .eq("employee_id", employee.id)
      .order("enrollment_date", { ascending: false });
    
    if (error) {
      console.error("Error fetching benefits:", error);
      toast.error("შეცდომა სარგებლების ჩატვირთვისას");
    } else {
      setMyBenefits(data as any || []);
    }
  };

  const handleEnroll = async (planId: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("გთხოვთ შეხვიდეთ სისტემაში");
      return;
    }

    const { data: employee } = await supabase
      .from("employees")
      .select("id")
      .eq("user_id", user.id)
      .single();

    if (!employee) {
      toast.error("თანამშრომელი ვერ მოიძებნა");
      return;
    }

    // Get the benefit plan details
    const plan = benefitPlans.find(p => p.id === planId);
    if (!plan) return;

    const { error } = await supabase
      .from("employee_benefit_enrollments")
      .insert({
        employee_id: employee.id,
        benefit_plan_id: planId,
        enrollment_date: new Date().toISOString().split('T')[0],
        status: 'active',
        coverage_level: 'standard',
        employee_contribution: plan.employee_contribution || 0,
        employer_contribution: plan.employer_contribution || 0
      });

    if (error) {
      console.error("Enrollment error:", error);
      toast.error("რეგისტრაციის შეცდომა");
    } else {
      toast.success("წარმატებით დარეგისტრირდით");
      fetchMyBenefits();
    }
  };

  const getBenefitIcon = (type: string) => {
    switch (type) {
      case "health": return <Heart className="h-6 w-6" />;
      case "pension": return <Shield className="h-6 w-6" />;
      case "dental": return <Eye className="h-6 w-6" />;
      case "life_insurance": return <Briefcase className="h-6 w-6" />;
      default: return <Heart className="h-6 w-6" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: "default" | "secondary" | "destructive" | "outline" } = {
      active: "default",
      pending: "secondary",
      cancelled: "destructive",
      expired: "outline"
    };
    return <Badge variant={variants[status] || "outline"}>{status}</Badge>;
  };

  return (
    <>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">სარგებლების მენეჯმენტი</h1>
        </div>

        <Tabs defaultValue="my-benefits">
          <TabsList>
            <TabsTrigger value="my-benefits">ჩემი სარგებლები</TabsTrigger>
            <TabsTrigger value="available">ხელმისაწვდომი სარგებლები</TabsTrigger>
          </TabsList>

          <TabsContent value="my-benefits" className="space-y-4">
            {myBenefits.length === 0 ? (
              <Card className="p-6 text-center">
                <p className="text-muted-foreground">თქვენ არ გაქვთ რეგისტრირებული სარგებლები</p>
              </Card>
            ) : (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {myBenefits.map((benefit) => (
                  <Card key={benefit.id} className="p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        {getBenefitIcon(benefit.benefit_plans.plan_type)}
                        <div>
                          <h3 className="font-semibold">{benefit.benefit_plans.plan_name}</h3>
                          <p className="text-sm text-muted-foreground">{benefit.benefit_plans.provider_name}</p>
                        </div>
                      </div>
                      {getStatusBadge(benefit.status)}
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">დაფარვის დონე:</span>
                        <span className="font-medium">{benefit.coverage_level}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">თქვენი წილი:</span>
                        <span className="font-medium">{benefit.employee_contribution} ₾</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">დამსაქმებლის წილი:</span>
                        <span className="font-medium">{benefit.employer_contribution} ₾</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">რეგისტრაცია:</span>
                        <span className="font-medium">{new Date(benefit.enrollment_date).toLocaleDateString('ka-GE')}</span>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="available" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {benefitPlans.map((plan) => (
                <Card key={plan.id} className="p-6 space-y-4">
                  <div className="flex items-center gap-3">
                    {getBenefitIcon(plan.plan_type)}
                    <div>
                      <h3 className="font-semibold">{plan.plan_name}</h3>
                      <p className="text-sm text-muted-foreground">{plan.provider_name}</p>
                    </div>
                  </div>
                  <p className="text-sm">{plan.coverage_details}</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">თქვენი წილი:</span>
                      <span className="font-medium">{plan.employee_contribution} ₾</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">დამსაქმებლის წილი:</span>
                      <span className="font-medium">{plan.employer_contribution} ₾</span>
                    </div>
                  </div>
                  <Button 
                    className="w-full" 
                    size="sm"
                    onClick={() => handleEnroll(plan.id)}
                  >
                    რეგისტრაცია
                  </Button>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}