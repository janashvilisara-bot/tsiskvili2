import { useState, useEffect } from "react";
import { Plus, Search, Calendar, DollarSign, TrendingUp, FileText, Download, Sparkles, FileSpreadsheet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { ResponsiveTable, MobileCard, MobileCardRow } from "@/components/ResponsiveTable";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { exportPensionReport, exportPensionsGeCSV } from "@/lib/exportPensionReport";
import { calculatePensionContribution, calculateIncomeTax, getPensionStateRate, FINANCIAL_CONSTANTS } from "@/lib/financialCalculations";

interface PensionPayment {
  id: string;
  employee_id: string;
  payment_date: string;
  period_month: number;
  period_year: number;
  employee_contribution: number;
  employer_contribution: number;
  total_amount: number;
  base_salary: number;
  status: string;
  payment_reference: string | null;
  notes: string | null;
  employee?: {
    full_name: string;
    personal_id_number: string | null;
    pension_account_number: string | null;
  };
}

interface Employee {
  id: string;
  full_name: string;
  salary: number;
  has_pension: boolean;
  is_pension_payer: boolean | null;
  pension_account_number: string | null;
  date_of_birth: string | null;
  gender: string | null;
}

const MONTHS = [
  { value: 1, label: "იანვარი" },
  { value: 2, label: "თებერვალი" },
  { value: 3, label: "მარტი" },
  { value: 4, label: "აპრილი" },
  { value: 5, label: "მაისი" },
  { value: 6, label: "ივნისი" },
  { value: 7, label: "ივლისი" },
  { value: 8, label: "აგვისტო" },
  { value: 9, label: "სექტემბერი" },
  { value: 10, label: "ოქტომბერი" },
  { value: 11, label: "ნოემბერი" },
  { value: 12, label: "დეკემბერი" },
];

export default function PensionPayments() {
  const { user, userRole } = useAuth();
  const [payments, setPayments] = useState<PensionPayment[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<string>("");
  const [selectedMonth, setSelectedMonth] = useState<string>(String(new Date().getMonth() + 1));
  const [selectedYear, setSelectedYear] = useState<string>(String(new Date().getFullYear()));
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterMonth, setFilterMonth] = useState<string>("all");
  const [filterYear, setFilterYear] = useState<string>("all");

  const canManagePensions = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    fetchPayments();
    fetchEmployees();
  }, []);

  const fetchPayments = async () => {
    try {
      const { data, error } = await supabase
        .from('pension_payments')
        .select(`
          *,
          employee:employees(full_name, personal_id_number, pension_account_number)
        `)
        .order('period_year', { ascending: false })
        .order('period_month', { ascending: false });

      if (error) throw error;
      setPayments(data || []);
    } catch (error: any) {
      toast.error('გადახდების ჩატვირთვა ვერ მოხერხდა');
      console.error(error);
    }
  };

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('id, full_name, salary, has_pension, is_pension_payer, pension_account_number, date_of_birth, gender')
        .eq('has_pension', true)
        .eq('status', 'active')
        .order('full_name');

      if (error) throw error;
      setEmployees(data || []);
    } catch (error: any) {
      toast.error('თანამშრომლების ჩატვირთვა ვერ მოხერხდა');
      console.error(error);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const employee = employees.find(emp => emp.id === selectedEmployee);
      if (!employee) {
        toast.error('აირჩიეთ თანამშრომელი');
        return;
      }

      const baseSalary = employee.salary || 0;
      const age = employee.date_of_birth
        ? Math.floor((Date.now() - new Date(employee.date_of_birth).getTime()) / (365.25 * 24 * 3600 * 1000))
        : undefined;
      const gender = employee.gender === 'male' || employee.gender === 'female' ? employee.gender : undefined;
      const pension = calculatePensionContribution(baseSalary, { age, gender });
      const employeeContribution = pension.employeeContribution;
      const employerContribution = pension.employerContribution;

      const payload = {
        employee_id: selectedEmployee,
        period_month: parseInt(selectedMonth),
        period_year: parseInt(selectedYear),
        base_salary: baseSalary,
        employee_contribution: employeeContribution,
        employer_contribution: employerContribution,
        payment_date: formData.get('payment_date') as string,
        status: formData.get('status') as string,
        payment_reference: formData.get('payment_reference') as string || null,
        notes: formData.get('notes') as string || null,
        created_by: user?.id,
      };

      const { error } = await supabase
        .from('pension_payments')
        .insert(payload);

      if (error) throw error;

      toast.success('საპენსიო გადახდა დაემატა');
      setIsDialogOpen(false);
      fetchPayments();
      
      // Reset form
      setSelectedEmployee("");
      setSelectedMonth(String(new Date().getMonth() + 1));
      setSelectedYear(String(new Date().getFullYear()));
    } catch (error: any) {
      toast.error(error.message || 'დამატება ვერ მოხერხდა');
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStatusUpdate = async (paymentId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('pension_payments')
        .update({ status: newStatus })
        .eq('id', paymentId);

      if (error) throw error;
      toast.success('სტატუსი განახლდა');
      fetchPayments();
    } catch (error: any) {
      toast.error('განახლება ვერ მოხერხდა');
      console.error(error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-success/10 text-success border-success/20';
      case 'pending':
        return 'bg-warning/10 text-warning border-warning/20';
      case 'cancelled':
        return 'bg-destructive/10 text-destructive border-destructive/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'paid':
        return 'გადახდილი';
      case 'pending':
        return 'მოლოდინში';
      case 'cancelled':
        return 'გაუქმებული';
      default:
        return status;
    }
  };

  const filteredPayments = payments.filter(payment => {
    const matchesSearch = payment.employee?.full_name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === "all" || payment.status === filterStatus;
    const matchesMonth = filterMonth === "all" || payment.period_month === parseInt(filterMonth);
    const matchesYear = filterYear === "all" || payment.period_year === parseInt(filterYear);
    
    return matchesSearch && matchesStatus && matchesMonth && matchesYear;
  });

  const totalStats = {
    totalPaid: filteredPayments
      .filter(p => p.status === 'paid')
      .reduce((sum, p) => sum + Number(p.total_amount), 0),
    totalPending: filteredPayments
      .filter(p => p.status === 'pending')
      .reduce((sum, p) => sum + Number(p.total_amount), 0),
    totalEmployees: new Set(filteredPayments.map(p => p.employee_id)).size,
  };

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => currentYear - i);

  const handleExportPensionReport = async () => {
    const reportMonth = filterMonth !== "all" ? parseInt(filterMonth) : new Date().getMonth() + 1;
    const reportYear = filterYear !== "all" ? parseInt(filterYear) : currentYear;
    
    const paymentsToExport = filteredPayments.length > 0 ? filteredPayments : payments;
    
    if (paymentsToExport.length === 0) {
      toast.error('ექსპორტისთვის მონაცემები არ მოიძებნა');
      return;
    }

    const success = await exportPensionReport(paymentsToExport, reportMonth, reportYear);
    if (success) {
      toast.success('საპენსიო რეპორტი წარმატებით ჩამოიტვირთა');
    } else {
      toast.error('რეპორტის ექსპორტი ვერ მოხერხდა');
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">საპენსიო გადახდები</h1>
          <p className="text-muted-foreground">თანამშრომლების საპენსიო გადახდების ჟურნალი</p>
        </div>
        <div className="flex items-center gap-2">
          {canManagePensions && (
            <Button variant="outline" className="gap-2" onClick={handleExportPensionReport}>
              <Download className="h-4 w-4" />
              pensions.ge XLSX
            </Button>
          )}
          {canManagePensions && (
            <Button variant="outline" className="gap-2" onClick={() => {
              const reportMonth = filterMonth !== "all" ? parseInt(filterMonth) : new Date().getMonth() + 1;
              const reportYear = filterYear !== "all" ? parseInt(filterYear) : currentYear;
              const data = filteredPayments.length > 0 ? filteredPayments : payments;
              if (data.length === 0) { toast.error('მონაცემები არ მოიძებნა'); return; }
              if (exportPensionsGeCSV(data, reportMonth, reportYear)) toast.success('CSV ჩამოიტვირთა');
              else toast.error('ექსპორტი ვერ მოხერხდა');
            }}>
              <FileSpreadsheet className="h-4 w-4" />
              CSV
            </Button>
          )}
          {canManagePensions && (
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                ახალი გადახდა
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>საპენსიო გადახდის დამატება</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="employee_id">თანამშრომელი *</Label>
                  <Select value={selectedEmployee} onValueChange={setSelectedEmployee} required>
                    <SelectTrigger>
                      <SelectValue placeholder="აირჩიეთ თანამშრომელი" />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.full_name} ({emp.salary?.toLocaleString()} ₾)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="period_month">თვე *</Label>
                    <Select value={selectedMonth} onValueChange={setSelectedMonth} required>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {MONTHS.map((month) => (
                          <SelectItem key={month.value} value={String(month.value)}>
                            {month.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="period_year">წელი *</Label>
                    <Select value={selectedYear} onValueChange={setSelectedYear} required>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {years.map((year) => (
                          <SelectItem key={year} value={String(year)}>
                            {year}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                {selectedEmployee && (
                  <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                    <p className="text-sm font-medium">გადასახადის გაანგარიშება:</p>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">თანამშრომლის წილი (2%):</span>
                        <span className="font-medium">
                          {((employees.find(e => e.id === selectedEmployee)?.salary || 0) * 0.02).toFixed(2)} ₾
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">დამსაქმებლის წილი (2%):</span>
                        <span className="font-medium">
                          {((employees.find(e => e.id === selectedEmployee)?.salary || 0) * 0.02).toFixed(2)} ₾
                        </span>
                      </div>
                      <div className="flex justify-between pt-2 border-t">
                        <span className="font-medium">სულ:</span>
                        <span className="font-bold">
                          {((employees.find(e => e.id === selectedEmployee)?.salary || 0) * 0.04).toFixed(2)} ₾
                        </span>
                      </div>
                    </div>
                  </div>
                )}
                <div>
                  <Label htmlFor="payment_date">გადახდის თარიღი *</Label>
                  <Input
                    id="payment_date"
                    name="payment_date"
                    type="date"
                    defaultValue={new Date().toISOString().split('T')[0]}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="status">სტატუსი *</Label>
                  <Select name="status" defaultValue="pending" required>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">მოლოდინში</SelectItem>
                      <SelectItem value="paid">გადახდილი</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="payment_reference">გადახდის ნომერი</Label>
                  <Input
                    id="payment_reference"
                    name="payment_reference"
                    placeholder="მაგ: TRX123456"
                  />
                </div>
                <div>
                  <Label htmlFor="notes">შენიშვნა</Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    placeholder="დამატებითი ინფორმაცია..."
                    rows={3}
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'მიმდინარეობს...' : 'დამატება'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
          )}
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">გადახდილი</CardTitle>
            <DollarSign className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStats.totalPaid.toLocaleString()} ₾</div>
            <p className="text-xs text-muted-foreground">დადასტურებული გადახდები</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">მოლოდინში</CardTitle>
            <Calendar className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStats.totalPending.toLocaleString()} ₾</div>
            <p className="text-xs text-muted-foreground">გადასახდელი თანხა</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">თანამშრომლები</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStats.totalEmployees}</div>
            <p className="text-xs text-muted-foreground">საპენსიოს მქონე</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="ძებნა..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={filterMonth} onValueChange={setFilterMonth}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="თვე" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">ყველა თვე</SelectItem>
            {MONTHS.map((month) => (
              <SelectItem key={month.value} value={String(month.value)}>
                {month.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterYear} onValueChange={setFilterYear}>
          <SelectTrigger className="w-[120px]">
            <SelectValue placeholder="წელი" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">ყველა წელი</SelectItem>
            {years.map((year) => (
              <SelectItem key={year} value={String(year)}>
                {year}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="სტატუსი" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">ყველა</SelectItem>
            <SelectItem value="pending">მოლოდინში</SelectItem>
            <SelectItem value="paid">გადახდილი</SelectItem>
            <SelectItem value="cancelled">გაუქმებული</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Payments Table */}
      <Card>
        <CardContent className="p-0">
          <ResponsiveTable
            data={filteredPayments}
            mobileCards={(payment) => (
              <MobileCard>
                <div className="space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-medium">{payment.employee?.full_name}</div>
                      <div className="text-sm text-muted-foreground">
                        {MONTHS.find(m => m.value === payment.period_month)?.label} {payment.period_year}
                      </div>
                    </div>
                    <Badge variant="outline" className={getStatusColor(payment.status)}>
                      {getStatusText(payment.status)}
                    </Badge>
                  </div>
                  <MobileCardRow label="ხელფასი" value={`${Number(payment.base_salary).toLocaleString()} ₾`} />
                  <MobileCardRow label="თანამშრომლის წილი" value={`${Number(payment.employee_contribution).toFixed(2)} ₾`} />
                  <MobileCardRow label="დამსაქმებლის წილი" value={`${Number(payment.employer_contribution).toFixed(2)} ₾`} />
                  <MobileCardRow 
                    label="სულ" 
                    value={<span className="font-semibold">{Number(payment.total_amount).toFixed(2)} ₾</span>}
                  />
                  {canManagePensions && payment.status === 'pending' && (
                    <Button
                      size="sm"
                      className="w-full mt-2"
                      onClick={() => handleStatusUpdate(payment.id, 'paid')}
                    >
                      გადახდილად მონიშვნა
                    </Button>
                  )}
                </div>
              </MobileCard>
            )}
          >
            <thead>
              <tr className="border-b">
                <th className="p-4 text-left font-medium">თანამშრომელი</th>
                <th className="p-4 text-left font-medium">პერიოდი</th>
                <th className="p-4 text-left font-medium">ხელფასი</th>
                <th className="p-4 text-left font-medium">თანამშრ. წილი</th>
                <th className="p-4 text-left font-medium">დამსაქმ. წილი</th>
                <th className="p-4 text-left font-medium">სულ</th>
                <th className="p-4 text-left font-medium">სტატუსი</th>
                <th className="p-4 text-left font-medium">მოქმედება</th>
              </tr>
            </thead>
            <tbody>
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-muted-foreground">
                    საპენსიო გადახდები არ მოიძებნა
                  </td>
                </tr>
              ) : (
                filteredPayments.map((payment) => (
                  <tr key={payment.id} className="border-b hover:bg-muted/50">
                    <td className="p-4">
                      <div>
                        <div className="font-medium">{payment.employee?.full_name}</div>
                        {payment.employee?.pension_account_number && (
                          <div className="text-sm text-muted-foreground">
                            {payment.employee.pension_account_number}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      {MONTHS.find(m => m.value === payment.period_month)?.label} {payment.period_year}
                    </td>
                    <td className="p-4">{Number(payment.base_salary).toLocaleString()} ₾</td>
                    <td className="p-4">{Number(payment.employee_contribution).toFixed(2)} ₾</td>
                    <td className="p-4">{Number(payment.employer_contribution).toFixed(2)} ₾</td>
                    <td className="p-4 font-semibold">{Number(payment.total_amount).toFixed(2)} ₾</td>
                    <td className="p-4">
                      <Badge variant="outline" className={getStatusColor(payment.status)}>
                        {getStatusText(payment.status)}
                      </Badge>
                    </td>
                    <td className="p-4">
                      {canManagePensions && payment.status === 'pending' && (
                        <Button
                          size="sm"
                          onClick={() => handleStatusUpdate(payment.id, 'paid')}
                        >
                          გადახდა
                        </Button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </ResponsiveTable>
        </CardContent>
      </Card>
    </div>
  );
}
