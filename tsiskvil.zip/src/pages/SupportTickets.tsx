import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { 
  Plus, TicketCheck, Clock, CheckCircle2, AlertCircle, 
  MessageSquare, ArrowRight, Sparkles, Filter, CalendarDays,
  Bot, Loader2, Zap, ShieldCheck, XCircle, SkipForward
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";

const statusMap: Record<string, { label: string; color: string; icon: typeof Clock; gradient: string }> = {
  open: { label: "ღია", color: "bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300", icon: Clock, gradient: "from-blue-400 to-blue-600" },
  in_progress: { label: "მუშავდება", color: "bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300", icon: AlertCircle, gradient: "from-amber-400 to-orange-500" },
  resolved: { label: "გადაწყვეტილი", color: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300", icon: CheckCircle2, gradient: "from-emerald-400 to-green-600" },
  closed: { label: "დახურული", color: "bg-muted text-muted-foreground", icon: CheckCircle2, gradient: "from-gray-400 to-gray-500" },
};

const priorityMap: Record<string, { label: string; color: string; dot: string }> = {
  low: { label: "დაბალი", color: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300", dot: "bg-slate-400" },
  medium: { label: "საშუალო", color: "bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-300", dot: "bg-amber-400" },
  high: { label: "მაღალი", color: "bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300", dot: "bg-red-500" },
  critical: { label: "კრიტიკული", color: "bg-red-200 text-red-900 dark:bg-red-950 dark:text-red-200", dot: "bg-red-600 animate-pulse" },
};

const categoryMap: Record<string, string> = {
  technical: "ტექნიკური",
  bug: "ხარვეზი",
  feature_request: "ფუნქციის მოთხოვნა",
  data_issue: "მონაცემთა პრობლემა",
  access: "წვდომის პრობლემა",
  other: "სხვა",
};

export default function SupportTickets() {
  const { user, userRole } = useAuth();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [detailTicket, setDetailTicket] = useState<any>(null);
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "technical",
    priority: "medium",
  });

  const [resolutionNotes, setResolutionNotes] = useState("");

  const { data: tickets, isLoading } = useQuery({
    queryKey: ["support-tickets", filterStatus],
    queryFn: async () => {
      let query = supabase
        .from("support_tickets")
        .select("*")
        .order("created_at", { ascending: false });

      if (filterStatus !== "all") {
        query = query.eq("status", filterStatus);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("support_tickets").insert({
        title: form.title,
        description: form.description,
        category: form.category,
        priority: form.priority,
        created_by: user?.email || "unknown",
      });
      if (error) throw error;

      try {
        await supabase.functions.invoke("send-support-ticket-email", {
          body: {
            ticketTitle: form.title,
            category: categoryMap[form.category] || form.category,
            priority: priorityMap[form.priority]?.label || form.priority,
            description: form.description,
            idempotencySeed: `${Date.now()}`,
          },
        });
      } catch (emailError) {
        console.error("Email notification failed:", emailError);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["support-tickets"] });
      setDialogOpen(false);
      setForm({ title: "", description: "", category: "technical", priority: "medium" });
      toast({ title: "ტიკეტი შეიქმნა", description: "საპორტ ტიკეტი წარმატებით დაემატა და შეტყობინება გაიგზავნა" });
    },
    onError: () => {
      toast({ title: "შეცდომა", description: "ტიკეტის შექმნა ვერ მოხერხდა", variant: "destructive" });
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status, notes }: { id: string; status: string; notes?: string }) => {
      const update: any = { status };
      if (status === "resolved") {
        update.resolved_at = new Date().toISOString();
        if (notes) update.resolution_notes = notes;
      }
      const { error } = await supabase.from("support_tickets").update(update).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["support-tickets"] });
      setDetailTicket(null);
      setResolutionNotes("");
      toast({ title: "სტატუსი განახლდა" });
    },
  });

  const autoResolveMutation = useMutation({
    mutationFn: async (ticketId: string) => {
      const { data, error } = await supabase.functions.invoke("auto-resolve-ticket", {
        body: { ticketId },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["support-tickets"] });
      if (data.resolved) {
        toast({ title: "✅ AI გადაწყვეტა", description: "პრობლემა ავტომატურად მოგვარდა!" });
      } else {
        toast({ title: "🔍 AI დიაგნოსტიკა", description: data.diagnosis?.slice(0, 100) || "ანალიზი დასრულდა" });
      }
      // Refresh the detail ticket
      if (detailTicket) {
        supabase.from("support_tickets").select("*").eq("id", detailTicket.id).single().then(({ data: updated }) => {
          if (updated) setDetailTicket(updated);
        });
      }
    },
    onError: (err: any) => {
      toast({ title: "შეცდომა", description: err.message || "AI ანალიზი ვერ მოხერხდა", variant: "destructive" });
    },
  });

  const isAdmin = userRole === "admin" || userRole === "hr_manager";

  const openCount = tickets?.filter(t => t.status === "open").length || 0;
  const inProgressCount = tickets?.filter(t => t.status === "in_progress").length || 0;
  const resolvedCount = tickets?.filter(t => t.status === "resolved").length || 0;
  const totalCount = tickets?.length || 0;

  const statCards = [
    { label: "ღია", count: openCount, gradient: "from-blue-500 to-cyan-500", shadowColor: "shadow-blue-500/20", icon: Clock },
    { label: "მუშავდება", count: inProgressCount, gradient: "from-amber-500 to-orange-500", shadowColor: "shadow-amber-500/20", icon: AlertCircle },
    { label: "გადაწყვეტილი", count: resolvedCount, gradient: "from-emerald-500 to-green-500", shadowColor: "shadow-emerald-500/20", icon: CheckCircle2 },
    { label: "სულ ტიკეტი", count: totalCount, gradient: "from-violet-500 to-purple-500", shadowColor: "shadow-violet-500/20", icon: TicketCheck },
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">

          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-violet-400 via-purple-500 to-indigo-500 shadow-xl shadow-purple-500/30 animate-scale-in">
                <TicketCheck className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-foreground via-foreground/90 to-foreground/70 bg-clip-text text-transparent">
                  საპორტ ტიკეტები
                </h1>
                <p className="text-muted-foreground mt-1">ტექნიკური პრობლემების აღრიცხვა და მართვა</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-card border rounded-xl px-3 py-1.5">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-[140px] border-0 bg-transparent shadow-none h-8 px-1">
                    <SelectValue placeholder="ფილტრი" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა</SelectItem>
                    <SelectItem value="open">ღია</SelectItem>
                    <SelectItem value="in_progress">მუშავდება</SelectItem>
                    <SelectItem value="resolved">გადაწყვეტილი</SelectItem>
                    <SelectItem value="closed">დახურული</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                {isAdmin && (
                  <DialogTrigger asChild>
                    <Button className="gap-2 rounded-xl bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 shadow-lg shadow-purple-500/25 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/30 hover:-translate-y-0.5">
                      <Plus className="h-4 w-4" />
                      ახალი ტიკეტი
                    </Button>
                  </DialogTrigger>
                )}
                <DialogContent className="max-w-lg">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Sparkles className="h-5 w-5 text-purple-500" />
                      ახალი საპორტ ტიკეტი
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>სათაური</Label>
                      <Input
                        value={form.title}
                        onChange={(e) => setForm({ ...form, title: e.target.value })}
                        placeholder="მოკლე აღწერა..."
                        className="rounded-xl"
                      />
                    </div>
                    <div>
                      <Label>აღწერა</Label>
                      <Textarea
                        value={form.description}
                        onChange={(e) => setForm({ ...form, description: e.target.value })}
                        placeholder="დეტალური აღწერა პრობლემის..."
                        rows={5}
                        className="rounded-xl"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>კატეგორია</Label>
                        <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                          <SelectTrigger className="rounded-xl">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(categoryMap).map(([key, label]) => (
                              <SelectItem key={key} value={key}>{label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>პრიორიტეტი</Label>
                        <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                          <SelectTrigger className="rounded-xl">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(priorityMap).map(([key, { label }]) => (
                              <SelectItem key={key} value={key}>{label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <Button
                      onClick={() => createMutation.mutate()}
                      disabled={!form.title || !form.description || createMutation.isPending}
                      className="w-full rounded-xl bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 shadow-lg shadow-purple-500/25"
                    >
                      {createMutation.isPending ? "იქმნება..." : "შექმნა"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 animate-fade-in" style={{ animationDelay: "100ms" }}>
            {statCards.map((stat) => {
              const Icon = stat.icon;
              return (
                <Card key={stat.label} className={`relative overflow-hidden border-0 shadow-lg ${stat.shadowColor} hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group`}>
                  <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-[0.08] group-hover:opacity-[0.12] transition-opacity`} />
                  <CardContent className="relative flex items-center gap-4 p-5">
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${stat.gradient} shadow-lg`}>
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="text-3xl font-bold text-foreground">{stat.count}</p>
                      <p className="text-xs text-muted-foreground font-medium">{stat.label}</p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Tickets List */}
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-5">
                    <div className="h-4 bg-muted rounded w-1/3 mb-3" />
                    <div className="h-3 bg-muted rounded w-2/3" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : !tickets?.length ? (
            <Card className="border-dashed border-2">
              <CardContent className="flex flex-col items-center justify-center py-16 gap-4">
                <div className="p-5 rounded-2xl bg-gradient-to-br from-violet-100 to-purple-100 dark:from-violet-900/30 dark:to-purple-900/30">
                  <MessageSquare className="h-12 w-12 text-violet-500" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-foreground text-lg">ტიკეტები არ მოიძებნა</p>
                  <p className="text-sm text-muted-foreground mt-1">ახალი ტიკეტის შესაქმნელად დააჭირეთ ღილაკს</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3 animate-fade-in" style={{ animationDelay: "200ms" }}>
              {tickets.map((ticket, index) => {
                const status = statusMap[ticket.status] || statusMap.open;
                const priority = priorityMap[ticket.priority] || priorityMap.medium;
                const StatusIcon = status.icon;

                return (
                  <Card
                    key={ticket.id}
                    className="cursor-pointer group hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5 border border-border/50 hover:border-primary/20 overflow-hidden animate-fade-in"
                    style={{ animationDelay: `${index * 50}ms` }}
                    onClick={() => setDetailTicket(ticket)}
                  >
                    <div className={`absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b ${status.gradient} opacity-60`} />
                    <CardContent className="flex items-center gap-4 p-5 pl-6">
                      <div className={`p-2.5 rounded-xl bg-gradient-to-br ${status.gradient} shadow-md shrink-0`}>
                        <StatusIcon className="h-4 w-4 text-white" />
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                          <h3 className="font-semibold text-foreground truncate">{ticket.title}</h3>
                          <div className="flex items-center gap-1.5">
                            <div className={`w-2 h-2 rounded-full ${priority.dot}`} />
                            <span className="text-[11px] text-muted-foreground font-medium">{priority.label}</span>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-1">{ticket.description}</p>
                        <div className="flex items-center gap-3 mt-2.5">
                          <Badge className={`text-[10px] font-medium rounded-lg px-2 ${status.color}`}>{status.label}</Badge>
                          <Badge variant="outline" className="text-[10px] rounded-lg px-2">{categoryMap[ticket.category] || ticket.category}</Badge>
                          <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                            <CalendarDays className="h-3 w-3" />
                            {new Date(ticket.created_at).toLocaleDateString("ka-GE")}
                          </span>
                        </div>
                      </div>

                      <ArrowRight className="h-5 w-5 text-muted-foreground/30 group-hover:text-primary group-hover:translate-x-1 transition-all duration-300 shrink-0" />
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!detailTicket} onOpenChange={(open) => !open && setDetailTicket(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          {detailTicket && (() => {
            const status = statusMap[detailTicket.status] || statusMap.open;
            const priority = priorityMap[detailTicket.priority] || priorityMap.medium;
            return (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl bg-gradient-to-br ${status.gradient}`}>
                      <TicketCheck className="h-5 w-5 text-white" />
                    </div>
                    <span className="truncate">{detailTicket.title}</span>
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-5">
                  <div className="flex gap-2 flex-wrap">
                    <Badge className={`rounded-lg px-3 py-1 ${status.color}`}>{status.label}</Badge>
                    <Badge className={`rounded-lg px-3 py-1 ${priority.color}`}>
                      <span className={`w-2 h-2 rounded-full ${priority.dot} mr-1.5 inline-block`} />
                      {priority.label}
                    </Badge>
                    <Badge variant="outline" className="rounded-lg px-3 py-1">{categoryMap[detailTicket.category] || detailTicket.category}</Badge>
                  </div>

                  <div className="bg-muted/50 rounded-xl p-4">
                    <Label className="text-xs text-muted-foreground mb-2 block">აღწერა</Label>
                    <p className="text-sm whitespace-pre-wrap text-foreground">{detailTicket.description}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-muted/30 rounded-xl p-3">
                      <span className="text-xs text-muted-foreground">შემქმნელი</span>
                      <p className="font-medium text-sm mt-0.5">{detailTicket.created_by}</p>
                    </div>
                    <div className="bg-muted/30 rounded-xl p-3">
                      <span className="text-xs text-muted-foreground">თარიღი</span>
                      <p className="font-medium text-sm mt-0.5">{new Date(detailTicket.created_at).toLocaleString("ka-GE")}</p>
                    </div>
                  </div>

                  {detailTicket.resolution_notes && (
                    <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 p-4 rounded-xl">
                      <Label className="text-xs text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        გადაწყვეტის შენიშვნა
                      </Label>
                      <p className="text-sm mt-2">{detailTicket.resolution_notes}</p>
                    </div>
                  )}

                  {/* AI Diagnosis Section */}
                  {detailTicket.ai_diagnosis && (
                    <div className="bg-violet-50 dark:bg-violet-950/30 border border-violet-200 dark:border-violet-800 p-4 rounded-xl space-y-3">
                      <Label className="text-xs text-violet-700 dark:text-violet-400 flex items-center gap-1.5">
                        <Bot className="h-3.5 w-3.5" />
                        AI დიაგნოსტიკა
                        {detailTicket.ai_resolved && (
                          <Badge className="ml-2 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-300 text-[10px]">
                            ✅ ავტომატურად გადაწყვეტილი
                          </Badge>
                        )}
                      </Label>
                      <p className="text-sm whitespace-pre-wrap">{detailTicket.ai_diagnosis}</p>

                      {/* Actions Taken */}
                      {detailTicket.ai_actions_taken && (detailTicket.ai_actions_taken as any[]).length > 0 && (
                        <div className="space-y-2 mt-3">
                          <Label className="text-xs text-muted-foreground">შესრულებული მოქმედებები:</Label>
                          {(detailTicket.ai_actions_taken as any[]).map((action: any, idx: number) => (
                            <div key={idx} className="flex items-start gap-2 text-xs bg-background/50 p-2 rounded-lg">
                              {action.status === "executed" ? (
                                <ShieldCheck className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                              ) : action.status === "blocked" ? (
                                <XCircle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                              ) : (
                                <SkipForward className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                              )}
                              <div>
                                <span className="font-medium">{action.description}</span>
                                {action.reason && (
                                  <span className="text-muted-foreground ml-1">- {action.reason}</span>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {isAdmin && detailTicket.status !== "resolved" && detailTicket.status !== "closed" && (
                    <div className="space-y-3 border-t pt-4">
                      {/* AI Auto-Resolve Button */}
                      <Button
                        onClick={() => autoResolveMutation.mutate(detailTicket.id)}
                        disabled={autoResolveMutation.isPending}
                        className="w-full rounded-xl bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 hover:from-violet-600 hover:via-purple-600 hover:to-indigo-600 shadow-lg shadow-purple-500/25 transition-all"
                      >
                        {autoResolveMutation.isPending ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            AI ანალიზი მიმდინარეობს...
                          </>
                        ) : (
                          <>
                            <Zap className="h-4 w-4 mr-2" />
                            🤖 AI ავტომატური გადაწყვეტა
                          </>
                        )}
                      </Button>

                      <div>
                        <Label>გადაწყვეტის შენიშვნა</Label>
                        <Textarea
                          value={resolutionNotes}
                          onChange={(e) => setResolutionNotes(e.target.value)}
                          placeholder="რა გაკეთდა პრობლემის მოსაგვარებლად..."
                          rows={3}
                          className="rounded-xl mt-1.5"
                        />
                      </div>
                      <div className="flex gap-2">
                        {detailTicket.status === "open" && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="rounded-xl"
                            onClick={() => updateStatusMutation.mutate({ id: detailTicket.id, status: "in_progress" })}
                          >
                            <AlertCircle className="h-3.5 w-3.5 mr-1.5" />
                            მუშავდება
                          </Button>
                        )}
                        <Button
                          size="sm"
                          className="rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700"
                          onClick={() => updateStatusMutation.mutate({
                            id: detailTicket.id,
                            status: "resolved",
                            notes: resolutionNotes,
                          })}
                        >
                          <CheckCircle2 className="h-3.5 w-3.5 mr-1.5" />
                          გადაწყვეტილი
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>
    </PageTransition>
  );
}
