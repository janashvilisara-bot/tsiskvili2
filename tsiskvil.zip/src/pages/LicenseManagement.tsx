import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Package, Building2, Zap, Crown, Check, Lock, Shield } from "lucide-react";

interface FeaturePackage {
  id: string;
  name: string;
  name_ka: string;
  description_ka: string | null;
  price_monthly: number;
  price_yearly: number;
  color: string;
  icon: string;
  sort_order: number;
}

interface FeatureDefinition {
  id: string;
  feature_key: string;
  name: string;
  name_ka: string;
  category: string;
  package_id: string | null;
  sort_order: number;
}

interface Company {
  id: string;
  company_name: string;
}

interface CompanyFeature {
  feature_key: string;
  is_enabled: boolean;
}

interface CompanyPackage {
  package_id: string;
  is_active: boolean;
}

const iconMap: Record<string, any> = {
  Zap, Crown, Building2, Package,
};

const colorMap: Record<string, string> = {
  emerald: 'from-emerald-500 to-emerald-600',
  blue: 'from-blue-500 to-blue-600',
  purple: 'from-purple-500 to-purple-600',
};

export default function LicenseManagement() {
  const { user, userRole } = useAuth();
  const [packages, setPackages] = useState<FeaturePackage[]>([]);
  const [features, setFeatures] = useState<FeatureDefinition[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [selectedCompany, setSelectedCompany] = useState<string>("");
  const [companyFeatures, setCompanyFeatures] = useState<CompanyFeature[]>([]);
  const [companyPackages, setCompanyPackages] = useState<CompanyPackage[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (selectedCompany) {
      fetchCompanyAccess(selectedCompany);
    }
  }, [selectedCompany]);

  const fetchData = async () => {
    const [packagesRes, featuresRes, companiesRes] = await Promise.all([
      supabase.from('feature_packages').select('*').order('sort_order'),
      supabase.from('feature_definitions').select('*').order('sort_order'),
      supabase.from('companies').select('id, company_name').eq('is_active', true).order('company_name'),
    ]);

    if (packagesRes.data) setPackages(packagesRes.data);
    if (featuresRes.data) setFeatures(featuresRes.data);
    if (companiesRes.data) {
      setCompanies(companiesRes.data);
      // Auto-select if only one company
      if (companiesRes.data.length === 1 && !selectedCompany) {
        setSelectedCompany(companiesRes.data[0].id);
      }
    }
  };

  const fetchCompanyAccess = async (companyId: string) => {
    const [featuresRes, packagesRes] = await Promise.all([
      supabase.from('company_features').select('feature_key, is_enabled').eq('company_id', companyId),
      supabase.from('company_packages').select('package_id, is_active').eq('company_id', companyId),
    ]);

    setCompanyFeatures(featuresRes.data || []);
    setCompanyPackages(packagesRes.data || []);
  };

  const toggleFeature = async (featureKey: string, enabled: boolean) => {
    if (!selectedCompany || userRole !== 'admin') {
      toast.error('მხოლოდ ადმინისტრატორს შეუძლია ცვლილებების შეტანა');
      return;
    }
    setIsLoading(true);

    try {
      const existing = companyFeatures.find(f => f.feature_key === featureKey);

      if (existing) {
        const { error } = await supabase
          .from('company_features')
          .update({ is_enabled: enabled })
          .eq('company_id', selectedCompany)
          .eq('feature_key', featureKey);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('company_features')
          .insert({
            company_id: selectedCompany,
            feature_key: featureKey,
            is_enabled: enabled,
            enabled_by: user?.id,
          });
        if (error) throw error;
      }

      toast.success(enabled ? 'ფუნქცია ჩართულია' : 'ფუნქცია გამორთულია');
      await fetchCompanyAccess(selectedCompany);
    } catch (error: any) {
      console.error('Toggle feature error:', error);
      toast.error(error?.message || 'შეცდომა ფუნქციის გადართვისას');
    } finally {
      setIsLoading(false);
    }
  };

  const activatePackage = async (packageId: string) => {
    if (!selectedCompany || userRole !== 'admin') {
      toast.error('მხოლოდ ადმინისტრატორს შეუძლია პაკეტის გააქტიურება');
      return;
    }
    setIsLoading(true);

    try {
      // Find the selected package and its sort_order
      const selectedPkg = packages.find(p => p.id === packageId);
      if (!selectedPkg) throw new Error('პაკეტი ვერ მოიძებნა');

      // Get all packages up to and including selected (by sort_order)
      const includedPackageIds = packages
        .filter(p => p.sort_order <= selectedPkg.sort_order)
        .map(p => p.id);

      // Features that should be enabled (from selected package and lower)
      const enabledFeatureKeys = features
        .filter(f => f.package_id && includedPackageIds.includes(f.package_id))
        .map(f => f.feature_key);

      // Features that should be disabled (from higher packages)
      const disabledFeatureKeys = features
        .filter(f => f.package_id && !includedPackageIds.includes(f.package_id))
        .map(f => f.feature_key);

      // Deactivate all other packages, activate selected
      for (const pkg of packages) {
        const { error } = await supabase
          .from('company_packages')
          .upsert({
            company_id: selectedCompany,
            package_id: pkg.id,
            is_active: pkg.id === packageId,
            activated_by: pkg.id === packageId ? user?.id : null,
          }, { onConflict: 'company_id,package_id' });
        if (error) throw error;
      }

      // Enable features from included packages
      for (const featureKey of enabledFeatureKeys) {
        const { error } = await supabase
          .from('company_features')
          .upsert({
            company_id: selectedCompany,
            feature_key: featureKey,
            is_enabled: true,
            enabled_by: user?.id,
          }, { onConflict: 'company_id,feature_key' });
        if (error) throw error;
      }

      // Disable features from higher packages
      for (const featureKey of disabledFeatureKeys) {
        const { error } = await supabase
          .from('company_features')
          .upsert({
            company_id: selectedCompany,
            feature_key: featureKey,
            is_enabled: false,
            enabled_by: user?.id,
          }, { onConflict: 'company_id,feature_key' });
        if (error) throw error;
      }

      toast.success(`პაკეტი "${selectedPkg.name_ka}" გააქტიურდა`);
      await fetchCompanyAccess(selectedCompany);
    } catch (error: any) {
      console.error('Activate package error:', error);
      toast.error(error?.message || 'შეცდომა პაკეტის გააქტიურებისას');
    } finally {
      setIsLoading(false);
    }
  };

  const isFeatureEnabled = (featureKey: string): boolean => {
    const f = companyFeatures.find(cf => cf.feature_key === featureKey);
    return f ? f.is_enabled : false;
  };

  const isPackageActive = (packageId: string): boolean => {
    const p = companyPackages.find(cp => cp.package_id === packageId);
    return p ? p.is_active : false;
  };

  const getFeaturesByPackage = (packageId: string) => {
    return features.filter(f => f.package_id === packageId);
  };

  const getCategoryLabel = (cat: string) => {
    const labels: Record<string, string> = {
      core: 'ძირითადი',
      attendance: 'დასწრება',
      leave: 'შვებულებები',
      finance: 'ფინანსები',
      recruitment: 'რეკრუტმენტი',
      communication: 'კომუნიკაცია',
      performance: 'პერფორმანსი',
      development: 'განვითარება',
      analytics: 'ანალიტიკა',
      advanced: 'მოწინავე',
    };
    return labels[cat] || cat;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <Shield className="h-8 w-8 text-primary" />
          ლიცენზიების მართვა
        </h1>
        <p className="mt-2 text-muted-foreground">მართეთ კლიენტების პაკეტები და ფუნქციონალის წვდომა</p>
      </div>

      {/* Company selector */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">აირჩიეთ კომპანია</CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedCompany} onValueChange={setSelectedCompany}>
            <SelectTrigger className="max-w-md">
              <SelectValue placeholder="აირჩიეთ კომპანია..." />
            </SelectTrigger>
            <SelectContent>
              {companies.map(c => (
                <SelectItem key={c.id} value={c.id}>{c.company_name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {selectedCompany && (
        <Tabs defaultValue="packages">
          <TabsList>
            <TabsTrigger value="packages">პაკეტები</TabsTrigger>
            <TabsTrigger value="features">ინდივიდუალური ფუნქციები</TabsTrigger>
          </TabsList>

          <TabsContent value="packages" className="space-y-4">
            <div className="grid gap-6 md:grid-cols-3">
              {packages.map(pkg => {
                const IconComp = iconMap[pkg.icon] || Package;
                const active = isPackageActive(pkg.id);
                const pkgFeatures = getFeaturesByPackage(pkg.id);
                const enabledCount = pkgFeatures.filter(f => isFeatureEnabled(f.feature_key)).length;

                return (
                  <Card key={pkg.id} className={`relative overflow-hidden transition-all ${active ? 'ring-2 ring-primary shadow-lg' : 'hover:shadow-md'}`}>
                    <div className={`absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r ${colorMap[pkg.color] || colorMap.blue}`} />
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className={`p-2.5 rounded-xl bg-gradient-to-br ${colorMap[pkg.color] || colorMap.blue}`}>
                          <IconComp className="h-5 w-5 text-white" />
                        </div>
                        {active && <Badge className="bg-primary">აქტიური</Badge>}
                      </div>
                      <CardTitle className="text-xl mt-3">{pkg.name_ka}</CardTitle>
                      <CardDescription>{pkg.description_ka}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {pkg.price_monthly > 0 && (
                        <div>
                          <span className="text-3xl font-bold">₾{pkg.price_monthly}</span>
                          <span className="text-muted-foreground">/თვე</span>
                        </div>
                      )}
                      {pkg.price_monthly === 0 && pkg.name === 'Enterprise' && (
                        <div className="text-lg font-semibold text-muted-foreground">ინდივიდუალური</div>
                      )}

                      <div className="space-y-2">
                        <p className="text-sm font-medium text-muted-foreground">
                          {enabledCount}/{pkgFeatures.length} ფუნქცია ჩართული
                        </p>
                        {pkgFeatures.map(f => (
                          <div key={f.id} className="flex items-center gap-2 text-sm">
                            {isFeatureEnabled(f.feature_key) 
                              ? <Check className="h-4 w-4 text-primary" /> 
                              : <Lock className="h-4 w-4 text-muted-foreground/40" />
                            }
                            <span className={isFeatureEnabled(f.feature_key) ? '' : 'text-muted-foreground/60'}>
                              {f.name_ka}
                            </span>
                          </div>
                        ))}
                      </div>

                      <Button
                        className="w-full"
                        variant={active ? "outline" : "default"}
                        disabled={isLoading}
                        onClick={() => activatePackage(pkg.id)}
                      >
                        {active ? 'განახლება' : 'გააქტიურება'}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="features" className="space-y-4">
            {/* Group features by category */}
            {Array.from(new Set(features.map(f => f.category))).map(category => {
              const categoryFeatures = features.filter(f => f.category === category);
              return (
                <Card key={category}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">{getCategoryLabel(category)}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {categoryFeatures.map(feature => {
                        const pkg = packages.find(p => p.id === feature.package_id);
                        return (
                          <div key={feature.id} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                            <div className="flex items-center gap-3">
                              <Switch
                                checked={isFeatureEnabled(feature.feature_key)}
                                onCheckedChange={(checked) => toggleFeature(feature.feature_key, checked)}
                                disabled={isLoading}
                              />
                              <div>
                                <p className="font-medium">{feature.name_ka}</p>
                                <p className="text-xs text-muted-foreground">{feature.feature_key}</p>
                              </div>
                            </div>
                            {pkg && (
                              <Badge variant="outline" className="text-xs">
                                {pkg.name_ka}
                              </Badge>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </TabsContent>
        </Tabs>
      )}

      {!selectedCompany && (
        <div className="flex h-64 items-center justify-center text-muted-foreground">
          <div className="text-center">
            <Building2 className="mx-auto h-12 w-12 text-muted-foreground/30 mb-3" />
            <p>აირჩიეთ კომპანია ლიცენზიის სამართავად</p>
          </div>
        </div>
      )}
    </div>
  );
}
