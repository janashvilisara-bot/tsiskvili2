import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Download, FileSpreadsheet } from "lucide-react";
import { ReportPageShell } from "@/components/reports/ReportPageShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ResponsiveTable } from "@/components/ResponsiveTable";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { XLSX } from '@/lib/xlsxCompat';
import { useBranchFilter } from "@/hooks/useBranchFilter";


interface IdealAttendanceRecord {
  employee_id: string;
  employee_name: string;
  department_name: string;
  salary: number;
  planned_hours: number;
  actual_hours: number;
  difference_hours: number;
  planned_salary: number;
  work_days: number;
}

const IdealAttendanceReport = () => {
  const currentDate = new Date();
  const [selectedMonth, setSelectedMonth] = useState<number>(currentDate.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState<number>(currentDate.getFullYear());
  const [records, setRecords] = useState<IdealAttendanceRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [departments, setDepartments] = useState<any[]>([]);
  const [selectedDepartment, setSelectedDepartment] = useState<string>("all");
  const branchId = useBranchFilter();

  useEffect(() => {
    fetchDepartments();
  }, []);

  useEffect(() => {
    fetchData();
  }, [selectedMonth, selectedYear, selectedDepartment, branchId]);


  const fetchDepartments = async () => {
    const { data, error } = await supabase
      .from("departments")
      .select("id, name")
      .eq("is_active", true)
      .order("name");

    if (error) {
      console.error("Error fetching departments:", error);
      return;
    }

    setDepartments(data || []);
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const startDate = new Date(selectedYear, selectedMonth - 1, 1);
      const endDate = new Date(selectedYear, selectedMonth, 0);
      const startDateStr = startDate.toISOString().split('T')[0];
      const endDateStr = endDate.toISOString().split('T')[0];

      // Fetch employees
      let employeesQuery = supabase
        .from("employees")
        .select("id, full_name, salary, department")
        .eq("status", "active");

      if (selectedDepartment !== "all") {
        employeesQuery = employeesQuery.eq("department", selectedDepartment);
      }
      if (branchId) {
        employeesQuery = employeesQuery.eq("branch_id", branchId);
      }

      const { data: employees, error: empError } = await employeesQuery;

      if (empError) throw empError;


      // Fetch public holidays
      const { data: holidays, error: holidaysError } = await supabase
        .from("public_holidays")
        .select("holiday_date")
        .gte("holiday_date", startDateStr)
        .lte("holiday_date", endDateStr)
        .eq("is_active", true);

      if (holidaysError) throw holidaysError;

      const holidayDates = new Set(holidays?.map(h => h.holiday_date) || []);

      // Fetch work schedules
      const { data: schedules, error: schedError } = await supabase
        .from("work_schedules")
        .select("*");

      if (schedError) throw schedError;

      // Fetch schedule templates
      const { data: templates, error: templError } = await supabase
        .from("schedule_templates")
        .select("*");

      if (templError) throw templError;

      // Fetch attendance
      const { data: attendance, error: attError } = await supabase
        .from("attendance")
        .select("*")
        .gte("date", startDateStr)
        .lte("date", endDateStr);

      if (attError) throw attError;

      const results: IdealAttendanceRecord[] = [];

      for (const employee of employees || []) {
        // Find employee's schedule
        const schedule = schedules?.find(s => s.employee_id === employee.id);
        const template = schedule ? templates?.find(t => t.id === schedule.template_id) : null;

        // Calculate work days in month
        let workDays = 0;
        let dailyHours = 8; // default

        // Use work_schedule's custom times first, then fallback to template
        const effectiveStartTime = schedule?.start_time || template?.start_time;
        const effectiveEndTime = schedule?.end_time || template?.end_time;
        const effectiveBreakDuration = schedule?.break_duration ?? template?.break_duration ?? 0;

        if (effectiveStartTime && effectiveEndTime) {
          const startParts = effectiveStartTime.split(':');
          const endParts = effectiveEndTime.split(':');
          
          if (startParts.length >= 2 && endParts.length >= 2) {
            const startHour = parseInt(startParts[0], 10) || 0;
            const startMin = parseInt(startParts[1], 10) || 0;
            const endHour = parseInt(endParts[0], 10) || 0;
            const endMin = parseInt(endParts[1], 10) || 0;
            
            const totalMinutes = (endHour * 60 + endMin) - (startHour * 60 + startMin);
            const calculatedHours = (totalMinutes - (effectiveBreakDuration || 0)) / 60;
            
            // Only use calculated hours if it's a valid positive number
            if (!isNaN(calculatedHours) && calculatedHours > 0) {
              dailyHours = calculatedHours;
            }
          }
        }

        // Count work days (excluding weekends and holidays)
        for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
          const dateStr = d.toISOString().split('T')[0];
          const dayOfWeek = d.getDay();

          // Skip weekends
          if (dayOfWeek === 0 || dayOfWeek === 6) continue;

          // Skip holidays
          if (holidayDates.has(dateStr)) continue;

          workDays++;
        }

        const plannedHours = workDays * dailyHours;

        // Calculate actual hours
        const empAttendance = attendance?.filter(a => a.employee_id === employee.id) || [];
        let actualHours = 0;

        for (const att of empAttendance) {
          if (att.check_in && att.check_out) {
            const checkIn = new Date(att.check_in);
            const checkOut = new Date(att.check_out);
            
            // Validate dates
            if (!isNaN(checkIn.getTime()) && !isNaN(checkOut.getTime())) {
              const hours = (checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60);
              
              // Subtract break duration
              const breakHours = (att.break_duration || 0) / 60;
              const netHours = Math.max(0, hours - breakHours);
              
              if (!isNaN(netHours)) {
                actualHours += netHours;
              }
            }
          }
        }

        const differenceHours = plannedHours - actualHours;

        // Ensure all values are valid numbers
        const safeActualHours = isNaN(actualHours) ? 0 : actualHours;
        const safeDifferenceHours = isNaN(differenceHours) ? 0 : differenceHours;
        const safePlannedHours = isNaN(plannedHours) ? 0 : plannedHours;

        results.push({
          employee_id: employee.id,
          employee_name: employee.full_name,
          department_name: employee.department || "N/A",
          salary: employee.salary || 0,
          planned_hours: Math.round(safePlannedHours * 10) / 10,
          actual_hours: Math.round(safeActualHours * 10) / 10,
          difference_hours: Math.round(safeDifferenceHours * 10) / 10,
          planned_salary: employee.salary || 0,
          work_days: workDays,
        });
      }

      setRecords(results);
    } catch (error: any) {
      console.error("Error fetching data:", error);
      toast.error("შეცდომა მონაცემების ჩატვირთვისას");
    } finally {
      setLoading(false);
    }
  };

  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(
      records.map((record, index) => ({
        "№": index + 1,
        "თანამშრომელი": record.employee_name,
        "დეპარტამენტი": record.department_name,
        "სამუშაო დღეები": record.work_days,
        "დაგეგმილი საათები": record.planned_hours,
        "რეალური საათები": record.actual_hours,
        "სხვაობა (საათები)": record.difference_hours,
        "ხელფასი (თუ სრულად იმუშავებდა)": record.planned_salary,
        "რეალური ხელფასი პროპორციულად": record.planned_hours > 0 ? Math.round((record.actual_hours / record.planned_hours) * record.planned_salary * 100) / 100 : 0,
      }))
    );

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "დაგეგმილი vs რეალური");

    const monthName = new Date(selectedYear, selectedMonth - 1).toLocaleString('ka-GE', { month: 'long' });
    XLSX.writeFile(wb, `დაგეგმილი_vs_რეალური_დასწრება_${monthName}_${selectedYear}.xlsx`);
    toast.success("ექსელ ფაილი წარმატებით ჩამოიტვირთა");
  };

  return (
    <ReportPageShell
      title="დაგეგმილი vs რეალური დასწრება"
      description="რამდენ საათს იმუშავებდა თანამშრომელი და რა ხელფასს მიიღებდა თუ არცერთი გაცდენა არ ჰქონდა"
      icon={Calendar}
      gradient="from-cyan-400 via-blue-500 to-indigo-500"
      shadow="shadow-blue-500/30"
    >
      <Card className="border-border/50 bg-card/80 backdrop-blur-xl shadow-xl">
        <CardContent className="space-y-6 pt-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Select value={selectedMonth.toString()} onValueChange={(v) => setSelectedMonth(parseInt(v))}>
              <SelectTrigger>
                <SelectValue placeholder="აირჩიეთ თვე" />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 12 }, (_, i) => (
                  <SelectItem key={i + 1} value={(i + 1).toString()}>
                    {new Date(2024, i).toLocaleString('ka-GE', { month: 'long' })}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedYear.toString()} onValueChange={(v) => setSelectedYear(parseInt(v))}>
              <SelectTrigger>
                <SelectValue placeholder="აირჩიეთ წელი" />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 5 }, (_, i) => {
                  const year = currentDate.getFullYear() - 2 + i;
                  return (
                    <SelectItem key={year} value={year.toString()}>
                      {year}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>

            <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
              <SelectTrigger>
                <SelectValue placeholder="დეპარტამენტი" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                {departments.map((dept) => (
                  <SelectItem key={dept.id} value={dept.name}>
                    {dept.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button onClick={exportToExcel} variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              ექსელში ჩამოტვირთვა
            </Button>
          </div>

          <ResponsiveTable data={records}>
            <TableHeader>
              <TableRow>
                <TableHead>თანამშრომელი</TableHead>
                <TableHead>დეპარტამენტი</TableHead>
                <TableHead className="text-right">სამუშაო დღეები</TableHead>
                <TableHead className="text-right">დაგეგმილი საათები</TableHead>
                <TableHead className="text-right">რეალური საათები</TableHead>
                <TableHead className="text-right">სხვაობა</TableHead>
                <TableHead className="text-right">დაგეგმილი ხელფასი</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    <div className="flex items-center justify-center gap-2">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                      <span>იტვირთება...</span>
                    </div>
                  </TableCell>
                </TableRow>
              ) : records.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    <FileSpreadsheet className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p className="text-muted-foreground">არ მოიძებნა ჩანაწერები</p>
                  </TableCell>
                </TableRow>
              ) : (
                records.map((record) => (
                  <TableRow key={record.employee_id}>
                    <TableCell className="font-medium">{record.employee_name}</TableCell>
                    <TableCell>{record.department_name}</TableCell>
                    <TableCell className="text-right">{record.work_days}</TableCell>
                    <TableCell className="text-right">{record.planned_hours}</TableCell>
                    <TableCell className="text-right">{record.actual_hours}</TableCell>
                    <TableCell className="text-right">
                      <span className={record.difference_hours > 0 ? "text-destructive font-semibold" : "text-success"}>
                        {record.difference_hours > 0 ? `-${record.difference_hours}` : record.difference_hours}
                      </span>
                    </TableCell>
                    <TableCell className="text-right font-semibold">{record.planned_salary.toFixed(2)} ₾</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </ResponsiveTable>
        </CardContent>
      </Card>
    </ReportPageShell>
  );
};

export default IdealAttendanceReport;
