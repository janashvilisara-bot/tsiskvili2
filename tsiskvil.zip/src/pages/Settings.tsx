import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Trash2, User, Mail, Calendar, Shield, Lock, Edit, MapPin, FileDown, Wifi } from "lucide-react";
import { exportComparisonWord } from "@/lib/exportComparisonWord";
import { useAuth } from "@/contexts/AuthContext";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import OfficeLocationsManager from "@/components/settings/OfficeLocationsManager";
import GlobalCellSettings from "@/components/settings/GlobalCellSettings";
import KursiSettings from "@/components/settings/KursiSettings";
import TurnstileDevicesManager from "@/components/settings/TurnstileDevicesManager";
import HerioSettings from "@/components/settings/HerioSettings";
import GoogleDriveSettings from "@/components/settings/GoogleDriveSettings";

interface UserRole {
  id: string;
  user_id: string;
  role: string;
  profiles: {
    full_name: string;
  };
}

export default function Settings() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialTab = searchParams.get("tab") || "profile";
  const { user, userRole } = useAuth();
  const [userRoles, setUserRoles] = useState<UserRole[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<string>("");
  const [selectedRole, setSelectedRole] = useState<string>("employee");
  const [isLoading, setIsLoading] = useState(false);
  const [userProfile, setUserProfile] = useState<any>(null);
  
  // Profile edit state
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editedFullName, setEditedFullName] = useState("");
  
  // Password change state
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  useEffect(() => {
    fetchUserRoles();
    fetchUsers();
    fetchUserProfile();
  }, [user]);

  const fetchUserProfile = async () => {
    if (!user) return;
    
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();
    
    if (error) {
      console.error('Error fetching profile:', error);
    } else {
      setUserProfile(data);
      setEditedFullName(data?.full_name || "");
    }
  };

  const handleUpdateProfile = async () => {
    if (!user || !editedFullName.trim()) {
      toast.error('სახელი აუცილებელია');
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ full_name: editedFullName.trim() })
        .eq('id', user.id);

      if (error) throw error;
      
      toast.success('პროფილი განახლდა');
      setIsEditingProfile(false);
      fetchUserProfile();
    } catch (error: any) {
      toast.error('პროფილის განახლება ვერ მოხერხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleChangePassword = async () => {
    if (!newPassword || !confirmPassword) {
      toast.error('შეავსეთ ყველა ველი');
      return;
    }

    if (newPassword.length < 6) {
      toast.error('პაროლი უნდა იყოს მინიმუმ 6 სიმბოლო');
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error('პაროლები არ ემთხვევა');
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });

      if (error) throw error;
      
      toast.success('პაროლი შეიცვალა');
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (error: any) {
      toast.error('პაროლის შეცვლა ვერ მოხერხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchUserRoles = async () => {
    const { data, error } = await supabase
      .from('user_roles')
      .select('id, user_id, role');
    
    if (error) {
      toast.error('როლების ჩატვირთვა ვერ მოხერხდა');
      return;
    }

    // Fetch profile names separately
    const rolesWithProfiles = await Promise.all(
      (data || []).map(async (role) => {
        const { data: profile } = await supabase
          .from('profiles')
          .select('full_name')
          .eq('id', role.user_id)
          .single();
        
        return {
          ...role,
          profiles: { full_name: profile?.full_name || 'უცნობი' }
        };
      })
    );
    
    setUserRoles(rolesWithProfiles);
  };

  const fetchUsers = async () => {
    const { data, error } = await supabase
      .from('profiles')
      .select('id, full_name');
    
    if (error) {
      toast.error('მომხმარებლების ჩატვირთვა ვერ მოხერხდა');
    } else {
      setUsers(data || []);
    }
  };

  const handleAddRole = async () => {
    if (!selectedUser) {
      toast.error('აირჩიეთ მომხმარებელი');
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('user_roles')
        .insert([{ user_id: selectedUser, role: selectedRole as 'admin' | 'hr_manager' | 'employee' }]);

      if (error) throw error;
      toast.success('როლი დაემატა');
      fetchUserRoles();
      setSelectedUser("");
    } catch (error: any) {
      toast.error(error.message || 'როლის დამატება ვერ მოხერხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteRole = async (id: string) => {
    if (!confirm('დარწმუნებული ხართ რომ გსურთ როლის წაშლა?')) return;

    try {
      const { error } = await supabase
        .from('user_roles')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast.success('როლი წაიშალა');
      fetchUserRoles();
    } catch (error: any) {
      toast.error('როლის წაშლა ვერ მოხერხდა');
    }
  };

  const getRoleText = (role: string | null) => {
    switch(role) {
      case 'admin': return 'ადმინისტრატორი';
      case 'hr_manager': return 'HR მენეჯერი';
      case 'department_manager': return 'დეპარტამენტის მენეჯერი';
      case 'employee': return 'თანამშრომელი';
      default: return 'თანამშრომელი';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">პარამეტრები</h1>
        <p className="mt-2 text-muted-foreground">მართეთ სისტემის პარამეტრები</p>
      </div>

      <Tabs defaultValue={initialTab} className="space-y-6" onValueChange={(value) => setSearchParams({ tab: value })}>
        <TabsList>
          <TabsTrigger value="profile">
            <User className="h-4 w-4 mr-2" />
            პროფილი
          </TabsTrigger>
          <TabsTrigger value="security">
            <Lock className="h-4 w-4 mr-2" />
            უსაფრთხოება
          </TabsTrigger>
          {userRole === 'admin' && (
            <>
              <TabsTrigger value="roles">
                <Shield className="h-4 w-4 mr-2" />
                როლები
              </TabsTrigger>
              <TabsTrigger value="locations">
                <MapPin className="h-4 w-4 mr-2" />
                ლოკაციები
              </TabsTrigger>
            </>
          )}
          {(userRole === 'admin' || userRole === 'hr_manager') && (
            <TabsTrigger value="integrations">
              <Wifi className="h-4 w-4 mr-2" />
              ინტეგრაციები
            </TabsTrigger>
          )}
        </TabsList>

        {/* Profile Tab */}
        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  პროფილის ინფორმაცია
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsEditingProfile(!isEditingProfile)}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  {isEditingProfile ? 'გაუქმება' : 'რედაქტირება'}
                </Button>
              </CardTitle>
              <CardDescription>თქვენი პირადი ინფორმაცია</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {isEditingProfile ? (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="fullName">სრული სახელი</Label>
                    <Input
                      id="fullName"
                      value={editedFullName}
                      onChange={(e) => setEditedFullName(e.target.value)}
                      placeholder="შეიყვანეთ სახელი"
                    />
                  </div>
                  <Button onClick={handleUpdateProfile} disabled={isLoading}>
                    {isLoading ? 'შენახვა...' : 'შენახვა'}
                  </Button>
                </div>
              ) : (
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex items-center gap-3 rounded-lg border p-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <User className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">სრული სახელი</p>
                      <p className="font-medium">{userProfile?.full_name || 'მომხმარებელი'}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 rounded-lg border p-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Mail className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">ელ. ფოსტა</p>
                      <p className="font-medium">{user?.email || 'არ არის მითითებული'}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 rounded-lg border p-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Shield className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">როლი</p>
                      <Badge variant="secondary">{getRoleText(userRole)}</Badge>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 rounded-lg border p-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                      <Calendar className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">რეგისტრაციის თარიღი</p>
                      <p className="font-medium">
                        {userProfile?.created_at 
                          ? new Date(userProfile.created_at).toLocaleDateString('ka-GE')
                          : 'არ არის ცნობილი'}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>


          {/* Comparison Export */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileDown className="h-5 w-5" />
                შედარების დოკუმენტი
              </CardTitle>
              <CardDescription>TalentOS vs Self.hr vs Ilaria - ფუნქციების შედარება</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" onClick={exportComparisonWord}>
                <FileDown className="h-4 w-4 mr-2" />
                Word ფაილის ჩამოტვირთვა
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                პაროლის შეცვლა
              </CardTitle>
              <CardDescription>განაახლეთ თქვენი პაროლი</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="newPassword">ახალი პაროლი</Label>
                <Input
                  id="newPassword"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="შეიყვანეთ ახალი პაროლი"
                />
              </div>
              <div>
                <Label htmlFor="confirmPassword">პაროლის დადასტურება</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="გაიმეორეთ ახალი პაროლი"
                />
              </div>
              <Button onClick={handleChangePassword} disabled={isLoading}>
                {isLoading ? 'შენახვა...' : 'პაროლის შეცვლა'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Roles Tab (Admin Only) */}
        {userRole === 'admin' && (
          <TabsContent value="roles" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>როლების მართვა</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="user">მომხმარებელი</Label>
                    <Select value={selectedUser} onValueChange={setSelectedUser}>
                      <SelectTrigger>
                        <SelectValue placeholder="აირჩიეთ მომხმარებელი" />
                      </SelectTrigger>
                      <SelectContent>
                        {users.map((user) => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.full_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="role">როლი</Label>
                    <Select value={selectedRole} onValueChange={setSelectedRole}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="employee">თანამშრომელი</SelectItem>
                        <SelectItem value="hr_manager">HR მენეჯერი</SelectItem>
                        <SelectItem value="admin">ადმინისტრატორი</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={handleAddRole} disabled={isLoading}>
                    {isLoading ? 'დამატება...' : 'როლის დამატება'}
                  </Button>

                  <div className="mt-6 space-y-2">
                    <h3 className="font-semibold">არსებული როლები</h3>
                    {userRoles.map((userRole) => (
                      <div key={userRole.id} className="flex items-center justify-between rounded-lg border p-3">
                        <div>
                          <p className="font-medium">{userRole.profiles?.full_name}</p>
                          <p className="text-sm text-muted-foreground">
                            {userRole.role === 'admin' ? 'ადმინისტრატორი' : 
                             userRole.role === 'hr_manager' ? 'HR მენეჯერი' : 'თანამშრომელი'}
                          </p>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDeleteRole(userRole.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>კომპანიის ინფორმაცია</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="companyName">კომპანიის სახელი</Label>
                    <Input id="companyName" defaultValue="HR & CRM Pro" />
                  </div>
                  <div>
                    <Label htmlFor="companyEmail">ელ. ფოსტა</Label>
                    <Input id="companyEmail" type="email" defaultValue="info@company.ge" />
                  </div>
                  <div>
                    <Label htmlFor="companyPhone">ტელეფონი</Label>
                    <Input id="companyPhone" defaultValue="+995 555 000 000" />
                  </div>
                  <Button>შენახვა</Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        )}

        {/* Locations Tab (Admin Only) */}
        {userRole === 'admin' && (
          <TabsContent value="locations" className="space-y-6">
            <OfficeLocationsManager />
          </TabsContent>
        )}

        {(userRole === 'admin' || userRole === 'hr_manager') && (
          <TabsContent value="integrations" className="space-y-6">
            {userRole === 'admin' && (
              <div className="flex flex-col gap-2 rounded-lg border bg-muted/40 p-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="font-medium">შეტყობინებები და კალენდრები</p>
                  <p className="text-sm text-muted-foreground">
                    Telegram, Slack, Microsoft Teams, WhatsApp, Outlook და Google კალენდარი
                  </p>
                </div>
                <Button asChild><a href="/integrations">ინტეგრაციების გვერდი</a></Button>
              </div>
            )}
            <GoogleDriveSettings />
            {userRole === 'admin' && (
              <>
                <HerioSettings />
                <TurnstileDevicesManager />
                <GlobalCellSettings />
                <KursiSettings />
              </>
            )}
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}
