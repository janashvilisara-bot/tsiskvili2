import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, RefreshCw, CheckCircle2, XCircle, Loader2, Play, Clock, User, Bot } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { toast } from "sonner";

interface PayrollRun {
  id: string;
  month: number;
  year: number;
  status: "running" | "success" | "failed";
  records_processed: number;
  total_net_amount: number;
  triggered_by: string;
  triggered_by_user_id: string | null;
  error_message: string | null;
  started_at: string;
  completed_at: string | null;
  duration_ms: number | null;
}

const MONTHS_KA = ["იანვარი","თებერვალი","მარტი","აპრილი","მაისი","ივნისი","ივლისი","აგვისტო","სექტემბერი","ოქტომბერი","ნოემბერი","დეკემბერი"];
const MONTHS_EN = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export default function PayrollRunHistory() {
  const navigate = useNavigate();
  const { user, userRole } = useAuth();
  const { language } = useLanguage();
  const months = language === "ka" ? MONTHS_KA : MONTHS_EN;
  const isAdmin = userRole === "admin" || userRole === "hr_manager";

  const [runs, setRuns] = useState<PayrollRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [selected, setSelected] = useState<PayrollRun | null>(null);
  const [manualMonth, setManualMonth] = useState<string>(String(new Date().getMonth() || 12));
  const [manualYear, setManualYear] = useState<string>(String(new Date().getMonth() === 0 ? new Date().getFullYear() - 1 : new Date().getFullYear()));

  const fetchRuns = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("payroll_runs")
      .select("*")
      .order("started_at", { ascending: false })
      .limit(100);
    if (error) {
      toast.error(language === "ka" ? "ისტორიის ჩატვირთვა ვერ მოხერხდა" : "Failed to load history");
    } else {
      setRuns((data || []) as PayrollRun[]);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchRuns();
    const channel = supabase
      .channel("payroll_runs_changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "payroll_runs" }, fetchRuns)
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const triggerRun = async () => {
    if (!isAdmin) return;
    setRunning(true);
    try {
      const { data, error } = await supabase.functions.invoke("process-monthly-payroll", {
        body: {
          month: parseInt(manualMonth),
          year: parseInt(manualYear),
          triggered_by: "manual",
          triggered_by_user_id: user?.id,
        },
      });
      if (error) throw error;
      if (data?.success) {
        toast.success(
          language === "ka"
            ? `დამუშავდა ${data.records} თანამშრომელი`
            : `Processed ${data.records} employees`
        );
      } else {
        toast.error(data?.error || (language === "ka" ? "შეცდომა მოხდა" : "Error occurred"));
      }
      fetchRuns();
    } catch (e: any) {
      toast.error(language === "ka" ? "გაშვება ვერ მოხერხდა" : "Run failed");
    } finally {
      setRunning(false);
    }
  };

  const statusBadge = (status: string) => {
    const map: Record<string, { label: string; variant: any; icon: any; cls: string }> = {
      running: {
        label: language === "ka" ? "მიმდინარე" : "Running",
        variant: "secondary",
        icon: Loader2,
        cls: "bg-blue-500/10 text-blue-700 dark:text-blue-300 border-blue-500/30",
      },
      success: {
        label: language === "ka" ? "წარმატებული" : "Success",
        variant: "default",
        icon: CheckCircle2,
        cls: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30",
      },
      failed: {
        label: language === "ka" ? "შეცდომა" : "Failed",
        variant: "destructive",
        icon: XCircle,
        cls: "bg-red-500/10 text-red-700 dark:text-red-300 border-red-500/30",
      },
    };
    const s = map[status] || map.running;
    const Icon = s.icon;
    return (
      <Badge variant="outline" className={s.cls}>
        <Icon className={`w-3 h-3 mr-1 ${status === "running" ? "animate-spin" : ""}`} />
        {s.label}
      </Badge>
    );
  };

  const triggerLabel = (run: PayrollRun) => {
    if (run.triggered_by === "manual") return language === "ka" ? "ხელით" : "Manual";
    if (run.triggered_by === "manual_recovery") return language === "ka" ? "ხელით (აღდგენა)" : "Manual (recovery)";
    if (run.triggered_by === "historical") return language === "ka" ? "ისტორიული" : "Historical";
    return language === "ka" ? "ავტომატური (Cron)" : "Automatic (Cron)";
  };

  const formatDuration = (ms: number | null) => {
    if (!ms || ms < 0) return "-";
    if (ms < 1000) return `${ms} ms`;
    return `${(ms / 1000).toFixed(1)} s`;
  };

  const formatDate = (iso: string | null) => {
    if (!iso) return "-";
    return new Date(iso).toLocaleString(language === "ka" ? "ka-GE" : "en-US");
  };

  if (!isAdmin) {
    return (
      <div className="p-6">
        <p className="text-muted-foreground">
          {language === "ka" ? "წვდომა შეზღუდულია" : "Access restricted"}
        </p>
      </div>
    );
  }

  const yearOptions = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/payroll")}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">
              {language === "ka" ? "ხელფასის გატარების ისტორია" : "Payroll Run History"}
            </h1>
            <p className="text-sm text-muted-foreground">
              {language === "ka"
                ? "ყოველი გაშვების სტატუსი, ხანგრძლივობა და შედეგი"
                : "Status, duration and outcome of every run"}
            </p>
          </div>
        </div>
        <Button variant="outline" onClick={fetchRuns} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} />
          {language === "ka" ? "განახლება" : "Refresh"}
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            {language === "ka" ? "ახალი გაშვება ხელით" : "Trigger new run manually"}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3 items-end">
          <div className="space-y-1">
            <label className="text-xs text-muted-foreground">
              {language === "ka" ? "თვე" : "Month"}
            </label>
            <Select value={manualMonth} onValueChange={setManualMonth}>
              <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                {months.map((m, i) => (
                  <SelectItem key={i + 1} value={String(i + 1)}>{m}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <label className="text-xs text-muted-foreground">
              {language === "ka" ? "წელი" : "Year"}
            </label>
            <Select value={manualYear} onValueChange={setManualYear}>
              <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                {yearOptions.map(y => (
                  <SelectItem key={y} value={String(y)}>{y}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button onClick={triggerRun} disabled={running}>
            {running ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Play className="w-4 h-4 mr-2" />}
            {language === "ka" ? "გაშვება" : "Run"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            {language === "ka" ? "ბოლო გაშვებები" : "Recent runs"}
          </CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{language === "ka" ? "პერიოდი" : "Period"}</TableHead>
                <TableHead>{language === "ka" ? "სტატუსი" : "Status"}</TableHead>
                <TableHead>{language === "ka" ? "თანამშრომლები" : "Employees"}</TableHead>
                <TableHead>{language === "ka" ? "სულ წმინდა" : "Total Net"}</TableHead>
                <TableHead>{language === "ka" ? "გამშვები" : "Triggered by"}</TableHead>
                <TableHead>{language === "ka" ? "დაიწყო" : "Started"}</TableHead>
                <TableHead>{language === "ka" ? "ხანგრძლივობა" : "Duration"}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading && (
                <TableRow><TableCell colSpan={7} className="text-center py-8"><Loader2 className="w-5 h-5 animate-spin mx-auto" /></TableCell></TableRow>
              )}
              {!loading && runs.length === 0 && (
                <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  {language === "ka" ? "ჩანაწერები არ არის" : "No records"}
                </TableCell></TableRow>
              )}
              {!loading && runs.map(run => (
                <TableRow
                  key={run.id}
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => setSelected(run)}
                >
                  <TableCell className="font-medium">{months[run.month - 1]} {run.year}</TableCell>
                  <TableCell>{statusBadge(run.status)}</TableCell>
                  <TableCell>{run.records_processed}</TableCell>
                  <TableCell>{Number(run.total_net_amount).toFixed(2)} ₾</TableCell>
                  <TableCell>
                    <span className="inline-flex items-center gap-1 text-sm">
                      {run.triggered_by === "manual" || run.triggered_by === "manual_recovery"
                        ? <User className="w-3 h-3" />
                        : <Bot className="w-3 h-3" />}
                      {triggerLabel(run)}
                    </span>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{formatDate(run.started_at)}</TableCell>
                  <TableCell className="text-sm">
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatDuration(run.duration_ms)}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {selected && `${months[selected.month - 1]} ${selected.year}`}
            </DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-3 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">{language === "ka" ? "სტატუსი" : "Status"}</span>{statusBadge(selected.status)}</div>
              <div className="flex justify-between"><span className="text-muted-foreground">{language === "ka" ? "თანამშრომლები" : "Employees processed"}</span><span className="font-medium">{selected.records_processed}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{language === "ka" ? "სულ წმინდა" : "Total net amount"}</span><span className="font-medium">{Number(selected.total_net_amount).toFixed(2)} ₾</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{language === "ka" ? "გამშვები" : "Triggered by"}</span><span>{triggerLabel(selected)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{language === "ka" ? "დაიწყო" : "Started at"}</span><span>{formatDate(selected.started_at)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{language === "ka" ? "დასრულდა" : "Completed at"}</span><span>{formatDate(selected.completed_at)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">{language === "ka" ? "ხანგრძლივობა" : "Duration"}</span><span>{formatDuration(selected.duration_ms)}</span></div>
              {selected.error_message && (
                <div className="mt-3 p-3 rounded-md border border-red-500/30 bg-red-500/5">
                  <div className="text-xs font-semibold text-red-700 dark:text-red-300 mb-1">
                    {language === "ka" ? "შეცდომის შეტყობინება" : "Error message"}
                  </div>
                  <div className="text-xs font-mono break-all">{selected.error_message}</div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
