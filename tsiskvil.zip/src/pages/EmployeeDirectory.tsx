import { useEffect, useMemo, useState } from "react";
import { Users, Search, Building2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { PageTransition } from "@/components/PageTransition";
import { useBranchFilter } from "@/hooks/useBranchFilter";


interface DirectoryEmployee {
  id: string;
  full_name: string;
  department: string | null;
}

export default function EmployeeDirectory() {
  const [employees, setEmployees] = useState<DirectoryEmployee[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState<string>("all");

  const branchId = useBranchFilter();

  useEffect(() => {
    const load = async () => {
      try {
        let q = supabase
          .from("employees")
          .select("id, full_name, department")
          .eq("status", "active")
          .order("full_name", { ascending: true });
        if (branchId) q = q.eq("branch_id", branchId);
        const { data, error } = await q;
        if (error) throw error;
        setEmployees((data || []) as any);
      } catch (e) {
        console.error("Failed to load directory", e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [branchId]);


  const departments = useMemo(() => {
    const map = new Map<string, string>();
    employees.forEach((e) => {
      if (e.department) map.set(e.department, e.department);
    });
    return Array.from(map.keys()).sort();
  }, [employees]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return employees.filter((e) => {
      const matchesQuery = !q || e.full_name?.toLowerCase().includes(q);
      const matchesDept =
        departmentFilter === "all" ||
        (e.department || "უცნობი") === departmentFilter;
      return matchesQuery && matchesDept;
    });
  }, [employees, search, departmentFilter]);

  // Group by department
  const grouped = useMemo(() => {
    const groups: Record<string, DirectoryEmployee[]> = {};
    filtered.forEach((e) => {
      const key = e.department || "უცნობი დეპარტამენტი";
      if (!groups[key]) groups[key] = [];
      groups[key].push(e);
    });
    return Object.entries(groups).sort(([a], [b]) => a.localeCompare(b, "ka"));
  }, [filtered]);

  const initials = (name: string) =>
    name
      .split(" ")
      .map((p) => p[0])
      .filter(Boolean)
      .slice(0, 2)
      .join("")
      .toUpperCase();

  return (
    <PageTransition>
      <div className="space-y-6 p-4 md:p-6">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Users className="h-7 w-7 text-primary" />
            თანამშრომელთა დირექტორია
          </h1>
          <p className="text-muted-foreground mt-1">
            {filtered.length} აქტიური თანამშრომელი
          </p>
        </div>

        <Card className="border-none shadow-md">
          <CardContent className="p-4 flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="ძიება სახელით..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-full md:w-[240px]">
                <SelectValue placeholder="ყველა დეპარტამენტი" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                {departments.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {loading ? (
          <div className="text-center py-12 text-muted-foreground">იტვირთება...</div>
        ) : grouped.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">თანამშრომელი ვერ მოიძებნა</div>
        ) : (
          <div className="space-y-6">
            {grouped.map(([deptName, members]) => (
              <div key={deptName}>
                <div className="flex items-center gap-2 mb-3">
                  <Building2 className="h-4 w-4 text-primary" />
                  <h2 className="text-lg font-semibold">{deptName}</h2>
                  <Badge variant="secondary">{members.length}</Badge>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                  {members.map((emp) => (
                    <Card
                      key={emp.id}
                      className="border border-border/60 hover:shadow-md hover:border-primary/40 transition-all"
                    >
                      <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                        <Avatar className="h-14 w-14 border-2 border-primary/20">
                          <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                            {initials(emp.full_name)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="text-sm font-medium leading-tight line-clamp-2">
                          {emp.full_name}
                        </div>
                        <div className="text-xs text-muted-foreground line-clamp-1">
                          {emp.department || "-"}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </PageTransition>
  );
}
