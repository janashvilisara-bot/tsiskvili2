import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Trophy, TrendingUp, Users, Eye, Lock, AlertTriangle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

interface EmployeeWithRating {
  id: string;
  full_name: string;
  position: string;
  department: string | null;
  photo_url: string | null;
  avgRating: number;
  evaluationCount: number;
  latestEvaluation: string;
}

export default function Evaluations() {
  const navigate = useNavigate();
  const { userRole } = useAuth();
  const [topPerformers, setTopPerformers] = useState<EmployeeWithRating[]>([]);
  const [allEmployees, setAllEmployees] = useState<EmployeeWithRating[]>([]);
  const [riskAssessments, setRiskAssessments] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const isManagement = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    fetchEvaluations();
    if (isManagement) fetchRiskAssessments();
  }, []);

  const fetchEvaluations = async () => {
    setIsLoading(true);
    try {
      // Fetch all employees with their evaluations
      const { data: employees, error: empError } = await supabase
        .from('employees')
        .select('id, full_name, position, department, status')
        .eq('status', 'active');

      if (empError) throw empError;

      // Fetch all evaluations
      const { data: evaluations, error: evalError } = await supabase
        .from('employee_evaluations')
        .select('employee_id, overall_rating, evaluation_date');

      if (evalError) throw evalError;

      // Calculate average ratings for each employee
      const employeeRatings: EmployeeWithRating[] = employees
        .map((emp) => {
          const empEvals = evaluations?.filter((e) => e.employee_id === emp.id) || [];
          
          if (empEvals.length === 0) {
            return null;
          }

          const avgRating = empEvals.reduce((sum, e) => sum + (e.overall_rating || 0), 0) / empEvals.length;
          const latestEval = empEvals.sort((a, b) => 
            new Date(b.evaluation_date).getTime() - new Date(a.evaluation_date).getTime()
          )[0];

          return {
            id: emp.id,
            full_name: emp.full_name,
            position: emp.position || '',
            department: emp.department,
            photo_url: null,
            avgRating: Math.round(avgRating * 10) / 10,
            evaluationCount: empEvals.length,
            latestEvaluation: latestEval.evaluation_date,
          };
        })
        .filter((emp): emp is EmployeeWithRating => emp !== null)
        .sort((a, b) => b.avgRating - a.avgRating);

      setAllEmployees(employeeRatings);
      setTopPerformers(employeeRatings.slice(0, 10));
    } catch (error: any) {
      console.error('Error fetching evaluations:', error);
      toast.error('შეფასებების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchRiskAssessments = async () => {
    try {
      const { data, error } = await supabase
        .from('employee_risk_assessments')
        .select('*, employees!inner(full_name, position, department)')
        .order('risk_score', { ascending: false });

      if (!error && data) {
        setRiskAssessments(data);
      }
    } catch (error) {
      console.error('Error fetching risk assessments:', error);
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-orange-600';
      case 'critical': return 'text-red-600';
      default: return 'text-muted-foreground';
    }
  };

  const getRiskLabel = (level: string) => {
    switch (level) {
      case 'low': return 'დაბალი';
      case 'medium': return 'საშუალო';
      case 'high': return 'მაღალი';
      case 'critical': return 'კრიტიკული';
      default: return level;
    }
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 4.5) return "text-green-600";
    if (rating >= 3.5) return "text-blue-600";
    if (rating >= 2.5) return "text-yellow-600";
    return "text-red-600";
  };

  const getRatingBadge = (rating: number) => {
    if (rating >= 4.5) return { variant: "default" as const, text: "შესანიშნავი" };
    if (rating >= 3.5) return { variant: "secondary" as const, text: "კარგი" };
    if (rating >= 2.5) return { variant: "outline" as const, text: "საშუალო" };
    return { variant: "destructive" as const, text: "საჭიროებს გაუმჯობესებას" };
  };

  const LeaderboardCard = ({ employee, rank }: { employee: EmployeeWithRating; rank: number }) => {
    const badge = getRatingBadge(employee.avgRating);
    
    return (
      <Card className="hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <div className="flex-shrink-0">
              {rank <= 3 ? (
                <div className="relative">
                  <Trophy 
                    className={`h-8 w-8 ${
                      rank === 1 ? 'text-yellow-500' : 
                      rank === 2 ? 'text-gray-400' : 
                      'text-amber-600'
                    }`} 
                  />
                  <span className="absolute -top-1 -right-1 bg-background border rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                    {rank}
                  </span>
                </div>
              ) : (
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center font-bold text-muted-foreground">
                  {rank}
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="font-semibold truncate">{employee.full_name}</h3>
                <Badge variant={badge.variant}>{badge.text}</Badge>
              </div>
              <p className="text-sm text-muted-foreground truncate">
                {employee.position}
                {employee.department && ` • ${employee.department}`}
              </p>
            </div>

            <div className="text-right flex-shrink-0">
              <div className={`text-2xl font-bold ${getRatingColor(employee.avgRating)}`}>
                {employee.avgRating}
              </div>
              <p className="text-xs text-muted-foreground">
                {employee.evaluationCount} შეფასება
              </p>
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate(`/employee-evaluations/${employee.id}`)}
            >
              <Eye className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  const EmployeeList = ({ employees }: { employees: EmployeeWithRating[] }) => (
    <div className="space-y-3">
      {employees.map((employee, index) => (
        <LeaderboardCard key={employee.id} employee={employee} rank={index + 1} />
      ))}
    </div>
  );

  if (isLoading) {
    return (
      <>
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">იტვირთება...</p>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <TrendingUp className="h-8 w-8" />
              თანამშრომელთა შეფასებები
            </h1>
            <p className="text-muted-foreground mt-2">
              ეფექტურობის მონიტორინგი და შეფასება
            </p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">სულ შეფასებული</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{allEmployees.length}</div>
              <p className="text-xs text-muted-foreground">აქტიური თანამშრომელი</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">საშუალო რეიტინგი</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {allEmployees.length > 0
                  ? (allEmployees.reduce((sum, e) => sum + e.avgRating, 0) / allEmployees.length).toFixed(1)
                  : '0'}
              </div>
              <p className="text-xs text-muted-foreground">5-დან</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">ყველაზე მაღალი</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {allEmployees.length > 0 ? topPerformers[0]?.avgRating || '0' : '0'}
              </div>
              <p className="text-xs text-muted-foreground truncate">
                {topPerformers[0]?.full_name || '-'}
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all" className="gap-2">
              <Users className="h-4 w-4" />
              ყველა თანამშრომელი
            </TabsTrigger>
            <TabsTrigger value="leaderboard" className="gap-2">
              {!isManagement && <Lock className="h-4 w-4" />}
              <Trophy className="h-4 w-4" />
              ლიდერბორდი (TOP 10)
            </TabsTrigger>
            {isManagement && (
              <TabsTrigger value="risk" className="gap-2">
                <AlertTriangle className="h-4 w-4" />
                რისკის ანალიზი
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {allEmployees.length > 0 ? (
              <EmployeeList employees={allEmployees} />
            ) : (
              <Card>
                <CardContent className="flex h-32 items-center justify-center text-muted-foreground">
                  შეფასებები არ მოიძებნა
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="leaderboard" className="space-y-4">
            {!isManagement ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lock className="h-5 w-5" />
                    წვდომა შეზღუდულია
                  </CardTitle>
                  <CardDescription>
                    ლიდერბორდის ნახვა ხელმისაწვდომია მხოლოდ მენეჯმენტისთვის
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex h-32 items-center justify-center">
                  <p className="text-muted-foreground text-center">
                    თქვენ არ გაქვთ უფლება ნახოთ ლიდერბორდი.<br />
                    დაუკავშირდით ადმინისტრატორს დამატებითი ინფორმაციისთვის.
                  </p>
                </CardContent>
              </Card>
            ) : topPerformers.length > 0 ? (
              <div className="space-y-4">
                <Card className="gradient-primary text-white">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Trophy className="h-6 w-6" />
                      TOP 10 თანამშრომელი
                    </CardTitle>
                    <CardDescription className="text-white/80">
                      საუკეთესო ეფექტურობის მქონე თანამშრომლები
                    </CardDescription>
                  </CardHeader>
                </Card>
                <EmployeeList employees={topPerformers} />
              </div>
            ) : (
              <Card>
                <CardContent className="flex h-32 items-center justify-center text-muted-foreground">
                  შეფასებები არ მოიძებნა
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {isManagement && (
            <TabsContent value="risk" className="space-y-4">
              {riskAssessments.length > 0 ? (
                <div className="space-y-3">
                  {riskAssessments.map((assessment: any) => (
                    <Card key={assessment.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4">
                          <div className="flex-shrink-0">
                            <AlertTriangle className={`h-6 w-6 ${getRiskColor(assessment.risk_level)}`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold truncate">{assessment.employees?.full_name}</h3>
                              <Badge variant={assessment.risk_level === 'critical' || assessment.risk_level === 'high' ? 'destructive' : assessment.risk_level === 'medium' ? 'secondary' : 'default'}>
                                {getRiskLabel(assessment.risk_level)}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground truncate">
                              {assessment.employees?.position}
                              {assessment.employees?.department && ` • ${assessment.employees.department}`}
                            </p>
                          </div>
                          <div className="text-right flex-shrink-0 w-24">
                            <div className={`text-2xl font-bold ${getRiskColor(assessment.risk_level)}`}>
                              {assessment.risk_score}
                            </div>
                            <Progress value={assessment.risk_score} className="h-2 mt-1" />
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate(`/employee-evaluations/${assessment.employee_id}`)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="flex h-32 items-center justify-center text-muted-foreground">
                    რისკის ანალიზი ჯერ არ ჩატარებულა. გადადით თანამშრომლის შეფასებებზე და გამოიყენეთ "რისკის ანალიზი" ღილაკი.
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          )}
        </Tabs>
      </div>
    </>
  );
}
