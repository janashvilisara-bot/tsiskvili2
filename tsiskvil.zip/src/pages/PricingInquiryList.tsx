import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import {
  Search,
  Eye,
  Inbox,
  Building2,
  Mail,
  Phone,
  Users,
  MapPin,
  ArrowLeft,
  Calendar,
  Tag,
  StickyNote,
} from "lucide-react";

type Inquiry = {
  id: string;
  company_name: string;
  contact_person: string;
  contact_position: string | null;
  email: string;
  phone: string | null;
  website: string | null;
  industry: string | null;
  country: string | null;
  employee_count: number | null;
  branches_count: number | null;
  current_hr_system: string | null;
  modules_needed: string[] | null;
  integrations_needed: string[] | null;
  special_requirements: string | null;
  expected_users: number | null;
  timeline: string | null;
  budget_range: string | null;
  additional_notes: string | null;
  status: string;
  internal_notes: string | null;
  created_at: string;
  updated_at: string;
};

const statusLabels: Record<string, string> = {
  new: "ახალი",
  contacted: "დაკავშირებული",
  proposal_sent: "შეთავაზება გაგზავნილი",
  in_negotiation: "მოლაპარაკება",
  won: "დამკვიდრებული",
  lost: "დაკარგული",
  on_hold: "შეჩერებული",
};

const statusColors: Record<string, string> = {
  new: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  contacted: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  proposal_sent: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  in_negotiation: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
  won: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  lost: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  on_hold: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200",
};

export default function PricingInquiryList() {
  const { userRole } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selected, setSelected] = useState<Inquiry | null>(null);
  const [internalNotes, setInternalNotes] = useState("");
  const [updating, setUpdating] = useState(false);

  // Access control: only admin and hr_manager can view
  useEffect(() => {
    if (userRole !== "admin" && userRole !== "hr_manager") {
      navigate("/");
    }
  }, [userRole, navigate]);

  const fetchInquiries = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("pricing_inquiries")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      toast({
        title: "შეცდომა",
        description: "მონაცემების ჩატვირთვა ვერ მოხერხდა",
        variant: "destructive",
      });
    } else {
      setInquiries(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (userRole === "admin" || userRole === "hr_manager") {
      fetchInquiries();
    }
  }, [userRole]);

  const filtered = inquiries.filter((inq) => {
    const matchesSearch =
      search.trim() === "" ||
      inq.company_name.toLowerCase().includes(search.toLowerCase()) ||
      inq.contact_person.toLowerCase().includes(search.toLowerCase()) ||
      inq.email.toLowerCase().includes(search.toLowerCase()) ||
      (inq.phone && inq.phone.includes(search));
    const matchesStatus =
      statusFilter === "all" || inq.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const updateStatus = async (id: string, newStatus: string) => {
    setUpdating(true);
    const { error } = await supabase
      .from("pricing_inquiries")
      .update({ status: newStatus, updated_at: new Date().toISOString() })
      .eq("id", id);

    setUpdating(false);
    if (error) {
      toast({
        title: "შეცდომა",
        description: "სტატუსის განახლება ვერ მოხერხდა",
        variant: "destructive",
      });
    } else {
      toast({ title: "განახლებულია", description: "სტატუსი წარმატებით შეიცვალა" });
      setInquiries((prev) =>
        prev.map((i) => (i.id === id ? { ...i, status: newStatus } : i))
      );
      if (selected && selected.id === id) {
        setSelected({ ...selected, status: newStatus });
      }
    }
  };

  const saveInternalNotes = async () => {
    if (!selected) return;
    setUpdating(true);
    const { error } = await supabase
      .from("pricing_inquiries")
      .update({ internal_notes: internalNotes, updated_at: new Date().toISOString() })
      .eq("id", selected.id);

    setUpdating(false);
    if (error) {
      toast({
        title: "შეცდომა",
        description: "შენიშვნის შენახვა ვერ მოხერხდა",
        variant: "destructive",
      });
    } else {
      toast({ title: "შენახულია", description: "შიდა შენიშვნა განახლდა" });
      setInquiries((prev) =>
        prev.map((i) =>
          i.id === selected.id ? { ...i, internal_notes: internalNotes } : i
        )
      );
      setSelected({ ...selected, internal_notes: internalNotes });
    }
  };

  const openDetail = (inq: Inquiry) => {
    setSelected(inq);
    setInternalNotes(inq.internal_notes || "");
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
          <p className="text-muted-foreground">იტვირთება...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-mesh py-6 px-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Inbox className="h-6 w-6 text-primary" />
                ფასების შეკითხვები
              </h1>
              <p className="text-sm text-muted-foreground">
                კომპანიების მიერ გამოგზავნილი ფასის შეფასების მოთხოვნები
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary">სულ: {inquiries.length}</Badge>
            <Badge variant="outline" className="text-green-600">
              ახალი: {inquiries.filter((i) => i.status === "new").length}
            </Badge>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="ძებნა კომპანიით, კონტაქტით, ელფოსტით..."
                  className="pl-9"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <div className="flex gap-2 flex-wrap">
                {["all", "new", "contacted", "proposal_sent", "won", "lost"].map(
                  (s) => (
                    <Button
                      key={s}
                      variant={statusFilter === s ? "default" : "outline"}
                      size="sm"
                      onClick={() => setStatusFilter(s)}
                    >
                      {s === "all" ? "ყველა" : statusLabels[s] || s}
                    </Button>
                  )
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Table */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">შეკითხვების სია</CardTitle>
          </CardHeader>
          <CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>კომპანია</TableHead>
                  <TableHead>კონტაქტი</TableHead>
                  <TableHead>თანამშრომლები</TableHead>
                  <TableHead>მოდულები</TableHead>
                  <TableHead>ბიუჯეტი</TableHead>
                  <TableHead>სტატუსი</TableHead>
                  <TableHead>თარიღი</TableHead>
                  <TableHead className="text-right">ქმედება</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                      შედეგები არ მოიძებნა
                    </TableCell>
                  </TableRow>
                ) : (
                  filtered.map((inq) => (
                    <TableRow
                      key={inq.id}
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => openDetail(inq)}
                    >
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Building2 className="h-4 w-4 text-primary shrink-0" />
                          <span className="font-medium">{inq.company_name}</span>
                        </div>
                        {inq.industry && (
                          <div className="text-xs text-muted-foreground mt-0.5">
                            {inq.industry}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div>{inq.contact_person}</div>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Mail className="h-3 w-3" />
                          {inq.email}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          {inq.employee_count || "-"}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {(inq.modules_needed || [])
                            .slice(0, 3)
                            .map((m) => (
                              <Badge key={m} variant="secondary" className="text-[10px]">
                                {m.length > 15 ? m.slice(0, 15) + "..." : m}
                              </Badge>
                            ))}
                          {(inq.modules_needed || []).length > 3 && (
                            <Badge variant="outline" className="text-[10px]">
                              +{(inq.modules_needed || []).length - 3}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{inq.budget_range || "-"}</TableCell>
                      <TableCell>
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            statusColors[inq.status] || ""
                          }`}
                        >
                          {statusLabels[inq.status] || inq.status}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {new Date(inq.created_at).toLocaleDateString("ka-GE")}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            openDetail(inq);
                          }}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2 text-xl">
                  <Building2 className="h-5 w-5 text-primary" />
                  {selected.company_name}
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-6">
                {/* Status & actions */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm text-muted-foreground">სტატუსი:</span>
                  {Object.entries(statusLabels).map(([key, label]) => (
                    <Button
                      key={key}
                      size="sm"
                      variant={selected.status === key ? "default" : "outline"}
                      onClick={() => updateStatus(selected.id, key)}
                      disabled={updating}
                      className="text-xs"
                    >
                      {label}
                    </Button>
                  ))}
                </div>

                {/* Info grid */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-primary" />
                        კომპანიის ინფორმაცია
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ინდუსტრია</span>
                        <span>{selected.industry || "-"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ქვეყანა</span>
                        <span>{selected.country || "-"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">თანამშრომლები</span>
                        <span>{selected.employee_count || "-"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ფილიალები</span>
                        <span>{selected.branches_count || "-"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ვებსაიტი</span>
                        <span>{selected.website || "-"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">მიმდინარე HR</span>
                        <span>{selected.current_hr_system || "-"}</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Mail className="h-4 w-4 text-primary" />
                        საკონტაქტო ინფორმაცია
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">სახელი</span>
                        <span>{selected.contact_person}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">თანამდებობა</span>
                        <span>{selected.contact_position || "-"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ელფოსტა</span>
                        <span className="font-mono text-xs">{selected.email}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ტელეფონი</span>
                        <span>{selected.phone || "-"}</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Modules & integrations */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Tag className="h-4 w-4 text-primary" />
                        საჭირო მოდულები ({(selected.modules_needed || []).length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {(selected.modules_needed || []).map((m) => (
                          <Badge key={m} variant="secondary">
                            {m}
                          </Badge>
                        ))}
                        {(selected.modules_needed || []).length === 0 && (
                          <span className="text-sm text-muted-foreground">არ არის მითითებული</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-primary" />
                        ინტეგრაციები ({(selected.integrations_needed || []).length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {(selected.integrations_needed || []).map((m) => (
                          <Badge key={m} variant="outline">
                            {m}
                          </Badge>
                        ))}
                        {(selected.integrations_needed || []).length === 0 && (
                          <span className="text-sm text-muted-foreground">არ არის მითითებული</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Requirements & notes */}
                {(selected.special_requirements || selected.additional_notes) && (
                  <div className="grid sm:grid-cols-2 gap-4">
                    {selected.special_requirements && (
                      <Card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-sm">სპეციფიური მოთხოვნები</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm whitespace-pre-wrap">
                            {selected.special_requirements}
                          </p>
                        </CardContent>
                      </Card>
                    )}
                    {selected.additional_notes && (
                      <Card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-sm">დამატებითი კომენტარი</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm whitespace-pre-wrap">
                            {selected.additional_notes}
                          </p>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                )}

                {/* Timeline & budget */}
                <Card>
                  <CardContent className="p-4 flex flex-wrap gap-6 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">ვადა:</span>
                      <span>{selected.timeline || "-"}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">მოსალოდნელი მომხმარებლები:</span>
                      <span>{selected.expected_users || "-"}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Tag className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">ბიუჯეტი:</span>
                      <span>{selected.budget_range || "-"}</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Internal notes (admin only) */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <StickyNote className="h-4 w-4 text-primary" />
                      შიდა შენიშვნები (მხოლოდ Admin/HR)
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Textarea
                      rows={4}
                      placeholder="დაწერეთ შიდა კომენტარი - ეს ხილვადია მხოლოდ Admin/HR-ისთვის..."
                      value={internalNotes}
                      onChange={(e) => setInternalNotes(e.target.value)}
                    />
                    <div className="flex justify-end">
                      <Button
                        onClick={saveInternalNotes}
                        disabled={updating}
                        size="sm"
                      >
                        შენახვა
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
