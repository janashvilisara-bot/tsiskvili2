import { useState, useEffect } from "react";
import { Plus, Search, Calendar, User, Building2, AlertCircle, CheckCircle, XCircle, Send, LayoutGrid, List, Loader2 } from "lucide-react";
import { ResponsiveTable, MobileCard, MobileCardRow } from "@/components/ResponsiveTable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import { formatters } from "@/lib/dateUtils";
import { useRealtime } from "@/hooks/useRealtime";
import { usePersistedState } from "@/hooks/usePersistedState";
import KanbanBoard from "@/components/tasks/KanbanBoard";
import ProjectsManager from "@/components/tasks/ProjectsManager";
import TaskDetailEnhanced from "@/components/tasks/TaskDetailEnhanced";

interface Task {
  id: string;
  title: string;
  description: string | null;
  task_type: string;
  status: string;
  priority: string;
  department_id: string | null;
  assigned_to: string | null;
  assigned_by: string | null;
  due_date: string | null;
  completed_at: string | null;
  submitted_at: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  approval_notes: string | null;
  notes: string | null;
  created_at: string;
  project_id: string | null;
  parent_task_id: string | null;
  progress: number | null;
  employees?: { full_name: string };
  departments?: { name: string };
}

const taskTypes = [
  { value: 'contract_preparation', label: 'ხელშეკრულების გაფორმება' },
  { value: 'laptop_purchase', label: 'ლეპტოპის შეძენა' },
  { value: 'training', label: 'ტრენინგი' },
  { value: 'onboarding', label: 'ონბორდინგი' },
  { value: 'document_preparation', label: 'დოკუმენტაცია' },
  { value: 'equipment_setup', label: 'აღჭურვილობის მოწყობა' },
  { value: 'other', label: 'სხვა' },
];

const statusOptions = [
  { value: 'draft', label: 'სამუშაო ვერსია', color: 'bg-gray-100 text-gray-700', icon: AlertCircle },
  { value: 'submitted', label: 'გაგზავნილი', color: 'bg-blue-100 text-blue-700', icon: Send },
  { value: 'approved', label: 'დამტკიცებული', color: 'bg-green-100 text-green-700', icon: CheckCircle },
  { value: 'rejected', label: 'უარყოფილი', color: 'bg-red-100 text-red-700', icon: XCircle },
  { value: 'in_progress', label: 'მიმდინარე', color: 'bg-purple-100 text-purple-700', icon: AlertCircle },
  { value: 'completed', label: 'დასრულებული', color: 'bg-teal-100 text-teal-700', icon: CheckCircle },
  { value: 'cancelled', label: 'გაუქმებული', color: 'bg-slate-100 text-slate-700', icon: XCircle },
];

const priorityOptions = [
  { value: 'low', label: 'დაბალი', color: 'bg-gray-100 text-gray-700' },
  { value: 'medium', label: 'საშუალო', color: 'bg-blue-100 text-blue-700' },
  { value: 'high', label: 'მაღალი', color: 'bg-orange-100 text-orange-700' },
  { value: 'urgent', label: 'გადაუდებელი', color: 'bg-red-100 text-red-700' },
];

export default function Tasks() {
  const { user, userRole } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = usePersistedState<string>("tasks:search", "");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(true);
  const [filterStatus, setFilterStatus] = usePersistedState<string>("tasks:filterStatus", "all");
  const [filterPriority, setFilterPriority] = usePersistedState<string>("tasks:filterPriority", "all");
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [currentEmployeeId, setCurrentEmployeeId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"list" | "kanban">("list");
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);

  const canManage = userRole === 'admin' || userRole === 'hr_manager' || userRole === 'department_manager';
  const activeBranchId = useBranchFilter();

  useEffect(() => {
    fetchTasks();
    fetchEmployees();
    fetchDepartments();
  }, [activeBranchId]);

  useEffect(() => {
    if (user?.id) fetchCurrentEmployee();
  }, [user?.id]);

  const fetchCurrentEmployee = async () => {
    if (!user?.id) return;
    const { data } = await supabase
      .from('employees').select('id').eq('user_id', user.id).maybeSingle();
    if (data) setCurrentEmployeeId(data.id);
  };

  const fetchEmployees = async () => {
    let q = supabase
      .from('employees').select('id, full_name, position').eq('status', 'active');
    if (activeBranchId) q = q.eq('branch_id', activeBranchId);
    const { data } = await q;
    setEmployees(data || []);
  };

  const fetchDepartments = async () => {
    let q = supabase
      .from('departments').select('id, name').eq('is_active', true);
    if (activeBranchId) q = q.eq('branch_id', activeBranchId);
    const { data } = await q;
    setDepartments(data || []);
  };

  const fetchTasks = async () => {
    setIsFetching(true);
    try {
      let q = supabase
        .from('tasks')
        .select(`*, departments(name)`)
        .is('parent_task_id', null)
        .order('created_at', { ascending: false });
      if (activeBranchId) q = q.eq('branch_id', activeBranchId);
      const { data, error } = await q;

      if (error) throw error;

      const tasksWithEmployees = await Promise.all(
        (data || []).map(async (task) => {
          if (task.assigned_to) {
            const { data: employee } = await supabase
              .from('employees').select('full_name').eq('id', task.assigned_to).single();
            return { ...task, employees: employee };
          }
          return { ...task, employees: null };
        })
      );

      setTasks(tasksWithEmployees as any);
    } catch (error: any) {
      toast.error('დავალებების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsFetching(false);
    }
  };

  useRealtime({ table: 'tasks', event: '*', onChange: fetchTasks });

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const { data: currentEmployee } = await supabase
        .from('employees').select('id').eq('user_id', user?.id).maybeSingle();

      const payload: any = {
        title: formData.get('title') as string,
        description: formData.get('description') as string || null,
        task_type: formData.get('task_type') as string,
        status: 'submitted',
        priority: formData.get('priority') as string,
        department_id: formData.get('department_id') as string || null,
        assigned_to: formData.get('assigned_to') as string || null,
        assigned_by: currentEmployee?.id,
        due_date: formData.get('due_date') as string || null,
        notes: formData.get('notes') as string || null,
      };

      if (selectedProjectId) {
        payload.project_id = selectedProjectId;
      }

      const { error } = await supabase.from('tasks').insert([payload]);
      if (error) throw error;

      // Send notification to assignee
      if (payload.assigned_to) {
        const { data: assigneeEmployee } = await supabase
          .from('employees').select('user_id').eq('id', payload.assigned_to).single();
        if (assigneeEmployee?.user_id) {
          await supabase.from('notifications').insert({
            title: 'ახალი დავალება',
            message: `თქვენ გაქვთ ახალი დავალება: ${payload.title}`,
            type: 'task',
            target_audience: 'individual',
            user_id: assigneeEmployee.user_id,
            created_by: user?.id,
            link: '/tasks',
          });
        }
      }

      toast.success('დავალება გაიგზავნა');
      setIsDialogOpen(false);
      fetchTasks();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDirectAction = async (taskId: string, newStatus: string) => {
    try {
      const { data: currentEmployee } = await supabase
        .from('employees').select('id').eq('user_id', user?.id).maybeSingle();
      const now = new Date().toISOString();
      const updateData: any = {
        status: newStatus,
        reviewed_by: currentEmployee?.id,
        reviewed_at: now,
        updated_at: now,
      };
      if (newStatus === 'completed') updateData.completed_at = now;

      const { error } = await supabase.from('tasks').update(updateData).eq('id', taskId);
      if (error) throw error;
      toast.success(newStatus === 'completed' ? 'დავალება შესრულდა' : 'სტატუსი განახლდა');
      fetchTasks();
    } catch (error: any) {
      toast.error('შეცდომა მოხდა');
    }
  };

  const handleStatusChange = async (taskId: string, newStatus: string) => {
    try {
      const now = new Date().toISOString();
      const updateData: any = { status: newStatus, updated_at: now };
      if (newStatus === 'completed') updateData.completed_at = now;

      const { error } = await supabase.from('tasks').update(updateData).eq('id', taskId);
      if (error) throw error;
      toast.success('სტატუსი განახლდა');
      fetchTasks();
    } catch (error: any) {
      toast.error('შეცდომა მოხდა');
    }
  };

  const isAssignee = (task: Task) => currentEmployeeId && task.assigned_to === currentEmployeeId;

  // Filter tasks
  const filteredTasks = tasks.filter((task) => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'all' || task.status === filterStatus;
    const matchesPriority = filterPriority === 'all' || task.priority === filterPriority;
    const matchesProject = !selectedProjectId || task.project_id === selectedProjectId;
    return matchesSearch && matchesStatus && matchesPriority && matchesProject;
  });

  const getStatusBadge = (status: string, task?: Task) => {
    const option = statusOptions.find(s => s.value === status);
    if (!option) return { label: status, color: 'bg-gray-100', icon: AlertCircle };
    if (status === 'submitted' && task && isAssignee(task)) {
      return { ...option, label: 'მიღებული' };
    }
    return option;
  };

  const getPriorityBadge = (priority: string) => {
    return priorityOptions.find(p => p.value === priority) || { label: priority, color: 'bg-gray-100' };
  };

  const pendingApprovalCount = tasks.filter(t => t.status === 'submitted').length;
  const activeCount = tasks.filter(t => t.status === 'approved' || t.status === 'in_progress').length;
  const completedCount = tasks.filter(t => t.status === 'completed').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">დავალებები</h1>
          <p className="mt-2 text-muted-foreground">დავალებების მართვა და თვალყურის დევნება</p>
        </div>
        <div className="flex items-center gap-2">
          {/* View mode toggle */}
          <div className="flex items-center border rounded-lg">
            <Button
              size="sm" variant={viewMode === "list" ? "default" : "ghost"}
              className="rounded-r-none gap-1"
              onClick={() => setViewMode("list")}
            >
              <List className="h-4 w-4" />
              სია
            </Button>
            <Button
              size="sm" variant={viewMode === "kanban" ? "default" : "ghost"}
              className="rounded-l-none gap-1"
              onClick={() => setViewMode("kanban")}
            >
              <LayoutGrid className="h-4 w-4" />
              Kanban
            </Button>
          </div>

          {canManage && (
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  ახალი დავალება
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>ახალი დავალების შექმნა</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <Label htmlFor="title">სათაური *</Label>
                      <Input id="title" name="title" required />
                    </div>
                    <div className="col-span-2">
                      <Label htmlFor="description">აღწერა</Label>
                      <Textarea id="description" name="description" rows={3} />
                    </div>
                    <div>
                      <Label htmlFor="task_type">დავალების ტიპი *</Label>
                      <Select name="task_type" required>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {taskTypes.map((type) => (
                            <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="priority">პრიორიტეტი *</Label>
                      <Select name="priority" required defaultValue="medium">
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {priorityOptions.map((p) => (
                            <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="department_id">დეპარტამენტი</Label>
                      <Select name="department_id">
                        <SelectTrigger><SelectValue placeholder="აირჩიეთ" /></SelectTrigger>
                        <SelectContent>
                          {departments.map((d) => (
                            <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="assigned_to">პასუხისმგებელი</Label>
                      <Select name="assigned_to">
                        <SelectTrigger><SelectValue placeholder="აირჩიეთ" /></SelectTrigger>
                        <SelectContent>
                          {employees.map((e) => (
                            <SelectItem key={e.id} value={e.id}>{e.full_name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-2">
                      <Label htmlFor="due_date">ვადა</Label>
                      <Input id="due_date" name="due_date" type="date" />
                    </div>
                    <div className="col-span-2">
                      <Label htmlFor="notes">შენიშვნები</Label>
                      <Textarea id="notes" name="notes" rows={2} />
                    </div>
                  </div>
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? 'შექმნა...' : 'შექმნა'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      {canManage && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-500/10"><Send className="h-5 w-5 text-blue-600" /></div>
                <div>
                  <p className="text-sm text-muted-foreground">დასამტკიცებელი</p>
                  <p className="text-2xl font-bold">{pendingApprovalCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-500/10"><AlertCircle className="h-5 w-5 text-purple-600" /></div>
                <div>
                  <p className="text-sm text-muted-foreground">აქტიური</p>
                  <p className="text-2xl font-bold">{activeCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-teal-500/10"><CheckCircle className="h-5 w-5 text-teal-600" /></div>
                <div>
                  <p className="text-sm text-muted-foreground">დასრულებული</p>
                  <p className="text-2xl font-bold">{completedCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main content with sidebar */}
      <div className="flex gap-6">
        {/* Projects sidebar */}
        {canManage && (
          <div className="w-64 shrink-0 hidden lg:block">
            <ProjectsManager
              onProjectSelect={setSelectedProjectId}
              selectedProjectId={selectedProjectId}
              departments={departments}
            />
          </div>
        )}

        {/* Tasks area */}
        <div className="flex-1 min-w-0 space-y-4">
          {/* Filters */}
          <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="ძიება..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="სტატუსი" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ყველა სტატუსი</SelectItem>
                {statusOptions.map((s) => (
                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="პრიორიტეტი" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ყველა პრიორიტეტი</SelectItem>
                {priorityOptions.map((p) => (
                  <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Kanban or List view */}
          {viewMode === "kanban" ? (
            <KanbanBoard
              tasks={filteredTasks}
              onStatusChange={handleStatusChange}
              onTaskClick={(task) => { setSelectedTask(task as Task); setIsDetailDialogOpen(true); }}
            />
          ) : isFetching ? (
            <div className="flex h-64 items-center justify-center text-muted-foreground">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>დავალებები ({filteredTasks.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveTable
                  data={filteredTasks}
                  mobileCards={(task: Task) => {
                    const status = getStatusBadge(task.status, task);
                    const priority = getPriorityBadge(task.priority);
                    const taskType = taskTypes.find(t => t.value === task.task_type);
                    const StatusIcon = status.icon;
                    return (
                      <MobileCard key={task.id}>
                        <div className="flex items-start justify-between gap-3 mb-3" onClick={() => { setSelectedTask(task); setIsDetailDialogOpen(true); }}>
                          <h3 className="font-semibold text-base flex-1">{task.title}</h3>
                          <Badge className={`${status.color} flex items-center gap-1 text-xs shrink-0`}>
                            <StatusIcon className="h-3 w-3" />{status.label}
                          </Badge>
                        </div>
                        {task.description && (
                          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{task.description}</p>
                        )}
                        <div className="space-y-2 text-sm">
                          <MobileCardRow label="ტიპი" value={taskType?.label || '-'} />
                          <MobileCardRow label="პრიორიტეტი" value={<Badge className={`${priority.color} text-xs`}>{priority.label}</Badge>} />
                          <MobileCardRow label="პასუხისმგებელი" value={task.employees?.full_name || '-'} />
                          {task.due_date && <MobileCardRow label="ვადა" value={formatters.shortDate(task.due_date)} />}
                        </div>
                        <div className="flex gap-2 mt-4 pt-3 border-t">
                          {task.status === 'submitted' && isAssignee(task) && (
                            <>
                              <Button size="sm" variant="default" className="flex-1" onClick={() => handleDirectAction(task.id, 'completed')}>
                                <CheckCircle className="h-3 w-3 mr-1" />შესრულებულია
                              </Button>
                              <Button size="sm" variant="destructive" className="flex-1" onClick={() => handleDirectAction(task.id, 'rejected')}>
                                <XCircle className="h-3 w-3 mr-1" />უარყოფა
                              </Button>
                            </>
                          )}
                          {(task.status === 'approved' || task.status === 'in_progress') && (isAssignee(task) || canManage) && (
                            <Select value={task.status} onValueChange={(v) => handleStatusChange(task.id, v)}>
                              <SelectTrigger className="w-full h-9"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="approved">დამტკიცებული</SelectItem>
                                <SelectItem value="in_progress">მიმდინარე</SelectItem>
                                <SelectItem value="completed">დასრულებული</SelectItem>
                              </SelectContent>
                            </Select>
                          )}
                        </div>
                      </MobileCard>
                    );
                  }}
                >
                  <TableHeader>
                    <TableRow>
                      <TableHead>სათაური</TableHead>
                      <TableHead>ტიპი</TableHead>
                      <TableHead>პრიორიტეტი</TableHead>
                      <TableHead>პასუხისმგებელი</TableHead>
                      <TableHead>ვადა</TableHead>
                      <TableHead>სტატუსი</TableHead>
                      <TableHead>ქმედებები</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTasks.map((task) => {
                      const status = getStatusBadge(task.status, task);
                      const priority = getPriorityBadge(task.priority);
                      const taskType = taskTypes.find(t => t.value === task.task_type);
                      const StatusIcon = status.icon;
                      return (
                        <TableRow key={task.id} className="cursor-pointer hover:bg-muted/50" onClick={() => { setSelectedTask(task); setIsDetailDialogOpen(true); }}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{task.title}</div>
                              {task.description && (
                                <div className={`text-sm text-muted-foreground ${isAssignee(task) ? '' : 'line-clamp-1'}`}>{task.description}</div>
                              )}
                              {task.progress !== null && task.progress > 0 && (
                                <div className="w-24 bg-muted rounded-full h-1 mt-1">
                                  <div className="bg-primary h-1 rounded-full" style={{ width: `${task.progress}%` }} />
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{isAssignee(task) ? (task.description || task.title) : taskType?.label}</TableCell>
                          <TableCell><Badge className={priority.color}>{priority.label}</Badge></TableCell>
                          <TableCell>
                            {task.employees?.full_name ? (
                              <div className="flex items-center gap-2"><User className="h-4 w-4" />{task.employees.full_name}</div>
                            ) : '-'}
                          </TableCell>
                          <TableCell>
                            {task.due_date ? (
                              <div className="flex items-center gap-2"><Calendar className="h-4 w-4" />{formatters.shortDate(task.due_date)}</div>
                            ) : '-'}
                          </TableCell>
                          <TableCell>
                            <Badge className={`${status.color} flex items-center gap-1 w-fit`}>
                              <StatusIcon className="h-3 w-3" />{status.label}
                            </Badge>
                          </TableCell>
                          <TableCell onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center gap-2">
                              {task.status === 'submitted' && isAssignee(task) && (
                                <>
                                  <Button size="sm" variant="default" onClick={() => handleDirectAction(task.id, 'completed')}>
                                    <CheckCircle className="h-3 w-3 mr-1" />შესრულებულია
                                  </Button>
                                  <Button size="sm" variant="destructive" onClick={() => handleDirectAction(task.id, 'rejected')}>
                                    <XCircle className="h-3 w-3 mr-1" />უარყოფა
                                  </Button>
                                </>
                              )}
                              {(task.status === 'approved' || task.status === 'in_progress') && (isAssignee(task) || canManage) && (
                                <Select value={task.status} onValueChange={(v) => handleStatusChange(task.id, v)}>
                                  <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="approved">დამტკიცებული</SelectItem>
                                    <SelectItem value="in_progress">მიმდინარე</SelectItem>
                                    <SelectItem value="completed">დასრულებული</SelectItem>
                                  </SelectContent>
                                </Select>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </ResponsiveTable>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Enhanced Task Detail Dialog */}
      <TaskDetailEnhanced
        task={selectedTask}
        open={isDetailDialogOpen}
        onOpenChange={setIsDetailDialogOpen}
        onStatusChange={handleDirectAction}
        isAssignee={selectedTask ? !!isAssignee(selectedTask) : false}
        canManage={canManage}
        employees={employees}
        statusOptions={statusOptions}
        priorityOptions={priorityOptions}
        taskTypes={taskTypes}
      />

      {/* Review Dialog (kept for backward compatibility) */}
      <Dialog open={isReviewDialogOpen} onOpenChange={setIsReviewDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>დავალების განხილვა</DialogTitle>
          </DialogHeader>
          {selectedTask && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">{selectedTask.title}</h3>
                {selectedTask.description && (
                  <p className="text-sm text-muted-foreground">{selectedTask.description}</p>
                )}
              </div>
              <form id="review-form" className="space-y-4">
                <div>
                  <Label htmlFor="approval_notes">შენიშვნები</Label>
                  <Textarea id="approval_notes" name="approval_notes" placeholder="დაამატეთ შენიშვნები..." rows={3} />
                </div>
                <div className="flex gap-2">
                  <Button type="button" variant="outline" className="flex-1" onClick={() => { handleDirectAction(selectedTask.id, 'rejected'); setIsReviewDialogOpen(false); }}>
                    <XCircle className="h-4 w-4 mr-2" />უარყოფა
                  </Button>
                  <Button type="button" className="flex-1" onClick={() => { handleDirectAction(selectedTask.id, 'approved'); setIsReviewDialogOpen(false); }}>
                    <CheckCircle className="h-4 w-4 mr-2" />დამტკიცება
                  </Button>
                </div>
              </form>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
