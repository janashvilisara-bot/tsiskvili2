import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { Bot, Send, ShieldCheck, FileText, AlertTriangle, CheckCircle2, Loader2, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const STARTERS = [
  "რა მონაცემები გვაქვს დაცული GDPR-ის თანახმად?",
  "როგორ დავამუშავო თანამშრომლის DSR მოთხოვნა?",
  "რა გავაკეთო data breach-ის შემთხვევაში?",
  "შემიძლია სამედიცინო ცნობის შენახვა და რა ვადით?",
];

export default function AIDPO() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [complianceScore, setComplianceScore] = useState<number | null>(null);
  const [stats, setStats] = useState({ dsr: 0, breaches: 0, dpia: 0, consents: 0 });
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadStats();
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const loadStats = async () => {
    try {
      const [dsr, breaches, dpia, consents] = await Promise.all([
        supabase.from("dsr_requests").select("id", { count: "exact", head: true }),
        supabase.from("data_breaches").select("id", { count: "exact", head: true }),
        supabase.from("dpia_assessments").select("id", { count: "exact", head: true }),
        supabase.from("user_consents").select("id", { count: "exact", head: true }),
      ]);
      setStats({
        dsr: dsr.count || 0,
        breaches: breaches.count || 0,
        dpia: dpia.count || 0,
        consents: consents.count || 0,
      });

      // Simple compliance heuristic
      let score = 60;
      if ((dpia.count || 0) > 0) score += 10;
      if ((consents.count || 0) > 0) score += 15;
      if ((breaches.count || 0) === 0) score += 10;
      if ((dsr.count || 0) >= 0) score += 5;
      setComplianceScore(Math.min(score, 100));
    } catch (e) {
      console.error(e);
    }
  };

  const send = async (text?: string) => {
    const content = (text ?? input).trim();
    if (!content || loading) return;
    setInput("");
    const next = [...messages, { role: "user" as const, content }];
    setMessages(next);
    setLoading(true);

    try {
      const { data: session } = await supabase.auth.getSession();
      const token = session.session?.access_token;
      const resp = await fetch(
        `https://fookshkjpwnqxszwykdv.supabase.co/functions/v1/ai-dpo-chat`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
          },
          body: JSON.stringify({ messages: next }),
        }
      );

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({ error: "შეცდომა" }));
        toast.error(err.error || "AI-სთან კავშირი ვერ მოხერხდა");
        setLoading(false);
        return;
      }

      // Stream SSE
      const reader = resp.body?.getReader();
      const decoder = new TextDecoder();
      let assistantText = "";
      setMessages((m) => [...m, { role: "assistant", content: "" }]);

      while (reader) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value);
        const lines = chunk.split("\n").filter((l) => l.startsWith("data: "));
        for (const line of lines) {
          const data = line.slice(6).trim();
          if (data === "[DONE]") continue;
          try {
            const json = JSON.parse(data);
            const delta = json.choices?.[0]?.delta?.content || "";
            if (delta) {
              assistantText += delta;
              setMessages((m) => {
                const copy = [...m];
                copy[copy.length - 1] = { role: "assistant", content: assistantText };
                return copy;
              });
            }
          } catch {}
        }
      }
    } catch (e) {
      console.error(e);
      toast.error("შეცდომა შეტყობინების გაგზავნისას");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <Bot className="h-8 w-8 text-primary" />
          AI DPO ასისტენტი
          <Badge variant="secondary" className="gap-1">
            <Sparkles className="h-3 w-3" /> Beta
          </Badge>
        </h1>
        <p className="mt-2 text-muted-foreground">
          ხელოვნური ინტელექტის მონაცემთა დაცვის ოფიცერი - GDPR და საქართველოს კანონის შესაბამისად
        </p>
      </div>

      {/* Compliance Dashboard */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Compliance Score</CardDescription>
            <CardTitle className="text-2xl flex items-center gap-2">
              {complianceScore ?? "-"}%
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Progress value={complianceScore ?? 0} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>DSR მოთხოვნები</CardDescription>
            <CardTitle className="text-2xl">{stats.dsr}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>DPIA შეფასებები</CardDescription>
            <CardTitle className="text-2xl">{stats.dpia}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Breach ინციდენტი</CardDescription>
            <CardTitle className="text-2xl flex items-center gap-2">
              {stats.breaches}
              {stats.breaches === 0 ? (
                <ShieldCheck className="h-5 w-5 text-emerald-500" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-destructive" />
              )}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Chat */}
      <Card className="flex flex-col h-[600px]">
        <CardHeader className="border-b">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Bot className="h-5 w-5 text-primary" />
            ჩაუსვი კითხვა AI DPO-ს
          </CardTitle>
        </CardHeader>

        <CardContent className="flex-1 overflow-hidden p-0">
          <ScrollArea className="h-full" ref={scrollRef as any}>
            <div className="p-6 space-y-4">
              {messages.length === 0 && (
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">პოპულარული კითხვები:</p>
                  <div className="grid gap-2 sm:grid-cols-2">
                    {STARTERS.map((s) => (
                      <Button
                        key={s}
                        variant="outline"
                        className="h-auto justify-start text-left whitespace-normal py-3"
                        onClick={() => send(s)}
                      >
                        <FileText className="h-4 w-4 mr-2 shrink-0" />
                        {s}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {messages.map((m, i) => (
                <div
                  key={i}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg px-4 py-3 ${
                      m.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted"
                    }`}
                  >
                    {m.role === "assistant" ? (
                      <div className="prose prose-sm dark:prose-invert max-w-none">
                        <ReactMarkdown>{m.content || "..."}</ReactMarkdown>
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap text-sm">{m.content}</p>
                    )}
                  </div>
                </div>
              ))}

              {loading && messages[messages.length - 1]?.role === "user" && (
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg px-4 py-3">
                    <Loader2 className="h-4 w-4 animate-spin" />
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>

        <div className="border-t p-4">
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
              placeholder="დაწერე კითხვა მონაცემთა დაცვის შესახებ..."
              disabled={loading}
            />
            <Button onClick={() => send()} disabled={loading || !input.trim()}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
