import { useState, useEffect } from "react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, MapPin, Search, CheckCircle, XCircle, FileDown } from "lucide-react";
import { formatters } from "@/lib/dateUtils";
import { useAuth } from "@/contexts/AuthContext";
import { exportToExcel } from "@/lib/exportToExcel";

interface PersonalTrip {
  id: string;
  employee_id: string;
  manager_id: string | null;
  destination: string;
  purpose: string | null;
  start_date: string;
  end_date: string;
  start_time: string | null;
  end_time: string | null;
  status: string;
  created_at: string;
  employees: {
    full_name: string;
    avatar_url: string | null;
    position: string | null;
  };
}

const ServiceTrips = () => {
  const { user, userRole } = useAuth();
  const [trips, setTrips] = useState<PersonalTrip[]>([]);
  const [managers, setManagers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const canManage = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    fetchTrips();
    fetchManagers();
  }, []);

  const fetchManagers = async () => {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('id, full_name, position')
        .eq('status', 'active')
        .order('full_name');

      if (error) throw error;
      setManagers(data || []);
    } catch (error: any) {
      toast.error('მენეჯერების ჩატვირთვა ვერ მოხერხდა');
    }
  };

  const fetchTrips = async () => {
    try {
      const { data, error } = await (supabase as any)
        .from('service_trips')
        .select(`
          *,
          employees:employee_id (full_name, avatar_url, position)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTrips(data || []);
    } catch (error: any) {
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const { data: currentEmployee, error: empError } = await (supabase as any)
        .from('employees')
        .select('id')
        .eq('email', user?.email)
        .maybeSingle();

      if (empError) throw empError;

      let employeeId = currentEmployee?.id;

      if (!employeeId) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('full_name')
          .eq('id', user?.id)
          .maybeSingle();

        const { data: newEmp, error: createEmpErr } = await supabase
          .from('employees')
          .insert([{
            full_name: profile?.full_name || user?.email || 'მომხმარებელი',
            email: user?.email as string,
            position: 'სპეციალისტი',
            hire_date: new Date().toISOString().slice(0, 10),
            status: 'active',
            created_by: user?.id,
          }])
          .select('id')
          .single();

        if (createEmpErr) throw createEmpErr;
        employeeId = newEmp.id;
      }

      const payload = {
        employee_id: employeeId,
        manager_id: formData.get('manager_id') as string,
        destination: formData.get('destination') as string,
        purpose: formData.get('purpose') as string,
        start_date: formData.get('start_date') as string,
        end_date: formData.get('end_date') as string,
        start_time: formData.get('start_time') as string,
        end_time: formData.get('end_time') as string,
        status: 'pending',
      };

      const { error } = await (supabase as any)
        .from('service_trips')
        .insert([payload]);

      if (error) throw error;

      toast.success('პირადი გასვლის მოთხოვნა წარმატებით გაიგზავნა');
      setIsDialogOpen(false);
      fetchTrips();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      toast.error('მოთხოვნის გაგზავნა ვერ მოხერხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApprove = async (id: string) => {
    try {
      const { error } = await supabase
        .from('service_trips')
        .update({ 
          status: 'approved',
          approved_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;

      toast.success('მოთხოვნა დამტკიცდა');
      fetchTrips();
    } catch (error: any) {
      toast.error('დამტკიცება ვერ მოხერხდა');
    }
  };

  const handleReject = async (id: string) => {
    try {
      const { error } = await supabase
        .from('service_trips')
        .update({ 
          status: 'rejected',
          rejection_reason: 'უარყოფილია'
        })
        .eq('id', id);

      if (error) throw error;

      toast.success('მოთხოვნა უარყოფილია');
      fetchTrips();
    } catch (error: any) {
      toast.error('უარყოფა ვერ მოხერხდა');
    }
  };

  const filteredTrips = trips.filter((trip) =>
    trip.employees?.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    trip.destination?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-500';
      case 'rejected':
        return 'bg-red-500';
      default:
        return 'bg-yellow-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'approved':
        return 'დამტკიცებული';
      case 'rejected':
        return 'უარყოფილი';
      default:
        return 'განხილვაში';
    }
  };

  const handleExport = () => {
    const exportData = filteredTrips.map(trip => ({
      'თანამშრომელი': trip.employees?.full_name || '',
      'პოზიცია': trip.employees?.position || '',
      'დანიშნულების ადგილი': trip.destination,
      'მიზანი': trip.purpose || '',
      'დაწყების თარიღი': formatters.shortDate(trip.start_date),
      'დამთავრების თარიღი': formatters.shortDate(trip.end_date),
      'დაწყების დრო': trip.start_time || '',
      'დამთავრების დრო': trip.end_time || '',
      'სტატუსი': getStatusText(trip.status),
      'შექმნის თარიღი': formatters.shortDate(trip.created_at),
    }));

    exportToExcel(exportData, 'პირადი_გასვლები');
    toast.success('მონაცემები წარმატებით ექსპორტირდა Excel ფაილში');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">იტვირთება...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">პირადი გასვლები</h1>
            <p className="text-muted-foreground mt-1">
              პირადი გასვლების მოთხოვნების მართვა
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={handleExport} variant="outline">
              <FileDown className="h-4 w-4 mr-2" />
              Excel Export
            </Button>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  ახალი მოთხოვნა
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>პირადი გასვლის მოთხოვნა</DialogTitle>
                  <DialogDescription>
                    შეავსეთ ყველა საჭირო ველი პირადი გასვლის მოთხოვნის გასაგზავნად
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="destination">დანიშნულების ადგილი *</Label>
                      <Input
                        id="destination"
                        name="destination"
                        placeholder="მაგ: თბილისი"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="manager_id">მენეჯერი *</Label>
                      <Select name="manager_id" required>
                        <SelectTrigger>
                          <SelectValue placeholder="აირჩიეთ მენეჯერი" />
                        </SelectTrigger>
                        <SelectContent>
                          {managers.map((manager) => (
                            <SelectItem key={manager.id} value={manager.id}>
                              {manager.full_name} - {manager.position}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="start_date">დაწყების თარიღი *</Label>
                      <Input
                        id="start_date"
                        name="start_date"
                        type="date"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="end_date">დამთავრების თარიღი *</Label>
                      <Input
                        id="end_date"
                        name="end_date"
                        type="date"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="start_time">დაწყების დრო</Label>
                      <Input
                        id="start_time"
                        name="start_time"
                        type="time"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="end_time">დამთავრების დრო</Label>
                      <Input
                        id="end_time"
                        name="end_time"
                        type="time"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="purpose">მიზანი</Label>
                    <Textarea
                      id="purpose"
                      name="purpose"
                      placeholder="აღწერეთ გასვლის მიზანი"
                      rows={3}
                    />
                  </div>

                  <DialogFooter>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsDialogOpen(false)}
                      disabled={isLoading}
                    >
                      გაუქმება
                    </Button>
                    <Button type="submit" disabled={isLoading}>
                      {isLoading ? 'იგზავნება...' : 'გაგზავნა'}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="ძებნა თანამშრომლის ან დანიშნულების მიხედვით..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {filteredTrips.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-10">
              <MapPin className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">მოთხოვნები არ მოიძებნა</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {filteredTrips.map((trip) => (
              <Card key={trip.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <Avatar>
                        <AvatarImage src={trip.employees?.avatar_url || ''} />
                        <AvatarFallback>
                          {trip.employees?.full_name?.charAt(0) || 'T'}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">
                          {trip.employees?.full_name || 'უცნობი თანამშრომელი'}
                        </CardTitle>
                        <CardDescription>
                          {trip.employees?.position || 'პოზიცია არ არის მითითებული'}
                        </CardDescription>
                      </div>
                    </div>
                    <Badge className={getStatusColor(trip.status)}>
                      {getStatusText(trip.status)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">დანიშნულების ადგილი</p>
                      <p className="font-medium flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        {trip.destination}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">მიზანი</p>
                      <p className="font-medium">{trip.purpose || 'არ არის მითითებული'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">დაწყების თარიღი</p>
                      <p className="font-medium">{formatters.shortDate(trip.start_date)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">დამთავრების თარიღი</p>
                      <p className="font-medium">{formatters.shortDate(trip.end_date)}</p>
                    </div>
                    {trip.start_time && (
                      <div>
                        <p className="text-sm text-muted-foreground">დაწყების დრო</p>
                        <p className="font-medium">{trip.start_time}</p>
                      </div>
                    )}
                    {trip.end_time && (
                      <div>
                        <p className="text-sm text-muted-foreground">დამთავრების დრო</p>
                        <p className="font-medium">{trip.end_time}</p>
                      </div>
                    )}
                    <div>
                      <p className="text-sm text-muted-foreground">შექმნის თარიღი</p>
                      <p className="font-medium">{formatters.shortDate(trip.created_at)}</p>
                    </div>
                  </div>
                  {canManage && trip.status === 'pending' && (
                    <div className="flex gap-2 mt-4">
                      <Button
                        size="sm"
                        onClick={() => handleApprove(trip.id)}
                        className="flex-1"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        დამტკიცება
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleReject(trip.id)}
                        className="flex-1"
                      >
                        <XCircle className="h-4 w-4 mr-2" />
                        უარყოფა
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
    </div>
  );
};

export default ServiceTrips;
