import { useState, useEffect } from "react";
import { Plus, Search, Check, X, Clock, Calendar, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { ka } from "date-fns/locale";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { ResponsiveTable, MobileCard, MobileCardRow } from "@/components/ResponsiveTable";
import { useIsMobile } from "@/hooks/use-mobile";

interface OvertimeRequest {
  id: string;
  employee_id: string;
  user_id: string;
  manager_id: string | null;
  work_date: string;
  start_time: string;
  end_time: string;
  hours: number;
  overtime_type: string;
  reason: string | null;
  status: string;
  approved_by: string | null;
  approved_at: string | null;
  created_at: string;
  employees: {
    full_name: string;
    position: string;
  } | null;
}

export default function OvertimeRequests() {
  const { user, userRole } = useAuth();
  const [requests, setRequests] = useState<OvertimeRequest[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState<any>(null);
  const isMobile = useIsMobile();
  
  const [formData, setFormData] = useState({
    employee_id: "",
    work_date: "",
    start_time: "",
    end_time: "",
    overtime_type: "weekday",
    reason: "",
  });

  const canManage = userRole === 'admin' || userRole === 'hr_manager' || userRole === 'department_manager';

  useEffect(() => {
    if (user) {
      fetchRequests();
      fetchEmployees();
      fetchCurrentEmployee();
    }
  }, [user, canManage]);

  const fetchCurrentEmployee = async () => {
    if (!user?.email) return;
    
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('*')
        .eq('email', user.email)
        .single();
      
      if (error) throw error;
      setCurrentEmployee(data);
      setFormData(prev => ({ ...prev, employee_id: data.id }));
    } catch (error: any) {
      console.error('Error fetching current employee:', error);
    }
  };

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('id, full_name, position, email')
        .eq('status', 'active');
      
      if (error) throw error;
      setEmployees(data || []);
    } catch (error: any) {
      console.error('Error fetching employees:', error);
    }
  };

  const fetchRequests = async () => {
    try {
      setIsLoading(true);
      
      let query = supabase
        .from('overtime_requests' as any)
        .select(`
          *,
          employees:employee_id (
            full_name,
            position
          )
        `)
        .order('created_at', { ascending: false });

      if (!canManage && user?.id) {
        query = query.eq('user_id', user.id);
      }

      const { data, error } = await query;


      if (error) throw error;
      setRequests((data as any) || []);
    } catch (error: any) {
      console.error('Error fetching overtime requests:', error);
      toast.error('ზეგანაკვეთური მოთხოვნების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const calculateHours = (startTime: string, endTime: string): number => {
    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);
    
    const startMinutes = startHour * 60 + startMin;
    const endMinutes = endHour * 60 + endMin;
    
    return Math.round((endMinutes - startMinutes) / 60 * 100) / 100;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error('გთხოვთ გაიაროთ ავტორიზაცია');
      return;
    }

    if (!formData.employee_id || !formData.work_date || !formData.start_time || !formData.end_time) {
      toast.error('გთხოვთ შეავსოთ ყველა სავალდებულო ველი');
      return;
    }

    const hours = calculateHours(formData.start_time, formData.end_time);
    
    if (hours <= 0) {
      toast.error('დასრულების დრო უნდა იყოს დაწყების დროზე მეტი');
      return;
    }

    try {
      setIsLoading(true);

      // Manager registering overtime for another employee: must match programmatic attendance
      const isManagerForOther = canManage && formData.employee_id !== currentEmployee?.id;
      if (isManagerForOther) {
        const { data: att, error: attErr } = await supabase
          .from('attendance')
          .select('check_in, check_out')
          .eq('employee_id', formData.employee_id)
          .eq('date', formData.work_date)
          .maybeSingle();

        if (attErr) {
          console.error('Attendance lookup error:', attErr);
          toast.error('დასწრების მონაცემების შემოწმება ვერ მოხერხდა');
          setIsLoading(false);
          return;
        }

        if (!att || !att.check_in || !att.check_out) {
          toast.error('შეცდომა: მითითებულ თარიღში თანამშრომლის პროგრამული გატარება (შემოსვლა/გასვლა) ვერ მოიძებნა');
          setIsLoading(false);
          return;
        }

        const toMin = (t: string) => {
          const [h, m] = t.split(':').map(Number);
          return h * 60 + m;
        };
        const TOLERANCE = 15; // minutes
        const reqStart = toMin(formData.start_time);
        const reqEnd = toMin(formData.end_time);
        const attStart = toMin(att.check_in);
        const attEnd = toMin(att.check_out);

        if (reqStart < attStart - TOLERANCE || reqEnd > attEnd + TOLERANCE) {
          toast.error(
            `შეცდომა: მითითებული დრო (${formData.start_time}–${formData.end_time}) არ ემთხვევა თანამშრომლის პროგრამულ გატარებას (${att.check_in.slice(0,5)}–${att.check_out.slice(0,5)})`
          );
          setIsLoading(false);
          return;
        }
      }

      const { error } = await supabase
        .from('overtime_requests' as any)
        .insert([{
          employee_id: formData.employee_id,
          user_id: user.id,
          work_date: formData.work_date,
          start_time: formData.start_time,
          end_time: formData.end_time,
          hours: hours,
          overtime_type: formData.overtime_type,
          reason: formData.reason || null,
        }]);

      if (error) throw error;

      toast.success('ზეგანაკვეთური მოთხოვნა წარმატებით შეიქმნა');
      setIsDialogOpen(false);
      setFormData({
        employee_id: currentEmployee?.id || "",
        work_date: "",
        start_time: "",
        end_time: "",
        overtime_type: "weekday",
        reason: "",
      });
      fetchRequests();
    } catch (error: any) {
      console.error('Error creating overtime request:', error);
      toast.error('ზეგანაკვეთური მოთხოვნის შექმნა ვერ მოხერხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApprove = async (requestId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('overtime_requests' as any)
        .update({
          status: 'approved',
          approved_by: user.id,
          approved_at: new Date().toISOString(),
        })
        .eq('id', requestId);

      if (error) throw error;

      toast.success('მოთხოვნა დამტკიცდა');
      fetchRequests();
    } catch (error: any) {
      console.error('Error approving request:', error);
      toast.error('დამტკიცება ვერ მოხერხდა');
    }
  };

  const handleReject = async (requestId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('overtime_requests' as any)
        .update({
          status: 'rejected',
          approved_by: user.id,
          approved_at: new Date().toISOString(),
        })
        .eq('id', requestId);

      if (error) throw error;

      toast.success('მოთხოვნა უარყოფილია');
      fetchRequests();
    } catch (error: any) {
      console.error('Error rejecting request:', error);
      toast.error('უარყოფა ვერ მოხერხდა');
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: { label: 'მოლოდინში', variant: 'secondary' as const },
      approved: { label: 'დამტკიცებული', variant: 'default' as const },
      rejected: { label: 'უარყოფილი', variant: 'destructive' as const },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const getOvertimeTypeBadge = (type: string) => {
    const typeConfig = {
      weekday: { label: 'სამუშაო დღე', color: 'bg-blue-100 text-blue-800' },
      weekend: { label: 'შაბათ-კვირა', color: 'bg-purple-100 text-purple-800' },
      holiday: { label: 'დასვენების დღე', color: 'bg-red-100 text-red-800' },
    };

    const config = typeConfig[type as keyof typeof typeConfig] || typeConfig.weekday;
    return <span className={`px-2 py-1 rounded-full text-xs ${config.color}`}>{config.label}</span>;
  };

  const filteredRequests = requests.filter((request) => {
    const name = request.employees?.full_name?.toLowerCase() || "";
    const position = request.employees?.position?.toLowerCase() || "";
    return name.includes(searchQuery.toLowerCase()) || position.includes(searchQuery.toLowerCase());
  });

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">ზეგანაკვეთური სამუშაო</h1>
          <p className="text-muted-foreground mt-1">
            ზეგანაკვეთური სამუშაოს მოთხოვნების მართვა
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>

          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              ახალი მოთხოვნა
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>ზეგანაკვეთური სამუშაოს მოთხოვნა</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              {canManage && (
                <div>
                  <Label htmlFor="employee_id">თანამშრომელი *</Label>
                  <Select
                    value={formData.employee_id}
                    onValueChange={(value) => setFormData({ ...formData, employee_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="აირჩიეთ თანამშრომელი" />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.full_name} - {emp.position}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div>
                <Label htmlFor="work_date">სამუშაო თარიღი *</Label>
                <Input
                  id="work_date"
                  type="date"
                  value={formData.work_date}
                  onChange={(e) => setFormData({ ...formData, work_date: e.target.value })}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="start_time">დაწყების დრო *</Label>
                  <Input
                    id="start_time"
                    type="time"
                    value={formData.start_time}
                    onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="end_time">დასრულების დრო *</Label>
                  <Input
                    id="end_time"
                    type="time"
                    value={formData.end_time}
                    onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="overtime_type">ზეგანაკვეთის ტიპი *</Label>
                <Select
                  value={formData.overtime_type}
                  onValueChange={(value) => setFormData({ ...formData, overtime_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekday">სამუშაო დღე</SelectItem>
                    <SelectItem value="weekend">შაბათ-კვირა</SelectItem>
                    <SelectItem value="holiday">დასვენების დღე</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="reason">მიზეზი</Label>
                <Textarea
                  id="reason"
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  placeholder="აღწერეთ ზეგანაკვეთის მიზეზი..."
                  rows={3}
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  გაუქმება
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? 'იტვირთება...' : 'გაგზავნა'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-border/50 bg-muted/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-primary mt-0.5 shrink-0" />
            <div className="space-y-1 text-sm text-muted-foreground">
              <p className="font-medium text-foreground">რა არის წარმოდგენილი ამ გვერდზე?</p>
              <p>ეს გვერდი გამოიყენება ზეგანაკვეთური სამუშაოს მოთხოვნების შესაქმნელად და სამართავად:</p>
              <p><strong>ახალი მოთხოვნა</strong> - თანამშრომელი ან მენეჯერი ქმნის ზეგანაკვეთურის მოთხოვნას თარიღის, დროისა და მიზეზის მითითებით</p>
              <p><strong>დამტკიცება / უარყოფა</strong> - მენეჯერი ან HR ამტკიცებს ან უარყოფს მოთხოვნას</p>
              <p><strong>⏰ საათები</strong> - ნაჩვენებია ზეგანაკვეთური საათების რაოდენობა და ტიპი</p>
              <p><strong>ანაზღაურება</strong> - დამტკიცებული ზეგანაკვეთური ავტომატურად აისახება ხელფასის გამოთვლაში (×1.5 სტანდარტული, ×2.0 უქმე დღეები)</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            ზეგანაკვეთური მოთხოვნები
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="ძიება თანამშრომლის სახელით..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <ResponsiveTable
            data={filteredRequests}
            mobileCards={(request: OvertimeRequest, index: number) => (
              <MobileCard key={request.id}>
                <MobileCardRow 
                  label="თანამშრომელი" 
                  value={
                    <div>
                      <div className="font-medium">{request.employees?.full_name}</div>
                      <div className="text-xs text-muted-foreground">{request.employees?.position}</div>
                    </div>
                  } 
                />
                <MobileCardRow 
                  label="თარიღი" 
                  value={format(new Date(request.work_date), 'dd MMMM yyyy', { locale: ka })} 
                />
                <MobileCardRow 
                  label="დრო" 
                  value={`${request.start_time} - ${request.end_time}`} 
                />
                <MobileCardRow 
                  label="საათები" 
                  value={`${request.hours} სთ`} 
                />
                <MobileCardRow 
                  label="ტიპი" 
                  value={getOvertimeTypeBadge(request.overtime_type)} 
                />
                <MobileCardRow 
                  label="სტატუსი" 
                  value={getStatusBadge(request.status)} 
                />
                {canManage && request.status === 'pending' && (
                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      variant="default"
                      onClick={() => handleApprove(request.id)}
                      className="flex-1"
                    >
                      <Check className="h-4 w-4 mr-1" />
                      დამტკიცება
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleReject(request.id)}
                      className="flex-1"
                    >
                      <X className="h-4 w-4 mr-1" />
                      უარყოფა
                    </Button>
                  </div>
                )}
              </MobileCard>
            )}
          >
            <TableHeader>
              <TableRow>
                <TableHead>თანამშრომელი</TableHead>
                <TableHead>თარიღი</TableHead>
                <TableHead>დრო</TableHead>
                <TableHead>საათები</TableHead>
                <TableHead>ტიპი</TableHead>
                <TableHead>სტატუსი</TableHead>
                {canManage && <TableHead>მოქმედებები</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={canManage ? 7 : 6} className="text-center">
                    იტვირთება...
                  </TableCell>
                </TableRow>
              ) : filteredRequests.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={canManage ? 7 : 6} className="text-center text-muted-foreground">
                    მოთხოვნები არ მოიძებნა
                  </TableCell>
                </TableRow>
              ) : (
                filteredRequests.map((request) => (
                  <TableRow key={request.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{request.employees?.full_name}</div>
                        <div className="text-sm text-muted-foreground">{request.employees?.position}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {format(new Date(request.work_date), 'dd MMMM yyyy', { locale: ka })}
                    </TableCell>
                    <TableCell>
                      {request.start_time} - {request.end_time}
                    </TableCell>
                    <TableCell>{request.hours} სთ</TableCell>
                    <TableCell>{getOvertimeTypeBadge(request.overtime_type)}</TableCell>
                    <TableCell>{getStatusBadge(request.status)}</TableCell>
                    {canManage && (
                      <TableCell>
                        {request.status === 'pending' && (
                          <div className="flex flex-wrap gap-2">
                            <Button
                              size="sm"
                              variant="default"
                              onClick={() => handleApprove(request.id)}
                            >
                              <Check className="h-4 w-4 mr-1" />
                              დამტკიცება
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleReject(request.id)}
                            >
                              <X className="h-4 w-4 mr-1" />
                              უარყოფა
                            </Button>
                          </div>
                        )}
                      </TableCell>
                    )}
                  </TableRow>
                ))
              )}
            </TableBody>
          </ResponsiveTable>
        </CardContent>
      </Card>
    </div>
  );
}
