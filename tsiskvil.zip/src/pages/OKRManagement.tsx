import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { Target, TrendingUp, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface KeyResult {
  id: string;
  title: string;
  metric_type: string;
  target_value: number;
  current_value: number;
  unit: string;
  status: string;
}

interface Objective {
  id: string;
  title: string;
  description: string;
  objective_type: string;
  time_period: string;
  fiscal_year: number;
  start_date: string;
  end_date: string;
  status: string;
  progress: number;
  key_results: KeyResult[];
}

export default function OKRManagement() {
  const [objectives, setObjectives] = useState<Objective[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchObjectives();
  }, []);

  const fetchObjectives = async () => {
    const { data, error } = await supabase
      .from("objectives" as any)
      .select(`
        *,
        key_results (*)
      `)
      .order("created_at", { ascending: false });
    
    if (error) {
      toast.error("შეცდომა მიზნების ჩატვირთვისას");
    } else {
      setObjectives(data as any || []);
    }
    setLoading(false);
  };

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: "default" | "secondary" | "destructive" | "outline" } = {
      on_track: "default",
      at_risk: "secondary",
      behind: "destructive",
      completed: "outline"
    };
    return <Badge variant={variants[status] || "outline"}>{status}</Badge>;
  };

  const calculateProgress = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  return (
    <>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">OKR / KPI მართვა</h1>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            ახალი მიზანი
          </Button>
        </div>

        <div className="grid gap-6">
          {objectives.length === 0 ? (
            <Card className="p-8 text-center">
              <Target className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">მიზნები არ მოიძებნა</p>
            </Card>
          ) : (
            objectives.map((objective) => (
              <Card key={objective.id} className="p-6 space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <Target className="h-5 w-5 text-primary" />
                      <h3 className="text-xl font-semibold">{objective.title}</h3>
                      {getStatusBadge(objective.status)}
                    </div>
                    <p className="text-muted-foreground mb-4">{objective.description}</p>
                    <div className="flex gap-4 text-sm text-muted-foreground">
                      <span>ტიპი: {objective.objective_type}</span>
                      <span>პერიოდი: {objective.time_period}</span>
                      <span>წელი: {objective.fiscal_year}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent animate-fade-in">{objective.progress}%</div>
                    <Progress value={objective.progress} className="w-32 mt-3 h-3" />
                  </div>
                </div>

                {objective.key_results && objective.key_results.length > 0 && (
                  <div className="space-y-3 mt-4 pt-4 border-t">
                    <h4 className="font-semibold flex items-center gap-2">
                      <TrendingUp className="h-4 w-4" />
                      Key Results
                    </h4>
                    {objective.key_results.map((kr) => (
                      <div key={kr.id} className="space-y-2 p-4 bg-muted/50 rounded-lg">
                        <div className="flex justify-between items-start">
                          <p className="font-medium">{kr.title}</p>
                          {getStatusBadge(kr.status)}
                        </div>
                        <div className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">პროგრესი</span>
                            <span className="font-medium">
                              {kr.current_value} / {kr.target_value} {kr.unit}
                            </span>
                          </div>
                          <Progress value={calculateProgress(kr.current_value, kr.target_value)} />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            ))
          )}
        </div>
      </div>
    </>
  );
}