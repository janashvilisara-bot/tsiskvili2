import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ArrowRightLeft, Plus, Building2 } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

interface Branch {
  id: string;
  name: string;
  code: string;
}
interface Employee {
  id: string;
  full_name: string;
  branch_id: string | null;
}
interface Transfer {
  id: string;
  employee_id: string;
  from_branch_id: string | null;
  to_branch_id: string;
  transfer_date: string;
  reason: string | null;
  notes: string | null;
  created_at: string;
  employees?: { full_name: string } | null;
  from_branch?: { name: string } | null;
  to_branch?: { name: string } | null;
}

export default function BranchTransfers() {
  const { userRole } = useAuth();
  const canManage = userRole === "admin" || userRole === "hr_manager";

  const [branches, setBranches] = useState<Branch[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // form state
  const [employeeId, setEmployeeId] = useState("");
  const [toBranchId, setToBranchId] = useState("");
  const [transferDate, setTransferDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [reason, setReason] = useState("");
  const [notes, setNotes] = useState("");

  const loadAll = async () => {
    setLoading(true);
    try {
      const [{ data: br }, { data: emp }, { data: tr }] = await Promise.all([
        supabase
          .from("branches")
          .select("id, name, code")
          .eq("is_active", true)
          .order("name"),
        supabase
          .from("employees")
          .select("id, full_name, branch_id")
          .eq("status", "active")
          .is("deleted_at", null)
          .order("full_name"),
        supabase
          .from("branch_transfers")
          .select(
            "id, employee_id, from_branch_id, to_branch_id, transfer_date, reason, notes, created_at, employees(full_name), from_branch:branches!branch_transfers_from_branch_id_fkey(name), to_branch:branches!branch_transfers_to_branch_id_fkey(name)"
          )
          .order("created_at", { ascending: false })
          .limit(100),
      ]);
      setBranches((br as Branch[]) || []);
      setEmployees((emp as Employee[]) || []);
      setTransfers((tr as any) || []);
    } catch (e) {
      toast.error("მონაცემების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const reset = () => {
    setEmployeeId("");
    setToBranchId("");
    setTransferDate(new Date().toISOString().split("T")[0]);
    setReason("");
    setNotes("");
  };

  const submit = async () => {
    if (!employeeId || !toBranchId) {
      toast.error("აირჩიეთ თანამშრომელი და ფილიალი");
      return;
    }
    const emp = employees.find((e) => e.id === employeeId);
    if (emp && emp.branch_id === toBranchId) {
      toast.error("თანამშრომელი უკვე ამ ფილიალშია");
      return;
    }
    setSubmitting(true);
    try {
      const { error } = await supabase.from("branch_transfers").insert({
        employee_id: employeeId,
        from_branch_id: emp?.branch_id ?? null,
        to_branch_id: toBranchId,
        transfer_date: transferDate,
        reason: reason || null,
        notes: notes || null,
      } as any);
      if (error) throw error;
      toast.success("გადაყვანა შესრულდა");
      setDialogOpen(false);
      reset();
      loadAll();
    } catch (e: any) {
      toast.error("გადაყვანა ვერ შესრულდა");
    } finally {
      setSubmitting(false);
    }
  };

  if (!canManage) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-10 text-center text-muted-foreground">
            ამ გვერდის ნახვის უფლება არ გაქვთ
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <ArrowRightLeft className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">ფილიალთაშორის გადაყვანა</h1>
            <p className="text-sm text-muted-foreground">
              თანამშრომლების გადაყვანის ისტორია და ახალი გადაყვანის ინიცირება
            </p>
          </div>
        </div>
        <Button onClick={() => setDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" /> ახალი გადაყვანა
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            გადაყვანების ისტორია ({transfers.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">
              იტვირთება...
            </div>
          ) : transfers.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <Building2 className="h-10 w-10 mx-auto mb-2 opacity-40" />
              ჯერ არ მომხდარა გადაყვანა
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>თარიღი</TableHead>
                    <TableHead>თანამშრომელი</TableHead>
                    <TableHead>საიდან</TableHead>
                    <TableHead>სად</TableHead>
                    <TableHead>მიზეზი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transfers.map((t) => (
                    <TableRow key={t.id}>
                      <TableCell className="whitespace-nowrap text-sm">
                        {format(new Date(t.transfer_date), "yyyy-MM-dd")}
                      </TableCell>
                      <TableCell className="font-medium">
                        {t.employees?.full_name || "-"}
                      </TableCell>
                      <TableCell>
                        {t.from_branch?.name ? (
                          <Badge variant="outline">{t.from_branch.name}</Badge>
                        ) : (
                          <span className="text-muted-foreground text-xs">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge>{t.to_branch?.name || "-"}</Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-[260px] truncate">
                        {t.reason || "-"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>ახალი გადაყვანა</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>თანამშრომელი *</Label>
              <Select value={employeeId} onValueChange={setEmployeeId}>
                <SelectTrigger>
                  <SelectValue placeholder="აირჩიეთ თანამშრომელი" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((e) => (
                    <SelectItem key={e.id} value={e.id}>
                      {e.full_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>ფილიალი (სად) *</Label>
              <Select value={toBranchId} onValueChange={setToBranchId}>
                <SelectTrigger>
                  <SelectValue placeholder="აირჩიეთ ფილიალი" />
                </SelectTrigger>
                <SelectContent>
                  {branches.map((b) => (
                    <SelectItem key={b.id} value={b.id}>
                      {b.name} ({b.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>გადაყვანის თარიღი</Label>
              <Input
                type="date"
                value={transferDate}
                onChange={(e) => setTransferDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>მიზეზი</Label>
              <Input
                placeholder="მაგ: დაწინაურება, რეორგანიზაცია"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>დამატებითი შენიშვნა</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              disabled={submitting}
            >
              გაუქმება
            </Button>
            <Button onClick={submit} disabled={submitting}>
              {submitting ? "მიმდინარეობს..." : "გადაყვანა"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
