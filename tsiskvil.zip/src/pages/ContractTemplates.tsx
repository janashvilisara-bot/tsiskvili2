import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { Plus, Edit, Trash2, FileText, Eye, Download, FileDown, ChevronDown } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { exportContractAppendix } from "@/lib/exportContractAppendix";
import { exportMasterAgreement } from "@/lib/contracts/exportMasterAgreement";
import { exportAppendixTariffs } from "@/lib/contracts/exportAppendixTariffs";
import { exportAppendixSLA } from "@/lib/contracts/exportAppendixSLA";
import { exportDPA } from "@/lib/contracts/exportDPA";
import { exportNDA } from "@/lib/contracts/exportNDA";
import { exportSecurityCertificate } from "@/lib/contracts/exportSecurityCertificate";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";

interface ContractTemplate {
  id: string;
  name: string;
  contract_type: string;
  template_content: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
}

const ContractTemplates = () => {
  const { userRole } = useAuth();
  const [templates, setTemplates] = useState<ContractTemplate[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<ContractTemplate | null>(null);
  const [previewTemplate, setPreviewTemplate] = useState<ContractTemplate | null>(null);

  const canManage = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    if (canManage) {
      fetchTemplates();
    }
  }, [canManage]);

  const fetchTemplates = async () => {
    // @ts-ignore - contract_templates table exists in database
    const { data, error } = await supabase
      // @ts-ignore
      .from('contract_templates')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      toast.error('შეცდომა: ' + error.message);
    } else {
      // @ts-ignore
      setTemplates(data || []);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);

    const templateData = {
      name: formData.get('name') as string,
      contract_type: formData.get('contract_type') as string,
      template_content: formData.get('template_content') as string,
      description: formData.get('description') as string || null,
      is_active: true,
    };

    if (editingTemplate) {
      // @ts-ignore - contract_templates table exists in database
      const { error } = await supabase
        // @ts-ignore
        .from('contract_templates')
        .update(templateData)
        .eq('id', editingTemplate.id);

      if (error) {
        toast.error('შეცდომა: ' + error.message);
      } else {
        toast.success('შაბლონი განახლდა');
        fetchTemplates();
        setIsDialogOpen(false);
        setEditingTemplate(null);
      }
    } else {
      // @ts-ignore - contract_templates table exists in database
      const { error } = await supabase
        // @ts-ignore
        .from('contract_templates')
        .insert([templateData]);

      if (error) {
        toast.error('შეცდომა: ' + error.message);
      } else {
        toast.success('შაბლონი დაემატა');
        fetchTemplates();
        setIsDialogOpen(false);
      }
    }
  };

  const handleToggleActive = async (template: ContractTemplate) => {
    // @ts-ignore - contract_templates table exists in database
    const { error } = await supabase
      // @ts-ignore
      .from('contract_templates')
      .update({ is_active: !template.is_active })
      .eq('id', template.id);

    if (error) {
      toast.error('შეცდომა: ' + error.message);
    } else {
      toast.success(template.is_active ? 'შაბლონი დეაქტივირდა' : 'შაბლონი აქტივირდა');
      fetchTemplates();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('დარწმუნებული ხართ რომ გსურთ შაბლონის წაშლა?')) return;

    // @ts-ignore - contract_templates table exists in database
    const { error } = await supabase
      // @ts-ignore
      .from('contract_templates')
      .delete()
      .eq('id', id);

    if (error) {
      toast.error('შეცდომა: ' + error.message);
    } else {
      toast.success('შაბლონი წაიშალა');
      fetchTemplates();
    }
  };

  const getContractTypeText = (type: string) => {
    const types: Record<string, string> = {
      permanent: 'უვადო',
      fixed_term: 'ვადიანი',
      probation: 'გამოსაცდელი',
      freelance: 'ფრილანსერი',
      intern: 'სტაჟიორი',
      service: 'მომსახურება',
    };
    return types[type] || type;
  };

  if (!canManage) {
    return (
      <>
        <div className="p-8 text-center">
          <p className="text-muted-foreground">თქვენ არ გაქვთ წვდომა ამ გვერდზე</p>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="p-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">ხელშეკრულების შაბლონები</h1>
            <p className="text-muted-foreground">მართეთ ხელშეკრულების შაბლონები და ჩამოტვირთეთ იურიდიული დოკუმენტები</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={(open) => {
              setIsDialogOpen(open);
              if (!open) setEditingTemplate(null);
            }}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  ახალი შაბლონი
                </Button>
              </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingTemplate ? 'შაბლონის რედაქტირება' : 'ახალი შაბლონი'}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">შაბლონის სახელი</Label>
                    <Input
                      id="name"
                      name="name"
                      defaultValue={editingTemplate?.name}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contract_type">ხელშეკრულების ტიპი</Label>
                    <Select name="contract_type" defaultValue={editingTemplate?.contract_type} required>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="permanent">უვადო</SelectItem>
                        <SelectItem value="fixed_term">ვადიანი</SelectItem>
                        <SelectItem value="probation">გამოსაცდელი</SelectItem>
                        <SelectItem value="freelance">ფრილანსერი</SelectItem>
                        <SelectItem value="intern">სტაჟიორი</SelectItem>
                        <SelectItem value="service">მომსახურება</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">აღწერა</Label>
                  <Textarea
                    id="description"
                    name="description"
                    defaultValue={editingTemplate?.description || ''}
                    rows={2}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="template_content">შაბლონის შინაარსი</Label>
                  <div className="text-sm text-muted-foreground mb-2">
                    გამოიყენეთ პლეისჰოლდერები: {'{employee_name}'}, {'{position}'}, {'{salary}'}, 
                    {'{start_date}'}, {'{end_date}'}, {'{additional_terms}'}, {'{contract_number}'}, {'{current_date}'}
                  </div>
                  <Textarea
                    id="template_content"
                    name="template_content"
                    defaultValue={editingTemplate?.template_content}
                    rows={20}
                    className="font-mono text-sm"
                    required
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => {
                    setIsDialogOpen(false);
                    setEditingTemplate(null);
                  }}>
                    გაუქმება
                  </Button>
                  <Button type="submit">
                    {editingTemplate ? 'განახლება' : 'შენახვა'}
                  </Button>
                </div>
              </form>
            </DialogContent>
           </Dialog>
        </div>

        {/* Contract Documents Download Section - Collapsible */}
        <Collapsible>
          <Card>
            <CardHeader className="cursor-pointer">
              <CollapsibleTrigger className="flex items-center justify-between w-full">
                <CardTitle className="flex items-center gap-2">
                  <FileDown className="h-5 w-5" />
                  იურიდიული დოკუმენტების შაბლონები (Word)
                </CardTitle>
                <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform duration-200" />
              </CollapsibleTrigger>
            </CardHeader>
            <CollapsibleContent>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  <Button variant="outline" className="justify-start h-auto py-3" onClick={() => exportMasterAgreement()}>
                    <Download className="h-4 w-4 mr-2 shrink-0" />
                    <div className="text-left">
                      <div className="font-medium">გენერალური ხელშეკრულება</div>
                      <div className="text-xs text-muted-foreground">Master Service Agreement</div>
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start h-auto py-3" onClick={() => exportContractAppendix()}>
                    <Download className="h-4 w-4 mr-2 shrink-0" />
                    <div className="text-left">
                      <div className="font-medium">დანართი #1 - სისტემის მახასიათებლები</div>
                      <div className="text-xs text-muted-foreground">System Features Appendix</div>
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start h-auto py-3" onClick={() => exportAppendixTariffs()}>
                    <Download className="h-4 w-4 mr-2 shrink-0" />
                    <div className="text-left">
                      <div className="font-medium">დანართი #2 - ტარიფები</div>
                      <div className="text-xs text-muted-foreground">Pricing & Payment Terms</div>
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start h-auto py-3" onClick={() => exportAppendixSLA()}>
                    <Download className="h-4 w-4 mr-2 shrink-0" />
                    <div className="text-left">
                      <div className="font-medium">დანართი #3 - SLA</div>
                      <div className="text-xs text-muted-foreground">Service Level Agreement</div>
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start h-auto py-3" onClick={() => exportDPA()}>
                    <Download className="h-4 w-4 mr-2 shrink-0" />
                    <div className="text-left">
                      <div className="font-medium">მონაცემთა დამუშავება (DPA)</div>
                      <div className="text-xs text-muted-foreground">Data Processing Agreement</div>
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start h-auto py-3" onClick={() => exportNDA()}>
                    <Download className="h-4 w-4 mr-2 shrink-0" />
                    <div className="text-left">
                      <div className="font-medium">კონფიდენციალურობა (NDA)</div>
                      <div className="text-xs text-muted-foreground">Non-Disclosure Agreement</div>
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start h-auto py-3 border-primary/30 bg-primary/5" onClick={() => exportSecurityCertificate()}>
                    <Download className="h-4 w-4 mr-2 shrink-0" />
                    <div className="text-left">
                      <div className="font-medium">უსაფრთხოების სერტიფიკატი</div>
                      <div className="text-xs text-muted-foreground">Security Compliance Certificate</div>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        <div className="grid gap-4">
          {templates.map((template) => (
            <Card key={template.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <CardTitle>{template.name}</CardTitle>
                      <Badge variant="outline">
                        {getContractTypeText(template.contract_type)}
                      </Badge>
                      {!template.is_active && (
                        <Badge variant="secondary">არააქტიური</Badge>
                      )}
                    </div>
                    {template.description && (
                      <p className="text-sm text-muted-foreground">{template.description}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor={`active-${template.id}`} className="text-sm">
                        აქტიური
                      </Label>
                      <Switch
                        id={`active-${template.id}`}
                        checked={template.is_active}
                        onCheckedChange={() => handleToggleActive(template)}
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setPreviewTemplate(template)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditingTemplate(template);
                        setIsDialogOpen(true);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(template.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
            </Card>
          ))}

          {templates.length === 0 && (
            <Card>
              <CardContent className="p-8 text-center">
                <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">შაბლონები არ მოიძებნა</p>
              </CardContent>
            </Card>
          )}
        </div>

        <Dialog open={!!previewTemplate} onOpenChange={(open) => !open && setPreviewTemplate(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{previewTemplate?.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="p-4 bg-muted rounded-md">
                <pre className="whitespace-pre-wrap text-sm">
                  {previewTemplate?.template_content}
                </pre>
              </div>
              <Button variant="outline" onClick={() => setPreviewTemplate(null)}>
                დახურვა
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default ContractTemplates;
