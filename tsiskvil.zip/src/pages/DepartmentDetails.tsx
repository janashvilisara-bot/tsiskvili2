import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowLeft, Building2, Users, DollarSign, TrendingUp, Phone, Mail, Briefcase } from "lucide-react";
import { ResponsiveTable, MobileCard, MobileCardRow } from "@/components/ResponsiveTable";
import { useIsMobile } from "@/hooks/use-mobile";
import { Pencil } from "lucide-react";
import { EditDepartmentDialog } from "@/components/org-structure/EditDepartmentDialog";
import { EditPositionDialog } from "@/components/org-structure/EditPositionDialog";

interface Department {
  id: string;
  name: string;
  name_en: string | null;
  parent_department_id: string | null;
  manager_id: string | null;
  budget: number | null;
  headcount_limit: number | null;
  description: string | null;
  is_active: boolean;
  manager?: {
    full_name: string;
    avatar_url: string | null;
    email: string;
    phone: string | null;
    position: string;
  };
}

interface Employee {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  position: string;
  avatar_url: string | null;
  status: string;
  hire_date: string;
}

interface SubDepartment {
  id: string;
  name: string;
  name_en: string | null;
  employee_count: number;
  manager?: {
    full_name: string;
  };
}

const DepartmentDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [department, setDepartment] = useState<Department | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [subDepartments, setSubDepartments] = useState<SubDepartment[]>([]);
  const [loading, setLoading] = useState(true);
  const [positions, setPositions] = useState<any[]>([]);
  const [allDepartments, setAllDepartments] = useState<{ id: string; name: string }[]>([]);
  const [allEmployees, setAllEmployees] = useState<{ id: string; full_name: string }[]>([]);
  const [editDeptOpen, setEditDeptOpen] = useState(false);
  const [editPos, setEditPos] = useState<any | null>(null);
  const [stats, setStats] = useState({
    totalEmployees: 0,
    activeEmployees: 0,
    avgSalary: 0,
    totalSalaries: 0,
  });

  useEffect(() => {
    if (id) {
      fetchDepartmentData();
    }
  }, [id]);

  const fetchDepartmentData = async () => {
    try {
      setLoading(true);

      // Fetch department details
      const { data: deptData, error: deptError } = await supabase
        .from('departments')
        .select(`
          *,
          manager:employees!manager_id(full_name, avatar_url, email, phone, position)
        `)
        .eq('id', id)
        .single();

      if (deptError) throw deptError;
      setDepartment(deptData);

      // Fetch employees in this department
      const { data: empData, error: empError } = await supabase
        .from('employees')
        .select('id, full_name, email, phone, position, avatar_url, status, hire_date')
        .eq('department', deptData.name)
        .order('full_name');

      if (empError) throw empError;
      setEmployees(empData || []);

      // Fetch sub-departments
      const { data: subDeptData, error: subDeptError } = await supabase
        .from('departments')
        .select(`
          id,
          name,
          name_en,
          manager:employees!manager_id(full_name)
        `)
        .eq('parent_department_id', id)
        .eq('is_active', true);

      if (subDeptError) throw subDeptError;

      // Count employees for each sub-department
      const subDepartmentsWithCount = await Promise.all(
        (subDeptData || []).map(async (subDept: any) => {
          const { count } = await supabase
            .from('employees')
            .select('*', { count: 'exact', head: true })
            .eq('department', subDept.name)
            .eq('status', 'active');

          return {
            ...subDept,
            employee_count: count || 0,
          };
        })
      );

      setSubDepartments(subDepartmentsWithCount);

      const [{ data: posData }, { data: deptList }, { data: empList }] = await Promise.all([
        supabase.from('positions').select('*').eq('department_id', id).order('title'),
        supabase.from('departments').select('id, name').order('name'),
        supabase.from('employees').select('id, full_name').eq('status', 'active').order('full_name'),
      ]);
      setPositions(posData || []);
      setAllDepartments(deptList || []);
      setAllEmployees(empList || []);

      // Calculate statistics
      const activeEmp = empData?.filter(e => e.status === 'active') || [];
      
      // Fetch salaries for statistics
      const { data: salaryData } = await supabase
        .from('employees')
        .select('salary')
        .eq('department', deptData.name)
        .eq('status', 'active')
        .not('salary', 'is', null);

      const totalSalaries = salaryData?.reduce((sum, e) => sum + (e.salary || 0), 0) || 0;
      const avgSalary = salaryData && salaryData.length > 0 ? totalSalaries / salaryData.length : 0;

      setStats({
        totalEmployees: empData?.length || 0,
        activeEmployees: activeEmp.length,
        avgSalary,
        totalSalaries,
      });

    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <>
        <div className="p-8 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </>
    );
  }

  if (!department) {
    return (
      <>
        <div className="p-8 text-center">
          <p className="text-muted-foreground">დეპარტამენტი ვერ მოიძებნა</p>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="p-8 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-3 flex-1">
            <div className="p-3 rounded-xl bg-primary/10">
              <Building2 className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">{department.name}</h1>
              {department.name_en && (
                <p className="text-muted-foreground">{department.name_en}</p>
              )}
            </div>
          </div>
          <Badge variant={department.is_active ? "default" : "secondary"}>
            {department.is_active ? 'აქტიური' : 'არააქტიური'}
          </Badge>
          <Button variant="outline" size="sm" onClick={() => setEditDeptOpen(true)}>
            <Pencil className="h-4 w-4 mr-2" />
            რედაქტირება
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>პოზიციები ({positions.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {positions.length === 0 ? (
              <p className="text-sm text-muted-foreground">ამ დეპარტამენტში პოზიციები არ არის</p>
            ) : (
              <div className="divide-y divide-border">
                {positions.map((pos) => (
                  <div key={pos.id} className="flex items-center justify-between gap-3 py-3">
                    <div className="min-w-0">
                      <p className="font-medium">{pos.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {pos.level || '-'} · {pos.filled_count ?? 0}/{pos.headcount ?? 0}
                        {pos.min_salary || pos.max_salary ? ` · ${pos.min_salary ?? 0}–${pos.max_salary ?? 0} ₾` : ''}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => setEditPos(pos)}>
                      <Pencil className="h-4 w-4 mr-1" />
                      რედაქტირება
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Description */}
        {department.description && (
          <Card>
            <CardContent className="pt-6">
              <p className="text-muted-foreground">{department.description}</p>
            </CardContent>
          </Card>
        )}

        {/* Manager Info */}
        {department.manager && (
          <Card>
            <CardHeader>
              <CardTitle>დეპარტამენტის მენეჯერი</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={department.manager.avatar_url || undefined} />
                  <AvatarFallback>
                    {department.manager.full_name.split(' ').map(n => n[0]).join('').toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{department.manager.full_name}</h3>
                  <p className="text-sm text-muted-foreground flex items-center gap-1">
                    <Briefcase className="h-3 w-3" />
                    {department.manager.position}
                  </p>
                  <div className="flex gap-4 mt-2">
                    <a href={`mailto:${department.manager.email}`} className="text-sm text-primary flex items-center gap-1 hover:underline">
                      <Mail className="h-3 w-3" />
                      {department.manager.email}
                    </a>
                    {department.manager.phone && (
                      <a href={`tel:${department.manager.phone}`} className="text-sm text-primary flex items-center gap-1 hover:underline">
                        <Phone className="h-3 w-3" />
                        {department.manager.phone}
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-500/10">
                  <Users className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">სულ თანამშრომელი</p>
                  <p className="text-2xl font-bold">
                    {stats.totalEmployees}
                    {department.headcount_limit && (
                      <span className="text-sm text-muted-foreground ml-1">
                        / {department.headcount_limit}
                      </span>
                    )}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-green-500/10">
                  <Users className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">აქტიური</p>
                  <p className="text-2xl font-bold">{stats.activeEmployees}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-500/10">
                  <TrendingUp className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">საშუალო ხელფასი</p>
                  <p className="text-lg font-bold">
                    {new Intl.NumberFormat('ka-GE', {
                      style: 'currency',
                      currency: 'GEL',
                      minimumFractionDigits: 0,
                    }).format(stats.avgSalary)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-orange-500/10">
                  <DollarSign className="h-5 w-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">ბიუჯეტი</p>
                  <p className="text-lg font-bold">
                    {new Intl.NumberFormat('ka-GE', {
                      style: 'currency',
                      currency: 'GEL',
                      minimumFractionDigits: 0,
                    }).format(department.budget || 0)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sub-departments */}
        {subDepartments.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>ქვე-დეპარტამენტები ({subDepartments.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {subDepartments.map((subDept) => (
                  <Card key={subDept.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate(`/department/${subDept.id}`)}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded-lg bg-primary/10">
                          <Building2 className="h-4 w-4 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold">{subDept.name}</h4>
                          {subDept.name_en && (
                            <p className="text-xs text-muted-foreground">{subDept.name_en}</p>
                          )}
                          {subDept.manager && (
                            <p className="text-xs text-muted-foreground mt-1">
                              მენეჯერი: {subDept.manager.full_name}
                            </p>
                          )}
                          <div className="flex items-center gap-1 mt-2">
                            <Users className="h-3 w-3 text-muted-foreground" />
                            <span className="text-sm font-medium">{subDept.employee_count} თანამშრომელი</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Employees Table */}
        <Card>
          <CardHeader>
            <CardTitle>თანამშრომლები ({employees.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {employees.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">არ არის თანამშრომელი ამ დეპარტამენტში</p>
            ) : isMobile ? (
              <div className="space-y-4">
                {employees.map((employee) => (
                  <MobileCard key={employee.id} onClick={() => navigate(`/employees/${employee.id}`)}>
                    <div className="flex items-center gap-3 mb-3">
                      <Avatar>
                        <AvatarImage src={employee.avatar_url || undefined} />
                        <AvatarFallback>
                          {employee.full_name.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h4 className="font-semibold">{employee.full_name}</h4>
                        <Badge variant={employee.status === 'active' ? 'default' : 'secondary'} className="text-xs">
                          {employee.status === 'active' ? 'აქტიური' : 'არააქტიური'}
                        </Badge>
                      </div>
                    </div>
                    <MobileCardRow label="პოზიცია" value={employee.position} />
                    <MobileCardRow label="ელ. ფოსტა" value={employee.email} />
                    {employee.phone && <MobileCardRow label="ტელეფონი" value={employee.phone} />}
                    <MobileCardRow label="დაქირავების თარიღი" value={new Date(employee.hire_date).toLocaleDateString('ka-GE')} />
                  </MobileCard>
                ))}
              </div>
            ) : (
              <ResponsiveTable>
                <thead>
                  <tr>
                    <th>თანამშრომელი</th>
                    <th>პოზიცია</th>
                    <th>ელ. ფოსტა</th>
                    <th>ტელეფონი</th>
                    <th>სტატუსი</th>
                    <th>დაქირავება</th>
                  </tr>
                </thead>
                <tbody>
                  {employees.map((employee) => (
                    <tr key={employee.id} onClick={() => navigate(`/employees/${employee.id}`)} className="cursor-pointer hover:bg-muted/50">
                      <td>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarImage src={employee.avatar_url || undefined} />
                            <AvatarFallback>
                              {employee.full_name.split(' ').map(n => n[0]).join('').toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{employee.full_name}</span>
                        </div>
                      </td>
                      <td>{employee.position}</td>
                      <td>{employee.email}</td>
                      <td>{employee.phone || '-'}</td>
                      <td>
                        <Badge variant={employee.status === 'active' ? 'default' : 'secondary'}>
                          {employee.status === 'active' ? 'აქტიური' : 'არააქტიური'}
                        </Badge>
                      </td>
                      <td>{new Date(employee.hire_date).toLocaleDateString('ka-GE')}</td>
                    </tr>
                  ))}
                </tbody>
              </ResponsiveTable>
            )}
          </CardContent>
        </Card>
      </div>
      <EditDepartmentDialog
        open={editDeptOpen}
        onOpenChange={setEditDeptOpen}
        department={department}
        departments={allDepartments.filter(d => d.id !== department.id)}
        employees={allEmployees}
        onSuccess={() => { setEditDeptOpen(false); fetchDepartmentData(); }}
      />
      <EditPositionDialog
        open={!!editPos}
        onOpenChange={(o) => !o && setEditPos(null)}
        position={editPos}
        departments={allDepartments}
        onSuccess={() => { setEditPos(null); fetchDepartmentData(); }}
      />
    </>
  );
};

export default DepartmentDetails;