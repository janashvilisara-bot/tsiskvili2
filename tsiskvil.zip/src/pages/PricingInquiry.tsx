import { useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle2, Building2, Sparkles, Crown, Rocket } from "lucide-react";

const MODULES = [
  "ადამიანური რესურსები (HR)",
  "ხელფასი / Payroll",
  "დასწრება / Attendance",
  "შვებულებები",
  "სამუშაო გრაფიკები",
  "რეკრუტმენტი",
  "შეფასებები / OKR",
  "სწავლება",
  "დავალებები / Tasks",
  "ფინანსები / ბიუჯეტი",
  "მივლინებები",
  "ბენეფიტები",
  "ჩატი",
  "დოკუმენტბრუნვა",
  "ანგარიშგება / Analytics",
];

const INTEGRATIONS = [
  "RS.ge",
  "Pension.ge",
  "Signify (ხელმოწერა)",
  "ბანკები (გადარიცხვები)",
  "Google Calendar",
  "SMS გადამხდელი",
  "ბრძოლადარიცხვა (Turnstile)",
  "SSO (SAML/OAuth)",
];

const schema = z.object({
  company_name: z.string().trim().min(2).max(200),
  contact_person: z.string().trim().min(2).max(120),
  contact_position: z.string().trim().max(120).optional().or(z.literal("")),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  website: z.string().trim().max(255).optional().or(z.literal("")),
  industry: z.string().trim().max(120).optional().or(z.literal("")),
  country: z.string().trim().max(80).optional().or(z.literal("")),
  employee_count: z.coerce.number().int().min(0).max(1000000).optional(),
  branches_count: z.coerce.number().int().min(0).max(10000).optional(),
  current_hr_system: z.string().trim().max(200).optional().or(z.literal("")),
  expected_users: z.coerce.number().int().min(0).max(1000000).optional(),
  timeline: z.string().max(80).optional(),
  budget_range: z.string().max(80).optional(),
  
  special_requirements: z.string().max(2000).optional().or(z.literal("")),
  additional_notes: z.string().max(2000).optional().or(z.literal("")),
});

export default function PricingInquiry() {
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [modules, setModules] = useState<string[]>([]);
  const [integrations, setIntegrations] = useState<string[]>([]);
  const [form, setForm] = useState<Record<string, any>>({
    timeline: "1-3 თვე",
  });
  const [estimate, setEstimate] = useState<{ basic: number; pro: number; ent: number } | null>(null);

  const computeEstimate = () => {
    const employees = Number(form.employee_count) || Number(form.expected_users) || 25;
    const branches = Number(form.branches_count) || 1;
    const moduleCount = modules.length || 5;
    const integrationCount = integrations.length;

    // Base per-employee pricing (GEL/month)
    const basicPerUser = 8;
    const proPerUser = 14;
    const entPerUser = 22;

    const moduleFactor = 1 + Math.max(0, moduleCount - 5) * 0.04;
    const integrationFactor = 1 + integrationCount * 0.05;
    const branchFactor = 1 + Math.max(0, branches - 1) * 0.03;

    const round = (n: number) => Math.max(150, Math.round(n / 10) * 10);

    const basic = round(employees * basicPerUser * moduleFactor * branchFactor);
    const pro = round(employees * proPerUser * moduleFactor * integrationFactor * branchFactor);
    const ent = round(employees * entPerUser * moduleFactor * integrationFactor * branchFactor * 1.15);
    return { basic, pro, ent };
  };

  const set = (k: string, v: any) => setForm((p) => ({ ...p, [k]: v }));
  const toggle = (arr: string[], setter: (v: string[]) => void, val: string) =>
    setter(arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast({
        title: "შეავსეთ ფორმა სწორად",
        description: first?.message ?? "გთხოვთ შეამოწმოთ ველები",
        variant: "destructive",
      });
      return;
    }
    setSubmitting(true);
    const payload = {
      ...parsed.data,
      modules_needed: modules,
      integrations_needed: integrations,
    };
    const { error } = await supabase.from("pricing_inquiries").insert(payload as any);
    setSubmitting(false);
    if (error) {
      toast({ title: "შეცდომა", description: "გთხოვთ სცადოთ ხელახლა", variant: "destructive" });
      return;
    }
    setEstimate(computeEstimate());
    setDone(true);
    toast({ title: "მადლობა!", description: "ქვემოთ ნახეთ სავარაუდო ფასები." });
  };

  if (done && estimate) {
    const fmt = (n: number) => `${n.toLocaleString("ka-GE")} ₾`;
    const tiers = [
      {
        name: "Starter",
        price: estimate.basic,
        icon: Sparkles,
        desc: "ძირითადი HR ფუნქციები მცირე გუნდისთვის",
        features: ["ძირითადი მოდულები", "მობილური აპი", "Email მხარდაჭერა", "სტანდარტული ანგარიშები"],
      },
      {
        name: "Professional",
        price: estimate.pro,
        icon: Rocket,
        desc: "სრული პაკეტი ინტეგრაციებით",
        features: ["ყველა მოდული", "ინტეგრაციები (RS.ge, SMS, Bank)", "პრიორიტეტული მხარდაჭერა", "Advanced ანალიტიკა"],
        highlight: true,
      },
      {
        name: "Enterprise",
        price: estimate.ent,
        icon: Crown,
        desc: "Custom გადაწყვეტა მსხვილი ორგანიზაციებისთვის",
        features: ["Custom დეველოპმენტი", "SLA 99.9%", "Dedicated მენეჯერი", "SSO + უსაფრთხოების აუდიტი"],
      },
    ];
    return (
      <div className="min-h-screen bg-gradient-mesh py-10 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <CheckCircle2 className="h-14 w-14 mx-auto text-primary mb-3" />
            <h1 className="text-3xl md:text-4xl font-bold mb-2">მადლობა! აი თქვენი სავარაუდო ფასები</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              ფასები გამოთვლილია თქვენი მოთხოვნის მიხედვით. საბოლოო შეთავაზებით ჩვენი გუნდი დაგიკავშირდებათ 1-2 სამუშაო დღეში.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {tiers.map((t) => {
              const Icon = t.icon;
              return (
                <Card key={t.name} className={`relative ${t.highlight ? "neon-border ring-2 ring-primary md:scale-105" : ""}`}>
                  {t.highlight && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-semibold px-3 py-1 rounded-full">
                      რეკომენდირებული
                    </div>
                  )}
                  <CardHeader className="text-center">
                    <Icon className="h-10 w-10 mx-auto text-primary mb-2" />
                    <CardTitle className="text-xl">{t.name}</CardTitle>
                    <CardDescription>{t.desc}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold">{fmt(t.price)}</div>
                      <div className="text-xs text-muted-foreground">თვეში (სავარაუდო)</div>
                    </div>
                    <ul className="space-y-2 text-sm">
                      {t.features.map((f) => (
                        <li key={f} className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <p className="text-xs text-muted-foreground text-center mt-6 max-w-2xl mx-auto">
            * ფასები სავარაუდოა და გამოთვლილია თანამშრომელთა რაოდენობის, არჩეული მოდულებისა და ინტეგრაციების მიხედვით. საბოლოო ფასი დადგინდება ინდივიდუალურად.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-mesh py-10 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <Building2 className="h-12 w-12 mx-auto text-primary mb-3 neon-text" />
          <h1 className="text-3xl md:text-4xl font-bold mb-2">ფასის შეფასების ფორმა</h1>
          <p className="text-muted-foreground">
            შეავსეთ ქვემოთ მოცემული ფორმა და მივიღებთ ინდივიდუალურ ფასნამდევს თქვენი ბიზნესისთვის
          </p>
        </div>

        <form onSubmit={submit} className="space-y-6">
          {/* Company info */}
          <Card>
            <CardHeader>
              <CardTitle>კომპანიის ინფორმაცია</CardTitle>
              <CardDescription>ძირითადი დეტალები კომპანიის შესახებ</CardDescription>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label>კომპანიის დასახელება *</Label>
                <Input required onChange={(e) => set("company_name", e.target.value)} />
              </div>
              <div>
                <Label>ინდუსტრია</Label>
                <Input placeholder="მაგ. რიტეილი, IT, წარმოება..." onChange={(e) => set("industry", e.target.value)} />
              </div>
              <div>
                <Label>ქვეყანა</Label>
                <Input defaultValue="საქართველო" onChange={(e) => set("country", e.target.value)} />
              </div>
              <div>
                <Label>თანამშრომელთა რაოდენობა</Label>
                <Input type="number" min={0} onChange={(e) => set("employee_count", e.target.value)} />
              </div>
              <div>
                <Label>ფილიალების რაოდენობა</Label>
                <Input type="number" min={0} onChange={(e) => set("branches_count", e.target.value)} />
              </div>
              <div className="md:col-span-2">
                <Label>ვებსაიტი</Label>
                <Input placeholder="https://..." onChange={(e) => set("website", e.target.value)} />
              </div>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card>
            <CardHeader>
              <CardTitle>საკონტაქტო პირი</CardTitle>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>სახელი და გვარი *</Label>
                <Input required onChange={(e) => set("contact_person", e.target.value)} />
              </div>
              <div>
                <Label>თანამდებობა</Label>
                <Input onChange={(e) => set("contact_position", e.target.value)} />
              </div>
              <div>
                <Label>ელფოსტა *</Label>
                <Input type="email" required onChange={(e) => set("email", e.target.value)} />
              </div>
              <div>
                <Label>ტელეფონი</Label>
                <Input type="tel" onChange={(e) => set("phone", e.target.value)} />
              </div>
            </CardContent>
          </Card>

          {/* Modules */}
          <Card>
            <CardHeader>
              <CardTitle>საჭირო მოდულები</CardTitle>
              <CardDescription>მონიშნეთ ყველა მოდული, რომელიც გჭირდებათ</CardDescription>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-3">
              {MODULES.map((m) => (
                <label key={m} className="flex items-center gap-2 cursor-pointer">
                  <Checkbox
                    checked={modules.includes(m)}
                    onCheckedChange={() => toggle(modules, setModules, m)}
                  />
                  <span className="text-sm">{m}</span>
                </label>
              ))}
            </CardContent>
          </Card>

          {/* Integrations */}
          <Card>
            <CardHeader>
              <CardTitle>საჭირო ინტეგრაციები</CardTitle>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-3">
              {INTEGRATIONS.map((m) => (
                <label key={m} className="flex items-center gap-2 cursor-pointer">
                  <Checkbox
                    checked={integrations.includes(m)}
                    onCheckedChange={() => toggle(integrations, setIntegrations, m)}
                  />
                  <span className="text-sm">{m}</span>
                </label>
              ))}
            </CardContent>
          </Card>

          {/* Tech & timeline */}
          <Card>
            <CardHeader>
              <CardTitle>ტექნიკური და კომერციული დეტალები</CardTitle>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>მომხმარებელთა მოსალოდნელი რაოდენობა</Label>
                <Input type="number" min={0} onChange={(e) => set("expected_users", e.target.value)} />
              </div>
              <div>
                <Label>მიმდინარე HR სისტემა</Label>
                <Input placeholder="მაგ. Excel, BambooHR, არცერთი..." onChange={(e) => set("current_hr_system", e.target.value)} />
              </div>
              <div>
                <Label>დანერგვის სასურველი ვადა</Label>
                <Select defaultValue="1-3 თვე" onValueChange={(v) => set("timeline", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="დაუყოვნებლივ">დაუყოვნებლივ</SelectItem>
                    <SelectItem value="1-3 თვე">1-3 თვე</SelectItem>
                    <SelectItem value="3-6 თვე">3-6 თვე</SelectItem>
                    <SelectItem value="6+ თვე">6+ თვე</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>ბიუჯეტი (თვიური)</Label>
                <Select onValueChange={(v) => set("budget_range", v)}>
                  <SelectTrigger><SelectValue placeholder="აირჩიეთ" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="< 500 ₾">&lt; 500 ₾</SelectItem>
                    <SelectItem value="500-1500 ₾">500 - 1,500 ₾</SelectItem>
                    <SelectItem value="1500-5000 ₾">1,500 - 5,000 ₾</SelectItem>
                    <SelectItem value="5000+ ₾">5,000+ ₾</SelectItem>
                    <SelectItem value="ჯერ არ ვიცი">ჯერ არ ვიცი</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="md:col-span-2">
                <Label>სპეციფიური მოთხოვნები</Label>
                <Textarea rows={3} placeholder="მაგ. SSO, custom roles, white-label..." onChange={(e) => set("special_requirements", e.target.value)} />
              </div>
              <div className="md:col-span-2">
                <Label>დამატებითი კომენტარი</Label>
                <Textarea rows={3} onChange={(e) => set("additional_notes", e.target.value)} />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center">
            <Button type="submit" size="lg" disabled={submitting} className="min-w-[240px]">
              {submitting ? "იგზავნება..." : "გაგზავნა"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
