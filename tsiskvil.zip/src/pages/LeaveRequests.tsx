import { useState, useEffect } from "react";
import { Plus, Search, Check, X, Calendar, FileDown, User, Umbrella, DollarSign, Loader2 } from "lucide-react";
import { exportToExcel } from "@/lib/exportToExcel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { usePersistedState } from "@/hooks/usePersistedState";
import { formatters } from "@/lib/dateUtils";
import { ka } from "date-fns/locale";
import { useRealtime } from "@/hooks/useRealtime";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import { DateErrorBoundary } from "@/components/DateErrorBoundary";


interface CustomField {
  label: string;
  value: string;
}

interface LeaveRequest {
  id: string;
  employee_id: string;
  manager_id: string | null;
  replacement_employee_id: string | null;
  leave_type: string;
  start_date: string;
  end_date: string;
  reason: string | null;
  status: string;
  created_at: string;
  sick_leave_certificate_number: string | null;
  sick_leave_issue_date: string | null;
  sick_leave_start_date: string | null;
  sick_leave_end_date: string | null;
  sick_leave_compensation_percentage: number | null;
  custom_fields: any;
  employees: {
    full_name: string;
    position: string;
    department: string | null;
  } | null;
  replacement_employee: {
    full_name: string;
    position: string;
  } | null;
}

interface LeaveHistory {
  id: string;
  leave_type: string;
  start_date: string;
  end_date: string;
  status: string;
  created_at: string;
}

export default function LeaveRequests() {
  const { user, userRole } = useAuth();
  const activeBranchId = useBranchFilter();
  const [requests, setRequests] = useState<LeaveRequest[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [managers, setManagers] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = usePersistedState<string>("leave-requests:search", "");
  const [positionFilter, setPositionFilter] = usePersistedState<string>("leave-requests:position", "");
  const [statusFilter, setStatusFilter] = usePersistedState<string>("leave-requests:status", "all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isFetchingRequests, setIsFetchingRequests] = useState(true);
  const [confirmDecision, setConfirmDecision] = useState<{ id: string; action: 'approve' | 'reject'; name: string } | null>(null);
  const [isDecisionLoading, setIsDecisionLoading] = useState(false);
  const [selectedLeaveType, setSelectedLeaveType] = useState("");
  const [customFields, setCustomFields] = useState<CustomField[]>([]);
  const [leaveHistory, setLeaveHistory] = useState<LeaveHistory[]>([]);
  const [currentEmployee, setCurrentEmployee] = useState<any>(null);
  const [replacementSearch, setReplacementSearch] = useState("");
  const [showReplacementSuggestions, setShowReplacementSuggestions] = useState(false);
  const [selectedReplacementId, setSelectedReplacementId] = useState<string | null>(null);

  const filteredReplacementEmployees = employees.filter(emp =>
    emp.full_name.toLowerCase().includes(replacementSearch.toLowerCase())
  ).slice(0, 5);

  const isHrOrAdmin = userRole === 'admin' || userRole === 'hr_manager';
  const canManage = isHrOrAdmin || userRole === 'department_manager' || managers.some(m => m.email === user?.email && (m.position?.toLowerCase().includes('მენეჯერი') || m.position?.toLowerCase().includes('manager')));

  // Check if user can approve a specific request (only HR/Admin or same department manager)
  const canApproveRequest = (request: LeaveRequest) => {
    // HR and admins can approve all requests
    if (userRole === 'hr_manager') return true;
    
    // Admins can only approve requests from their own department
    if (userRole === 'admin') {
      if (!currentEmployee?.department || !request.employees?.department) return false;
      return currentEmployee.department === request.employees.department;
    }
    
    // Department managers can only approve requests from their department
    if (userRole === 'department_manager') {
      if (!currentEmployee?.department || !request.employees?.department) return false;
      return currentEmployee.department === request.employees.department;
    }
    
    // Regular managers - check if they manage this employee's department
    if (currentEmployee?.department && request.employees?.department) {
      return currentEmployee.department === request.employees.department;
    }
    
    return false;
  };

  useEffect(() => {
    fetchRequests();
    fetchEmployees();
    fetchManagers();
    fetchCurrentEmployee();
  }, [user, activeBranchId]);

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase.rpc('get_employee_directory' as any);
      
      if (error) throw error;
      // Map RPC column names to expected format
      const mapped = (data || []).map((emp: any) => ({
        id: emp.emp_id,
        full_name: emp.emp_full_name,
        position: emp.emp_position,
        department: emp.emp_department,
      }));
      setEmployees(mapped);
    } catch (error: any) {
      console.error('Error fetching employees:', error);
    }
  };

  const fetchManagers = async () => {
    try {
      let q = supabase
        .from('employees')
        .select('id, full_name, position, department, email')
        .eq('status', 'active');
      if (activeBranchId) q = q.eq('branch_id', activeBranchId);
      const { data, error } = await q;
      
      if (error) throw error;
      setManagers(data || []);
    } catch (error: any) {
      console.error('Error fetching managers:', error);
    }
  };

  const fetchCurrentEmployee = async () => {
    if (!user) return;
    
    try {
      const { data: empData, error: empError } = await supabase
        .from('employees')
        .select('*')
        .eq('email', user.email)
        .maybeSingle();
      
      if (empError) throw empError;
      
      // Get department manager separately
      if (empData?.department) {
        const { data: deptData } = await supabase
          .from('departments')
          .select('manager_id')
          .eq('name', empData.department)
          .maybeSingle();
        
        setCurrentEmployee({ ...empData, direct_manager_id: deptData?.manager_id });
      } else {
        setCurrentEmployee(empData);
      }
      
      if (empData) {
        fetchLeaveHistory(empData.id);
      }
    } catch (error) {
      console.error('Error fetching current employee:', error);
    }
  };

  const fetchLeaveHistory = async (employeeId: string) => {
    try {
      const { data, error } = await supabase
        .from('leave_requests')
        .select('*')
        .eq('employee_id', employeeId)
        .eq('status', 'approved')
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) throw error;
      setLeaveHistory(data || []);
    } catch (error) {
      console.error('Error fetching leave history:', error);
    }
  };

  const fetchRequests = async () => {
    setIsFetchingRequests(true);
    try {
      let q = supabase
        .from('leave_requests')
        .select(`
          *,
          employees!leave_requests_employee_id_fkey(full_name, position, department),
          replacement_employee:employees!leave_requests_replacement_employee_id_fkey(full_name, position)
        `)
        .order('created_at', { ascending: false });
      if (activeBranchId) q = q.eq('branch_id', activeBranchId);
      const { data, error } = await q;

      if (error) throw error;
      setRequests((data || []) as LeaveRequest[]);
    } catch (error: any) {
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsFetchingRequests(false);
    }
  };

  // Use centralized Realtime hook
  useRealtime({
    table: 'leave_requests',
    event: '*',
    onChange: fetchRequests,
  });


  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      // Get or create current user's employee record
      const { data: currentEmployee, error: empError } = await supabase
        .from('employees')
        .select('id, branch_id')
        .eq('email', user?.email)
        .limit(1)
        .maybeSingle();

      if (empError) {
        console.error('Employee fetch error:', empError);
        throw new Error('თანამშრომლის მონაცემების ჩატვირთვა ვერ მოხერხდა');
      }

      let employeeId = currentEmployee?.id as string | undefined;
      let employeeBranchId = currentEmployee?.branch_id as string | undefined;

      if (!employeeId) {
        // Try to create minimal employee record for the current user
        const { data: profile } = await supabase
          .from('profiles')
          .select('full_name')
          .eq('id', user?.id)
          .maybeSingle();

        const { data: newEmp, error: createEmpErr } = await supabase
          .from('employees')
          .insert([{
            full_name: profile?.full_name || (user?.email ?? 'მომხმარებელი'),
            email: user?.email as string,
            position: 'სპეციალისტი',
            department: null,
            hire_date: new Date().toISOString().slice(0, 10),
            status: 'active',
            created_by: user?.id as string,
          }])
          .select('id, branch_id')
          .single();

        if (createEmpErr) {
          console.error('Employee creation error:', createEmpErr);
          throw new Error('თანამშრომლის ჩანაწერის შექმნა ვერ მოხერხდა');
        }
        employeeId = newEmp.id;
        employeeBranchId = newEmp.branch_id;
      }

      const leaveType = formData.get('leave_type') as string;
      const replacementEmployeeId = formData.get('replacement_employee_id') as string || null;
      
      const payload: any = {
        employee_id: employeeId as string,
        user_id: user?.id as string,
        branch_id: employeeBranchId,
        manager_id: (formData.get('manager_id') as string) || null,
        leave_type: leaveType,
        start_date: formData.get('start_date') as string,
        end_date: formData.get('end_date') as string,
        reason: (formData.get('reason') as string) || null,
        status: 'pending',
        replacement_employee_id: replacementEmployeeId || null,
        custom_fields: customFields.length > 0 ? customFields : null,
      };

      // Add sick leave certificate fields if leave type is "sick"
      if (leaveType === 'sick') {
        payload.sick_leave_certificate_number = formData.get('sick_leave_certificate_number') || null;
        payload.sick_leave_issue_date = formData.get('sick_leave_issue_date') || null;
      }


      const { data: insertedRequest, error } = await supabase
        .from('leave_requests')
        .insert([payload])
        .select('*, employees!leave_requests_employee_id_fkey(full_name, department)')
        .single();

      if (error) {
        console.error('Insert error:', error);
        throw new Error('შვებულების მოთხოვნის გაგზავნა ვერ მოხერხდა. გთხოვთ, სცადოთ ხელახლა.');
      }

      // Notification is handled by database trigger (notify_leave_request)

      toast.success('შვებულების მოთხოვნა წარმატებით გაიგზავნა');
      setIsDialogOpen(false);
      setCustomFields([]);
      setReplacementSearch("");
      setSelectedReplacementId(null);
      fetchRequests();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      console.error('Leave request error:', error);
      toast.error(error.message || 'შეცდომა მოხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApprove = (id: string) => {
    const request = requests.find(r => r.id === id);
    setConfirmDecision({ id, action: 'approve', name: request?.employees?.full_name || '' });
  };

  const handleReject = (id: string) => {
    const request = requests.find(r => r.id === id);
    setConfirmDecision({ id, action: 'reject', name: request?.employees?.full_name || '' });
  };

  const performDecision = async () => {
    if (!confirmDecision) return;
    const { id, action } = confirmDecision;
    setConfirmDecision(null);
    setIsDecisionLoading(true);

    try {
      if (action === 'approve') {
        // Get the leave request details to notify replacement
        const { data: leaveRequest } = await supabase
          .from('leave_requests')
          .select('*, employees!leave_requests_employee_id_fkey(full_name, position), replacement:employees!leave_requests_replacement_employee_id_fkey(user_id, full_name)')
          .eq('id', id)
          .single();

        const { error } = await supabase
          .from('leave_requests')
          .update({
            status: 'approved',
            approved_by: user?.id,
            approved_at: new Date().toISOString(),
          })
          .eq('id', id);

        if (error) throw error;

        // Notify replacement employee if assigned
        if (leaveRequest?.replacement_employee_id && leaveRequest?.replacement?.user_id) {
          await supabase
            .from('notifications')
            .insert({
              title: 'თქვენ დაინიშნეთ შემცვლელად',
              message: `${leaveRequest.employees?.full_name} (${leaveRequest.employees?.position}) შვებულებაში იმყოფება ${new Date(leaveRequest.start_date).toLocaleDateString('ka-GE')} - ${new Date(leaveRequest.end_date).toLocaleDateString('ka-GE')}. თქვენ დაინიშნეთ შემცვლელად ამ პერიოდში.`,
              type: 'general',
              target_audience: 'specific',
              user_id: leaveRequest.replacement.user_id,
              created_by: user?.id
            });
        }

        toast.success('შვებულება დამტკიცებულია');
      } else {
        const { error } = await supabase
          .from('leave_requests')
          .update({
            status: 'rejected',
            approved_by: user?.id,
            approved_at: new Date().toISOString(),
          })
          .eq('id', id);

        if (error) throw error;
        toast.success('შვებულება უარყოფილია');
      }
      fetchRequests();
    } catch (error: any) {
      toast.error('შეცდომა მოხდა');
    } finally {
      setIsDecisionLoading(false);
    }
  };

  const filteredRequests = requests.filter((req) => {
    const matchesSearch = req.employees?.full_name?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPosition = !positionFilter || req.employees?.position?.toLowerCase().includes(positionFilter.toLowerCase());
    const matchesStatus = statusFilter === "all" || req.status === statusFilter;
    return matchesSearch && matchesPosition && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-700';
      case 'rejected': return 'bg-red-100 text-red-700';
      default: return 'bg-yellow-100 text-yellow-700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'approved': return 'დამტკიცებული';
      case 'rejected': return 'უარყოფილი';
      default: return 'განხილვაში';
    }
  };

  const handleExport = () => {
    const exportData = filteredRequests.map(req => {
      const data: any = {
        'თანამშრომელი': req.employees?.full_name || '',
        'პოზიცია': req.employees?.position || '',
        'ტიპი': req.leave_type,
        'დაწყება': new Date(req.start_date).toLocaleDateString('ka-GE'),
        'დასრულება': new Date(req.end_date).toLocaleDateString('ka-GE'),
        'მიზეზი': req.reason || '',
        'სტატუსი': getStatusText(req.status),
        'თარიღი': new Date(req.created_at).toLocaleDateString('ka-GE')
      };
      
      if (req.leave_type === 'sick' && req.sick_leave_certificate_number) {
        data['ბიულეტინის ნომერი'] = req.sick_leave_certificate_number;
        data['ბიულეტინის გაცემა'] = req.sick_leave_issue_date ? new Date(req.sick_leave_issue_date).toLocaleDateString('ka-GE') : '';
        data['ბიულეტინის ვადა'] = req.sick_leave_start_date && req.sick_leave_end_date 
          ? `${new Date(req.sick_leave_start_date).toLocaleDateString('ka-GE')} - ${new Date(req.sick_leave_end_date).toLocaleDateString('ka-GE')}`
          : '';
      }
      
      return data;
    });

    const success = exportToExcel(exportData, `შვებულებები_${new Date().toISOString().split('T')[0]}`, 'შვებულებები');
    if (success) {
      toast.success('ექსპორტი წარმატებით განხორციელდა');
    } else {
      toast.error('ექსპორტის შეცდომა');
    }
  };

  const getLeaveTypeColor = (type: string) => {
    switch (type) {
      case 'paid': return { bg: 'from-blue-500/10 to-blue-600/5', border: 'border-blue-500/20', icon: 'text-blue-600', badge: 'bg-blue-500/10 text-blue-600 border-blue-500/20' };
      case 'sick': return { bg: 'from-green-500/10 to-green-600/5', border: 'border-green-500/20', icon: 'text-green-600', badge: 'bg-green-500/10 text-green-600 border-green-500/20' };
      case 'unpaid': return { bg: 'from-orange-500/10 to-orange-600/5', border: 'border-orange-500/20', icon: 'text-orange-600', badge: 'bg-orange-500/10 text-orange-600 border-orange-500/20' };
      case 'dayoff': return { bg: 'from-purple-500/10 to-purple-600/5', border: 'border-purple-500/20', icon: 'text-purple-600', badge: 'bg-purple-500/10 text-purple-600 border-purple-500/20' };
      default: return { bg: 'from-gray-500/10 to-gray-600/5', border: 'border-gray-500/20', icon: 'text-gray-600', badge: 'bg-gray-500/10 text-gray-600 border-gray-500/20' };
    }
  };

  const getLeaveTypeIcon = (type: string) => {
    switch (type) {
      case 'paid': return <Umbrella className="h-4 w-4" />;
      case 'sick': return <Plus className="h-4 w-4" />;
      case 'unpaid': return <DollarSign className="h-4 w-4" />;
      case 'dayoff': return <User className="h-4 w-4" />;
      default: return <Calendar className="h-4 w-4" />;
    }
  };

  const getLeaveTypeName = (type: string) => {
    switch (type) {
      case 'paid': return 'ხელფასიანი შვებულება';
      case 'sick': return 'საავადმყოფოს ფურცელი';
      case 'unpaid': return 'უხელფასო შვებულება';
      case 'dayoff': return 'Day Off';
      default: return 'შვებულება';
    }
  };

  const calculateLeaveDays = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    return Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  };

  return (
    <div className="space-y-4 md:space-y-6 px-1 md:px-0">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="min-w-0">
          <h1 className="text-2xl md:text-3xl font-bold truncate">შვებულებები</h1>
          <p className="mt-1 md:mt-2 text-sm md:text-base text-muted-foreground">შვებულებების მოთხოვნების მართვა</p>
        </div>
        <div className="flex gap-2 flex-shrink-0">
          <Button variant="outline" onClick={handleExport} className="gap-2 flex-1 md:flex-none text-sm">
            <FileDown className="h-4 w-4" />
            <span>ექსპორტი</span>
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2 flex-1 md:flex-none text-sm">
                <Plus className="h-4 w-4" />
                <span>ახალი მოთხოვნა</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>შვებულების მოთხოვნა</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="leave_type">შვებულების ტიპი *</Label>
                  <Select name="leave_type" required onValueChange={setSelectedLeaveType}>
                    <SelectTrigger>
                      <SelectValue placeholder="აირჩიეთ ტიპი" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="paid">ხელფასიანი შვებულება</SelectItem>
                      <SelectItem value="unpaid">უხელფასო შვებულება</SelectItem>
                      <SelectItem value="sick">საავადმყოფოს ფურცელი</SelectItem>
                      <SelectItem value="dayoff">Day Off</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {selectedLeaveType === 'sick' && (
                  <>
                    <div className="border-t pt-4">
                      <h3 className="text-sm font-semibold mb-3">ბიულეტინის ინფორმაცია</h3>
                      <div className="space-y-3">
                        <div>
                          <Label htmlFor="sick_leave_certificate_number">ბიულეტინის ნომერი</Label>
                          <Input 
                            id="sick_leave_certificate_number" 
                            name="sick_leave_certificate_number" 
                            placeholder="მაგ. 123456789"
                          />
                        </div>
                        <div>
                          <Label htmlFor="sick_leave_issue_date">გაცემის თარიღი</Label>
                          <Input 
                            id="sick_leave_issue_date" 
                            name="sick_leave_issue_date" 
                            type="date"
                          />
                        </div>
                      </div>
                    </div>
                  </>
                )}
                <div>
                  <Label htmlFor="manager_id">უშუალო უფროსი *</Label>
                  {currentEmployee?.direct_manager_id ? (
                    <>
                      <Input 
                        value={managers.find(m => m.id === currentEmployee.direct_manager_id)?.full_name || 'უფროსი არ არის მინიჭებული'}
                        disabled
                        className="bg-muted"
                      />
                      <input type="hidden" name="manager_id" value={currentEmployee.direct_manager_id} />
                    </>
                  ) : (
                    <Input 
                      value="უფროსი არ არის მინიჭებული"
                      disabled
                      className="bg-muted text-muted-foreground"
                    />
                  )}
                  <p className="text-xs text-muted-foreground mt-1">
                    უშუალო უფროსი ავტომატურად აიღება დეპარტამენტის მიხედვით
                  </p>
                </div>
                <div className="relative">
                  <Label htmlFor="replacement_employee_name">შემცვლელი თანამშრომელი</Label>
                  <Input 
                    id="replacement_employee_name" 
                    name="replacement_employee_name" 
                    placeholder="ჩაწერეთ შემცვლელის სახელი და გვარი"
                    value={replacementSearch}
                    onChange={(e) => {
                      setReplacementSearch(e.target.value);
                      setShowReplacementSuggestions(true);
                      setSelectedReplacementId(null);
                    }}
                    onFocus={() => {
                      setShowReplacementSuggestions(true);
                    }}
                    onBlur={() => {
                      // Delay to allow click on suggestion
                      setTimeout(() => setShowReplacementSuggestions(false), 200);
                    }}
                    autoComplete="off"
                  />
                  <input type="hidden" name="replacement_employee_id" value={selectedReplacementId || ''} />
                  {showReplacementSuggestions && replacementSearch.length >= 1 && (
                    <div className="absolute z-50 w-full mt-1 bg-popover border border-border rounded-md shadow-lg max-h-48 overflow-y-auto">
                      {filteredReplacementEmployees.length > 0 ? (
                        filteredReplacementEmployees.map((emp) => (
                          <button
                            key={emp.id}
                            type="button"
                            className="w-full px-3 py-2 text-left hover:bg-accent text-sm"
                            onMouseDown={(e) => {
                              e.preventDefault();
                              setReplacementSearch(emp.full_name);
                              setSelectedReplacementId(emp.id);
                              setShowReplacementSuggestions(false);
                            }}
                          >
                            <span className="font-medium">{emp.full_name}</span>
                            <span className="text-muted-foreground ml-2">- {emp.position || 'პოზიცია არ არის'}</span>
                          </button>
                        ))
                      ) : (
                        <div className="px-3 py-2 text-sm text-muted-foreground">
                          თანამშრომელი ვერ მოიძებნა
                        </div>
                      )}
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">
                    შემცვლელს მიეცემა შეტყობინება როცა შვებულება დამტკიცდება
                  </p>
                </div>
                <div>
                  <Label htmlFor="start_date">დაწყების თარიღი *</Label>
                  <Input id="start_date" name="start_date" type="date" required />
                </div>
                <div>
                  <Label htmlFor="end_date">დასრულების თარიღი *</Label>
                  <Input id="end_date" name="end_date" type="date" required />
                  <p className="text-xs text-muted-foreground mt-1">
                    შვებულების დღეები ითვლება დასრულების თარიღის ჩათვლით
                  </p>
                </div>
                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-semibold">დამატებითი ველები</h3>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setCustomFields([...customFields, { label: '', value: '' }])}
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      დამატება
                    </Button>
                  </div>
                  {customFields.map((field, index) => (
                    <div key={index} className="flex gap-2 mb-2">
                      <Input
                        placeholder="ველის სახელი"
                        value={field.label}
                        onChange={(e) => {
                          const newFields = [...customFields];
                          newFields[index].label = e.target.value;
                          setCustomFields(newFields);
                        }}
                        className="flex-1"
                      />
                      <Input
                        placeholder="მნიშვნელობა"
                        value={field.value}
                        onChange={(e) => {
                          const newFields = [...customFields];
                          newFields[index].value = e.target.value;
                          setCustomFields(newFields);
                        }}
                        className="flex-1"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => setCustomFields(customFields.filter((_, i) => i !== index))}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
                <div>
                  <Label htmlFor="reason">მიზეზი</Label>
                  <Textarea id="reason" name="reason" placeholder="შეიყვანეთ მიზეზი" />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'მიმდინარეობს...' : 'გაგზავნა'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="ძებნა..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Leave History Timeline */}
      {currentEmployee && (
        <Card className="group relative overflow-hidden border-border/50 bg-card/95">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-6">
              <Calendar className="h-5 w-5 text-primary" />
              <h3 className="text-lg font-semibold">შვებულებების ისტორია</h3>
            </div>

            {leaveHistory.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                შვებულებების ისტორია ცარიელია
              </div>
            ) : (
              <div className="relative">
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border"></div>
                
                <div className="space-y-6">
                  {leaveHistory.map((leave) => {
                    const colors = getLeaveTypeColor(leave.leave_type);
                    const icon = getLeaveTypeIcon(leave.leave_type);
                    const days = calculateLeaveDays(leave.start_date, leave.end_date);
                    
                    return (
                      <div key={leave.id} className="relative flex gap-4">
                        <div className={`relative z-10 flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-br ${colors.bg} border-2 ${colors.border} shrink-0`}>
                          <div className={colors.icon}>
                            {icon}
                          </div>
                        </div>
                        <div className="flex-1 pb-6">
                          <div className={`p-4 rounded-lg bg-gradient-to-br ${colors.bg} border ${colors.border}`}>
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-semibold text-sm">{getLeaveTypeName(leave.leave_type)}</span>
                              <Badge className={colors.badge}>დამტკიცებული</Badge>
                            </div>
                            <div className="text-xs text-muted-foreground space-y-1">
                              <div className="flex items-center gap-2">
                                <Calendar className="h-3 w-3" />
                                <span>
                                  {formatters.shortDateWithMonth(leave.start_date)} - {formatters.longDate(leave.end_date)}
                                </span>
                              </div>
                              <div>ხანგრძლივობა: {days} დღე</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Status category tabs */}
      <div className="flex flex-wrap gap-2">
        {[
          { key: "all", label: "ყველა", color: "bg-primary text-primary-foreground" },
          { key: "pending", label: "მოლოდინში", color: "bg-amber-500 text-white" },
          { key: "approved", label: "დამტკიცებული", color: "bg-emerald-600 text-white" },
          { key: "rejected", label: "უარყოფილი", color: "bg-rose-600 text-white" },
        ].map((cat) => {
          const count =
            cat.key === "all"
              ? requests.length
              : requests.filter((r) => r.status === cat.key).length;
          const isActive = statusFilter === cat.key;
          return (
            <button
              key={cat.key}
              onClick={() => setStatusFilter(cat.key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium border transition-all ${
                isActive
                  ? `${cat.color} border-transparent shadow-md`
                  : "bg-card text-foreground border-border hover:bg-muted"
              }`}
            >
              <span>{cat.label}</span>
              <span
                className={`min-w-[22px] h-[22px] px-1.5 rounded-full text-xs font-bold flex items-center justify-center ${
                  isActive ? "bg-white/25" : "bg-muted text-foreground"
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Filters */}
      <Card className="border-none shadow-md">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="ძიება სახელით..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Input
              placeholder="პოზიცია"
              value={positionFilter}
              onChange={(e) => setPositionFilter(e.target.value)}
              className="w-[180px]"
            />
          </div>
        </CardContent>
      </Card>


      <div className="grid gap-4">
        {filteredRequests.map((request) => (
          <Card key={request.id}>
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{request.employees?.full_name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{request.employees?.position}</p>
                </div>
                <Badge className={getStatusColor(request.status)}>
                  {getStatusText(request.status)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-2 text-sm">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>{new Date(request.start_date).toLocaleDateString('ka-GE')} - {new Date(request.end_date).toLocaleDateString('ka-GE')}</span>
                </div>
                <div>
                  <span className="font-medium">ტიპი:</span> {({annual:"ყოველწლიური",sick:"სამედიცინო",personal:"პირადი",unpaid:"უხელფასო",paid:"ანაზღაურებადი",maternity:"დეკრეტული"} as Record<string,string>)[request.leave_type] || request.leave_type}
                </div>
                {request.replacement_employee && (
                  <div>
                    <span className="font-medium">შემცვლელი:</span> {request.replacement_employee.full_name} ({request.replacement_employee.position})
                  </div>
                )}
                {request.reason && (
                  <div>
                    <span className="font-medium">მიზეზი:</span> {request.reason}
                  </div>
                )}
                {request.leave_type === 'sick' && request.sick_leave_certificate_number && (
                  <div className="mt-3 pt-3 border-t">
                    <div className="text-xs font-semibold text-muted-foreground mb-2">ბიულეტინის ინფორმაცია</div>
                    <div className="space-y-1 text-xs">
                      <div><span className="font-medium">ნომერი:</span> {request.sick_leave_certificate_number}</div>
                      {request.sick_leave_issue_date && (
                        <div><span className="font-medium">გაცემა:</span> {new Date(request.sick_leave_issue_date).toLocaleDateString('ka-GE')}</div>
                      )}
                      {request.sick_leave_start_date && request.sick_leave_end_date && (
                        <div>
                          <span className="font-medium">ვადა:</span> {new Date(request.sick_leave_start_date).toLocaleDateString('ka-GE')} - {new Date(request.sick_leave_end_date).toLocaleDateString('ka-GE')}
                        </div>
                      )}
                    </div>
                  </div>
                )}
                {request.custom_fields && Array.isArray(request.custom_fields) && request.custom_fields.length > 0 && (
                  <div className="mt-3 pt-3 border-t">
                    <div className="text-xs font-semibold text-muted-foreground mb-2">დამატებითი ინფორმაცია</div>
                    <div className="space-y-1 text-xs">
                      {request.custom_fields.map((field: CustomField, idx: number) => (
                        <div key={idx}>
                          <span className="font-medium">{field.label}:</span> {field.value}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              {canManage && request.status === 'pending' && canApproveRequest(request) && (
                <div className="mt-4 flex gap-2">
                  <Button
                    size="sm"
                    className="flex-1"
                    onClick={() => handleApprove(request.id)}
                  >
                    <Check className="mr-1 h-4 w-4" />
                    დამტკიცება
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    className="flex-1"
                    onClick={() => handleReject(request.id)}
                  >
                    <X className="mr-1 h-4 w-4" />
                    უარყოფა
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <AlertDialog open={confirmDecision !== null} onOpenChange={(open) => { if (!open) setConfirmDecision(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirmDecision?.action === 'approve' ? 'შვებულების დამტკიცება' : 'შვებულების უარყოფა'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirmDecision?.action === 'approve'
                ? `დაადასტურეთ ${confirmDecision?.name || 'თანამშრომლის'} შვებულების დამტკიცება.`
                : `დაადასტურეთ ${confirmDecision?.name || 'თანამშრომლის'} შვებულების უარყოფა.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDecisionLoading}>გაუქმება</AlertDialogCancel>
            <AlertDialogAction onClick={performDecision} disabled={isDecisionLoading}>
              {isDecisionLoading ? 'მიმდინარეობს...' : 'დადასტურება'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {isFetchingRequests ? (
        <div className="flex h-64 items-center justify-center text-muted-foreground">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      ) : filteredRequests.length === 0 && (
        <div className="flex h-64 items-center justify-center text-muted-foreground">
          მოთხოვნები არ მოიძებნა
        </div>
      )}
    </div>
  );
}