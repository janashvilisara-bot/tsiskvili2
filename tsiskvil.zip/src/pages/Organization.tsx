import { useLanguage } from "@/contexts/LanguageContext";
import { useState, useEffect } from "react";
import { useFeatureLock, FeatureLockOverlay } from "@/components/FeatureCardLock";
import { 
  Building2,
  Network,
  ClipboardList,
  Phone,
  FileCheck,
  AlertTriangle,
  Briefcase,
  Car,
  ArrowRight,
  Sparkles,
  Users,
  ArrowUpRight,
  ArrowDownRight,
  FolderTree,
  Target
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { IndustryTemplatesDialog } from "@/components/org-structure/IndustryTemplatesDialog";
import HubErrorState from "@/components/HubErrorState";
import { cn } from "@/lib/utils";

interface OrganizationStats {
  totalDepartments: number;
  totalPositions: number;
  activeTasks: number;
  totalContacts: number;
}

export default function Organization() {
  const navigate = useNavigate();
  const { isLocked, handleLockedClick } = useFeatureLock();
  const [stats, setStats] = useState<OrganizationStats>({
    totalDepartments: 0,
    totalPositions: 0,
    activeTasks: 0,
    totalContacts: 0
  });
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState(false);
  const { language } = useLanguage();
  const L = (ka: string, en: string) => (language === "en" ? en : ka);

  useEffect(() => {
    fetchOrganizationStats();
  }, []);

  const fetchOrganizationStats = async () => {
    try {
      // Fetch departments
      const { count: deptCount } = await supabase
        .from('departments')
        .select('*', { count: 'exact', head: true });

      // Fetch positions
      const { count: posCount } = await supabase
        .from('positions')
        .select('*', { count: 'exact', head: true });

      // Fetch active tasks
      const { count: taskCount } = await supabase
        .from('tasks')
        .select('*', { count: 'exact', head: true })
        .neq('status', 'completed');

      // Fetch contacts
      const { count: contactCount } = await supabase
        .from('contacts')
        .select('*', { count: 'exact', head: true });

      setStats({
        totalDepartments: deptCount || 0,
        totalPositions: posCount || 0,
        activeTasks: taskCount || 0,
        totalContacts: contactCount || 0
      });
    } catch (error) {
      console.error('Error fetching organization stats:', error);
      setFetchError(true);
    } finally {
      setLoading(false);
    }
  };

  const quickStats = [
    {
      title: L("დეპარტამენტები", "Departments"),
      value: fetchError ? "—" : stats.totalDepartments.toString(),
      icon: Building2,
      color: "from-amber-500 to-orange-600",
      bgColor: "bg-amber-500/10",
      trend: L("სტრუქტურა", "Structure"),
      trendUp: true,
      description: L("განყოფილება", "Units")
    },
    {
      title: L("პოზიციები", "Positions"),
      value: fetchError ? "—" : stats.totalPositions.toString(),
      icon: FolderTree,
      color: "from-orange-500 to-red-600",
      bgColor: "bg-orange-500/10",
      trend: L("თანამდებობები", "Job titles"),
      trendUp: true,
      description: L("თანამდებობა", "Roles")
    },
    {
      title: L("აქტიური დავალებები", "Active tasks"),
      value: fetchError ? "—" : stats.activeTasks.toString(),
      icon: ClipboardList,
      color: "from-cyan-500 to-teal-600",
      bgColor: "bg-cyan-500/10",
      trend: stats.activeTasks > 0 ? L("მიმდინარე", "In progress") : L("დასრულებული", "Done"),
      trendUp: true,
      description: L("დავალება", "Tasks")
    },
    {
      title: L("კონტაქტები", "Contacts"),
      value: fetchError ? "—" : stats.totalContacts.toString(),
      icon: Phone,
      color: "from-emerald-500 to-green-600",
      bgColor: "bg-emerald-500/10",
      trend: L("პარტნიორები", "Partners"),
      trendUp: true,
      description: L("პარტნიორი", "Partners")
    }
  ];

  const categories = [
    {
      title: L("კომპანია და სტრუქტურა", "Company and structure"),
      description: L("ის, რასაც ერთხელ აწყობთ: კომპანია, ფილიალები, დეპარტამენტები, პოზიციები", "What you set up once: company, branches, departments, positions"),
      icon: Building2,
      color: "from-amber-400 via-orange-500 to-red-500",
      shadowColor: "shadow-orange-500/25",
      functions: [
        { name: L("კომპანია", "Company"), description: L("რეკვიზიტები, მისამართი, საკონტაქტო პირი", "Details, address, contact person"), url: "/company-settings", icon: Briefcase, stats: L("პარამეტრები", "Settings") },
        { name: L("ფილიალები", "Branches"), description: L("ფილიალების დამატება და მართვა", "Add and manage branches"), url: "/branches", icon: Building2, stats: L("ფილიალები", "Branches") },
        { name: L("ორგანიზაციული სტრუქტურა", "Org structure"), description: L("დეპარტამენტების ხის სქემა და რედაქტირება", "Department tree and editing"), url: "/organizational-structure", icon: Network, stats: L(`${stats.totalDepartments} დეპარტამენტი`, `${stats.totalDepartments} departments`) },
        { name: L("პოზიციები და აღწერილობები", "Positions and descriptions"), description: L("თანამდებობები და მოვალეობები", "Job titles and duties"), url: "/job-descriptions", icon: FileCheck, stats: L(`${stats.totalPositions} პოზიცია`, `${stats.totalPositions} positions`) },
      ]
    },
    {
      title: L("სამუშაო წესები", "Work rules"),
      description: L("გრაფიკები, შვებულების ტიპები და დასვენების დღეები", "Schedules, leave types and holidays"),
      icon: ClipboardList,
      color: "from-cyan-400 via-teal-500 to-emerald-500",
      shadowColor: "shadow-teal-500/25",
      functions: [
        { name: L("გრაფიკის შაბლონები", "Schedule templates"), description: L("ფიქსირებული, საათობრივი და ცვლების შაბლონები", "Fixed, hourly and shift templates"), url: "/schedule-templates", icon: ClipboardList, stats: L("შაბლონები", "Templates") },
        { name: L("შვებულების ტიპები", "Leave types"), description: L("ანაზღაურებადი, ავადმყოფობის, დეკრეტული და სხვა", "Paid, sick, maternity and more"), url: "/leave-types", icon: FolderTree, stats: L("ტიპები", "Types") },
        { name: L("დასვენების დღეები", "Public holidays"), description: L("ოფიციალური უქმე დღეები", "Official days off"), url: "/public-holidays", icon: Target, stats: L("კალენდარი", "Calendar") },
        { name: L("ოფისის ლოკაციები", "Office locations"), description: L("დასწრების გეოლოკაციის წერტილები", "Attendance geolocation points"), url: "/settings?tab=locations", icon: Car, stats: L("ლოკაციები", "Locations") },
      ]
    }
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {fetchError && <HubErrorState onRetry={fetchOrganizationStats} />}
          {/* Header */}
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-400 via-orange-500 to-red-500 shadow-xl shadow-orange-500/30 animate-scale-in">
                <Building2 className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-foreground via-foreground/90 to-foreground/70 bg-clip-text text-transparent">
                  {L("ორგანიზაცია", "Organization")}
                </h1>
                <p className="text-muted-foreground mt-1 text-lg">
                  {L("ორგანიზაციული სტრუქტურისა და პროცესების მართვის სისტემა", "Manage your structure and processes")}
                </p>
              </div>
            </div>
          </div>

          <IndustryTemplatesDialog onSuccess={fetchOrganizationStats} />

          {/* Quick Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {quickStats.map((stat, index) => (
              <Card 
                key={index}
                className={cn(
                  "group relative overflow-hidden border-border/50 bg-card/80 backdrop-blur-xl",
                  "hover:shadow-2xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-2",
                  "animate-fade-in"
                )}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <CardContent className="p-6 relative">
                  <div className="flex items-start justify-between mb-4">
                    <div className={cn(
                      "p-3 rounded-xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-3",
                      stat.bgColor
                    )}>
                      <stat.icon className="h-6 w-6" style={{ color: `hsl(var(--primary))` }} />
                    </div>
                    
                    <div className={cn(
                      "flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full transition-all duration-300",
                      stat.trendUp 
                        ? "text-emerald-600 bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-400" 
                        : "text-amber-600 bg-amber-100 dark:bg-amber-950/50 dark:text-amber-400"
                    )}>
                      {stat.trendUp ? (
                        <ArrowUpRight className="h-3 w-3" />
                      ) : (
                        <ArrowDownRight className="h-3 w-3" />
                      )}
                      <span>{stat.trend}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-2xl md:text-3xl font-bold tracking-tight group-hover:scale-105 transition-transform duration-300 origin-left">
                      {loading ? (
                        <div className="h-8 w-16 bg-muted animate-pulse rounded" />
                      ) : (
                        stat.value
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground font-medium">
                      {stat.title}
                    </div>
                    <div className="text-xs text-muted-foreground/70">
                      {stat.description}
                    </div>
                  </div>

                  <div className={cn(
                    "absolute -right-8 -bottom-8 w-32 h-32 rounded-full blur-3xl opacity-0 group-hover:opacity-30 transition-opacity duration-500",
                    `bg-gradient-to-br ${stat.color}`
                  )} />
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Categories */}
          <div className="space-y-10">
            {categories.map((category, idx) => (
              <div 
                key={idx} 
                className="space-y-6 animate-fade-in"
                style={{ animationDelay: `${(idx + 4) * 100}ms` }}
              >
                {/* Category Header */}
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "p-3 rounded-xl bg-gradient-to-br shadow-xl",
                    category.color,
                    category.shadowColor
                  )}>
                    <category.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl md:text-3xl font-bold text-foreground">{category.title}</h2>
                    <p className="text-sm text-muted-foreground">{category.description}</p>
                  </div>
                </div>

                {/* Function Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
                  {category.functions.map((func, funcIdx) => (
                    <Card
                      key={funcIdx}
                      className={cn(
                        "group cursor-pointer overflow-hidden",
                        "border-border/50 bg-card/80 backdrop-blur-xl",
                        "hover:border-primary/50 transition-all duration-500",
                        "hover:shadow-2xl hover:-translate-y-2",
                        "animate-fade-in"
                      )}
                      style={{ animationDelay: `${(idx * 4 + funcIdx + 5) * 50}ms` }}
                      onClick={(e) => isLocked(func.url) ? handleLockedClick(e) : navigate(func.url)}
                    >
                      {isLocked(func.url) && <FeatureLockOverlay />}
                      <CardHeader className={cn(
                        "bg-gradient-to-br text-white pb-4 relative overflow-hidden",
                        category.color
                      )}>
                        <div className="flex items-center gap-3 relative z-10">
                          <div className="p-2.5 bg-white/20 rounded-xl backdrop-blur-sm group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                            <func.icon className="h-5 w-5" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{func.name}</CardTitle>
                            <span className="text-xs text-white/80">{func.stats}</span>
                          </div>
                        </div>
                        
                        <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700" />
                        <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white/5 rounded-full group-hover:scale-125 transition-transform duration-500" />
                      </CardHeader>
                      
                      <CardContent className="pt-6 relative">
                        <CardDescription className="text-muted-foreground mb-4 min-h-[48px] leading-relaxed">
                          {func.description}
                        </CardDescription>
                        
                        <div className="flex items-center gap-2 text-primary font-semibold text-sm group-hover:gap-4 transition-all duration-300">
                          <span>{L("გახსნა", "Open")}</span>
                          <ArrowRight className="h-4 w-4 group-hover:translate-x-2 transition-transform duration-300" />
                        </div>

                        <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Enhanced Footer Stats */}
          <div 
            className="mt-12 p-6 md:p-8 rounded-2xl bg-gradient-to-r from-primary/5 via-primary/10 to-accent/10 border border-primary/20 backdrop-blur-xl animate-fade-in"
            style={{ animationDelay: '800ms' }}
          >
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-primary/10 animate-pulse">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-lg font-semibold text-foreground">
                    სულ ხელმისაწვდომია <span className="text-2xl font-bold text-primary">{categories.reduce((sum, cat) => sum + cat.functions.length, 0)}</span> ორგანიზაციული ფუნქცია
                  </p>
                  <p className="text-sm text-muted-foreground">
                    მართეთ თქვენი ორგანიზაციის სტრუქტურა ეფექტურად
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-orange-500/10 text-orange-600 dark:text-orange-400">
                  <Building2 className="h-4 w-4" />
                  <span className="text-sm font-medium">{stats.totalDepartments} დეპარტამენტი</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
