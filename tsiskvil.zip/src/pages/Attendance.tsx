import { useState, useEffect } from "react";
import { Plus, Search, Clock, Activity, MapPin, Download, Users, AlertCircle, TrendingUp, MessageSquare, Send } from "lucide-react";
import { XLSX } from '@/lib/xlsxCompat';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { withRetry } from "@/lib/supabaseRetry";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatters } from "@/lib/dateUtils";
import { useRealtime } from "@/hooks/useRealtime";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import { DateErrorBoundary } from "@/components/DateErrorBoundary";

interface Attendance {
  id: string;
  employee_id: string;
  date: string;
  check_in: string | null;
  check_out: string | null;
  status: string;
  notes: string | null;
  check_in_method: string | null;
  check_out_method: string | null;
  check_in_location: string | null;
  check_out_location: string | null;
  employees: {
    full_name: string;
    position: string;
  };
}

interface EmployeeLastActivity {
  employee_id: string;
  employee_name: string;
  employee_number: string;
  employee_avatar: string | null;
  employee_position: string;
  employee_department: string | null;
  last_check_in: string | null;
  last_check_out: string | null;
  last_location: string | null;
  status: "online" | "offline" | "unknown";
}

export default function Attendance() {
  const { user, userRole } = useAuth();
  const { t } = useLanguage();
  const [attendances, setAttendances] = useState<Attendance[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDepartment, setSelectedDepartment] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [activities, setActivities] = useState<EmployeeLastActivity[]>([]);
  const [loadingActivities, setLoadingActivities] = useState(false);
  const [sendingSmsTo, setSendingSmsTo] = useState<string | null>(null);
  const [smsDialogOpen, setSmsDialogOpen] = useState(false);
  const [smsMessage, setSmsMessage] = useState('გთხოვთ შეხვიდეთ სისტემაში და დააფიქსიროთ დასწრება.');
  const [selectedEmployeesForSms, setSelectedEmployeesForSms] = useState<string[]>([]);

  const canManage = userRole === 'admin' || userRole === 'hr_manager';
  const activeBranchId = useBranchFilter();

  useEffect(() => {
    fetchAttendances();
    fetchEmployees();
    fetchDepartments();
  }, [selectedDate, activeBranchId]);

  useEffect(() => {
    fetchLastActivities();
  }, [activeBranchId]);

  // Use centralized Realtime hook
  useRealtime({
    table: 'attendance',
    event: '*',
    onChange: (payload) => {
      fetchAttendances();
      fetchLastActivities();
    },
  });

  const fetchEmployees = async () => {
    try {
      let q = supabase
        .from('employees')
        .select('id, full_name, position, department, phone')
        .eq('status', 'active');
      if (activeBranchId) q = q.eq('branch_id', activeBranchId);
      const { data, error } = await q;
      
      if (error) throw error;
      setEmployees(data || []);
    } catch (error: any) {
      console.error('Error fetching employees:', error);
    }
  };

  const fetchDepartments = async () => {
    try {
      const { data, error } = await supabase
        .from('departments')
        .select('id, name')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      setDepartments(data || []);
    } catch (error: any) {
      console.error('Error fetching departments:', error);
    }
  };

  const fetchAttendances = async () => {
    try {
      let q = supabase
        .from('attendance')
        .select(`
          *,
          employees(full_name, position)
        `)
        .gte('date', selectedDate)
        .lte('date', selectedDate)
        .order('date', { ascending: false });
      if (activeBranchId) q = q.eq('branch_id', activeBranchId);
      const { data, error } = await q;

      if (error) throw error;
      setAttendances(data || []);
    } catch (error: any) {
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    }
  };

  const fetchLastActivities = async () => {
    try {
      setLoadingActivities(true);
      let empQ = supabase
        .from("employees")
        .select("id, full_name, employee_number, avatar_url, position, department")
        .eq("status", "active")
        .order("full_name");
      if (activeBranchId) empQ = empQ.eq('branch_id', activeBranchId);
      const { data: employees, error: empError } = await empQ;

      if (empError) throw empError;

      let attQ = supabase
        .from("attendance")
        .select("employee_id, check_in, check_out, check_in_location, date")
        .gte("date", new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0])
        .order("date", { ascending: false });
      if (activeBranchId) attQ = attQ.eq('branch_id', activeBranchId);
      const { data: attendance, error: attError } = await attQ;

      if (attError) throw attError;

      const latestAttendance = (employees || []).map((emp) => {
        const empAttendance = (attendance || [])
          .filter((a) => a.employee_id === emp.id)
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

        const lastCheckIn = empAttendance?.check_in;
        const lastCheckOut = empAttendance?.check_out;
        
        let status: "online" | "offline" | "unknown" = "unknown";
        if (lastCheckIn && !lastCheckOut) {
          status = "online";
        } else if (lastCheckOut) {
          status = "offline";
        }

        return {
          employee_id: emp.id,
          employee_name: emp.full_name,
          employee_number: emp.employee_number || "-",
          employee_avatar: emp.avatar_url,
          employee_position: emp.position || "-",
          employee_department: emp.department || null,
          last_check_in: lastCheckIn,
          last_check_out: lastCheckOut,
          last_location: empAttendance?.check_in_location || null,
          status,
        };
      });

      setActivities(latestAttendance);
    } catch (error: any) {
      toast.error("აქტივობების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoadingActivities(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const payload = {
        employee_id: formData.get('employee_id') as string,
        date: formData.get('date') as string,
        check_in: formData.get('check_in') as string || null,
        check_out: formData.get('check_out') as string || null,
        status: formData.get('status') as string,
        notes: formData.get('notes') as string || null,
        created_by: user?.id,
      };

      const { error } = await withRetry(() =>
        supabase
          .from('attendance')
          .insert([payload])
          .select()
      );

      if (error) throw error;
      toast.success(t('attendance.attendanceAdded'));
      setIsDialogOpen(false);
      fetchAttendances();
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const filteredAttendances = attendances.filter((att) => {
    const matchesSearch = att.employees?.full_name?.toLowerCase().includes(searchQuery.toLowerCase());
    const emp = employees.find(e => e.id === att.employee_id);
    const matchesDepartment = selectedDepartment === "all" || emp?.department === selectedDepartment;
    const matchesStatus = selectedStatus === "all" || att.status === selectedStatus;
    return matchesSearch && matchesDepartment && matchesStatus;
  });

  const filteredActivities = activities.filter((activity) => {
    const matchesSearch =
      activity.employee_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      activity.employee_number.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDepartment = selectedDepartment === "all" || activity.employee_department === selectedDepartment;
    const matchesActivityStatus = selectedStatus === "all" || activity.status === selectedStatus;
    return matchesSearch && matchesDepartment && matchesActivityStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present': return 'bg-green-100 text-green-700';
      case 'absent': return 'bg-red-100 text-red-700';
      case 'late': return 'bg-yellow-100 text-yellow-700';
      case 'half_day': return 'bg-blue-100 text-blue-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'present': return t('attendance.present');
      case 'absent': return t('attendance.absent');
      case 'late': return t('attendance.late');
      case 'half_day': return t('attendance.halfDay');
      default: return status;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "online":
        return <Badge className="bg-green-500">აქტიური</Badge>;
      case "offline":
        return <Badge variant="secondary">არააქტიური</Badge>;
      default:
        return <Badge variant="outline">უცნობი</Badge>;
    }
  };

  const getTimeDifference = (time: string | null) => {
    if (!time) return "-";
    const now = new Date();
    const activityTime = new Date(time);
    
    // Check if date is valid
    if (isNaN(activityTime.getTime())) return "-";
    
    const diffMs = now.getTime() - activityTime.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "ახლახან";
    if (diffMins < 60) return `${diffMins} წთ წინ`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} სთ წინ`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} დღის წინ`;
  };

  const exportToExcel = () => {
    const data = filteredAttendances.map(att => ({
      'თარიღი': att.date,
      'დღე': new Date(att.date).toLocaleDateString('ka-GE', { weekday: 'long' }),
      'თანამშრომელი': att.employees?.full_name,
      'პოზიცია': att.employees?.position,
      'შემოსვლა': att.check_in || '-',
      'გასვლა': att.check_out || '-',
      'შესვენების დაწყება': (att as any).break_start || '-',
      'შესვენების დასრულება': (att as any).break_end || '-',
      'სამუშაოს დასრული': att.check_out || '-',
      'სტატუსი': getStatusText(att.status),
      'დაგვიანების კომენტარი': (att as any).lateness_comment || '-',
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'დასწრების ისტორია');
    XLSX.writeFile(wb, `დასწრება_${selectedDate}.xlsx`);
    toast.success('ექსპორტი წარმატებით განხორციელდა');
  };

  const sendSmsReminder = async (employeeId: string, phone: string, name: string) => {
    if (!phone) {
      toast.error('თანამშრომელს არ აქვს ტელეფონის ნომერი');
      return;
    }

    setSendingSmsTo(employeeId);
    try {
      const { data, error } = await supabase.functions.invoke('send-cloudsms', {
        body: {
          to: phone,
          message: smsMessage
        }
      });

      if (error) throw error;
      toast.success(`SMS გაიგზავნა: ${name}`);
    } catch (error: any) {
      console.error('SMS error:', error);
      toast.error('SMS-ის გაგზავნა ვერ მოხერხდა');
    } finally {
      setSendingSmsTo(null);
    }
  };

  const sendBulkSmsReminder = async () => {
    const absentEmployees = activities.filter(a => 
      a.status === 'offline' || a.status === 'unknown'
    );

    if (absentEmployees.length === 0) {
      toast.error('არდასწრებული თანამშრომლები ვერ მოიძებნა');
      return;
    }

    const employeesWithPhones = absentEmployees.filter(a => {
      const emp = employees.find(e => e.id === a.employee_id);
      return emp?.phone;
    });

    if (employeesWithPhones.length === 0) {
      toast.error('თანამშრომლებს არ აქვთ ტელეფონის ნომრები');
      return;
    }

    let successCount = 0;
    let errorCount = 0;

    for (const activity of employeesWithPhones) {
      const emp = employees.find(e => e.id === activity.employee_id);
      if (!emp?.phone) continue;

      try {
        await supabase.functions.invoke('send-cloudsms', {
          body: {
            to: emp.phone,
            message: smsMessage
          }
        });
        successCount++;
      } catch (error) {
        errorCount++;
      }
    }

    if (successCount > 0) {
      toast.success(`${successCount} SMS გაიგზავნა წარმატებით`);
    }
    if (errorCount > 0) {
      toast.error(`${errorCount} SMS ვერ გაიგზავნა`);
    }
    setSmsDialogOpen(false);
  };

  const stats = {
    totalEmployees: activities.length,
    presentToday: activities.filter((a) => a.status === "online").length,
    absent: activities.filter((a) => a.status === "offline").length,
    lateToday: activities.filter((a) => a.status === "unknown").length,
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
            დასწრება & აქტივობა
          </h1>
          <p className="text-muted-foreground text-lg">თანამშრომლების დასწრების მონიტორინგი რეალურ დროში</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {canManage && (
            <Dialog open={smsDialogOpen} onOpenChange={setSmsDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="gap-2 shadow-md hover:shadow-lg transition-all bg-gradient-to-r from-green-500/10 to-green-600/10 border-green-500/30 text-green-700 dark:text-green-400 hover:from-green-500/20 hover:to-green-600/20">
                  <MessageSquare className="h-4 w-4" />
                  SMS შეხსენება
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>SMS შეხსენების გაგზავნა</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>შეტყობინების ტექსტი</Label>
                    <Textarea
                      value={smsMessage}
                      onChange={(e) => setSmsMessage(e.target.value)}
                      placeholder="შეიყვანეთ შეტყობინება..."
                      className="mt-1"
                      rows={3}
                    />
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-2">
                      SMS გაიგზავნება არდასწრებულ თანამშრომლებთან ({stats.absent + stats.lateToday} თანამშრომელი)
                    </p>
                  </div>
                  <Button 
                    onClick={sendBulkSmsReminder} 
                    className="w-full gap-2"
                    disabled={stats.absent + stats.lateToday === 0}
                  >
                    <Send className="h-4 w-4" />
                    გაგზავნა ყველასთან
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
          <Button onClick={exportToExcel} variant="outline" className="gap-2 shadow-md hover:shadow-lg transition-all">
            <Download className="h-4 w-4" />
            ექსპორტი
          </Button>
          {canManage && (
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2 shadow-lg hover:shadow-xl transition-all">
                  <Plus className="h-4 w-4" />
                  {t('attendance.addAttendance')}
                </Button>
              </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t('attendance.addAttendance')}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="employee_id">{t('attendance.employee')} *</Label>
                  <Select name="employee_id" required>
                    <SelectTrigger>
                      <SelectValue placeholder={t('common.search')} />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.full_name} - {emp.position}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="date">{t('attendance.date')} *</Label>
                  <Input id="date" name="date" type="date" required defaultValue={selectedDate} />
                </div>
                <div>
                  <Label htmlFor="check_in">{t('attendance.checkIn')}</Label>
                  <Input id="check_in" name="check_in" type="time" />
                </div>
                <div>
                  <Label htmlFor="check_out">{t('attendance.checkOut')}</Label>
                  <Input id="check_out" name="check_out" type="time" />
                </div>
                <div>
                  <Label htmlFor="status">{t('attendance.status')} *</Label>
                  <Select name="status" required defaultValue="present">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="present">{t('attendance.present')}</SelectItem>
                      <SelectItem value="absent">{t('attendance.absent')}</SelectItem>
                      <SelectItem value="late">{t('attendance.late')}</SelectItem>
                      <SelectItem value="half_day">{t('attendance.halfDay')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="notes">{t('attendance.notes')}</Label>
                  <Textarea id="notes" name="notes" placeholder={t('attendance.notesPlaceholder')} />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? t('common.loading') : t('common.save')}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
          )}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-none shadow-lg hover:shadow-xl transition-all bg-gradient-to-br from-background to-muted/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">სულ თანამშრომლები</CardTitle>
            <div className="p-2 bg-primary/10 rounded-lg">
              <Users className="h-5 w-5 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{stats.totalEmployees}</div>
            <p className="text-xs text-muted-foreground mt-1">აქტიური მომხმარებლები</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg hover:shadow-xl transition-all bg-gradient-to-br from-green-50 to-green-100/50 dark:from-green-950/20 dark:to-green-900/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">ოფისში</CardTitle>
            <div className="p-2 bg-green-500/10 rounded-lg">
              <Clock className="h-5 w-5 text-green-600 dark:text-green-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600 dark:text-green-400">{stats.presentToday}</div>
            <p className="text-xs text-muted-foreground mt-1">დღეს დასწრებული</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg hover:shadow-xl transition-all bg-gradient-to-br from-orange-50 to-orange-100/50 dark:from-orange-950/20 dark:to-orange-900/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">გარეთ</CardTitle>
            <div className="p-2 bg-orange-500/10 rounded-lg">
              <MapPin className="h-5 w-5 text-orange-600 dark:text-orange-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600 dark:text-orange-400">{stats.absent}</div>
            <p className="text-xs text-muted-foreground mt-1">ამჟამად არდასწრებული</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg hover:shadow-xl transition-all bg-gradient-to-br from-red-50 to-red-100/50 dark:from-red-950/20 dark:to-red-900/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">უცნობი სტატუსი</CardTitle>
            <div className="p-2 bg-red-500/10 rounded-lg">
              <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600 dark:text-red-400">{stats.lateToday}</div>
            <p className="text-xs text-muted-foreground mt-1">აქტივობის გარეშე</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="realtime" className="w-full">
        <TabsList className="grid w-full grid-cols-2 h-12 bg-muted/50 p-1">
          <TabsTrigger value="realtime" className="gap-2 data-[state=active]:bg-background data-[state=active]:shadow-md transition-all">
            <Activity className="h-4 w-4" />
            რეალურ დროში
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2 data-[state=active]:bg-background data-[state=active]:shadow-md transition-all">
            <Clock className="h-4 w-4" />
            ისტორია
          </TabsTrigger>
        </TabsList>

        {/* Real-time Activity Tab */}
        <TabsContent value="realtime" className="space-y-4 mt-6">
          <Card className="border-none shadow-xl">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10 border-b">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <CardTitle className="text-xl">რეალურ დროში აქტივობა</CardTitle>
                <div className="flex items-center gap-3 flex-1 justify-end flex-wrap">
                  <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="დეპარტამენტი" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                      {departments.map((dept) => (
                        <SelectItem key={dept.id} value={dept.name}>
                          {dept.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                    <SelectTrigger className="w-[160px]">
                      <SelectValue placeholder="სტატუსი" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა სტატუსი</SelectItem>
                      <SelectItem value="online">აქტიური</SelectItem>
                      <SelectItem value="offline">არააქტიური</SelectItem>
                      <SelectItem value="unknown">უცნობი</SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="ძიება თანამშრომლის მიხედვით..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>თანამშრომელი</TableHead>
                    <TableHead>პოზიცია</TableHead>
                    <TableHead>სტატუსი</TableHead>
                    <TableHead>ბოლო შესვლა</TableHead>
                    <TableHead>ბოლო გასვლა</TableHead>
                    {canManage && <TableHead className="text-right">მოქმედება</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredActivities.map((activity) => (
                    <TableRow key={activity.employee_id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={activity.employee_avatar || ""} />
                            <AvatarFallback>
                              {activity.employee_name.split(" ").map((n) => n[0]).join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{activity.employee_name}</div>
                            <div className="text-sm text-muted-foreground">
                              #{activity.employee_number}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{activity.employee_position}</TableCell>
                      <TableCell>{getStatusBadge(activity.status)}</TableCell>
                      <TableCell>
                        {activity.last_check_in ? (
                          <div>
                            <div className="font-medium">
                              {formatters.time24(activity.last_check_in)}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {getTimeDifference(activity.last_check_in)}
                            </div>
                          </div>
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      <TableCell>
                        {activity.last_check_out ? (
                          <div>
                            <div className="font-medium">
                              {formatters.time24(activity.last_check_out)}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {getTimeDifference(activity.last_check_out)}
                            </div>
                          </div>
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      {canManage && (
                        <TableCell className="text-right">
                          {(activity.status === 'offline' || activity.status === 'unknown') && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="gap-1 text-green-600 hover:text-green-700 hover:bg-green-50"
                              disabled={sendingSmsTo === activity.employee_id}
                              onClick={() => {
                                const emp = employees.find(e => e.id === activity.employee_id);
                                if (emp?.phone) {
                                  sendSmsReminder(activity.employee_id, emp.phone, activity.employee_name);
                                } else {
                                  toast.error('ტელეფონის ნომერი არ არის');
                                }
                              }}
                            >
                              {sendingSmsTo === activity.employee_id ? (
                                <span className="animate-spin">⏳</span>
                              ) : (
                                <MessageSquare className="h-4 w-4" />
                              )}
                              SMS
                            </Button>
                          )}
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="space-y-4 mt-6">
          <Card className="border-none shadow-xl">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10 border-b">
              <div className="flex flex-col sm:flex-row gap-4 items-center flex-wrap">
                <CardTitle className="text-xl">დასწრების ისტორია</CardTitle>
                <div className="flex items-center gap-3 flex-1 flex-wrap">
                  <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="დეპარტამენტი" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                      {departments.map((dept) => (
                        <SelectItem key={dept.id} value={dept.name}>
                          {dept.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                    <SelectTrigger className="w-[160px]">
                      <SelectValue placeholder="სტატუსი" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა სტატუსი</SelectItem>
                      <SelectItem value="present">დასწრებული</SelectItem>
                      <SelectItem value="absent">არდასწრებული</SelectItem>
                      <SelectItem value="late">დაგვიანებული</SelectItem>
                      <SelectItem value="half_day">ნახევარი დღე</SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="relative flex-1 min-w-[200px]">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder={t('common.search')}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-[180px]"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t('attendance.employee')}</TableHead>
                    <TableHead>თარიღი</TableHead>
                    <TableHead>დღე</TableHead>
                    <TableHead>შემოსვლა</TableHead>
                    <TableHead>გასვლა</TableHead>
                    <TableHead>შესვენების დაწყება</TableHead>
                    <TableHead>შესვენების დასრულება</TableHead>
                    <TableHead>სამუშაოს დასრული</TableHead>
                    <TableHead>დაგვიანების კომენტარი</TableHead>
                    <TableHead>{t('attendance.status')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAttendances.map((attendance) => (
                    <TableRow key={attendance.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{attendance.employees?.full_name}</div>
                          <div className="text-sm text-muted-foreground">{attendance.employees?.position}</div>
                        </div>
                      </TableCell>
                      <TableCell>{new Date(attendance.date).toLocaleDateString('ka-GE')}</TableCell>
                      <TableCell>
                        {new Date(attendance.date).toLocaleDateString('ka-GE', { weekday: 'long' })}
                      </TableCell>
                      <TableCell>
                        {attendance.check_in ? (
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-green-600" />
                            {attendance.check_in}
                          </div>
                        ) : '-'}
                      </TableCell>
                      <TableCell>
                        {attendance.check_out ? (
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-red-600" />
                            {attendance.check_out}
                          </div>
                        ) : '-'}
                      </TableCell>
                      <TableCell>
                        {(attendance as any).break_start || '-'}
                      </TableCell>
                      <TableCell>
                        {(attendance as any).break_end || '-'}
                      </TableCell>
                      <TableCell>
                        {attendance.check_out || '-'}
                      </TableCell>
                      <TableCell className="max-w-xs">
                        {(attendance as any).lateness_comment || '-'}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(attendance.status)}>
                          {getStatusText(attendance.status)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
