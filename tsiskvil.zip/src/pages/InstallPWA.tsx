import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Smartphone, CheckCircle, Bot } from "lucide-react";
import { toast } from "sonner";
import { useLanguage } from "@/contexts/LanguageContext";
const APK_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/download-apk`;

export default function InstallPWA() {
  const { t } = useLanguage();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      toast.success(t('install.installed'));
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, [t]);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      toast.success(t('install.installBtn'));
    }
    setDeferredPrompt(null);
    setIsInstallable(false);
  };

  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const isAndroid = /Android/.test(navigator.userAgent);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-b from-primary/5 to-background">
      <div className="max-w-md w-full space-y-6">
        {/* Android APK download card */}
        <Card className="border-primary/30 shadow-lg">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <Bot className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl">{t('install.androidApp')}</CardTitle>
            <CardDescription>{t('install.androidDesc')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <Button asChild className="w-full gap-2" size="lg">
              <a href={APK_URL}>
                <Download className="h-5 w-5" />
                {t('install.downloadApk')}
              </a>
            </Button>
            <p className="text-center text-xs text-muted-foreground">{t('install.apkSize')}</p>

            <div className="border-t pt-4 space-y-2">
              <h4 className="font-semibold text-sm">{t('install.apkStepsTitle')}</h4>
              <ol className="space-y-1.5 text-sm text-muted-foreground">
                <li>1. {t('install.apkStep1')}</li>
                <li>2. {t('install.apkStep2')}</li>
                <li>3. {t('install.apkStep3')}</li>
                <li>4. {t('install.apkStep4')}</li>
              </ol>
            </div>
          </CardContent>
        </Card>

        {/* PWA / browser install card */}
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
              <Smartphone className="h-7 w-7 text-primary" />
            </div>
            <CardTitle className="text-xl">{t('install.title')}</CardTitle>
            <CardDescription>{t('install.subtitle')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {isInstalled ? (
              <div className="text-center space-y-4">
                <div className="flex justify-center">
                  <CheckCircle className="h-16 w-16 text-green-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">{t('install.installed')}</h3>
                  <p className="text-muted-foreground">{t('install.installedDesc')}</p>
                </div>
              </div>
            ) : (
              <>
                {isInstallable && !isIOS && (
                  <Button onClick={handleInstall} variant="outline" className="w-full gap-2" size="lg">
                    <Download className="h-5 w-5" />
                    {t('install.installBtn')}
                  </Button>
                )}

                {isIOS && (
                  <div className="space-y-4">
                    <h3 className="font-semibold">{t('install.iosTitle')}</h3>
                    <ol className="space-y-2 text-sm text-muted-foreground">
                      <li>1. {t('install.iosStep1')} <span className="inline-block">⬆️</span></li>
                      <li>2. {t('install.iosStep2')}</li>
                      <li>3. {t('install.iosStep3')}</li>
                      <li>4. {t('install.iosStep4')}</li>
                    </ol>
                  </div>
                )}

                {isAndroid && !isInstallable && (
                  <div className="space-y-4">
                    <h3 className="font-semibold">{t('install.pwaTitle')}</h3>
                    <ol className="space-y-2 text-sm text-muted-foreground">
                      <li>1. {t('install.pwaStep1')}</li>
                      <li>2. {t('install.pwaStep2')}</li>
                      <li>3. {t('install.pwaStep3')}</li>
                      <li>4. {t('install.pwaStep4')}</li>
                    </ol>
                  </div>
                )}

                <div className="border-t pt-4 space-y-2">
                  <h4 className="font-semibold text-sm">{t('install.whyTitle')}</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>✓ {t('install.why1')}</li>
                    <li>✓ {t('install.why2')}</li>
                    <li>✓ {t('install.why3')}</li>
                    <li>✓ {t('install.why4')}</li>
                  </ul>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
