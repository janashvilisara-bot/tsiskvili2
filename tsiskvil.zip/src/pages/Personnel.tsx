import { useState, useEffect } from "react";
import { useFeatureLock, FeatureLockOverlay } from "@/components/FeatureCardLock";
import { 
  Users,
  CalendarCheck,
  Calendar,
  Plane,
  Clock,
  FileText,
  Cog,
  CalendarDays,
  PartyPopper,
  Smartphone,
  Activity,
  ArrowRight,
  Sparkles,
  UserCheck,
  MessageCircle,
  Video,
  ArrowUpRight,
  ArrowDownRight,
  UserPlus,
  Timer,
  ClipboardList,
  FileSignature,
  Building2
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import HubErrorState from "@/components/HubErrorState";
import { cn } from "@/lib/utils";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import { useBranch } from "@/contexts/BranchContext";

interface PersonnelStats {
  totalEmployees: number;
  activeEmployees: number;
  pendingLeaves: number;
  todayAttendance: number;
  totalDepartments: number;
}

export default function Personnel() {
  const navigate = useNavigate();
  const { isLocked, handleLockedClick } = useFeatureLock();
  const [stats, setStats] = useState<PersonnelStats>({
    totalEmployees: 0,
    activeEmployees: 0,
    pendingLeaves: 0,
    todayAttendance: 0,
    totalDepartments: 0
  });
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState(false);
  const activeBranchId = useBranchFilter();
  const {
    branches,
    activeBranch,
    canViewAll,
    setActiveBranchId,
    isLoading: branchesLoading,
  } = useBranch();

  useEffect(() => {
    fetchPersonnelStats();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeBranchId]);

  const fetchPersonnelStats = async () => {
    try {
      const applyBranch = (q: any) => activeBranchId ? q.eq('branch_id', activeBranchId) : q;

      // Fetch total employees
      const { count: totalCount } = await applyBranch(
        supabase.from('employees').select('*', { count: 'exact', head: true })
      );

      // Fetch active employees
      const { count: activeCount } = await applyBranch(
        supabase.from('employees').select('*', { count: 'exact', head: true }).eq('status', 'active')
      );

      // Fetch pending leave requests
      const { count: pendingCount } = await applyBranch(
        supabase.from('leave_requests').select('*', { count: 'exact', head: true }).eq('status', 'pending')
      );

      // Fetch today's attendance
      const today = new Date().toISOString().split('T')[0];
      const { count: attendanceCount } = await applyBranch(
        supabase.from('attendance').select('*', { count: 'exact', head: true }).eq('date', today).not('check_in', 'is', null)
      );

      // Fetch total departments
      const { count: departmentsCount } = await applyBranch(
        supabase.from('departments').select('*', { count: 'exact', head: true })
      );

      setStats({
        totalEmployees: totalCount || 0,
        activeEmployees: activeCount || 0,
        pendingLeaves: pendingCount || 0,
        todayAttendance: attendanceCount || 0,
        totalDepartments: departmentsCount || 0
      });
    } catch (error) {
      console.error('Error fetching personnel stats:', error);
      setFetchError(true);
    } finally {
      setLoading(false);
    }
  };

  const quickStats = [
    {
      title: "სულ თანამშრომელი",
      value: stats.totalEmployees.toString(),
      icon: Users,
      color: "from-blue-500 to-indigo-600",
      bgColor: "bg-blue-500/10",
      trend: "+5",
      trendUp: true,
      description: "თანამშრომელი"
    },
    {
      title: "აქტიური",
      value: stats.activeEmployees.toString(),
      icon: UserCheck,
      color: "from-emerald-500 to-green-600",
      bgColor: "bg-emerald-500/10",
      trend: `${stats.totalEmployees > 0 ? Math.round((stats.activeEmployees / stats.totalEmployees) * 100) : 0}%`,
      trendUp: true,
      description: "თანამშრომელი"
    },
    {
      title: "მომლოდინე შვებულებები",
      value: stats.pendingLeaves.toString(),
      icon: Calendar,
      color: "from-orange-500 to-amber-600",
      bgColor: "bg-orange-500/10",
      trend: stats.pendingLeaves > 0 ? "საჭიროებს ყურადღებას" : "დასრულებული",
      trendUp: stats.pendingLeaves === 0,
      description: "მოთხოვნა"
    },
    {
      title: "დღევანდელი დასწრება",
      value: stats.todayAttendance.toString(),
      icon: CalendarCheck,
      color: "from-cyan-500 to-teal-600",
      bgColor: "bg-cyan-500/10",
      trend: `${stats.activeEmployees > 0 ? Math.round((stats.todayAttendance / stats.activeEmployees) * 100) : 0}%`,
      trendUp: true,
      description: "თანამშრომელი"
    }
  ];

  const categories = [
    {
      title: "ძირითადი ფუნქციები",
      description: "თანამშრომლების მართვა და დასწრება",
      icon: Users,
      color: "from-blue-400 via-indigo-500 to-violet-500",
      shadowColor: "shadow-indigo-500/25",
      functions: [
        { 
          name: "თანამშრომლები", 
          description: "თანამშრომლების მონაცემების მართვა",
          url: "/employees",
          icon: Users,
          stats: `${stats.totalEmployees} სულ`
        },
        { 
          name: "თანამშრომელთა დირექტორია", 
          description: "სახელი და დეპარტამენტი (ხელმისაწვდომი ყველასთვის)",
          url: "/employee-directory",
          icon: Users,
          stats: `${stats.activeEmployees} აქტიური`
        },
        { 
          name: "ორგანიზაციული სტრუქტურა", 
          description: "დეპარტამენტების, პოზიციების და ბიუჯეტების მართვა",
          url: "/organizational-structure",
          icon: Building2,
          stats: `${stats.totalDepartments} დეპარტამენტი`
        },
        { 
          name: "დასწრება", 
          description: "დასწრების აღრიცხვა და მონიტორინგი",
          url: "/attendance",
          icon: CalendarCheck,
          stats: `${stats.todayAttendance} დღეს`
        },
        { 
          name: "შვებულებები", 
          description: "შვებულებების მოთხოვნები და მართვა",
          url: "/leave-requests",
          icon: Calendar,
          stats: `${stats.pendingLeaves} მომლოდინე`
        },
        { 
          name: "მივლინებები", 
          description: "სამსახურეობრივი მივლინებების მართვა",
          url: "/business-trip-requests",
          icon: Plane,
          stats: "მოთხოვნები"
        },
        { 
          name: "ზეგანაკვეთური", 
          description: "ზეგანაკვეთური სამუშაოს მოთხოვნები",
          url: "/overtime-requests",
          icon: Clock,
          stats: "მოთხოვნები"
        },
        { 
          name: "დოკუმენტები", 
          description: "დოკუმენტების მართვა და ხელმოწერა",
          url: "/documents",
          icon: FileText,
          stats: "დოკუმენტები"
        },
      ]
    },
    {
      title: "გრაფიკები",
      description: "სამუშაო გრაფიკებისა და დროის მართვა",
      icon: Calendar,
      color: "from-violet-400 via-purple-500 to-pink-500",
      shadowColor: "shadow-purple-500/25",
      functions: [
        { 
          name: "სამუშაო გრაფიკები", 
          description: "თანამშრომლების სამუშაო გრაფიკების მართვა",
          url: "/work-schedules",
          icon: Calendar,
          stats: "გრაფიკები"
        },
        { 
          name: "გრაფიკების შაბლონები", 
          description: "გრაფიკების შაბლონების შექმნა და რედაქტირება",
          url: "/schedule-templates",
          icon: Cog,
          stats: "შაბლონები"
        },
        { 
          name: "ცვლების გრაფიკი", 
          description: "ცვლების დაგეგმვა და მართვა",
          url: "/shift-schedules",
          icon: CalendarDays,
          stats: "ცვლები"
        },
        { 
          name: "დასვენების დღეები", 
          description: "საჯარო დასვენების დღეების კალენდარი",
          url: "/public-holidays",
          icon: PartyPopper,
          stats: "კალენდარი"
        },
      ]
    },
    {
      title: "აღრიცხვა",
      description: "დროის აღრიცხვა და ანალიტიკა",
      icon: Clock,
      color: "from-teal-400 via-emerald-500 to-green-500",
      shadowColor: "shadow-emerald-500/25",
      functions: [
        { 
          name: "სამუშაო დროის აღრიცხვა", 
          description: "სამუშაო დროის დეტალური აღრიცხვა",
          url: "/work-time-tracking",
          icon: Timer,
          stats: "აღრიცხვა"
        },
        { 
          name: "მობილური აღრიცხვა", 
          description: "მობილურიდან დასწრების აღრიცხვა",
          url: "/mobile-attendance",
          icon: Smartphone,
          stats: "მობილური"
        },
        { 
          name: "დასწრების ანალიტიკა", 
          description: "დასწრების ანალიზი და სტატისტიკა",
          url: "/attendance-analytics",
          icon: Activity,
          stats: "ანალიტიკა"
        },
        { 
          name: "სამუშაო დროის ფორმები", 
          description: "სამუშაო დროის ფორმების გენერატორი",
          url: "/work-time-form-generator",
          icon: FileText,
          stats: "ფორმები"
        },
      ]
    },
    {
      title: "კომუნიკაცია",
      description: "შიდა კომუნიკაცია და მესენჯერი",
      icon: MessageCircle,
      color: "from-cyan-400 via-sky-500 to-blue-500",
      shadowColor: "shadow-sky-500/25",
      functions: [
        { 
          name: "მესენჯერი", 
          description: "რეალ-ტაიმ ჩატი თანამშრომლებთან",
          url: "/chat",
          icon: MessageCircle,
          stats: "ჩატი"
        },
        { 
          name: "დავალებები", 
          description: "Kanban დაფა და პროექტების მართვა",
          url: "/tasks",
          icon: ClipboardList,
          stats: "დავალებები"
        },
        { 
          name: "Signify ხელმოწერა", 
          description: "ელექტრონული ხელმოწერის ინტეგრაცია",
          url: "/signify-integration",
          icon: FileSignature,
          stats: "ხელმოწერა"
        },
      ]
    }
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {fetchError && <HubErrorState onRetry={fetchPersonnelStats} />}
          {/* Header */}
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-400 via-indigo-500 to-violet-500 shadow-xl shadow-indigo-500/30 animate-scale-in">
                <Users className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-foreground via-foreground/90 to-foreground/70 bg-clip-text text-transparent">
                  პერსონალი
                </h1>
                <p className="text-muted-foreground mt-1 text-lg">
                  თანამშრომლების მართვისა და დასწრების სისტემა
                </p>
              </div>
            </div>
          </div>

          {/* Branch List */}
          <section className="space-y-3 animate-fade-in" aria-label="ფილიალების ჩამონათვალი">
            <div className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold text-foreground">ფილიალები</h2>
            </div>
            {branchesLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {[1, 2, 3].map((item) => (
                  <div key={item} className="h-20 rounded-xl border border-border/50 bg-card/80 animate-pulse" />
                ))}
              </div>
            ) : branches.length === 0 ? (
              <div className="rounded-xl border border-border/50 bg-card/80 px-4 py-5 text-sm text-muted-foreground">
                ფილიალი ვერ მოიძებნა
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {canViewAll && (
                  <button
                    type="button"
                    onClick={() => setActiveBranchId(null)}
                    className={cn(
                      "rounded-xl border bg-card/80 p-4 text-left transition-all hover:border-primary/50 hover:bg-primary/5",
                      activeBranch === null ? "border-primary ring-1 ring-primary/30" : "border-border/50"
                    )}
                  >
                    <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                      <Building2 className="h-4 w-4 text-primary" />
                      ყველა ფილიალი
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">სრული ხედი</p>
                  </button>
                )}
                {branches.map((branch) => (
                  <button
                    type="button"
                    key={branch.id}
                    onClick={() => setActiveBranchId(branch.id)}
                    className={cn(
                      "rounded-xl border bg-card/80 p-4 text-left transition-all hover:border-primary/50 hover:bg-primary/5",
                      activeBranch?.id === branch.id ? "border-primary ring-1 ring-primary/30" : "border-border/50"
                    )}
                  >
                    <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                      <Building2 className="h-4 w-4 text-primary" />
                      <span className="truncate">{branch.name}</span>
                    </div>
                    <p className="mt-1 truncate text-xs text-muted-foreground">
                      {branch.city || branch.code || "ფილიალი"}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </section>

          {/* Quick Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {quickStats.map((stat, index) => (
              <Card 
                key={index}
                className={cn(
                  "group relative overflow-hidden border-border/50 bg-card/80 backdrop-blur-xl",
                  "hover:shadow-2xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-2",
                  "animate-fade-in"
                )}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <CardContent className="p-6 relative">
                  <div className="flex items-start justify-between mb-4">
                    <div className={cn(
                      "p-3 rounded-xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-3",
                      stat.bgColor
                    )}>
                      <stat.icon className="h-6 w-6" style={{ color: `hsl(var(--primary))` }} />
                    </div>
                    
                    <div className={cn(
                      "flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full transition-all duration-300",
                      stat.trendUp 
                        ? "text-emerald-600 bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-400" 
                        : "text-amber-600 bg-amber-100 dark:bg-amber-950/50 dark:text-amber-400"
                    )}>
                      {stat.trendUp ? (
                        <ArrowUpRight className="h-3 w-3" />
                      ) : (
                        <ArrowDownRight className="h-3 w-3" />
                      )}
                      <span>{stat.trend}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-2xl md:text-3xl font-bold tracking-tight group-hover:scale-105 transition-transform duration-300 origin-left">
                      {loading ? (
                        <div className="h-8 w-16 bg-muted animate-pulse rounded" />
                      ) : (
                        stat.value
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground font-medium">
                      {stat.title}
                    </div>
                    <div className="text-xs text-muted-foreground/70">
                      {stat.description}
                    </div>
                  </div>

                  <div className={cn(
                    "absolute -right-8 -bottom-8 w-32 h-32 rounded-full blur-3xl opacity-0 group-hover:opacity-30 transition-opacity duration-500",
                    `bg-gradient-to-br ${stat.color}`
                  )} />
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Categories */}
          <div className="space-y-10">
            {categories.map((category, idx) => (
              <div 
                key={idx} 
                className="space-y-6 animate-fade-in"
                style={{ animationDelay: `${(idx + 4) * 100}ms` }}
              >
                {/* Category Header */}
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "p-3 rounded-xl bg-gradient-to-br shadow-xl",
                    category.color,
                    category.shadowColor
                  )}>
                    <category.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl md:text-3xl font-bold text-foreground">{category.title}</h2>
                    <p className="text-sm text-muted-foreground">{category.description}</p>
                  </div>
                </div>

                {/* Function Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
                  {category.functions.map((func, funcIdx) => (
                    <Card
                      key={funcIdx}
                      className={cn(
                        "group cursor-pointer overflow-hidden",
                        "border-border/50 bg-card/80 backdrop-blur-xl",
                        "hover:border-primary/50 transition-all duration-500",
                        "hover:shadow-2xl hover:-translate-y-2",
                        "animate-fade-in"
                      )}
                      style={{ animationDelay: `${(idx * 4 + funcIdx + 5) * 50}ms` }}
                      onClick={(e) => isLocked(func.url) ? handleLockedClick(e) : navigate(func.url)}
                    >
                      {isLocked(func.url) && <FeatureLockOverlay />}
                      <CardHeader className={cn(
                        "bg-gradient-to-br text-white pb-4 relative overflow-hidden",
                        category.color
                      )}>
                        <div className="flex items-center gap-3 relative z-10">
                          <div className="p-2.5 bg-white/20 rounded-xl backdrop-blur-sm group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                            <func.icon className="h-5 w-5" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{func.name}</CardTitle>
                            <span className="text-xs text-white/80">{func.stats}</span>
                          </div>
                        </div>
                        
                        <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700" />
                        <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white/5 rounded-full group-hover:scale-125 transition-transform duration-500" />
                      </CardHeader>
                      
                      <CardContent className="pt-6 relative">
                        <CardDescription className="text-muted-foreground mb-4 min-h-[48px] leading-relaxed">
                          {func.description}
                        </CardDescription>
                        
                        <div className="flex items-center gap-2 text-primary font-semibold text-sm group-hover:gap-4 transition-all duration-300">
                          <span>გახსნა</span>
                          <ArrowRight className="h-4 w-4 group-hover:translate-x-2 transition-transform duration-300" />
                        </div>

                        <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Enhanced Footer Stats */}
          <div 
            className="mt-12 p-6 md:p-8 rounded-2xl bg-gradient-to-r from-primary/5 via-primary/10 to-accent/10 border border-primary/20 backdrop-blur-xl animate-fade-in"
            style={{ animationDelay: '800ms' }}
          >
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-primary/10 animate-pulse">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-lg font-semibold text-foreground">
                    სულ ხელმისაწვდომია <span className="text-2xl font-bold text-primary">{categories.reduce((sum, cat) => sum + cat.functions.length, 0)}</span> პერსონალური ფუნქცია
                  </p>
                  <p className="text-sm text-muted-foreground">
                    მართეთ თქვენი გუნდი ეფექტურად
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                  <Users className="h-4 w-4" />
                  <span className="text-sm font-medium">{stats.activeEmployees} აქტიური თანამშრომელი</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
