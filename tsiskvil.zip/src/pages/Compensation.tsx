
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/contexts/AuthContext";
import { Plus, Check, X, Filter, Info, Scale, ChevronDown } from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface Compensation {
  id: string;
  employee_id: string;
  amount: number;
  type: string;
  bonus_type: string | null;
  reason: string | null;
  status: string;
  approved_at: string | null;
  approved_by: string | null;
  payment_date: string | null;
  created_at: string;
  updated_at: string;
  employees?: {
    full_name: string;
    position: string;
  };
}

interface Employee {
  id: string;
  full_name: string;
  position: string;
  department: string | null;
}

export default function Compensation() {
  const { userRole } = useAuth();
  const [compensations, setCompensations] = useState<Compensation[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterEmployee, setFilterEmployee] = useState<string>("all");

  const [formData, setFormData] = useState({
    employee_id: "",
    amount: "",
    bonus_type: "",
    reason: "",
    payment_date: "",
  });

  const isAdmin = userRole === "admin" || userRole === "hr_manager";

  const compensationTypes: { value: string; label: string; description: string }[] = [
    { value: "overtime", label: "ზეგანაკვეთური სამუშაოს კომპენსაცია", description: "მუხ. 27 - 40 სთ/კვირაში ზემოთ, გაზრდილი ტარიფი (1.5x)" },
    { value: "night_work", label: "ღამის სამუშაოს დანამატი", description: "მუხ. 27 - 22:00–06:00, დანამატი ძირითად ტარიფზე" },
    { value: "holiday_work", label: "უქმე/დასვენების დღეს მუშაობა", description: "მუხ. 30 - გაორმაგებული ტარიფი (2x)" },
    { value: "unused_leave", label: "გამოუყენებელი შვებულების კომპენსაცია", description: "მუხ. 29 - გაუთვალისწინებელი შვებულების ანაზღაურება" },
    { value: "severance", label: "გათავისუფლების კომპენსაცია", description: "მუხ. 48 - არანაკლებ 1 თვის ხელფასი" },
    { value: "performance", label: "შესრულების პრემია", description: "სამუშაოს ხარისხის წახალისება" },
    { value: "annual", label: "წლიური ბონუსი", description: "წლის შეჯამებისას მინიჭებული" },
    { value: "project", label: "პროექტის ბონუსი", description: "პროექტის წარმატებით დასრულება" },
    { value: "retention", label: "შენარჩუნების ბონუსი", description: "ძირითადი კადრის შენარჩუნება" },
    { value: "referral", label: "რეკომენდაციის ბონუსი", description: "ახალი თანამშრომლის რეკომენდაცია" },
    { value: "hazard", label: "საშიშ პირობებში მუშაობის დანამატი", description: "მძიმე/საშიში სამუშაო გარემო" },
    { value: "other", label: "სხვა", description: "სხვა ტიპის კომპენსაცია" },
  ];

  const getCompensationTypeLabel = (value: string) => {
    return compensationTypes.find(t => t.value === value)?.label || value;
  };

  useEffect(() => {
    fetchCompensations();
    if (isAdmin) {
      fetchEmployees();
    }
  }, [isAdmin]);

  const fetchCompensations = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("compensation")
        .select(`
          *,
          employees (
            full_name,
            position
          )
        `)
        .order("created_at", { ascending: false });
      
      if (error) throw error;
      setCompensations((data as Compensation[]) || []);
    } catch (error) {
      console.error("Error fetching compensations:", error);
      toast.error("შეცდომა კომპენსაციების ჩატვირთვისას");
    } finally {
      setLoading(false);
    }
  };

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from("employees")
        .select("id, full_name, position, department")
        .eq("status", "active")
        .order("full_name");
      
      if (error) throw error;
      setEmployees((data as Employee[]) || []);
    } catch (error) {
      console.error("Error fetching employees:", error);
      toast.error("შეცდომა თანამშრომლების ჩატვირთვისას");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.employee_id || !formData.amount || !formData.bonus_type) {
      toast.error("გთხოვთ შეავსოთ ყველა სავალდებულო ველი");
      return;
    }

    try {
      const { error } = await supabase.from("compensation").insert({
        employee_id: formData.employee_id,
        amount: parseFloat(formData.amount),
        type: "compensation",
        bonus_type: formData.bonus_type,
        reason: formData.reason || null,
        payment_date: formData.payment_date || null,
        status: "pending",
      });

      if (error) throw error;

      toast.success("ბონუსი წარმატებით დაემატა");
      setIsDialogOpen(false);
      setFormData({
        employee_id: "",
        amount: "",
        bonus_type: "",
        reason: "",
        payment_date: "",
      });
      fetchCompensations();
    } catch (error) {
      console.error("Error adding compensation:", error);
      toast.error("შეცდომა ბონუსის დამატებისას");
    }
  };

  const handleApprove = async (id: string) => {
    try {
      const { error } = await supabase
        .from("compensation")
        .update({
          status: "approved",
          approved_at: new Date().toISOString(),
        })
        .eq("id", id);

      if (error) throw error;

      toast.success("ბონუსი დამტკიცდა");
      fetchCompensations();
    } catch (error) {
      console.error("Error approving compensation:", error);
      toast.error("შეცდომა ბონუსის დამტკიცებისას");
    }
  };

  const handleReject = async (id: string) => {
    try {
      const { error } = await supabase
        .from("compensation")
        .update({ status: "rejected" })
        .eq("id", id);

      if (error) throw error;

      toast.success("ბონუსი უარყოფილია");
      fetchCompensations();
    } catch (error) {
      console.error("Error rejecting compensation:", error);
      toast.error("შეცდომა ბონუსის უარყოფისას");
    }
  };

  const getStatusBadge = (status: string) => {
    const statusMap: { [key: string]: { variant: "default" | "secondary" | "destructive" | "outline"; label: string } } = {
      approved: { variant: "default", label: "დამტკიცებული" },
      pending: { variant: "secondary", label: "მოლოდინში" },
      rejected: { variant: "destructive", label: "უარყოფილი" },
      paid: { variant: "outline", label: "გადახდილი" },
    };
    const { variant, label } = statusMap[status] || { variant: "outline", label: status };
    return <Badge variant={variant}>{label}</Badge>;
  };

  const filteredCompensations = compensations.filter((comp) => {
    if (filterStatus !== "all" && comp.status !== filterStatus) return false;
    if (filterEmployee !== "all" && comp.employee_id !== filterEmployee) return false;
    return true;
  });

  return (
    <PageTransition>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">კომპენსაცია და დანამატები</h1>
              <p className="text-sm text-muted-foreground mt-1">ბონუსების, დანამატების და კომპენსაციების მართვა საქართველოს შრომის კოდექსის შესაბამისად</p>
            </div>
            {isAdmin && (
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="gap-2">
                    <Plus className="h-4 w-4" />
                    ახალი ბონუსი
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>ბონუსის დამატება</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="employee_id">
                          თანამშრომელი <span className="text-red-500">*</span>
                        </Label>
                        <Select
                          value={formData.employee_id}
                          onValueChange={(value) => setFormData({ ...formData, employee_id: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="აირჩიეთ თანამშრომელი" />
                          </SelectTrigger>
                          <SelectContent>
                            {employees.map((emp) => (
                              <SelectItem key={emp.id} value={emp.id}>
                                {emp.full_name} - {emp.position}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="amount">
                          თანხა (₾) <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="amount"
                          type="number"
                          step="0.01"
                          value={formData.amount}
                          onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                          placeholder="მაგ: 500"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bonus_type">
                          ბონუსის ტიპი <span className="text-red-500">*</span>
                        </Label>
                        <Select
                          value={formData.bonus_type}
                          onValueChange={(value) => setFormData({ ...formData, bonus_type: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="აირჩიეთ ტიპი" />
                          </SelectTrigger>
                          <SelectContent>
                            {compensationTypes.map((ct) => (
                              <SelectItem key={ct.value} value={ct.value}>
                                {ct.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="payment_date">გადახდის თარიღი</Label>
                        <Input
                          id="payment_date"
                          type="date"
                          value={formData.payment_date}
                          onChange={(e) => setFormData({ ...formData, payment_date: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="reason">მიზეზი/აღწერა</Label>
                      <Textarea
                        id="reason"
                        value={formData.reason}
                        onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                        placeholder="მიუთითეთ ბონუსის მინიჭების მიზეზი..."
                        rows={3}
                      />
                    </div>

                    <div className="flex gap-2 justify-end pt-4">
                      <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                        გაუქმება
                      </Button>
                      <Button type="submit">შენახვა</Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            )}
          </div>

          {/* Info Card */}
          <Collapsible>
            <Card className="border-blue-200 dark:border-blue-800 bg-blue-50/50 dark:bg-blue-950/20">
              <CollapsibleTrigger className="w-full">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Scale className="h-4 w-4 text-blue-600" />
                    საქართველოს შრომის კოდექსით გათვალისწინებული კომპენსაციის სახეები
                    <ChevronDown className="h-4 w-4 ml-auto text-muted-foreground" />
                  </CardTitle>
                </CardHeader>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <CardContent className="pt-0">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                    {compensationTypes.map((ct) => (
                      <div key={ct.value} className="flex items-start gap-2 p-2 rounded-lg bg-background/60">
                        <Info className="h-3.5 w-3.5 mt-0.5 text-blue-500 shrink-0" />
                        <div>
                          <p className="font-medium text-xs">{ct.label}</p>
                          <p className="text-xs text-muted-foreground">{ct.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Card>
          </Collapsible>

          {/* Filters */}
          {isAdmin && (
            <Card className="p-4">
              <div className="flex items-center gap-4">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <div className="flex gap-4 flex-1">
                  <div className="flex-1 max-w-xs">
                    <Select value={filterStatus} onValueChange={setFilterStatus}>
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder="ყველა სტატუსი" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">ყველა სტატუსი</SelectItem>
                        <SelectItem value="pending">მოლოდინში</SelectItem>
                        <SelectItem value="approved">დამტკიცებული</SelectItem>
                        <SelectItem value="rejected">უარყოფილი</SelectItem>
                        <SelectItem value="paid">გადახდილი</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex-1 max-w-xs">
                    <Select value={filterEmployee} onValueChange={setFilterEmployee}>
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder="ყველა თანამშრომელი" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">ყველა თანამშრომელი</SelectItem>
                        {employees.map((emp) => (
                          <SelectItem key={emp.id} value={emp.id}>
                            {emp.full_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </Card>
          )}

          {/* Compensations Table */}
          <Card>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="text-xs">თარიღი</TableHead>
                    <TableHead className="text-xs">თანამშრომელი</TableHead>
                    <TableHead className="text-xs">პოზიცია</TableHead>
                    <TableHead className="text-xs">ბონუსის ტიპი</TableHead>
                    <TableHead className="text-xs">მიზეზი</TableHead>
                    <TableHead className="text-xs">თანხა</TableHead>
                    <TableHead className="text-xs">სტატუსი</TableHead>
                    <TableHead className="text-xs">გადახდის თარიღი</TableHead>
                    {isAdmin && <TableHead className="text-xs text-right">მოქმედებები</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                        იტვირთება...
                      </TableCell>
                    </TableRow>
                  ) : filteredCompensations.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                        კომპენსაციები არ მოიძებნა
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredCompensations.map((comp) => (
                      <TableRow key={comp.id} className="hover:bg-muted/30">
                        <TableCell className="text-xs">
                          {new Date(comp.created_at).toLocaleDateString("ka-GE")}
                        </TableCell>
                        <TableCell className="text-sm font-medium">
                          {comp.employees?.full_name || "-"}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {comp.employees?.position || "-"}
                        </TableCell>
                        <TableCell className="text-xs">{getCompensationTypeLabel(comp.bonus_type || "") || "-"}</TableCell>
                        <TableCell className="text-xs max-w-xs truncate">
                          {comp.reason || "-"}
                        </TableCell>
                        <TableCell className="text-sm font-semibold">{comp.amount} ₾</TableCell>
                        <TableCell>{getStatusBadge(comp.status)}</TableCell>
                        <TableCell className="text-xs">
                          {comp.payment_date
                            ? new Date(comp.payment_date).toLocaleDateString("ka-GE")
                            : "-"}
                        </TableCell>
                        {isAdmin && (
                          <TableCell>
                            {comp.status === "pending" && (
                              <div className="flex gap-1 justify-end">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-7 w-7 p-0"
                                  onClick={() => handleApprove(comp.id)}
                                  title="დამტკიცება"
                                >
                                  <Check className="h-3 w-3 text-green-600" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-7 w-7 p-0"
                                  onClick={() => handleReject(comp.id)}
                                  title="უარყოფა"
                                >
                                  <X className="h-3 w-3 text-red-600" />
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        )}
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </Card>
        </div>
    </PageTransition>
  );
}