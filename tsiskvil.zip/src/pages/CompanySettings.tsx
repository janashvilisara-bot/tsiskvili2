import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Loader2, Building2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { wrapPageWithTransition } from "@/lib/wrapPageWithTransition";

interface CompanyFormData {
  company_name: string;
  identification_code: string;
  contact_person: string;
  email: string;
  phone: string;
  legal_address: string;
  physical_address: string;
}

function CompanySettings() {
  const { userRole } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [companyId, setCompanyId] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<CompanyFormData>();

  useEffect(() => {
    fetchCompanyData();
  }, []);

  const fetchCompanyData = async () => {
    try {
      const { data, error } = await supabase
        .from("companies")
        .select("*")
        .eq("is_active", true)
        .single();

      if (error && error.code !== "PGRST116") {
        throw error;
      }

      if (data) {
        setCompanyId(data.id);
        reset(data);
      }
    } catch (error: any) {
      console.error("Error fetching company:", error);
      toast.error("მონაცემების ჩატვირთვისას მოხდა შეცდომა");
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: CompanyFormData) => {
    setSaving(true);
    try {
      if (companyId) {
        // Update existing company
        const { error } = await supabase
          .from("companies")
          .update(data)
          .eq("id", companyId);

        if (error) throw error;
        toast.success("კომპანიის მონაცემები განახლდა");
      } else {
        // Create new company
        const { error } = await supabase
          .from("companies")
          .insert([data]);

        if (error) throw error;
        toast.success("კომპანია წარმატებით დარეგისტრირდა");
        fetchCompanyData();
      }
    } catch (error: any) {
      console.error("Error saving company:", error);
      toast.error("შენახვისას მოხდა შეცდომა");
    } finally {
      setSaving(false);
    }
  };

  if (userRole !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card>
          <CardContent className="pt-6">
            <p className="text-muted-foreground">
              მხოლოდ ადმინისტრატორს შეუძლია კომპანიის მონაცემების მართვა
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-3xl mx-auto">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Building2 className="h-6 w-6 text-primary" />
              <CardTitle>კომპანიის რეგისტრაცია</CardTitle>
            </div>
            <CardDescription>
              შეიყვანეთ თქვენი კომპანიის სრული ინფორმაცია
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="company_name">
                    კომპანიის სახელი <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="company_name"
                    {...register("company_name", {
                      required: "კომპანიის სახელი აუცილებელია",
                    })}
                  />
                  {errors.company_name && (
                    <p className="text-sm text-destructive">
                      {errors.company_name.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="identification_code">
                    საიდენტიფიკაციო კოდი <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="identification_code"
                    {...register("identification_code", {
                      required: "საიდენტიფიკაციო კოდი აუცილებელია",
                    })}
                  />
                  {errors.identification_code && (
                    <p className="text-sm text-destructive">
                      {errors.identification_code.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contact_person">საკონტაქტო პირი</Label>
                  <Input
                    id="contact_person"
                    {...register("contact_person")}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">ტელეფონი</Label>
                  <Input id="phone" {...register("phone")} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">
                    ელ. ფოსტა <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    {...register("email", {
                      required: "ელ. ფოსტა აუცილებელია",
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: "არასწორი ელ. ფოსტის ფორმატი",
                      },
                    })}
                  />
                  {errors.email && (
                    <p className="text-sm text-destructive">
                      {errors.email.message}
                    </p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="legal_address">
                  იურიდიული მისამართი <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="legal_address"
                  {...register("legal_address", {
                    required: "იურიდიული მისამართი აუცილებელია",
                  })}
                />
                {errors.legal_address && (
                  <p className="text-sm text-destructive">
                    {errors.legal_address.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="physical_address">
                  ფიზიკური მისამართი <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="physical_address"
                  {...register("physical_address", {
                    required: "ფიზიკური მისამართი აუცილებელია",
                  })}
                />
                {errors.physical_address && (
                  <p className="text-sm text-destructive">
                    {errors.physical_address.message}
                  </p>
                )}
              </div>

              <Button type="submit" disabled={saving} className="w-full">
                {saving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    შენახვა...
                  </>
                ) : companyId ? (
                  "მონაცემების განახლება"
                ) : (
                  "კომპანიის რეგისტრაცია"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default wrapPageWithTransition(CompanySettings);
