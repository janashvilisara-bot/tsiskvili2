import { useState, useEffect } from "react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import {
  Hotel, Plus, MapPin, Calendar, Banknote, AlertTriangle, CheckCircle2,
  Building2, Coins, FileDown, Plane, Trash2, Pencil,
} from "lucide-react";
import * as XLSX from "xlsx";
import HotelSearch from "@/components/travel/HotelSearch";


interface Vendor {
  id: string;
  name: string;
  vendor_type: string;
  city: string;
  country: string;
  address: string | null;
  contact_person: string | null;
  contact_phone: string | null;
  contact_email: string | null;
  corporate_rate: number | null;
  currency: string;
  rating: number | null;
  contract_end_date: string | null;
  is_active: boolean;
  notes: string | null;
}

interface Booking {
  id: string;
  trip_id: string | null;
  employee_id: string | null;
  vendor_id: string | null;
  booking_type: string;
  vendor_name_manual: string | null;
  city: string;
  country: string;
  check_in_date: string;
  check_out_date: string;
  nights: number;
  room_type: string | null;
  guests: number;
  nightly_rate: number;
  total_amount: number;
  per_diem_days: number;
  per_diem_rate: number;
  per_diem_total: number;
  currency: string;
  status: string;
  confirmation_number: string | null;
  exceeds_limit: boolean;
  limit_amount: number | null;
  expense_request_id: string | null;
  notes: string | null;
  employees?: { full_name: string } | null;
  travel_vendors?: { name: string } | null;
}

const statusLabels: Record<string, { label: string; className: string }> = {
  requested: { label: "მოთხოვნილი", className: "bg-amber-500/15 text-amber-600 border-amber-500/30" },
  confirmed: { label: "დადასტურებული", className: "bg-blue-500/15 text-blue-600 border-blue-500/30" },
  checked_in: { label: "მიმდინარე", className: "bg-violet-500/15 text-violet-600 border-violet-500/30" },
  completed: { label: "დასრულებული", className: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30" },
  cancelled: { label: "გაუქმებული", className: "bg-destructive/15 text-destructive border-destructive/30" },
};

const typeLabels: Record<string, string> = {
  hotel: "სასტუმრო",
  transport: "ტრანსპორტი",
  apartment: "ბინა",
};

export default function TravelDesk() {
  const { userRole } = useAuth();
  const branchId = useBranchFilter();
  const isAdminOrHr = userRole === "admin" || userRole === "hr_manager";

  const [loading, setLoading] = useState(true);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [trips, setTrips] = useState<any[]>([]);
  const [rates, setRates] = useState<any[]>([]);
  const [limits, setLimits] = useState<any[]>([]);
  const [statusFilter, setStatusFilter] = useState("all");

  const [bookingOpen, setBookingOpen] = useState(false);
  const [vendorOpen, setVendorOpen] = useState(false);
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    trip_id: "",
    vendor_id: "",
    vendor_name_manual: "",
    booking_type: "hotel",
    city: "",
    country: "Georgia",
    check_in_date: "",
    check_out_date: "",
    room_type: "",
    guests: "1",
    nightly_rate: "",
    confirmation_number: "",
    notes: "",
  });

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [branchId]);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [b, v, t, r, l] = await Promise.all([
        supabase
          .from("travel_bookings")
          .select("*, employees(full_name), travel_vendors(name)")
          .order("check_in_date", { ascending: false }),
        supabase.from("travel_vendors").select("*").order("name"),
        supabase
          .from("business_trip_requests")
          .select("id, destination, start_date, end_date, employee_id, status, employees(full_name)")
          .in("status", ["approved", "pending"])
          .order("start_date", { ascending: false }),
        supabase.from("per_diem_rates").select("*").order("country"),
        supabase.from("travel_policy_limits").select("*").order("country"),
      ]);
      if (b.error) throw b.error;
      setBookings((b.data as any) || []);
      setVendors((v.data as any) || []);
      setTrips((t.data as any) || []);
      setRates(r.data || []);
      setLimits(l.data || []);
    } catch {
      toast.error("მონაცემების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const openBookingDialog = () => {
    setForm({
      trip_id: "",
      vendor_id: "",
      vendor_name_manual: "",
      booking_type: "hotel",
      city: "",
      country: "Georgia",
      check_in_date: "",
      check_out_date: "",
      room_type: "",
      guests: "1",
      nightly_rate: "",
      confirmation_number: "",
      notes: "",
    });
  };

  const openBookingFromSearch = (prefill: {
    vendor_id?: string;
    vendor_name_manual?: string;
    city: string;
    check_in_date: string;
    check_out_date: string;
    nightly_rate?: string;
  }) => {
    setForm({
      trip_id: "",
      vendor_id: prefill.vendor_id || "",
      vendor_name_manual: prefill.vendor_name_manual || "",
      booking_type: "hotel",
      city: prefill.city,
      country: "Georgia",
      check_in_date: prefill.check_in_date,
      check_out_date: prefill.check_out_date,
      room_type: "",
      guests: "1",
      nightly_rate: prefill.nightly_rate || "",
      confirmation_number: "",
      notes: "",
    });
    setBookingOpen(true);

  };

  const onTripChange = (tripId: string) => {
    const trip = trips.find((t) => t.id === tripId);
    setForm((f) => ({
      ...f,
      trip_id: tripId,
      city: trip?.destination || f.city,
      check_in_date: trip?.start_date || f.check_in_date,
      check_out_date: trip?.end_date || f.check_out_date,
    }));
  };

  const onVendorChange = (vendorId: string) => {
    const vendor = vendors.find((v) => v.id === vendorId);
    setForm((f) => ({
      ...f,
      vendor_id: vendorId,
      city: vendor?.city || f.city,
      country: vendor?.country || f.country,
      nightly_rate: vendor?.corporate_rate ? String(vendor.corporate_rate) : f.nightly_rate,
    }));
  };

  const saveBooking = async () => {
    if (!form.city || !form.check_in_date || !form.check_out_date) {
      toast.error("შეავსეთ ქალაქი და თარიღები");
      return;
    }
    if (new Date(form.check_out_date) < new Date(form.check_in_date)) {
      toast.error("გასვლის თარიღი არ შეიძლება იყოს შესვლამდე");
      return;
    }
    setSaving(true);
    try {
      const trip = trips.find((t) => t.id === form.trip_id);
      const { error } = await supabase.from("travel_bookings").insert({
        trip_id: form.trip_id || null,
        employee_id: trip?.employee_id || null,
        branch_id: branchId,
        vendor_id: form.vendor_id || null,
        vendor_name_manual: form.vendor_id ? null : form.vendor_name_manual || null,
        booking_type: form.booking_type,
        city: form.city,
        country: form.country,
        check_in_date: form.check_in_date,
        check_out_date: form.check_out_date,
        room_type: form.room_type || null,
        guests: Number(form.guests) || 1,
        nightly_rate: Number(form.nightly_rate) || 0,
        confirmation_number: form.confirmation_number || null,
        notes: form.notes || null,
      });
      if (error) throw error;
      toast.success("ჯავშანი დაემატა");
      setBookingOpen(false);
      loadAll();
    } catch {
      toast.error("ჯავშნის შენახვა ვერ მოხერხდა");
    } finally {
      setSaving(false);
    }
  };

  const updateStatus = async (booking: Booking, status: string) => {
    try {
      const { error } = await supabase.from("travel_bookings").update({ status }).eq("id", booking.id);
      if (error) throw error;
      toast.success(
        status === "completed"
          ? "ჯავშანი დასრულდა და ხარჯი ავტომატურად შეიქმნა"
          : "სტატუსი განახლდა"
      );
      loadAll();
    } catch {
      toast.error("სტატუსის განახლება ვერ მოხერხდა");
    }
  };

  const saveVendor = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      name: String(fd.get("name") || ""),
      vendor_type: String(fd.get("vendor_type") || "hotel"),
      city: String(fd.get("city") || ""),
      country: String(fd.get("country") || "Georgia"),
      address: String(fd.get("address") || "") || null,
      contact_person: String(fd.get("contact_person") || "") || null,
      contact_phone: String(fd.get("contact_phone") || "") || null,
      contact_email: String(fd.get("contact_email") || "") || null,
      corporate_rate: fd.get("corporate_rate") ? Number(fd.get("corporate_rate")) : null,
      rating: fd.get("rating") ? Number(fd.get("rating")) : null,
      contract_end_date: String(fd.get("contract_end_date") || "") || null,
      notes: String(fd.get("notes") || "") || null,
    };
    if (!payload.name || !payload.city) {
      toast.error("შეავსეთ დასახელება და ქალაქი");
      return;
    }
    setSaving(true);
    try {
      if (editingVendor) {
        const { error } = await supabase.from("travel_vendors").update(payload).eq("id", editingVendor.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("travel_vendors").insert(payload);
        if (error) throw error;
      }
      toast.success("მომწოდებელი შენახულია");
      setVendorOpen(false);
      setEditingVendor(null);
      loadAll();
    } catch {
      toast.error("შენახვა ვერ მოხერხდა");
    } finally {
      setSaving(false);
    }
  };

  const toggleVendor = async (vendor: Vendor) => {
    const { error } = await supabase
      .from("travel_vendors")
      .update({ is_active: !vendor.is_active })
      .eq("id", vendor.id);
    if (error) return toast.error("ცვლილება ვერ მოხერხდა");
    loadAll();
  };

  const exportBookings = () => {
    const rows = filtered.map((b) => ({
      "თანამშრომელი": b.employees?.full_name || "-",
      "ქალაქი": b.city,
      "მომწოდებელი": b.travel_vendors?.name || b.vendor_name_manual || "-",
      "შესვლა": b.check_in_date,
      "გასვლა": b.check_out_date,
      "ღამეები": b.nights,
      "ღამის ფასი": b.nightly_rate,
      "სასტუმრო ჯამი": b.total_amount,
      "სადღეღამისო": b.per_diem_total,
      "სულ": Number(b.total_amount) + Number(b.per_diem_total),
      "სტატუსი": statusLabels[b.status]?.label || b.status,
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "ჯავშნები");
    XLSX.writeFile(wb, `travel_bookings_${new Date().toISOString().slice(0, 10)}.xlsx`);
    toast.success("ექსპორტი დასრულდა");
  };

  const filtered = bookings.filter((b) => statusFilter === "all" || b.status === statusFilter);

  const totals = filtered.reduce(
    (acc, b) => {
      acc.hotel += Number(b.total_amount) || 0;
      acc.perDiem += Number(b.per_diem_total) || 0;
      acc.nights += Number(b.nights) || 0;
      return acc;
    },
    { hotel: 0, perDiem: 0, nights: 0 }
  );

  const gel = (n: number) => `${(Number(n) || 0).toFixed(2)} ₾`;

  return (
    <PageTransition>
      <div className="p-4 md:p-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-sky-400 via-blue-500 to-indigo-600 shadow-lg shadow-blue-500/25">
              <Hotel className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">მოგზაურობის ცენტრი</h1>
              <p className="text-muted-foreground text-sm">
                სასტუმროების ჯავშნები, სადღეღამისო და მივლინების ხარჯები ერთ ადგილას
              </p>
            </div>
          </div>
          {isAdminOrHr && (
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" onClick={exportBookings} aria-label="ექსპორტი Excel-ში">
                <FileDown className="h-4 w-4 mr-2" /> ექსპორტი
              </Button>
              <Button onClick={openBookingDialog}>
                <Plus className="h-4 w-4 mr-2" /> ახალი ჯავშანი
              </Button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">ჯავშნები</p>
              <p className="text-2xl font-bold">{filtered.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">ღამეები</p>
              <p className="text-2xl font-bold">{totals.nights}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">სასტუმროს ხარჯი</p>
              <p className="text-2xl font-bold">{gel(totals.hotel)}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">სადღეღამისო</p>
              <p className="text-2xl font-bold">{gel(totals.perDiem)}</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="bookings">
          <TabsList>
            <TabsTrigger value="bookings">ჯავშნები</TabsTrigger>
            <TabsTrigger value="search">ძიება</TabsTrigger>
            <TabsTrigger value="vendors">სასტუმროები</TabsTrigger>

            <TabsTrigger value="policy">ტარიფები და ლიმიტები</TabsTrigger>
          </TabsList>

          <TabsContent value="bookings" className="space-y-4 mt-4">
            <div className="w-full md:w-64">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger aria-label="სტატუსის ფილტრი">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა სტატუსი</SelectItem>
                  {Object.entries(statusLabels).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {loading ? (
              <p className="text-muted-foreground">იტვირთება...</p>
            ) : filtered.length === 0 ? (
              <Card>
                <CardContent className="p-10 text-center text-muted-foreground">
                  ჯავშნები არ მოიძებნა
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {filtered.map((b) => (
                  <Card key={b.id} className="overflow-hidden">
                    <CardContent className="p-4 space-y-3">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-semibold truncate">
                              {b.travel_vendors?.name || b.vendor_name_manual || typeLabels[b.booking_type]}
                            </span>
                            <Badge variant="outline" className={statusLabels[b.status]?.className}>
                              {statusLabels[b.status]?.label || b.status}
                            </Badge>
                            {b.exceeds_limit && (
                              <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/30">
                                <AlertTriangle className="h-3 w-3 mr-1" /> ლიმიტს აღემატება
                              </Badge>
                            )}
                            {b.expense_request_id && (
                              <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30">
                                <CheckCircle2 className="h-3 w-3 mr-1" /> ხარჯი შექმნილია
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            {b.employees?.full_name || "-"}
                          </p>
                        </div>
                        {isAdminOrHr && b.status !== "completed" && b.status !== "cancelled" && (
                          <div className="flex gap-2 flex-wrap">
                            {b.status === "requested" && (
                              <Button size="sm" variant="outline" onClick={() => updateStatus(b, "confirmed")}>
                                დადასტურება
                              </Button>
                            )}
                            {b.status === "confirmed" && (
                              <Button size="sm" variant="outline" onClick={() => updateStatus(b, "checked_in")}>
                                შესვლა
                              </Button>
                            )}
                            <Button size="sm" onClick={() => updateStatus(b, "completed")}>
                              დასრულება
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => updateStatus(b, "cancelled")}>
                              გაუქმება
                            </Button>
                          </div>
                        )}
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-sm">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground shrink-0" />
                          <span className="truncate">{b.city}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground shrink-0" />
                          <span className="truncate">{b.check_in_date} → {b.check_out_date}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Hotel className="h-4 w-4 text-muted-foreground shrink-0" />
                          <span>{b.nights} ღამე × {gel(b.nightly_rate)}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Coins className="h-4 w-4 text-muted-foreground shrink-0" />
                          <span>სადღეღამისო {gel(b.per_diem_total)}</span>
                        </div>
                        <div className="flex items-center gap-2 font-semibold">
                          <Banknote className="h-4 w-4 text-muted-foreground shrink-0" />
                          <span>{gel(Number(b.total_amount) + Number(b.per_diem_total))}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="search" className="space-y-4 mt-4">
            <HotelSearch
              vendors={vendors}
              canManage={isAdminOrHr}
              onBook={openBookingFromSearch}
              onVendorsChanged={loadAll}
            />
          </TabsContent>

          <TabsContent value="vendors" className="space-y-4 mt-4">

            {isAdminOrHr && (
              <Button onClick={() => { setEditingVendor(null); setVendorOpen(true); }}>
                <Plus className="h-4 w-4 mr-2" /> სასტუმროს დამატება
              </Button>
            )}
            <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              {vendors.map((v) => (
                <Card key={v.id} className={v.is_active ? "" : "opacity-60"}>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Building2 className="h-4 w-4 shrink-0" />
                      <span className="truncate">{v.name}</span>
                    </CardTitle>
                    <CardDescription>{v.city}, {v.country} · {typeLabels[v.vendor_type] || v.vendor_type}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    {v.corporate_rate != null && (
                      <p className="font-medium">კორპორატიული ტარიფი: {gel(v.corporate_rate)}</p>
                    )}
                    {v.contact_person && <p className="text-muted-foreground truncate">{v.contact_person} · {v.contact_phone}</p>}
                    {v.contract_end_date && (
                      <p className="text-muted-foreground">ხელშეკრულება: {v.contract_end_date}-მდე</p>
                    )}
                    {isAdminOrHr && (
                      <div className="flex gap-2 pt-2">
                        <Button size="sm" variant="outline" onClick={() => { setEditingVendor(v); setVendorOpen(true); }}>
                          <Pencil className="h-3 w-3 mr-1" /> რედაქტირება
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => toggleVendor(v)}>
                          {v.is_active ? "დეაქტივაცია" : "აქტივაცია"}
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
              {vendors.length === 0 && (
                <p className="text-muted-foreground">სასტუმროები ჯერ არ დამატებულა</p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="policy" className="space-y-4 mt-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">სადღეღამისო ტარიფები</CardTitle>
                  <CardDescription>დღიური ანაზღაურება მიმართულების მიხედვით</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  {rates.map((r) => (
                    <div key={r.id} className="flex justify-between border-b border-border/50 pb-1">
                      <span>{r.city || r.country}</span>
                      <span className="font-medium">{gel(r.daily_rate)}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">ღამის ლიმიტები</CardTitle>
                  <CardDescription>მაქსიმალური დასაშვები ღირებულება ღამეში</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  {limits.map((l) => (
                    <div key={l.id} className="flex justify-between border-b border-border/50 pb-1">
                      <span>{l.city || l.country}</span>
                      <span className="font-medium">{gel(l.max_nightly_rate)}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Booking dialog */}
        <Dialog open={bookingOpen} onOpenChange={setBookingOpen}>
          <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>ახალი ჯავშანი</DialogTitle>
              <DialogDescription>
                აირჩიეთ მივლინება - ქალაქი, თარიღები და სადღეღამისო ავტომატურად შეივსება
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="md:col-span-2 space-y-2">
                <Label>მივლინება</Label>
                <Select value={form.trip_id} onValueChange={onTripChange}>
                  <SelectTrigger><SelectValue placeholder="აირჩიეთ მივლინება" /></SelectTrigger>
                  <SelectContent>
                    {trips.map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.employees?.full_name} - {t.destination} ({t.start_date})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>სასტუმრო (კატალოგიდან)</Label>
                <Select value={form.vendor_id} onValueChange={onVendorChange}>
                  <SelectTrigger><SelectValue placeholder="აირჩიეთ" /></SelectTrigger>
                  <SelectContent>
                    {vendors.filter((v) => v.is_active).map((v) => (
                      <SelectItem key={v.id} value={v.id}>{v.name} - {v.city}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>ან შეიყვანეთ ხელით</Label>
                <Input
                  value={form.vendor_name_manual}
                  onChange={(e) => setForm({ ...form, vendor_name_manual: e.target.value, vendor_id: "" })}
                  placeholder="სასტუმროს დასახელება"
                />
              </div>
              <div className="space-y-2">
                <Label>ქალაქი *</Label>
                <Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>ქვეყანა</Label>
                <Input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>შესვლა *</Label>
                <Input type="date" value={form.check_in_date} onChange={(e) => setForm({ ...form, check_in_date: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>გასვლა *</Label>
                <Input type="date" value={form.check_out_date} onChange={(e) => setForm({ ...form, check_out_date: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>ოთახის ტიპი</Label>
                <Input value={form.room_type} onChange={(e) => setForm({ ...form, room_type: e.target.value })} placeholder="Standard / Twin" />
              </div>
              <div className="space-y-2">
                <Label>ღამის ფასი (₾)</Label>
                <Input type="number" min="0" step="0.01" value={form.nightly_rate} onChange={(e) => setForm({ ...form, nightly_rate: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>დადასტურების ნომერი</Label>
                <Input value={form.confirmation_number} onChange={(e) => setForm({ ...form, confirmation_number: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>სტუმრები</Label>
                <Input type="number" min="1" value={form.guests} onChange={(e) => setForm({ ...form, guests: e.target.value })} />
              </div>
              <div className="md:col-span-2 space-y-2">
                <Label>შენიშვნა</Label>
                <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setBookingOpen(false)}>გაუქმება</Button>
              <Button onClick={saveBooking} disabled={saving}>შენახვა</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Vendor dialog */}
        <Dialog open={vendorOpen} onOpenChange={(o) => { setVendorOpen(o); if (!o) setEditingVendor(null); }}>
          <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingVendor ? "სასტუმროს რედაქტირება" : "სასტუმროს დამატება"}</DialogTitle>
              <DialogDescription>კონტრაქტორი მომწოდებლების კატალოგი</DialogDescription>
            </DialogHeader>
            <form onSubmit={saveVendor} className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="v-name">დასახელება *</Label>
                <Input id="v-name" name="name" defaultValue={editingVendor?.name} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="v-type">ტიპი</Label>
                <select
                  id="v-type"
                  name="vendor_type"
                  defaultValue={editingVendor?.vendor_type || "hotel"}
                  className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
                >
                  <option value="hotel">სასტუმრო</option>
                  <option value="apartment">ბინა</option>
                  <option value="transport">ტრანსპორტი</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="v-city">ქალაქი *</Label>
                <Input id="v-city" name="city" defaultValue={editingVendor?.city} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="v-country">ქვეყანა</Label>
                <Input id="v-country" name="country" defaultValue={editingVendor?.country || "Georgia"} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="v-rate">კორპორატიული ტარიფი (₾)</Label>
                <Input id="v-rate" name="corporate_rate" type="number" min="0" step="0.01" defaultValue={editingVendor?.corporate_rate ?? ""} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="v-rating">რეიტინგი</Label>
                <Input id="v-rating" name="rating" type="number" min="0" max="5" step="0.1" defaultValue={editingVendor?.rating ?? ""} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="v-person">საკონტაქტო პირი</Label>
                <Input id="v-person" name="contact_person" defaultValue={editingVendor?.contact_person ?? ""} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="v-phone">ტელეფონი</Label>
                <Input id="v-phone" name="contact_phone" defaultValue={editingVendor?.contact_phone ?? ""} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="v-email">ელფოსტა</Label>
                <Input id="v-email" name="contact_email" type="email" defaultValue={editingVendor?.contact_email ?? ""} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="v-contract">ხელშეკრულების ვადა</Label>
                <Input id="v-contract" name="contract_end_date" type="date" defaultValue={editingVendor?.contract_end_date ?? ""} />
              </div>
              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="v-address">მისამართი</Label>
                <Input id="v-address" name="address" defaultValue={editingVendor?.address ?? ""} />
              </div>
              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="v-notes">შენიშვნა</Label>
                <Textarea id="v-notes" name="notes" defaultValue={editingVendor?.notes ?? ""} />
              </div>
              <DialogFooter className="md:col-span-2">
                <Button type="button" variant="outline" onClick={() => setVendorOpen(false)}>გაუქმება</Button>
                <Button type="submit" disabled={saving}>შენახვა</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </PageTransition>
  );
}
