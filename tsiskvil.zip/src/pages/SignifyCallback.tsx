import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function SignifyCallback() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    const code = searchParams.get('code');
    const state = searchParams.get('state');

    if (!code) {
      setStatus('error');
      setErrorMsg('Authorization code not found');
      return;
    }

    // Retrieve PKCE verifier and state from sessionStorage
    const storedVerifier = sessionStorage.getItem('signify_pkce_verifier');
    const storedState = sessionStorage.getItem('signify_oauth_state');
    const storedRedirectUri = sessionStorage.getItem('signify_redirect_uri');

    if (!storedVerifier) {
      setStatus('error');
      setErrorMsg('PKCE verifier not found. Please try again.');
      return;
    }

    if (storedState && state !== storedState) {
      setStatus('error');
      setErrorMsg('State mismatch. Possible CSRF attack.');
      return;
    }

    // Exchange code for tokens
    exchangeCode(code, storedVerifier, storedRedirectUri || window.location.origin + '/signify-callback', state || undefined);
  }, [searchParams]);

  const exchangeCode = async (code: string, codeVerifier: string, redirectUri: string, state?: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('signify-oauth', {
        body: {
          action: 'exchange',
          code,
          code_verifier: codeVerifier,
          redirect_uri: redirectUri,
          state,
        },
      });

      // Clean up sessionStorage
      sessionStorage.removeItem('signify_pkce_verifier');
      sessionStorage.removeItem('signify_oauth_state');
      sessionStorage.removeItem('signify_redirect_uri');

      if (error || !data?.success) {
        setStatus('error');
        setErrorMsg(data?.error || 'Token exchange failed');
        return;
      }

      setStatus('success');

      // Redirect to signify integration page after 2 seconds
      setTimeout(() => {
        navigate('/signify-integration', { replace: true });
      }, 2000);
    } catch (err: any) {
      setStatus('error');
      setErrorMsg(err.message || 'Unexpected error');
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
          {status === 'loading' && (
            <>
              <Loader2 className="h-12 w-12 animate-spin text-primary" />
              <h2 className="text-xl font-semibold">Signify ექაუნთის დაკავშირება...</h2>
              <p className="text-sm text-muted-foreground">გთხოვთ მოიცადოთ</p>
            </>
          )}

          {status === 'success' && (
            <>
              <div className="h-12 w-12 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                <CheckCircle className="h-7 w-7 text-green-600 dark:text-green-400" />
              </div>
              <h2 className="text-xl font-semibold">Signify წარმატებით დაკავშირდა!</h2>
              <p className="text-sm text-muted-foreground">გადამისამართება...</p>
            </>
          )}

          {status === 'error' && (
            <>
              <div className="h-12 w-12 rounded-full bg-destructive/10 flex items-center justify-center">
                <AlertCircle className="h-7 w-7 text-destructive" />
              </div>
              <h2 className="text-xl font-semibold">შეცდომა</h2>
              <p className="text-sm text-muted-foreground">{errorMsg}</p>
              <Button onClick={() => navigate('/signify-integration', { replace: true })} className="mt-2">
                უკან დაბრუნება
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
