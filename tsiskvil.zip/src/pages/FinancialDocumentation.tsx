import { FileDown, Book } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageTransition } from "@/components/PageTransition";
import { exportFinancialDocToPDF } from "@/lib/exportFinancialDocToPDF";
import { toast } from "sonner";

export default function FinancialDocumentation() {
  const handleDownloadPDF = () => {
    exportFinancialDocToPDF();
    toast.success("PDF დოკუმენტაცია ჩამოიტვირთა!");
  };

  return (
    <PageTransition>
      <div className="space-y-6 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              ფინანსური სისტემის დოკუმენტაცია
            </h1>
            <p className="mt-2 text-muted-foreground">
              სრული გზამკვლევი HR & CRM Pro ფინანსური სისტემისთვის
            </p>
          </div>
          <Button onClick={handleDownloadPDF} className="gap-2">
            <FileDown className="h-4 w-4" />
            ჩამოტვირთვა PDF
          </Button>
        </div>

        {/* Documentation Content */}
        <div className="grid gap-6">
          {/* Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="h-5 w-5 text-primary" />
                ზოგადი მიმოხილვა
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-sm max-w-none dark:prose-invert">
              <p>
                ფინანსური სისტემა მოიცავს ხელფასების დარიცხვას, ბიუჯეტის დაგეგმვას, ხარჯების აღრიცხვას, 
                ზეგანაკვეთური სამუშაოს აღრიცხვას და კომპენსაციების მართვას. სისტემა ინტეგრირებულია 
                დასწრების აღრიცხვასთან, შვებულებებთან და სამუშაო გრაფიკებთან.
              </p>
            </CardContent>
          </Card>

          {/* Main Components */}
          <Card>
            <CardHeader>
              <CardTitle>მთავარი კომპონენტები</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                  <div>
                    <h3 className="font-semibold">Payroll (ხელფასები)</h3>
                    <p className="text-sm text-muted-foreground">ყოველთვიური ხელფასების დარიცხვა და გადახდა</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                  <div>
                    <h3 className="font-semibold">Budget Planning (ბიუჯეტის დაგეგმვა)</h3>
                    <p className="text-sm text-muted-foreground">დეპარტამენტების ბიუჯეტის დაგეგმვა</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                  <div>
                    <h3 className="font-semibold">Budget Expenses (ხარჯები)</h3>
                    <p className="text-sm text-muted-foreground">ხარჯების აღრიცხვა და ანალიზი</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                  <div>
                    <h3 className="font-semibold">Overtime (ზეგანაკვეთური)</h3>
                    <p className="text-sm text-muted-foreground">ზეგანაკვეთური საათების აღრიცხვა და გადახდა</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                  <div>
                    <h3 className="font-semibold">Compensation (კომპენსაცია)</h3>
                    <p className="text-sm text-muted-foreground">ბონუსები და დამატებითი კომპენსაციები</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                  <div>
                    <h3 className="font-semibold">Reports (ანგარიშები)</h3>
                    <p className="text-sm text-muted-foreground">ფინანსური ანგარიშგება და ანალიტიკა</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payroll Calculation */}
          <Card>
            <CardHeader>
              <CardTitle>ხელფასების გამოთვლა</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <p className="font-mono text-sm">
                    წმინდა ხელფასი = საბაზო ხელფასი + ბონუსები + დღესასწაულების ზეგანაკვეთური - დაკავებები - პენსია
                  </p>
                </div>
                <div className="grid gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-8 bg-secondary rounded-full" />
                    <div>
                      <p className="font-semibold text-sm">საბაზო ხელფასი</p>
                      <p className="text-xs text-muted-foreground">თანამშრომლის ხელშეკრულებით განსაზღვრული თანხა</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-8 bg-secondary rounded-full" />
                    <div>
                      <p className="font-semibold text-sm">ბონუსები</p>
                      <p className="text-xs text-muted-foreground">ხელით შეყვანილი ბონუსები და წახალისება</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-8 bg-secondary rounded-full" />
                    <div>
                      <p className="font-semibold text-sm">დღესასწაულების ზეგანაკვეთური</p>
                      <p className="text-xs text-muted-foreground">საჯარო დღესასწაულებზე მუშაობის ანაზღაურება (x2)</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-8 bg-destructive/50 rounded-full" />
                    <div>
                      <p className="font-semibold text-sm">დაკავებები</p>
                      <p className="text-xs text-muted-foreground">ჯარიმები, სესხის დაფარვა და სხვა დაკავებები</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-8 bg-destructive/50 rounded-full" />
                    <div>
                      <p className="font-semibold text-sm">პენსიის შენატანი</p>
                      <p className="text-xs text-muted-foreground">2% საბაზო ხელფასიდან</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Overtime Multipliers */}
          <Card>
            <CardHeader>
              <CardTitle>ზეგანაკვეთური მულტიპლიკატორები</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 md:grid-cols-3">
                <div className="p-4 rounded-lg border bg-card text-center">
                  <div className="text-3xl font-bold text-primary">x1.5</div>
                  <p className="text-sm font-medium mt-2">სამუშაო დღეები</p>
                  <p className="text-xs text-muted-foreground">საათობრივი განაკვეთის 150%</p>
                </div>
                <div className="p-4 rounded-lg border bg-card text-center">
                  <div className="text-3xl font-bold text-secondary">x2.0</div>
                  <p className="text-sm font-medium mt-2">შაბათ-კვირა</p>
                  <p className="text-xs text-muted-foreground">საათობრივი განაკვეთის 200%</p>
                </div>
                <div className="p-4 rounded-lg border bg-card text-center">
                  <div className="text-3xl font-bold text-accent">x2.0</div>
                  <p className="text-sm font-medium mt-2">საჯარო დღესასწაულები</p>
                  <p className="text-xs text-muted-foreground">საათობრივი განაკვეთის 200%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Budget Categories */}
          <Card>
            <CardHeader>
              <CardTitle>ბიუჯეტის კატეგორიები</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-2 md:grid-cols-2">
                {[
                  { name: "Salaries", desc: "ხელფასები და დაკავშირებული ხარჯები" },
                  { name: "Benefits", desc: "თანამშრომელთა შეღავათები და სოციალური პაკეტი" },
                  { name: "Training", desc: "ტრენინგები და პროფესიული განვითარება" },
                  { name: "Equipment", desc: "აღჭურვილობა და ტექნიკა" },
                  { name: "Marketing", desc: "მარკეტინგული აქტივობები" },
                  { name: "Operations", desc: "ოპერაციული ხარჯები" },
                  { name: "Other", desc: "სხვა დანარჩენი კატეგორიები" }
                ].map((cat) => (
                  <div key={cat.name} className="flex items-center gap-3 p-3 rounded-lg bg-muted/30">
                    <div className="w-2 h-2 rounded-full bg-accent" />
                    <div>
                      <p className="font-semibold text-sm">{cat.name}</p>
                      <p className="text-xs text-muted-foreground">{cat.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Data Sources */}
          <Card>
            <CardHeader>
              <CardTitle>მონაცემთა წყაროები (Supabase ცხრილები)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-2">
                {[
                  "employees - თანამშრომლების ინფორმაცია და ხელფასები",
                  "payroll - ხელფასის დარიცხვები და გადახდები",
                  "budget_plans - ბიუჯეტის გეგმები და პროგნოზები",
                  "budget_expenses - ფაქტობრივი ხარჯები",
                  "overtime_requests - ზეგანაკვეთური სამუშაოს მოთხოვნები",
                  "compensation - კომპენსაციები და ბონუსები",
                  "public_holidays - საჯარო დღესასწაულები",
                  "attendance - დასწრების აღრიცხვა"
                ].map((source, idx) => (
                  <div key={idx} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                    <p className="text-sm font-mono">{source}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Download CTA */}
          <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <CardContent className="pt-6">
              <div className="text-center space-y-4">
                <h3 className="text-xl font-bold">სრული დოკუმენტაცია</h3>
                <p className="text-muted-foreground">
                  ჩამოტვირთეთ დეტალური PDF გზამკვლევი კოდის მაგალითებით, SQL queries-ით და სრული ტექნიკური დოკუმენტაციით
                </p>
                <Button onClick={handleDownloadPDF} size="lg" className="gap-2">
                  <FileDown className="h-5 w-5" />
                  ჩამოტვირთვა PDF დოკუმენტაცია
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageTransition>
  );
}
