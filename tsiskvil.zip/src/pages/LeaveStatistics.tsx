import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Umbrella, Users, TrendingUp, Calendar as CalendarIcon, Download, BarChart3, PieChart } from "lucide-react";
import { ReportPageShell } from "@/components/reports/ReportPageShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { PageTransition } from "@/components/PageTransition";
import { format, startOfMonth, endOfMonth, startOfYear, endOfYear } from "date-fns";
import { ka } from "date-fns/locale";
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, Cell } from "recharts";
import { XLSX } from '@/lib/xlsxCompat';
import { useBranchFilter } from "@/hooks/useBranchFilter";


interface DepartmentStat {
  department_name: string;
  total_employees: number;
  on_leave_count: number;
  on_leave_percentage: number;
  leave_types: {
    annual: number;
    sick: number;
    personal: number;
    unpaid: number;
  };
  employees_on_leave: Array<{
    name: string;
    leave_type: string;
    start_date: string;
    end_date: string;
  }>;
}

export default function LeaveStatistics() {
  const { userRole } = useAuth();
  const [departmentStats, setDepartmentStats] = useState<DepartmentStat[]>([]);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState<Date>(startOfMonth(new Date()));
  const [endDate, setEndDate] = useState<Date>(endOfMonth(new Date()));
  const [periodType, setPeriodType] = useState<string>("month");
  const branchId = useBranchFilter();

  useEffect(() => {
    if (userRole === 'admin' || userRole === 'hr_manager') {
      fetchLeaveStatistics();
    }
  }, [userRole, startDate, endDate, branchId]);


  useEffect(() => {
    const today = new Date();
    if (periodType === "month") {
      setStartDate(startOfMonth(today));
      setEndDate(endOfMonth(today));
    } else if (periodType === "year") {
      setStartDate(startOfYear(today));
      setEndDate(endOfYear(today));
    }
  }, [periodType]);

  const fetchLeaveStatistics = async () => {
    setLoading(true);
    try {
      // Get all departments
      const { data: departments } = await supabase
        .from('departments')
        .select('id, name')
        .eq('is_active', true);

      if (!departments) {
        setDepartmentStats([]);
        return;
      }

      const stats: DepartmentStat[] = [];

      for (const dept of departments) {
        // Get total employees in department
        let empQuery = supabase
          .from('employees')
          .select('id, full_name', { count: 'exact' })
          .eq('department', dept.name)
          .eq('status', 'active');
        if (branchId) empQuery = empQuery.eq('branch_id', branchId);
        const { data: employees, count: totalEmployees } = await empQuery;

        // Get leave requests in the date range
        let leaveQ = supabase
          .from('leave_requests')
          .select(`
            *,
            employee:employees!leave_requests_employee_id_fkey (
              full_name,
              department
            )
          `)
          .eq('status', 'approved')
          .gte('end_date', format(startDate, 'yyyy-MM-dd'))
          .lte('start_date', format(endDate, 'yyyy-MM-dd'));
        if (branchId) leaveQ = leaveQ.eq('branch_id', branchId);
        const { data: leaveRequests } = await leaveQ;


        // Filter leaves for this department
        const departmentLeaves = leaveRequests?.filter(
          leave => leave.employee?.department === dept.name
        ) || [];

        // Count unique employees on leave
        const uniqueEmployeesOnLeave = new Set(departmentLeaves.map(l => l.employee_id));
        const onLeaveCount = uniqueEmployeesOnLeave.size;

        // Count by leave type
        const leaveTypes = {
          annual: 0,
          sick: 0,
          personal: 0,
          unpaid: 0,
        };

        departmentLeaves.forEach(leave => {
          if (leave.leave_type === 'annual') leaveTypes.annual++;
          else if (leave.leave_type === 'sick') leaveTypes.sick++;
          else if (leave.leave_type === 'personal') leaveTypes.personal++;
          else if (leave.leave_type === 'unpaid') leaveTypes.unpaid++;
        });

        // Get employee details
        const employeesOnLeave = departmentLeaves.map(leave => ({
          name: leave.employee?.full_name || 'N/A',
          leave_type: leave.leave_type,
          start_date: leave.start_date,
          end_date: leave.end_date,
        }));

        stats.push({
          department_name: dept.name,
          total_employees: totalEmployees || 0,
          on_leave_count: onLeaveCount,
          on_leave_percentage: totalEmployees ? Math.round((onLeaveCount / totalEmployees) * 100) : 0,
          leave_types: leaveTypes,
          employees_on_leave: employeesOnLeave,
        });
      }

      setDepartmentStats(stats.sort((a, b) => b.on_leave_count - a.on_leave_count));
    } catch (error) {
      console.error('Error fetching leave statistics:', error);
      toast.error('სტატისტიკის ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = () => {
    const exportData = departmentStats.flatMap(stat => 
      stat.employees_on_leave.map(emp => ({
        'დეპარტამენტი': stat.department_name,
        'თანამშრომელი': emp.name,
        'შვებულების ტიპი': emp.leave_type === 'annual' ? 'ხელფასიანი' :
                           emp.leave_type === 'sick' ? 'სამედიცინო' :
                           emp.leave_type === 'personal' ? 'პირადი' :
                           emp.leave_type === 'unpaid' ? 'უხელფასო' : emp.leave_type,
        'დაწყება': format(new Date(emp.start_date), 'd MMM yyyy', { locale: ka }),
        'დასრულება': format(new Date(emp.end_date), 'd MMM yyyy', { locale: ka }),
      }))
    );

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'შვებულებების სტატისტიკა');
    XLSX.writeFile(wb, `შვებულებების_სტატისტიკა_${format(new Date(), 'yyyy-MM-dd')}.xlsx`);
    toast.success('Excel ფაილი ჩამოტვირთულია');
  };

  const chartData = departmentStats.map(stat => ({
    name: stat.department_name,
    შვებულებაში: stat.on_leave_count,
    სულ: stat.total_employees,
  }));

  const getLeaveTypeLabel = (type: string) => {
    switch (type) {
      case 'annual': return 'ხელფასიანი';
      case 'sick': return 'სამედიცინო';
      case 'personal': return 'პირადი';
      case 'unpaid': return 'უხელფასო';
      default: return type;
    }
  };

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  if (userRole !== 'admin' && userRole !== 'hr_manager') {
    return (
      <PageTransition>
        <div className="flex items-center justify-center min-h-screen">
          <Card className="p-6">
            <p className="text-muted-foreground">არ გაქვთ წვდომა ამ გვერდზე</p>
          </Card>
        </div>
      </PageTransition>
    );
  }

  if (loading) {
    return (
      <PageTransition>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </PageTransition>
    );
  }

  const totalEmployees = departmentStats.reduce((sum, stat) => sum + stat.total_employees, 0);
  const totalOnLeave = departmentStats.reduce((sum, stat) => sum + stat.on_leave_count, 0);
  const averageLeavePercentage = totalEmployees > 0 ? Math.round((totalOnLeave / totalEmployees) * 100) : 0;

  return (
    <ReportPageShell
      title="შვებულებების სტატისტიკა"
      description="დეპარტამენტების მიხედვით შვებულებაში მყოფი თანამშრომლების ანალიზი"
      icon={PieChart}
      gradient="from-pink-400 via-rose-500 to-red-500"
      shadow="shadow-rose-500/30"
      actions={
        <Button onClick={handleExport} size="lg" className="gap-2 bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 shadow-lg">
          <Download className="h-4 w-4" />
          Excel ექსპორტი
        </Button>
      }
    >

        {/* Period Filter */}
        <Card>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">პერიოდი</label>
                <Select value={periodType} onValueChange={setPeriodType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="month">მიმდინარე თვე</SelectItem>
                    <SelectItem value="year">მიმდინარე წელი</SelectItem>
                    <SelectItem value="custom">სხვა პერიოდი</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {periodType === "custom" && (
                <>
                  <div>
                    <label className="text-sm font-medium mb-2 block">დაწყება</label>
                    <Calendar
                      mode="single"
                      selected={startDate}
                      onSelect={(date) => date && setStartDate(date)}
                      locale={ka}
                      className="rounded-md border"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">დასრულება</label>
                    <Calendar
                      mode="single"
                      selected={endDate}
                      onSelect={(date) => date && setEndDate(date)}
                      locale={ka}
                      className="rounded-md border"
                    />
                  </div>
                </>
              )}
            </div>
            <div className="mt-4 text-sm text-muted-foreground">
              პერიოდი: {format(startDate, 'd MMM yyyy', { locale: ka })} - {format(endDate, 'd MMM yyyy', { locale: ka })}
            </div>
          </CardContent>
        </Card>

        {/* Summary Statistics */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-blue-500/10">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">სულ თანამშრომელი</p>
                  <p className="text-2xl font-bold">{totalEmployees}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-orange-500/10">
                  <Umbrella className="h-6 w-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">შვებულებაში</p>
                  <p className="text-2xl font-bold">{totalOnLeave}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-green-500/10">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">საშუალო %</p>
                  <p className="text-2xl font-bold">{averageLeavePercentage}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Chart */}
        <Card>
          <CardHeader>
            <CardTitle>დიაგრამა</CardTitle>
            <CardDescription>დეპარტამენტების შედარება</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="შვებულებაში" fill="#3b82f6" />
                <Bar dataKey="სულ" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Department Details */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">დეპარტამენტების დეტალები</h2>
          {departmentStats.map((stat, idx) => (
            <Card key={idx}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    {stat.department_name}
                    <Badge variant={stat.on_leave_percentage > 20 ? "destructive" : "secondary"}>
                      {stat.on_leave_percentage}%
                    </Badge>
                  </CardTitle>
                  <div className="text-sm text-muted-foreground">
                    {stat.on_leave_count} / {stat.total_employees} თანამშრომელი
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Leave Types Summary */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="p-3 rounded-lg bg-blue-500/10">
                    <p className="text-xs text-muted-foreground">ხელფასიანი</p>
                    <p className="text-lg font-semibold text-blue-600">{stat.leave_types.annual}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-red-500/10">
                    <p className="text-xs text-muted-foreground">სამედიცინო</p>
                    <p className="text-lg font-semibold text-red-600">{stat.leave_types.sick}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-purple-500/10">
                    <p className="text-xs text-muted-foreground">პირადი</p>
                    <p className="text-lg font-semibold text-purple-600">{stat.leave_types.personal}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-orange-500/10">
                    <p className="text-xs text-muted-foreground">უხელფასო</p>
                    <p className="text-lg font-semibold text-orange-600">{stat.leave_types.unpaid}</p>
                  </div>
                </div>

                {/* Employees on Leave */}
                {stat.employees_on_leave.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">შვებულებაში მყოფი თანამშრომლები:</h4>
                    <div className="space-y-2">
                      {stat.employees_on_leave.map((emp, empIdx) => (
                        <div key={empIdx} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                          <div>
                            <p className="font-medium">{emp.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {format(new Date(emp.start_date), 'd MMM', { locale: ka })} - {format(new Date(emp.end_date), 'd MMM yyyy', { locale: ka })}
                            </p>
                          </div>
                          <Badge variant="outline">
                            {getLeaveTypeLabel(emp.leave_type)}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {stat.employees_on_leave.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    შვებულებაში მყოფი თანამშრომლები არ არიან
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {departmentStats.length === 0 && (
          <Card className="p-12">
            <div className="text-center text-muted-foreground">
              არჩეულ პერიოდში შვებულებები არ მოიძებნა
            </div>
          </Card>
        )}
    </ReportPageShell>
  );
}
