import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Users, Target, Briefcase, TrendingUp, Building2 } from "lucide-react";
import { Navigate } from "react-router-dom";

interface DeptInfo {
  id: string;
  name: string;
  headcount_limit: number | null;
}

export default function ManagerHeadcount() {
  const { user, userRole } = useAuth();
  const [loading, setLoading] = useState(true);
  const [dept, setDept] = useState<DeptInfo | null>(null);
  const [activeCount, setActiveCount] = useState(0);
  const [openVacancies, setOpenVacancies] = useState(0);

  if (userRole && userRole !== "department_manager" && userRole !== "admin" && userRole !== "hr_manager") {
    return <Navigate to="/" replace />;
  }

  useEffect(() => {
    const load = async () => {
      if (!user) return;
      setLoading(true);
      try {
        const { data: emp } = await supabase
          .from("employees")
          .select("id")
          .eq("user_id", user.id)
          .maybeSingle();
        if (!emp) return;

        const { data: d } = await supabase
          .from("departments")
          .select("id, name, headcount_limit")
          .eq("manager_id", emp.id)
          .maybeSingle();
        if (!d) return;
        setDept(d);

        const { count: ac } = await supabase
          .from("employees")
          .select("*", { count: "exact", head: true })
          .eq("department", d.name)
          .eq("status", "active");
        setActiveCount(ac || 0);

        const { count: vc } = await supabase
          .from("job_vacancies")
          .select("*", { count: "exact", head: true })
          .eq("department_id", d.id)
          .eq("status", "open");
        setOpenVacancies(vc || 0);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="h-10 w-10 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
      </div>
    );
  }

  if (!dept) {
    return (
      <div className="container mx-auto py-8">
        <Card>
          <CardHeader>
            <CardTitle>დეპარტამენტი ვერ მოიძებნა</CardTitle>
            <CardDescription>თქვენ არ ხართ მინიჭებული რომელიმე დეპარტამენტის ხელმძღვანელად.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const limit = dept.headcount_limit ?? 0;
  const filledPct = limit > 0 ? Math.min(100, Math.round((activeCount / limit) * 100)) : 0;
  const remaining = Math.max(0, limit - activeCount);

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">საშტატო ერთეულები</h1>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Building2 className="h-5 w-5" />
          <p className="text-lg">{dept.name}</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">საშტატო ლიმიტი</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{limit || "-"}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">ფაქტიური</CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeCount}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">თავისუფალი შტატი</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{remaining}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">ღია ვაკანსიები</CardTitle>
            <Briefcase className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{openVacancies}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>შტატის შევსება</CardTitle>
          <CardDescription>
            {limit > 0
              ? `${activeCount} / ${limit} (${filledPct}%)`
              : "საშტატო ლიმიტი არ არის განსაზღვრული"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {limit > 0 && <Progress value={filledPct} />}
          <div className="flex gap-2 flex-wrap">
            {limit > 0 && activeCount > limit && (
              <Badge variant="destructive">გადაჭარბება: {activeCount - limit}</Badge>
            )}
            {limit > 0 && activeCount <= limit && remaining > 0 && (
              <Badge variant="outline">დარჩა {remaining} ვაკანტური ერთეული</Badge>
            )}
            {openVacancies > 0 && (
              <Badge variant="secondary">{openVacancies} ღია ვაკანსია</Badge>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
