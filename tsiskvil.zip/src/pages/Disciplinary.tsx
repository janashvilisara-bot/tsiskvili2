import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { AlertTriangle, Plus, Search, Filter } from "lucide-react";
import { DisciplinaryActionCard } from "@/components/org-structure/DisciplinaryActionCard";
import { Badge } from "@/components/ui/badge";

interface Employee {
  id: string;
  full_name: string;
  avatar_url: string | null;
  department: string | null;
}

interface DisciplinaryAction {
  id: string;
  employee_id: string;
  action_type: string;
  reason: string;
  description: string | null;
  issued_by: string | null;
  issued_date: string;
  status: string;
  severity: string;
  follow_up_date: string | null;
  follow_up_notes: string | null;
  employee?: { full_name: string; avatar_url: string | null };
  issuer?: { full_name: string; avatar_url: string | null };
}

const Disciplinary = () => {
  const { userRole } = useAuth();
  const [actions, setActions] = useState<DisciplinaryAction[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAction, setEditingAction] = useState<DisciplinaryAction | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');

  const canManage = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    fetchDisciplinaryActions();
    if (canManage) {
      fetchEmployees();
    }
  }, [canManage]);

  // Realtime subscription
  useEffect(() => {
    const channel = supabase
      .channel('disciplinary-actions-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'disciplinary_actions' }, () => {
        fetchDisciplinaryActions();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchDisciplinaryActions = async () => {
    try {
      const response = await supabase
        .from('disciplinary_actions')
        .select(`
          *,
          employee:employees!employee_id(full_name, avatar_url),
          issuer:employees!issued_by(full_name, avatar_url)
        `)
        .order('issued_date', { ascending: false });
      
      if (response.error) throw response.error;
      setActions((response.data as any) || []);
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('id, full_name, avatar_url, department')
        .eq('status', 'active')
        .order('full_name');
      
      if (error) throw error;
      setEmployees(data || []);
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);

    // Get current employee ID for issued_by
    const { data: currentEmployee } = await supabase
      .from('employees')
      .select('id')
      .eq('user_id', (await supabase.auth.getUser()).data.user?.id)
      .single();

    const actionData = {
      employee_id: formData.get('employee_id') as string,
      action_type: formData.get('action_type') as string,
      reason: formData.get('reason') as string,
      description: formData.get('description') as string || null,
      issued_by: currentEmployee?.id || null,
      issued_date: formData.get('issued_date') as string,
      status: formData.get('status') as string,
      severity: formData.get('severity') as string,
      follow_up_date: formData.get('follow_up_date') as string || null,
      follow_up_notes: formData.get('follow_up_notes') as string || null,
    };

    try {
      if (editingAction) {
        const { error } = await supabase
          .from('disciplinary_actions')
          .update(actionData)
          .eq('id', editingAction.id);
        
        if (error) throw error;
        toast.success('საყვედური განახლდა');
      } else {
        const { error } = await supabase
          .from('disciplinary_actions')
          .insert([actionData]);
        
        if (error) throw error;
        toast.success('საყვედური დაემატა');
      }
      
      setIsDialogOpen(false);
      setEditingAction(null);
      fetchDisciplinaryActions();
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const handleDelete = async (action: DisciplinaryAction) => {
    if (!confirm('ნამდვილად გსურთ ამ საყვედურის წაშლა?')) return;

    try {
      const { error } = await supabase
        .from('disciplinary_actions')
        .delete()
        .eq('id', action.id);
      
      if (error) throw error;
      toast.success('საყვედური წაიშალა');
      fetchDisciplinaryActions();
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const handleEdit = (action: DisciplinaryAction) => {
    setEditingAction(action);
    setIsDialogOpen(true);
  };

  if (!canManage) {
    return (
      <>
        <div className="p-8 text-center">
          <p className="text-muted-foreground">თქვენ არ გაქვთ წვდომა ამ გვერდზე</p>
        </div>
      </>
    );
  }

  // Filtered data
  const filteredActions = actions.filter(action => {
    const matchesSearch = 
      action.reason.toLowerCase().includes(searchTerm.toLowerCase()) ||
      action.employee?.full_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || action.status === statusFilter;
    const matchesSeverity = severityFilter === 'all' || action.severity === severityFilter;
    return matchesSearch && matchesStatus && matchesSeverity;
  });

  // Stats
  const totalActions = actions.length;
  const activeActions = actions.filter(a => a.status === 'active').length;
  const criticalActions = actions.filter(a => a.severity === 'critical').length;

  return (
    <>
      <div className="p-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-red-500/10">
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">დისციპლინური საყვედურები</h1>
              <p className="text-muted-foreground">თანამშრომლების დისციპლინური ქმედებები</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-500/10">
                  <AlertTriangle className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">სულ საყვედურები</p>
                  <p className="text-2xl font-bold">{totalActions}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-orange-500/10">
                  <AlertTriangle className="h-5 w-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">აქტიური</p>
                  <p className="text-2xl font-bold">{activeActions}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-red-500/10">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">კრიტიკული</p>
                  <p className="text-2xl font-bold">{criticalActions}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Card */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between gap-4">
              <div className="flex-1">
                <CardTitle>საყვედურების სია</CardTitle>
                <CardDescription>ყველა დისციპლინური ქმედება</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative w-48">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="ძიება..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>
                
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-36">
                    <SelectValue placeholder="სტატუსი" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა</SelectItem>
                    <SelectItem value="active">აქტიური</SelectItem>
                    <SelectItem value="resolved">გადაწყვეტილი</SelectItem>
                    <SelectItem value="appealed">საჩივრის პროცესში</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={severityFilter} onValueChange={setSeverityFilter}>
                  <SelectTrigger className="w-36">
                    <SelectValue placeholder="სერიოზულობა" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა</SelectItem>
                    <SelectItem value="low">დაბალი</SelectItem>
                    <SelectItem value="medium">საშუალო</SelectItem>
                    <SelectItem value="high">მაღალი</SelectItem>
                    <SelectItem value="critical">კრიტიკული</SelectItem>
                  </SelectContent>
                </Select>

                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={() => setEditingAction(null)}>
                      <Plus className="h-4 w-4 mr-2" />
                      ახალი საყვედური
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>
                        {editingAction ? 'საყვედურის რედაქტირება' : 'ახალი საყვედური'}
                      </DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleSave} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="employee_id">თანამშრომელი *</Label>
                          <Select 
                            name="employee_id" 
                            defaultValue={editingAction?.employee_id}
                            required
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="აირჩიეთ..." />
                            </SelectTrigger>
                            <SelectContent>
                              {employees.map((emp) => (
                                <SelectItem key={emp.id} value={emp.id}>
                                  {emp.full_name}
                                  {emp.department && ` - ${emp.department}`}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="action_type">საყვედურის ტიპი *</Label>
                          <Select 
                            name="action_type" 
                            defaultValue={editingAction?.action_type || 'verbal_warning'}
                            required
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="verbal_warning">სიტყვიერი გაფრთხილება</SelectItem>
                              <SelectItem value="written_warning">წერილობითი გაფრთხილება</SelectItem>
                              <SelectItem value="suspension">შეჩერება</SelectItem>
                              <SelectItem value="termination">გათავისუფლება</SelectItem>
                              <SelectItem value="other">სხვა</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="severity">სერიოზულობა *</Label>
                          <Select 
                            name="severity" 
                            defaultValue={editingAction?.severity || 'low'}
                            required
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="low">დაბალი</SelectItem>
                              <SelectItem value="medium">საშუალო</SelectItem>
                              <SelectItem value="high">მაღალი</SelectItem>
                              <SelectItem value="critical">კრიტიკული</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="status">სტატუსი *</Label>
                          <Select 
                            name="status" 
                            defaultValue={editingAction?.status || 'active'}
                            required
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="active">აქტიური</SelectItem>
                              <SelectItem value="resolved">გადაწყვეტილი</SelectItem>
                              <SelectItem value="appealed">საჩივრის პროცესში</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="reason">მიზეზი *</Label>
                        <Input
                          id="reason"
                          name="reason"
                          defaultValue={editingAction?.reason}
                          placeholder="მაგ: დისციპლინის დარღვევა"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="description">დეტალური აღწერა</Label>
                        <Textarea
                          id="description"
                          name="description"
                          defaultValue={editingAction?.description || ''}
                          placeholder="დეტალური ინფორმაცია საყვედურის შესახებ..."
                          rows={4}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="issued_date">გამოცემის თარიღი *</Label>
                          <Input
                            id="issued_date"
                            name="issued_date"
                            type="date"
                            defaultValue={editingAction?.issued_date || new Date().toISOString().split('T')[0]}
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="follow_up_date">შემდგომი შემოწმება</Label>
                          <Input
                            id="follow_up_date"
                            name="follow_up_date"
                            type="date"
                            defaultValue={editingAction?.follow_up_date || ''}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="follow_up_notes">შენიშვნები შემდგომი შემოწმებისთვის</Label>
                        <Textarea
                          id="follow_up_notes"
                          name="follow_up_notes"
                          defaultValue={editingAction?.follow_up_notes || ''}
                          placeholder="რა უნდა შემოწმდეს..."
                          rows={3}
                        />
                      </div>

                      <div className="flex justify-end gap-2 pt-4">
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => {
                            setIsDialogOpen(false);
                            setEditingAction(null);
                          }}
                        >
                          გაუქმება
                        </Button>
                        <Button type="submit">
                          {editingAction ? 'განახლება' : 'შენახვა'}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {filteredActions.length === 0 ? (
              <div className="text-center py-12">
                <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                <p className="text-muted-foreground">
                  {searchTerm || statusFilter !== 'all' || severityFilter !== 'all'
                    ? 'ფილტრით საყვედურები არ მოიძებნა'
                    : 'დისციპლინური საყვედურები არ არის'}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {filteredActions.map((action) => (
                  <DisciplinaryActionCard
                    key={action.id}
                    action={action}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                    canManage={canManage}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default Disciplinary;
