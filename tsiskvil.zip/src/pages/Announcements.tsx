import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Pin, Eye, EyeOff, Pencil, Trash2, Search } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";

interface Announcement {
  id: string;
  title: string;
  content: string;
  announcement_type: string;
  target_audience: string;
  priority: string;
  is_pinned: boolean;
  published: boolean;
  created_at: string;
  updated_at: string;
  created_by: string;
}

export default function Announcements() {
  const { user, userRole } = useAuth();
  const { t } = useLanguage();
  const canManage = userRole === 'admin' || userRole === 'hr_manager';
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [openDialog, setOpenDialog] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [announcementToDelete, setAnnouncementToDelete] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    announcement_type: "general",
    target_audience: "all",
    priority: "normal",
    is_pinned: false,
    published: true,
  });

  useEffect(() => {
    fetchAnnouncements();
  }, []);

  const fetchAnnouncements = async () => {
    try {
      const { data, error } = await supabase
        .from("announcements")
        .select("*")
        .order("is_pinned", { ascending: false })
        .order("created_at", { ascending: false });

      if (error) throw error;
      setAnnouncements(data || []);
    } catch (error: any) {
      toast.error("შეცდომა გამოცხადებების ჩატვირთვისას");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!formData.title || !formData.content) {
      toast.error("გთხოვთ შეავსოთ ყველა სავალდებულო ველი");
      return;
    }

    try {
      if (editingAnnouncement) {
        const { error } = await supabase
          .from("announcements")
          .update({
            ...formData,
            updated_at: new Date().toISOString(),
          })
          .eq("id", editingAnnouncement.id);

        if (error) throw error;
        toast.success("გამოცხადება წარმატებით განახლდა");
      } else {
        const { error } = await supabase
          .from("announcements")
          .insert([
            {
              ...formData,
              created_by: user?.id,
            },
          ]);

        if (error) throw error;
        toast.success("გამოცხადება წარმატებით შეიქმნა");
      }

      setOpenDialog(false);
      setEditingAnnouncement(null);
      resetForm();
      fetchAnnouncements();
    } catch (error: any) {
      toast.error("შეცდომა გამოცხადების შენახვისას");
      console.error(error);
    }
  };

  const handleEdit = (announcement: Announcement) => {
    setEditingAnnouncement(announcement);
    setFormData({
      title: announcement.title,
      content: announcement.content,
      announcement_type: announcement.announcement_type,
      target_audience: announcement.target_audience,
      priority: announcement.priority,
      is_pinned: announcement.is_pinned,
      published: announcement.published,
    });
    setOpenDialog(true);
  };

  const handleDelete = async () => {
    if (!announcementToDelete) return;

    try {
      const { error } = await supabase
        .from("announcements")
        .delete()
        .eq("id", announcementToDelete);

      if (error) throw error;
      toast.success("გამოცხადება წარმატებით წაიშალა");
      fetchAnnouncements();
    } catch (error: any) {
      toast.error("შეცდომა წაშლისას");
      console.error(error);
    } finally {
      setDeleteDialogOpen(false);
      setAnnouncementToDelete(null);
    }
  };

  const togglePublish = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from("announcements")
        .update({ published: !currentStatus })
        .eq("id", id);

      if (error) throw error;
      toast.success(currentStatus ? "გამოცხადება დამალულია" : "გამოცხადება გამოქვეყნდა");
      fetchAnnouncements();
    } catch (error: any) {
      toast.error("შეცდომა სტატუსის შეცვლისას");
      console.error(error);
    }
  };

  const togglePin = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from("announcements")
        .update({ is_pinned: !currentStatus })
        .eq("id", id);

      if (error) throw error;
      toast.success(currentStatus ? "გამოცხადება მოხსნილია" : "გამოცხადება ჩამაგრდა");
      fetchAnnouncements();
    } catch (error: any) {
      toast.error("შეცდომა");
      console.error(error);
    }
  };

  const resetForm = () => {
    setFormData({
      title: "",
      content: "",
      announcement_type: "general",
      target_audience: "all",
      priority: "normal",
      is_pinned: false,
      published: true,
    });
  };

  const filteredAnnouncements = announcements.filter((announcement) =>
    announcement.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    announcement.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getPriorityBadge = (priority: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      low: "secondary",
      normal: "default",
      high: "destructive",
    };
    return variants[priority] || "default";
  };

  const getTypeBadge = (type: string) => {
    const labels: Record<string, string> = {
      general: "ზოგადი",
      hr: "HR",
      event: "ღონისძიება",
      policy: "პოლიტიკა",
      celebration: "დღესასწაული",
    };
    return labels[type] || type;
  };

  const getAudienceBadge = (audience: string) => {
    const labels: Record<string, string> = {
      all: "ყველა",
      employees: "თანამშრომლები",
      managers: "მენეჯერები",
      hr: "HR",
    };
    return labels[audience] || audience;
  };

  if (loading) {
    return (
      <>
        <div className="flex items-center justify-center h-96">
          <div className="text-lg">იტვირთება...</div>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">გამოცხადებები (News Feed)</h1>
            <p className="text-muted-foreground mt-1">მართეთ კომპანიის სიახლეები და გამოცხადებები</p>
          </div>
          <Dialog open={openDialog} onOpenChange={(open) => {
            setOpenDialog(open);
            if (!open) {
              setEditingAnnouncement(null);
              resetForm();
            }
          }}>
            {canManage && (
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                ახალი გამოცხადება
              </Button>
            </DialogTrigger>
            )}
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingAnnouncement ? "გამოცხადების რედაქტირება" : "ახალი გამოცხადება"}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">სათაური *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="შეიყვანეთ სათაური"
                  />
                </div>

                <div>
                  <Label htmlFor="content">შინაარსი *</Label>
                  <Textarea
                    id="content"
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    placeholder="შეიყვანეთ შინაარსი"
                    rows={5}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="type">ტიპი</Label>
                    <Select
                      value={formData.announcement_type}
                      onValueChange={(value) => setFormData({ ...formData, announcement_type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">ზოგადი</SelectItem>
                        <SelectItem value="hr">HR</SelectItem>
                        <SelectItem value="event">ღონისძიება</SelectItem>
                        <SelectItem value="policy">პოლიტიკა</SelectItem>
                        <SelectItem value="celebration">დღესასწაული</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="audience">აუდიტორია</Label>
                    <Select
                      value={formData.target_audience}
                      onValueChange={(value) => setFormData({ ...formData, target_audience: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">ყველა</SelectItem>
                        <SelectItem value="employees">თანამშრომლები</SelectItem>
                        <SelectItem value="managers">მენეჯერები</SelectItem>
                        <SelectItem value="hr">HR</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="priority">პრიორიტეტი</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value) => setFormData({ ...formData, priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">დაბალი</SelectItem>
                      <SelectItem value="normal">ნორმალური</SelectItem>
                      <SelectItem value="high">მაღალი</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="published"
                    checked={formData.published}
                    onCheckedChange={(checked) => setFormData({ ...formData, published: checked })}
                  />
                  <Label htmlFor="published">გამოქვეყნებული</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="pinned"
                    checked={formData.is_pinned}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_pinned: checked })}
                  />
                  <Label htmlFor="pinned">ჩამაგრებული</Label>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => {
                  setOpenDialog(false);
                  setEditingAnnouncement(null);
                  resetForm();
                }}>
                  გაუქმება
                </Button>
                <Button onClick={handleSubmit}>
                  {editingAnnouncement ? "განახლება" : "შექმნა"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="ძიება..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {filteredAnnouncements.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-muted-foreground">გამოცხადებები ვერ მოიძებნა</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredAnnouncements.map((announcement) => (
              <Card key={announcement.id} className={announcement.is_pinned ? "border-primary" : ""}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {announcement.is_pinned && (
                          <Pin className="h-4 w-4 text-primary" />
                        )}
                        <CardTitle>{announcement.title}</CardTitle>
                      </div>
                      <div className="flex gap-2 flex-wrap">
                        <Badge variant={getPriorityBadge(announcement.priority)}>
                          {announcement.priority === "high" ? "მაღალი" : announcement.priority === "normal" ? "ნორმალური" : "დაბალი"}
                        </Badge>
                        <Badge variant="outline">{getTypeBadge(announcement.announcement_type)}</Badge>
                        <Badge variant="secondary">{getAudienceBadge(announcement.target_audience)}</Badge>
                        {announcement.published ? (
                          <Badge variant="default" className="bg-green-500">
                            <Eye className="h-3 w-3 mr-1" />
                            გამოქვეყნებული
                          </Badge>
                        ) : (
                          <Badge variant="secondary">
                            <EyeOff className="h-3 w-3 mr-1" />
                            დამალული
                          </Badge>
                        )}
                      </div>
                    </div>
                    {canManage && (
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => togglePin(announcement.id, announcement.is_pinned)}
                        title={announcement.is_pinned ? "მოხსნა" : "ჩამაგრება"}
                      >
                        <Pin className={`h-4 w-4 ${announcement.is_pinned ? "fill-current text-primary" : ""}`} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => togglePublish(announcement.id, announcement.published)}
                        title={announcement.published ? "დამალვა" : "გამოქვეყნება"}
                      >
                        {announcement.published ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEdit(announcement)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          setAnnouncementToDelete(announcement.id);
                          setDeleteDialogOpen(true);
                        }}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="whitespace-pre-wrap">
                    {announcement.content}
                  </CardDescription>
                  <div className="mt-4 text-xs text-muted-foreground">
                    შეიქმნა: {new Date(announcement.created_at).toLocaleDateString("ka-GE")}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>დარწმუნებული ხართ?</AlertDialogTitle>
            <AlertDialogDescription>
              ეს მოქმედება შეუქცევადია. გამოცხადება სამუდამოდ წაიშლება.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>გაუქმება</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              წაშლა
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
