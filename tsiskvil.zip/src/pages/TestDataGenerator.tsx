import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { 
  Database, 
  Users, 
  Calendar, 
  Clock, 
  FileText, 
  PlayCircle,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  Trash2,
  Briefcase,
  DollarSign,
  PiggyBank,
  GraduationCap,
  Star,
  Gift,
  Scale
} from "lucide-react";
import { format, subDays, addDays, startOfMonth, endOfMonth, eachDayOfInterval, isWeekend } from "date-fns";

interface GenerationStep {
  id: string;
  name: string;
  status: 'pending' | 'running' | 'completed' | 'error';
  count?: number;
}

const TestDataGenerator = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [steps, setSteps] = useState<GenerationStep[]>([]);
  const [options, setOptions] = useState({
    createEmployees: true,
    createAttendance: true,
    createLeaveRequests: true,
    createShiftSchedules: true,
    createBusinessTrips: true,
    createPayroll: true,
    createPension: true,
    createTrainings: true,
    createEvaluations: true,
    createBonuses: true,
    createDisciplinary: true,
    attendanceMonths: 3,
  });

  // Department and Schedule IDs (from query results)
  const HR_DEPARTMENT_ID = "1251c8f8-d397-46a9-9a18-f4a47d3b569f";
  const LOGISTICS_DEPARTMENT_ID = "6c2a2716-e628-45b4-9aae-f06bdee95502";
  const FULL_SCHEDULE_ID = "618684f3-a337-4dfa-b3cb-7e2d2c0ee191";
  const DAY_SHIFT_ID = "30f6242e-367e-4ca9-9c4b-ef1e8dd6bb33";
  const NIGHT_SHIFT_ID = "f67c9eb0-596a-4017-ad43-df0de742eadb";

  const georgianFirstNames = [
    "გიორგი", "ნიკა", "დავით", "ლუკა", "ალექსანდრე",
    "მარიამ", "ანა", "ნინო", "თამარ", "ელენე",
    "ზურაბ", "ვახტანგ", "ლაშა", "გოგა", "თენგიზ",
    "ეკა", "ქეთი", "სოფო", "ნათია", "მაია"
  ];

  const georgianLastNames = [
    "ბერიძე", "კაპანაძე", "გელაშვილი", "მამულაშვილი", "ხარაიშვილი",
    "ჯაფარიძე", "სულაკაური", "ნადირაძე", "ქვარცხავა", "ბუჩუკური",
    "ჩხეიძე", "გოგოლაძე", "ბაქრაძე", "მგელაძე", "გიგაური"
  ];

  const positions = {
    hr: ["HR მენეჯერი", "HR სპეციალისტი", "რეკრუტერი", "ტრენერი", "HR ასისტენტი"],
    logistics: ["ლოგისტიკის მენეჯერი", "დისპეჩერი", "მძღოლი", "საწყობის მუშაკი", "კოორდინატორი",
               "ოპერატორი", "შემფუთველი", "მაკომპლექტებელი", "ინვენტარის სპეციალისტი", "მიმღები"]
  };

  const generateRandomPhone = () => {
    const prefix = ["555", "557", "558", "577", "599"][Math.floor(Math.random() * 5)];
    const number = Math.floor(100000 + Math.random() * 900000);
    return `+995${prefix}${number}`;
  };

  const generateRandomPersonalId = () => {
    return Math.floor(10000000000 + Math.random() * 89999999999).toString();
  };

  const generateRandomDate = (startYear: number, endYear: number) => {
    const start = new Date(startYear, 0, 1);
    const end = new Date(endYear, 11, 31);
    return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
  };

  const updateStep = (stepId: string, status: GenerationStep['status'], count?: number) => {
    setSteps(prev => prev.map(s => 
      s.id === stepId ? { ...s, status, count: count ?? s.count } : s
    ));
  };

  const generateTestData = async () => {
    setIsGenerating(true);
    setProgress(0);
    
    const initialSteps: GenerationStep[] = [];
    if (options.createEmployees) {
      initialSteps.push({ id: 'hr-employees', name: 'HR თანამშრომლები (5)', status: 'pending' });
      initialSteps.push({ id: 'logistics-employees', name: 'ლოგისტიკის თანამშრომლები (10)', status: 'pending' });
      initialSteps.push({ id: 'work-schedules', name: 'სამუშაო გრაფიკები', status: 'pending' });
    }
    if (options.createShiftSchedules) {
      initialSteps.push({ id: 'shift-schedules', name: 'ცვლების გრაფიკები', status: 'pending' });
    }
    if (options.createAttendance) {
      initialSteps.push({ id: 'attendance', name: 'დასწრების მონაცემები', status: 'pending' });
    }
    if (options.createLeaveRequests) {
      initialSteps.push({ id: 'leave-requests', name: 'შვებულების მოთხოვნები', status: 'pending' });
    }
    if (options.createBusinessTrips) {
      initialSteps.push({ id: 'business-trips', name: 'მივლინებები', status: 'pending' });
    }
    if (options.createPayroll) {
      initialSteps.push({ id: 'payroll', name: 'ხელფასები (მიმდინარე თვე)', status: 'pending' });
    }
    if (options.createPension) {
      initialSteps.push({ id: 'pension', name: 'საპენსიო გადახდები (მიმდინარე თვე)', status: 'pending' });
    }
    if (options.createTrainings) {
      initialSteps.push({ id: 'trainings', name: 'ტრენინგები', status: 'pending' });
    }
    if (options.createEvaluations) {
      initialSteps.push({ id: 'evaluations', name: 'შეფასებები', status: 'pending' });
    }
    if (options.createBonuses) {
      initialSteps.push({ id: 'bonuses', name: 'ბონუსები', status: 'pending' });
    }
    if (options.createDisciplinary) {
      initialSteps.push({ id: 'disciplinary', name: 'დისციპლინური ზომები', status: 'pending' });
    }
    
    setSteps(initialSteps);
    
    const totalSteps = initialSteps.length;
    let completedSteps = 0;
    const createdEmployeeIds: string[] = [];

    try {
      // 1. Create HR Employees (5)
      if (options.createEmployees) {
        updateStep('hr-employees', 'running');
        const hrEmployees = [];
        
        for (let i = 0; i < 5; i++) {
          const firstName = georgianFirstNames[Math.floor(Math.random() * georgianFirstNames.length)];
          const lastName = georgianLastNames[Math.floor(Math.random() * georgianLastNames.length)];
          const position = positions.hr[i];
          const birthDate = generateRandomDate(1970, 2000);
          const hireDate = generateRandomDate(2020, 2024);
          
          hrEmployees.push({
            full_name: `${firstName} ${lastName}`,
            email: `test.hr.${i + 1}.${Date.now()}@test.ge`,
            phone: generateRandomPhone(),
            personal_id_number: generateRandomPersonalId(),
            position: position,
            department: 'ადამიანური რესურსები',
            date_of_birth: format(birthDate, 'yyyy-MM-dd'),
            hire_date: format(hireDate, 'yyyy-MM-dd'),
            salary: 2000 + Math.floor(Math.random() * 3000),
            status: 'active',
            gender: i < 3 ? 'male' : 'female',
          });
        }

        const { data: hrData, error: hrError } = await supabase
          .from('employees')
          .insert(hrEmployees)
          .select('id');

        if (hrError) throw hrError;
        hrData?.forEach(e => createdEmployeeIds.push(e.id));
        updateStep('hr-employees', 'completed', 5);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);

        // 2. Create Logistics Employees (10)
        updateStep('logistics-employees', 'running');
        const logisticsEmployees = [];
        
        for (let i = 0; i < 10; i++) {
          const firstName = georgianFirstNames[Math.floor(Math.random() * georgianFirstNames.length)];
          const lastName = georgianLastNames[Math.floor(Math.random() * georgianLastNames.length)];
          const position = positions.logistics[i];
          const birthDate = generateRandomDate(1975, 2002);
          const hireDate = generateRandomDate(2021, 2024);
          
          logisticsEmployees.push({
            full_name: `${firstName} ${lastName}`,
            email: `test.logistics.${i + 1}.${Date.now()}@test.ge`,
            phone: generateRandomPhone(),
            personal_id_number: generateRandomPersonalId(),
            position: position,
            department: 'ლოგისტიკა',
            date_of_birth: format(birthDate, 'yyyy-MM-dd'),
            hire_date: format(hireDate, 'yyyy-MM-dd'),
            salary: 1500 + Math.floor(Math.random() * 2000),
            status: 'active',
            gender: i < 7 ? 'male' : 'female',
          });
        }

        const { data: logData, error: logError } = await supabase
          .from('employees')
          .insert(logisticsEmployees)
          .select('id');

        if (logError) throw logError;
        logData?.forEach(e => createdEmployeeIds.push(e.id));
        updateStep('logistics-employees', 'completed', 10);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);

        // 3. Create Work Schedules
        updateStep('work-schedules', 'running');
        const workSchedules = [];
        
        // HR employees - full schedule (09:00-18:00)
        for (let i = 0; i < 5; i++) {
          workSchedules.push({
            employee_id: createdEmployeeIds[i],
            template_id: FULL_SCHEDULE_ID,
            schedule_type: 'სრული 1',
            start_time: '09:00',
            end_time: '18:00',
            break_duration: 60,
            effective_from: format(subDays(new Date(), 90), 'yyyy-MM-dd'),
          });
        }

        // Logistics employees - shifts
        for (let i = 5; i < 15; i++) {
          const isNightShift = (i - 5) % 2 !== 0;
          workSchedules.push({
            employee_id: createdEmployeeIds[i],
            template_id: isNightShift ? NIGHT_SHIFT_ID : DAY_SHIFT_ID,
            schedule_type: isNightShift ? 'ცვლები' : 'ცვლები',
            start_time: isNightShift ? '20:00' : '08:00',
            end_time: isNightShift ? '08:00' : '20:00',
            break_duration: 60,
            effective_from: format(subDays(new Date(), 90), 'yyyy-MM-dd'),
          });
        }

        const { error: wsError } = await supabase
          .from('work_schedules')
          .insert(workSchedules);

        if (wsError) throw wsError;
        updateStep('work-schedules', 'completed', workSchedules.length);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);
      }

      // 4. Create Shift Schedules for Logistics
      if (options.createShiftSchedules && createdEmployeeIds.length >= 15) {
        updateStep('shift-schedules', 'running');
        const shiftSchedules = [];
        const today = new Date();
        const monthStart = startOfMonth(today);
        const monthEnd = endOfMonth(today);
        const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

        for (let i = 5; i < 15; i++) {
          const isNightShift = (i - 5) % 2 !== 0;
          
          daysInMonth.forEach((day, dayIndex) => {
            // Create shifts for alternating days (like real shift work)
            if ((dayIndex + i) % 3 !== 0) { // Skip some days for realistic scheduling
              shiftSchedules.push({
                employee_id: createdEmployeeIds[i],
                shift_date: format(day, 'yyyy-MM-dd'),
                start_time: isNightShift ? '20:00:00' : '08:00:00',
                end_time: isNightShift ? '08:00:00' : '20:00:00',
                break_duration: 60,
                shift_name: isNightShift ? 'ღამის ცვლა' : 'დღის ცვლა',
              });
            }
          });
        }

        // Insert in batches of 100
        for (let i = 0; i < shiftSchedules.length; i += 100) {
          const batch = shiftSchedules.slice(i, i + 100);
          const { error: ssError } = await supabase
            .from('shift_schedules')
            .insert(batch);
          if (ssError) console.error('Shift schedule batch error:', ssError);
        }

        updateStep('shift-schedules', 'completed', shiftSchedules.length);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);
      }

      // 5. Create Attendance Records
      if (options.createAttendance && createdEmployeeIds.length > 0) {
        updateStep('attendance', 'running');
        const attendanceRecords = [];
        const startDate = subDays(new Date(), options.attendanceMonths * 30);
        const today = new Date();
        const days = eachDayOfInterval({ start: startDate, end: subDays(today, 1) });

        for (const employeeId of createdEmployeeIds) {
          const employeeIndex = createdEmployeeIds.indexOf(employeeId);
          const isHR = employeeIndex < 5;
          const isNightShift = !isHR && (employeeIndex - 5) % 2 !== 0;

          days.forEach((day, dayIndex) => {
            // Skip weekends for HR employees
            if (isHR && isWeekend(day)) return;
            
            // Skip some days randomly for logistics (shift pattern)
            if (!isHR && (dayIndex + employeeIndex) % 3 === 0) return;

            // Random attendance variations
            const hasLateArrival = Math.random() < 0.1; // 10% late
            const hasEarlyDeparture = Math.random() < 0.05; // 5% early departure
            const isAbsent = Math.random() < 0.03; // 3% absent

            if (isAbsent) {
              attendanceRecords.push({
                employee_id: employeeId,
                date: format(day, 'yyyy-MM-dd'),
                status: 'absent',
              });
            } else {
              let checkIn, checkOut;
              
              if (isHR) {
                checkIn = hasLateArrival 
                  ? `09:${String(Math.floor(Math.random() * 30) + 10).padStart(2, '0')}` 
                  : `08:${String(Math.floor(Math.random() * 15) + 45).padStart(2, '0')}`;
                checkOut = hasEarlyDeparture 
                  ? `17:${String(Math.floor(Math.random() * 30) + 15).padStart(2, '0')}` 
                  : `18:${String(Math.floor(Math.random() * 30)).padStart(2, '0')}`;
              } else if (isNightShift) {
                checkIn = hasLateArrival 
                  ? `20:${String(Math.floor(Math.random() * 20) + 10).padStart(2, '0')}` 
                  : `19:${String(Math.floor(Math.random() * 15) + 45).padStart(2, '0')}`;
                checkOut = `08:${String(Math.floor(Math.random() * 30)).padStart(2, '0')}`;
              } else {
                checkIn = hasLateArrival 
                  ? `08:${String(Math.floor(Math.random() * 30) + 10).padStart(2, '0')}` 
                  : `07:${String(Math.floor(Math.random() * 15) + 45).padStart(2, '0')}`;
                checkOut = hasEarlyDeparture 
                  ? `19:${String(Math.floor(Math.random() * 30) + 15).padStart(2, '0')}` 
                  : `20:${String(Math.floor(Math.random() * 30)).padStart(2, '0')}`;
              }

              attendanceRecords.push({
                employee_id: employeeId,
                date: format(day, 'yyyy-MM-dd'),
                check_in: checkIn,
                check_out: checkOut,
                status: 'present',
                lateness_justified: hasLateArrival ? (Math.random() > 0.5 ? true : null) : null,
                lateness_comment: hasLateArrival ? 'ტესტ კომენტარი' : null,
              });
            }
          });
        }

        // Insert in batches of 200
        for (let i = 0; i < attendanceRecords.length; i += 200) {
          const batch = attendanceRecords.slice(i, i + 200);
          const { error: attError } = await supabase
            .from('attendance')
            .insert(batch);
          if (attError) console.error('Attendance batch error:', attError);
        }

        updateStep('attendance', 'completed', attendanceRecords.length);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);
      }

      // 6. Create Leave Requests
      if (options.createLeaveRequests && createdEmployeeIds.length > 0) {
        updateStep('leave-requests', 'running');
        const leaveRequests = [];
        
        // Create 2-3 leave requests per employee
        for (const employeeId of createdEmployeeIds) {
          const numLeaves = Math.floor(Math.random() * 2) + 1;
          
          for (let i = 0; i < numLeaves; i++) {
            const startDate = subDays(new Date(), Math.floor(Math.random() * 60) + 10);
            const duration = Math.floor(Math.random() * 5) + 1;
            const endDate = addDays(startDate, duration);
            const statuses = ['approved', 'pending', 'rejected'];
            const leaveTypes = ['annual', 'sick', 'personal'];
            
            leaveRequests.push({
              employee_id: employeeId,
              user_id: (await supabase.auth.getUser()).data.user?.id,
              start_date: format(startDate, 'yyyy-MM-dd'),
              end_date: format(endDate, 'yyyy-MM-dd'),
              leave_type: leaveTypes[Math.floor(Math.random() * leaveTypes.length)],
              status: statuses[Math.floor(Math.random() * statuses.length)],
              reason: 'ტესტ შვებულების მოთხოვნა',
            });
          }
        }

        const { error: leaveError } = await supabase
          .from('leave_requests')
          .insert(leaveRequests);

        if (leaveError) console.error('Leave requests error:', leaveError);
        updateStep('leave-requests', 'completed', leaveRequests.length);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);
      }

      // 7. Create Business Trip Requests
      if (options.createBusinessTrips && createdEmployeeIds.length > 0) {
        updateStep('business-trips', 'running');
        const businessTrips = [];
        const destinations = ['ბათუმი', 'ქუთაისი', 'რუსთავი', 'გორი', 'თელავი', 'ზუგდიდი'];
        const purposes = [
          'კლიენტთან შეხვედრა',
          'კონფერენციაზე მონაწილეობა',
          'ტრენინგის ჩატარება',
          'პარტნიორთან მოლაპარაკება',
          'საწყობის შემოწმება',
          'ახალი ფილიალის გახსნა'
        ];
        const transportTypes = ['company_car', 'personal_car', 'public_transport', 'train'];
        
        // Create 1-2 business trips per employee
        for (const employeeId of createdEmployeeIds.slice(0, 10)) {
          const numTrips = Math.floor(Math.random() * 2) + 1;
          
          for (let i = 0; i < numTrips; i++) {
            const startDate = addDays(new Date(), Math.floor(Math.random() * 30) + 5);
            const duration = Math.floor(Math.random() * 4) + 1;
            const endDate = addDays(startDate, duration);
            const statuses = ['approved', 'pending_manager', 'pending_hr', 'rejected'];
            
            businessTrips.push({
              employee_id: employeeId,
              user_id: (await supabase.auth.getUser()).data.user?.id,
              destination: destinations[Math.floor(Math.random() * destinations.length)],
              purpose: purposes[Math.floor(Math.random() * purposes.length)],
              start_date: format(startDate, 'yyyy-MM-dd'),
              end_date: format(endDate, 'yyyy-MM-dd'),
              status: statuses[Math.floor(Math.random() * statuses.length)],
              estimated_budget: Math.floor(Math.random() * 500 + 100),
              transportation_type: transportTypes[Math.floor(Math.random() * transportTypes.length)],
              accommodation_needed: Math.random() > 0.5,
            });
          }
        }

        const { error: tripError } = await supabase
          .from('business_trip_requests')
          .insert(businessTrips);

        if (tripError) console.error('Business trips error:', tripError);
        updateStep('business-trips', 'completed', businessTrips.length);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);
      }

      // 8. Create Payroll for current month
      if (options.createPayroll && createdEmployeeIds.length > 0) {
        updateStep('payroll', 'running');
        const currentMonth = new Date().getMonth() + 1;
        const currentYear = new Date().getFullYear();
        const payrollRecords = [];

        for (const employeeId of createdEmployeeIds) {
          const employeeIndex = createdEmployeeIds.indexOf(employeeId);
          const baseSalary = 1500 + Math.floor(Math.random() * 2500);
          const bonuses = Math.random() > 0.7 ? Math.floor(Math.random() * 500) : 0;
          const deductions = Math.floor(baseSalary * 0.02); // 2% pension
          const incomeTax = Math.floor((baseSalary + bonuses - deductions) * 0.2); // 20% tax
          const netSalary = baseSalary + bonuses - deductions - incomeTax;
          const overtimeHours = Math.random() > 0.8 ? Math.floor(Math.random() * 10) : 0;

          payrollRecords.push({
            employee_id: employeeId,
            month: currentMonth,
            year: currentYear,
            base_salary: baseSalary,
            bonuses: bonuses,
            deductions: deductions + incomeTax,
            gross_salary: baseSalary + bonuses,
            net_salary: netSalary,
            overtime_hours: overtimeHours,
            overtime_pay: overtimeHours * 15,
            status: Math.random() > 0.3 ? 'paid' : 'pending',
          });
        }

        const { error: payrollError } = await supabase
          .from('payroll')
          .insert(payrollRecords);

        if (payrollError) console.error('Payroll error:', payrollError);
        updateStep('payroll', 'completed', payrollRecords.length);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);
      }

      // 9. Create Pension Payments for current month
      if (options.createPension && createdEmployeeIds.length > 0) {
        updateStep('pension', 'running');
        const currentMonth = new Date().getMonth() + 1;
        const currentYear = new Date().getFullYear();
        const pensionRecords = [];

        for (const employeeId of createdEmployeeIds) {
          const baseSalary = 1500 + Math.floor(Math.random() * 2500);
          const employeeContribution = Math.floor(baseSalary * 0.02);
          const employerContribution = Math.floor(baseSalary * 0.02);
          const totalAmount = employeeContribution + employerContribution;

          pensionRecords.push({
            employee_id: employeeId,
            period_month: currentMonth,
            period_year: currentYear,
            base_salary: baseSalary,
            employee_contribution: employeeContribution,
            employer_contribution: employerContribution,
            total_amount: totalAmount,
            payment_date: format(new Date(), 'yyyy-MM-dd'),
            status: Math.random() > 0.3 ? 'paid' : 'pending',
          });
        }

        const { error: pensionError } = await supabase
          .from('pension_payments')
          .insert(pensionRecords);

        if (pensionError) console.error('Pension error:', pensionError);
        updateStep('pension', 'completed', pensionRecords.length);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);
      }

      // 10. Create Training Courses
      if (options.createTrainings) {
        updateStep('trainings', 'running');
        const trainingRecords = [];
        const trainingTitles = [
          'უსაფრთხოების ტრენინგი',
          'პირველადი სამედიცინო დახმარება',
          'ხანძარსაწინააღმდეგო ინსტრუქტაჟი',
          'კომუნიკაციის უნარები',
          'ლიდერობის განვითარება',
          'კლიენტებთან მომსახურება',
          'Excel-ის კურსი',
          'პროექტების მართვა'
        ];
        const categories = ['სავალდებულო', 'პროფესიული', 'soft_skills', 'ტექნიკური'];

        for (let i = 0; i < 8; i++) {
          const startDate = addDays(new Date(), Math.floor(Math.random() * 30) + 1);
          trainingRecords.push({
            title: trainingTitles[i],
            description: `${trainingTitles[i]} - სრული კურსი`,
            category: categories[Math.floor(Math.random() * categories.length)],
            start_date: format(startDate, 'yyyy-MM-dd'),
            end_date: format(addDays(startDate, Math.floor(Math.random() * 3) + 1), 'yyyy-MM-dd'),
            instructor_name: georgianFirstNames[Math.floor(Math.random() * georgianFirstNames.length)] + ' ' + 
                       georgianLastNames[Math.floor(Math.random() * georgianLastNames.length)],
            max_participants: Math.floor(Math.random() * 15) + 5,
            is_online: Math.random() > 0.5,
            course_status: ['active', 'upcoming', 'completed'][Math.floor(Math.random() * 3)],
          });
        }

        const { error: trainingError } = await supabase
          .from('training_courses')
          .insert(trainingRecords);

        if (trainingError) console.error('Training error:', trainingError);
        updateStep('trainings', 'completed', trainingRecords.length);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);
      }

      // 11. Create Evaluations
      if (options.createEvaluations && createdEmployeeIds.length > 0) {
        updateStep('evaluations', 'running');
        const evaluationRecords = [];
        const currentUser = (await supabase.auth.getUser()).data.user;

        for (const employeeId of createdEmployeeIds.slice(0, 10)) {
          const periodStart = subDays(new Date(), 90);
          const periodEnd = subDays(new Date(), 1);
          
          evaluationRecords.push({
            employee_id: employeeId,
            evaluator_id: employeeId, // Self-evaluation for test
            evaluation_date: format(new Date(), 'yyyy-MM-dd'),
            period_start: format(periodStart, 'yyyy-MM-dd'),
            period_end: format(periodEnd, 'yyyy-MM-dd'),
            overall_rating: Math.floor(Math.random() * 3) + 3,
            performance_rating: Math.floor(Math.random() * 3) + 3,
            teamwork_rating: Math.floor(Math.random() * 3) + 3,
            communication_rating: Math.floor(Math.random() * 3) + 3,
            leadership_rating: Math.floor(Math.random() * 3) + 2,
            strengths: 'კარგი კომუნიკაცია, პასუხისმგებლობა, დროული დავალებების შესრულება',
            areas_for_improvement: 'ანალიტიკური უნარების გაუმჯობესება',
            goals: 'მომდევნო კვარტალში პროდუქტიულობის 10%-ით გაზრდა',
            comments: 'საერთო შეფასება დამაკმაყოფილებელია',
            status: ['draft', 'submitted', 'acknowledged'][Math.floor(Math.random() * 3)],
          });
        }

        const { error: evalError } = await supabase
          .from('employee_evaluations')
          .insert(evaluationRecords);

        if (evalError) console.error('Evaluation error:', evalError);
        updateStep('evaluations', 'completed', evaluationRecords.length);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);
      }

      // 12. Create Bonuses (Compensation)
      if (options.createBonuses && createdEmployeeIds.length > 0) {
        updateStep('bonuses', 'running');
        const bonusRecords = [];
        const bonusTypes = ['performance', 'annual', 'project', 'referral'];
        const bonusReasons = [
          'კვარტალური შედეგებისთვის',
          'წლის საუკეთესო თანამშრომელი',
          'პროექტის წარმატებით დასრულება',
          'რეფერალ პრემია'
        ];

        for (const employeeId of createdEmployeeIds.slice(0, 8)) {
          const bonusTypeIndex = Math.floor(Math.random() * bonusTypes.length);
          bonusRecords.push({
            employee_id: employeeId,
            type: 'bonus',
            bonus_type: bonusTypes[bonusTypeIndex],
            amount: Math.floor(Math.random() * 800) + 200,
            reason: bonusReasons[bonusTypeIndex],
            status: ['pending', 'approved', 'rejected'][Math.floor(Math.random() * 3)],
            payment_date: format(addDays(new Date(), Math.floor(Math.random() * 30)), 'yyyy-MM-dd'),
          });
        }

        const { error: bonusError } = await supabase
          .from('compensation')
          .insert(bonusRecords);

        if (bonusError) console.error('Bonus error:', bonusError);
        updateStep('bonuses', 'completed', bonusRecords.length);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);
      }

      // 13. Create Disciplinary Actions
      if (options.createDisciplinary && createdEmployeeIds.length > 0) {
        updateStep('disciplinary', 'running');
        const disciplinaryRecords = [];
        const actionTypes = ['verbal_warning', 'written_warning', 'suspension', 'termination', 'other'];
        const reasons = [
          'სამუშაო დისციპლინის დარღვევა',
          'დაგვიანება',
          'არასათანადო ქცევა',
          'წესების დარღვევა'
        ];
        const severities = ['low', 'medium', 'high', 'critical'];

        for (const employeeId of createdEmployeeIds.slice(0, 5)) {
          const issuedDate = subDays(new Date(), Math.floor(Math.random() * 60) + 10);
          disciplinaryRecords.push({
            employee_id: employeeId,
            action_type: actionTypes[Math.floor(Math.random() * actionTypes.length)],
            reason: reasons[Math.floor(Math.random() * reasons.length)],
            description: 'დეტალური აღწერა დისციპლინური ზომის შესახებ',
            severity: severities[Math.floor(Math.random() * severities.length)],
            issued_date: format(issuedDate, 'yyyy-MM-dd'),
            status: ['active', 'resolved', 'appealed'][Math.floor(Math.random() * 3)],
            follow_up_date: format(addDays(issuedDate, 30), 'yyyy-MM-dd'),
            follow_up_notes: 'მდგომარეობის შემოწმება ერთ თვეში',
          });
        }

        const { error: discError } = await supabase
          .from('disciplinary_actions')
          .insert(disciplinaryRecords);

        if (discError) console.error('Disciplinary error:', discError);
        updateStep('disciplinary', 'completed', disciplinaryRecords.length);
        completedSteps++;
        setProgress((completedSteps / totalSteps) * 100);
      }

      toast.success(`ტესტ მონაცემები წარმატებით შეიქმნა! შეიქმნა ${createdEmployeeIds.length} თანამშრომელი`);
    } catch (error: any) {
      console.error('Generation error:', error);
      toast.error(`შეცდომა: ${error.message}`);
      steps.forEach(s => {
        if (s.status === 'running') updateStep(s.id, 'error');
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const clearTestData = async () => {
    const confirmed = window.confirm('ნამდვილად გსურთ ტესტ მონაცემების წაშლა? (test.* ელფოსტის მქონე თანამშრომლები)');
    if (!confirmed) return;

    try {
      // First get test employee IDs
      const { data: testEmployees } = await supabase
        .from('employees')
        .select('id')
        .like('email', 'test.%');

      if (testEmployees && testEmployees.length > 0) {
        const ids = testEmployees.map(e => e.id);

        // Delete related records
        await supabase.from('attendance').delete().in('employee_id', ids);
        await supabase.from('leave_requests').delete().in('employee_id', ids);
        await supabase.from('business_trip_requests').delete().in('employee_id', ids);
        await supabase.from('shift_schedules').delete().in('employee_id', ids);
        await supabase.from('work_schedules').delete().in('employee_id', ids);
        await supabase.from('payroll').delete().in('employee_id', ids);
        await supabase.from('pension_payments').delete().in('employee_id', ids);
        await supabase.from('employee_evaluations').delete().in('employee_id', ids);
        await supabase.from('compensation').delete().in('employee_id', ids);
        await supabase.from('disciplinary_actions').delete().in('employee_id', ids);
        await supabase.from('employees').delete().in('id', ids);

        toast.success(`წაიშალა ${testEmployees.length} ტესტ თანამშრომელი და მათთან დაკავშირებული მონაცემები`);
      } else {
        toast.info('ტესტ თანამშრომლები ვერ მოიძებნა');
      }
    } catch (error: any) {
      toast.error(`შეცდომა წაშლისას: ${error.message}`);
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-6 w-6" />
            ტესტ-მონაცემების გენერატორი
          </CardTitle>
          <CardDescription>
            შექმენით სატესტო მონაცემები სისტემის ფუნქციონალის შესამოწმებლად
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              ეს ინსტრუმენტი შექმნის სატესტო თანამშრომლებს (test.* ელფოსტით) და მათთვის დასწრების, 
              შვებულებების და ცვლების მონაცემებს. გამოიყენეთ მხოლოდ ტესტირებისთვის!
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">გენერაციის პარამეტრები</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="createEmployees" 
                    checked={options.createEmployees}
                    onCheckedChange={(checked) => setOptions(prev => ({ ...prev, createEmployees: !!checked }))}
                  />
                  <Label htmlFor="createEmployees" className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    თანამშრომლების შექმნა (HR: 5, ლოგისტიკა: 10)
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="createShiftSchedules" 
                    checked={options.createShiftSchedules}
                    onCheckedChange={(checked) => setOptions(prev => ({ ...prev, createShiftSchedules: !!checked }))}
                  />
                  <Label htmlFor="createShiftSchedules" className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    ცვლების გრაფიკები (მიმდინარე თვე)
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="createAttendance" 
                    checked={options.createAttendance}
                    onCheckedChange={(checked) => setOptions(prev => ({ ...prev, createAttendance: !!checked }))}
                  />
                  <Label htmlFor="createAttendance" className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    დასწრების მონაცემები
                  </Label>
                </div>

                {options.createAttendance && (
                  <div className="ml-6 flex items-center gap-2">
                    <Label htmlFor="attendanceMonths">თვეების რაოდენობა:</Label>
                    <Input 
                      id="attendanceMonths"
                      type="number" 
                      min={1} 
                      max={12}
                      value={options.attendanceMonths}
                      onChange={(e) => setOptions(prev => ({ ...prev, attendanceMonths: parseInt(e.target.value) || 1 }))}
                      className="w-20"
                    />
                  </div>
                )}

                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="createLeaveRequests" 
                    checked={options.createLeaveRequests}
                    onCheckedChange={(checked) => setOptions(prev => ({ ...prev, createLeaveRequests: !!checked }))}
                  />
                  <Label htmlFor="createLeaveRequests" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    შვებულების მოთხოვნები
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="createBusinessTrips" 
                    checked={options.createBusinessTrips}
                    onCheckedChange={(checked) => setOptions(prev => ({ ...prev, createBusinessTrips: !!checked }))}
                  />
                  <Label htmlFor="createBusinessTrips" className="flex items-center gap-2">
                    <Briefcase className="h-4 w-4" />
                    მივლინებები
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="createPayroll" 
                    checked={options.createPayroll}
                    onCheckedChange={(checked) => setOptions(prev => ({ ...prev, createPayroll: !!checked }))}
                  />
                  <Label htmlFor="createPayroll" className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4" />
                    ხელფასები (მიმდინარე თვე)
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="createPension" 
                    checked={options.createPension}
                    onCheckedChange={(checked) => setOptions(prev => ({ ...prev, createPension: !!checked }))}
                  />
                  <Label htmlFor="createPension" className="flex items-center gap-2">
                    <PiggyBank className="h-4 w-4" />
                    საპენსიო გადახდები (მიმდინარე თვე)
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="createTrainings" 
                    checked={options.createTrainings}
                    onCheckedChange={(checked) => setOptions(prev => ({ ...prev, createTrainings: !!checked }))}
                  />
                  <Label htmlFor="createTrainings" className="flex items-center gap-2">
                    <GraduationCap className="h-4 w-4" />
                    ტრენინგები
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="createEvaluations" 
                    checked={options.createEvaluations}
                    onCheckedChange={(checked) => setOptions(prev => ({ ...prev, createEvaluations: !!checked }))}
                  />
                  <Label htmlFor="createEvaluations" className="flex items-center gap-2">
                    <Star className="h-4 w-4" />
                    შეფასებები
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="createBonuses" 
                    checked={options.createBonuses}
                    onCheckedChange={(checked) => setOptions(prev => ({ ...prev, createBonuses: !!checked }))}
                  />
                  <Label htmlFor="createBonuses" className="flex items-center gap-2">
                    <Gift className="h-4 w-4" />
                    ბონუსები
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="createDisciplinary" 
                    checked={options.createDisciplinary}
                    onCheckedChange={(checked) => setOptions(prev => ({ ...prev, createDisciplinary: !!checked }))}
                  />
                  <Label htmlFor="createDisciplinary" className="flex items-center gap-2">
                    <Scale className="h-4 w-4" />
                    დისციპლინური ზომები
                  </Label>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">პროგრესი</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {steps.length > 0 && (
                  <>
                    <Progress value={progress} className="h-2" />
                    <div className="space-y-2">
                      {steps.map(step => (
                        <div key={step.id} className="flex items-center justify-between text-sm">
                          <span className="flex items-center gap-2">
                            {step.status === 'running' && <Loader2 className="h-4 w-4 animate-spin text-blue-500" />}
                            {step.status === 'completed' && <CheckCircle2 className="h-4 w-4 text-green-500" />}
                            {step.status === 'error' && <AlertTriangle className="h-4 w-4 text-red-500" />}
                            {step.status === 'pending' && <div className="h-4 w-4 rounded-full border-2 border-muted" />}
                            {step.name}
                          </span>
                          {step.count !== undefined && (
                            <Badge variant="outline">{step.count}</Badge>
                          )}
                        </div>
                      ))}
                    </div>
                  </>
                )}

                {steps.length === 0 && (
                  <p className="text-muted-foreground text-center py-4">
                    აირჩიეთ პარამეტრები და დაიწყეთ გენერაცია
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="flex gap-4">
            <Button 
              onClick={generateTestData} 
              disabled={isGenerating}
              className="flex-1"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  მიმდინარეობს გენერაცია...
                </>
              ) : (
                <>
                  <PlayCircle className="h-4 w-4 mr-2" />
                  დაიწყე გენერაცია
                </>
              )}
            </Button>

            <Button 
              variant="destructive" 
              onClick={clearTestData}
              disabled={isGenerating}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              ტესტ მონაცემების წაშლა
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">რა შეიქმნება?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <Users className="h-4 w-4" />
                HR დეპარტამენტი (5 თანამშრომელი)
              </h4>
              <ul className="text-sm text-muted-foreground list-disc list-inside">
                <li>სრული სამუშაო გრაფიკი (09:00-18:00)</li>
                <li>ფიქსირებული სამუშაო დღეები</li>
                <li>შაბათ-კვირა დასვენება</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium flex items-center gap-2">
                <Users className="h-4 w-4" />
                ლოგისტიკა (10 თანამშრომელი)
              </h4>
              <ul className="text-sm text-muted-foreground list-disc list-inside">
                <li>5 თანამშრომელი დღის ცვლაში (08:00-20:00)</li>
                <li>5 თანამშრომელი ღამის ცვლაში (20:00-08:00)</li>
                <li>მონაცვლეობითი გრაფიკი</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TestDataGenerator;
