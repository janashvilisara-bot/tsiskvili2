import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Plus, TrendingUp, TrendingDown, DollarSign, Edit, Trash2, Download, Filter, Sparkles, GitCompare, CheckCircle, XCircle, Clock, Receipt, LineChart as LineChartIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PieChart, Pie, Cell, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { exportToExcel } from "@/lib/exportToExcel";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface Department {
  id: string;
  name: string;
}

interface BudgetPlan {
  id: string;
  fiscal_year: number;
  fiscal_quarter: number | null;
  fiscal_month: number | null;
  department_id: string | null;
  category: string;
  planned_amount: number;
  actual_amount: number;
  variance: number | null;
  notes: string | null;
  created_at: string;
  status: string;
  submitted_by: string | null;
  approved_by: string | null;
  approved_at: string | null;
  rejection_reason: string | null;
  departments?: Department;
}

interface BudgetExpense {
  id: string;
  budget_plan_id: string;
  expense_date: string;
  amount: number;
  description: string;
  category: string;
  created_at: string;
}

export default function BudgetPlanning() {
  const [budgets, setBudgets] = useState<BudgetPlan[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [editingBudget, setEditingBudget] = useState<BudgetPlan | null>(null);
  const [userRole, setUserRole] = useState<string[]>([]);
  
  const [filterYear, setFilterYear] = useState<string>("all");
  const [filterQuarter, setFilterQuarter] = useState<string>("all");
  const [filterDepartment, setFilterDepartment] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [showFilters, setShowFilters] = useState(false);
  
  // Expense management dialog
  const [isAddExpenseDialogOpen, setIsAddExpenseDialogOpen] = useState(false);
  const [selectedBudgetForExpense, setSelectedBudgetForExpense] = useState<BudgetPlan | null>(null);
  const [expenses, setExpenses] = useState<BudgetExpense[]>([]);
  const [isViewExpensesDialogOpen, setIsViewExpensesDialogOpen] = useState(false);
  const [expenseFormData, setExpenseFormData] = useState({
    expense_date: new Date().toISOString().split('T')[0],
    amount: 0,
    description: "",
    category: "",
  });
  
  // Actual expenses tracking dialog (deprecated - keeping for compatibility)
  const [isExpenseDialogOpen, setIsExpenseDialogOpen] = useState(false);
  const [trackingBudget, setTrackingBudget] = useState<BudgetPlan | null>(null);
  const [expenseAmount, setExpenseAmount] = useState(0);
  
  // Approval dialog state
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [rejectingBudget, setRejectingBudget] = useState<BudgetPlan | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");
  
  // Forecast dialog state
  const [isForecastDialogOpen, setIsForecastDialogOpen] = useState(false);
  const [forecastLoading, setForecastLoading] = useState(false);
  const [forecastData, setForecastData] = useState<any>(null);
  
  // Comparison state
  const [showComparison, setShowComparison] = useState(false);
  const [comparisonYear, setComparisonYear] = useState<string>("");
  const [comparisonQuarter, setComparisonQuarter] = useState<string>("all");
  
  const [formData, setFormData] = useState({
    fiscal_year: new Date().getFullYear(),
    fiscal_quarter: null as number | null,
    fiscal_month: null as number | null,
    department_id: "",
    category: "",
    planned_amount: 0,
    notes: "",
  });

  useEffect(() => {
    fetchBudgets();
    fetchDepartments();
    fetchUserRole();
  }, []);

  const fetchDepartments = async () => {
    const { data, error } = await supabase
      .from("departments")
      .select("id, name")
      .eq("is_active", true)
      .order("name");

    if (error) {
      toast.error("დეპარტამენტების ჩატვირთვის შეცდომა");
    } else {
      setDepartments(data || []);
    }
  };

  const fetchUserRole = async () => {
    const { data, error } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", (await supabase.auth.getUser()).data.user?.id);
    
    if (!error && data) {
      setUserRole(data.map(r => r.role));
    }
  };

  const fetchBudgets = async () => {
    const { data, error } = await supabase
      .from("budget_plans")
      .select(`
        *,
        departments:department_id (
          id,
          name
        )
      `)
      .order("fiscal_year", { ascending: false })
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("ბიუჯეტის ჩატვირთვის შეცდომა");
    } else {
      setBudgets((data as any) || []);
    }
    setLoading(false);
  };

  // Recalculate the plan's actual total from its expenses; returns false (and shows an error) on failure
  const syncActualAmount = async (budgetPlanId: string): Promise<boolean> => {
    const { data: expensesData, error: sumError } = await supabase
      .from("budget_expenses")
      .select("amount")
      .eq("budget_plan_id", budgetPlanId);
    if (sumError) {
      toast.error("ხარჯი შენახულია, მაგრამ ჯამის გადათვლა ვერ მოხერხდა");
      return false;
    }
    const totalExpenses = expensesData?.reduce((sum, e) => sum + Number(e.amount), 0) || 0;
    const { error: updError } = await supabase
      .from("budget_plans")
      .update({ actual_amount: totalExpenses })
      .eq("id", budgetPlanId);
    if (updError) {
      toast.error("ხარჯი შენახულია, მაგრამ ბიუჯეტის ჯამის განახლება ვერ მოხერხდა");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { data: { user } } = await supabase.auth.getUser();
    
    const payload = {
      ...formData,
      department_id: formData.department_id || null,
      submitted_by: user?.id,
      status: 'pending',
    };

    if (editingBudget) {
      const { error } = await supabase
        .from("budget_plans")
        .update(payload)
        .eq("id", editingBudget.id);

      if (error) {
        toast.error("განახლების შეცდომა");
      } else {
        toast.success("ბიუჯეტი განახლდა");
        fetchBudgets();
        setIsDialogOpen(false);
        resetForm();
      }
    } else {
      const { error } = await supabase
        .from("budget_plans")
        .insert([payload]);

      if (error) {
        toast.error("შექმნის შეცდომა");
      } else {
        toast.success("ბიუჯეტის მოთხოვნა გაიგზავნა დამტკიცებისთვის");
        fetchBudgets();
        setIsDialogOpen(false);
        resetForm();
      }
    }
  };

  const handleApproveBudget = async (id: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    
    const { error } = await supabase
      .from("budget_plans")
      .update({ 
        status: 'approved',
        approved_by: user?.id,
        approved_at: new Date().toISOString()
      })
      .eq("id", id);

    if (error) {
      toast.error("დამტკიცების შეცდომა");
    } else {
      toast.success("ბიუჯეტი დამტკიცდა");
      fetchBudgets();
    }
  };

  const handleRejectBudget = async (id: string, reason: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    
    const { error } = await supabase
      .from("budget_plans")
      .update({ 
        status: 'rejected',
        approved_by: user?.id,
        rejection_reason: reason
      })
      .eq("id", id);

    if (error) {
      toast.error("უარყოფის შეცდომა");
    } else {
      toast.success("ბიუჯეტი უარყოფილია");
      fetchBudgets();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("დარწმუნებული ხართ?")) return;

    const { error } = await supabase
      .from("budget_plans")
      .delete()
      .eq("id", id);

    if (error) {
      toast.error("წაშლის შეცდომა");
    } else {
      toast.success("ბიუჯეტი წაიშალა");
      fetchBudgets();
    }
  };

  const handleEdit = (budget: BudgetPlan) => {
    setEditingBudget(budget);
    setFormData({
      fiscal_year: budget.fiscal_year,
      fiscal_quarter: budget.fiscal_quarter,
      fiscal_month: budget.fiscal_month,
      department_id: budget.department_id || "",
      category: budget.category,
      planned_amount: budget.planned_amount,
      notes: budget.notes || "",
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      fiscal_year: new Date().getFullYear(),
      fiscal_quarter: null,
      fiscal_month: null,
      department_id: "",
      category: "",
      planned_amount: 0,
      notes: "",
    });
    setEditingBudget(null);
  };

  const handleUpdateActualExpense = async () => {
    if (!trackingBudget) return;

    const { error } = await supabase
      .from("budget_plans")
      .update({ actual_amount: expenseAmount })
      .eq("id", trackingBudget.id);

    if (error) {
      toast.error("ფაქტობრივი ხარჯის განახლების შეცდომა");
    } else {
      toast.success("ფაქტობრივი ხარჯი განახლდა");
      fetchBudgets();
      setIsExpenseDialogOpen(false);
      setTrackingBudget(null);
      setExpenseAmount(0);
    }
  };

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBudgetForExpense) return;

    const { data: { user } } = await supabase.auth.getUser();

    const payload = {
      budget_plan_id: selectedBudgetForExpense.id,
      expense_date: expenseFormData.expense_date,
      amount: expenseFormData.amount,
      description: expenseFormData.description,
      category: expenseFormData.category,
      department_id: selectedBudgetForExpense.department_id,
      fiscal_year: selectedBudgetForExpense.fiscal_year,
      fiscal_quarter: selectedBudgetForExpense.fiscal_quarter,
      fiscal_month: selectedBudgetForExpense.fiscal_month,
      status: 'approved',
      created_by: user?.id,
    };

    const { error } = await supabase
      .from("budget_expenses")
      .insert([payload]);

    if (error) {
      console.error(error);
      toast.error("ხარჯის დამატების შეცდომა");
      return;
    }

    // Update actual_amount in budget_plan
    const synced = await syncActualAmount(selectedBudgetForExpense.id);

    if (synced) toast.success("ხარჯი წარმატებით დაემატა");
    fetchBudgets();
    setIsAddExpenseDialogOpen(false);
    setSelectedBudgetForExpense(null);
    setExpenseFormData({
      expense_date: new Date().toISOString().split('T')[0],
      amount: 0,
      description: "",
      category: "",
    });
  };

  const fetchExpenses = async (budgetPlanId: string) => {
    const { data, error } = await supabase
      .from("budget_expenses")
      .select("*")
      .eq("budget_plan_id", budgetPlanId)
      .order("expense_date", { ascending: false });

    if (error) {
      toast.error("ხარჯების ჩატვირთვის შეცდომა");
    } else {
      setExpenses((data as any) || []);
    }
  };

  const handleDeleteExpense = async (expenseId: string, budgetPlanId: string) => {
    if (!confirm("დარწმუნებული ხართ?")) return;

    const { error } = await supabase
      .from("budget_expenses")
      .delete()
      .eq("id", expenseId);

    if (error) {
      toast.error("ხარჯის წაშლის შეცდომა");
      return;
    }

    // Recalculate total
    const synced = await syncActualAmount(budgetPlanId);

    if (synced) toast.success("ხარჯი წაიშალა");
    fetchExpenses(budgetPlanId);
    fetchBudgets();
  };

  // Filtered budgets based on filters
  const filteredBudgets = useMemo(() => {
    return budgets.filter(budget => {
      if (filterYear !== "all" && budget.fiscal_year.toString() !== filterYear) return false;
      if (filterQuarter !== "all" && budget.fiscal_quarter?.toString() !== filterQuarter) return false;
      if (filterDepartment !== "all" && budget.department_id !== filterDepartment) return false;
      if (filterStatus !== "all" && budget.status !== filterStatus) return false;
      return true;
    });
  }, [budgets, filterYear, filterQuarter, filterDepartment, filterStatus]);

  const pendingBudgets = useMemo(() => budgets.filter(b => b.status === 'pending'), [budgets]);
  const isAdmin = userRole.includes('admin') || userRole.includes('hr_manager');

  const totalPlanned = filteredBudgets.reduce((sum, b) => sum + b.planned_amount, 0);
  const totalActual = filteredBudgets.reduce((sum, b) => sum + b.actual_amount, 0);
  const totalVariance = totalActual - totalPlanned;
  const budgetUtilization = totalPlanned > 0 ? (totalActual / totalPlanned) * 100 : 0;

  // Available years from budgets
  const availableYears = useMemo(() => {
    const years = [...new Set(budgets.map(b => b.fiscal_year))].sort((a, b) => b - a);
    return years;
  }, [budgets]);

  // Comparison data
  const comparisonData = useMemo(() => {
    if (!comparisonYear || comparisonYear === "all") return null;
    
    const currentYearBudgets = filteredBudgets.filter(b => 
      b.fiscal_year === parseInt(filterYear) &&
      (filterQuarter === "all" || b.fiscal_quarter?.toString() === filterQuarter)
    );
    
    const previousYearBudgets = budgets.filter(b => 
      b.fiscal_year === parseInt(comparisonYear) &&
      (comparisonQuarter === "all" || b.fiscal_quarter?.toString() === comparisonQuarter)
    );
    
    const currentTotal = currentYearBudgets.reduce((sum, b) => sum + b.actual_amount, 0);
    const previousTotal = previousYearBudgets.reduce((sum, b) => sum + b.actual_amount, 0);
    const change = currentTotal - previousTotal;
    const changePercent = previousTotal > 0 ? (change / previousTotal) * 100 : 0;
    
    return {
      current: { year: filterYear, quarter: filterQuarter, total: currentTotal },
      previous: { year: comparisonYear, quarter: comparisonQuarter, total: previousTotal },
      change,
      changePercent,
    };
  }, [filteredBudgets, budgets, filterYear, filterQuarter, comparisonYear, comparisonQuarter]);

  // Forecast function
  const handleForecast = async () => {
    setForecastLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('budget-forecast', {
        body: {
          year: parseInt(filterYear === "all" ? new Date().getFullYear().toString() : filterYear) + 1,
          quarter: filterQuarter !== "all" ? parseInt(filterQuarter) : null,
          departmentId: filterDepartment !== "all" ? filterDepartment : null,
          category: null,
        }
      });

      if (error) throw error;

      if (data.error) {
        toast.error(data.error);
        return;
      }

      setForecastData(data);
      toast.success("პროგნოზი წარმატებით შეიქმნა");
    } catch (error: any) {
      console.error('Forecast error:', error);
      toast.error(error.message || "პროგნოზის შექმნა ვერ მოხერხდა");
    } finally {
      setForecastLoading(false);
    }
  };

  // Export to Excel
  const handleExportToExcel = () => {
    const exportData = filteredBudgets.map(budget => ({
      "ფისკალური წელი": budget.fiscal_year,
      "კვარტალი": budget.fiscal_quarter ? `Q${budget.fiscal_quarter}` : "-",
      "თვე": budget.fiscal_month || "-",
      "დეპარტამენტი": budget.departments?.name || "ყველა",
      "კატეგორია": budget.category,
      "დაგეგმილი თანხა": budget.planned_amount,
      "ფაქტობრივი თანხა": budget.actual_amount,
      "გადახარჯვა": budget.variance || 0,
      "შენიშვნები": budget.notes || "-",
    }));

    exportToExcel(exportData, "budget-report");
    toast.success("ბიუჯეტი წარმატებით ექსპორტირდა Excel-ში");
  };

  // Department budget data for pie chart
  const departmentData = departments.map((dept) => {
    const deptBudgets = filteredBudgets.filter((b) => b.department_id === dept.id);
    const planned = deptBudgets.reduce((sum, b) => sum + b.planned_amount, 0);
    const actual = deptBudgets.reduce((sum, b) => sum + b.actual_amount, 0);
    return {
      name: dept.name,
      planned,
      actual,
    };
  }).filter(d => d.planned > 0 || d.actual > 0);

  // Category spending data for bar chart
  const categoryData = filteredBudgets.reduce((acc, budget) => {
    const existing = acc.find(item => item.category === budget.category);
    if (existing) {
      existing.planned += budget.planned_amount;
      existing.actual += budget.actual_amount;
    } else {
      acc.push({
        category: budget.category,
        planned: budget.planned_amount,
        actual: budget.actual_amount,
      });
    }
    return acc;
  }, [] as { category: string; planned: number; actual: number }[]);

  // Monthly trend data for line chart
  const monthlyData = filteredBudgets.reduce((acc, budget) => {
    if (budget.fiscal_month) {
      const key = `${budget.fiscal_year}-${budget.fiscal_month}`;
      const existing = acc.find(item => item.period === key);
      if (existing) {
        existing.planned += budget.planned_amount;
        existing.actual += budget.actual_amount;
      } else {
        acc.push({
          period: key,
          month: budget.fiscal_month,
          year: budget.fiscal_year,
          planned: budget.planned_amount,
          actual: budget.actual_amount,
        });
      }
    }
    return acc;
  }, [] as { period: string; month: number; year: number; planned: number; actual: number }[])
  .sort((a, b) => a.year === b.year ? a.month - b.month : a.year - b.year);

  const COLORS = ['hsl(var(--primary))', 'hsl(var(--secondary))', 'hsl(var(--accent))', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6'];
  const CHART_COLORS = {
    planned: 'hsl(var(--primary))',
    actual: 'hsl(var(--accent))',
  };

  return (
    <>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">ბიუჯეტის დაგეგმვა და კონტროლი</h1>
            <p className="text-muted-foreground mt-2">ფინანსური რესურსების მართვა და ანალიზი</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" onClick={() => setShowFilters(!showFilters)}>
              <Filter className="mr-2 h-4 w-4" />
              ფილტრები
            </Button>
            <Button variant="outline" onClick={() => setShowComparison(!showComparison)}>
              <GitCompare className="mr-2 h-4 w-4" />
              შედარება
            </Button>
            <Button variant="outline" onClick={handleExportToExcel} disabled={filteredBudgets.length === 0}>
              <Download className="mr-2 h-4 w-4" />
              Excel ექსპორტი
            </Button>
            <Dialog open={isForecastDialogOpen} onOpenChange={setIsForecastDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Sparkles className="mr-2 h-4 w-4" />
                  AI პროგნოზი
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>ბიუჯეტის პროგნოზირება AI-ით</DialogTitle>
                </DialogHeader>
                
                {!forecastData ? (
                  <div className="space-y-4">
                    <p className="text-muted-foreground">
                      AI გააანალიზებს თქვენს ისტორიულ ბიუჯეტის მონაცემებს და შექმნის პროგნოზს მომავალი პერიოდებისთვის.
                    </p>
                    <Button onClick={handleForecast} disabled={forecastLoading} className="w-full">
                      {forecastLoading ? "იტვირთება..." : "პროგნოზის შექმნა"}
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid gap-4">
                      <Card className="p-4 bg-primary/5">
                        <h4 className="font-semibold mb-2">პროგნოზირებული თანხა</h4>
                        <p className="text-2xl font-bold">
                          {new Intl.NumberFormat('ka-GE', {
                            style: 'currency',
                            currency: 'GEL'
                          }).format(forecastData.forecastedAmount)}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">
                          საშუალო: {new Intl.NumberFormat('ka-GE', {
                            style: 'currency',
                            currency: 'GEL'
                          }).format(forecastData.historicalAverage)}
                        </p>
                      </Card>
                      
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-semibold mb-1">დასაბუთება</h4>
                          <p className="text-sm text-muted-foreground">{forecastData.justification}</p>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold mb-1">რისკები</h4>
                          <p className="text-sm text-muted-foreground">{forecastData.risks}</p>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold mb-1">რეკომენდაციები</h4>
                          <p className="text-sm text-muted-foreground">{forecastData.recommendations}</p>
                        </div>
                      </div>
                      
                      <div className="text-xs text-muted-foreground">
                        ანალიზი ემყარება {forecastData.dataPoints} ისტორიულ ჩანაწერს
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      <Button variant="outline" onClick={() => setForecastData(null)} className="flex-1">
                        ახალი პროგნოზი
                      </Button>
                      <Button onClick={() => setIsForecastDialogOpen(false)} className="flex-1">
                        დახურვა
                      </Button>
                    </div>
                  </div>
                )}
              </DialogContent>
            </Dialog>
            
            {/* Forecast Button */}
            <Button 
              variant="outline" 
              onClick={() => setIsForecastDialogOpen(true)}
              className="gap-2"
            >
              <LineChartIcon className="h-4 w-4" />
              პროგნოზირება
            </Button>

            <Dialog open={isDialogOpen} onOpenChange={(open) => {
              setIsDialogOpen(open);
              if (!open) resetForm();
            }}>
              <DialogTrigger asChild>
                <Button onClick={resetForm}>
                  <Plus className="mr-2 h-4 w-4" />
                  ახალი ბიუჯეტი
                </Button>
              </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>{editingBudget ? "ბიუჯეტის რედაქტირება" : "ახალი ბიუჯეტის შექმნა"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fiscal_year">ფისკალური წელი *</Label>
                    <Input
                      id="fiscal_year"
                      type="number"
                      value={formData.fiscal_year}
                      onChange={(e) => setFormData({ ...formData, fiscal_year: parseInt(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fiscal_quarter">კვარტალი</Label>
                    <Select
                      value={formData.fiscal_quarter?.toString() || "none"}
                      onValueChange={(value) => setFormData({ ...formData, fiscal_quarter: value === "none" ? null : parseInt(value) })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="არჩევითი" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">არჩევითი</SelectItem>
                        <SelectItem value="1">Q1</SelectItem>
                        <SelectItem value="2">Q2</SelectItem>
                        <SelectItem value="3">Q3</SelectItem>
                        <SelectItem value="4">Q4</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fiscal_month">თვე</Label>
                    <Input
                      id="fiscal_month"
                      type="number"
                      min="1"
                      max="12"
                      placeholder="1-12"
                      value={formData.fiscal_month || ""}
                      onChange={(e) => setFormData({ ...formData, fiscal_month: e.target.value ? parseInt(e.target.value) : null })}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="department_id">დეპარტამენტი</Label>
                    <Select
                      value={formData.department_id || "all"}
                      onValueChange={(value) => setFormData({ ...formData, department_id: value === "all" ? "" : value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="ყველა დეპარტამენტი" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                        {departments.map((dept) => (
                          <SelectItem key={dept.id} value={dept.id}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">კატეგორია *</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="აირჩიეთ კატეგორია" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ხელფასები">ხელფასები</SelectItem>
                        <SelectItem value="ბონუსები">ბონუსები</SelectItem>
                        <SelectItem value="სარგებლები">სარგებლები</SelectItem>
                        <SelectItem value="ტრენინგები">ტრენინგები</SelectItem>
                        <SelectItem value="დაქირავება">დაქირავება</SelectItem>
                        <SelectItem value="ოპერაციული">ოპერაციული ხარჯები</SelectItem>
                        <SelectItem value="სხვა">სხვა</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>


                <div className="space-y-2">
                  <Label htmlFor="planned_amount">დაგეგმილი თანხა *</Label>
                  <Input
                    id="planned_amount"
                    type="number"
                    step="0.01"
                    value={formData.planned_amount}
                    onChange={(e) => setFormData({ ...formData, planned_amount: parseFloat(e.target.value) })}
                    required
                  />
                  <p className="text-xs text-muted-foreground">
                    ფაქტობრივი ხარჯები ჩაიწერება ცალკე, შექმნის შემდეგ
                  </p>
                </div>


                <div className="space-y-2">
                  <Label htmlFor="notes">შენიშვნები</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    rows={3}
                  />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    გაუქმება
                  </Button>
                  <Button type="submit">
                    {editingBudget ? "განახლება" : "შექმნა"}
                  </Button>
                </div>
              </form>
            </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Pending Approval Dashboard - Only for Admins/HR */}
        {isAdmin && pendingBudgets.length > 0 && (
          <Card className="p-6 bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-amber-100 dark:bg-amber-900/30 rounded-lg">
                  <Clock className="h-6 w-6 text-amber-600 dark:text-amber-400" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">დამტკიცების მოლოდინში</h2>
                  <p className="text-sm text-muted-foreground">{pendingBudgets.length} მოთხოვნა საჭიროებს თქვენს ყურადღებას</p>
                </div>
              </div>
              <Badge variant="outline" className="text-lg px-4 py-2">
                {pendingBudgets.length}
              </Badge>
            </div>

            <div className="space-y-3">
              {pendingBudgets.slice(0, 5).map((budget) => (
                <Card key={budget.id} className="p-4 bg-background">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold">{budget.category}</h4>
                        <Badge variant="outline" className="text-xs">
                          {budget.fiscal_year}
                          {budget.fiscal_quarter && ` Q${budget.fiscal_quarter}`}
                        </Badge>
                        {budget.departments && (
                          <Badge variant="secondary" className="text-xs">{budget.departments.name}</Badge>
                        )}
                      </div>
                      <div className="flex gap-6 text-sm">
                        <div>
                          <span className="text-muted-foreground">დაგეგმილი: </span>
                          <span className="font-medium">
                            {new Intl.NumberFormat('ka-GE', {
                              style: 'currency',
                              currency: 'GEL'
                            }).format(budget.planned_amount)}
                          </span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">ფაქტობრივი: </span>
                          <span className="font-medium">
                            {new Intl.NumberFormat('ka-GE', {
                              style: 'currency',
                              currency: 'GEL'
                            }).format(budget.actual_amount)}
                          </span>
                        </div>
                      </div>
                      {budget.notes && (
                        <p className="text-xs text-muted-foreground mt-2 line-clamp-1">{budget.notes}</p>
                      )}
                    </div>
                    <div className="flex gap-2 ml-4">
                      <Button
                        size="sm"
                        onClick={() => handleApproveBudget(budget.id)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        დამტკიცება
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setRejectingBudget(budget);
                          setIsRejectDialogOpen(true);
                        }}
                      >
                        <XCircle className="h-4 w-4 mr-1" />
                        უარყოფა
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
              
              {pendingBudgets.length > 5 && (
                <div className="text-center pt-2">
                  <Button 
                    variant="link" 
                    onClick={() => {
                      setFilterStatus("pending");
                      setShowFilters(true);
                    }}
                  >
                    ყველას ნახვა ({pendingBudgets.length})
                  </Button>
                </div>
              )}
            </div>
          </Card>
        )}

        {/* Filters Section */}
        {showFilters && (
          <Card className="p-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>ფისკალური წელი</Label>
                <Select value={filterYear} onValueChange={setFilterYear}>
                  <SelectTrigger>
                    <SelectValue placeholder="ყველა წელი" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა წელი</SelectItem>
                    {availableYears.map(year => (
                      <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>კვარტალი</Label>
                <Select value={filterQuarter} onValueChange={setFilterQuarter}>
                  <SelectTrigger>
                    <SelectValue placeholder="ყველა კვარტალი" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა კვარტალი</SelectItem>
                    <SelectItem value="1">Q1</SelectItem>
                    <SelectItem value="2">Q2</SelectItem>
                    <SelectItem value="3">Q3</SelectItem>
                    <SelectItem value="4">Q4</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>სტატუსი</Label>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="ყველა სტატუსი" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა სტატუსი</SelectItem>
                    <SelectItem value="pending">მოლოდინში</SelectItem>
                    <SelectItem value="approved">დამტკიცებული</SelectItem>
                    <SelectItem value="rejected">უარყოფილი</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>დეპარტამენტი</Label>
                <Select value={filterDepartment} onValueChange={setFilterDepartment}>
                  <SelectTrigger>
                    <SelectValue placeholder="ყველა დეპარტამენტი" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                    {departments.map(dept => (
                      <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {(filterYear !== "all" || filterQuarter !== "all" || filterDepartment !== "all" || filterStatus !== "all") && (
              <div className="mt-4">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    setFilterYear("all");
                    setFilterQuarter("all");
                    setFilterDepartment("all");
                    setFilterStatus("all");
                  }}
                >
                  ფილტრების გასუფთავება
                </Button>
              </div>
            )}
          </Card>
        )}

        {/* Forecast Section */}
        {isForecastDialogOpen && (
          <Card className="p-6 border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-background">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <LineChartIcon className="h-5 w-5 text-primary" />
                  ბიუჯეტის პროგნოზი (AI ანალიზი)
                </h3>
                <Button variant="ghost" size="sm" onClick={() => setIsForecastDialogOpen(false)}>
                  ✕
                </Button>
              </div>

              {!forecastData ? (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    შექმენით პროგნოზი მიმდინარე გადახარჯვის ტენდენციის საფუძველზე. 
                    AI გააანალიზებს ისტორიულ მონაცემებს და შესთავაზებთ რეალისტურ პროგნოზს მომავალი პერიოდებისთვის.
                  </p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 bg-muted/50 rounded-lg">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">პროგნოზის პერიოდი</p>
                      <p className="font-medium">
                        {filterYear !== "all" ? parseInt(filterYear) + 1 : new Date().getFullYear() + 1} წელი
                        {filterQuarter !== "all" ? `, Q${filterQuarter}` : ''}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">დეპარტამენტი</p>
                      <p className="font-medium">
                        {filterDepartment !== "all" 
                          ? departments.find(d => d.id === filterDepartment)?.name 
                          : 'ყველა'}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">მონაცემთა წერტილები</p>
                      <p className="font-medium">{filteredBudgets.length} ჩანაწერი</p>
                    </div>
                  </div>

                  <Button 
                    onClick={handleForecast}
                    disabled={forecastLoading || filteredBudgets.length === 0}
                    className="w-full"
                  >
                    {forecastLoading ? (
                      <>
                        <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                        პროგნოზის შექმნა...
                      </>
                    ) : (
                      <>
                        <Sparkles className="mr-2 h-4 w-4" />
                        პროგნოზის გენერირება
                      </>
                    )}
                  </Button>

                  {filteredBudgets.length === 0 && (
                    <Alert>
                      <AlertDescription>
                        არ არის საკმარისი ისტორიული მონაცემები პროგნოზირებისთვის. 
                        გთხოვთ შეარჩიოთ პერიოდი, რომელსაც აქვს ხარჯვის ისტორია.
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <Card className="p-4 bg-card">
                      <p className="text-sm text-muted-foreground mb-2">პროგნოზირებული ბიუჯეტი</p>
                      <p className="text-3xl font-bold text-primary">
                        {new Intl.NumberFormat('ka-GE', {
                          style: 'currency',
                          currency: 'GEL'
                        }).format(forecastData.forecastedAmount)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-2">
                        საშუალო ისტორიული: {new Intl.NumberFormat('ka-GE', {
                          style: 'currency',
                          currency: 'GEL'
                        }).format(forecastData.historicalAverage)}
                      </p>
                      <div className="mt-2">
                        <Badge variant={forecastData.forecastedAmount > forecastData.historicalAverage ? "destructive" : "default"}>
                          {forecastData.forecastedAmount > forecastData.historicalAverage ? (
                            <>↑ +{((forecastData.forecastedAmount / forecastData.historicalAverage - 1) * 100).toFixed(1)}%</>
                          ) : (
                            <>↓ {((forecastData.forecastedAmount / forecastData.historicalAverage - 1) * 100).toFixed(1)}%</>
                          )}
                        </Badge>
                      </div>
                    </Card>

                    <Card className="p-4 bg-card">
                      <p className="text-sm text-muted-foreground mb-2">მონაცემთა საფუძველი</p>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">ანალიზირებული პერიოდები:</span>
                          <span className="font-medium">{forecastData.dataPoints}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">პროგნოზის წელი:</span>
                          <span className="font-medium">
                            {filterYear !== "all" ? parseInt(filterYear) + 1 : new Date().getFullYear() + 1}
                          </span>
                        </div>
                      </div>
                    </Card>
                  </div>

                  <div className="space-y-3">
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <h4 className="font-semibold mb-2 text-sm flex items-center gap-2">
                        📊 დასაბუთება
                      </h4>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                        {forecastData.justification}
                      </p>
                    </div>

                    <div className="p-4 bg-destructive/5 border border-destructive/20 rounded-lg">
                      <h4 className="font-semibold mb-2 text-sm flex items-center gap-2 text-destructive">
                        ⚠️ რისკები
                      </h4>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                        {forecastData.risks}
                      </p>
                    </div>

                    <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                      <h4 className="font-semibold mb-2 text-sm flex items-center gap-2 text-primary">
                        💡 რეკომენდაციები
                      </h4>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                        {forecastData.recommendations}
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-4 border-t">
                    <Button 
                      onClick={() => setForecastData(null)}
                      variant="outline"
                      className="flex-1"
                    >
                      ახალი პროგნოზი
                    </Button>
                    <Button 
                      onClick={() => {
                        setIsForecastDialogOpen(false);
                        setForecastData(null);
                      }}
                      variant="secondary"
                      className="flex-1"
                    >
                      დახურვა
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </Card>
        )}

        {/* Enhanced Year Comparison Section */}
        {showComparison && (
          <Card className="p-6 border-2 border-primary/20">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold flex items-center gap-2">
                  <GitCompare className="h-5 w-5 text-primary" />
                  წლების შედარება და ანალიზი
                </h3>
                <Button variant="ghost" size="sm" onClick={() => setShowComparison(false)}>
                  ✕
                </Button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>ძირითადი წელი</Label>
                  <Select value={filterYear} onValueChange={setFilterYear}>
                    <SelectTrigger>
                      <SelectValue placeholder="აირჩიეთ წელი" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableYears.map(year => (
                        <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>შედარების წელი</Label>
                  <Select value={comparisonYear} onValueChange={setComparisonYear}>
                    <SelectTrigger>
                      <SelectValue placeholder="აირჩიეთ წელი" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableYears.filter(y => y.toString() !== filterYear).map(year => (
                        <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>ძირითადი კვარტალი</Label>
                  <Select value={filterQuarter} onValueChange={setFilterQuarter}>
                    <SelectTrigger>
                      <SelectValue placeholder="ყველა კვარტალი" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა კვარტალი</SelectItem>
                      <SelectItem value="1">Q1</SelectItem>
                      <SelectItem value="2">Q2</SelectItem>
                      <SelectItem value="3">Q3</SelectItem>
                      <SelectItem value="4">Q4</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>შედარების კვარტალი</Label>
                  <Select value={comparisonQuarter} onValueChange={setComparisonQuarter}>
                    <SelectTrigger>
                      <SelectValue placeholder="ყველა კვარტალი" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა კვარტალი</SelectItem>
                      <SelectItem value="1">Q1</SelectItem>
                      <SelectItem value="2">Q2</SelectItem>
                      <SelectItem value="3">Q3</SelectItem>
                      <SelectItem value="4">Q4</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {comparisonData && comparisonYear && comparisonYear !== "all" && (
                <>
                  {/* Summary Cards */}
                  <div className="grid gap-4 md:grid-cols-3">
                    <Card className="p-4 bg-primary/5">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">
                          {filterYear} წელი {filterQuarter !== "all" && `Q${filterQuarter}`}
                        </p>
                        <p className="text-2xl font-bold text-primary">
                          {new Intl.NumberFormat('ka-GE', {
                            style: 'currency',
                            currency: 'GEL'
                          }).format(comparisonData.current.total)}
                        </p>
                      </div>
                    </Card>

                    <Card className="p-4 bg-secondary/5">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">
                          {comparisonYear} წელი {comparisonQuarter !== "all" && `Q${comparisonQuarter}`}
                        </p>
                        <p className="text-2xl font-bold text-secondary">
                          {new Intl.NumberFormat('ka-GE', {
                            style: 'currency',
                            currency: 'GEL'
                          }).format(comparisonData.previous.total)}
                        </p>
                      </div>
                    </Card>

                    <Card className={`p-4 ${comparisonData.change > 0 ? 'bg-red-50 dark:bg-red-950/20' : 'bg-green-50 dark:bg-green-950/20'}`}>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">ცვლილება</p>
                        <div className="flex items-baseline gap-2">
                          <p className={`text-2xl font-bold ${comparisonData.change > 0 ? 'text-red-500' : 'text-green-500'}`}>
                            {new Intl.NumberFormat('ka-GE', {
                              style: 'currency',
                              currency: 'GEL',
                              signDisplay: 'always'
                            }).format(comparisonData.change)}
                          </p>
                          <Badge variant={comparisonData.change > 0 ? "destructive" : "default"}>
                            {comparisonData.changePercent >= 0 ? '↑' : '↓'} {Math.abs(comparisonData.changePercent).toFixed(1)}%
                          </Badge>
                        </div>
                      </div>
                    </Card>
                  </div>

                  {/* Category Comparison Chart */}
                  <Card className="p-6">
                    <h4 className="text-lg font-semibold mb-4">კატეგორიების მიხედვით შედარება</h4>
                    <ResponsiveContainer width="100%" height={350}>
                      <BarChart
                        data={(() => {
                          const currentYearBudgets = budgets.filter(b => 
                            b.fiscal_year === parseInt(filterYear) &&
                            (filterQuarter === "all" || b.fiscal_quarter?.toString() === filterQuarter)
                          );
                          const previousYearBudgets = budgets.filter(b => 
                            b.fiscal_year === parseInt(comparisonYear) &&
                            (comparisonQuarter === "all" || b.fiscal_quarter?.toString() === comparisonQuarter)
                          );

                          const categories = [...new Set([
                            ...currentYearBudgets.map(b => b.category),
                            ...previousYearBudgets.map(b => b.category)
                          ])];

                          return categories.map(category => {
                            const currentTotal = currentYearBudgets
                              .filter(b => b.category === category)
                              .reduce((sum, b) => sum + b.actual_amount, 0);
                            const previousTotal = previousYearBudgets
                              .filter(b => b.category === category)
                              .reduce((sum, b) => sum + b.actual_amount, 0);
                            
                            return {
                              category,
                              [filterYear]: currentTotal,
                              [comparisonYear]: previousTotal,
                            };
                          });
                        })()}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="category" stroke="hsl(var(--muted-foreground))" />
                        <YAxis stroke="hsl(var(--muted-foreground))" />
                        <Tooltip 
                          formatter={(value: number) => new Intl.NumberFormat('ka-GE', { 
                            style: 'currency', 
                            currency: 'GEL' 
                          }).format(value)}
                          contentStyle={{ 
                            backgroundColor: 'hsl(var(--card))', 
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '6px'
                          }}
                        />
                        <Legend />
                        <Bar dataKey={filterYear} fill="hsl(var(--primary))" name={`${filterYear} წელი`} />
                        <Bar dataKey={comparisonYear} fill="hsl(var(--secondary))" name={`${comparisonYear} წელი`} />
                      </BarChart>
                    </ResponsiveContainer>
                  </Card>

                  {/* Trend Analysis */}
                  <Card className="p-6">
                    <h4 className="text-lg font-semibold mb-4">ტენდენციების ანალიზი</h4>
                    <div className="space-y-4">
                      {(() => {
                        const currentYearBudgets = budgets.filter(b => 
                          b.fiscal_year === parseInt(filterYear) &&
                          (filterQuarter === "all" || b.fiscal_quarter?.toString() === filterQuarter)
                        );
                        const previousYearBudgets = budgets.filter(b => 
                          b.fiscal_year === parseInt(comparisonYear) &&
                          (comparisonQuarter === "all" || b.fiscal_quarter?.toString() === comparisonQuarter)
                        );

                        const categories = [...new Set([
                          ...currentYearBudgets.map(b => b.category),
                          ...previousYearBudgets.map(b => b.category)
                        ])];

                        return categories.map(category => {
                          const currentTotal = currentYearBudgets
                            .filter(b => b.category === category)
                            .reduce((sum, b) => sum + b.actual_amount, 0);
                          const previousTotal = previousYearBudgets
                            .filter(b => b.category === category)
                            .reduce((sum, b) => sum + b.actual_amount, 0);
                          
                          const change = currentTotal - previousTotal;
                          const changePercent = previousTotal > 0 ? (change / previousTotal) * 100 : 0;

                          return (
                            <div key={category} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                              <div className="flex-1">
                                <p className="font-medium">{category}</p>
                                <div className="flex gap-4 mt-1 text-sm text-muted-foreground">
                                  <span>
                                    {filterYear}: {new Intl.NumberFormat('ka-GE', {
                                      style: 'currency',
                                      currency: 'GEL'
                                    }).format(currentTotal)}
                                  </span>
                                  <span>
                                    {comparisonYear}: {new Intl.NumberFormat('ka-GE', {
                                      style: 'currency',
                                      currency: 'GEL'
                                    }).format(previousTotal)}
                                  </span>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className={`font-semibold ${change > 0 ? 'text-red-500' : change < 0 ? 'text-green-500' : 'text-muted-foreground'}`}>
                                  {change > 0 ? '↑' : change < 0 ? '↓' : '='} {Math.abs(changePercent).toFixed(1)}%
                                </div>
                                <div className={`text-xs ${change > 0 ? 'text-red-500' : change < 0 ? 'text-green-500' : 'text-muted-foreground'}`}>
                                  {new Intl.NumberFormat('ka-GE', {
                                    style: 'currency',
                                    currency: 'GEL',
                                    signDisplay: 'always'
                                  }).format(change)}
                                </div>
                              </div>
                            </div>
                          );
                        });
                      })()}
                    </div>
                  </Card>

                  {/* Key Insights */}
                  <Alert>
                    <AlertDescription>
                      <div className="space-y-2">
                        <p className="font-semibold">ძირითადი დასკვნები:</p>
                        <ul className="space-y-1 text-sm list-disc list-inside">
                          <li>
                            საერთო ხარჯები {comparisonData.changePercent > 0 ? 'გაიზარდა' : 'შემცირდა'} {Math.abs(comparisonData.changePercent).toFixed(1)}%-ით
                          </li>
                          <li>
                            აბსოლუტური ცვლილება: {new Intl.NumberFormat('ka-GE', {
                              style: 'currency',
                              currency: 'GEL',
                              signDisplay: 'always'
                            }).format(comparisonData.change)}
                          </li>
                          {comparisonData.changePercent > 10 && (
                            <li className="text-red-500">
                              ⚠️ გაფრთხილება: ხარჯები მნიშვნელოვნად გაიზარდა
                            </li>
                          )}
                          {comparisonData.changePercent < -10 && (
                            <li className="text-green-500">
                              ✓ დადებითი ტენდენცია: ხარჯები მნიშვნელოვნად შემცირდა
                            </li>
                          )}
                        </ul>
                      </div>
                    </AlertDescription>
                  </Alert>
                </>
              )}

              {(!comparisonYear || comparisonYear === "all") && (
                <Alert>
                  <AlertDescription>
                    აირჩიეთ შესადარებელი წლები და კვარტლები ანალიზის სანახავად.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </Card>
        )}

        {/* Summary Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">დაგეგმილი ბიუჯეტი</p>
                <p className="text-2xl font-bold">
                  {new Intl.NumberFormat('ka-GE', {
                    style: 'currency',
                    currency: 'GEL'
                  }).format(totalPlanned)}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-muted-foreground" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">ფაქტობრივი ხარჯი</p>
                <p className="text-2xl font-bold">
                  {new Intl.NumberFormat('ka-GE', {
                    style: 'currency',
                    currency: 'GEL'
                  }).format(totalActual)}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-muted-foreground" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">გადახარჯვა</p>
                <p className={`text-2xl font-bold ${totalVariance < 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {new Intl.NumberFormat('ka-GE', {
                    style: 'currency',
                    currency: 'GEL',
                    signDisplay: 'always'
                  }).format(totalVariance)}
                </p>
              </div>
              {totalVariance > 0 ? (
                <TrendingUp className="h-8 w-8 text-red-500" />
              ) : (
                <TrendingDown className="h-8 w-8 text-green-500" />
              )}
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">გამოყენება</p>
                <p className="text-2xl font-bold">{budgetUtilization.toFixed(1)}%</p>
                <Progress value={budgetUtilization} className="mt-2" />
              </div>
            </div>
          </Card>
        </div>

        {/* Charts Section */}
        {filteredBudgets.length > 0 && (
          <div className="grid gap-6 md:grid-cols-2">
            {/* Department Distribution - Pie Chart */}
            {departmentData.length > 0 && (
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">დეპარტამენტების ბიუჯეტის განაწილება</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={departmentData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="hsl(var(--primary))"
                      dataKey="planned"
                    >
                      {departmentData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number) => new Intl.NumberFormat('ka-GE', { style: 'currency', currency: 'GEL' }).format(value)}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </Card>
            )}

            {/* Category Comparison - Bar Chart */}
            {categoryData.length > 0 && (
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">კატეგორიების მიხედვით შედარება</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={categoryData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="category" stroke="hsl(var(--muted-foreground))" />
                    <YAxis stroke="hsl(var(--muted-foreground))" />
                    <Tooltip 
                      formatter={(value: number) => new Intl.NumberFormat('ka-GE', { style: 'currency', currency: 'GEL' }).format(value)}
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px'
                      }}
                    />
                    <Legend />
                    <Bar dataKey="planned" fill={CHART_COLORS.planned} name="დაგეგმილი" />
                    <Bar dataKey="actual" fill={CHART_COLORS.actual} name="ფაქტობრივი" />
                  </BarChart>
                </ResponsiveContainer>
              </Card>
            )}

            {/* Monthly Trend - Line Chart */}
            {monthlyData.length > 0 && (
              <Card className="p-6 md:col-span-2">
                <h3 className="text-lg font-semibold mb-4">ხარჯვის ტენდენციები (თვეების მიხედვით)</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="period" 
                      stroke="hsl(var(--muted-foreground))"
                      tickFormatter={(value) => {
                        const [year, month] = value.split('-');
                        return `${month}/${year.slice(2)}`;
                      }}
                    />
                    <YAxis stroke="hsl(var(--muted-foreground))" />
                    <Tooltip 
                      formatter={(value: number) => new Intl.NumberFormat('ka-GE', { style: 'currency', currency: 'GEL' }).format(value)}
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '6px'
                      }}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="planned" 
                      stroke={CHART_COLORS.planned} 
                      strokeWidth={2}
                      name="დაგეგმილი"
                      dot={{ fill: CHART_COLORS.planned }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="actual" 
                      stroke={CHART_COLORS.actual} 
                      strokeWidth={2}
                      name="ფაქტობრივი"
                      dot={{ fill: CHART_COLORS.actual }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </Card>
            )}
          </div>
        )}

        {/* Budget List */}
        <div className="space-y-4">
          {loading ? (
            <Card className="p-6 text-center">
              <p className="text-muted-foreground">იტვირთება...</p>
            </Card>
          ) : filteredBudgets.length === 0 ? (
            <Card className="p-8 text-center">
              <DollarSign className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">
                {budgets.length === 0 ? "ბიუჯეტები არ მოიძებნა" : "აღნიშნული ფილტრებით ბიუჯეტები არ მოიძებნა"}
              </p>
            </Card>
          ) : (
            filteredBudgets.map((budget) => {
              const variance = budget.actual_amount - budget.planned_amount;
              const utilizationPercent = (budget.actual_amount / budget.planned_amount) * 100;
              
              return (
                <Card key={budget.id} className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-semibold">{budget.category}</h3>
                        <Badge variant="outline">
                          {budget.fiscal_year}
                          {budget.fiscal_quarter && ` Q${budget.fiscal_quarter}`}
                          {budget.fiscal_month && ` / თვე ${budget.fiscal_month}`}
                        </Badge>
                        {budget.departments && (
                          <Badge variant="secondary">{budget.departments.name}</Badge>
                        )}
                        <Badge 
                          variant={
                            budget.status === 'approved' ? 'default' : 
                            budget.status === 'rejected' ? 'destructive' : 
                            'outline'
                          }
                        >
                          {budget.status === 'approved' && <CheckCircle className="mr-1 h-3 w-3" />}
                          {budget.status === 'rejected' && <XCircle className="mr-1 h-3 w-3" />}
                          {budget.status === 'pending' && <Clock className="mr-1 h-3 w-3" />}
                          {budget.status === 'approved' ? 'დამტკიცებული' : 
                           budget.status === 'rejected' ? 'უარყოფილი' : 
                           'მოლოდინში'}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-6 mt-4">
                        <div>
                          <p className="text-sm text-muted-foreground">დაგეგმილი</p>
                          <p className="text-lg font-semibold">
                            {new Intl.NumberFormat('ka-GE', {
                              style: 'currency',
                              currency: 'GEL'
                            }).format(budget.planned_amount)}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">ფაქტობრივი</p>
                          <p className="text-lg font-semibold">
                            {new Intl.NumberFormat('ka-GE', {
                              style: 'currency',
                              currency: 'GEL'
                            }).format(budget.actual_amount)}
                          </p>
                          {budget.status === 'approved' && (userRole.includes('admin') || userRole.includes('hr_manager')) && (
                            <div className="flex gap-2 mt-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setSelectedBudgetForExpense(budget);
                                  setExpenseFormData({
                                    expense_date: new Date().toISOString().split('T')[0],
                                    amount: 0,
                                    description: "",
                                    category: budget.category,
                                  });
                                  setIsAddExpenseDialogOpen(true);
                                }}
                                className="h-8 px-3"
                                title="ხარჯის დამატება"
                              >
                                <Plus className="h-4 w-4 mr-1" />
                                ხარჯის დამატება
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setSelectedBudgetForExpense(budget);
                                  fetchExpenses(budget.id);
                                  setIsViewExpensesDialogOpen(true);
                                }}
                                className="h-8 px-3"
                                title="ხარჯების ნახვა"
                              >
                                <Receipt className="h-4 w-4 mr-1" />
                                ნახვა
                              </Button>
                            </div>
                          )}
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">გადახარჯვა</p>
                          <p className={`text-lg font-semibold ${variance < 0 ? 'text-green-500' : 'text-red-500'}`}>
                            {variance >= 0 ? <TrendingUp className="inline h-4 w-4 mr-1" /> : <TrendingDown className="inline h-4 w-4 mr-1" />}
                            {new Intl.NumberFormat('ka-GE', {
                              style: 'currency',
                              currency: 'GEL',
                              signDisplay: 'always'
                            }).format(variance)}
                          </p>
                        </div>
                      </div>

                      <div className="mt-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-muted-foreground">გამოყენება</span>
                          <span className="text-sm font-medium">{utilizationPercent.toFixed(1)}%</span>
                        </div>
                        <Progress value={Math.min(utilizationPercent, 100)} className="h-2" />
                      </div>

                      {budget.notes && (
                        <p className="text-sm text-muted-foreground mt-3">{budget.notes}</p>
                      )}
                      
                      {budget.rejection_reason && (
                        <div className="mt-3 p-3 bg-destructive/10 rounded-md">
                          <p className="text-sm text-destructive"><strong>უარყოფის მიზეზი:</strong> {budget.rejection_reason}</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      {budget.status === 'pending' && (userRole.includes('admin') || userRole.includes('hr_manager')) && (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleApproveBudget(budget.id)}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            დამტკიცება
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setRejectingBudget(budget);
                              setIsRejectDialogOpen(true);
                            }}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            უარყოფა
                          </Button>
                        </>
                      )}
                      {budget.status === 'pending' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(budget)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      )}
                      {(userRole.includes('admin') || userRole.includes('hr_manager')) && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(budget.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              );
            })
          )}
        </div>

        {/* Add Expense Dialog */}
        <Dialog open={isAddExpenseDialogOpen} onOpenChange={setIsAddExpenseDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>ფაქტიური ხარჯის დამატება</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddExpense} className="space-y-4">
              <div className="p-4 bg-muted rounded-lg">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">კატეგორია</p>
                    <p className="font-semibold">{selectedBudgetForExpense?.category}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">დაგეგმილი ბიუჯეტი</p>
                    <p className="font-semibold">
                      {selectedBudgetForExpense && new Intl.NumberFormat('ka-GE', {
                        style: 'currency',
                        currency: 'GEL'
                      }).format(selectedBudgetForExpense.planned_amount)}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">მიმდინარე ფაქტიური</p>
                    <p className="font-semibold">
                      {selectedBudgetForExpense && new Intl.NumberFormat('ka-GE', {
                        style: 'currency',
                        currency: 'GEL'
                      }).format(selectedBudgetForExpense.actual_amount)}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">ხელმისაწვდომი</p>
                    <p className={`font-semibold ${selectedBudgetForExpense && (selectedBudgetForExpense.planned_amount - selectedBudgetForExpense.actual_amount) < 0 ? 'text-red-500' : 'text-green-500'}`}>
                      {selectedBudgetForExpense && new Intl.NumberFormat('ka-GE', {
                        style: 'currency',
                        currency: 'GEL'
                      }).format(selectedBudgetForExpense.planned_amount - selectedBudgetForExpense.actual_amount)}
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expense_date">ხარჯის თარიღი *</Label>
                  <Input
                    id="expense_date"
                    type="date"
                    value={expenseFormData.expense_date}
                    onChange={(e) => setExpenseFormData({ ...expenseFormData, expense_date: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">თანხა *</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    value={expenseFormData.amount}
                    onChange={(e) => setExpenseFormData({ ...expenseFormData, amount: parseFloat(e.target.value) || 0 })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense_category">ხარჯის კატეგორია *</Label>
                <Input
                  id="expense_category"
                  value={expenseFormData.category}
                  onChange={(e) => setExpenseFormData({ ...expenseFormData, category: e.target.value })}
                  placeholder="მაგ: ოფისის ინვენტარი, ტრანსპორტირება..."
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">აღწერა</Label>
                <Textarea
                  id="description"
                  value={expenseFormData.description}
                  onChange={(e) => setExpenseFormData({ ...expenseFormData, description: e.target.value })}
                  placeholder="ხარჯის დეტალური აღწერა..."
                  rows={3}
                />
              </div>

              {expenseFormData.amount > 0 && selectedBudgetForExpense && (
                <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>ახალი ფაქტიური ჯამი:</span>
                      <span className="font-semibold">
                        {new Intl.NumberFormat('ka-GE', {
                          style: 'currency',
                          currency: 'GEL'
                        }).format(selectedBudgetForExpense.actual_amount + expenseFormData.amount)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>დარჩენილი ბიუჯეტი:</span>
                      <span className={`font-semibold ${(selectedBudgetForExpense.planned_amount - selectedBudgetForExpense.actual_amount - expenseFormData.amount) < 0 ? 'text-red-500' : 'text-green-500'}`}>
                        {new Intl.NumberFormat('ka-GE', {
                          style: 'currency',
                          currency: 'GEL'
                        }).format(selectedBudgetForExpense.planned_amount - selectedBudgetForExpense.actual_amount - expenseFormData.amount)}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex gap-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsAddExpenseDialogOpen(false);
                    setSelectedBudgetForExpense(null);
                  }}
                  className="flex-1"
                >
                  გაუქმება
                </Button>
                <Button
                  type="submit"
                  className="flex-1"
                  disabled={expenseFormData.amount === 0 || !expenseFormData.category}
                >
                  დამატება
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* View Expenses Dialog */}
        <Dialog open={isViewExpensesDialogOpen} onOpenChange={setIsViewExpensesDialogOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>
                ხარჯების ჩანაწერები - {selectedBudgetForExpense?.category}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 overflow-y-auto">
              <div className="p-4 bg-muted rounded-lg">
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">დაგეგმილი ბიუჯეტი</p>
                    <p className="font-semibold">
                      {selectedBudgetForExpense && new Intl.NumberFormat('ka-GE', {
                        style: 'currency',
                        currency: 'GEL'
                      }).format(selectedBudgetForExpense.planned_amount)}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">ჯამური ფაქტიური ხარჯი</p>
                    <p className="font-semibold">
                      {selectedBudgetForExpense && new Intl.NumberFormat('ka-GE', {
                        style: 'currency',
                        currency: 'GEL'
                      }).format(selectedBudgetForExpense.actual_amount)}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">ხარჯების რაოდენობა</p>
                    <p className="font-semibold">{expenses.length}</p>
                  </div>
                </div>
              </div>

              {expenses.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Receipt className="mx-auto h-12 w-12 mb-4 opacity-50" />
                  <p>ხარჯები არ მოიძებნა</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {expenses.map((expense) => (
                    <Card key={expense.id} className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h4 className="font-semibold">{expense.category}</h4>
                            <Badge variant="outline">
                              {new Date(expense.expense_date).toLocaleDateString('ka-GE')}
                            </Badge>
                          </div>
                          {expense.description && (
                            <p className="text-sm text-muted-foreground mb-2">{expense.description}</p>
                          )}
                          <p className="text-lg font-bold">
                            {new Intl.NumberFormat('ka-GE', {
                              style: 'currency',
                              currency: 'GEL'
                            }).format(expense.amount)}
                          </p>
                        </div>
                        {(userRole.includes('admin') || userRole.includes('hr_manager')) && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteExpense(expense.id, expense.budget_plan_id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        )}
                      </div>
                    </Card>
                  ))}
                </div>
              )}

              <div className="flex justify-end pt-4 border-t">
                <Button onClick={() => setIsViewExpensesDialogOpen(false)}>
                  დახურვა
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Actual Expense Tracking Dialog (Deprecated) */}
        <Dialog open={isExpenseDialogOpen} onOpenChange={setIsExpenseDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>ფაქტობრივი ხარჯის აღრიცხვა</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="p-4 bg-muted rounded-lg">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">კატეგორია</p>
                    <p className="font-semibold">{trackingBudget?.category}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">დაგეგმილი</p>
                    <p className="font-semibold">
                      {trackingBudget && new Intl.NumberFormat('ka-GE', {
                        style: 'currency',
                        currency: 'GEL'
                      }).format(trackingBudget.planned_amount)}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>ფაქტობრივი დახარჯული თანხა *</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={expenseAmount}
                  onChange={(e) => setExpenseAmount(parseFloat(e.target.value) || 0)}
                  placeholder="0.00"
                />
                <p className="text-xs text-muted-foreground">
                  შეიყვანეთ რეალურად დახარჯული თანხა ამ ბიუჯეტის კატეგორიაზე
                </p>
              </div>
              
              {trackingBudget && expenseAmount > 0 && (
                <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">გადახარჯვა:</span>
                    <span className={`font-semibold ${expenseAmount - trackingBudget.planned_amount < 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {new Intl.NumberFormat('ka-GE', {
                        style: 'currency',
                        currency: 'GEL',
                        signDisplay: 'always'
                      }).format(expenseAmount - trackingBudget.planned_amount)}
                    </span>
                  </div>
                </div>
              )}
              
              <div className="flex gap-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsExpenseDialogOpen(false);
                    setTrackingBudget(null);
                    setExpenseAmount(0);
                  }}
                  className="flex-1"
                >
                  გაუქმება
                </Button>
                <Button
                  onClick={handleUpdateActualExpense}
                  className="flex-1"
                  disabled={expenseAmount === 0}
                >
                  შენახვა
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Reject Budget Dialog */}
        <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>ბიუჯეტის უარყოფა</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>უარყოფის მიზეზი *</Label>
                <Textarea
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="მიუთითეთ უარყოფის მიზეზი..."
                  rows={4}
                  required
                />
              </div>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsRejectDialogOpen(false);
                    setRejectionReason("");
                    setRejectingBudget(null);
                  }}
                  className="flex-1"
                >
                  გაუქმება
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => {
                    if (rejectingBudget && rejectionReason.trim()) {
                      handleRejectBudget(rejectingBudget.id, rejectionReason);
                      setIsRejectDialogOpen(false);
                      setRejectionReason("");
                      setRejectingBudget(null);
                    } else {
                      toast.error("მიუთითეთ უარყოფის მიზეზი");
                    }
                  }}
                  className="flex-1"
                  disabled={!rejectionReason.trim()}
                >
                  უარყოფა
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}
