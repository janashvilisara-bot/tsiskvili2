import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  Plus, Search, Bell, Trash2, CheckCheck, ExternalLink,
  Cake, Megaphone, FileText, UserPlus, CalendarDays, Wallet, Info, X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useRealtime } from "@/hooks/useRealtime";
import { cn } from "@/lib/utils";

interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  target_audience: string;
  created_at: string;
  expires_at: string | null;
  is_read: boolean;
  user_id: string | null;
  link: string | null;
}

export default function Notifications() {
  const navigate = useNavigate();
  const { user, userRole } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [targetAudience, setTargetAudience] = useState<string>('all');
  const [profiles, setProfiles] = useState<{ id: string; full_name: string }[]>([]);
  const [recipientSearch, setRecipientSearch] = useState<string>('');
  const [selectedRecipientIds, setSelectedRecipientIds] = useState<string[]>([]);

  const canManage = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    fetchNotifications();
    fetchProfiles();
  }, []);

  const fetchNotifications = async () => {
    try {
      if (!user) return;

      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .or(`user_id.eq.${user.id},user_id.is.null`)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setNotifications(data || []);
    } catch (error: any) {
      toast.error('შეტყობინებების ჩატვირთვა ვერ მოხერხდა');
    }
  };

  const fetchProfiles = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name')
        .order('full_name');
      if (error) throw error;
      setProfiles(data || []);
    } catch (error) {
      console.error('პროფილების ჩატვირთვა ვერ მოხერხდა', error);
    }
  };

  // Use centralized Realtime hook
  useRealtime({
    table: 'notifications',
    event: '*',
    onChange: fetchNotifications,
  });

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      if (!user?.id) {
        toast.error('გთხოვთ, გაიაროთ ავტორიზაცია');
        setIsLoading(false);
        return;
      }

      const selectedAudience = targetAudience;
      if (selectedAudience === 'specific' && selectedRecipientIds.length === 0) {
        toast.error('აირჩიეთ მაინც ერთი თანამშრომელი');
        setIsLoading(false);
        return;
      }

      const payload: any = {
        title: formData.get('title') as string,
        message: formData.get('message') as string,
        type: formData.get('type') as string,
        target_audience: selectedAudience,
        created_by: user.id,
      };

      if (selectedAudience === 'specific') {
        payload.employee_ids = selectedRecipientIds;
      }

      const { error } = await supabase
        .from('notifications')
        .insert([payload]);

      if (error) throw error;
      toast.success('შეტყობინება გაიგზავნა');
      setIsDialogOpen(false);
      setSelectedRecipientIds([]);
      setTargetAudience('all');
      fetchNotifications();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!canManage) {
      toast.error('არ გაქვთ უფლება');
      return;
    }

    if (!confirm('დარწმუნებული ხართ რომ გსურთ წაშლა?')) return;

    try {
      const { error } = await supabase
        .from('notifications')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast.success('შეტყობინება წაიშალა');
      fetchNotifications();
    } catch (error: any) {
      toast.error('წაშლა ვერ მოხერხდა');
    }
  };

  const markAsRead = async (id: string) => {
    try {
      await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', id);
      
      fetchNotifications();
    } catch (error) {
      console.error('Error marking as read:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      if (!user) return;
      
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .or(`user_id.eq.${user.id},user_id.is.null`)
        .eq('is_read', false);
      
      if (error) throw error;
      toast.success('ყველა შეტყობინება მონიშნულია წაკითხულად');
      fetchNotifications();
    } catch (error) {
      toast.error('ოპერაცია ვერ შესრულდა');
    }
  };

  const filteredNotifications = notifications.filter((notif) => {
    const matchesSearch = notif.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notif.message.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || notif.type === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const typeMeta: Record<string, { label: string; icon: any; bg: string; fg: string; ring: string }> = {
    birthday:      { label: "დაბადების დღე",      icon: Cake,         bg: "bg-pink-100 dark:bg-pink-500/15",       fg: "text-pink-600 dark:text-pink-300",       ring: "bg-pink-500" },
    announcement:  { label: "გამცნობა",            icon: Megaphone,    bg: "bg-blue-100 dark:bg-blue-500/15",       fg: "text-blue-600 dark:text-blue-300",       ring: "bg-blue-500" },
    document:      { label: "დოკუმენტი",           icon: FileText,     bg: "bg-violet-100 dark:bg-violet-500/15",   fg: "text-violet-600 dark:text-violet-300",   ring: "bg-violet-500" },
    new_employee:  { label: "ახალი თანამშრომელი",  icon: UserPlus,     bg: "bg-emerald-100 dark:bg-emerald-500/15", fg: "text-emerald-600 dark:text-emerald-300", ring: "bg-emerald-500" },
    leave:         { label: "შვებულება",           icon: CalendarDays, bg: "bg-amber-100 dark:bg-amber-500/15",     fg: "text-amber-600 dark:text-amber-300",     ring: "bg-amber-500" },
    payroll:       { label: "ხელფასი",             icon: Wallet,       bg: "bg-teal-100 dark:bg-teal-500/15",       fg: "text-teal-600 dark:text-teal-300",       ring: "bg-teal-500" },
    general:       { label: "ზოგადი",              icon: Info,         bg: "bg-slate-100 dark:bg-slate-500/15",     fg: "text-slate-600 dark:text-slate-300",     ring: "bg-slate-500" },
  };
  const getTypeMeta = (t: string) => typeMeta[t] || typeMeta.general;

  const formatRelative = (iso: string) => {
    const diff = Date.now() - new Date(iso).getTime();
    const m = Math.floor(diff / 60000);
    if (m < 1) return "ახლახან";
    if (m < 60) return `${m} წთ წინ`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h} სთ წინ`;
    const d = Math.floor(h / 24);
    if (d === 1) return "გუშინ";
    if (d < 7) return `${d} დღის წინ`;
    return new Date(iso).toLocaleDateString("ka-GE", { day: "numeric", month: "short" });
  };

  const stats = useMemo(() => {
    const total = notifications.length;
    const unread = notifications.filter(n => !n.is_read).length;
    return { total, unread };
  }, [notifications]);

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 md:py-10 space-y-8">
      {/* Header */}
      <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <Bell className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-foreground">შეტყობინებები</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {stats.unread > 0
                ? <>თქვენ გაქვთ <span className="font-semibold text-primary">{stats.unread} ახალი</span> შეტყობინება</>
                : "ყველაფერი წაკითხულია"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="rounded-xl border border-border bg-card px-3.5 py-1.5 text-center shadow-sm">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">სულ</p>
            <p className="text-base font-bold text-foreground leading-tight">{stats.total}</p>
          </div>
          <div className="rounded-xl border border-primary/20 bg-primary/10 px-3.5 py-1.5 text-center">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-primary/70">ახალი</p>
            <p className="text-base font-bold text-primary leading-tight">{stats.unread}</p>
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="space-y-3">
        <div className="flex flex-col gap-2 sm:flex-row">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="ძებნა შეტყობინებებში..."
              className="h-10 rounded-xl border-border bg-card pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              className="h-10 gap-2 rounded-xl"
              onClick={markAllAsRead}
              disabled={stats.unread === 0}
            >
              <CheckCheck className="h-4 w-4" />
              ყველას წაკითხვა
            </Button>
            {canManage && (
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="h-10 gap-2 rounded-xl">
                    <Plus className="h-4 w-4" />
                    ახალი
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>შეტყობინების შექმნა</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="title">სათაური *</Label>
                      <Input id="title" name="title" required placeholder="შეტყობინების სათაური" />
                    </div>
                    <div>
                      <Label htmlFor="type">ტიპი *</Label>
                      <Select name="type" required>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="general">ზოგადი</SelectItem>
                          <SelectItem value="birthday">დაბადების დღე</SelectItem>
                          <SelectItem value="document">დოკუმენტი</SelectItem>
                          <SelectItem value="new_employee">ახალი თანამშრომელი</SelectItem>
                          <SelectItem value="leave">შვებულება</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="target_audience">აუდიტორია *</Label>
                      <Select name="target_audience" required value={targetAudience} onValueChange={setTargetAudience}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">ყველა თანამშრომელი</SelectItem>
                          <SelectItem value="specific">კონკრეტული პირები</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {targetAudience === 'specific' && (
                      <div className="space-y-2">
                        <Label>აირჩიეთ თანამშრომლები</Label>
                        <Input
                          placeholder="ძებნა თანამშრომლებში..."
                          value={recipientSearch}
                          onChange={(e) => setRecipientSearch(e.target.value)}
                        />
                        <ScrollArea className="h-56 rounded-md border p-2">
                          <div className="space-y-2">
                            {profiles
                              .filter((p) => p.full_name.toLowerCase().includes(recipientSearch.toLowerCase()))
                              .map((p) => {
                                const checked = selectedRecipientIds.includes(p.id);
                                return (
                                  <label key={p.id} className="flex items-center gap-3 text-sm">
                                    <Checkbox
                                      checked={checked}
                                      onCheckedChange={(val) => {
                                        const isChecked = Boolean(val);
                                        setSelectedRecipientIds((prev) =>
                                          isChecked ? [...prev, p.id] : prev.filter((id) => id !== p.id)
                                        );
                                      }}
                                    />
                                    <span>{p.full_name}</span>
                                  </label>
                                );
                              })}
                            {profiles.filter((p) => p.full_name.toLowerCase().includes(recipientSearch.toLowerCase())).length === 0 && (
                              <p className="text-sm text-muted-foreground">შედეგი არ მოიძებნა</p>
                            )}
                          </div>
                        </ScrollArea>
                        <p className="text-xs text-muted-foreground">არჩეულია: {selectedRecipientIds.length}</p>
                      </div>
                    )}
                    <div>
                      <Label htmlFor="message">შეტყობინება *</Label>
                      <Textarea id="message" name="message" required placeholder="შეიყვანეთ შეტყობინება" rows={4} />
                    </div>
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? 'მიმდინარეობს...' : 'გაგზავნა'}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>

        {/* Category chips */}
        <div className="flex flex-wrap gap-2">
          {[
            { v: "all",          label: "ყველა" },
            { v: "birthday",     label: "დაბადების დღე" },
            { v: "new_employee", label: "ახალი თანამშრომელი" },
            { v: "document",     label: "დოკუმენტი" },
            { v: "leave",        label: "შვებულება" },
          ].map(c => (
            <button
              key={c.v}
              onClick={() => setSelectedCategory(c.v)}
              className={cn(
                "rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all",
                selectedCategory === c.v
                  ? "border-primary bg-primary text-primary-foreground shadow-sm"
                  : "border-border bg-card text-muted-foreground hover:text-foreground hover:border-foreground/30"
              )}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Notification list */}
      <div className="space-y-3">
        {filteredNotifications.map((notif) => {
          const meta = getTypeMeta(notif.type);
          const Icon = meta.icon;
          const unread = !notif.is_read;
          return (
            <div
              key={notif.id}
              onClick={() => {
                if (unread) markAsRead(notif.id);
                if (notif.link) navigate(notif.link);
              }}
              className={cn(
                "group relative rounded-2xl border bg-card p-4 shadow-sm transition-all duration-200",
                "hover:shadow-md hover:-translate-y-px",
                unread ? "border-border" : "border-border/60 bg-card/60",
                notif.link && "cursor-pointer"
              )}
            >
              <div className={cn("flex gap-4", !unread && "opacity-80")}>
                <div className="relative flex-shrink-0">
                  <div className={cn("flex h-12 w-12 items-center justify-center rounded-full", meta.bg, meta.fg)}>
                    <Icon className="h-5 w-5" />
                  </div>
                  {unread && (
                    <span className={cn(
                      "absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full ring-2 ring-card",
                      meta.ring
                    )} />
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className={cn(
                          "truncate text-sm",
                          unread ? "font-semibold text-foreground" : "font-medium text-foreground/80"
                        )}>
                          {notif.title}
                        </h3>
                        <span className={cn(
                          "shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-semibold",
                          meta.bg, meta.fg
                        )}>
                          {meta.label}
                        </span>
                        {notif.link && (
                          <ExternalLink className="h-3.5 w-3.5 text-muted-foreground" />
                        )}
                      </div>
                      <p className={cn(
                        "mt-1 text-sm leading-relaxed whitespace-pre-wrap line-clamp-3",
                        unread ? "text-muted-foreground" : "text-muted-foreground/80"
                      )}>
                        {notif.message}
                      </p>
                    </div>
                    <span className="whitespace-nowrap text-xs font-medium text-muted-foreground">
                      {formatRelative(notif.created_at)}
                    </span>
                  </div>

                  <div className="mt-3 flex items-center gap-2">
                    {notif.link && (
                      <Button
                        size="sm"
                        className="h-7 rounded-lg px-3 text-xs font-semibold"
                        onClick={(e) => { e.stopPropagation(); if (unread) markAsRead(notif.id); navigate(notif.link!); }}
                      >
                        ნახვა
                      </Button>
                    )}
                    {unread && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 rounded-lg px-3 text-xs font-semibold text-muted-foreground hover:text-foreground"
                        onClick={(e) => { e.stopPropagation(); markAsRead(notif.id); }}
                      >
                        წაკითხულად მონიშვნა
                      </Button>
                    )}
                    {canManage && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="ml-auto h-7 w-7 rounded-lg p-0 text-muted-foreground opacity-0 transition-opacity hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                        onClick={(e) => { e.stopPropagation(); handleDelete(notif.id); }}
                        aria-label="წაშლა"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredNotifications.length === 0 && (
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-border bg-card/40 py-16 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
            <Bell className="h-5 w-5" />
          </div>
          <p className="text-sm font-medium text-foreground">შეტყობინებები არ მოიძებნა</p>
          <p className="text-xs text-muted-foreground">სცადეთ სხვა ფილტრი ან ძებნა</p>
        </div>
      )}
    </div>
  );
}
