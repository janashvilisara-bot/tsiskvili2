import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Download, FileSpreadsheet, FileText, Calendar, Receipt, Baby, TrendingUp, DollarSign } from "lucide-react";
import { ReportPageShell } from "@/components/reports/ReportPageShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { XLSX } from '@/lib/xlsxCompat';

import { exportFullFinancialReport } from "@/lib/exportFullFinancialReport";
import { exportAnnualFinancialReport } from "@/lib/exportAnnualFinancialReport";

const MONTHS = [
  'იანვარი', 'თებერვალი', 'მარტი', 'აპრილი', 'მაისი', 'ივნისი',
  'ივლისი', 'აგვისტო', 'სექტემბერი', 'ოქტომბერი', 'ნოემბერი', 'დეკემბერი'
];

interface FinancialData {
  attendance: any[];
  overtime: any[];
  payroll: any[];
  pension: any[];
  holidays: any[];
  budgetExpenses: any[];
  leaves: any[];
  compensations: any[];
}

export default function FinancialReports() {
  const { userRole } = useAuth();
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [loading, setLoading] = useState(false);
  const [financialData, setFinancialData] = useState<FinancialData>({
    attendance: [],
    overtime: [],
    payroll: [],
    pension: [],
    holidays: [],
    budgetExpenses: [],
    leaves: [],
    compensations: []
  });

  const canViewReports = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    if (canViewReports) {
      fetchAllFinancialData();
    }
  }, [selectedMonth, selectedYear, canViewReports]);

  const fetchAllFinancialData = async () => {
    setLoading(true);
    try {
      const startDate = `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`;
      const endDate = new Date(selectedYear, selectedMonth, 0).toISOString().split('T')[0];

      // Fetch attendance
      const { data: attendanceData } = await supabase
        .from('attendance')
        .select(`
          *,
          employees:employee_id(full_name, position, department)
        `)
        .gte('date', startDate)
        .lte('date', endDate)
        .order('date', { ascending: false });

      // Fetch overtime requests
      const { data: overtimeData } = await supabase
        .from('overtime_requests' as any)
        .select(`
          *,
          employees:employee_id(full_name, position, department)
        `)
        .gte('work_date', startDate)
        .lte('work_date', endDate)
        .eq('status', 'approved')
        .order('work_date', { ascending: false });

      // Fetch payroll
      const { data: payrollData } = await supabase
        .from('payroll')
        .select(`
          *,
          employees:employee_id(full_name, position, department)
        `)
        .eq('month', selectedMonth)
        .eq('year', selectedYear)
        .order('created_at', { ascending: false });

      // Fetch pension payments
      const { data: pensionData } = await supabase
        .from('pension_payments')
        .select(`
          *,
          employee:employees(full_name, position, department, personal_id_number)
        `)
        .eq('period_month', selectedMonth)
        .eq('period_year', selectedYear)
        .order('payment_date', { ascending: false });

      // Fetch public holidays
      const { data: holidaysData } = await supabase
        .from('public_holidays')
        .select('*')
        .gte('holiday_date', startDate)
        .lte('holiday_date', endDate)
        .eq('is_active', true);

      // Fetch budget expenses
      const { data: budgetData } = await supabase
        .from('budget_expenses')
        .select('*')
        .eq('fiscal_month', selectedMonth)
        .eq('fiscal_year', selectedYear)
        .order('expense_date', { ascending: false });

      // Fetch leave requests
      const { data: leavesData } = await supabase
        .from('leave_requests')
        .select(`
          *,
          employees:employee_id(full_name, position, department)
        `)
        .gte('start_date', startDate)
        .lte('end_date', endDate)
        .eq('status', 'approved')
        .order('start_date', { ascending: false });

      // Fetch compensations (bonuses)
      const { data: compensationsData } = await supabase
        .from('compensation' as any)
        .select(`
          *,
          employees:employee_id(full_name, position, department)
        `)
        .gte('created_at', startDate)
        .lte('created_at', endDate)
        .order('created_at', { ascending: false });

      setFinancialData({
        attendance: attendanceData || [],
        overtime: overtimeData || [],
        payroll: payrollData || [],
        pension: pensionData || [],
        holidays: holidaysData || [],
        budgetExpenses: budgetData || [],
        leaves: leavesData || [],
        compensations: compensationsData || []
      });

    } catch (error) {
      console.error('Error fetching financial data:', error);
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setLoading(false);
    }
  };

  const exportAttendanceToExcel = () => {
    const data = financialData.attendance.map(att => ({
      'თანამშრომელი': att.employees?.full_name,
      'პოზიცია': att.employees?.position,
      'დეპარტამენტი': att.employees?.department,
      'თარიღი': att.date,
      'შესვლა': att.check_in || '-',
      'გასვლა': att.check_out || '-',
      'ზეგანაკვეთური (საათები)': att.overtime_hours || 0,
      'სტატუსი': att.status
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'დასწრება');
    XLSX.writeFile(wb, `დასწრება_${MONTHS[selectedMonth - 1]}_${selectedYear}.xlsx`);
    toast.success('ექსელის ფაილი ჩამოიტვირთა');
  };

  const exportOvertimeToExcel = () => {
    const data = financialData.overtime.map(ot => ({
      'თანამშრომელი': ot.employees?.full_name,
      'პოზიცია': ot.employees?.position,
      'დეპარტამენტი': ot.employees?.department,
      'თარიღი': ot.work_date,
      'დაწყება': ot.start_time,
      'დასრულება': ot.end_time,
      'საათები': ot.hours,
      'ტიპი': ot.overtime_type,
      'მიზეზი': ot.reason || '-',
      'სტატუსი': ot.status
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'ზეგანაკვეთური');
    XLSX.writeFile(wb, `ზეგანაკვეთური_${MONTHS[selectedMonth - 1]}_${selectedYear}.xlsx`);
    toast.success('ექსელის ფაილი ჩამოიტვირთა');
  };

  const exportPayrollToExcel = () => {
    const data = financialData.payroll.map(pr => ({
      'თანამშრომელი': pr.employees?.full_name,
      'პოზიცია': pr.employees?.position,
      'დეპარტამენტი': pr.employees?.department,
      'თვე': MONTHS[pr.month - 1],
      'წელი': pr.year,
      'ძირითადი ხელფასი': pr.base_salary,
      'ბონუსები': pr.bonuses,
      'დაქვითვები': pr.deductions,
      'მთლიანი ხელფასი': pr.gross_salary || (pr.base_salary + pr.bonuses),
      'წმინდა ხელფასი': pr.net_salary,
      'ზეგანაკვეთური საათები': pr.overtime_hours || 0,
      'დღესასწაულის საათები': pr.holiday_overtime_hours || 0,
      'სტატუსი': pr.status
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'ხელფასები');
    XLSX.writeFile(wb, `ხელფასები_${MONTHS[selectedMonth - 1]}_${selectedYear}.xlsx`);
    toast.success('ექსელის ფაილი ჩამოიტვირთა');
  };

  const exportPensionToExcel = () => {
    const data = financialData.pension.map(pen => ({
      'თანამშრომელი': pen.employee?.full_name,
      'პოზიცია': pen.employee?.position,
      'დეპარტამენტი': pen.employee?.department,
      'პირადი ნომერი': pen.employee?.personal_id_number,
      'პერიოდი': `${MONTHS[pen.period_month - 1]} ${pen.period_year}`,
      'ძირითადი ხელფასი': pen.base_salary,
      'თანამშრომლის წილი': pen.employee_contribution,
      'დამსაქმებლის წილი': pen.employer_contribution,
      'ჯამური თანხა': pen.total_amount,
      'გადახდის თარიღი': pen.payment_date,
      'სტატუსი': pen.status,
      'საფინანსო კოდი': pen.payment_reference || '-'
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'პენსია');
    XLSX.writeFile(wb, `პენსია_${MONTHS[selectedMonth - 1]}_${selectedYear}.xlsx`);
    toast.success('ექსელის ფაილი ჩამოიტვირთა');
  };

  const exportFullReport = async () => {
    try {
      await exportFullFinancialReport(selectedMonth, selectedYear);
      toast.success('სრული ფინანსური ანგარიში ჩამოიტვირთა');
    } catch (error) {
      toast.error('შეცდომა ექსპორტისას');
    }
  };

  const exportAnnualReport = async () => {
    try {
      await exportAnnualFinancialReport(selectedYear);
      toast.success('წლიური ფინანსური ანგარიში ჩამოიტვირთა');
    } catch (error) {
      toast.error('შეცდომა ექსპორტისას');
    }
  };

  const exportConsolidatedReport = () => {
    const wb = XLSX.utils.book_new();

    // Calculate totals
    const payrollTotal = financialData.payroll.reduce((sum, p) => sum + (p.net_salary || 0), 0);
    const bonusesTotal = financialData.payroll.reduce((sum, p) => sum + (p.bonuses || 0), 0);
    const compensationsTotal = financialData.compensations.reduce((sum, c) => sum + (c.amount || 0), 0);
    const overtimeHours = financialData.overtime.reduce((sum, o) => sum + (o.hours || 0), 0);
    const pensionTotal = financialData.pension.reduce((sum, p) => sum + ((p.employee_contribution || 0) + (p.employer_contribution || 0)), 0);
    const budgetTotal = financialData.budgetExpenses.reduce((sum, b) => sum + (b.amount || 0), 0);
    const leavesTotal = financialData.leaves.reduce((sum, l) => {
      const days = l.end_date && l.start_date 
        ? Math.ceil((new Date(l.end_date).getTime() - new Date(l.start_date).getTime()) / (1000 * 60 * 60 * 24)) + 1
        : 0;
      return sum + days;
    }, 0);

    // Summary sheet
    const summaryData = [
      ['სრული ფინანსური ანგარიში'],
      ['პერიოდი:', `${MONTHS[selectedMonth - 1]} ${selectedYear}`],
      [''],
      ['კატეგორია', 'თანხა/რაოდენობა', 'ერთეული'],
      ['ხელფასები (წმინდა)', payrollTotal.toFixed(2), '₾'],
      ['ბონუსები (payroll)', bonusesTotal.toFixed(2), '₾'],
      ['კომპენსაციები', compensationsTotal.toFixed(2), '₾'],
      ['ზეგანაკვეთური საათები', overtimeHours.toString(), 'საათი'],
      ['პენსია', pensionTotal.toFixed(2), '₾'],
      ['ბიუჯეტის ხარჯები', budgetTotal.toFixed(2), '₾'],
      ['შვებულებები', leavesTotal.toString(), 'დღე'],
      [''],
      ['ჯამური ფინანსური ხარჯი:', (
        payrollTotal + bonusesTotal + compensationsTotal + pensionTotal + budgetTotal
      ).toFixed(2), '₾']
    ];

    const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, wsSummary, 'შეჯამება');

    // Add all other sheets
    if (financialData.payroll.length > 0) {
      const payrollSheet = XLSX.utils.json_to_sheet(financialData.payroll.map(pr => ({
        'თანამშრომელი': pr.employees?.full_name,
        'ძირითადი': pr.base_salary,
        'ბონუსები': pr.bonuses,
        'დაქვითვები': pr.deductions,
        'წმინდა': pr.net_salary,
        'სტატუსი': pr.status
      })));
      XLSX.utils.book_append_sheet(wb, payrollSheet, 'ხელფასები');
    }

    if (financialData.overtime.length > 0) {
      const overtimeSheet = XLSX.utils.json_to_sheet(financialData.overtime.map(ot => ({
        'თანამშრომელი': ot.employees?.full_name,
        'თარიღი': ot.work_date,
        'საათები': ot.hours,
        'ტიპი': ot.overtime_type
      })));
      XLSX.utils.book_append_sheet(wb, overtimeSheet, 'ზეგანაკვეთური');
    }

    if (financialData.pension.length > 0) {
      const pensionSheet = XLSX.utils.json_to_sheet(financialData.pension.map(pen => ({
        'თანამშრომელი': pen.employee?.full_name,
        'თანამშრომლის წილი': pen.employee_contribution,
        'დამსაქმებლის წილი': pen.employer_contribution,
        'ჯამი': pen.total_amount,
        'სტატუსი': pen.status
      })));
      XLSX.utils.book_append_sheet(wb, pensionSheet, 'პენსია');
    }

    if (financialData.budgetExpenses.length > 0) {
      const budgetSheet = XLSX.utils.json_to_sheet(financialData.budgetExpenses.map(b => ({
        'კატეგორია': b.category,
        'თანხა': b.amount,
        'თარიღი': b.expense_date,
        'სტატუსი': b.status
      })));
      XLSX.utils.book_append_sheet(wb, budgetSheet, 'ბიუჯეტი');
    }

    // Leave Requests Sheet
    if (financialData.leaves.length > 0) {
      const leavesSheet = XLSX.utils.json_to_sheet(financialData.leaves.map(l => ({
        'თანამშრომელი': l.employees?.full_name || '',
        'თანამდებობა': l.employees?.position || '',
        'დეპარტამენტი': l.employees?.department || '',
        'შვებულების ტიპი': l.leave_type === 'annual' ? 'ყოველწლიური' :
                           l.leave_type === 'sick' ? 'სამედიცინო' :
                           l.leave_type === 'personal' ? 'პირადი' :
                           l.leave_type === 'unpaid' ? 'ანაზღაურების გარეშე' : l.leave_type,
        'დაწყების თარიღი': l.start_date,
        'დასრულების თარიღი': l.end_date,
        'დღეების რაოდენობა': l.end_date && l.start_date 
          ? Math.ceil((new Date(l.end_date).getTime() - new Date(l.start_date).getTime()) / (1000 * 60 * 60 * 24)) + 1
          : 0,
        'მიზეზი': l.reason || ''
      })));
      XLSX.utils.book_append_sheet(wb, leavesSheet, 'შვებულებები');
    }

    // Compensations/Bonuses Sheet
    if (financialData.compensations.length > 0) {
      const compensationsSheet = XLSX.utils.json_to_sheet(financialData.compensations.map(c => ({
        'თანამშრომელი': c.employees?.full_name || '',
        'თანამდებობა': c.employees?.position || '',
        'დეპარტამენტი': c.employees?.department || '',
        'თანხა': c.amount,
        'ტიპი': c.type === 'bonus' ? 'ბონუსი' :
                c.type === 'compensation' ? 'კომპენსაცია' :
                c.type === 'allowance' ? 'შემწეობა' : c.type,
        'ბონუსის ტიპი': c.bonus_type || '',
        'მიზეზი': c.reason || '',
        'თარიღი': new Date(c.created_at).toLocaleDateString('ka-GE'),
        'სტატუსი': c.status === 'approved' ? 'დამტკიცებული' :
                   c.status === 'pending' ? 'მოლოდინში' :
                   c.status === 'rejected' ? 'უარყოფილი' : c.status
      })));
      XLSX.utils.book_append_sheet(wb, compensationsSheet, 'კომპენსაციები');
    }

    XLSX.writeFile(wb, `სრული_ფინანსური_ანგარიში_${MONTHS[selectedMonth - 1]}_${selectedYear}.xlsx`);
    toast.success('კონსოლიდირებული რეპორტი ჩამოიტვირთა');
  };

  if (!canViewReports) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p className="text-lg">არ გაქვთ წვდომა ამ გვერდზე</p>
      </div>
    );
  }

  return (
    <ReportPageShell
      title="ფინანსური რეპორტები"
      description="სრული ფინანსური ანგარიშგება და Excel ექსპორტი"
      icon={DollarSign}
      gradient="from-violet-400 via-purple-500 to-fuchsia-500"
      shadow="shadow-purple-500/30"
      actions={
        <>
          <Button onClick={exportAnnualReport} size="lg" className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 shadow-lg">
            <TrendingUp className="mr-2 h-5 w-5" />
            წლიური ანგარიში
          </Button>
          <Button onClick={exportFullReport} size="lg" className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 shadow-lg">
            <Receipt className="mr-2 h-5 w-5" />
            სრული ანგარიში
          </Button>
        </>
      }
    >

        <Card className="border-border/50 bg-muted/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <FileText className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div className="space-y-1 text-sm text-muted-foreground">
                <p className="font-medium text-foreground">რა არის წარმოდგენილი ამ გვერდზე?</p>
                <p>ეს გვერდი აერთიანებს კომპანიის სრულ ფინანსურ ანგარიშგებას არჩეული თვისა და წლისთვის:</p>
                <p><strong>სულ ხელფასები</strong> - ყველა თანამშრომლის ჯამური ხელფასის მოცულობა</p>
                <p><strong>⏰ ზეგანაკვეთური</strong> - ზეგანაკვეთური მოთხოვნები და მათი სტატუსი</p>
                <p><strong>საპენსიო</strong> - თანამშრომლისა და დამსაქმებლის საპენსიო შენატანები</p>
                <p><strong>ბიუჯეტი</strong> - კომპანიის ხარჯები კატეგორიების მიხედვით</p>
                <p><strong>წლიური ანგარიში</strong> - ექსპორტი მთელი წლის მონაცემებით Excel-ში</p>
                <p><strong>სრული ანგარიში</strong> - არჩეული თვის დეტალური ანგარიში Excel-ში</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex gap-4">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <Select value={selectedMonth.toString()} onValueChange={(v) => setSelectedMonth(parseInt(v))}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {MONTHS.map((month, index) => (
                      <SelectItem key={index} value={(index + 1).toString()}>
                        {month}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedYear.toString()} onValueChange={(v) => setSelectedYear(parseInt(v))}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[2024, 2025, 2026].map((year) => (
                      <SelectItem key={year} value={year.toString()}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Summary Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">სულ ხელფასები</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {financialData.payroll.reduce((sum, p) => sum + p.net_salary, 0).toFixed(2)} ₾
              </div>
              <p className="text-xs text-muted-foreground">
                {financialData.payroll.length} თანამშრომელი
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">ზეგანაკვეთური</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {financialData.overtime.reduce((sum, o) => sum + o.hours, 0)} სთ
              </div>
              <p className="text-xs text-muted-foreground">
                {financialData.overtime.length} მოთხოვნა
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">პენსია</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {financialData.pension.reduce((sum, p) => sum + p.total_amount, 0).toFixed(2)} ₾
              </div>
              <p className="text-xs text-muted-foreground">
                {financialData.pension.length} გადახდა
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">ბიუჯეტის ხარჯები</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {financialData.budgetExpenses.reduce((sum, b) => sum + b.amount, 0).toFixed(2)} ₾
              </div>
              <p className="text-xs text-muted-foreground">
                {financialData.budgetExpenses.length} ხარჯი
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Reports */}
        <Tabs defaultValue="payroll" className="space-y-4">
          <TabsList>
            <TabsTrigger value="payroll">ხელფასები</TabsTrigger>
            <TabsTrigger value="overtime">ზეგანაკვეთური</TabsTrigger>
            <TabsTrigger value="pension">პენსია</TabsTrigger>
            <TabsTrigger value="attendance">დასწრება</TabsTrigger>
            <TabsTrigger value="budget">ბიუჯეტი</TabsTrigger>
          </TabsList>

          <TabsContent value="payroll">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>ხელფასები - {MONTHS[selectedMonth - 1]} {selectedYear}</CardTitle>
                <Button onClick={exportPayrollToExcel} variant="outline">
                  <FileSpreadsheet className="mr-2 h-4 w-4" />
                  Excel ექსპორტი
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead className="text-right">ძირითადი</TableHead>
                      <TableHead className="text-right">ბონუსები</TableHead>
                      <TableHead className="text-right">დაქვითვები</TableHead>
                      <TableHead className="text-right">წმინდა</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {financialData.payroll.map((pr) => (
                      <TableRow key={pr.id}>
                        <TableCell className="font-medium">{pr.employees?.full_name}</TableCell>
                        <TableCell className="text-right">{pr.base_salary.toFixed(2)} ₾</TableCell>
                        <TableCell className="text-right text-green-600">+{pr.bonuses.toFixed(2)} ₾</TableCell>
                        <TableCell className="text-right text-red-600">-{pr.deductions.toFixed(2)} ₾</TableCell>
                        <TableCell className="text-right font-bold">{pr.net_salary.toFixed(2)} ₾</TableCell>
                        <TableCell><Badge>{pr.status}</Badge></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="overtime">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>ზეგანაკვეთური - {MONTHS[selectedMonth - 1]} {selectedYear}</CardTitle>
                <Button onClick={exportOvertimeToExcel} variant="outline">
                  <FileSpreadsheet className="mr-2 h-4 w-4" />
                  Excel ექსპორტი
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>თარიღი</TableHead>
                      <TableHead className="text-right">საათები</TableHead>
                      <TableHead>ტიპი</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {financialData.overtime.map((ot) => (
                      <TableRow key={ot.id}>
                        <TableCell className="font-medium">{ot.employees?.full_name}</TableCell>
                        <TableCell>{ot.work_date}</TableCell>
                        <TableCell className="text-right font-semibold">{ot.hours}h</TableCell>
                        <TableCell><Badge variant="outline">{ot.overtime_type}</Badge></TableCell>
                        <TableCell><Badge>{ot.status}</Badge></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pension">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>პენსიის გადახდები - {MONTHS[selectedMonth - 1]} {selectedYear}</CardTitle>
                <Button onClick={exportPensionToExcel} variant="outline">
                  <FileSpreadsheet className="mr-2 h-4 w-4" />
                  Excel ექსპორტი
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead className="text-right">თანამშრომლის წილი</TableHead>
                      <TableHead className="text-right">დამსაქმებლის წილი</TableHead>
                      <TableHead className="text-right">ჯამი</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {financialData.pension.map((pen) => (
                      <TableRow key={pen.id}>
                        <TableCell className="font-medium">{pen.employee?.full_name}</TableCell>
                        <TableCell className="text-right">{pen.employee_contribution.toFixed(2)} ₾</TableCell>
                        <TableCell className="text-right">{pen.employer_contribution.toFixed(2)} ₾</TableCell>
                        <TableCell className="text-right font-bold">{pen.total_amount.toFixed(2)} ₾</TableCell>
                        <TableCell><Badge>{pen.status}</Badge></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="attendance">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>დასწრება - {MONTHS[selectedMonth - 1]} {selectedYear}</CardTitle>
                <Button onClick={exportAttendanceToExcel} variant="outline">
                  <FileSpreadsheet className="mr-2 h-4 w-4" />
                  Excel ექსპორტი
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>თარიღი</TableHead>
                      <TableHead>შესვლა</TableHead>
                      <TableHead>გასვლა</TableHead>
                      <TableHead className="text-right">ზეგანაკვეთური</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {financialData.attendance.slice(0, 50).map((att) => (
                      <TableRow key={att.id}>
                        <TableCell className="font-medium">{att.employees?.full_name}</TableCell>
                        <TableCell>{att.date}</TableCell>
                        <TableCell>{att.check_in || '-'}</TableCell>
                        <TableCell>{att.check_out || '-'}</TableCell>
                        <TableCell className="text-right">{att.overtime_hours || 0}h</TableCell>
                        <TableCell><Badge variant="outline">{att.status}</Badge></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {financialData.attendance.length > 50 && (
                  <p className="mt-4 text-center text-sm text-muted-foreground">
                    ნაჩვენებია პირველი 50 ჩანაწერი. სრული რეპორტისთვის გამოიყენეთ Excel ექსპორტი
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="budget">
            <Card>
              <CardHeader>
                <CardTitle>ბიუჯეტის ხარჯები - {MONTHS[selectedMonth - 1]} {selectedYear}</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>კატეგორია</TableHead>
                      <TableHead>თარიღი</TableHead>
                      <TableHead className="text-right">თანხა</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {financialData.budgetExpenses.map((exp) => (
                      <TableRow key={exp.id}>
                        <TableCell className="font-medium">{exp.category}</TableCell>
                        <TableCell>{exp.expense_date}</TableCell>
                        <TableCell className="text-right font-semibold">{exp.amount.toFixed(2)} ₾</TableCell>
                        <TableCell><Badge>{exp.status}</Badge></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
    </ReportPageShell>
  );
}