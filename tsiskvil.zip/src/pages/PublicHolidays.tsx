import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, PartyPopper } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { z } from "zod";

interface PublicHoliday {
  id: string;
  name: string;
  holiday_date: string;
  is_recurring: boolean;
  is_active: boolean;
  overtime_multiplier: number;
}

const PublicHolidays = () => {
  const { userRole } = useAuth();
  const { toast } = useToast();
  const [holidays, setHolidays] = useState<PublicHoliday[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingHoliday, setEditingHoliday] = useState<PublicHoliday | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    holiday_date: "",
    is_recurring: false,
    is_active: true,
    overtime_multiplier: 1.5,
  });

  useEffect(() => {
    if (userRole === "admin" || userRole === "hr_manager") {
      fetchHolidays();
    }
  }, [userRole]);

  const fetchHolidays = async () => {
    const { data, error } = await supabase
      .from("public_holidays")
      .select("*")
      .order("holiday_date", { ascending: true });

    if (error) {
      toast({
        title: "შეცდომა",
        description: "დასვენების დღეების ჩატვირთვა ვერ მოხერხდა",
        variant: "destructive",
      });
      return;
    }

    setHolidays(data || []);
  };

  const publicHolidaySchema = z.object({
    name: z.string().min(1, 'სახელი სავალდებულოა').max(200),
    holiday_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'თარიღის ფორმატი უნდა იყოს YYYY-MM-DD'),
    is_recurring: z.boolean(),
    is_active: z.boolean(),
    overtime_multiplier: z.number().min(1, 'კოეფიციენტი უნდა იყოს 1-ზე მეტი ან ტოლი').max(5, 'კოეფიციენტი არ შეიძლება იყოს 5-ზე მეტი'),
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const result = publicHolidaySchema.safeParse(formData);
    if (!result.success) {
      const errors = result.error.flatten().fieldErrors;
      toast({
        title: "შეცდომა",
        description: Object.values(errors).flat()[0] || 'შეცდომა ვალიდაციისას',
        variant: "destructive",
      });
      return;
    }

    if (editingHoliday) {
      const { error } = await supabase
        .from("public_holidays")
        .update(result.data)
        .eq("id", editingHoliday.id);

      if (error) {
        toast({
          title: "შეცდომა",
          description: "დასვენების დღის განახლება ვერ მოხერხდა",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "წარმატება",
        description: "დასვენების დღე განახლდა",
      });
    } else {
      const { error } = await supabase.from("public_holidays").insert([result.data as any]);

      if (error) {
        toast({
          title: "შეცდომა",
          description: "დასვენების დღის დამატება ვერ მოხერხდა",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "წარმატება",
        description: "დასვენების დღე დაემატა",
      });
    }

    setIsDialogOpen(false);
    setEditingHoliday(null);
    setFormData({ name: "", holiday_date: "", is_recurring: false, is_active: true, overtime_multiplier: 1.5 });
    fetchHolidays();
  };

  const handleEdit = (holiday: PublicHoliday) => {
    setEditingHoliday(holiday);
    setFormData({
      name: holiday.name,
      holiday_date: holiday.holiday_date,
      is_recurring: holiday.is_recurring,
      is_active: holiday.is_active,
      overtime_multiplier: holiday.overtime_multiplier || 1.5,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("დარწმუნებული ხართ, რომ გსურთ დასვენების დღის წაშლა?")) {
      return;
    }

    const { error } = await supabase
      .from("public_holidays")
      .delete()
      .eq("id", id);

    if (error) {
      toast({
        title: "შეცდომა",
        description: "დასვენების დღის წაშლა ვერ მოხერხდა",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "წარმატება",
      description: "დასვენების დღე წაშლილია",
    });
    fetchHolidays();
  };


  const resetForm = () => {
    setEditingHoliday(null);
    setFormData({ name: "", holiday_date: "", is_recurring: false, is_active: true, overtime_multiplier: 1.5 });
  };

  if (userRole !== "admin" && userRole !== "hr_manager") {
    return (
      <div className="flex items-center justify-center h-screen">
        <p className="text-lg">არ გაქვთ წვდომა ამ გვერდზე</p>
      </div>
    );
  }

  

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <PartyPopper className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">დასვენების დღეების მართვა</h1>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              ახალი დასვენების დღე
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingHoliday ? "დასვენების დღის რედაქტირება" : "ახალი დასვენების დღე"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">დასახელება</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  placeholder="მაგ: ახალი წელი"
                />
              </div>
              <div>
                <Label htmlFor="holiday_date">თარიღი</Label>
                <Input
                  id="holiday_date"
                  type="date"
                  value={formData.holiday_date}
                  onChange={(e) => setFormData({ ...formData, holiday_date: e.target.value })}
                  required
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_recurring"
                  checked={formData.is_recurring}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, is_recurring: checked })
                  }
                />
                <Label htmlFor="is_recurring">განმეორებადი (ყოველწლიური)</Label>
              </div>
              <div>
                <Label htmlFor="overtime_multiplier">
                  ოვერთაიმის კოეფიციენტი (x{formData.overtime_multiplier})
                </Label>
                <div className="flex items-center gap-4 mt-2">
                  <Input
                    id="overtime_multiplier"
                    type="number"
                    step="0.1"
                    min="1.0"
                    max="5.0"
                    value={formData.overtime_multiplier}
                    onChange={(e) => setFormData({ 
                      ...formData, 
                      overtime_multiplier: parseFloat(e.target.value) || 1.5 
                    })}
                    className="w-32"
                  />
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setFormData({ ...formData, overtime_multiplier: 1.5 })}
                    >
                      1.5x
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setFormData({ ...formData, overtime_multiplier: 2.0 })}
                    >
                      2.0x
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setFormData({ ...formData, overtime_multiplier: 3.0 })}
                    >
                      3.0x
                    </Button>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  8 საათი × {formData.overtime_multiplier} = {(8 * formData.overtime_multiplier).toFixed(1)} საათი ანაზღაურება
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, is_active: checked })
                  }
                />
                <Label htmlFor="is_active">აქტიური</Label>
              </div>
              <div className="flex gap-2 justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsDialogOpen(false);
                    resetForm();
                  }}
                >
                  გაუქმება
                </Button>
                <Button type="submit">
                  {editingHoliday ? "განახლება" : "დამატება"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>დასვენების დღეების სია</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>დასახელება</TableHead>
                <TableHead>თარიღი</TableHead>
                <TableHead>ტიპი</TableHead>
                <TableHead>კოეფიციენტი</TableHead>
                <TableHead>სტატუსი</TableHead>
                <TableHead className="text-right">მოქმედებები</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {holidays.map((holiday) => (
                <TableRow key={holiday.id}>
                  <TableCell className="font-medium">{holiday.name}</TableCell>
                  <TableCell>{new Date(holiday.holiday_date).toLocaleDateString('ka-GE')}</TableCell>
                  <TableCell>
                    {holiday.is_recurring ? "ყოველწლიური" : "ერთჯერადი"}
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="font-semibold">
                      {holiday.overtime_multiplier || 1.5}x
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span
                      className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                        holiday.is_active
                          ? "bg-green-50 text-green-700"
                          : "bg-gray-50 text-gray-700"
                      }`}
                    >
                      {holiday.is_active ? "აქტიური" : "არააქტიური"}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-2 justify-end">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(holiday)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDelete(holiday.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {holidays.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground">
                    დასვენების დღეები არ არის დამატებული
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default PublicHolidays;
