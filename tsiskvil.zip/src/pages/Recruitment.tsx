import { useState, useEffect } from "react";
import { useFeatureLock, FeatureLockOverlay } from "@/components/FeatureCardLock";
import { 
  Briefcase,
  UserPlus,
  FileText,
  DollarSign,
  ArrowRight,
  Users,
  Sparkles,
  GraduationCap,
  ArrowUpRight,
  ArrowDownRight,
  UserCheck,
  Clock,
  Target
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import HubErrorState from "@/components/HubErrorState";
import { cn } from "@/lib/utils";

interface RecruitmentStats {
  openVacancies: number;
  totalCandidates: number;
  pendingInterviews: number;
  hiredThisMonth: number;
}

export default function Recruitment() {
  const navigate = useNavigate();
  const { isLocked, handleLockedClick } = useFeatureLock();
  const [stats, setStats] = useState<RecruitmentStats>({
    openVacancies: 0,
    totalCandidates: 0,
    pendingInterviews: 0,
    hiredThisMonth: 0
  });
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState(false);

  useEffect(() => {
    fetchRecruitmentStats();
  }, []);

  const fetchRecruitmentStats = async () => {
    try {
      // Fetch open vacancies
      const { count: vacancyCount } = await supabase
        .from('job_vacancies')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'open');

      // Fetch total candidates
      const { count: candidateCount } = await supabase
        .from('candidates')
        .select('*', { count: 'exact', head: true });

      // Fetch pending interviews (candidates with status 'interview')
      const { count: interviewCount } = await supabase
        .from('candidates')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'interview');

      // Fetch hired this month
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);
      
      const { count: hiredCount } = await supabase
        .from('candidates')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'hired')
        .gte('updated_at', startOfMonth.toISOString());

      setStats({
        openVacancies: vacancyCount || 0,
        totalCandidates: candidateCount || 0,
        pendingInterviews: interviewCount || 0,
        hiredThisMonth: hiredCount || 0
      });
    } catch (error) {
      console.error('Error fetching recruitment stats:', error);
      setFetchError(true);
    } finally {
      setLoading(false);
    }
  };

  const quickStats = [
    {
      title: "ღია ვაკანსიები",
      value: stats.openVacancies.toString(),
      icon: Briefcase,
      color: "from-sky-500 to-blue-600",
      bgColor: "bg-sky-500/10",
      trend: "+3",
      trendUp: true,
      description: "პოზიცია"
    },
    {
      title: "სულ კანდიდატები",
      value: stats.totalCandidates.toString(),
      icon: Users,
      color: "from-indigo-500 to-violet-600",
      bgColor: "bg-indigo-500/10",
      trend: "+12%",
      trendUp: true,
      description: "აპლიკანტი"
    },
    {
      title: "მომლოდინე ინტერვიუ",
      value: stats.pendingInterviews.toString(),
      icon: Clock,
      color: "from-amber-500 to-orange-600",
      bgColor: "bg-amber-500/10",
      trend: stats.pendingInterviews > 0 ? "დაგეგმილი" : "არ არის",
      trendUp: stats.pendingInterviews > 0,
      description: "ინტერვიუ"
    },
    {
      title: "დაქირავებული (თვე)",
      value: stats.hiredThisMonth.toString(),
      icon: UserCheck,
      color: "from-emerald-500 to-green-600",
      bgColor: "bg-emerald-500/10",
      trend: "+2",
      trendUp: true,
      description: "თანამშრომელი"
    }
  ];

  const categories = [
    {
      title: "ძირითადი ფუნქციები",
      description: "რეკრუტმენტის ცენტრალური სერვისები",
      icon: Briefcase,
      color: "from-sky-400 via-blue-500 to-indigo-500",
      shadowColor: "shadow-blue-500/25",
      functions: [
        { 
          name: "ვაკანსიები", 
          description: "ვაკანსიების მართვა და პუბლიკაცია",
          url: "/vacancies",
          icon: Briefcase,
          stats: `${stats.openVacancies} ღია`
        },
        { 
          name: "კანდიდატები", 
          description: "კანდიდატების მართვა და შეფასება",
          url: "/candidates",
          icon: UserPlus,
          stats: `${stats.totalCandidates} სულ`
        },
        { 
          name: "ონბორდინგი", 
          description: "ახალი თანამშრომლების ადაპტაცია",
          url: "/onboarding",
          icon: GraduationCap,
          stats: "პროცესი"
        },
      ]
    },
    {
      title: "პარამეტრები & შაბლონები",
      description: "რეკრუტმენტის დამხმარე ინსტრუმენტები",
      icon: FileText,
      color: "from-rose-400 via-pink-500 to-fuchsia-500",
      shadowColor: "shadow-pink-500/25",
      functions: [
        { 
          name: "ონბორდინგ შაბლონები", 
          description: "ონბორდინგის პროცესის შაბლონები",
          url: "/onboarding-templates",
          icon: FileText,
          stats: "შაბლონები"
        },
        { 
          name: "გარიგებები", 
          description: "რეკრუტმენტის გარიგებების მართვა",
          url: "/deals",
          icon: DollarSign,
          stats: "გარიგებები"
        },
      ]
    }
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {fetchError && <HubErrorState onRetry={fetchRecruitmentStats} />}
          {/* Header */}
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-sky-400 via-blue-500 to-indigo-500 shadow-xl shadow-blue-500/30 animate-scale-in">
                <UserPlus className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-foreground via-foreground/90 to-foreground/70 bg-clip-text text-transparent">
                  რეკრუტმენტი
                </h1>
                <p className="text-muted-foreground mt-1 text-lg">
                  რეკრუტმენტისა და ონბორდინგის მართვის სისტემა
                </p>
              </div>
            </div>
          </div>

          {/* Quick Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {quickStats.map((stat, index) => (
              <Card 
                key={index}
                className={cn(
                  "group relative overflow-hidden border-border/50 bg-card/80 backdrop-blur-xl",
                  "hover:shadow-2xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-2",
                  "animate-fade-in"
                )}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <CardContent className="p-6 relative">
                  <div className="flex items-start justify-between mb-4">
                    <div className={cn(
                      "p-3 rounded-xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-3",
                      stat.bgColor
                    )}>
                      <stat.icon className="h-6 w-6" style={{ color: `hsl(var(--primary))` }} />
                    </div>
                    
                    <div className={cn(
                      "flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full transition-all duration-300",
                      stat.trendUp 
                        ? "text-emerald-600 bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-400" 
                        : "text-amber-600 bg-amber-100 dark:bg-amber-950/50 dark:text-amber-400"
                    )}>
                      {stat.trendUp ? (
                        <ArrowUpRight className="h-3 w-3" />
                      ) : (
                        <ArrowDownRight className="h-3 w-3" />
                      )}
                      <span>{stat.trend}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-2xl md:text-3xl font-bold tracking-tight group-hover:scale-105 transition-transform duration-300 origin-left">
                      {loading ? (
                        <div className="h-8 w-16 bg-muted animate-pulse rounded" />
                      ) : (
                        stat.value
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground font-medium">
                      {stat.title}
                    </div>
                    <div className="text-xs text-muted-foreground/70">
                      {stat.description}
                    </div>
                  </div>

                  <div className={cn(
                    "absolute -right-8 -bottom-8 w-32 h-32 rounded-full blur-3xl opacity-0 group-hover:opacity-30 transition-opacity duration-500",
                    `bg-gradient-to-br ${stat.color}`
                  )} />
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Categories */}
          <div className="space-y-10">
            {categories.map((category, idx) => (
              <div 
                key={idx} 
                className="space-y-6 animate-fade-in"
                style={{ animationDelay: `${(idx + 4) * 100}ms` }}
              >
                {/* Category Header */}
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "p-3 rounded-xl bg-gradient-to-br shadow-xl",
                    category.color,
                    category.shadowColor
                  )}>
                    <category.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl md:text-3xl font-bold text-foreground">{category.title}</h2>
                    <p className="text-sm text-muted-foreground">{category.description}</p>
                  </div>
                </div>

                {/* Function Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
                  {category.functions.map((func, funcIdx) => (
                    <Card
                      key={funcIdx}
                      className={cn(
                        "group cursor-pointer overflow-hidden",
                        "border-border/50 bg-card/80 backdrop-blur-xl",
                        "hover:border-primary/50 transition-all duration-500",
                        "hover:shadow-2xl hover:-translate-y-2",
                        "animate-fade-in"
                      )}
                      style={{ animationDelay: `${(idx * 4 + funcIdx + 5) * 50}ms` }}
                      onClick={(e) => isLocked(func.url) ? handleLockedClick(e) : navigate(func.url)}
                    >
                      {isLocked(func.url) && <FeatureLockOverlay />}
                      <CardHeader className={cn(
                        "bg-gradient-to-br text-white pb-4 relative overflow-hidden",
                        category.color
                      )}>
                        <div className="flex items-center gap-3 relative z-10">
                          <div className="p-2.5 bg-white/20 rounded-xl backdrop-blur-sm group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                            <func.icon className="h-5 w-5" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{func.name}</CardTitle>
                            <span className="text-xs text-white/80">{func.stats}</span>
                          </div>
                        </div>
                        
                        <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700" />
                        <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white/5 rounded-full group-hover:scale-125 transition-transform duration-500" />
                      </CardHeader>
                      
                      <CardContent className="pt-6 relative">
                        <CardDescription className="text-muted-foreground mb-4 min-h-[48px] leading-relaxed">
                          {func.description}
                        </CardDescription>
                        
                        <div className="flex items-center gap-2 text-primary font-semibold text-sm group-hover:gap-4 transition-all duration-300">
                          <span>გახსნა</span>
                          <ArrowRight className="h-4 w-4 group-hover:translate-x-2 transition-transform duration-300" />
                        </div>

                        <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Enhanced Footer Stats */}
          <div 
            className="mt-12 p-6 md:p-8 rounded-2xl bg-gradient-to-r from-primary/5 via-primary/10 to-accent/10 border border-primary/20 backdrop-blur-xl animate-fade-in"
            style={{ animationDelay: '800ms' }}
          >
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-primary/10 animate-pulse">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-lg font-semibold text-foreground">
                    სულ ხელმისაწვდომია <span className="text-2xl font-bold text-primary">{categories.reduce((sum, cat) => sum + cat.functions.length, 0)}</span> რეკრუტმენტის ფუნქცია
                  </p>
                  <p className="text-sm text-muted-foreground">
                    მოიძიეთ და დაიქირავეთ საუკეთესო ტალანტები
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400">
                  <Target className="h-4 w-4" />
                  <span className="text-sm font-medium">{stats.openVacancies} ღია პოზიცია</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
