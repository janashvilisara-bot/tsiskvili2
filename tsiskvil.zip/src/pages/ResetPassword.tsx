import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Lock, Loader2, CheckCircle2 } from "lucide-react";

export default function ResetPassword() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isRecovery, setIsRecovery] = useState<boolean | null>(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    // Recovery links carry type=recovery in the URL hash; Supabase also fires
    // PASSWORD_RECOVERY once it exchanges the token.
    const hash = window.location.hash;
    if (hash.includes("type=recovery")) {
      setIsRecovery(true);
      return;
    }
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") {
        setIsRecovery(true);
      }
    });
    const timer = setTimeout(() => {
      setIsRecovery((prev) => (prev === null ? false : prev));
    }, 3000);
    return () => {
      subscription.unsubscribe();
      clearTimeout(timer);
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (password.length < 6) {
      toast.error("პაროლი უნდა შეიცავდეს მინიმუმ 6 სიმბოლოს");
      return;
    }
    if (password !== confirmPassword) {
      toast.error("პაროლები არ ემთხვევა");
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      setDone(true);
      toast.success("პაროლი წარმატებით შეიცვალა!");
      setTimeout(() => navigate("/auth"), 2000);
    } catch (error) {
      console.error("Password update error:", error);
      toast.error("შეცდომა მოხდა", {
        description: "ბმული შესაძლოა ვადაგასულია - მოითხოვეთ აღდგენა თავიდან",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (isRecovery === null) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (isRecovery === false) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>ბმული არასწორია</CardTitle>
            <CardDescription>
              აღდგენის ბმული არასწორია ან ვადაგასულია. გთხოვთ, მოითხოვოთ პაროლის
              აღდგენა თავიდან.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full" onClick={() => navigate("/auth")}>
              შესვლის გვერდზე დაბრუნება
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Lock className="h-5 w-5 text-primary" />
            <CardTitle>ახალი პაროლის დაყენება</CardTitle>
          </div>
          <CardDescription>შეიყვანეთ თქვენი ახალი პაროლი</CardDescription>
        </CardHeader>
        <CardContent>
          {done ? (
            <div className="flex flex-col items-center gap-3 py-4 text-center">
              <CheckCircle2 className="h-12 w-12 text-green-500" />
              <p className="text-sm text-muted-foreground">
                პაროლი შეიცვალა! გადამისამართება შესვლის გვერდზე...
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="new_password">ახალი პაროლი</Label>
                <Input
                  id="new_password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  autoComplete="new-password"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm_password">გაიმეორეთ პაროლი</Label>
                <Input
                  id="confirm_password"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  minLength={6}
                  autoComplete="new-password"
                />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                პაროლის შეცვლა
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
