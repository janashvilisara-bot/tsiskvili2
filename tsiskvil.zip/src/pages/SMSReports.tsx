import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Download, Search, MessageSquare } from "lucide-react";
import { ReportPageShell } from "@/components/reports/ReportPageShell";
import { format } from "date-fns";
import { ka } from "date-fns/locale";
import { exportToExcel } from "@/lib/exportToExcel";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface SMSLog {
  id: string;
  recipient: string;
  message: string;
  status: string;
  sent_at: string;
  twilio_sid: string | null;
  employee_id: string | null;
  employee_name: string | null;
  organization: string | null;
}

export default function SMSReports() {
  const [logs, setLogs] = useState<SMSLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<SMSLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    fetchLogs();
  }, []);

  useEffect(() => {
    if (searchTerm) {
      const filtered = logs.filter(
        (log) =>
          log.recipient.toLowerCase().includes(searchTerm.toLowerCase()) ||
          log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
          log.status.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredLogs(filtered);
    } else {
      setFilteredLogs(logs);
    }
  }, [searchTerm, logs]);

  const fetchLogs = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("sms_logs")
        .select("*")
        .order("sent_at", { ascending: false });

      if (error) throw error;
      setLogs(data || []);
      setFilteredLogs(data || []);
    } catch (error: any) {
      console.error("Error fetching SMS logs:", error);
      toast({
        title: "შეცდომა",
        description: "SMS ლოგების ჩატვირთვა ვერ მოხერხდა",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleExport = () => {
    const exportData = filteredLogs.map((log, index) => ({
      "#": index + 1,
      "თანამშრომელი": log.employee_name || "-",
      "ორგანიზაცია": log.organization || "მთავარი ორგანიზაცია",
      "თარიღი": format(new Date(log.sent_at), "dd/MM/yyyy HH:mm", { locale: ka }),
      "ნომერი": log.recipient,
      "შეტყობინება": log.message,
      "გაგზავნის სტატუსი": getStatusLabel(log.status),
    }));

    const success = exportToExcel(
      exportData,
      `SMS_რეპორტი_${format(new Date(), "dd-MM-yyyy")}`,
      "SMS ისტორია"
    );

    if (success) {
      toast({
        title: "წარმატება",
        description: "რეპორტი წარმატებით ჩამოიტვირთა",
      });
    } else {
      toast({
        title: "შეცდომა",
        description: "რეპორტის ექსპორტი ვერ მოხერხდა",
        variant: "destructive",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "sent":
      case "delivered":
        return "default";
      case "failed":
      case "undelivered":
        return "destructive";
      case "queued":
        return "secondary";
      default:
        return "outline";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status.toLowerCase()) {
      case "sent":
        return "გაგზავნილია";
      case "delivered":
        return "მიწოდებულია";
      case "failed":
        return "ვერ გაიგზავნა";
      case "undelivered":
        return "ვერ მიიწოდა";
      case "queued":
        return "რიგშია";
      default:
        return status;
    }
  };

  return (
    <ReportPageShell
      title="SMS რეპორტი"
      description="გაგზავნილი SMS შეტყობინებების ისტორია"
      icon={MessageSquare}
      gradient="from-green-400 via-emerald-500 to-teal-500"
      shadow="shadow-emerald-500/30"
      actions={
        <Button onClick={handleExport} disabled={filteredLogs.length === 0} size="lg" className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 shadow-lg">
          <Download className="mr-2 h-4 w-4" />
          Excel-ში ექსპორტი
        </Button>
      }
    >

      <Card>
        <CardHeader>
          <CardTitle>ძებნა და ფილტრაცია</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="ძებნა ნომრის, შეტყობინების ან სტატუსის მიხედვით..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>
            SMS ისტორია ({filteredLogs.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">იტვირთება...</div>
          ) : filteredLogs.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              SMS ჩანაწერები არ მოიძებნა
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">#</TableHead>
                    <TableHead>თანამშრომელი</TableHead>
                    <TableHead>ორგანიზაცია</TableHead>
                    <TableHead>თარიღი</TableHead>
                    <TableHead>ნომერი</TableHead>
                    <TableHead className="max-w-md">შეტყობინება</TableHead>
                    <TableHead>გაგზავნის სტატუსი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLogs.map((log, index) => (
                    <TableRow key={log.id}>
                      <TableCell className="text-muted-foreground">{index + 1}</TableCell>
                      <TableCell className="font-medium">
                        {log.employee_name || "-"}
                      </TableCell>
                      <TableCell className="text-sm">
                        {log.organization || "მთავარი ორგანიზაცია"}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        {format(new Date(log.sent_at), "dd/MM/yyyy HH:mm", {
                          locale: ka,
                        })}
                      </TableCell>
                      <TableCell className="font-mono">{log.recipient}</TableCell>
                      <TableCell className="max-w-md">
                        <div className="line-clamp-3 text-sm">{log.message}</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusColor(log.status)}>
                          {getStatusLabel(log.status)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </ReportPageShell>
  );
}
