import { useState, useEffect } from "react";
import { Plus, Pencil, Trash2, Calendar, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { PageTransition } from "@/components/PageTransition";

interface LeaveType {
  id: string;
  name: string;
  name_en: string | null;
  days_allowed: number;
  is_paid: boolean;
  requires_approval: boolean;
  approver_role: string | null;
  color: string | null;
  description: string | null;
  is_active: boolean;
}

const COLORS = [
  { value: "blue", label: "ლურჯი", class: "bg-blue-500" },
  { value: "green", label: "მწვანე", class: "bg-green-500" },
  { value: "red", label: "წითელი", class: "bg-red-500" },
  { value: "yellow", label: "ყვითელი", class: "bg-yellow-500" },
  { value: "purple", label: "იასამნისფერი", class: "bg-purple-500" },
  { value: "orange", label: "ნარინჯისფერი", class: "bg-orange-500" },
  { value: "pink", label: "ვარდისფერი", class: "bg-pink-500" },
  { value: "cyan", label: "ცისფერი", class: "bg-cyan-500" },
];

type ApproverRole = "admin" | "hr_manager" | "department_manager" | "employee";

export default function LeaveTypes() {
  const [leaveTypes, setLeaveTypes] = useState<LeaveType[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingType, setEditingType] = useState<LeaveType | null>(null);
  const [formData, setFormData] = useState<{
    name: string;
    name_en: string;
    days_allowed: number;
    is_paid: boolean;
    requires_approval: boolean;
    approver_role: ApproverRole;
    color: string;
    description: string;
    is_active: boolean;
  }>({
    name: "",
    name_en: "",
    days_allowed: 0,
    is_paid: true,
    requires_approval: true,
    approver_role: "hr_manager",
    color: "blue",
    description: "",
    is_active: true,
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchLeaveTypes();
  }, []);

  const fetchLeaveTypes = async () => {
    try {
      const { data, error } = await supabase
        .from("leave_types")
        .select("*")
        .order("name");

      if (error) throw error;
      setLeaveTypes(data || []);
    } catch (error) {
      console.error("Error fetching leave types:", error);
      toast({
        title: "შეცდომა",
        description: "შვებულების ტიპების ჩატვირთვა ვერ მოხერხდა",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!formData.name) {
      toast({
        title: "შეცდომა",
        description: "გთხოვთ შეავსოთ სახელი",
        variant: "destructive",
      });
      return;
    }

    try {
      if (editingType) {
        const { error } = await supabase
          .from("leave_types")
          .update(formData)
          .eq("id", editingType.id);

        if (error) throw error;
        toast({
          title: "წარმატება",
          description: "შვებულების ტიპი განახლდა",
        });
      } else {
        const { error } = await supabase.from("leave_types").insert([formData]);

        if (error) throw error;
        toast({
          title: "წარმატება",
          description: "შვებულების ტიპი დაემატა",
        });
      }

      setDialogOpen(false);
      resetForm();
      fetchLeaveTypes();
    } catch (error) {
      console.error("Error saving leave type:", error);
      toast({
        title: "შეცდომა",
        description: "შენახვა ვერ მოხერხდა",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("ნამდვილად გსურთ წაშლა?")) return;

    try {
      const { error } = await supabase.from("leave_types").delete().eq("id", id);

      if (error) throw error;
      toast({
        title: "წარმატება",
        description: "შვებულების ტიპი წაიშალა",
      });
      fetchLeaveTypes();
    } catch (error) {
      console.error("Error deleting leave type:", error);
      toast({
        title: "შეცდომა",
        description: "წაშლა ვერ მოხერხდა",
        variant: "destructive",
      });
    }
  };

  const openEditDialog = (leaveType: LeaveType) => {
    setEditingType(leaveType);
    setFormData({
      name: leaveType.name,
      name_en: leaveType.name_en || "",
      days_allowed: leaveType.days_allowed,
      is_paid: leaveType.is_paid,
      requires_approval: leaveType.requires_approval,
      approver_role: (leaveType.approver_role as ApproverRole) || "hr_manager",
      color: leaveType.color || "blue",
      description: leaveType.description || "",
      is_active: leaveType.is_active,
    });
    setDialogOpen(true);
  };

  const resetForm = () => {
    setEditingType(null);
    setFormData({
      name: "",
      name_en: "",
      days_allowed: 0,
      is_paid: true,
      requires_approval: true,
      approver_role: "hr_manager",
      color: "blue",
      description: "",
      is_active: true,
    });
  };

  const getColorClass = (color: string | null) => {
    return COLORS.find((c) => c.value === color)?.class || "bg-blue-500";
  };

  return (
    <PageTransition>
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg">
              <Calendar className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">შვებულების ტიპები</h1>
              <p className="text-muted-foreground">
                შვებულების კატეგორიების მართვა
              </p>
            </div>
          </div>
          <Button
            onClick={() => {
              resetForm();
              setDialogOpen(true);
            }}
            className="gap-2"
          >
            <Plus className="h-4 w-4" />
            დამატება
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>შვებულების ტიპების სია</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">იტვირთება...</div>
            ) : leaveTypes.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                შვებულების ტიპები არ არის დამატებული
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ფერი</TableHead>
                    <TableHead>სახელი</TableHead>
                    <TableHead>სახელი (EN)</TableHead>
                    <TableHead>დღეები</TableHead>
                    <TableHead>ანაზღაურებადი</TableHead>
                    <TableHead>დამტკიცება</TableHead>
                    <TableHead>სტატუსი</TableHead>
                    <TableHead className="text-right">მოქმედება</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {leaveTypes.map((type) => (
                    <TableRow key={type.id}>
                      <TableCell>
                        <div
                          className={`w-6 h-6 rounded-full ${getColorClass(
                            type.color
                          )}`}
                        />
                      </TableCell>
                      <TableCell className="font-medium">{type.name}</TableCell>
                      <TableCell>{type.name_en || "-"}</TableCell>
                      <TableCell>{type.days_allowed}</TableCell>
                      <TableCell>
                        {type.is_paid ? (
                          <Check className="h-4 w-4 text-green-500" />
                        ) : (
                          <X className="h-4 w-4 text-red-500" />
                        )}
                      </TableCell>
                      <TableCell>
                        {type.requires_approval ? (
                          <Badge variant="outline">საჭიროა</Badge>
                        ) : (
                          <Badge variant="secondary">არ საჭიროებს</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={type.is_active ? "default" : "secondary"}
                        >
                          {type.is_active ? "აქტიური" : "არააქტიური"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog(type)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(type.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingType ? "რედაქტირება" : "ახალი შვებულების ტიპი"}
              </DialogTitle>
              <DialogDescription>
                შეავსეთ შვებულების ტიპის პარამეტრები
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label>სახელი (ქართულად) *</Label>
                <Input
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  placeholder="მაგ: წლიური შვებულება"
                />
              </div>

              <div className="space-y-2">
                <Label>სახელი (ინგლისურად)</Label>
                <Input
                  value={formData.name_en}
                  onChange={(e) =>
                    setFormData({ ...formData, name_en: e.target.value })
                  }
                  placeholder="e.g: Annual Leave"
                />
              </div>

              <div className="space-y-2">
                <Label>დასაშვები დღეების რაოდენობა</Label>
                <Input
                  type="number"
                  min={0}
                  value={formData.days_allowed}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      days_allowed: parseInt(e.target.value) || 0,
                    })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label>ფერი</Label>
                <Select
                  value={formData.color}
                  onValueChange={(value) =>
                    setFormData({ ...formData, color: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {COLORS.map((color) => (
                      <SelectItem key={color.value} value={color.value}>
                        <div className="flex items-center gap-2">
                          <div className={`w-4 h-4 rounded-full ${color.class}`} />
                          {color.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>აღწერა</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  placeholder="შვებულების ტიპის აღწერა..."
                  rows={3}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>ანაზღაურებადი</Label>
                <Switch
                  checked={formData.is_paid}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, is_paid: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>საჭიროებს დამტკიცებას</Label>
                <Switch
                  checked={formData.requires_approval}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, requires_approval: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>აქტიური</Label>
                <Switch
                  checked={formData.is_active}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, is_active: checked })
                  }
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                გაუქმება
              </Button>
              <Button onClick={handleSubmit}>
                {editingType ? "განახლება" : "დამატება"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </PageTransition>
  );
}
