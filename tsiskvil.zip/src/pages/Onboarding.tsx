import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  UserPlus,
  CheckCircle2,
  Clock,
  AlertCircle,
  Calendar,
  User,
  BookOpen,
  Users,
  Wrench,
  FileText,
  ChevronRight,
} from "lucide-react";

interface OnboardingData {
  id: string;
  employee_id: string;
  template_id: string;
  start_date: string;
  expected_end_date: string;
  actual_end_date: string | null;
  status: string;
  progress_percentage: number;
  assigned_buddy_id: string | null;
  notes: string | null;
  employee?: {
    full_name: string;
    position: string;
    department: string;
  };
  template?: {
    name: string;
    position_type: string;
  };
  buddy?: {
    full_name: string;
  };
}

interface TaskData {
  id: string;
  title: string;
  description: string | null;
  due_days: number;
  task_type: string;
  is_mandatory: boolean | null;
  order_index: number | null;
  completion?: {
    completed_at: string | null;
    status: string | null;
  };
}

const categoryIcons: Record<string, any> = {
  administrative: FileText,
  training: BookOpen,
  team: Users,
  technical: Wrench,
  onboarding: UserPlus,
  other: AlertCircle,
};

const categoryLabels: Record<string, { ka: string; en: string }> = {
  administrative: { ka: "ადმინისტრაციული", en: "Administrative" },
  training: { ka: "ტრენინგი", en: "Training" },
  team: { ka: "გუნდი", en: "Team" },
  technical: { ka: "ტექნიკური", en: "Technical" },
  onboarding: { ka: "ონბორდინგი", en: "Onboarding" },
  other: { ka: "სხვა", en: "Other" },
};

export default function Onboarding() {
  const navigate = useNavigate();
  const { user, userRole } = useAuth();
  const { language } = useLanguage();
  const [loading, setLoading] = useState(true);
  const [onboardings, setOnboardings] = useState<OnboardingData[]>([]);
  const [selectedOnboarding, setSelectedOnboarding] = useState<OnboardingData | null>(null);
  const [tasks, setTasks] = useState<TaskData[]>([]);
  const [activeTab, setActiveTab] = useState("all");

  useEffect(() => {
    fetchOnboardings();
  }, [user, userRole]);

  useEffect(() => {
    if (selectedOnboarding) {
      fetchTasks(selectedOnboarding.id, selectedOnboarding.template_id);
    }
  }, [selectedOnboarding]);

  const fetchOnboardings = async () => {
    if (!user) return;

    try {
      setLoading(true);
      let query = supabase
        .from("employee_onboarding")
        .select(`
          *,
          employee:employees!employee_onboarding_employee_id_fkey(full_name, position, department),
          template:onboarding_templates(name, position_type)
        `);

      if (userRole !== "admin" && userRole !== "hr_manager") {
        const { data: empData } = await supabase
          .from("employees")
          .select("id")
          .eq("user_id", user.id)
          .single();

        if (empData) {
          query = query.eq("employee_id", empData.id);
        }
      }

      const { data, error } = await query.order("created_at", { ascending: false });

      if (error) throw error;

      const typedData = (data || []) as unknown as OnboardingData[];
      setOnboardings(typedData);

      if (typedData.length > 0 && !selectedOnboarding) {
        setSelectedOnboarding(typedData[0]);
      }
    } catch (error: any) {
      console.error("Error fetching onboardings:", error);
      toast.error(language === "ka" ? "შეცდომა ონბორდინგების ჩატვირთვისას" : "Error loading onboardings");
    } finally {
      setLoading(false);
    }
  };

  const fetchTasks = async (onboardingId: string, templateId: string) => {
    try {
      const { data: tasksData, error: tasksError } = await supabase
        .from("onboarding_tasks")
        .select("*")
        .eq("template_id", templateId)
        .order("order_index", { ascending: true });

      if (tasksError) throw tasksError;

      const { data: completionData, error: completionError } = await supabase
        .from("onboarding_task_completion")
        .select("*")
        .eq("onboarding_id", onboardingId);

      if (completionError) throw completionError;

      const tasksWithCompletion = (tasksData || []).map((task) => {
        const completion = (completionData || []).find((c) => c.task_id === task.id);
        return {
          ...task,
          completion: completion
            ? { completed_at: completion.completed_at, status: completion.status }
            : { completed_at: null, status: null },
        };
      });

      setTasks(tasksWithCompletion);
    } catch (error: any) {
      console.error("Error fetching tasks:", error);
      toast.error(language === "ka" ? "შეცდომა დავალებების ჩატვირთვისას" : "Error loading tasks");
    }
  };

  const handleTaskToggle = async (taskId: string, currentStatus: string | null, onboardingId: string) => {
    try {
      const newStatus = currentStatus === 'completed' ? 'pending' : 'completed';
      
      const { data: existing } = await supabase
        .from("onboarding_task_completion")
        .select("*")
        .eq("onboarding_id", onboardingId)
        .eq("task_id", taskId)
        .maybeSingle();

      if (existing) {
        const { error } = await supabase
          .from("onboarding_task_completion")
          .update({
            status: newStatus,
            completed_at: newStatus === 'completed' ? new Date().toISOString() : null,
            completed_by: user?.id,
          })
          .eq("id", existing.id);

        if (error) throw error;
      } else {
        const { error } = await supabase.from("onboarding_task_completion").insert({
          onboarding_id: onboardingId,
          task_id: taskId,
          status: 'completed',
          completed_at: new Date().toISOString(),
          completed_by: user?.id,
        });

        if (error) throw error;
      }

      await updateProgress(onboardingId);
      toast.success(language === "ka" ? "დავალება განახლდა" : "Task updated");
    } catch (error: any) {
      console.error("Error toggling task:", error);
      toast.error(language === "ka" ? "შეცდომა დავალების განახლებისას" : "Error updating task");
    }
  };

  const updateProgress = async (onboardingId: string) => {
    try {
      const { data: allTasks } = await supabase
        .from("onboarding_tasks")
        .select("id")
        .eq("template_id", selectedOnboarding?.template_id || "");

      const { data: completedTasks } = await supabase
        .from("onboarding_task_completion")
        .select("id")
        .eq("onboarding_id", onboardingId)
        .eq("status", "completed");

      const totalCount = allTasks?.length || 0;
      const completedCount = completedTasks?.length || 0;
      const progressPercentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

      const { error } = await supabase
        .from("employee_onboarding")
        .update({
          progress_percentage: progressPercentage,
          status: progressPercentage === 100 ? "completed" : "in_progress",
          actual_completion_date: progressPercentage === 100 ? new Date().toISOString() : null,
        })
        .eq("id", onboardingId);

      if (error) throw error;

      await fetchOnboardings();
      if (selectedOnboarding) {
        await fetchTasks(selectedOnboarding.id, selectedOnboarding.template_id);
      }
    } catch (error: any) {
      console.error("Error updating progress:", error);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
      not_started: { label: language === "ka" ? "არ დაწყებულა" : "Not Started", variant: "outline" },
      in_progress: { label: language === "ka" ? "პროცესშია" : "In Progress", variant: "default" },
      completed: { label: language === "ka" ? "დასრულებულია" : "Completed", variant: "secondary" },
    };

    const config = statusConfig[status] || statusConfig.not_started;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const filteredOnboardings = onboardings.filter((o) => {
    if (activeTab === "all") return true;
    return o.status === activeTab;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
          <p className="text-muted-foreground">{language === "ka" ? "იტვირთება..." : "Loading..."}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">{language === "ka" ? "ონბორდინგი" : "Onboarding"}</h1>
          <p className="text-muted-foreground mt-1">
            {language === "ka" ? "თანამშრომლების ონბორდინგის პროცესების მართვა" : "Manage employee onboarding processes"}
          </p>
        </div>
        {(userRole === "admin" || userRole === "hr_manager") && (
          <Button onClick={() => navigate("/employees")}>
            <UserPlus className="h-4 w-4 mr-2" />
            {language === "ka" ? "ახალი ონბორდინგი" : "New Onboarding"}
          </Button>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">
            {language === "ka" ? "ყველა" : "All"} ({onboardings.length})
          </TabsTrigger>
          <TabsTrigger value="in_progress">
            {language === "ka" ? "პროცესში" : "In Progress"} ({onboardings.filter((o) => o.status === "in_progress").length})
          </TabsTrigger>
          <TabsTrigger value="completed">
            {language === "ka" ? "დასრულებული" : "Completed"} ({onboardings.filter((o) => o.status === "completed").length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-6">
          {filteredOnboardings.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <UserPlus className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">{language === "ka" ? "ონბორდინგი არ მოიძებნა" : "No Onboardings Found"}</h3>
                <p className="text-muted-foreground text-center max-w-md">
                  {language === "ka"
                    ? "ამჟამად აქტიური ონბორდინგი არ არის. დაიწყეთ ახალი თანამშრომლის ონბორდინგი."
                    : "No active onboardings at the moment. Start a new employee onboarding."}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6 md:grid-cols-3">
              {/* Left: Onboarding List */}
              <div className="md:col-span-1 space-y-4">
                {filteredOnboardings.map((onboarding) => (
                  <Card
                    key={onboarding.id}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedOnboarding?.id === onboarding.id ? "ring-2 ring-primary" : ""
                    }`}
                    onClick={() => setSelectedOnboarding(onboarding)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-base">{onboarding.employee?.full_name}</CardTitle>
                          <CardDescription className="text-sm mt-1">{onboarding.employee?.position}</CardDescription>
                        </div>
                        <ChevronRight className="h-5 w-5 text-muted-foreground" />
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">{language === "ka" ? "პროგრესი" : "Progress"}</span>
                        <span className="font-semibold">{onboarding.progress_percentage}%</span>
                      </div>
                      <Progress value={onboarding.progress_percentage} className="h-2" />
                      <div className="flex items-center justify-between">
                        {getStatusBadge(onboarding.status)}
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {new Date(onboarding.expected_end_date).toLocaleDateString(language === "ka" ? "ka-GE" : "en-US")}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Right: Selected Onboarding Details */}
              {selectedOnboarding && (
                <div className="md:col-span-2 space-y-6">
                  {/* Overview Card */}
                  <Card>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{selectedOnboarding.employee?.full_name}</CardTitle>
                          <CardDescription className="mt-1">
                            {selectedOnboarding.employee?.position} • {selectedOnboarding.employee?.department}
                          </CardDescription>
                        </div>
                        {getStatusBadge(selectedOnboarding.status)}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">{language === "ka" ? "დაწყების თარიღი" : "Start Date"}</p>
                          <p className="font-medium">
                            {new Date(selectedOnboarding.start_date).toLocaleDateString(language === "ka" ? "ka-GE" : "en-US")}
                          </p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">{language === "ka" ? "დასრულების თარიღი" : "Expected End"}</p>
                          <p className="font-medium">
                            {new Date(selectedOnboarding.expected_end_date).toLocaleDateString(language === "ka" ? "ka-GE" : "en-US")}
                          </p>
                        </div>
                        {selectedOnboarding.buddy && (
                          <div className="space-y-1">
                            <p className="text-sm text-muted-foreground">{language === "ka" ? "მენტორი" : "Buddy"}</p>
                            <div className="flex items-center gap-2">
                              <User className="h-4 w-4 text-muted-foreground" />
                              <p className="font-medium">{selectedOnboarding.buddy.full_name}</p>
                            </div>
                          </div>
                        )}
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">{language === "ka" ? "თემფლეითი" : "Template"}</p>
                          <p className="font-medium">{selectedOnboarding.template?.name}</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">{language === "ka" ? "პროგრესი" : "Overall Progress"}</span>
                          <span className="font-semibold">{selectedOnboarding.progress_percentage}%</span>
                        </div>
                        <Progress value={selectedOnboarding.progress_percentage} className="h-3" />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Tasks Checklist */}
                  <Card>
                    <CardHeader>
                      <CardTitle>{language === "ka" ? "ონბორდინგის დავალებები" : "Onboarding Tasks"}</CardTitle>
                      <CardDescription>
                        {language === "ka" ? "შეასრულეთ დავალებები ონბორდინგის პროცესის დასასრულებლად" : "Complete tasks to finish the onboarding process"}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {Object.entries(
                        tasks.reduce((acc, task) => {
                          const category = task.task_type || 'other';
                          if (!acc[category]) acc[category] = [];
                          acc[category].push(task);
                          return acc;
                        }, {} as Record<string, TaskData[]>)
                      ).map(([category, categoryTasks]) => {
                        const CategoryIcon = categoryIcons[category] || AlertCircle;
                        return (
                          <div key={category} className="space-y-3">
                            <div className="flex items-center gap-2 pb-2 border-b">
                              <CategoryIcon className="h-4 w-4 text-primary" />
                              <h4 className="font-semibold text-sm">
                                {categoryLabels[category]?.[language] || category}
                              </h4>
                              <Badge variant="outline" className="ml-auto">
                                {categoryTasks.filter((t) => t.completion?.status === 'completed').length}/{categoryTasks.length}
                              </Badge>
                            </div>
                            <div className="space-y-2">
                              {categoryTasks.map((task) => (
                                <div
                                  key={task.id}
                                  className="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/30 transition-colors"
                                >
                                  <Checkbox
                                    id={task.id}
                                    checked={task.completion?.status === 'completed'}
                                    onCheckedChange={() =>
                                      handleTaskToggle(task.id, task.completion?.status || null, selectedOnboarding.id)
                                    }
                                    className="mt-1"
                                  />
                                  <div className="flex-1 space-y-1">
                                    <label
                                      htmlFor={task.id}
                                      className={`text-sm font-medium cursor-pointer ${
                                        task.completion?.status === 'completed' ? "line-through text-muted-foreground" : ""
                                      }`}
                                    >
                                      {task.title}
                                      {task.is_mandatory && <span className="text-destructive ml-1">*</span>}
                                    </label>
                                    {task.description && (
                                      <p className="text-xs text-muted-foreground">{task.description}</p>
                                    )}
                                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                      <div className="flex items-center gap-1">
                                        <Clock className="h-3 w-3" />
                                        <span>
                                          {language === "ka" ? "დღე" : "Day"} {task.due_days}
                                        </span>
                                      </div>
                                      {task.completion?.status === 'completed' && task.completion.completed_at && (
                                        <div className="flex items-center gap-1 text-green-600">
                                          <CheckCircle2 className="h-3 w-3" />
                                          <span>
                                            {new Date(task.completion.completed_at).toLocaleDateString(
                                              language === "ka" ? "ka-GE" : "en-US"
                                            )}
                                          </span>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
