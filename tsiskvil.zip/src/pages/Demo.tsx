import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDemoMode } from "@/contexts/DemoContext";
import { Loader2, CheckCircle2, Users, Clock, FileText, DollarSign } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const loadingSteps = [
  { icon: Users, text: "თანამშრომლების მონაცემები...", delay: 500 },
  { icon: Clock, text: "დასწრების ისტორია...", delay: 1000 },
  { icon: FileText, text: "შვებულებები და დოკუმენტები...", delay: 1500 },
  { icon: DollarSign, text: "ფინანსური მონაცემები...", delay: 2000 },
];

export default function Demo() {
  const navigate = useNavigate();
  const { setDemoMode } = useDemoMode();
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  useEffect(() => {
    setDemoMode(true);
    
    // Animate progress and steps
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 2;
      });
    }, 50);

    loadingSteps.forEach((step, index) => {
      setTimeout(() => {
        setCurrentStep(index);
        if (index > 0) {
          setCompletedSteps(prev => [...prev, index - 1]);
        }
      }, step.delay);
    });

    // Complete and redirect
    const timer = setTimeout(() => {
      setCompletedSteps([0, 1, 2, 3]);
      setTimeout(() => navigate("/dashboard"), 500);
    }, 2500);

    return () => {
      clearTimeout(timer);
      clearInterval(progressInterval);
    };
  }, [setDemoMode, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-primary/10">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
      </div>
      
      <div className="text-center space-y-8 relative z-10 p-8">
        <div className="relative mx-auto w-20 h-20">
          <div className="absolute inset-0 rounded-full border-4 border-primary/20" />
          <div 
            className="absolute inset-0 rounded-full border-4 border-primary border-t-transparent animate-spin"
            style={{ animationDuration: "1s" }}
          />
          <div className="absolute inset-2 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
            <Loader2 className="h-8 w-8 text-primary animate-spin" />
          </div>
        </div>
        
        <div>
          <h2 className="text-3xl font-bold text-foreground mb-2">
            დემო რეჟიმის მომზადება
          </h2>
          <p className="text-muted-foreground">
            ვამზადებთ სადემონსტრაციო გარემოს თქვენთვის
          </p>
        </div>

        <div className="w-80 mx-auto">
          <Progress value={progress} className="h-2" />
          <p className="text-sm text-muted-foreground mt-2">{progress}%</p>
        </div>

        <div className="space-y-3 max-w-xs mx-auto">
          {loadingSteps.map((step, index) => {
            const Icon = step.icon;
            const isCompleted = completedSteps.includes(index);
            const isCurrent = currentStep === index && !isCompleted;
            
            return (
              <div 
                key={index}
                className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-300 ${
                  isCompleted 
                    ? 'bg-green-500/10 text-green-600' 
                    : isCurrent 
                      ? 'bg-primary/10 text-primary' 
                      : 'text-muted-foreground/50'
                }`}
              >
                {isCompleted ? (
                  <CheckCircle2 className="h-5 w-5 text-green-500" />
                ) : isCurrent ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <Icon className="h-5 w-5" />
                )}
                <span className="text-sm font-medium">{step.text}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
