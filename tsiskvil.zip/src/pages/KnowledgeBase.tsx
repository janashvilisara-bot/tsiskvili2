import { useState, useEffect } from "react";
import { Plus, Search, Edit2, Trash2, BookOpen, Tag, Globe, Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface KBEntry {
  id: string;
  category: string;
  subcategory: string | null;
  title: string;
  content: string;
  tags: string[];
  language: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

const CATEGORIES = [
  { value: 'personnel', label: 'პერსონალი' },
  { value: 'attendance', label: 'დასწრება' },
  { value: 'leave', label: 'შვებულება' },
  { value: 'payroll', label: 'ხელფასი' },
  { value: 'recruitment', label: 'რეკრუტმენტი' },
  { value: 'training', label: 'ტრენინგი' },
  { value: 'security', label: 'უსაფრთხოება' },
  { value: 'labor_law', label: 'კანონმდებლობა' },
  { value: 'organization', label: 'ორგანიზაცია' },
  { value: 'finance', label: 'ფინანსები' },
  { value: 'documents', label: 'დოკუმენტები' },
  { value: 'system', label: 'სისტემა' },
  { value: 'business_trips', label: 'მივლინებები' },
  { value: 'faq', label: 'FAQ' },
  { value: 'general', label: 'ზოგადი' },
];

const KnowledgeBase = () => {
  const [entries, setEntries] = useState<KBEntry[]>([]);
  const [search, setSearch] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [isLoading, setIsLoading] = useState(true);
  const [editEntry, setEditEntry] = useState<KBEntry | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [form, setForm] = useState({
    category: 'general',
    subcategory: '',
    title: '',
    content: '',
    tags: '',
    language: 'ka',
  });
  const { toast } = useToast();

  const fetchEntries = async () => {
    setIsLoading(true);
    let query = supabase
      .from('knowledge_base')
      .select('*')
      .order('category')
      .order('title');

    if (filterCategory !== 'all') {
      query = query.eq('category', filterCategory);
    }

    const { data, error } = await query;
    if (error) {
      toast({ title: "შეცდომა", description: error.message, variant: "destructive" });
    } else {
      setEntries((data as any[]) || []);
    }
    setIsLoading(false);
  };

  useEffect(() => { fetchEntries(); }, [filterCategory]);

  const filteredEntries = entries.filter(e =>
    !search || e.title.toLowerCase().includes(search.toLowerCase()) ||
    e.content.toLowerCase().includes(search.toLowerCase()) ||
    e.tags?.some(t => t.toLowerCase().includes(search.toLowerCase()))
  );

  const openNew = () => {
    setEditEntry(null);
    setForm({ category: 'general', subcategory: '', title: '', content: '', tags: '', language: 'ka' });
    setIsDialogOpen(true);
  };

  const openEdit = (entry: KBEntry) => {
    setEditEntry(entry);
    setForm({
      category: entry.category,
      subcategory: entry.subcategory || '',
      title: entry.title,
      content: entry.content,
      tags: entry.tags?.join(', ') || '',
      language: entry.language,
    });
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.title.trim() || !form.content.trim()) {
      toast({ title: "შეცდომა", description: "სათაური და კონტენტი სავალდებულოა", variant: "destructive" });
      return;
    }

    const payload = {
      category: form.category,
      subcategory: form.subcategory || null,
      title: form.title.trim(),
      content: form.content.trim(),
      tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
      language: form.language,
    };

    let error;
    if (editEntry) {
      ({ error } = await supabase.from('knowledge_base').update(payload as any).eq('id', editEntry.id));
    } else {
      ({ error } = await supabase.from('knowledge_base').insert(payload as any));
    }

    if (error) {
      toast({ title: "შეცდომა", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "წარმატება", description: editEntry ? "ჩანაწერი განახლდა" : "ჩანაწერი დაემატა" });
      setIsDialogOpen(false);
      fetchEntries();
    }
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('knowledge_base').delete().eq('id', id);
    if (error) {
      toast({ title: "შეცდომა", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "წაიშალა" });
      fetchEntries();
    }
  };

  const getCategoryLabel = (val: string) => CATEGORIES.find(c => c.value === val)?.label || val;

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <BookOpen className="h-8 w-8 text-primary" />
            ცოდნის ბაზა (RAG)
          </h1>
          <p className="text-muted-foreground mt-1">ნინას AI ასისტენტის ცოდნის ბაზის მართვა</p>
        </div>
        <Button onClick={openNew} className="gap-2">
          <Plus className="h-4 w-4" />
          ახალი ჩანაწერი
        </Button>
      </div>

      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="ძებნა..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="კატეგორია" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">ყველა კატეგორია</SelectItem>
            {CATEGORIES.map(c => (
              <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="text-sm text-muted-foreground">
        სულ: {filteredEntries.length} ჩანაწერი
      </div>

      <div className="grid gap-4">
        {isLoading ? (
          <div className="text-center py-12 text-muted-foreground">იტვირთება...</div>
        ) : filteredEntries.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">ჩანაწერები არ მოიძებნა</div>
        ) : (
          filteredEntries.map(entry => (
            <Card key={entry.id} className="group hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="secondary" className="text-xs">{getCategoryLabel(entry.category)}</Badge>
                      {entry.subcategory && <Badge variant="outline" className="text-xs">{entry.subcategory}</Badge>}
                      <Badge variant="outline" className="text-xs">
                        <Globe className="h-3 w-3 mr-1" />
                        {entry.language}
                      </Badge>
                    </div>
                    <h3 className="font-semibold text-foreground">{entry.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{entry.content}</p>
                    {entry.tags?.length > 0 && (
                      <div className="flex gap-1 mt-2 flex-wrap">
                        {entry.tags.map(tag => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            <Tag className="h-3 w-3 mr-1" />{tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(entry)}>
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => handleDelete(entry.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editEntry ? 'ჩანაწერის რედაქტირება' : 'ახალი ჩანაწერი'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>კატეგორია</Label>
                <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(c => (
                      <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>ქვეკატეგორია</Label>
                <Input value={form.subcategory} onChange={e => setForm(f => ({ ...f, subcategory: e.target.value }))} placeholder="არასავალდებულო" />
              </div>
            </div>
            <div>
              <Label>სათაური *</Label>
              <Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="ჩანაწერის სათაური" />
            </div>
            <div>
              <Label>კონტენტი *</Label>
              <Textarea value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} placeholder="დეტალური ინფორმაცია..." rows={8} />
            </div>
            <div>
              <Label>თეგები (მძიმით გამოყოფილი)</Label>
              <Input value={form.tags} onChange={e => setForm(f => ({ ...f, tags: e.target.value }))} placeholder="თეგი1, თეგი2, თეგი3" />
            </div>
            <div>
              <Label>ენა</Label>
              <Select value={form.language} onValueChange={v => setForm(f => ({ ...f, language: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ka">ქართული</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                <X className="h-4 w-4 mr-1" /> გაუქმება
              </Button>
              <Button onClick={handleSave}>
                <Save className="h-4 w-4 mr-1" /> შენახვა
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default KnowledgeBase;
