import { useState, useEffect } from "react";
import { Plus, Search, DollarSign, Download, Play, Check, X, ChevronDown, ChevronUp, CheckCheck, Info, History, Clock, Loader2 } from "lucide-react";
import PreHirePayrollDialog from "@/components/payroll/PreHirePayrollDialog";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { usePersistedState } from "@/hooks/usePersistedState";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { Badge } from "@/components/ui/badge";
import { calculateFullPayroll } from "@/lib/financialCalculations";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Payroll {
  id: string;
  employee_id: string;
  month: number;
  year: number;
  base_salary: number;
  bonuses: number;
  deductions: number;
  net_salary: number;
  gross_salary?: number;
  status: string;
  holiday_overtime_hours?: number;
  overtime_hours?: number;
  notes?: string;
  employees: {
    full_name: string;
    position: string;
  };
}

export default function Payroll() {
  const { user, userRole } = useAuth();
  const { t, language } = useLanguage();
  
  const MONTHS = language === 'ka' ? [
    'იანვარი', 'თებერვალი', 'მარტი', 'აპრილი', 'მაისი', 'ივნისი',
    'ივლისი', 'აგვისტო', 'სექტემბერი', 'ოქტომბერი', 'ნოემბერი', 'დეკემბერი'
  ] : [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  
  const [payrolls, setPayrolls] = useState<Payroll[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = usePersistedState<string>("payroll:search", "");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isApprovingAll, setIsApprovingAll] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [bonusesMap, setBonusesMap] = useState<Map<string, number>>(new Map());
  const [preHireOpen, setPreHireOpen] = useState(false);
  const [rejectTarget, setRejectTarget] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [confirmAction, setConfirmAction] = useState<null | 'process' | 'approve-all'>(null);
  const [approveAllCount, setApproveAllCount] = useState(0);

  const canManage = userRole === 'admin' || userRole === 'hr_manager';
  const activeBranchId = useBranchFilter();

  useEffect(() => {
    fetchPayrolls();
    fetchEmployees();
  }, [selectedMonth, selectedYear, activeBranchId]);

  const fetchEmployees = async () => {
    try {
      let q = supabase
        .from('employees')
        .select('id, full_name, position, salary, is_pension_payer')
        .eq('status', 'active');
      if (activeBranchId) q = q.eq('branch_id', activeBranchId);
      const { data, error } = await q;
      
      if (error) throw error;
      setEmployees(data || []);
    } catch (error: any) {
      console.error('Error fetching employees:', error);
    }
  };

  const fetchPayrolls = async () => {
    setIsFetching(true);
    try {
      // Fetch all employees first
      let empQ = supabase
        .from('employees')
        .select('id, full_name, position, salary, is_pension_payer')
        .eq('status', 'active');
      if (activeBranchId) empQ = empQ.eq('branch_id', activeBranchId);
      const { data: allEmployees, error: empError } = await empQ;

      if (empError) throw empError;

      // Fetch approved bonuses for the selected month/year
      const bonusStartDate = `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`;
      const bonusEndDate = new Date(selectedYear, selectedMonth, 0).toISOString().split('T')[0];
      
      const { data: bonusesData, error: bonusError } = await supabase
        .from('compensation')
        .select('employee_id, amount, type')
        .eq('status', 'approved')
        .eq('type', 'bonus')
        .gte('payment_date', bonusStartDate)
        .lte('payment_date', bonusEndDate);

      if (bonusError) throw bonusError;

      // Create a map of bonuses by employee
      const bonusesMapTemp = new Map<string, number>();
      (bonusesData || []).forEach(bonus => {
        const current = bonusesMapTemp.get(bonus.employee_id) || 0;
        bonusesMapTemp.set(bonus.employee_id, current + bonus.amount);
      });
      
      setBonusesMap(bonusesMapTemp);

      // Fetch public holidays with overtime multipliers
      const { data: holidays, error: holidaysError } = await supabase
        .from('public_holidays')
        .select('holiday_date, is_recurring, overtime_multiplier')
        .eq('is_active', true);

      if (holidaysError) throw holidaysError;

      // Fetch attendance for the selected month to calculate holiday overtime
      const startDate = `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`;
      const endDate = new Date(selectedYear, selectedMonth, 0).toISOString().split('T')[0];

      const { data: attendanceData, error: attError } = await supabase
        .from('attendance')
        .select('employee_id, date, check_in, check_out')
        .gte('date', startDate)
        .lte('date', endDate)
        .not('check_in', 'is', null)
        .not('check_out', 'is', null);

      if (attError) throw attError;

      // Calculate holiday overtime for each employee
      const holidayOvertimeMap = new Map<string, number>();

      attendanceData?.forEach((attendance) => {
        const attendanceDate = attendance.date;
        const matchingHoliday = holidays?.find(holiday => {
          if (holiday.is_recurring) {
            const holidayMonthDay = holiday.holiday_date.substring(5);
            const attendanceMonthDay = attendanceDate.substring(5);
            return holidayMonthDay === attendanceMonthDay;
          }
          return holiday.holiday_date === attendanceDate;
        });

        if (matchingHoliday && attendance.check_in && attendance.check_out) {
          const [inHours, inMinutes] = attendance.check_in.split(':').map(Number);
          const [outHours, outMinutes] = attendance.check_out.split(':').map(Number);
          const totalMinutes = (outHours * 60 + outMinutes) - (inHours * 60 + inMinutes);
          const totalHours = totalMinutes / 60;
          const multiplier = matchingHoliday.overtime_multiplier || 1.5;
          const calculatedHours = totalHours * multiplier;

          const empId = attendance.employee_id;
          holidayOvertimeMap.set(
            empId,
            (holidayOvertimeMap.get(empId) || 0) + calculatedHours
          );
        }
      });

      // Fetch existing payroll records
      let payQ = supabase
        .from('payroll')
        .select('*, employees(full_name, position, is_pension_payer)')
        .eq('month', selectedMonth)
        .eq('year', selectedYear);
      if (activeBranchId) payQ = payQ.eq('branch_id', activeBranchId);
      const { data: existingPayrolls, error: payError } = await payQ;

      if (payError) throw payError;

      // Create a map of employees who already have payroll
      const employeesWithPayroll = new Set(
        (existingPayrolls || []).map(p => p.employee_id)
      );

      // Add "virtual" payroll entries for employees without records
      const virtualPayrolls = (allEmployees || [])
        .filter(emp => !employeesWithPayroll.has(emp.id))
        .map(emp => {
          const holidayOvertimeHours = holidayOvertimeMap.get(emp.id) || 0;
          const baseSalary = emp.salary || 0;
          const approvedBonuses = bonusesMapTemp.get(emp.id) || 0;
          
          // Calculate full payroll breakdown for virtual entries
          const calculation = calculateFullPayroll({
            baseSalary,
            manualBonuses: approvedBonuses,
            manualDeductions: 0,
            overtimeHours: 0,
            holidayOvertimeHours,
            
            hasPension: emp.is_pension_payer || false,
            benefitsDeduction: 0,
          });
          
          return {
            id: `virtual-${emp.id}`,
            employee_id: emp.id,
            month: selectedMonth,
            year: selectedYear,
            base_salary: calculation.baseSalary,
            bonuses: calculation.totalBonuses,
            deductions: calculation.totalDeductions,
            net_salary: calculation.netSalary,
            gross_salary: calculation.grossSalary,
            holiday_overtime_hours: holidayOvertimeHours,
            status: 'not_processed',
            notes: JSON.stringify({
              baseSalary: calculation.baseSalary,
              manualBonuses: approvedBonuses,
              holidayOvertimeHours,
              holidayOvertimeBonus: holidayOvertimeHours * calculation.hourlyRate,
              totalBonuses: calculation.totalBonuses,
              grossSalary: calculation.grossSalary,
              pensionEmployee: calculation.pensionEmployee,
              pensionEmployer: calculation.pensionEmployer,
              incomeTax: calculation.incomeTax,
              benefitsDeduction: calculation.benefitsDeduction,
              otherDeductions: 0,
              totalDeductions: calculation.totalDeductions,
              netSalary: calculation.netSalary,
              hourlyRate: calculation.hourlyRate,
            }),
            employees: {
              full_name: emp.full_name,
              position: emp.position,
            },
          };
        });

      // Add holiday overtime info to existing payrolls
      const enrichedExisting = (existingPayrolls || []).map(payroll => ({
        ...payroll,
        holiday_overtime_hours: holidayOvertimeMap.get(payroll.employee_id) || 0,
      }));

      // Combine existing and virtual payrolls
      setPayrolls([...enrichedExisting, ...virtualPayrolls]);
    } catch (error: any) {
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsFetching(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const baseSalary = parseFloat(formData.get('base_salary') as string);
      const manualBonuses = parseFloat(formData.get('bonuses') as string) || 0;
      const manualDeductions = parseFloat(formData.get('deductions') as string) || 0;
      const employeeId = formData.get('employee_id') as string;
      const month = parseInt(formData.get('month') as string);
      const year = parseInt(formData.get('year') as string);
      
      // Get employee info for pension check
      const employee = employees.find(e => e.id === employeeId);
      const hasPension = employee?.is_pension_payer || false;
      
      // Calculate hourly rate (assuming 160 working hours per month for 40-hour work week)
      const hourlyRate = baseSalary / 160;
      
      // Calculate holiday overtime bonus
      const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
      const endDate = new Date(year, month, 0).toISOString().split('T')[0];

      // Fetch public holidays
      const { data: holidays, error: holidaysError } = await supabase
        .from('public_holidays')
        .select('holiday_date, is_recurring, overtime_multiplier')
        .eq('is_active', true);

      if (holidaysError) throw holidaysError;

      // Fetch attendance for holiday overtime calculation
      const { data: attendanceData, error: attError } = await supabase
        .from('attendance')
        .select('date, check_in, check_out')
        .eq('employee_id', employeeId)
        .gte('date', startDate)
        .lte('date', endDate)
        .not('check_in', 'is', null)
        .not('check_out', 'is', null);

      if (attError) throw attError;

      // Calculate holiday overtime hours
      let holidayOvertimeHours = 0;
      attendanceData?.forEach((attendance) => {
        const attendanceDate = attendance.date;
        const matchingHoliday = holidays?.find(holiday => {
          if (holiday.is_recurring) {
            const holidayMonthDay = holiday.holiday_date.substring(5);
            const attendanceMonthDay = attendanceDate.substring(5);
            return holidayMonthDay === attendanceMonthDay;
          }
          return holiday.holiday_date === attendanceDate;
        });

        if (matchingHoliday && attendance.check_in && attendance.check_out) {
          const [inHours, inMinutes] = attendance.check_in.split(':').map(Number);
          const [outHours, outMinutes] = attendance.check_out.split(':').map(Number);
          const totalMinutes = (outHours * 60 + outMinutes) - (inHours * 60 + inMinutes);
          const totalHours = totalMinutes / 60;
          const multiplier = matchingHoliday.overtime_multiplier || 1.5;
          holidayOvertimeHours += totalHours * multiplier;
        }
      });

      // Fetch employee's active benefits
      const { data: benefitEnrollments, error: benefitsError } = await supabase
        .from('employee_benefit_enrollments')
        .select(`
          benefit_plan_id,
          benefit_plans (
            employee_contribution,
            employer_contribution
          )
        `)
        .eq('employee_id', employeeId)
        .eq('status', 'active');

      if (benefitsError) throw benefitsError;

      // Calculate total benefits deduction (employee contribution only)
      const benefitsDeduction = (benefitEnrollments || []).reduce((sum, enrollment: any) => {
        return sum + (enrollment.benefit_plans?.employee_contribution || 0);
      }, 0);

      // Use centralized calculation function
      const calculation = calculateFullPayroll({
        baseSalary,
        manualBonuses,
        manualDeductions,
        overtimeHours: 0, // regular overtime if needed
        holidayOvertimeHours,
        
        hasPension,
        benefitsDeduction,
      });

      const payload = {
        employee_id: employeeId,
        month,
        year,
        base_salary: calculation.baseSalary,
        bonuses: calculation.totalBonuses,
        deductions: calculation.totalDeductions,
        net_salary: calculation.netSalary,
        gross_salary: calculation.grossSalary,
        status: 'draft',
        created_by: user?.id,
        notes: JSON.stringify({
          baseSalary: calculation.baseSalary,
          manualBonuses,
          holidayOvertimeHours,
          holidayOvertimeBonus: holidayOvertimeHours * calculation.hourlyRate,
          totalBonuses: calculation.totalBonuses,
          grossSalary: calculation.grossSalary,
          pensionEmployee: calculation.pensionEmployee,
          pensionEmployer: calculation.pensionEmployer,
          incomeTax: calculation.incomeTax,
          benefitsDeduction: calculation.benefitsDeduction,
          otherDeductions: manualDeductions,
          totalDeductions: calculation.totalDeductions,
          netSalary: calculation.netSalary,
          hourlyRate: calculation.hourlyRate,
        })
      };

      const { error } = await supabase
        .from('payroll')
        .insert([payload]);

      if (error) throw error;
      toast.success(t('payroll.payrollProcessed'));
      setIsDialogOpen(false);
      fetchPayrolls();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleMarkAsPaid = async (id: string) => {
    try {
      const { error } = await supabase
        .from('payroll')
        .update({
          status: 'paid',
          paid_at: new Date().toISOString(),
        })
        .eq('id', id);

      if (error) throw error;
      toast.success(t('payroll.paid'));
      fetchPayrolls();
    } catch (error: any) {
      toast.error('შეცდომა მოხდა');
    }
  };

  const handleApprovePayroll = async (payrollId: string) => {
    try {
      const { error } = await supabase
        .from('payroll' as any)
        .update({ 
          status: 'approved',
          approved_by: user?.id,
          approved_at: new Date().toISOString()
        })
        .eq('id', payrollId);

      if (error) throw error;
      toast.success('ხელფასი დამტკიცდა');
      fetchPayrolls();
    } catch (error: any) {
      toast.error('დამტკიცება ვერ მოხერხდა');
    }
  };

  const handleRejectPayroll = (payrollId: string) => {
    setRejectTarget(payrollId);
    setRejectReason("");
  };

  const confirmRejectPayroll = async () => {
    if (!rejectTarget || !rejectReason.trim()) return;
    const id = rejectTarget;
    setRejectTarget(null);

    try {
      const { error } = await supabase
        .from('payroll' as any)
        .update({
          status: 'rejected',
          approved_by: user?.id,
          rejection_reason: rejectReason.trim(),
          approved_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;
      toast.success('ხელფასი უარყოფილია');
      fetchPayrolls();
    } catch (error: any) {
      toast.error('ოპერაცია ვერ შესრულდა');
    }
  };

  const handleManualProcessPayroll = () => {
    setConfirmAction('process');
  };

  const confirmManualProcessPayroll = async () => {
    setConfirmAction(null);
    setIsProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('process-monthly-payroll', {
        body: { 
          month: selectedMonth,
          year: selectedYear 
        }
      });

      if (error) throw error;
      
      toast.success(`წარმატებით დამუშავდა ${data.records} ხელფასი`);
      fetchPayrolls();
    } catch (error: any) {
      console.error('Error processing payroll:', error);
      toast.error('ხელფასების დამუშავება ვერ მოხერხდა');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleApproveAll = () => {
    const pendingPayrolls = payrolls.filter(
      p => !p.id.startsWith('virtual-') && (p.status === 'pending' || p.status === 'draft')
    );

    if (pendingPayrolls.length === 0) {
      toast.info('არ არის დასამტკიცებელი ხელფასები');
      return;
    }

    setApproveAllCount(pendingPayrolls.length);
    setConfirmAction('approve-all');
  };

  const confirmApproveAll = async () => {
    setConfirmAction(null);
    const pendingPayrolls = payrolls.filter(
      p => !p.id.startsWith('virtual-') && (p.status === 'pending' || p.status === 'draft')
    );

    setIsApprovingAll(true);
    try {
      const { error } = await supabase
        .from('payroll')
        .update({ 
          status: 'approved',
          approved_by: user?.id,
          approved_at: new Date().toISOString()
        })
        .in('id', pendingPayrolls.map(p => p.id));

      if (error) throw error;
      toast.success(`${pendingPayrolls.length} ხელფასი დამტკიცდა`);
      fetchPayrolls();
    } catch (error: any) {
      toast.error('დამტკიცება ვერ მოხერხდა');
    } finally {
      setIsApprovingAll(false);
    }
  };

  const filteredPayrolls = payrolls.filter((pr) =>
    pr.employees?.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    const colors: {[key: string]: string} = {
      draft: "bg-gray-500",
      pending: "bg-yellow-500",
      approved: "bg-blue-500",
      paid: "bg-green-100 text-green-700",
      rejected: "bg-red-500",
      not_processed: "bg-gray-100 text-gray-700"
    };
    return colors[status] || "bg-gray-500";
  };

  const getStatusText = (status: string) => {
    const texts: {[key: string]: string} = {
      draft: "მონახაზი",
      pending: "განსახილველი",
      approved: "დამტკიცებული",
      paid: t('payroll.paid'),
      rejected: "უარყოფილი",
      not_processed: 'არ არის დამუშავებული'
    };
    return texts[status] || status;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">{t('payroll.title')}</h1>
          <p className="text-muted-foreground mt-1">
            თანამშრომლების ხელფასების მართვა და ავტომატური დამუშავება
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {canManage && (
            <>
              <Button variant="outline" asChild>
                <Link to="/payroll/history">
                  <History className="mr-2 h-4 w-4" />
                  გაშვების ისტორია
                </Link>
              </Button>
              <Button 
                variant="outline"
                onClick={handleManualProcessPayroll}
                disabled={isProcessing}
              >
                {isProcessing ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                    დამუშავება...
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    ხელით დამუშავება
                  </>
                )}
              </Button>
              <Button 
                variant="outline"
                onClick={handleApproveAll}
                disabled={isApprovingAll}
                className="text-green-600 hover:text-green-700 hover:bg-green-50"
              >
                {isApprovingAll ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-green-600 border-t-transparent" />
                    დამტკიცება...
                  </>
                ) : (
                  <>
                    <CheckCheck className="mr-2 h-4 w-4" />
                    ყველას დამტკიცება
                  </>
                )}
              </Button>
              <Button variant="outline" onClick={() => setPreHireOpen(true)}>
                <Clock className="mr-2 h-4 w-4" />
                დანიშვნამდე გამომუშავება
              </Button>
              <PreHirePayrollDialog open={preHireOpen} onOpenChange={setPreHireOpen} onSuccess={fetchPayrolls} />
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                {t('payroll.processPayroll')}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t('payroll.processPayroll')}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="employee_id">{t('attendance.employee')} *</Label>
                  <Select name="employee_id" required>
                    <SelectTrigger>
                      <SelectValue placeholder={t('common.search')} />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.map((emp) => (
                        <SelectItem key={emp.id} value={emp.id}>
                          {emp.full_name} - {emp.salary ? `${emp.salary} ₾` : 'ხელფასი არ არის მითითებული'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="month">{t('payroll.month')} *</Label>
                    <Select name="month" required defaultValue={selectedMonth.toString()}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {MONTHS.map((month, index) => (
                          <SelectItem key={index} value={(index + 1).toString()}>
                            {month}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="year">{t('payroll.year')} *</Label>
                    <Input id="year" name="year" type="number" required defaultValue={selectedYear} />
                  </div>
                </div>
                <div>
                  <Label htmlFor="base_salary">{t('payroll.baseSalary')} *</Label>
                  <Input id="base_salary" name="base_salary" type="number" step="0.01" required placeholder="0.00" />
                </div>
                <div>
                  <Label htmlFor="bonuses">ბონუსები (ხელით შეყვანა)</Label>
                  <Input 
                    id="bonuses" 
                    name="bonuses" 
                    type="number" 
                    step="0.01" 
                    placeholder="მაგ: 500.00" 
                    defaultValue="0" 
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    შეიყვანეთ დამატებითი ბონუსები (შემადგენლობითი, ერთჯერადი და სხვა)
                  </p>
                </div>
                <div>
                  <Label htmlFor="deductions">დამატებითი დაქვითვები (არასავალდებულო)</Label>
                  <Input 
                    id="deductions" 
                    name="deductions" 
                    type="number" 
                    step="0.01" 
                    placeholder="მაგ: 200.00" 
                    defaultValue="0" 
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    <strong>საპენსიო ფონდი (2%) ავტომატურად დაითვლება.</strong><br />
                    აქ მხოლოდ დამატებითი დაქვითვები (სესხის დაფარვა, სადაზღვევო და სხვა)
                  </p>
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? t('common.loading') : t('common.add')}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
            </>
          )}
        </div>
      </div>

      {/* Salary Calculation Info */}
      <Card className="border-border/50 bg-muted/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-primary mt-0.5 shrink-0" />
            <div className="space-y-1 text-sm text-muted-foreground">
              <p className="font-medium text-foreground">როგორ ითვლება ხელფასი?</p>
              <p>
                <strong>1.</strong> ძირითადი ხელფასი + ბონუსები + ზეგანაკვეთური = <strong>მთლიანი შემოსავალი (Gross)</strong>
              </p>
              <p>
                <strong>2.</strong> ზეგანაკვეთური: სტანდარტული - <strong>×1.5</strong>, უქმე დღეები - <strong>×2.0</strong> (საათობრივი = ხელფასი ÷ 160)
              </p>
              <p>
                <strong>3.</strong> გამოქვითვები: საპენსიო - <strong>2%</strong> (Gross-იდან), საშემოსავლო გადასახადი - <strong>20%</strong>
              </p>
              <p>
                <strong>4.</strong> წმინდა ხელფასი (Net) = Gross − პენსია − გადასახადი − სხვა გამოქვითვები
              </p>
              <p className="font-medium text-foreground pt-2">ღილაკების ფუნქციები:</p>
              <p>
                <strong>დამუშავება</strong> - ავტომატურად ითვლის ყველა თანამშრომლის ხელფასს არჩეული თვისთვის
              </p>
              <p>
                <strong>დამტკიცება</strong> - ადასტურებს გამოთვლილ ხელფასს და ამზადებს გადახდისთვის
              </p>
              <p>
                <strong>უარყოფა</strong> - უარყოფს ხელფასის ჩანაწერს, თუ საჭიროა ხელახალი გადათვლა ან შესწორება
              </p>
              <p>
                <strong>გადახდილია</strong> - აღნიშნავს რომ ხელფასი უკვე გადარიცხულია თანამშრომელზე
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder={t('common.search')}
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={selectedMonth.toString()} onValueChange={(v) => setSelectedMonth(parseInt(v))}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {MONTHS.map((month, index) => (
              <SelectItem key={index} value={(index + 1).toString()}>
                {month}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Input
          type="number"
          value={selectedYear}
          onChange={(e) => setSelectedYear(parseInt(e.target.value))}
          className="w-24"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('payroll.title')} - {MONTHS[selectedMonth - 1]} {selectedYear}</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('attendance.employee')}</TableHead>
                <TableHead>{t('employees.position')}</TableHead>
                <TableHead className="text-right">{t('payroll.baseSalary')}</TableHead>
                <TableHead className="text-right">ზეგანაკვეთი</TableHead>
                <TableHead className="text-right">პენსია (2%)</TableHead>
                <TableHead className="text-right">საშემოსავლო (20%)</TableHead>
                <TableHead className="text-right">სხვა დაქვითვები</TableHead>
                <TableHead className="text-right">მთლიანი</TableHead>
                <TableHead className="text-right font-bold">{t('payroll.netSalary')}</TableHead>
                <TableHead>{t('payroll.paymentStatus')}</TableHead>
                {canManage && <TableHead className="text-right">მოქმედებები</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPayrolls.map((pr) => {
                let breakdown: any;
                try {
                  const parsed = pr.notes ? JSON.parse(pr.notes) : null;
                  // Only use parsed notes as breakdown if it has the full payroll shape
                  breakdown = parsed && typeof parsed.grossSalary === 'number' ? parsed : null;
                  
                  // Add approved bonuses from compensation table
                  if (breakdown) {
                    const approvedBonuses = bonusesMap.get(pr.employee_id) || 0;
                    if (approvedBonuses > 0) {
                      // Recalculate with approved bonuses
                      const totalManualBonuses = (breakdown.manualBonuses || 0) + approvedBonuses;
                      
                      const calc = calculateFullPayroll({
                        baseSalary: pr.base_salary,
                        manualBonuses: totalManualBonuses,
                        manualDeductions: pr.deductions,
                        overtimeHours: pr.overtime_hours || 0,
                        holidayOvertimeHours: pr.holiday_overtime_hours || 0,
                        
                        hasPension: (pr.employees as any)?.is_pension_payer || false,
                        benefitsDeduction: 0,
                      });
                      
                      breakdown = {
                        ...breakdown,
                        manualBonuses: totalManualBonuses,
                        totalBonuses: calc.totalBonuses,
                        grossSalary: calc.grossSalary,
                        pensionEmployee: calc.pensionEmployee,
                        pensionEmployer: calc.pensionEmployer,
                        incomeTax: calc.incomeTax,
                        totalDeductions: calc.totalDeductions,
                        netSalary: calc.netSalary,
                      };
                    }
                  }
                } catch {
                  breakdown = null;
                }

                // If no breakdown exists, calculate it on the fly
                if (!breakdown) {
                  const approvedBonuses = bonusesMap.get(pr.employee_id) || 0;
                  const totalManualBonuses = pr.bonuses + approvedBonuses;
                  
                  const calc = calculateFullPayroll({
                    baseSalary: pr.base_salary,
                    manualBonuses: totalManualBonuses,
                    manualDeductions: pr.deductions,
                    overtimeHours: pr.overtime_hours || 0,
                    holidayOvertimeHours: pr.holiday_overtime_hours || 0,
                    
                    hasPension: (pr.employees as any)?.is_pension_payer || false,
                    benefitsDeduction: 0,
                  });
                  
                  breakdown = {
                    baseSalary: calc.baseSalary,
                    manualBonuses: totalManualBonuses,
                    holidayOvertimeHours: pr.holiday_overtime_hours || 0,
                    holidayOvertimeBonus: (pr.holiday_overtime_hours || 0) * calc.hourlyRate,
                    totalBonuses: calc.totalBonuses,
                    grossSalary: calc.grossSalary,
                    pensionEmployee: calc.pensionEmployee,
                    pensionEmployer: calc.pensionEmployer,
                    incomeTax: calc.incomeTax,
                    benefitsDeduction: calc.benefitsDeduction,
                    otherDeductions: pr.deductions,
                    totalDeductions: calc.totalDeductions,
                    netSalary: calc.netSalary,
                    hourlyRate: calc.hourlyRate,
                  };
                }

                const baseSalary = breakdown.baseSalary;
                const bonuses = breakdown.totalBonuses;
                const grossSalary = breakdown.grossSalary;
                const pensionEmployee = breakdown.pensionEmployee;
                const incomeTax = breakdown.incomeTax;
                const benefitsDeduction = breakdown.benefitsDeduction;
                const otherDeductions = breakdown.otherDeductions;
                const totalDeductions = breakdown.totalDeductions;
                const netSalary = breakdown.netSalary;
                
                const isExpanded = expandedRows.has(pr.id);
                
                return (
                  <>
                    <TableRow key={pr.id} className="cursor-pointer hover:bg-muted/50" onClick={() => {
                      const newExpanded = new Set(expandedRows);
                      if (isExpanded) {
                        newExpanded.delete(pr.id);
                      } else {
                        newExpanded.add(pr.id);
                      }
                      setExpandedRows(newExpanded);
                    }}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          {pr.employees?.full_name}
                          {(pr as any).is_retroactive && (
                            <Badge variant="outline" className="ml-1 text-amber-700 border-amber-400">რეტროაქტიური</Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{pr.employees?.position}</TableCell>
                      <TableCell className="text-right">{baseSalary.toFixed(2)} ₾</TableCell>
                      <TableCell className="text-right text-green-600">
                        {bonuses > 0 ? `+${bonuses.toFixed(2)} ₾` : '-'}
                      </TableCell>
                      <TableCell className="text-right text-orange-600">
                        -{pensionEmployee.toFixed(2)} ₾
                      </TableCell>
                      <TableCell className="text-right text-purple-600">
                        -{incomeTax.toFixed(2)} ₾
                      </TableCell>
                      <TableCell className="text-right text-red-600">
                        {otherDeductions > 0 ? `-${otherDeductions.toFixed(2)} ₾` : '-'}
                      </TableCell>
                      <TableCell className="text-right font-semibold text-blue-600">{grossSalary.toFixed(2)} ₾</TableCell>
                      <TableCell className="text-right font-bold text-lg text-primary">{netSalary.toFixed(2)} ₾</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(pr.status)}>
                          {getStatusText(pr.status)}
                        </Badge>
                      </TableCell>
                      {canManage && (
                        <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex justify-end gap-2">
                            {pr.status === 'pending' && (
                              <>
                                <Button
                                  size="sm"
                                  variant="default"
                                  onClick={() => handleApprovePayroll(pr.id)}
                                >
                                  <Check className="mr-1 h-3 w-3" />
                                  დამტკიცება
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => handleRejectPayroll(pr.id)}
                                >
                                  <X className="mr-1 h-3 w-3" />
                                  უარყოფა
                                </Button>
                              </>
                            )}
                            {pr.status === 'approved' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleMarkAsPaid(pr.id)}
                              >
                                <DollarSign className="mr-1 h-3 w-3" />
                                {t('payroll.markPaid')}
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                    {isExpanded && breakdown && (
                      <TableRow key={`${pr.id}-details`}>
                        <TableCell colSpan={canManage ? 11 : 10} className="bg-muted/30 p-4">
                          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">ძირითადი ხელფასი</p>
                              <p className="font-semibold">{breakdown.baseSalary?.toFixed(2)} ₾</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">ხელით დამატებული ბონუსი</p>
                              <p className="font-semibold text-green-600">+{breakdown.manualBonuses?.toFixed(2) || 0} ₾</p>
                            </div>
                            {breakdown.holidayOvertimeHours > 0 && (
                              <div className="space-y-1">
                                <p className="text-xs text-muted-foreground">დღესასწაულის ზეგანაკვეთი</p>
                                <p className="font-semibold text-green-600">
                                  +{breakdown.holidayOvertimeBonus?.toFixed(2)} ₾
                                  <span className="text-xs ml-1">({breakdown.holidayOvertimeHours?.toFixed(1)}ს)</span>
                                </p>
                              </div>
                            )}
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">მთლიანი შემოსავალი</p>
                              <p className="font-semibold text-blue-600">{breakdown.grossSalary?.toFixed(2)} ₾</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">პენსია (თანამშრომელი)</p>
                              <p className="font-semibold text-orange-600">-{breakdown.pensionEmployee?.toFixed(2)} ₾ (2%)</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">პენსია (დამსაქმებელი)</p>
                              <p className="font-semibold text-orange-400">{breakdown.pensionEmployer?.toFixed(2)} ₾ (2%)</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">საშემოსავლო გადასახადი</p>
                              <p className="font-semibold text-purple-600">-{breakdown.incomeTax?.toFixed(2)} ₾ (20%)</p>
                            </div>
                            {breakdown.benefitsDeduction > 0 && (
                              <div className="space-y-1">
                                <p className="text-xs text-muted-foreground">სარგებლების დაკავება</p>
                                <p className="font-semibold text-red-600">-{breakdown.benefitsDeduction?.toFixed(2)} ₾</p>
                              </div>
                            )}
                            {breakdown.otherDeductions > 0 && (
                              <div className="space-y-1">
                                <p className="text-xs text-muted-foreground">სხვა დაქვითვები</p>
                                <p className="font-semibold text-red-600">-{breakdown.otherDeductions?.toFixed(2)} ₾</p>
                              </div>
                            )}
                            <div className="space-y-1">
                              <p className="text-xs text-muted-foreground">საათობრივი განაკვეთი</p>
                              <p className="font-semibold">{breakdown.hourlyRate?.toFixed(2)} ₾/ს</p>
                            </div>
                            <div className="space-y-1 col-span-2">
                              <p className="text-xs text-muted-foreground">წმინდა ხელფასი</p>
                              <p className="text-xl font-bold text-primary">{breakdown.netSalary?.toFixed(2)} ₾</p>
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </>
                );
              })}
            </TableBody>
          </Table>
          {isFetching ? (
            <div className="flex h-32 items-center justify-center text-muted-foreground">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : filteredPayrolls.length === 0 && (
            <div className="flex h-32 items-center justify-center text-muted-foreground">
              {t('payroll.noPayrollData')}
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={confirmAction !== null} onOpenChange={(open) => { if (!open) setConfirmAction(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirmAction === 'process'
                ? `დარწმუნებული ხართ რომ გსურთ ${MONTHS[selectedMonth - 1]} ${selectedYear} თვის ხელფასების დამუშავება?`
                : `დარწმუნებული ხართ რომ გსურთ ${approveAllCount} ხელფასის დამტკიცება?`}
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-2 text-sm text-muted-foreground">
                {(() => {
                  const list = confirmAction === 'approve-all'
                    ? payrolls.filter(p => !p.id.startsWith('virtual-') && (p.status === 'pending' || p.status === 'draft'))
                    : payrolls;
                  const total = list.reduce((s, p) => s + (Number(p.net_salary) || 0), 0);
                  return (
                    <div className="grid grid-cols-3 gap-2 rounded-md border border-border p-3 text-foreground">
                      <div><div className="text-xs text-muted-foreground">პერიოდი</div><div className="font-medium">{MONTHS[selectedMonth - 1]} {selectedYear}</div></div>
                      <div><div className="text-xs text-muted-foreground">მიმღებები</div><div className="font-medium">{list.length}</div></div>
                      <div><div className="text-xs text-muted-foreground">ხელზე ჯამი</div><div className="font-medium">{total.toLocaleString('ka-GE', { maximumFractionDigits: 2 })} ₾</div></div>
                    </div>
                  );
                })()}
                <p>ეს მოქმედება ცვლის ხელფასების სტატუსს.</p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>გაუქმება</AlertDialogCancel>
            <AlertDialogAction onClick={confirmAction === 'process' ? confirmManualProcessPayroll : confirmApproveAll}>
              დადასტურება
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={rejectTarget !== null} onOpenChange={(open) => { if (!open) setRejectTarget(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>ხელფასის უარყოფა</AlertDialogTitle>
            <AlertDialogDescription>მიუთითეთ უარყოფის მიზეზი.</AlertDialogDescription>
          </AlertDialogHeader>
          <Textarea
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            placeholder="უარყოფის მიზეზი"
            rows={3}
          />
          <AlertDialogFooter>
            <AlertDialogCancel>გაუქმება</AlertDialogCancel>
            <AlertDialogAction onClick={confirmRejectPayroll} disabled={!rejectReason.trim()}>
              უარყოფა
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}