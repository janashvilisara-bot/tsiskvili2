import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { Building2, Plus, LayoutGrid, Network, Search, Filter, AlertTriangle, BarChart3, Grid3x3, List } from "lucide-react";
import { OrganizationChart } from "@/components/org-structure/OrganizationChart";
import { DepartmentCard } from "@/components/org-structure/DepartmentCard";
import { PositionCard } from "@/components/org-structure/PositionCard";
import { ExportMenu } from "@/components/org-structure/ExportMenu";
import { DisciplinaryActionCard } from "@/components/org-structure/DisciplinaryActionCard";
import { DepartmentAnalytics } from "@/components/org-structure/DepartmentAnalytics";
import { DepartmentTrends } from "@/components/org-structure/DepartmentTrends";
import { AddDepartmentDialog } from "@/components/org-structure/AddDepartmentDialog";
import { AddPositionDialog } from "@/components/org-structure/AddPositionDialog";
import { EditDepartmentDialog } from "@/components/org-structure/EditDepartmentDialog";
import { EditPositionDialog } from "@/components/org-structure/EditPositionDialog";
import { DeleteConfirmDialog } from "@/components/org-structure/DeleteConfirmDialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";


interface Manager {
  full_name: string;
  avatar_url: string | null;
}

interface Department {
  id: string;
  name: string;
  name_en: string | null;
  parent_department_id: string | null;
  manager_id: string | null;
  budget: number | null;
  headcount_limit: number | null;
  description: string | null;
  is_active: boolean;
  manager?: Manager;
  employee_count?: number;
}

interface Position {
  id: string;
  title: string;
  department_id: string | null;
  level: string | null;
  min_salary: number | null;
  max_salary: number | null;
  required_skills: string[] | null;
  responsibilities: string | null;
  headcount: number;
  filled_count: number;
  is_active: boolean;
  department?: { name: string };
}

interface BudgetPlan {
  id: string;
  department_id: string | null;
  fiscal_year: number;
  fiscal_quarter: number | null;
  fiscal_month: number | null;
  category: string;
  planned_amount: number;
  actual_amount: number;
  variance: number | null;
  notes: string | null;
  department?: { name: string };
}

interface DisciplinaryAction {
  id: string;
  employee_id: string;
  action_type: string;
  reason: string;
  description: string | null;
  issued_by: string | null;
  issued_date: string;
  status: string;
  severity: string;
  follow_up_date: string | null;
  follow_up_notes: string | null;
  employee?: { full_name: string; avatar_url: string | null };
  issuer?: { full_name: string; avatar_url: string | null };
}

const OrganizationalStructure = () => {
  const { userRole } = useAuth();
  const navigate = useNavigate();
  const [departments, setDepartments] = useState<Department[]>([]);
  const [positions, setPositions] = useState<Position[]>([]);
  const [budgets, setBudgets] = useState<BudgetPlan[]>([]);
  const [disciplinaryActions, setDisciplinaryActions] = useState<DisciplinaryAction[]>([]);
  const [employees, setEmployees] = useState<{ id: string; full_name: string }[]>([]);
  const [viewMode, setViewMode] = useState<'chart' | 'grid' | 'list'>('chart');
  const [departmentViewSize, setDepartmentViewSize] = useState<'large' | 'small'>('large');
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [levelFilter, setLevelFilter] = useState<string>('all');
  const [addDepartmentOpen, setAddDepartmentOpen] = useState(false);
  const [addPositionOpen, setAddPositionOpen] = useState(false);
  const [editDepartmentOpen, setEditDepartmentOpen] = useState(false);
  const [editPositionOpen, setEditPositionOpen] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState<Department | null>(null);
  const [selectedPosition, setSelectedPosition] = useState<Position | null>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<{ type: 'department' | 'position'; id: string; name: string } | null>(null);
  const [analyticsData, setAnalyticsData] = useState<any[]>([]);

  const canManage = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    fetchDepartments();
    fetchPositions();
    fetchBudgets();
    fetchDisciplinaryActions();
    fetchEmployees();
    fetchAnalyticsData();
  }, []);

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from('employees')
        .select('id, full_name')
        .eq('status', 'active')
        .order('full_name');
      
      if (error) throw error;
      setEmployees(data || []);
    } catch (error: any) {
      console.error('Error fetching employees:', error);
    }
  };

  // Realtime subscriptions
  useEffect(() => {
    const departmentsChannel = supabase
      .channel('departments-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'departments' }, () => {
        fetchDepartments();
      })
      .subscribe();

    const positionsChannel = supabase
      .channel('positions-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'positions' }, () => {
        fetchPositions();
      })
      .subscribe();

    const budgetsChannel = supabase
      .channel('budgets-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'budget_plans' }, () => {
        fetchBudgets();
      })
      .subscribe();

    const disciplinaryChannel = supabase
      .channel('disciplinary-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'disciplinary_actions' }, () => {
        fetchDisciplinaryActions();
      })
      .subscribe();

    const employeesChannel = supabase
      .channel('employees-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'employees' }, () => {
        fetchDepartments();
        fetchAnalyticsData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(departmentsChannel);
      supabase.removeChannel(positionsChannel);
      supabase.removeChannel(budgetsChannel);
      supabase.removeChannel(disciplinaryChannel);
      supabase.removeChannel(employeesChannel);
    };
  }, []);

  const fetchDepartments = async () => {
    try {
      const response = await supabase
        .from('departments')
        .select(`
          *,
          manager:employees!manager_id(full_name, avatar_url)
        `)
        .order('name');
      
      if (response.error) throw response.error;
      
      const rawData: any[] = response.data || [];
      const { data: empRows } = await supabase
        .from('employees')
        .select('department')
        .eq('status', 'active');
      const counts: Record<string, number> = {};
      (empRows || []).forEach((e: any) => {
        const key = (e.department || '').trim().toLowerCase();
        if (key) counts[key] = (counts[key] || 0) + 1;
      });
      setDepartments(rawData.map(dept => ({
        ...dept,
        employee_count: counts[(dept.name || '').trim().toLowerCase()] || 0
      })));
      
      // Trigger analytics data fetch after departments are loaded
      fetchAnalyticsData();
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const fetchAnalyticsData = async () => {
    try {
      const { data: depts, error: deptsError } = await supabase
        .from('departments')
        .select('id, name, budget, manager:employees!manager_id(full_name, avatar_url)')
        .eq('is_active', true);

      if (deptsError) throw deptsError;

      const analyticsPromises = (depts || []).map(async (dept: any) => {
        // Get employee count
        const { count: empCount } = await supabase
          .from('employees')
          .select('*', { count: 'exact', head: true })
          .eq('department', dept.name)
          .eq('status', 'active');

        // Get salary data
        const { data: salaryData } = await supabase
          .from('employees')
          .select('salary')
          .eq('department', dept.name)
          .eq('status', 'active')
          .not('salary', 'is', null);

        const totalSalaries = salaryData?.reduce((sum, e) => sum + (e.salary || 0), 0) || 0;
        const avgSalary = salaryData && salaryData.length > 0 ? totalSalaries / salaryData.length : 0;

        return {
          id: dept.id,
          name: dept.name,
          budget: dept.budget || 0,
          employee_count: empCount || 0,
          avg_salary: avgSalary,
          total_salaries: totalSalaries,
          manager: dept.manager,
        };
      });

      const analytics = await Promise.all(analyticsPromises);
      setAnalyticsData(analytics);
    } catch (error: any) {
      console.error('Error fetching analytics:', error);
    }
  };

  const fetchPositions = async () => {
    try {
      const response = await supabase
        .from('positions')
        .select(`
          *,
          department:departments(name)
        `)
        .order('title');
      
      if (response.error) throw response.error;
      setPositions((response.data as any) || []);
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const fetchBudgets = async () => {
    try {
      const response = await supabase
        .from('budget_plans')
        .select(`
          *,
          department:departments(name)
        `)
        .order('fiscal_year', { ascending: false });
      
      if (response.error) throw response.error;
      setBudgets((response.data as any) || []);
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const fetchDisciplinaryActions = async () => {
    try {
      const response = await supabase
        .from('disciplinary_actions')
        .select(`
          *,
          employee:employees!employee_id(full_name, avatar_url),
          issuer:employees!issued_by(full_name, avatar_url)
        `)
        .order('issued_date', { ascending: false });
      
      if (response.error) throw response.error;
      setDisciplinaryActions((response.data as any) || []);
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const handleToggleDepartmentStatus = async (dept: Department) => {
    try {
      const { error } = await supabase
        .from('departments')
        .update({ is_active: !dept.is_active })
        .eq('id', dept.id);

      if (error) throw error;
      toast.success(dept.is_active ? 'დეპარტამენტი გამორთულია' : 'დეპარტამენტი ჩართულია');
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const handleTogglePositionStatus = async (pos: Position) => {
    try {
      const { error } = await supabase
        .from('positions')
        .update({ is_active: !pos.is_active })
        .eq('id', pos.id);

      if (error) throw error;
      toast.success(pos.is_active ? 'პოზიცია გამორთულია' : 'პოზიცია ჩართულია');
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const handleEditDepartment = (dept: Department) => {
    setSelectedDepartment(dept);
    setEditDepartmentOpen(true);
  };

  const handleEditPosition = (pos: Position) => {
    setSelectedPosition(pos);
    setEditPositionOpen(true);
  };

  const handleDeleteDepartment = (deptId: string, deptName: string) => {
    setDeleteTarget({ type: 'department', id: deptId, name: deptName });
    setDeleteConfirmOpen(true);
  };

  const handleDeletePosition = (posId: string, posTitle: string) => {
    setDeleteTarget({ type: 'position', id: posId, name: posTitle });
    setDeleteConfirmOpen(true);
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;

    try {
      const table = deleteTarget.type === 'department' ? 'departments' : 'positions';
      const { error } = await supabase
        .from(table)
        .delete()
        .eq('id', deleteTarget.id);

      if (error) throw error;

      toast.success(
        deleteTarget.type === 'department' 
          ? 'დეპარტამენტი წარმატებით წაიშალა' 
          : 'პოზიცია წარმატებით წაიშალა'
      );

      if (deleteTarget.type === 'department') {
        fetchDepartments();
      } else {
        fetchPositions();
      }
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    } finally {
      setDeleteConfirmOpen(false);
      setDeleteTarget(null);
    }
  };

  if (!canManage) {
    return (
      <div className="p-8 text-center">
        <p className="text-muted-foreground">თქვენ არ გაქვთ წვდომა ამ გვერდზე</p>
      </div>
    );
  }

  // Filtered data
  const filteredDepartments = departments.filter(dept =>
    dept.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dept.name_en?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredPositions = positions.filter(pos => {
    const matchesSearch = pos.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment = departmentFilter === 'all' || pos.department_id === departmentFilter;
    const matchesLevel = levelFilter === 'all' || pos.level === levelFilter;
    return matchesSearch && matchesDepartment && matchesLevel;
  });

  const filteredBudgets = budgets.filter(budget =>
    budget.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    budget.department?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredDisciplinary = disciplinaryActions.filter(action =>
    action.reason.toLowerCase().includes(searchTerm.toLowerCase()) ||
    action.employee?.full_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Stats
  const totalDepartments = departments.length;
  const activeDepartments = departments.filter(d => d.is_active).length;
  const totalPositions = positions.reduce((sum, pos) => sum + pos.headcount, 0);
  const filledPositions = positions.reduce((sum, pos) => sum + pos.filled_count, 0);
  const totalBudget = departments.reduce((sum, dept) => sum + (dept.budget || 0), 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="p-8 space-y-8">
        {/* Header with Gradient */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-background border border-primary/20 backdrop-blur-sm">
          <div className="absolute inset-0 bg-grid-white/5 [mask-image:linear-gradient(0deg,transparent,black)]" />
          <div className="relative p-8">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-xl bg-primary/10 backdrop-blur-sm border border-primary/20">
                    <Building2 className="h-8 w-8 text-primary" />
                  </div>
                  <div>
                    <h1 className="text-4xl font-bold bg-gradient-to-br from-foreground to-foreground/70 bg-clip-text text-transparent">
                      ორგანიზაციული სტრუქტურა
                    </h1>
                    <p className="text-muted-foreground mt-1">დეპარტამენტების, პოზიციების და ბიუჯეტების მართვა</p>
                  </div>
                </div>
              </div>
              <div className="flex gap-3">
                <ExportMenu data={filteredDepartments} filename="departments" type="departments" />
                {canManage && (
                  <>
                    <Button 
                      onClick={() => setAddDepartmentOpen(true)} 
                      className="gap-2 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 shadow-lg shadow-blue-500/20"
                    >
                      <Plus className="h-4 w-4" />
                      დეპარტამენტი
                    </Button>
                    <Button 
                      onClick={() => setAddPositionOpen(true)} 
                      className="gap-2 bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 shadow-lg shadow-purple-500/20"
                    >
                      <Plus className="h-4 w-4" />
                      პოზიცია
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Modern Stats Cards with Glassmorphism */}
        <div className="grid gap-4 md:grid-cols-5">
          <Card className="relative overflow-hidden border-blue-500/20 bg-gradient-to-br from-blue-500/10 via-blue-500/5 to-background backdrop-blur-sm hover:shadow-lg hover:shadow-blue-500/10 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent opacity-0 hover:opacity-100 transition-opacity" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">დეპარტამენტები</CardTitle>
              <div className="p-2 rounded-lg bg-blue-500/10 backdrop-blur-sm">
                <Building2 className="h-4 w-4 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-br from-blue-600 to-blue-400 bg-clip-text text-transparent">
                {totalDepartments}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {activeDepartments} აქტიური
              </p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden border-purple-500/20 bg-gradient-to-br from-purple-500/10 via-purple-500/5 to-background backdrop-blur-sm hover:shadow-lg hover:shadow-purple-500/10 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-transparent opacity-0 hover:opacity-100 transition-opacity" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">პოზიციები</CardTitle>
              <div className="p-2 rounded-lg bg-purple-500/10 backdrop-blur-sm">
                <LayoutGrid className="h-4 w-4 text-purple-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-br from-purple-600 to-purple-400 bg-clip-text text-transparent">
                {totalPositions}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {filledPositions} დაკავებული
              </p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden border-green-500/20 bg-gradient-to-br from-green-500/10 via-green-500/5 to-background backdrop-blur-sm hover:shadow-lg hover:shadow-green-500/10 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-transparent opacity-0 hover:opacity-100 transition-opacity" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">ბიუჯეტი</CardTitle>
              <div className="p-2 rounded-lg bg-green-500/10 backdrop-blur-sm">
                <BarChart3 className="h-4 w-4 text-green-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-br from-green-600 to-green-400 bg-clip-text text-transparent">
                {totalBudget.toLocaleString()} ₾
              </div>
              <p className="text-xs text-muted-foreground mt-1">სულ ბიუჯეტი</p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden border-orange-500/20 bg-gradient-to-br from-orange-500/10 via-orange-500/5 to-background backdrop-blur-sm hover:shadow-lg hover:shadow-orange-500/10 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500/10 to-transparent opacity-0 hover:opacity-100 transition-opacity" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">დისციპლინარული</CardTitle>
              <div className="p-2 rounded-lg bg-orange-500/10 backdrop-blur-sm">
                <AlertTriangle className="h-4 w-4 text-orange-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-br from-orange-600 to-orange-400 bg-clip-text text-transparent">
                {disciplinaryActions.length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">აქტიური შემთხვევები</p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden border-primary/20 bg-gradient-to-br from-primary/10 via-primary/5 to-background backdrop-blur-sm hover:shadow-lg hover:shadow-primary/10 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 hover:opacity-100 transition-opacity" />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">ანალიტიკა</CardTitle>
              <div className="p-2 rounded-lg bg-primary/10 backdrop-blur-sm">
                <Network className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-br from-primary to-primary/70 bg-clip-text text-transparent">
                {analyticsData.length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">დეპარტამენტი</p>
            </CardContent>
          </Card>
        </div>

        {/* Modern Tabs with Glassmorphism */}
        <Tabs defaultValue="departments" className="space-y-6">
          <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg border-b pb-4">
            <TabsList className="bg-muted/50 backdrop-blur-sm p-1 h-auto rounded-xl">
              <TabsTrigger 
                value="departments" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-blue-500 data-[state=active]:text-white rounded-lg px-6 py-2.5 transition-all"
              >
                <Building2 className="h-4 w-4 mr-2" />
                დეპარტამენტები
              </TabsTrigger>
              <TabsTrigger 
                value="positions" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-purple-500 data-[state=active]:text-white rounded-lg px-6 py-2.5 transition-all"
              >
                <LayoutGrid className="h-4 w-4 mr-2" />
                პოზიციები
              </TabsTrigger>
              <TabsTrigger 
                value="budgets" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-600 data-[state=active]:to-green-500 data-[state=active]:text-white rounded-lg px-6 py-2.5 transition-all"
              >
                <BarChart3 className="h-4 w-4 mr-2" />
                ბიუჯეტები
              </TabsTrigger>
              <TabsTrigger 
                value="disciplinary" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-600 data-[state=active]:to-orange-500 data-[state=active]:text-white rounded-lg px-6 py-2.5 transition-all"
              >
                <AlertTriangle className="h-4 w-4 mr-2" />
                დისციპლინარული
              </TabsTrigger>
              <TabsTrigger 
                value="analytics" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-primary/80 data-[state=active]:text-white rounded-lg px-6 py-2.5 transition-all"
              >
                <Network className="h-4 w-4 mr-2" />
                ანალიტიკა
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Departments Tab */}
          <TabsContent value="departments" className="space-y-6 animate-fade-in">
            <Card className="border-blue-500/20 bg-gradient-to-br from-blue-500/5 to-background backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="ძებნა დეპარტამენტების სახელით..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9 bg-background/50 backdrop-blur-sm border-blue-500/20 focus:border-blue-500/40"
                    />
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant={viewMode === 'chart' ? 'default' : 'outline'}
                      size="icon"
                      onClick={() => setViewMode('chart')}
                      className={viewMode === 'chart' ? 'bg-gradient-to-r from-blue-600 to-blue-500 shadow-lg shadow-blue-500/20' : ''}
                    >
                      <Network className="h-4 w-4" />
                    </Button>
                    <Button
                      variant={viewMode === 'grid' ? 'default' : 'outline'}
                      size="icon"
                      onClick={() => setViewMode('grid')}
                      className={viewMode === 'grid' ? 'bg-gradient-to-r from-blue-600 to-blue-500 shadow-lg shadow-blue-500/20' : ''}
                    >
                      <Grid3x3 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant={viewMode === 'list' ? 'default' : 'outline'}
                      size="icon"
                      onClick={() => setViewMode('list')}
                      className={viewMode === 'list' ? 'bg-gradient-to-r from-blue-600 to-blue-500 shadow-lg shadow-blue-500/20' : ''}
                    >
                      <List className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

          {viewMode === 'chart' && (
            <OrganizationChart
              departments={filteredDepartments}
              onDepartmentClick={(dept) => navigate(`/department/${dept.id}`)}
            />
          )}

            {viewMode === 'grid' && (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 animate-fade-in">
                {filteredDepartments.map((dept, index) => (
                  <div 
                    key={dept.id} 
                    className="animate-fade-in"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <DepartmentCard
                      department={dept}
                      onEdit={() => handleEditDepartment(dept)}
                      onDelete={() => handleDeleteDepartment(dept.id, dept.name)}
                      onToggleStatus={() => handleToggleDepartmentStatus(dept)}
                      canManage={canManage}
                      compact={false}
                    />
                  </div>
                ))}
              </div>
            )}

            {viewMode === 'list' && (
              <div className="space-y-3 animate-fade-in">
                {filteredDepartments.map((dept, index) => (
                  <Card 
                    key={dept.id} 
                    className="p-4 hover:shadow-lg hover:shadow-blue-500/10 cursor-pointer transition-all duration-300 border-blue-500/20 bg-gradient-to-r from-blue-500/5 to-background backdrop-blur-sm animate-fade-in" 
                    onClick={() => navigate(`/department/${dept.id}`)}
                    style={{ animationDelay: `${index * 30}ms` }}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="p-3 rounded-xl bg-blue-500/10 backdrop-blur-sm">
                          <Building2 className="h-8 w-8 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg">{dept.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {dept.manager ? dept.manager.full_name : 'მენეჯერი არ არის'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-sm font-bold bg-gradient-to-br from-green-600 to-green-400 bg-clip-text text-transparent">
                            {dept.budget?.toLocaleString()} ₾
                          </p>
                          <p className="text-xs text-muted-foreground">ბიუჯეტი</p>
                        </div>
                        <Badge variant={dept.is_active ? 'default' : 'secondary'} className={dept.is_active ? 'bg-gradient-to-r from-green-600 to-green-500' : ''}>
                          {dept.is_active ? 'აქტიური' : 'გამორთული'}
                        </Badge>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Positions Tab */}
          <TabsContent value="positions" className="space-y-6 animate-fade-in">
            <Card className="border-purple-500/20 bg-gradient-to-br from-purple-500/5 to-background backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="ძებნა პოზიციების სახელით..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9 bg-background/50 backdrop-blur-sm border-purple-500/20 focus:border-purple-500/40"
                    />
                  </div>
                  <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                    <SelectTrigger className="w-[200px] bg-background/50 backdrop-blur-sm border-purple-500/20">
                      <SelectValue placeholder="დეპარტამენტი" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა</SelectItem>
                      {departments.map((dept) => (
                        <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={levelFilter} onValueChange={setLevelFilter}>
                    <SelectTrigger className="w-[200px] bg-background/50 backdrop-blur-sm border-purple-500/20">
                      <SelectValue placeholder="დონე" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა</SelectItem>
                      <SelectItem value="junior">Junior</SelectItem>
                      <SelectItem value="middle">Middle</SelectItem>
                      <SelectItem value="senior">Senior</SelectItem>
                      <SelectItem value="manager">Manager</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 animate-fade-in">
              {filteredPositions.map((pos, index) => (
                <div 
                  key={pos.id} 
                  className="animate-fade-in"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <PositionCard
                    position={pos}
                    onEdit={() => handleEditPosition(pos)}
                    onDelete={() => handleDeletePosition(pos.id, pos.title)}
                    onToggleStatus={() => handleTogglePositionStatus(pos)}
                  />
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Budgets Tab */}
          <TabsContent value="budgets" className="space-y-6 animate-fade-in">
            <Card className="border-green-500/20 bg-gradient-to-br from-green-500/5 to-background backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="ძებნა ბიუჯეტის კატეგორიის მიხედვით..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 bg-background/50 backdrop-blur-sm border-green-500/20 focus:border-green-500/40"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-4 animate-fade-in">
              {filteredBudgets.map((budget, index) => (
                <Card 
                  key={budget.id} 
                  className="overflow-hidden border-green-500/20 bg-gradient-to-r from-green-500/5 to-background backdrop-blur-sm hover:shadow-lg hover:shadow-green-500/10 transition-all duration-300 animate-fade-in"
                  style={{ animationDelay: `${index * 30}ms` }}
                >
                  <div className="h-1 bg-gradient-to-r from-green-600 via-green-500 to-green-400" />
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-green-500/10">
                          <BarChart3 className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{budget.category}</CardTitle>
                          <CardDescription className="mt-1">{budget.department?.name || 'დეპარტამენტი არ არის მითითებული'}</CardDescription>
                        </div>
                      </div>
                      <Badge className="bg-gradient-to-r from-green-600 to-green-500 text-white">{budget.fiscal_year}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-3">
                      <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
                        <p className="text-sm text-muted-foreground mb-1">დაგეგმილი</p>
                        <p className="text-2xl font-bold bg-gradient-to-br from-blue-600 to-blue-400 bg-clip-text text-transparent">
                          {budget.planned_amount.toLocaleString()} ₾
                        </p>
                      </div>
                      <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                        <p className="text-sm text-muted-foreground mb-1">ფაქტობრივი</p>
                        <p className="text-2xl font-bold bg-gradient-to-br from-green-600 to-green-400 bg-clip-text text-transparent">
                          {budget.actual_amount.toLocaleString()} ₾
                        </p>
                      </div>
                      <div className={`p-4 rounded-lg border ${(budget.variance || 0) >= 0 ? 'bg-green-500/10 border-green-500/20' : 'bg-red-500/10 border-red-500/20'}`}>
                        <p className="text-sm text-muted-foreground mb-1">ვარიანსი</p>
                        <p className={`text-2xl font-bold ${(budget.variance || 0) >= 0 ? 'bg-gradient-to-br from-green-600 to-green-400 bg-clip-text text-transparent' : 'bg-gradient-to-br from-red-600 to-red-400 bg-clip-text text-transparent'}`}>
                          {(budget.variance || 0).toLocaleString()} ₾
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Disciplinary Tab */}
          <TabsContent value="disciplinary" className="space-y-6 animate-fade-in">
            <Card className="border-orange-500/20 bg-gradient-to-br from-orange-500/5 to-background backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="ძებნა თანამშრომლის ან მიზეზის მიხედვით..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 bg-background/50 backdrop-blur-sm border-orange-500/20 focus:border-orange-500/40"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-4 animate-fade-in">
              {filteredDisciplinary.map((action, index) => (
                <div 
                  key={action.id} 
                  className="animate-fade-in"
                  style={{ animationDelay: `${index * 30}ms` }}
                >
                  <DisciplinaryActionCard action={action} />
                </div>
              ))}
            </div>
          </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          <DepartmentAnalytics departments={analyticsData} />
          <DepartmentTrends departments={departments} />
        </TabsContent>
      </Tabs>

      {/* Dialogs */}
      <AddDepartmentDialog
        open={addDepartmentOpen}
        onOpenChange={setAddDepartmentOpen}
        onSuccess={() => {
          fetchDepartments();
          setAddDepartmentOpen(false);
        }}
        employees={employees}
        departments={departments}
      />

      <AddPositionDialog
        open={addPositionOpen}
        onOpenChange={setAddPositionOpen}
        onSuccess={() => {
          fetchPositions();
          setAddPositionOpen(false);
        }}
        departments={departments}
      />

      <EditDepartmentDialog
        open={editDepartmentOpen}
        onOpenChange={setEditDepartmentOpen}
        department={selectedDepartment}
        onSuccess={() => {
          fetchDepartments();
          setEditDepartmentOpen(false);
        }}
        employees={employees}
        departments={departments}
      />

      <EditPositionDialog
        open={editPositionOpen}
        onOpenChange={setEditPositionOpen}
        position={selectedPosition}
        onSuccess={() => {
          fetchPositions();
          setEditPositionOpen(false);
        }}
        departments={departments}
      />

      <DeleteConfirmDialog
        open={deleteConfirmOpen}
        onOpenChange={setDeleteConfirmOpen}
        onConfirm={confirmDelete}
        title={`${deleteTarget?.type === 'department' ? 'დეპარტამენტის' : 'პოზიციის'} წაშლა`}
        description={`დარწმუნებული ხართ, რომ გსურთ ${deleteTarget?.name} წაშლა?`}
      />
      </div>
    </div>
  );
};

export default OrganizationalStructure;
