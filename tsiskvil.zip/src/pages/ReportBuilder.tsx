import { useState, useEffect, useCallback } from "react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  BarChart3, Table2, PieChart, LineChart, Download, Plus, X, 
  GripVertical, Filter, Eye, Columns3, ArrowUpDown, FileDown,
  Database, Play, Trash2, Save
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, PieChart as RePieChart, Pie, Cell,
  LineChart as ReLineChart, Line, Area, AreaChart
} from "recharts";

// Available tables with Georgian labels
const DATA_SOURCES = [
  { key: "employees", label: "თანამშრომლები", icon: "👥" },
  { key: "attendance", label: "დასწრება", icon: "📋" },
  { key: "leave_requests", label: "შვებულებები", icon: "🏖️" },
  { key: "payroll", label: "ხელფასები", icon: "💰" },
  { key: "departments", label: "დეპარტამენტები", icon: "🏢" },
  { key: "tasks", label: "დავალებები", icon: "✅" },
  { key: "training_programs", label: "ტრენინგები", icon: "📚" },
  { key: "budget_expenses", label: "ხარჯები", icon: "📊" },
  { key: "budget_plans", label: "ბიუჯეტის გეგმები", icon: "📈" },
  { key: "overtime_requests", label: "ზეგანაკვეთური", icon: "⏰" },
  { key: "documents", label: "დოკუმენტები", icon: "📄" },
  { key: "job_vacancies", label: "ვაკანსიები", icon: "💼" },
  { key: "candidates", label: "კანდიდატები", icon: "🎯" },
  { key: "assets", label: "აქტივები", icon: "🖥️" },
];

const CHART_TYPES = [
  { key: "table", label: "ცხრილი", icon: Table2 },
  { key: "bar", label: "სვეტოვანი", icon: BarChart3 },
  { key: "line", label: "წრფივი", icon: LineChart },
  { key: "pie", label: "წრიული", icon: PieChart },
  { key: "area", label: "არეალი", icon: BarChart3 },
];

const CHART_COLORS = [
  "hsl(var(--primary))",
  "hsl(var(--accent))",
  "#8b5cf6", "#f59e0b", "#10b981", "#ef4444", "#3b82f6", "#ec4899"
];

interface ReportColumn {
  name: string;
  type: string;
}

interface ReportFilter {
  column: string;
  operator: string;
  value: string;
}

interface ReportConfig {
  dataSource: string;
  selectedColumns: string[];
  filters: ReportFilter[];
  chartType: string;
  groupBy: string;
  sortBy: string;
  sortOrder: "asc" | "desc";
  limit: number;
}

export default function ReportBuilder() {
  const [config, setConfig] = useState<ReportConfig>({
    dataSource: "",
    selectedColumns: [],
    filters: [],
    chartType: "table",
    groupBy: "",
    sortBy: "",
    sortOrder: "asc",
    limit: 100,
  });
  
  const [availableColumns, setAvailableColumns] = useState<ReportColumn[]>([]);
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [columnsLoading, setColumnsLoading] = useState(false);
  const [hasRun, setHasRun] = useState(false);

  // Fetch columns when data source changes
  useEffect(() => {
    if (!config.dataSource) {
      setAvailableColumns([]);
      return;
    }
    fetchColumns(config.dataSource);
  }, [config.dataSource]);

  const fetchColumns = async (table: string) => {
    setColumnsLoading(true);
    try {
      const { data: rows, error } = await supabase
        .from(table as any)
        .select("*")
        .limit(1);

      if (error) throw error;

      if (rows && rows.length > 0) {
        const cols = Object.keys(rows[0]).map(key => ({
          name: key,
          type: typeof rows[0][key] === "number" ? "number" : 
                typeof rows[0][key] === "boolean" ? "boolean" : "string"
        }));
        setAvailableColumns(cols);
      } else {
        // If no data, try to infer columns from an empty select
        setAvailableColumns([]);
        toast.info("ცხრილი ცარიელია, სვეტები ვერ მოიძებნა");
      }
    } catch (err: any) {
      toast.error("სვეტების ჩატვირთვა ვერ მოხერხდა: " + err.message);
      setAvailableColumns([]);
    } finally {
      setColumnsLoading(false);
    }
  };

  const toggleColumn = (colName: string) => {
    setConfig(prev => ({
      ...prev,
      selectedColumns: prev.selectedColumns.includes(colName)
        ? prev.selectedColumns.filter(c => c !== colName)
        : [...prev.selectedColumns, colName]
    }));
  };

  const selectAllColumns = () => {
    setConfig(prev => ({
      ...prev,
      selectedColumns: availableColumns.map(c => c.name)
    }));
  };

  const clearColumns = () => {
    setConfig(prev => ({ ...prev, selectedColumns: [] }));
  };

  const addFilter = () => {
    if (availableColumns.length === 0) return;
    setConfig(prev => ({
      ...prev,
      filters: [...prev.filters, { column: availableColumns[0].name, operator: "eq", value: "" }]
    }));
  };

  const updateFilter = (idx: number, field: keyof ReportFilter, value: string) => {
    setConfig(prev => ({
      ...prev,
      filters: prev.filters.map((f, i) => i === idx ? { ...f, [field]: value } : f)
    }));
  };

  const removeFilter = (idx: number) => {
    setConfig(prev => ({
      ...prev,
      filters: prev.filters.filter((_, i) => i !== idx)
    }));
  };

  const runReport = useCallback(async () => {
    if (!config.dataSource) {
      toast.error("აირჩიეთ მონაცემთა წყარო");
      return;
    }

    setLoading(true);
    setHasRun(true);

    try {
      const cols = config.selectedColumns.length > 0
        ? config.selectedColumns.join(",")
        : "*";

      let query = supabase
        .from(config.dataSource as any)
        .select(cols)
        .limit(config.limit);

      // Apply filters
      for (const filter of config.filters) {
        if (!filter.value) continue;
        switch (filter.operator) {
          case "eq": query = query.eq(filter.column, filter.value); break;
          case "neq": query = query.neq(filter.column, filter.value); break;
          case "gt": query = query.gt(filter.column, filter.value); break;
          case "lt": query = query.lt(filter.column, filter.value); break;
          case "gte": query = query.gte(filter.column, filter.value); break;
          case "lte": query = query.lte(filter.column, filter.value); break;
          case "like": query = query.ilike(filter.column, `%${filter.value}%`); break;
        }
      }

      // Apply sorting
      if (config.sortBy) {
        query = query.order(config.sortBy, { ascending: config.sortOrder === "asc" });
      }

      const { data: result, error } = await query;
      if (error) throw error;

      setData(result || []);
      toast.success(`${(result || []).length} ჩანაწერი მოიძებნა`);
    } catch (err: any) {
      toast.error("მოთხოვნის შესრულება ვერ მოხერხდა: " + err.message);
      setData([]);
    } finally {
      setLoading(false);
    }
  }, [config]);

  const exportToCSV = () => {
    if (data.length === 0) return;
    const headers = Object.keys(data[0]);
    const csv = [
      headers.join(","),
      ...data.map(row => headers.map(h => {
        const val = row[h];
        if (val === null || val === undefined) return "";
        const str = String(val);
        return str.includes(",") || str.includes('"') ? `"${str.replace(/"/g, '""')}"` : str;
      }).join(","))
    ].join("\n");

    const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `report_${config.dataSource}_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV ფაილი ჩამოიტვირთა");
  };

  const displayColumns = config.selectedColumns.length > 0 
    ? config.selectedColumns 
    : (data.length > 0 ? Object.keys(data[0]) : []);

  // Prepare chart data
  const getChartData = () => {
    if (data.length === 0) return [];

    // If groupBy is set, aggregate by count
    if (config.groupBy) {
      const grouped: Record<string, number> = {};
      data.forEach(row => {
        const key = String(row[config.groupBy] ?? "N/A");
        grouped[key] = (grouped[key] || 0) + 1;
      });
      return Object.entries(grouped)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 30)
        .map(([name, value]) => ({ name, value }));
    }

    // Without groupBy: detect numeric columns
    const cols = displayColumns.length > 0 ? displayColumns : (data.length > 0 ? Object.keys(data[0]) : []);
    const numCols = cols.filter(c => 
      data.some(row => {
        const v = row[c];
        return v !== null && v !== undefined && !isNaN(Number(v)) && typeof v !== "boolean" && String(v).trim() !== "";
      })
    );
    // Exclude uuid-like and date-like columns from numeric detection
    const realNumCols = numCols.filter(c => {
      const sample = data.find(row => row[c] !== null && row[c] !== undefined);
      if (!sample) return false;
      const val = String(sample[c]);
      // Skip UUIDs, dates, long strings
      if (val.includes("-") && val.length > 10) return false;
      if (val.includes("T") || val.includes(":")) return false;
      return true;
    });

    // If we found numeric columns, chart them directly
    if (realNumCols.length > 0) {
      const strCols = cols.filter(c => !realNumCols.includes(c) && data.some(row => typeof row[c] === "string"));
      const labelCol = strCols[0] || cols[0];
      return data.slice(0, 50).map((row, idx) => {
        const item: any = { name: row[labelCol] ? String(row[labelCol]).slice(0, 20) : `#${idx + 1}` };
        realNumCols.forEach(c => { item[c] = Number(row[c]) || 0; });
        return item;
      });
    }

    // Fallback: auto-group by the first string column that has variety
    const autoGroupCol = cols.find(c => {
      const uniqueVals = new Set(data.map(row => String(row[c] ?? "")));
      return uniqueVals.size > 1 && uniqueVals.size <= 30;
    });

    if (autoGroupCol) {
      const grouped: Record<string, number> = {};
      data.forEach(row => {
        const key = String(row[autoGroupCol] ?? "N/A");
        grouped[key] = (grouped[key] || 0) + 1;
      });
      return Object.entries(grouped)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 20)
        .map(([name, value]) => ({ name, value }));
    }

    return [];
  };

  const getChartNumericKeys = () => {
    if (config.groupBy) return ["value"];
    const cols = displayColumns.length > 0 ? displayColumns : (data.length > 0 ? Object.keys(data[0]) : []);
    const numCols = cols.filter(c => 
      data.some(row => {
        const v = row[c];
        return v !== null && v !== undefined && !isNaN(Number(v)) && typeof v !== "boolean" && String(v).trim() !== "";
      })
    ).filter(c => {
      const sample = data.find(row => row[c] !== null && row[c] !== undefined);
      if (!sample) return false;
      const val = String(sample[c]);
      if (val.includes("-") && val.length > 10) return false;
      if (val.includes("T") || val.includes(":")) return false;
      return true;
    });
    return numCols.length > 0 ? numCols : ["value"];
  };

  const chartData = getChartData();
  const chartNumericKeys = getChartNumericKeys();
  const numericColumns = availableColumns.filter(c => c.type === "number");

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-6">
        <div className="max-w-[1600px] mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-xl shadow-purple-500/25">
                <Database className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                  Report Builder
                </h1>
                <p className="text-muted-foreground text-sm">
                  აირჩიეთ მონაცემთა წყარო, სვეტები და ფილტრები ვიზუალური ანგარიშის შესაქმნელად
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {data.length > 0 && (
                <Button variant="outline" onClick={exportToCSV} className="gap-2">
                  <FileDown className="h-4 w-4" />
                  CSV
                </Button>
              )}
              <Button 
                onClick={runReport} 
                disabled={!config.dataSource || loading}
                className="gap-2 bg-gradient-to-r from-primary to-primary/80"
              >
                <Play className="h-4 w-4" />
                {loading ? "იტვირთება..." : "გაშვება"}
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Config Panel */}
            <div className="lg:col-span-4 space-y-4">
              {/* Data Source */}
              <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <Database className="h-4 w-4 text-primary" />
                    მონაცემთა წყარო
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Select
                    value={config.dataSource}
                    onValueChange={(v) => setConfig(prev => ({ ...prev, dataSource: v, selectedColumns: [], filters: [], groupBy: "", sortBy: "" }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="აირჩიეთ ცხრილი..." />
                    </SelectTrigger>
                    <SelectContent>
                      {DATA_SOURCES.map(ds => (
                        <SelectItem key={ds.key} value={ds.key}>
                          <span className="flex items-center gap-2">
                            <span>{ds.icon}</span>
                            <span>{ds.label}</span>
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>

              {/* Columns */}
              {availableColumns.length > 0 && (
                <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-semibold flex items-center gap-2">
                        <Columns3 className="h-4 w-4 text-primary" />
                        სვეტები
                      </CardTitle>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={selectAllColumns}>ყველა</Button>
                        <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={clearColumns}>გასუფთავება</Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto">
                      {availableColumns.map(col => (
                        <Badge
                          key={col.name}
                          variant={config.selectedColumns.includes(col.name) ? "default" : "outline"}
                          className={cn(
                            "cursor-pointer transition-all text-xs hover:scale-105",
                            config.selectedColumns.includes(col.name) 
                              ? "bg-primary text-primary-foreground" 
                              : "hover:bg-primary/10"
                          )}
                          onClick={() => toggleColumn(col.name)}
                        >
                          {col.name}
                        </Badge>
                      ))}
                    </div>
                    {columnsLoading && <p className="text-xs text-muted-foreground mt-2">იტვირთება...</p>}
                  </CardContent>
                </Card>
              )}

              {/* Filters */}
              {availableColumns.length > 0 && (
                <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-semibold flex items-center gap-2">
                        <Filter className="h-4 w-4 text-primary" />
                        ფილტრები
                      </CardTitle>
                      <Button variant="ghost" size="sm" className="h-7 gap-1" onClick={addFilter}>
                        <Plus className="h-3 w-3" /> დამატება
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {config.filters.map((filter, idx) => (
                      <div key={idx} className="flex gap-1.5 items-center">
                        <Select value={filter.column} onValueChange={v => updateFilter(idx, "column", v)}>
                          <SelectTrigger className="h-8 text-xs flex-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {availableColumns.map(c => (
                              <SelectItem key={c.name} value={c.name}>{c.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={filter.operator} onValueChange={v => updateFilter(idx, "operator", v)}>
                          <SelectTrigger className="h-8 text-xs w-16">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="eq">=</SelectItem>
                            <SelectItem value="neq">≠</SelectItem>
                            <SelectItem value="gt">&gt;</SelectItem>
                            <SelectItem value="lt">&lt;</SelectItem>
                            <SelectItem value="gte">≥</SelectItem>
                            <SelectItem value="lte">≤</SelectItem>
                            <SelectItem value="like">შეიცავს</SelectItem>
                          </SelectContent>
                        </Select>
                        <Input
                          className="h-8 text-xs flex-1"
                          placeholder="მნიშვნელობა"
                          value={filter.value}
                          onChange={e => updateFilter(idx, "value", e.target.value)}
                        />
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => removeFilter(idx)}>
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                    {config.filters.length === 0 && (
                      <p className="text-xs text-muted-foreground text-center py-2">ფილტრები არ არის დამატებული</p>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Sort & Group */}
              {availableColumns.length > 0 && (
                <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-semibold flex items-center gap-2">
                      <ArrowUpDown className="h-4 w-4 text-primary" />
                      დახარისხება და დაჯგუფება
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-xs text-muted-foreground mb-1 block">დახარისხება</label>
                        <Select value={config.sortBy || "__none__"} onValueChange={v => setConfig(p => ({ ...p, sortBy: v === "__none__" ? "" : v }))}>
                          <SelectTrigger className="h-8 text-xs">
                            <SelectValue placeholder="სვეტი..." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="__none__">არცერთი</SelectItem>
                            {availableColumns.map(c => (
                              <SelectItem key={c.name} value={c.name}>{c.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground mb-1 block">მიმართულება</label>
                        <Select value={config.sortOrder} onValueChange={v => setConfig(p => ({ ...p, sortOrder: v as "asc" | "desc" }))}>
                          <SelectTrigger className="h-8 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="asc">ზრდადობით ↑</SelectItem>
                            <SelectItem value="desc">კლებადობით ↓</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">დაჯგუფება (ჩარტისთვის)</label>
                      <Select value={config.groupBy || "__none__"} onValueChange={v => setConfig(p => ({ ...p, groupBy: v === "__none__" ? "" : v }))}>
                        <SelectTrigger className="h-8 text-xs">
                          <SelectValue placeholder="სვეტი..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="__none__">არცერთი</SelectItem>
                          {availableColumns.map(c => (
                            <SelectItem key={c.name} value={c.name}>{c.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">ლიმიტი</label>
                      <Select value={String(config.limit)} onValueChange={v => setConfig(p => ({ ...p, limit: Number(v) }))}>
                        <SelectTrigger className="h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="50">50</SelectItem>
                          <SelectItem value="100">100</SelectItem>
                          <SelectItem value="250">250</SelectItem>
                          <SelectItem value="500">500</SelectItem>
                          <SelectItem value="1000">1000</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Results Panel */}
            <div className="lg:col-span-8 space-y-4">
              {/* Chart Type Selector */}
              {config.dataSource && (
                <div className="flex items-center gap-2 flex-wrap">
                  {CHART_TYPES.map(ct => (
                    <Button
                      key={ct.key}
                      variant={config.chartType === ct.key ? "default" : "outline"}
                      size="sm"
                      className="gap-1.5"
                      onClick={() => setConfig(p => ({ ...p, chartType: ct.key }))}
                    >
                      <ct.icon className="h-4 w-4" />
                      {ct.label}
                    </Button>
                  ))}
                  {data.length > 0 && (
                    <Badge variant="secondary" className="ml-auto">
                      {data.length} ჩანაწერი
                    </Badge>
                  )}
                </div>
              )}

              {/* Chart View */}
              {hasRun && data.length > 0 && config.chartType !== "table" && (
                <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                  <CardContent className="pt-6">
                    {chartData.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8 text-sm">
                        {!config.groupBy 
                          ? "რიცხვითი სვეტები ვერ მოიძებნა. აირჩიეთ \"დაჯგუფება\" სვეტი ან რიცხვითი სვეტები"
                          : "მონაცემები ვერ მოიძებნა"}
                      </p>
                    ) : (
                      <ResponsiveContainer width="100%" height={config.chartType === "pie" ? 500 : 350}>
                        {config.chartType === "bar" ? (
                          <BarChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                            <XAxis dataKey="name" tick={{ fontSize: 11 }} angle={-30} textAnchor="end" height={60} />
                            <YAxis tick={{ fontSize: 11 }} />
                            <Tooltip />
                            <Legend />
                            {chartNumericKeys.map((key, i) => (
                              <Bar key={key} dataKey={key} name={config.groupBy ? "რაოდენობა" : key} fill={CHART_COLORS[i % CHART_COLORS.length]} radius={[4, 4, 0, 0]} />
                            ))}
                          </BarChart>
                        ) : config.chartType === "line" ? (
                          <ReLineChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                            <XAxis dataKey="name" tick={{ fontSize: 11 }} angle={-30} textAnchor="end" height={60} />
                            <YAxis tick={{ fontSize: 11 }} />
                            <Tooltip />
                            <Legend />
                            {chartNumericKeys.map((key, i) => (
                              <Line key={key} type="monotone" dataKey={key} name={config.groupBy ? "რაოდენობა" : key} stroke={CHART_COLORS[i % CHART_COLORS.length]} strokeWidth={2} dot={{ r: 4 }} />
                            ))}
                          </ReLineChart>
                        ) : config.chartType === "area" ? (
                          <AreaChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                            <XAxis dataKey="name" tick={{ fontSize: 11 }} angle={-30} textAnchor="end" height={60} />
                            <YAxis tick={{ fontSize: 11 }} />
                            <Tooltip />
                            <Legend />
                            {chartNumericKeys.map((key, i) => (
                              <Area key={key} type="monotone" dataKey={key} name={config.groupBy ? "რაოდენობა" : key} stroke={CHART_COLORS[i % CHART_COLORS.length]} fill={CHART_COLORS[i % CHART_COLORS.length]} fillOpacity={0.2} />
                            ))}
                          </AreaChart>
                        ) : (
                          <RePieChart>
                            <Pie
                              data={chartData.slice(0, 12)}
                              cx="50%"
                              cy="45%"
                              labelLine={false}
                              label={({ name, percent }) => percent > 0.04 ? `${String(name).slice(0, 12)}` : ""}
                              outerRadius={140}
                              innerRadius={50}
                              dataKey={chartNumericKeys[0] || "value"}
                              paddingAngle={2}
                              stroke="none"
                            >
                              {chartData.slice(0, 12).map((_, index) => (
                                <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value: any, name: any) => [value, name]} />
                            <Legend 
                              layout="horizontal" 
                              verticalAlign="bottom" 
                              align="center"
                              wrapperStyle={{ paddingTop: 16, fontSize: 12 }}
                              formatter={(value: string) => <span className="text-xs text-foreground">{String(value).slice(0, 20)}</span>}
                            />
                          </RePieChart>
                        )}
                      </ResponsiveContainer>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Table View */}
              {hasRun && data.length > 0 && config.chartType === "table" && (
                <Card className="border-border/50 bg-card/80 backdrop-blur-xl overflow-hidden">
                  <CardContent className="p-0">
                    <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-muted/50 sticky top-0 z-10">
                          <tr>
                            <th className="px-3 py-2 text-left text-xs font-semibold text-muted-foreground w-10">#</th>
                            {displayColumns.map(col => (
                              <th key={col} className="px-3 py-2 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap">
                                {col}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border/50">
                          {data.map((row, idx) => (
                            <tr key={idx} className="hover:bg-muted/30 transition-colors">
                              <td className="px-3 py-2 text-xs text-muted-foreground">{idx + 1}</td>
                              {displayColumns.map(col => (
                                <td key={col} className="px-3 py-2 text-xs max-w-[200px] truncate">
                                  {row[col] === null || row[col] === undefined 
                                    ? <span className="text-muted-foreground/50">-</span>
                                    : typeof row[col] === "boolean"
                                    ? row[col] ? "✓" : "✗"
                                    : String(row[col])
                                  }
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Empty State */}
              {!hasRun && (
                <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                  <CardContent className="flex flex-col items-center justify-center py-20 text-center">
                    <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-500/10 to-purple-500/10 mb-4">
                      <BarChart3 className="h-12 w-12 text-primary/50" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">Report Builder</h3>
                    <p className="text-sm text-muted-foreground max-w-md">
                      აირჩიეთ მონაცემთა წყარო, სასურველი სვეტები, დაამატეთ ფილტრები და დააჭირეთ "გაშვება" ღილაკს
                    </p>
                  </CardContent>
                </Card>
              )}

              {hasRun && data.length === 0 && !loading && (
                <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                  <CardContent className="flex flex-col items-center justify-center py-16 text-center">
                    <p className="text-muted-foreground">მონაცემები ვერ მოიძებნა მითითებული ფილტრებით</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
