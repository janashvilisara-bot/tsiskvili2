import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import {
  Shield,
  Users,
  Database,
  Lock,
  Server,
  Share2,
  Clock,
  UserCheck,
  Mail,
  Scale,
  Fingerprint,
  FileText,
  Globe,
  HardDrive
} from 'lucide-react';
import { PageTransition } from '@/components/PageTransition';

const PrivacyPolicy = () => {
  return (
    <PageTransition>
      <div className="max-w-4xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <Shield className="h-16 w-16 mx-auto text-primary" />
          <h1 className="text-4xl font-bold">კონფიდენციალურობის პოლიტიკა</h1>
          <p className="text-muted-foreground">Privacy Policy - B2B / SaaS</p>
          <p className="text-sm text-muted-foreground">ბოლო განახლება: 23 ივნისი, 2026</p>
        </div>

        <Card className="bg-muted/30 border-muted">
          <CardContent className="py-6">
            <p className="text-sm text-muted-foreground leading-relaxed">
              წინამდებარე კონფიდენციალურობის პოლიტიკა განმარტავს, თუ როგორ ხდება პერსონალურ მონაცემთა დამუშავება, შენახვა და დაცვა ადამიანური რესურსების მართვის ღრუბლოვან პლატფორმაში „Talent OS“ (შემდგომში „პლატფორმა“ ან „ჩვენ“).
            </p>
          </CardContent>
        </Card>

        {/* Section 1 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Scale className="h-5 w-5 text-primary" />
              1. მნიშვნელოვანი სამართლებრივი სტატუსი (მხარეთა როლები)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              საქართველოს კანონის „პერსონალურ მონაცემთა დაცვის შესახებ“ და მონაცემთა დაცვის ზოგადი რეგულაციის (GDPR) შესაბამისად, მხარეთა როლები განისაზღვრება შემდეგნაირად:
            </p>
            <ul className="space-y-3 text-sm text-muted-foreground list-none ml-0">
              <li className="flex gap-2">
                <Users className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <span>
                  <strong>მონაცემთა დამამუშავებელი (Data Controller):</strong> კლიენტი კომპანია/დამსაქმებელი, რომელიც ყიდულობს Talent OS-ის ლიცენზიას და სისტემაში ატვირთავს თავისი თანამშრომლების მონაცემებს. დამსაქმებელი განსაზღვრავს მონაცემთა დამუშავების მიზნებს, ვადებს და პასუხისმგებელია მათი შეგროვების კანონიერ საფუძვლებზე.
                </span>
              </li>
              <li className="flex gap-2">
                <Server className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <span>
                  <strong>მონაცემთა დამმუშავებელი (Data Processor):</strong> პლატფორმა Talent OS. ჩვენ ვმოქმედებთ ექსკლუზიურად დამსაქმებლის დავალებითა და ინსტრუქციებით, წინამდებარე პოლიტიკისა და მათთან გაფორმებული მონაცემთა დამუშავების შეთანხმების (DPA) ფარგლებში.
                </span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Section 2 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Database className="h-5 w-5 text-primary" />
              2. რა ტიპის მონაცემები მუშავდება სისტემაში?
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              დამსაქმებლის მიერ პლატფორმის გამოყენების სპეციფიკიდან გამომდინარე, Talent OS-ში მუშავდება მისი თანამშრომლების, კონტრაქტორებისა და სტაჟიორების შემდეგი მონაცემები:
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground list-disc ml-5">
              <li><strong>საიდენტიფიკაციო და საკონტაქტო მონაცემები:</strong> სახელი, გვარი, პირადი ნომერი (ID), ფოტო, ელ-ფოსტა, ტელეფონის ნომერი, საცხოვრებელი მისამართი.</li>
              <li><strong>პროფესიული მონაცემები:</strong> პოზიცია, დეპარტამენტი, სამუშაო სტაჟი, კარიერული განვითარების გეგმები, შეფასებები (KPI).</li>
              <li><strong>დასწრებისა და სამუშაო დროის აღრიცხვა:</strong> სამუშაო საათები, შვებულებები, დაგვიანებები, არდადეგები.</li>
              <li><strong>ფინანსური მონაცემები (Payroll):</strong> ხელფასი, პრემიები, ბონუსები, საბანკო რეკვიზიტები, საგადასახადო დაქვითვები.</li>
              <li><strong>დისციპლინური წარმოება:</strong> შიდაგამნაწესის დარღვევები, გაფრთხილებები, საყვედურები და სხვა კანონიერი სანქციები.</li>
              <li><strong>განსაკუთრებული კატეგორიის (ჯანმრთელობის) მონაცემები:</strong> საავადმყოფო ფურცლები (ბიულეტენები), სამედიცინო ცნობები, დეკრეტული შვებულების საფუძვლები და შრომისუუნარობის სტატუსი - შრომის კოდექსით გათვალისწინებული უფლებებისა და მოვალეობების შესრულების მიზნით.</li>
            </ul>
          </CardContent>
        </Card>

        {/* Section 3 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <FileText className="h-5 w-5 text-primary" />
              3. მონაცემთა დამუშავების მიზნები
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              პლატფორმა მონაცემებს ამუშავებს მხოლოდ დამსაქმებლის შრომითი და ორგანიზაციული პროცესების ავტომატიზაციის მიზნით, რაც მოიცავს: კადრების აღრიცხვას, სახელფასო უწყისების ფორმირებას, დისციპლინური წარმოების მართვას და შრომისუუნარობის (ჯანმრთელობის მდგომარეობის) გამო გაცდენილი დღეების კანონიერ ასახვას.
            </p>
          </CardContent>
        </Card>

        {/* Section 4 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Lock className="h-5 w-5 text-primary" />
              4. უსაფრთხოების გაძლიერებული გარანტიები
            </CardTitle>
            <CardDescription>
              ვინაიდან Talent OS-ში ინახება მაღალი სენსიტიურობის მქონე ფინანსური, სადისციპლინო და ჯანმრთელობის მონაცემები, ჩვენ ვახორციელებთ უსაფრთხოების გაძლიერებულ ზომებს:
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <ul className="space-y-3 text-sm text-muted-foreground list-none ml-0">
              <li className="flex gap-2">
                <HardDrive className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <span>
                  <strong>4.1. სრული დაშიფვრა (Encryption):</strong> მონაცემები იშიფრება როგორც გადაცემის პროცესში (In Transit - TLS 1.3), ისე სერვერებზე შენახვისას (At Rest - AES-256).
                </span>
              </li>
              <li className="flex gap-2">
                <Users className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <span>
                  <strong>4.2. მკაცრი როლური წვდომა (RBAC):</strong> პლატფორმა დამსაქმებელს აძლევს ინსტრუმენტს, შეზღუდოს სენსიტიურ მოდულებზე (მაგ. ჯანმრთელობის ცნობები ან ხელფასები) წვდომა და ის ხელმისაწვდომი გახადოს მხოლოდ ორგანიზაციის უფლებამოსილი პირებისთვის.
                </span>
              </li>
              <li className="flex gap-2">
                <FileText className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <span>
                  <strong>4.3. აუდიტის ლოგირება (Audit Trail):</strong> სისტემა ავტომატურად და შეუცვლელად აწარმოებს ყველა იმ ქმედების ჟურნალს (Logs), რომელიც უკავშირდება ჯანმრთელობის, სანქციებისა და ფინანსური მონაცემების ნახვას, შეცვლას ან წაშლას (ვინ, როდის და რა მონაცემი ნახა).
                </span>
              </li>
              <li className="flex gap-2">
                <Lock className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <span>
                  <strong>4.4. ორფაქტორიანი ავტორიზაცია (2FA):</strong> სისტემის ადმინისტრატორებისთვის სავალდებულოა მრავალფაქტორიანი ავტორიზაციის მექანიზმების გამოყენება.
                </span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Section 5 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Globe className="h-5 w-5 text-primary" />
              5. მონაცემთა ლოკალიზაცია და მდებარეობა
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              Talent OS-ის მთელი ინფრასტრუქტურა განთავსებულია Lovable პლატფორმაზე. ყველა პერსონალური და განსაკუთრებული კატეგორიის მონაცემი ფიზიკურად ლოკალიზებულია და ინახება ევროკავშირის (EU) ტერიტორიაზე არსებულ უსაფრთხო სერვერებზე, რაც უზრუნველყოფს ISO 27001 და GDPR სტანდარტების შესაბამისობას.
            </p>
          </CardContent>
        </Card>

        {/* Section 6 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Share2 className="h-5 w-5 text-primary" />
              6. მონაცემთა გადაცემა მესამე მხარეებზე
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              Talent OS <strong>არ გადასცემს, არ ყიდის და არ აზიარებს</strong> სისტემაში არსებულ მონაცემებს მესამე პირებთან მარკეტინგული ან სხვა კომერციული მიზნებისთვის. მონაცემებზე წვდომა შეიძლება მიეცეს მხოლოდ:
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground list-disc ml-5">
              <li>თავად დამსაქმებლის მიერ ინტეგრირებულ მესამე მხარის სისტემებს (მაგ. ორგანიზაციის შიდა Active Directory ან საბანკო API ხელფასების გადარიცხვისთვის).</li>
              <li>კანონით პირდაპირ გათვალისწინებულ შემთხვევებში, მხოლოდ დამსაქმებლის (Controller) ინფორმირების საფუძველზე, თუ არსებობს ოფიციალური იურიდიული მოთხოვნა.</li>
            </ul>
          </CardContent>
        </Card>

        {/* Section 7 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Clock className="h-5 w-5 text-primary" />
              7. მონაცემთა შენახვის ვადები
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              მონაცემები Talent OS-ში ინახება დამსაქმებელსა და ჩვენს შორის გაფორმებული კორპორატიული ხელშეკრულების მოქმედების ვადით. ხელშეკრულების შეწყვეტისას, დამსაქმებლის მოთხოვნით, ყველა მონაცემი უსაფრთხოდ იშლება ან ბრუნდება ექსპორტის სახით, გარდა იმ შემთხვევებისა, როდესაც კანონმდებლობა მოითხოვს გარკვეული ფინანსური ან საგადასახადო დოკუმენტაციის შენახვას.
            </p>
          </CardContent>
        </Card>

        {/* Section 8 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <UserCheck className="h-5 w-5 text-primary" />
              8. მონაცემთა სუბიექტების (თანამშრომელთა) უფლებები
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              ვინაიდან Talent OS არის მონაცემთა დამმუშავებელი (Processor), დასაქმებულებმა საკუთარი უფლებების (მონაცემთა წაშლა, გასწორება, წვდომა) გამოსაყენებლად პირდაპირ უნდა მიმართონ თავიანთ დამსაქმებელ კომპანიას (HR დეპარტამენტს). თუ თანამშრომელი მოთხოვნით მიმართავს Talent OS-ს, ჩვენ აღნიშნულ მოთხოვნას გადავამისამართებთ დამსაქმებელთან.
            </p>
          </CardContent>
        </Card>

        {/* Section 9 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Mail className="h-5 w-5 text-primary" />
              9. კონტაქტი
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              პლატფორმის უსაფრთხოებასთან, ტექნიკურ გარანტიებთან ან კონფიდენციალურობასთან დაკავშირებული კითხვების შემთხვევაში, დამსაქმებლებს შეუძლიათ დაუკავშირდნენ ჩვენს მონაცემთა დაცვის ოფიცერს (DPO):
            </p>
            <div className="flex items-center gap-2 text-sm font-medium text-foreground">
              <Mail className="h-4 w-4 text-primary" />
              <span>info@talentos.ge</span>
            </div>
          </CardContent>
        </Card>

        <Separator className="my-4" />

        <p className="text-center text-xs text-muted-foreground">
          © 2026 Talent OS. ყველა უფლება დაცულია. წინამდებარე პოლიტიკა შეიძლება პერიოდულად განახლდეს.
        </p>
      </div>
    </PageTransition>
  );
};

export default PrivacyPolicy;
