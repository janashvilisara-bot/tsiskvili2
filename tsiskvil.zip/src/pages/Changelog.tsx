import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  Rocket, Bug, Zap, Shield, Star, Clock, ChevronDown, ChevronUp, Plus, Trash2, Loader2,
} from "lucide-react";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

interface ChangeItem {
  id?: string;
  type: "feature" | "fix" | "improvement" | "security";
  text: string;
  sort_order?: number;
}

interface Release {
  id: string;
  version: string;
  date: string;
  title: string;
  highlights?: string;
  changes: ChangeItem[];
}

const typeConfig = {
  feature: { icon: Star, color: "text-emerald-500", bg: "bg-emerald-500/10", label: "ახალი" },
  fix: { icon: Bug, color: "text-red-500", bg: "bg-red-500/10", label: "შეცდომა" },
  improvement: { icon: Zap, color: "text-amber-500", bg: "bg-amber-500/10", label: "გაუმჯობესება" },
  security: { icon: Shield, color: "text-blue-500", bg: "bg-blue-500/10", label: "უსაფრთხოება" },
};

export default function Changelog() {
  const { userRole } = useAuth();
  const [releases, setReleases] = useState<Release[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedVersions, setExpandedVersions] = useState<string[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // New release form
  const [newVersion, setNewVersion] = useState("");
  const [newTitle, setNewTitle] = useState("");
  const [newHighlights, setNewHighlights] = useState("");
  const [newDate, setNewDate] = useState(new Date().toISOString().split("T")[0]);
  const [newItems, setNewItems] = useState<ChangeItem[]>([
    { type: "feature", text: "" },
  ]);

  const canManage = userRole === "admin" || userRole === "hr_manager";

  useEffect(() => {
    fetchReleases();
  }, []);

  const fetchReleases = async () => {
    setIsLoading(true);
    try {
      const { data: releasesData, error: relErr } = await supabase
        .from("changelog_releases")
        .select("*")
        .order("release_date", { ascending: false });

      if (relErr) throw relErr;

      const { data: itemsData, error: itemErr } = await supabase
        .from("changelog_items")
        .select("*")
        .order("sort_order", { ascending: true });

      if (itemErr) throw itemErr;

      const mapped: Release[] = (releasesData || []).map((r: any) => ({
        id: r.id,
        version: r.version,
        date: r.release_date,
        title: r.title,
        highlights: r.highlights,
        changes: (itemsData || [])
          .filter((item: any) => item.release_id === r.id)
          .map((item: any) => ({
            id: item.id,
            type: item.type as ChangeItem["type"],
            text: item.text,
            sort_order: item.sort_order,
          })),
      }));

      setReleases(mapped);
      if (mapped.length > 0 && expandedVersions.length === 0) {
        setExpandedVersions([mapped[0].version]);
      }
    } catch (error: any) {
      console.error("Error fetching changelog:", error);
      toast.error("ჩენჯლოგის ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleVersion = (version: string) => {
    setExpandedVersions((prev) =>
      prev.includes(version) ? prev.filter((v) => v !== version) : [...prev, version]
    );
  };

  const handleAddItem = () => {
    setNewItems([...newItems, { type: "feature", text: "" }]);
  };

  const handleRemoveItem = (index: number) => {
    setNewItems(newItems.filter((_, i) => i !== index));
  };

  const handleItemChange = (index: number, field: string, value: string) => {
    const updated = [...newItems];
    (updated[index] as any)[field] = value;
    setNewItems(updated);
  };

  const handleSaveRelease = async () => {
    if (!newVersion || !newTitle || newItems.every((i) => !i.text.trim())) {
      toast.error("შეავსეთ ვერსია, სათაური და მინიმუმ ერთი ცვლილება");
      return;
    }

    setIsSaving(true);
    try {
      const { data: release, error: relErr } = await supabase
        .from("changelog_releases")
        .insert({
          version: newVersion,
          title: newTitle,
          highlights: newHighlights || null,
          release_date: newDate,
        })
        .select()
        .single();

      if (relErr) throw relErr;

      const validItems = newItems.filter((i) => i.text.trim());
      if (validItems.length > 0) {
        const { error: itemErr } = await supabase.from("changelog_items").insert(
          validItems.map((item, idx) => ({
            release_id: release.id,
            type: item.type,
            text: item.text.trim(),
            sort_order: idx + 1,
          }))
        );
        if (itemErr) throw itemErr;
      }

      toast.success("რელიზი წარმატებით დაემატა");
      setIsAddDialogOpen(false);
      setNewVersion("");
      setNewTitle("");
      setNewHighlights("");
      setNewDate(new Date().toISOString().split("T")[0]);
      setNewItems([{ type: "feature", text: "" }]);
      fetchReleases();
    } catch (error: any) {
      toast.error(error.message || "შეცდომა");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteRelease = async (releaseId: string) => {
    if (!confirm("ნამდვილად წაშალოთ ეს რელიზი?")) return;
    try {
      const { error } = await supabase.from("changelog_releases").delete().eq("id", releaseId);
      if (error) throw error;
      toast.success("რელიზი წაიშალა");
      fetchReleases();
    } catch (error: any) {
      toast.error("წაშლა ვერ მოხერხდა");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Rocket className="h-6 w-6 text-primary" />
            რა შეიცვალა?
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            სისტემის განახლებების ისტორია და ახალი ფუნქციები
          </p>
        </div>
        {canManage && (
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                ახალი რელიზი
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>ახალი რელიზის დამატება</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <Label>ვერსია *</Label>
                    <Input
                      placeholder="მაგ: 3.9.0"
                      value={newVersion}
                      onChange={(e) => setNewVersion(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>თარიღი *</Label>
                    <Input
                      type="date"
                      value={newDate}
                      onChange={(e) => setNewDate(e.target.value)}
                    />
                  </div>
                </div>
                <div>
                  <Label>სათაური *</Label>
                  <Input
                    placeholder="მაგ: AI ანალიტიკა & რისკის პროგნოზი"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                  />
                </div>
                <div>
                  <Label>მოკლე აღწერა</Label>
                  <Textarea
                    placeholder="რელიზის მთავარი ცვლილებები..."
                    value={newHighlights}
                    onChange={(e) => setNewHighlights(e.target.value)}
                    rows={2}
                  />
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">ცვლილებები</Label>
                    <Button type="button" variant="outline" size="sm" onClick={handleAddItem}>
                      <Plus className="h-3 w-3 mr-1" /> დამატება
                    </Button>
                  </div>
                  {newItems.map((item, idx) => (
                    <div key={idx} className="flex gap-2 items-start">
                      <Select
                        value={item.type}
                        onValueChange={(val) => handleItemChange(idx, "type", val)}
                      >
                        <SelectTrigger className="w-36">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="feature">ახალი</SelectItem>
                          <SelectItem value="improvement">გაუმჯობესება</SelectItem>
                          <SelectItem value="fix">შეცდომა</SelectItem>
                          <SelectItem value="security">უსაფრთხოება</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input
                        className="flex-1"
                        placeholder="ცვლილების აღწერა..."
                        value={item.text}
                        onChange={(e) => handleItemChange(idx, "text", e.target.value)}
                      />
                      {newItems.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoveItem(idx)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>

                <Button className="w-full" onClick={handleSaveRelease} disabled={isSaving}>
                  {isSaving ? "ინახება..." : "რელიზის დამატება"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "ვერსიები", value: releases.length, icon: Rocket },
          { label: "ახალი ფუნქციები", value: releases.reduce((s, r) => s + r.changes.filter((c) => c.type === "feature").length, 0), icon: Star },
          { label: "გაუმჯობესებები", value: releases.reduce((s, r) => s + r.changes.filter((c) => c.type === "improvement").length, 0), icon: Zap },
          { label: "უსაფრთხოება", value: releases.reduce((s, r) => s + r.changes.filter((c) => c.type === "security").length, 0), icon: Shield },
        ].map((stat, i) => (
          <Card key={i} className="bg-card/50 border-border/50">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <stat.icon className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="text-xl font-bold">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Timeline */}
      <div className="space-y-3">
        {releases.map((release, rIdx) => {
          const isExpanded = expandedVersions.includes(release.version);
          return (
            <motion.div
              key={release.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: rIdx * 0.05 }}
            >
              <Card className={`border-border/50 ${rIdx === 0 ? "ring-1 ring-primary/30" : ""}`}>
                <button
                  onClick={() => toggleVersion(release.version)}
                  className="w-full flex items-center justify-between p-4 text-left hover:bg-muted/30 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Badge variant={rIdx === 0 ? "default" : "outline"} className="font-mono text-xs">
                      v{release.version}
                    </Badge>
                    <div>
                      <p className="font-semibold text-sm">{release.title}</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {release.date}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{release.changes.length} ცვლილება</span>
                    {canManage && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteRelease(release.id);
                        }}
                      >
                        <Trash2 className="h-3 w-3 text-destructive" />
                      </Button>
                    )}
                    {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </div>
                </button>

                {isExpanded && (
                  <CardContent className="pt-0 pb-4 px-4 space-y-2">
                    {release.highlights && (
                      <p className="text-xs text-muted-foreground bg-primary/5 p-2 rounded-md italic">
                        {release.highlights}
                      </p>
                    )}
                    {release.changes.map((change, cIdx) => {
                      const config = typeConfig[change.type] || typeConfig.feature;
                      const Icon = config.icon;
                      return (
                        <div key={change.id || cIdx} className="flex items-start gap-2">
                          <div className={`p-1 rounded ${config.bg} mt-0.5`}>
                            <Icon className={`h-3 w-3 ${config.color}`} />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm">{change.text}</p>
                          </div>
                          <Badge variant="outline" className={`text-[10px] ${config.color}`}>
                            {config.label}
                          </Badge>
                        </div>
                      );
                    })}
                  </CardContent>
                )}
              </Card>
            </motion.div>
          );
        })}

        {releases.length === 0 && (
          <Card>
            <CardContent className="flex h-32 items-center justify-center text-muted-foreground">
              ჯერ არ არის რელიზები
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
