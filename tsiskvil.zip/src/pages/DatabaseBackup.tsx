import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Download, Upload, Database, Shield, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import BackupScheduleConfig from "@/components/backup/BackupScheduleConfig";
import BackupHistory from "@/components/backup/BackupHistory";

const TABLE_GROUPS: Record<string, { label: string; tables: string[] }> = {
  hr: {
    label: "👥 თანამშრომლები & HR",
    tables: ["employees", "departments", "positions", "profiles", "user_roles", "custom_roles", "role_permissions", "organization_info", "companies"],
  },
  attendance: {
    label: "⏰ დასწრება & გრაფიკი",
    tables: ["attendance", "employee_schedules", "work_schedules", "shift_schedules", "shift_templates", "schedule_templates", "public_holidays", "office_locations", "overtime_requests"],
  },
  leave: {
    label: "🏖️ შვებულებები",
    tables: ["leave_requests", "leave_types"],
  },
  payroll: {
    label: "💰 ხელფასი & ფინანსები",
    tables: ["payroll", "payroll_details", "payroll_components", "salary_history", "compensation", "pension_payments", "deduction_types", "employee_deductions", "budget_plans", "budget_expenses", "expense_categories", "expense_requests"],
  },
  benefits: {
    label: "🎁 ბენეფიტები",
    tables: ["employee_benefits", "benefit_types", "benefit_plans", "employee_benefit_enrollments"],
  },
  documents: {
    label: "📄 დოკუმენტები & კონტრაქტები",
    tables: ["documents", "contracts", "contract_templates"],
  },
  recruitment: {
    label: "🔍 რეკრუტმენტი",
    tables: ["candidates", "job_vacancies", "job_descriptions"],
  },
  training: {
    label: "📚 ტრენინგი & განვითარება",
    tables: ["training_courses", "training_sessions", "training_enrollments", "employee_evaluations", "performance_reviews", "objectives", "key_results", "disciplinary_actions"],
  },
  other: {
    label: "📋 სხვა",
    tables: ["tasks", "announcements", "assets", "notifications", "badges", "employee_badges", "recognitions", "vehicle_requests", "business_trip_requests", "service_trips", "contacts", "deals", "support_tickets", "onboarding_templates", "onboarding_tasks", "video_tutorials"],
  },
};

export default function DatabaseBackup() {
  const [selectedTables, setSelectedTables] = useState<string[]>([]);
  const [isExporting, setIsExporting] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreResults, setRestoreResults] = useState<Record<string, any> | null>(null);

  const allTables = Object.values(TABLE_GROUPS).flatMap((g) => g.tables);

  const toggleTable = (table: string) => {
    setSelectedTables((prev) =>
      prev.includes(table) ? prev.filter((t) => t !== table) : [...prev, table]
    );
  };

  const toggleGroup = (tables: string[]) => {
    const allSelected = tables.every((t) => selectedTables.includes(t));
    if (allSelected) {
      setSelectedTables((prev) => prev.filter((t) => !tables.includes(t)));
    } else {
      setSelectedTables((prev) => [...new Set([...prev, ...tables])]);
    }
  };

  const selectAll = () => {
    if (selectedTables.length === allTables.length) {
      setSelectedTables([]);
    } else {
      setSelectedTables([...allTables]);
    }
  };

  const handleExport = async () => {
    if (selectedTables.length === 0) {
      toast.error("აირჩიეთ მინიმუმ ერთი ცხრილი");
      return;
    }

    setIsExporting(true);
    try {
      const { data, error } = await supabase.functions.invoke("database-backup", {
        body: { action: "export", tables: selectedTables },
      });

      if (error) throw error;

      // Download as JSON file
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const date = new Date().toISOString().split("T")[0];
      a.download = `talentos-backup-${date}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      const totalRows = Object.values(data.data as Record<string, any>).reduce(
        (sum: number, t: any) => sum + (t.count || 0), 0
      );
      toast.success(`ბექაფი წარმატებით ჩამოიტვირთა! (${totalRows} ჩანაწერი)`);
    } catch (err: any) {
      console.error("Export error:", err);
      toast.error("ბექაფის შექმნა ვერ მოხერხდა: " + (err.message || "Unknown error"));
    } finally {
      setIsExporting(false);
    }
  };

  const handleRestore = async () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const confirmed = window.confirm(
        "⚠️ ყურადღება!\n\nაღდგენა გადაწერს არსებულ მონაცემებს ბექაფის მონაცემებით.\n\nგსურთ გაგრძელება?"
      );
      if (!confirmed) return;

      setIsRestoring(true);
      setRestoreResults(null);
      try {
        const text = await file.text();
        const backupData = JSON.parse(text);

        if (!backupData.metadata || !backupData.data) {
          throw new Error("არასწორი ბექაფის ფაილი");
        }

        const { data, error } = await supabase.functions.invoke("database-backup", {
          body: { action: "restore", backupData },
        });

        if (error) throw error;

        setRestoreResults(data.results);
        toast.success("აღდგენა წარმატებით დასრულდა!");
      } catch (err: any) {
        console.error("Restore error:", err);
        toast.error("აღდგენა ვერ მოხერხდა: " + (err.message || "Unknown error"));
      } finally {
        setIsRestoring(false);
      }
    };
    input.click();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Database className="h-7 w-7 text-primary" />
          მონაცემთა ბექაფი
        </h1>
        <p className="text-muted-foreground mt-1">
          ექსპორტი და აღდგენა JSON ფორმატში
        </p>
      </div>

      {/* Export Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Download className="h-5 w-5" />
            ექსპორტი (ჩამოტვირთვა)
          </CardTitle>
          <CardDescription>
            აირჩიეთ ცხრილები რომელთა ბექაფიც გსურთ
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={selectAll}>
              {selectedTables.length === allTables.length ? "ყველას გაუქმება" : "ყველას არჩევა"}
            </Button>
            <Badge variant="secondary">{selectedTables.length} ცხრილი არჩეულია</Badge>
          </div>

          <div className="space-y-4">
            {Object.entries(TABLE_GROUPS).map(([key, group]) => {
              const groupSelected = group.tables.filter((t) => selectedTables.includes(t)).length;
              return (
                <div key={key} className="border rounded-lg p-3">
                  <div
                    className="flex items-center gap-2 cursor-pointer mb-2"
                    onClick={() => toggleGroup(group.tables)}
                  >
                    <Checkbox
                      checked={groupSelected === group.tables.length}
                      // indeterminate not directly supported, use visual cue
                    />
                    <span className="font-medium text-sm">{group.label}</span>
                    <Badge variant="outline" className="ml-auto text-xs">
                      {groupSelected}/{group.tables.length}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-2 ml-6">
                    {group.tables.map((table) => (
                      <label
                        key={table}
                        className="flex items-center gap-1.5 text-xs cursor-pointer hover:text-primary transition-colors"
                      >
                        <Checkbox
                          checked={selectedTables.includes(table)}
                          onCheckedChange={() => toggleTable(table)}
                        />
                        {table}
                      </label>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          <Separator />

          <Button
            onClick={handleExport}
            disabled={isExporting || selectedTables.length === 0}
            className="w-full gap-2"
            size="lg"
          >
            {isExporting ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <Download className="h-5 w-5" />
            )}
            {isExporting ? "მიმდინარეობს ექსპორტი..." : `ჩამოტვირთვა (${selectedTables.length} ცხრილი)`}
          </Button>
        </CardContent>
      </Card>

      {/* Schedule Section */}
      <BackupScheduleConfig selectedTables={selectedTables} />

      {/* Backup History */}
      <BackupHistory />

      {/* Restore Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Upload className="h-5 w-5" />
            აღდგენა (იმპორტი)
          </CardTitle>
          <CardDescription>
            ატვირთეთ ადრე ჩამოტვირთული ბექაფის ფაილი
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 flex gap-3">
            <Shield className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-semibold text-destructive">ყურადღება!</p>
              <p className="text-muted-foreground mt-1">
                აღდგენა გადაწერს არსებულ მონაცემებს. დარწმუნდით რომ სწორ ფაილს ტვირთავთ.
                რეკომენდირებულია აღდგენამდე მიმდინარე მონაცემების ბექაფის გაკეთება.
              </p>
            </div>
          </div>

          <Button
            onClick={handleRestore}
            disabled={isRestoring}
            variant="outline"
            className="w-full gap-2"
            size="lg"
          >
            {isRestoring ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <Upload className="h-5 w-5" />
            )}
            {isRestoring ? "მიმდინარეობს აღდგენა..." : "ფაილის ატვირთვა და აღდგენა"}
          </Button>

          {/* Restore Results */}
          {restoreResults && (
            <div className="space-y-2 mt-4">
              <h4 className="font-semibold text-sm">აღდგენის შედეგები:</h4>
              <div className="max-h-60 overflow-y-auto space-y-1">
                {Object.entries(restoreResults).map(([table, result]: [string, any]) => (
                  <div
                    key={table}
                    className="flex items-center justify-between text-sm py-1 px-2 rounded bg-muted/50"
                  >
                    <span className="font-mono text-xs">{table}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">
                        {result.inserted} ჩანაწერი
                      </span>
                      {result.success ? (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      ) : (
                        <AlertCircle className="h-4 w-4 text-destructive" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
