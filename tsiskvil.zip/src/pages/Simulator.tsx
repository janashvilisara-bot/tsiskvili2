import { BookOpen, Gamepad2, Download, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { InteractiveGuide } from "@/components/InteractiveGuide";
import { DemoMode } from "@/components/demo/DemoMode";
import { VideoTutorials } from "@/components/training/VideoTutorials";
import { exportComprehensiveManual } from "@/lib/exportComprehensiveManual";

const Simulator = () => {
  return (
    <div className="container mx-auto p-6 h-[calc(100vh-4rem)]">
      <Card className="h-full flex flex-col shadow-lg border-primary/10">
        <CardHeader className="border-b bg-gradient-to-r from-primary/5 to-accent/5">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl">ტრენინგ სიმულატორი</CardTitle>
              <CardDescription>
                ისწავლეთ სისტემის გამოყენება ინტერაქტიული გაიდებით და დემო რეჟიმით
              </CardDescription>
            </div>
            <Button
              onClick={exportComprehensiveManual}
              variant="outline"
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              სრული სახელმძღვანელო
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="flex-1 p-6 overflow-hidden">
          <Tabs defaultValue="interactive" className="h-full flex flex-col">
            <TabsList className="grid w-full grid-cols-3 mb-4">
              <TabsTrigger value="interactive" className="gap-2">
                <BookOpen className="h-4 w-4" />
                ინტერაქტიული გაიდი
              </TabsTrigger>
              <TabsTrigger value="demo" className="gap-2">
                <Gamepad2 className="h-4 w-4" />
                დემო რეჟიმი
              </TabsTrigger>
              <TabsTrigger value="videos" className="gap-2">
                <Video className="h-4 w-4" />
                ვიდეო ტუტორიალები
              </TabsTrigger>
            </TabsList>

            <TabsContent value="interactive" className="flex-1 overflow-auto">
              <InteractiveGuide />
            </TabsContent>

            <TabsContent value="demo" className="flex-1 overflow-auto">
              <DemoMode />
            </TabsContent>

            <TabsContent value="videos" className="flex-1 overflow-auto">
              <VideoTutorials />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default Simulator;
