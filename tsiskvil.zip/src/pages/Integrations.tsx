import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ChannelIntegrationCard from "@/components/settings/ChannelIntegrationCard";
import {
  CalendarDays,
  MessageCircle,
  MessagesSquare,
  Plug,
  Send,
  Users,
} from "lucide-react";

const Integrations = () => {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary text-primary-foreground">
              <Plug className="h-5 w-5" />
            </div>
            ინტეგრაციები
          </CardTitle>
          <CardDescription>
            შეტყობინებების არხები და კალენდრები ერთ ადგილას. შეავსეთ მონაცემები, ჩართეთ
            არხი და გაგზავნეთ სატესტო შეტყობინება.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          სანამ არხი ჩართული არ არის, სისტემა მას არ იყენებს - შეგიძლიათ ნელა, სათითაოდ
          დააკავშიროთ.
        </CardContent>
      </Card>

      <Tabs defaultValue="messaging">
        <TabsList>
          <TabsTrigger value="messaging">შეტყობინებები</TabsTrigger>
          <TabsTrigger value="calendar">კალენდრები</TabsTrigger>
        </TabsList>

        <TabsContent value="messaging" className="space-y-4 pt-4">
          <ChannelIntegrationCard
            provider="telegram"
            title="Telegram"
            description="შვებულებების, დავალებებისა და HR შეტყობინებების გაგზავნა ბოტით."
            icon={Send}
            gradient="bg-gradient-to-br from-sky-500 to-blue-600"
            testable
            docsUrl="https://core.telegram.org/bots#how-do-i-create-a-bot"
            setupHint="BotFather-ში შექმენით ბოტი, დააკოპირეთ ტოკენი და მიუთითეთ ჩატის ან ჯგუფის ID."
            fields={[
              {
                key: "bot_token",
                label: "ბოტის ტოკენი",
                placeholder: "123456:ABC-DEF...",
                secret: true,
              },
              { key: "chat_id", label: "ჩატის ID", placeholder: "-1001234567890" },
            ]}
          />

          <ChannelIntegrationCard
            provider="slack"
            title="Slack"
            description="მოთხოვნები და შეტყობინებები პირდაპირ სამუშაო არხში."
            icon={MessagesSquare}
            gradient="bg-gradient-to-br from-violet-500 to-fuchsia-600"
            testable
            docsUrl="https://api.slack.com/messaging/webhooks"
            setupHint="Slack-ში შექმენით Incoming Webhook სასურველ არხზე და ჩასვით მისი ბმული."
            fields={[
              {
                key: "webhook_url",
                label: "Webhook ბმული",
                placeholder: "https://hooks.slack.com/services/...",
                secret: true,
              },
              { key: "channel", label: "არხის სახელი (არასავალდებულო)", placeholder: "#hr" },
            ]}
          />

          <ChannelIntegrationCard
            provider="teams"
            title="Microsoft Teams"
            description="HR შეტყობინებები Teams-ის არხში."
            icon={Users}
            gradient="bg-gradient-to-br from-indigo-500 to-blue-700"
            testable
            docsUrl="https://learn.microsoft.com/microsoftteams/platform/webhooks-and-connectors/how-to/add-incoming-webhook"
            setupHint="Teams-ის არხზე დაამატეთ Incoming Webhook და ჩასვით მისი ბმული."
            fields={[
              {
                key: "webhook_url",
                label: "Webhook ბმული",
                placeholder: "https://outlook.office.com/webhook/...",
                secret: true,
              },
            ]}
          />

          <ChannelIntegrationCard
            provider="whatsapp"
            title="WhatsApp Business"
            description="ოფიციალური შეტყობინებები თანამშრომლების ნომრებზე."
            icon={MessageCircle}
            gradient="bg-gradient-to-br from-emerald-500 to-green-600"
            testable
            docsUrl="https://developers.facebook.com/docs/whatsapp/cloud-api"
            setupHint="WhatsApp Cloud API-ში აიღეთ მუდმივი ტოკენი და ნომრის ID."
            fields={[
              {
                key: "access_token",
                label: "წვდომის ტოკენი",
                placeholder: "EAAG...",
                secret: true,
              },
              { key: "phone_number_id", label: "ნომრის ID", placeholder: "1234567890" },
              {
                key: "default_recipient",
                label: "სატესტო მიმღების ნომერი",
                placeholder: "995555123456",
                hint: "საერთაშორისო ფორმატით, პლიუსის გარეშე.",
              },
            ]}
          />
        </TabsContent>

        <TabsContent value="calendar" className="space-y-4 pt-4">
          <ChannelIntegrationCard
            provider="outlook_calendar"
            title="Outlook კალენდარი"
            description="შვებულებები და შეხვედრები Outlook-ის კალენდარში."
            icon={CalendarDays}
            gradient="bg-gradient-to-br from-blue-500 to-cyan-600"
            docsUrl="https://learn.microsoft.com/graph/auth-v2-service"
            setupHint="Azure-ში დაარეგისტრირეთ აპლიკაცია და მიუთითეთ მისი მონაცემები."
            fields={[
              { key: "tenant_id", label: "Tenant ID", placeholder: "00000000-0000-..." },
              { key: "client_id", label: "Client ID", placeholder: "00000000-0000-..." },
              { key: "client_secret", label: "Client Secret", secret: true },
              {
                key: "calendar_user",
                label: "კალენდრის მფლობელი (ელფოსტა)",
                placeholder: "hr@company.ge",
              },
            ]}
          />

          <ChannelIntegrationCard
            provider="google_calendar"
            title="Google Calendar"
            description="შვებულებებისა და შეხვედრების სინქრონიზაცია Google კალენდართან."
            icon={CalendarDays}
            gradient="bg-gradient-to-br from-amber-500 to-orange-600"
            docsUrl="https://developers.google.com/calendar/api/guides/overview"
            setupHint="Google Cloud-ში შექმენით სერვისის ანგარიში და გაუზიარეთ კალენდარი."
            fields={[
              {
                key: "calendar_id",
                label: "კალენდრის ID",
                placeholder: "company.ge_xxx@group.calendar.google.com",
              },
              {
                key: "service_account_email",
                label: "სერვისის ანგარიშის ელფოსტა",
                placeholder: "calendar@project.iam.gserviceaccount.com",
              },
              { key: "private_key", label: "პირადი გასაღები", secret: true },
            ]}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Integrations;
