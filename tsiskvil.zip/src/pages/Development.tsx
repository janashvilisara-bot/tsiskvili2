import { useState, useEffect } from "react";
import { useFeatureLock, FeatureLockOverlay } from "@/components/FeatureCardLock";
import { 
  GraduationCap,
  CreditCard,
  Star,
  BarChart3,
  Lightbulb,
  ArrowRight,
  Sparkles,
  TrendingUp,
  Award,
  ArrowUpRight,
  ArrowDownRight,
  Users,
  Target,
  Trophy
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import HubErrorState from "@/components/HubErrorState";
import { cn } from "@/lib/utils";

interface DevelopmentStats {
  activeTrainings: number;
  completedEvaluations: number;
  recognitionsGiven: number;
  activeSurveys: number;
}

export default function Development() {
  const navigate = useNavigate();
  const { isLocked, handleLockedClick } = useFeatureLock();
  const [stats, setStats] = useState<DevelopmentStats>({
    activeTrainings: 0,
    completedEvaluations: 0,
    recognitionsGiven: 0,
    activeSurveys: 0
  });
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState(false);

  useEffect(() => {
    fetchDevelopmentStats();
  }, []);

  const fetchDevelopmentStats = async () => {
    try {
      // Fetch completed evaluations
      const { count: evalCount } = await supabase
        .from('employee_evaluations')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'completed');

      // Fetch recognitions
      const { count: recognitionCount } = await supabase
        .from('recognitions')
        .select('*', { count: 'exact', head: true });

      setStats({
        activeTrainings: 5, // Static value since table might not exist
        completedEvaluations: evalCount || 0,
        recognitionsGiven: recognitionCount || 0,
        activeSurveys: 2 // Static value since table might not exist
      });
    } catch (error) {
      console.error('Error fetching development stats:', error);
      setFetchError(true);
    } finally {
      setLoading(false);
    }
  };

  const quickStats = [
    {
      title: "აქტიური ტრენინგები",
      value: stats.activeTrainings.toString(),
      icon: GraduationCap,
      color: "from-lime-500 to-green-600",
      bgColor: "bg-lime-500/10",
      trend: "+5",
      trendUp: true,
      description: "პროგრამა"
    },
    {
      title: "დასრულებული შეფასებები",
      value: stats.completedEvaluations.toString(),
      icon: CreditCard,
      color: "from-emerald-500 to-teal-600",
      bgColor: "bg-emerald-500/10",
      trend: "+28%",
      trendUp: true,
      description: "შეფასება"
    },
    {
      title: "აღიარებები",
      value: stats.recognitionsGiven.toString(),
      icon: Trophy,
      color: "from-amber-500 to-yellow-600",
      bgColor: "bg-amber-500/10",
      trend: "+15",
      trendUp: true,
      description: "ჯილდო"
    },
    {
      title: "აქტიური კვლევები",
      value: stats.activeSurveys.toString(),
      icon: BarChart3,
      color: "from-cyan-500 to-blue-600",
      bgColor: "bg-cyan-500/10",
      trend: stats.activeSurveys > 0 ? "მიმდინარე" : "არ არის",
      trendUp: stats.activeSurveys > 0,
      description: "კვლევა"
    }
  ];

  const categories = [
    {
      title: "ძირითადი ფუნქციები",
      description: "თანამშრომლების განვითარებისა და ტრენინგის სერვისები",
      icon: GraduationCap,
      color: "from-lime-400 via-green-500 to-emerald-500",
      shadowColor: "shadow-green-500/25",
      functions: [
        { 
          name: "ტრენინგები", 
          description: "სასწავლო პროგრამები და ტრენინგების მართვა",
          url: "/training",
          icon: GraduationCap,
          stats: `${stats.activeTrainings} აქტიური`
        },
        { 
          name: "შეფასებები", 
          description: "თანამშრომლების შეფასების სისტემა",
          url: "/employee-evaluations",
          icon: CreditCard,
          stats: `${stats.completedEvaluations} დასრულებული`
        },
        { 
          name: "აღიარება", 
          description: "წახალისება და მიღწევების აღიარება",
          url: "/recognition",
          icon: Star,
          stats: `${stats.recognitionsGiven} ჯილდო`
        },
        { 
          name: "კვლევები", 
          description: "პულსური გამოკითხვები და ანალიტიკა",
          url: "/pulse-surveys",
          icon: BarChart3,
          stats: `${stats.activeSurveys} აქტიური`
        },
      ]
    },
    {
      title: "დამატებითი ინსტრუმენტები",
      description: "მიზნები და უკუკავშირი",
      icon: TrendingUp,
      color: "from-teal-400 via-cyan-500 to-blue-500",
      shadowColor: "shadow-cyan-500/25",
      functions: [
        { 
          name: "OKR / KPI", 
          description: "მიზნების დასახვა და შესრულების მონიტორინგი",
          url: "/okr",
          icon: Award,
          stats: "მიზნები"
        },
        { 
          name: "წუწუნის დაფა", 
          description: "იდეები და უკუკავშირის მართვა",
          url: "/feedback",
          icon: Lightbulb,
          stats: "უკუკავშირი"
        },
      ]
    }
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {fetchError && <HubErrorState onRetry={fetchDevelopmentStats} />}
          {/* Header */}
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-lime-400 via-green-500 to-emerald-500 shadow-xl shadow-green-500/30 animate-scale-in">
                <GraduationCap className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-foreground via-foreground/90 to-foreground/70 bg-clip-text text-transparent">
                  განვითარება
                </h1>
                <p className="text-muted-foreground mt-1 text-lg">
                  თანამშრომლების განვითარებისა და სწავლების მართვის სისტემა
                </p>
              </div>
            </div>
          </div>

          {/* Quick Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {quickStats.map((stat, index) => (
              <Card 
                key={index}
                className={cn(
                  "group relative overflow-hidden border-border/50 bg-card/80 backdrop-blur-xl",
                  "hover:shadow-2xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-2",
                  "animate-fade-in"
                )}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <CardContent className="p-6 relative">
                  <div className="flex items-start justify-between mb-4">
                    <div className={cn(
                      "p-3 rounded-xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-3",
                      stat.bgColor
                    )}>
                      <stat.icon className="h-6 w-6" style={{ color: `hsl(var(--primary))` }} />
                    </div>
                    
                    <div className={cn(
                      "flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full transition-all duration-300",
                      stat.trendUp 
                        ? "text-emerald-600 bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-400" 
                        : "text-amber-600 bg-amber-100 dark:bg-amber-950/50 dark:text-amber-400"
                    )}>
                      {stat.trendUp ? (
                        <ArrowUpRight className="h-3 w-3" />
                      ) : (
                        <ArrowDownRight className="h-3 w-3" />
                      )}
                      <span>{stat.trend}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-2xl md:text-3xl font-bold tracking-tight group-hover:scale-105 transition-transform duration-300 origin-left">
                      {loading ? (
                        <div className="h-8 w-16 bg-muted animate-pulse rounded" />
                      ) : (
                        stat.value
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground font-medium">
                      {stat.title}
                    </div>
                    <div className="text-xs text-muted-foreground/70">
                      {stat.description}
                    </div>
                  </div>

                  <div className={cn(
                    "absolute -right-8 -bottom-8 w-32 h-32 rounded-full blur-3xl opacity-0 group-hover:opacity-30 transition-opacity duration-500",
                    `bg-gradient-to-br ${stat.color}`
                  )} />
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Categories */}
          <div className="space-y-10">
            {categories.map((category, idx) => (
              <div 
                key={idx} 
                className="space-y-6 animate-fade-in"
                style={{ animationDelay: `${(idx + 4) * 100}ms` }}
              >
                {/* Category Header */}
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "p-3 rounded-xl bg-gradient-to-br shadow-xl",
                    category.color,
                    category.shadowColor
                  )}>
                    <category.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl md:text-3xl font-bold text-foreground">{category.title}</h2>
                    <p className="text-sm text-muted-foreground">{category.description}</p>
                  </div>
                </div>

                {/* Function Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
                  {category.functions.map((func, funcIdx) => (
                    <Card
                      key={funcIdx}
                      className={cn(
                        "group cursor-pointer overflow-hidden",
                        "border-border/50 bg-card/80 backdrop-blur-xl",
                        "hover:border-primary/50 transition-all duration-500",
                        "hover:shadow-2xl hover:-translate-y-2",
                        "animate-fade-in"
                      )}
                      style={{ animationDelay: `${(idx * 4 + funcIdx + 5) * 50}ms` }}
                      onClick={(e) => isLocked(func.url) ? handleLockedClick(e) : navigate(func.url)}
                    >
                      {isLocked(func.url) && <FeatureLockOverlay />}
                      <CardHeader className={cn(
                        "bg-gradient-to-br text-white pb-4 relative overflow-hidden",
                        category.color
                      )}>
                        <div className="flex items-center gap-3 relative z-10">
                          <div className="p-2.5 bg-white/20 rounded-xl backdrop-blur-sm group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                            <func.icon className="h-5 w-5" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{func.name}</CardTitle>
                            <span className="text-xs text-white/80">{func.stats}</span>
                          </div>
                        </div>
                        
                        <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700" />
                        <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white/5 rounded-full group-hover:scale-125 transition-transform duration-500" />
                      </CardHeader>
                      
                      <CardContent className="pt-6 relative">
                        <CardDescription className="text-muted-foreground mb-4 min-h-[48px] leading-relaxed">
                          {func.description}
                        </CardDescription>
                        
                        <div className="flex items-center gap-2 text-primary font-semibold text-sm group-hover:gap-4 transition-all duration-300">
                          <span>გახსნა</span>
                          <ArrowRight className="h-4 w-4 group-hover:translate-x-2 transition-transform duration-300" />
                        </div>

                        <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Enhanced Footer Stats */}
          <div 
            className="mt-12 p-6 md:p-8 rounded-2xl bg-gradient-to-r from-primary/5 via-primary/10 to-accent/10 border border-primary/20 backdrop-blur-xl animate-fade-in"
            style={{ animationDelay: '800ms' }}
          >
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-primary/10 animate-pulse">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-lg font-semibold text-foreground">
                    სულ ხელმისაწვდომია <span className="text-2xl font-bold text-primary">{categories.reduce((sum, cat) => sum + cat.functions.length, 0)}</span> განვითარების ფუნქცია
                  </p>
                  <p className="text-sm text-muted-foreground">
                    განავითარეთ თქვენი გუნდის პოტენციალი
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/10 text-green-600 dark:text-green-400">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-sm font-medium">{stats.activeTrainings} აქტიური ტრენინგი</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
