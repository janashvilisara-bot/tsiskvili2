import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { useLanguage } from "@/contexts/LanguageContext";

const NotFound = () => {
  const location = useLocation();
  const { t } = useLanguage();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen items-center justify-center relative overflow-hidden">
      <div className="fixed inset-0 -z-10" style={{ background: 'var(--gradient-mesh)' }} />
      <div className="fixed inset-0 -z-10 bg-background/95 backdrop-blur-3xl" />
      
      <div className="text-center space-y-6 animate-fade-in p-8">
        <div className="relative">
          <h1 className="text-9xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent animate-float">
            {t('notFound.title')}
          </h1>
          <div className="absolute inset-0 blur-3xl opacity-30 bg-gradient-to-r from-primary via-accent to-secondary -z-10" />
        </div>
        
        <p className="text-2xl font-medium text-muted-foreground">{t('notFound.message')}</p>
        <p className="text-muted-foreground max-w-md mx-auto">
          {t('notFound.description')}
        </p>
        
        <Link 
          to="/" 
          className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-primary to-accent text-primary-foreground rounded-lg font-medium hover:shadow-glow hover:scale-105 transition-all duration-300"
        >
          <span>{t('notFound.backHome')}</span>
          <span className="text-xl">→</span>
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
