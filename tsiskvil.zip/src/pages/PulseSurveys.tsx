import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Plus, BarChart3, Users, MessageSquare, Trash2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";

interface Survey {
  id: string;
  survey_title: string;
  description: string;
  survey_type: string;
  frequency: string;
  target_audience: string;
  department: string;
  questions: any[];
  is_anonymous: boolean;
  status: string;
  start_date: string;
  end_date: string;
  created_at: string;
}

interface SurveyResponse {
  id: string;
  survey_id: string;
  responses: any;
  submitted_at: string;
}

export default function PulseSurveys() {
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [responses, setResponses] = useState<SurveyResponse[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [selectedSurvey, setSelectedSurvey] = useState<Survey | null>(null);
  const [formData, setFormData] = useState({
    survey_title: "",
    description: "",
    survey_type: "pulse",
    frequency: "monthly",
    target_audience: "all",
    department: "",
    is_anonymous: true,
    start_date: "",
    end_date: "",
    questions: [{ question: "", type: "rating" }],
  });

  useEffect(() => {
    fetchSurveys();
  }, []);

  const fetchSurveys = async () => {
    const { data, error } = await supabase
      .from("wellness_surveys" as any)
      .select("*")
      .order("created_at", { ascending: false });
    
    if (error) {
      toast.error("შეცდომა კვლევების ჩატვირთვისას");
    } else {
      const mapped = (data || []).map((row: any) => ({
        id: row.id,
        survey_title: row.title,
        description: row.description,
        survey_type: row.survey_type,
        frequency: "monthly",
        target_audience: "all",
        department: "",
        questions: row.questions || [],
        is_anonymous: !!row.is_anonymous,
        status: row.is_active ? "active" : "draft",
        start_date: row.start_date,
        end_date: row.end_date,
        created_at: row.created_at,
      })) as Survey[];
      setSurveys(mapped);
    }
    setLoading(false);
  };

  const fetchResponses = async (surveyId: string) => {
    const { data, error } = await supabase
      .from("wellness_survey_responses" as any)
      .select("*")
      .eq("survey_id", surveyId);
    
    if (error) {
      toast.error("შეცდომა პასუხების ჩატვირთვისას");
    } else {
      setResponses(data as any || []);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { error } = await supabase
      .from("wellness_surveys" as any)
      .insert([
        {
          title: formData.survey_title,
          description: formData.description,
          survey_type: formData.survey_type,
          questions: formData.questions,
          is_anonymous: formData.is_anonymous,
          start_date: formData.start_date || null,
          end_date: formData.end_date || null,
          is_active: false,
        } as any,
      ]);

    if (error) {
      toast.error("შეცდომა კვლევის შექმნისას");
    } else {
      toast.success("კვლევა წარმატებით შეიქმნა");
      fetchSurveys();
      setIsDialogOpen(false);
      resetForm();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("დარწმუნებული ხართ?")) return;

    const { error} = await supabase
      .from("wellness_surveys" as any)
      .delete()
      .eq("id", id);

    if (error) {
      toast.error("შეცდომა წაშლისას");
    } else {
      toast.success("წარმატებით წაიშალა");
      fetchSurveys();
    }
  };

  const updateStatus = async (id: string, status: string) => {
    const { error } = await supabase
      .from("wellness_surveys" as any)
      .update({ is_active: status === "active" })
      .eq("id", id);

    if (error) {
      toast.error("შეცდომა სტატუსის შეცვლისას");
    } else {
      toast.success("სტატუსი შეიცვალა");
      fetchSurveys();
    }
  };

  const resetForm = () => {
    setFormData({
      survey_title: "",
      description: "",
      survey_type: "pulse",
      frequency: "monthly",
      target_audience: "all",
      department: "",
      is_anonymous: true,
      start_date: "",
      end_date: "",
      questions: [{ question: "", type: "rating" }],
    });
  };

  const addQuestion = () => {
    setFormData({
      ...formData,
      questions: [...formData.questions, { question: "", type: "rating" }],
    });
  };

  const removeQuestion = (index: number) => {
    const newQuestions = formData.questions.filter((_, i) => i !== index);
    setFormData({ ...formData, questions: newQuestions });
  };

  const updateQuestion = (index: number, field: string, value: string) => {
    const newQuestions = [...formData.questions];
    newQuestions[index] = { ...newQuestions[index], [field]: value };
    setFormData({ ...formData, questions: newQuestions });
  };

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: "default" | "secondary" | "destructive" | "outline" } = {
      draft: "outline",
      active: "default",
      closed: "secondary",
    };
    return <Badge variant={variants[status] || "outline"}>{status}</Badge>;
  };

  const viewResults = (survey: Survey) => {
    setSelectedSurvey(survey);
    fetchResponses(survey.id);
  };

  return (
    <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Pulse Surveys</h1>
            <p className="text-muted-foreground mt-2">თანამშრომლების აზრის კვლევა და ანალიზი</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm}>
                <Plus className="mr-2 h-4 w-4" />
                ახალი კვლევა
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>ახალი კვლევის შექმნა</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="survey_title">კვლევის დასახელება *</Label>
                    <Input
                      id="survey_title"
                      value={formData.survey_title}
                      onChange={(e) => setFormData({ ...formData, survey_title: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="survey_type">ტიპი *</Label>
                    <Select
                      value={formData.survey_type}
                      onValueChange={(value) => setFormData({ ...formData, survey_type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pulse">Pulse Survey</SelectItem>
                        <SelectItem value="engagement">ჩართულობა</SelectItem>
                        <SelectItem value="exit">Exit Interview</SelectItem>
                        <SelectItem value="onboarding">Onboarding Feedback</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">აღწერა</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={2}
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="frequency">სიხშირე</Label>
                    <Select
                      value={formData.frequency}
                      onValueChange={(value) => setFormData({ ...formData, frequency: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="weekly">კვირეული</SelectItem>
                        <SelectItem value="biweekly">ორკვირეული</SelectItem>
                        <SelectItem value="monthly">ყოველთვიური</SelectItem>
                        <SelectItem value="quarterly">კვარტალური</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="target_audience">აუდიტორია</Label>
                    <Select
                      value={formData.target_audience}
                      onValueChange={(value) => setFormData({ ...formData, target_audience: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">ყველა</SelectItem>
                        <SelectItem value="department">დეპარტამენტი</SelectItem>
                        <SelectItem value="team">გუნდი</SelectItem>
                        <SelectItem value="specific">კონკრეტული</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="department">დეპარტამენტი</Label>
                    <Input
                      id="department"
                      value={formData.department}
                      onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                      placeholder="არჩევითი"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="start_date">დაწყების თარიღი</Label>
                    <Input
                      id="start_date"
                      type="date"
                      value={formData.start_date}
                      onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end_date">დასრულების თარიღი</Label>
                    <Input
                      id="end_date"
                      type="date"
                      value={formData.end_date}
                      onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_anonymous"
                    checked={formData.is_anonymous}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_anonymous: checked })}
                  />
                  <Label htmlFor="is_anonymous">ანონიმური კვლევა</Label>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <Label>კითხვები</Label>
                    <Button type="button" variant="outline" size="sm" onClick={addQuestion}>
                      <Plus className="h-4 w-4 mr-1" />
                      დამატება
                    </Button>
                  </div>
                  {formData.questions.map((q, index) => (
                    <Card key={index} className="p-4">
                      <div className="space-y-3">
                        <div className="flex gap-3">
                          <div className="flex-1 space-y-2">
                            <Label>კითხვა {index + 1}</Label>
                            <Input
                              value={q.question}
                              onChange={(e) => updateQuestion(index, "question", e.target.value)}
                              placeholder="შეიყვანეთ კითხვა"
                              required
                            />
                          </div>
                          <div className="w-40 space-y-2">
                            <Label>ტიპი</Label>
                            <Select
                              value={q.type}
                              onValueChange={(value) => updateQuestion(index, "type", value)}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="rating">რეიტინგი (1-5)</SelectItem>
                                <SelectItem value="text">ტექსტი</SelectItem>
                                <SelectItem value="yes_no">კი/არა</SelectItem>
                                <SelectItem value="multiple">მრავალარჩევანი</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          {formData.questions.length > 1 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => removeQuestion(index)}
                              className="mt-7"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    გაუქმება
                  </Button>
                  <Button type="submit">შექმნა</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Tabs defaultValue="surveys">
          <TabsList>
            <TabsTrigger value="surveys">კვლევები</TabsTrigger>
            <TabsTrigger value="results">შედეგები</TabsTrigger>
          </TabsList>

          <TabsContent value="surveys" className="space-y-4">
            <div className="grid gap-4">
              {surveys.length === 0 ? (
                <Card className="p-8 text-center">
                  <MessageSquare className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">კვლევები არ მოიძებნა</p>
                </Card>
              ) : (
                surveys.map((survey) => (
                  <Card key={survey.id} className="p-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-xl font-semibold">{survey.survey_title}</h3>
                          {getStatusBadge(survey.status)}
                          {survey.is_anonymous && (
                            <Badge variant="outline">ანონიმური</Badge>
                          )}
                        </div>
                        <p className="text-muted-foreground mb-4">{survey.description}</p>
                        <div className="flex gap-4 text-sm text-muted-foreground">
                          <span>ტიპი: {survey.survey_type}</span>
                          <span>სიხშირე: {survey.frequency}</span>
                          <span>აუდიტორია: {survey.target_audience}</span>
                          {survey.start_date && (
                            <span>თარიღი: {new Date(survey.start_date).toLocaleDateString('ka-GE')}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {survey.status === "draft" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateStatus(survey.id, "active")}
                          >
                            გააქტიურება
                          </Button>
                        )}
                        {survey.status === "active" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateStatus(survey.id, "closed")}
                          >
                            დახურვა
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => viewResults(survey)}
                        >
                          <BarChart3 className="h-4 w-4 mr-1" />
                          შედეგები
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(survey.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="results" className="space-y-4">
            {selectedSurvey ? (
              <div className="space-y-6">
                <Card className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{selectedSurvey.survey_title}</h3>
                  <div className="flex gap-6 text-sm">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      <span>პასუხები: {responses.length}</span>
                    </div>
                  </div>
                </Card>

                {responses.length === 0 ? (
                  <Card className="p-8 text-center">
                    <BarChart3 className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">პასუხები ჯერ არ მოიძებნა</p>
                  </Card>
                ) : (
                  <Card className="p-6">
                    <h4 className="font-semibold mb-4">შედეგების ანალიზი</h4>
                    <p className="text-sm text-muted-foreground">
                      სრული ანალიტიკა მალე იქნება ხელმისაწვდომი
                    </p>
                  </Card>
                )}
              </div>
            ) : (
              <Card className="p-8 text-center">
                <BarChart3 className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">აირჩიეთ კვლევა შედეგების სანახავად</p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
  );
}