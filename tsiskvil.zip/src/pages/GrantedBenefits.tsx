import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Award, Download, Search } from "lucide-react";
import { format } from "date-fns";
import * as XLSX from "xlsx";

const CATEGORY_LABELS: Record<string, string> = {
  benefit: "ბენეფიტი",
  service: "სერვისი",
  equipment: "ტექნიკა",
  other: "სხვა",
};

interface Row {
  id: string;
  amount: number | null;
  start_date: string | null;
  end_date: string | null;
  is_active: boolean;
  notes: string | null;
  service_category: string;
  granted_at: string | null;
  employee: { id: string; full_name: string; department: string | null; branch_id: string | null } | null;
  benefit_type: { name: string; name_ka: string | null } | null;
}

export default function GrantedBenefits() {
  const [rows, setRows] = useState<Row[]>([]);
  const [departments, setDepartments] = useState<string[]>([]);
  const [branches, setBranches] = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState("all");
  const [branch, setBranch] = useState("all");
  const [category, setCategory] = useState("all");
  const [status, setStatus] = useState("all");

  useEffect(() => {
    (async () => {
      setLoading(true);
      const [b, br] = await Promise.all([
        supabase
          .from("employee_benefits")
          .select(
            "id, amount, start_date, end_date, is_active, notes, service_category, granted_at, employee:employees(id, full_name, department, branch_id), benefit_type:benefit_types(name, name_ka)"
          )
          .order("granted_at", { ascending: false }),
        supabase.from("branches").select("id, name").eq("is_active", true).order("name"),
      ]);
      if (!b.error) {
        const data = (b.data as any) || [];
        setRows(data);
        setDepartments(
          Array.from(new Set(data.map((r: any) => r.employee?.department).filter(Boolean))) as string[]
        );
      }
      if (!br.error) setBranches((br.data as any) || []);
      setLoading(false);
    })();
  }, []);

  const filtered = useMemo(() => {
    return rows.filter((r) => {
      if (search && !r.employee?.full_name.toLowerCase().includes(search.toLowerCase())) return false;
      if (department !== "all" && r.employee?.department !== department) return false;
      if (branch !== "all" && r.employee?.branch_id !== branch) return false;
      if (category !== "all" && r.service_category !== category) return false;
      if (status === "active" && !r.is_active) return false;
      if (status === "ended" && r.is_active) return false;
      return true;
    });
  }, [rows, search, department, branch, category, status]);

  const totals = useMemo(() => {
    const total = filtered.reduce((s, r) => s + (r.amount || 0), 0);
    const active = filtered.filter((r) => r.is_active).length;
    return { count: filtered.length, total, active };
  }, [filtered]);

  const handleExport = () => {
    const data = filtered.map((r) => ({
      "თანამშრომელი": r.employee?.full_name || "",
      "დეპარტამენტი": r.employee?.department || "",
      "ტიპი": r.benefit_type?.name_ka || r.benefit_type?.name || "",
      "კატეგორია": CATEGORY_LABELS[r.service_category] || r.service_category,
      "თანხა (₾)": r.amount ?? "",
      "დაწყება": r.start_date ? format(new Date(r.start_date), "dd/MM/yyyy") : "",
      "დასრულება": r.end_date ? format(new Date(r.end_date), "dd/MM/yyyy") : "",
      "სტატუსი": r.is_active ? "აქტიური" : "დასრულებული",
      "შენიშვნა": r.notes || "",
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "გაცემული ბენეფიტები");
    XLSX.writeFile(wb, `granted-benefits-${format(new Date(), "yyyy-MM-dd")}.xlsx`);
  };

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-primary to-primary/80 shadow-lg">
              <Award className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">გაცემული ბენეფიტები / სერვისები</h1>
              <p className="text-muted-foreground">
                მონიტორინგი - ვის რა ბენეფიტი/სერვისი/ტექნიკა აქვს გაცემული
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">სულ ჩანაწერი</p>
                <p className="text-2xl font-bold">{totals.count}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">აქტიური</p>
                <p className="text-2xl font-bold text-emerald-600">{totals.active}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">ჯამური თანხა</p>
                <p className="text-2xl font-bold">{totals.total.toFixed(2)} ₾</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <CardTitle>სია</CardTitle>
              <Button onClick={handleExport} variant="outline">
                <Download className="h-4 w-4 mr-2" /> Excel
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                <div className="relative">
                  <Search className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
                  <Input
                    placeholder="თანამშრომელი..."
                    className="pl-9"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <Select value={department} onValueChange={setDepartment}>
                  <SelectTrigger>
                    <SelectValue placeholder="დეპარტამენტი" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                    {departments.map((d) => (
                      <SelectItem key={d} value={d}>
                        {d}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={branch} onValueChange={setBranch}>
                  <SelectTrigger>
                    <SelectValue placeholder="ფილიალი" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა ფილიალი</SelectItem>
                    {branches.map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {b.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="კატეგორია" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა კატეგორია</SelectItem>
                    {Object.entries(CATEGORY_LABELS).map(([k, v]) => (
                      <SelectItem key={k} value={k}>
                        {v}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="სტატუსი" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა სტატუსი</SelectItem>
                    <SelectItem value="active">აქტიური</SelectItem>
                    <SelectItem value="ended">დასრულებული</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="rounded-md border overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>დეპარტამენტი</TableHead>
                      <TableHead>ტიპი</TableHead>
                      <TableHead>კატეგორია</TableHead>
                      <TableHead>თანხა</TableHead>
                      <TableHead>პერიოდი</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                          იტვირთება...
                        </TableCell>
                      </TableRow>
                    ) : filtered.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                          ჩანაწერი არ მოიძებნა
                        </TableCell>
                      </TableRow>
                    ) : (
                      filtered.map((r) => (
                        <TableRow key={r.id}>
                          <TableCell className="font-medium">{r.employee?.full_name || "-"}</TableCell>
                          <TableCell>{r.employee?.department || "-"}</TableCell>
                          <TableCell>{r.benefit_type?.name_ka || r.benefit_type?.name || "-"}</TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {CATEGORY_LABELS[r.service_category] || r.service_category}
                            </Badge>
                          </TableCell>
                          <TableCell>{r.amount != null ? `${r.amount} ₾` : "-"}</TableCell>
                          <TableCell className="text-sm">
                            {r.start_date ? format(new Date(r.start_date), "dd/MM/yyyy") : "-"}
                            {r.end_date && ` - ${format(new Date(r.end_date), "dd/MM/yyyy")}`}
                          </TableCell>
                          <TableCell>
                            {r.is_active ? (
                              <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-500/30">
                                აქტიური
                              </Badge>
                            ) : (
                              <Badge variant="secondary">დასრულებული</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageTransition>
  );
}
