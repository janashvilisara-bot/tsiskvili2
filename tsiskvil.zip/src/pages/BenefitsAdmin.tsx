
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Plus, Edit, Trash2, Shield, Building2 } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import InsuranceCompaniesTab from "@/components/benefits/InsuranceCompaniesTab";

interface BenefitPlan {
  id: string;
  plan_name: string;
  plan_type: string;
  provider_name: string;
  provider_contact: string;
  coverage_details: string;
  employee_contribution: number;
  employer_contribution: number;
  is_active: boolean;
  enrollment_start_date: string;
  enrollment_end_date: string;
  coverage_start_date: string;
  coverage_end_date: string;
  eligibility_criteria: string;
}

export default function BenefitsAdmin() {
  const [plans, setPlans] = useState<BenefitPlan[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<BenefitPlan | null>(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    plan_name: "",
    plan_type: "health",
    provider_name: "",
    provider_contact: "",
    coverage_details: "",
    employee_contribution: 0,
    employer_contribution: 0,
    enrollment_start_date: "",
    enrollment_end_date: "",
    coverage_start_date: "",
    coverage_end_date: "",
    eligibility_criteria: "",
    is_active: true,
  });

  useEffect(() => {
    fetchPlans();
  }, []);

  const fetchPlans = async () => {
    const { data, error } = await supabase
      .from("benefit_plans")
      .select("*")
      .order("plan_name");
    
    if (error) {
      console.error("Error fetching benefit plans:", error);
      toast.error("შეცდომა სარგებლების ჩატვირთვისას");
    } else {
      setPlans(data || []);
    }
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (editingPlan) {
      const { error } = await supabase
        .from("benefit_plans")
        .update(formData)
        .eq("id", editingPlan.id);

      if (error) {
        console.error("Update error:", error);
        toast.error("შეცდომა განახლებისას: " + error.message);
      } else {
        toast.success("წარმატებით განახლდა");
        fetchPlans();
        setIsDialogOpen(false);
        resetForm();
      }
    } else {
      const { error } = await supabase
        .from("benefit_plans")
        .insert([formData]);

      if (error) {
        console.error("Insert error:", error);
        toast.error("შეცდომა შექმნისას: " + error.message);
      } else {
        toast.success("წარმატებით შეიქმნა");
        fetchPlans();
        setIsDialogOpen(false);
        resetForm();
      }
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("დარწმუნებული ხართ?")) return;

    const { error } = await supabase
      .from("benefit_plans")
      .delete()
      .eq("id", id);

    if (error) {
      console.error("Delete error:", error);
      toast.error("შეცდომა წაშლისას: " + error.message);
    } else {
      toast.success("წარმატებით წაიშალა");
      fetchPlans();
    }
  };

  const handleEdit = (plan: BenefitPlan) => {
    setEditingPlan(plan);
    setFormData({
      plan_name: plan.plan_name,
      plan_type: plan.plan_type,
      provider_name: plan.provider_name || "",
      provider_contact: plan.provider_contact || "",
      coverage_details: plan.coverage_details || "",
      employee_contribution: plan.employee_contribution,
      employer_contribution: plan.employer_contribution,
      enrollment_start_date: plan.enrollment_start_date || "",
      enrollment_end_date: plan.enrollment_end_date || "",
      coverage_start_date: plan.coverage_start_date || "",
      coverage_end_date: plan.coverage_end_date || "",
      eligibility_criteria: plan.eligibility_criteria || "",
      is_active: plan.is_active,
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setEditingPlan(null);
    setFormData({
      plan_name: "",
      plan_type: "health",
      provider_name: "",
      provider_contact: "",
      coverage_details: "",
      employee_contribution: 0,
      employer_contribution: 0,
      enrollment_start_date: "",
      enrollment_end_date: "",
      coverage_start_date: "",
      coverage_end_date: "",
      eligibility_criteria: "",
      is_active: true,
    });
  };

  const toggleActive = async (id: string, currentStatus: boolean) => {
    const { error } = await supabase
      .from("benefit_plans")
      .update({ is_active: !currentStatus })
      .eq("id", id);

    if (error) {
      console.error("Toggle error:", error);
      toast.error("შეცდომა სტატუსის შეცვლისას: " + error.message);
    } else {
      toast.success("სტატუსი შეიცვალა");
      fetchPlans();
    }
  };

  return (
      
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">სარგებლების ადმინისტრირება</h1>
          <p className="text-muted-foreground mt-2">Benefit Plans და სადაზღვევო კომპანიების მართვა</p>
        </div>

        <Tabs defaultValue="plans" className="space-y-4">
          <TabsList>
            <TabsTrigger value="plans">Benefit Plans</TabsTrigger>
            <TabsTrigger value="insurance" className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              სადაზღვევო კომპანიები
            </TabsTrigger>
          </TabsList>

          <TabsContent value="plans" className="space-y-4">
            <div className="flex justify-end">
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={resetForm}>
                    <Plus className="mr-2 h-4 w-4" />
                    ახალი Benefit Plan
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>
                      {editingPlan ? "Benefit Plan-ის რედაქტირება" : "ახალი Benefit Plan"}
                    </DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="plan_name">გეგმის დასახელება *</Label>
                        <Input
                          id="plan_name"
                          value={formData.plan_name}
                          onChange={(e) => setFormData({ ...formData, plan_name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="plan_type">ტიპი *</Label>
                        <Select
                          value={formData.plan_type}
                          onValueChange={(value) => setFormData({ ...formData, plan_type: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="health">ჯანდაცვა</SelectItem>
                            <SelectItem value="pension">პენსია</SelectItem>
                            <SelectItem value="life_insurance">სიცოცხლის დაზღვევა</SelectItem>
                            <SelectItem value="dental">სტომატოლოგია</SelectItem>
                            <SelectItem value="vision">მხედველობა</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="provider_name">პროვაიდერი</Label>
                        <Input
                          id="provider_name"
                          value={formData.provider_name}
                          onChange={(e) => setFormData({ ...formData, provider_name: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="provider_contact">პროვაიდერის კონტაქტი</Label>
                        <Input
                          id="provider_contact"
                          value={formData.provider_contact}
                          onChange={(e) => setFormData({ ...formData, provider_contact: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="coverage_details">დაფარვის დეტალები</Label>
                      <Textarea
                        id="coverage_details"
                        value={formData.coverage_details}
                        onChange={(e) => setFormData({ ...formData, coverage_details: e.target.value })}
                        rows={3}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="employee_contribution">თანამშრომლის წილი (₾)</Label>
                        <Input
                          id="employee_contribution"
                          type="number"
                          value={formData.employee_contribution}
                          onChange={(e) => setFormData({ ...formData, employee_contribution: Number(e.target.value) })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="employer_contribution">დამსაქმებლის წილი (₾)</Label>
                        <Input
                          id="employer_contribution"
                          type="number"
                          value={formData.employer_contribution}
                          onChange={(e) => setFormData({ ...formData, employer_contribution: Number(e.target.value) })}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="enrollment_start_date">რეგისტრაციის დაწყება</Label>
                        <Input
                          id="enrollment_start_date"
                          type="date"
                          value={formData.enrollment_start_date}
                          onChange={(e) => setFormData({ ...formData, enrollment_start_date: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="enrollment_end_date">რეგისტრაციის დასრულება</Label>
                        <Input
                          id="enrollment_end_date"
                          type="date"
                          value={formData.enrollment_end_date}
                          onChange={(e) => setFormData({ ...formData, enrollment_end_date: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="coverage_start_date">დაფარვის დაწყება</Label>
                        <Input
                          id="coverage_start_date"
                          type="date"
                          value={formData.coverage_start_date}
                          onChange={(e) => setFormData({ ...formData, coverage_start_date: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="coverage_end_date">დაფარვის დასრულება</Label>
                        <Input
                          id="coverage_end_date"
                          type="date"
                          value={formData.coverage_end_date}
                          onChange={(e) => setFormData({ ...formData, coverage_end_date: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="eligibility_criteria">უფლების კრიტერიუმები</Label>
                      <Textarea
                        id="eligibility_criteria"
                        value={formData.eligibility_criteria}
                        onChange={(e) => setFormData({ ...formData, eligibility_criteria: e.target.value })}
                        rows={2}
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        id="is_active"
                        checked={formData.is_active}
                        onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                      />
                      <Label htmlFor="is_active">აქტიური</Label>
                    </div>

                    <div className="flex justify-end gap-3 pt-4">
                      <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                        გაუქმება
                      </Button>
                      <Button type="submit">
                        {editingPlan ? "განახლება" : "შექმნა"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <Card className="p-6">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>დასახელება</TableHead>
                    <TableHead>ტიპი</TableHead>
                    <TableHead>პროვაიდერი</TableHead>
                    <TableHead>თანამშრომლის წილი</TableHead>
                    <TableHead>დამსაქმებლის წილი</TableHead>
                    <TableHead>სტატუსი</TableHead>
                    <TableHead className="text-right">მოქმედებები</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center">იტვირთება...</TableCell>
                    </TableRow>
                  ) : plans.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center text-muted-foreground">
                        <Shield className="mx-auto h-12 w-12 mb-2 opacity-50" />
                        სარგებლები არ მოიძებნა
                      </TableCell>
                    </TableRow>
                  ) : (
                    plans.map((plan) => (
                      <TableRow key={plan.id}>
                        <TableCell className="font-medium">{plan.plan_name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{plan.plan_type}</Badge>
                        </TableCell>
                        <TableCell>{plan.provider_name || "-"}</TableCell>
                        <TableCell>{plan.employee_contribution} ₾</TableCell>
                        <TableCell>{plan.employer_contribution} ₾</TableCell>
                        <TableCell>
                          <Switch
                            checked={plan.is_active}
                            onCheckedChange={() => toggleActive(plan.id, plan.is_active)}
                          />
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEdit(plan)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(plan.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          <TabsContent value="insurance">
            <InsuranceCompaniesTab />
          </TabsContent>
        </Tabs>
      </div>
  );
}