import { useState, useEffect } from "react";
import { 
  Cog,
  Settings,
  Building2,
  Shield,
  HelpCircle,
  UserCog,
  Activity,
  MessageSquare,
  GraduationCap,
  Megaphone,
  ArrowRight,
  Sparkles,
  Lock,
  Database,
  Calendar,
  Clock,
  Download,
  ArrowUpRight,
  ArrowDownRight,
  Users,
  Key,
  MapPin,
  Trash2,
  RotateCcw,
  Server,
  HeadphonesIcon,
  ShieldCheck,
  BookOpen,
  History
} from "lucide-react";
import { downloadInstallationPackage } from "@/lib/downloadInstallationPackage";
import { DemoDataCard } from "@/components/system/DemoDataCard";
import { toast } from "sonner";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import HubErrorState from "@/components/HubErrorState";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";

interface SystemStats {
  totalUsers: number;
  activeRoles: number;
  auditLogsToday: number;
  systemHealth: string;
}

export default function System() {
  const navigate = useNavigate();
  const { userRole } = useAuth();
  const [stats, setStats] = useState<SystemStats>({
    totalUsers: 0,
    activeRoles: 0,
    auditLogsToday: 0,
    systemHealth: "კარგი"
  });
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState(false);

  useEffect(() => {
    fetchSystemStats();
  }, []);

  const fetchSystemStats = async () => {
    try {
      // Fetch total users with roles
      const { count: userCount } = await supabase
        .from('user_roles')
        .select('*', { count: 'exact', head: true });

      // Fetch custom roles
      const { count: roleCount } = await supabase
        .from('custom_roles')
        .select('*', { count: 'exact', head: true });

      // Fetch today's audit logs
      const today = new Date().toISOString().split('T')[0];
      const { count: auditCount } = await supabase
        .from('audit_logs')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', today);

      setStats({
        totalUsers: userCount || 0,
        activeRoles: (roleCount || 0) + 4, // +4 for default roles
        auditLogsToday: auditCount || 0,
        systemHealth: "კარგი"
      });
    } catch (error) {
      console.error('Error fetching system stats:', error);
      setFetchError(true);
    } finally {
      setLoading(false);
    }
  };

  const quickStats = [
    {
      title: "სულ მომხმარებლები",
      value: stats.totalUsers.toString(),
      icon: Users,
      color: "from-slate-500 to-gray-600",
      bgColor: "bg-slate-500/10",
      trend: "აქტიური",
      trendUp: true,
      description: "მომხმარებელი"
    },
    {
      title: "როლები",
      value: stats.activeRoles.toString(),
      icon: Key,
      color: "from-rose-500 to-pink-600",
      bgColor: "bg-rose-500/10",
      trend: "კონფიგურირებული",
      trendUp: true,
      description: "როლი"
    },
    {
      title: "დღევანდელი აუდიტი",
      value: stats.auditLogsToday.toString(),
      icon: Activity,
      color: "from-violet-500 to-purple-600",
      bgColor: "bg-violet-500/10",
      trend: "+15",
      trendUp: true,
      description: "ჩანაწერი"
    },
    {
      title: "სისტემის სტატუსი",
      value: stats.systemHealth,
      icon: Shield,
      color: "from-emerald-500 to-green-600",
      bgColor: "bg-emerald-500/10",
      trend: "ონლაინ",
      trendUp: true,
      description: "სტატუსი"
    }
  ];

  const categories = [
    {
      title: "ძირითადი პარამეტრები",
      description: "სისტემის კონფიგურაცია და პარამეტრები",
      icon: Settings,
      color: "from-slate-400 via-gray-500 to-zinc-600",
      shadowColor: "shadow-gray-500/25",
      functions: [
        { 
          name: "პარამეტრები", 
          description: "პერსონალური და სისტემის პარამეტრები",
          url: "/settings",
          icon: Settings,
          stats: "კონფიგურაცია"
        },
        { 
          name: "მენიუს მართვა", 
          description: "მოდულების ჩართვა/გამორთვა მენიუში",
          url: "/feature-toggles",
          icon: Sparkles,
          stats: "Toggle",
          adminOnly: true
        },
        { 
          name: "კომპანია", 
          description: "კომპანიის ინფორმაციის მართვა",
          url: "/company-settings",
          icon: Building2,
          stats: "ინფორმაცია"
        },
        { 
          name: "როლები", 
          description: "როლებისა და უფლებების მართვა",
          url: "/role-management",
          icon: Shield,
          stats: `${stats.activeRoles} როლი`
        },
        { 
          name: "Custom როლები", 
          description: "მორგებული როლების შექმნა",
          url: "/custom-role-management",
          icon: Shield,
          stats: "მორგებული"
        },
        { 
          name: "დახმარება", 
          description: "სისტემის გამოყენების ინსტრუქციები",
          url: "/help",
          icon: HelpCircle,
          stats: "გზამკვლევი"
        },
        { 
          name: "შვებულების ტიპები", 
          description: "შვებულების კატეგორიების მართვა",
          url: "/leave-types",
          icon: Calendar,
          stats: "კატეგორიები"
        },
        { 
          name: "გრაფიკის შაბლონები", 
          description: "სამუშაო გრაფიკის შაბლონები",
          url: "/schedule-templates",
          icon: Clock,
          stats: "შაბლონები"
        },
        { 
          name: "ოფისის ლოკაციები", 
          description: "ოფისების მდებარეობა და geofencing",
          url: "/settings?tab=locations",
          icon: MapPin,
          stats: "ლოკაციები"
        },
      ]
    },
    {
      title: "ადმინისტრირება",
      description: "მონიტორინგი და უსაფრთხოება",
      icon: Lock,
      color: "from-red-400 via-rose-500 to-pink-500",
      shadowColor: "shadow-rose-500/25",
      functions: [
        { 
          name: "ცვლილებების მონიტორინგი", 
          description: "სისტემის ცვლილებების აუდიტი",
          url: "/audit-logs",
          icon: Activity,
          stats: `${stats.auditLogsToday} დღეს`
        },
        { 
          name: "უსაფრთხოება", 
          description: "უსაფრთხოების პარამეტრები და მონიტორინგი",
          url: "/security",
          icon: Shield,
          stats: stats.systemHealth
        },
        { 
          name: "SMS პარამეტრები", 
          description: "SMS შეტყობინებების კონფიგურაცია",
          url: "/sms-settings",
          icon: MessageSquare,
          stats: "შეტყობინებები"
        },
        { 
          name: "ინტეგრაციები", 
          description: "Telegram, Slack, Teams, WhatsApp და კალენდრები",
          url: "/integrations",
          icon: MessageSquare,
          stats: "არხები"
        },
        { 
          name: "საინსტალაციო პაკეტი", 
          description: "Docker საინსტალაციო არქივის ჩამოტვირთვა",
          url: "#download-package",
          icon: Download,
          stats: "ჩამოტვირთვა",
          isDownload: true
        },
        { 
          name: "წაშლილი ჩანაწერები", 
          description: "Soft-deleted ჩანაწერების აღდგენა (GDPR)",
          url: "/deleted-records",
          icon: Trash2,
          stats: "აღდგენა"
        },
        { 
          name: "მონაცემთა ბექაფი", 
          description: "მონაცემთა ბაზის ბექაფი და აღდგენა (JSON)",
          url: "/database-backup",
          icon: Database,
          stats: "ბექაფი"
        },
        { 
          name: "შესვლების ისტორია", 
          description: "IP/Geo Anomaly Detection ლოგინებზე",
          url: "/login-history",
          icon: MapPin,
          stats: "მონიტორინგი"
        },
      ]
    },
    {
      title: "დამატებითი სერვისები",
      description: "კომუნიკაცია და ტრენინგი",
      icon: MessageSquare,
      color: "from-indigo-400 via-violet-500 to-purple-500",
      shadowColor: "shadow-violet-500/25",
      functions: [
        { 
          name: "გამოცხადებები", 
          description: "გამოცხადებების და ახალი ამბების მართვა",
          url: "/announcements",
          icon: Megaphone,
          stats: "სიახლეები"
        },
        { 
          name: "სიმულატორი", 
          description: "სასწავლო სიმულატორი და ტესტირება",
          url: "/simulator",
          icon: GraduationCap,
          stats: "ტესტი"
        },
        { 
          name: "რეკლამები", 
          description: "სარეკლამო მოდულის მართვა",
          url: "/advertisement-management",
          icon: Megaphone,
          stats: "რეკლამა"
        },
        { 
          name: "სერვერის პანელი", 
          description: "სერვერის მონიტორინგი, Health Check და Auto-Healing",
          url: "/client-admin",
          icon: Server,
          stats: "მონიტორინგი"
        },
        { 
          name: "საპორტ ტიკეტები", 
          description: "ტექნიკური მხარდაჭერის მოთხოვნები და AI გადაწყვეტა",
          url: "/support-tickets",
          icon: HeadphonesIcon,
          stats: "მხარდაჭერა"
        },
        { 
          name: "მონაცემთა დაცვა", 
          description: "ენკრიპცია, RBAC, RLS და კომპლაიანსი",
          url: "/data-protection",
          icon: ShieldCheck,
          stats: "უსაფრთხოება"
        },
        { 
          name: "ცოდნის ბაზა (RAG)", 
          description: "ნინა AI ასისტენტის ცოდნის ბაზის მართვა",
          url: "/knowledge-base",
          icon: BookOpen,
          stats: "RAG"
        },
        { 
          name: "რა შეიცვალა?", 
          description: "სისტემის განახლებების და ვერსიების ისტორია",
          url: "/changelog",
          icon: History,
          stats: "Changelog"
        },
      ]
    }
  ];

  const visibleCategories = categories
    .map((category) => ({
      ...category,
      functions: category.functions.filter((func) => {
        if ((func as any).adminOnly && userRole !== "admin") return false;
        return true;
      }),
    }))
    .filter((category) => category.functions.length > 0);

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {fetchError && <HubErrorState onRetry={fetchSystemStats} />}
          {/* Header */}
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-400 via-gray-500 to-zinc-600 shadow-xl shadow-gray-500/30 animate-scale-in">
                <Cog className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-foreground via-foreground/90 to-foreground/70 bg-clip-text text-transparent">
                  სისტემა
                </h1>
                <p className="text-muted-foreground mt-1 text-lg">
                  სისტემის პარამეტრებისა და ადმინისტრირების მართვა
                </p>
              </div>
            </div>
          </div>

          {/* Quick Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {quickStats.map((stat, index) => (
              <Card 
                key={index}
                className={cn(
                  "group relative overflow-hidden border-border/50 bg-card/80 backdrop-blur-xl",
                  "hover:shadow-2xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-2",
                  "animate-fade-in"
                )}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <CardContent className="p-6 relative">
                  <div className="flex items-start justify-between mb-4">
                    <div className={cn(
                      "p-3 rounded-xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-3",
                      stat.bgColor
                    )}>
                      <stat.icon className="h-6 w-6" style={{ color: `hsl(var(--primary))` }} />
                    </div>
                    
                    <div className={cn(
                      "flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full transition-all duration-300",
                      stat.trendUp 
                        ? "text-emerald-600 bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-400" 
                        : "text-amber-600 bg-amber-100 dark:bg-amber-950/50 dark:text-amber-400"
                    )}>
                      {stat.trendUp ? (
                        <ArrowUpRight className="h-3 w-3" />
                      ) : (
                        <ArrowDownRight className="h-3 w-3" />
                      )}
                      <span>{stat.trend}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-2xl md:text-3xl font-bold tracking-tight group-hover:scale-105 transition-transform duration-300 origin-left">
                      {loading ? (
                        <div className="h-8 w-16 bg-muted animate-pulse rounded" />
                      ) : (
                        stat.value
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground font-medium">
                      {stat.title}
                    </div>
                    <div className="text-xs text-muted-foreground/70">
                      {stat.description}
                    </div>
                  </div>

                  <div className={cn(
                    "absolute -right-8 -bottom-8 w-32 h-32 rounded-full blur-3xl opacity-0 group-hover:opacity-30 transition-opacity duration-500",
                    `bg-gradient-to-br ${stat.color}`
                  )} />
                </CardContent>
              </Card>
            ))}
          </div>

          <DemoDataCard />

          {/* Categories */}
          <div className="space-y-10">
            {visibleCategories.map((category, idx) => (
              <div
                key={idx}
                className="space-y-6 animate-fade-in"
                style={{ animationDelay: `${(idx + 4) * 100}ms` }}
              >
                {/* Category Header */}
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "p-3 rounded-xl bg-gradient-to-br shadow-xl",
                    category.color,
                    category.shadowColor
                  )}>
                    <category.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl md:text-3xl font-bold text-foreground">{category.title}</h2>
                    <p className="text-sm text-muted-foreground">{category.description}</p>
                  </div>
                </div>

                {/* Function Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
                  {category.functions.map((func, funcIdx) => (
                    <Card
                      key={funcIdx}
                      className={cn(
                        "group cursor-pointer overflow-hidden",
                        "border-border/50 bg-card/80 backdrop-blur-xl",
                        "hover:border-primary/50 transition-all duration-500",
                        "hover:shadow-2xl hover:-translate-y-2",
                        "animate-fade-in"
                      )}
                      style={{ animationDelay: `${(idx * 4 + funcIdx + 5) * 50}ms` }}
                      onClick={() => {
                        if ((func as any).isDownload) {
                          downloadInstallationPackage();
                          toast.success("საინსტალაციო პაკეტი იტვირთება...");
                        } else {
                          navigate(func.url);
                        }
                      }}
                    >
                      <CardHeader className={cn(
                        "bg-gradient-to-br text-white pb-4 relative overflow-hidden",
                        category.color
                      )}>
                        <div className="flex items-center gap-3 relative z-10">
                          <div className="p-2.5 bg-white/20 rounded-xl backdrop-blur-sm group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                            <func.icon className="h-5 w-5" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{func.name}</CardTitle>
                            <span className="text-xs text-white/80">{func.stats}</span>
                          </div>
                        </div>
                        
                        <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700" />
                        <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white/5 rounded-full group-hover:scale-125 transition-transform duration-500" />
                      </CardHeader>
                      
                      <CardContent className="pt-6 relative">
                        <CardDescription className="text-muted-foreground mb-4 min-h-[48px] leading-relaxed">
                          {func.description}
                        </CardDescription>
                        
                        <div className="flex items-center gap-2 text-primary font-semibold text-sm group-hover:gap-4 transition-all duration-300">
                          <span>გახსნა</span>
                          <ArrowRight className="h-4 w-4 group-hover:translate-x-2 transition-transform duration-300" />
                        </div>

                        <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Enhanced Footer Stats */}
          <div 
            className="mt-12 p-6 md:p-8 rounded-2xl bg-gradient-to-r from-primary/5 via-primary/10 to-accent/10 border border-primary/20 backdrop-blur-xl animate-fade-in"
            style={{ animationDelay: '800ms' }}
          >
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-primary/10 animate-pulse">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-lg font-semibold text-foreground">
                    სულ ხელმისაწვდომია <span className="text-2xl font-bold text-primary">{visibleCategories.reduce((sum, cat) => sum + cat.functions.length, 0)}</span> სისტემური ფუნქცია
                  </p>
                  <p className="text-sm text-muted-foreground">
                    მართეთ და მონიტორინგ გაუწიეთ თქვენს სისტემას
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                  <Shield className="h-4 w-4" />
                  <span className="text-sm font-medium">სისტემა {stats.systemHealth}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
