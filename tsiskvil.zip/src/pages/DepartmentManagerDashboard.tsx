import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Navigate } from 'react-router-dom';
import { Users, CalendarCheck, FileText, TrendingUp, Clock, CheckCircle2, AlertTriangle, XCircle, Hourglass } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ka } from 'date-fns/locale';

interface LiveStatusRow {
  employee_id: string;
  full_name: string;
  position: string | null;
  scheduled_start: string | null;
  check_in: string | null;
  state: 'on_time' | 'late' | 'pending' | 'missed' | 'no_schedule';
}

interface Employee {
  id: string;
  full_name: string;
  position: string;
  department: string;
  email: string;
  phone: string;
  hire_date: string;
}

interface AttendanceRecord {
  id: string;
  employee_id: string;
  date: string;
  check_in: string;
  check_out: string;
  status: string;
  employees: {
    full_name: string;
  };
}

export default function DepartmentManagerDashboard() {
  const { userRole, user } = useAuth();
  const [departmentName, setDepartmentName] = useState<string>('');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalEmployees: 0,
    presentToday: 0,
    absentToday: 0,
    onLeave: 0,
  });
  const [liveStatus, setLiveStatus] = useState<LiveStatusRow[]>([]);

  // Only department managers can access this page
  if (userRole !== 'department_manager') {
    return <Navigate to="/" replace />;
  }

  useEffect(() => {
    fetchDepartmentData();
    const id = setInterval(fetchDepartmentData, 60_000); // refresh every minute
    return () => clearInterval(id);
  }, [user]);

  const fetchDepartmentData = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Get current user's employee record
      const { data: employee, error: empError } = await supabase
        .from('employees')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (empError) throw empError;

      // Get managed department
      const { data: department, error: deptError } = await supabase
        .from('departments')
        .select('name')
        .eq('manager_id', employee.id)
        .single();

      if (deptError) throw deptError;

      setDepartmentName(department.name);

      // Get department employees
      const { data: deptEmployees, error: employeesError } = await supabase
        .from('employees')
        .select('*')
        .eq('department', department.name)
        .order('full_name');

      if (employeesError) throw employeesError;
      setEmployees(deptEmployees || []);

      // Get today's attendance for department employees
      const today = new Date().toISOString().split('T')[0];
      const employeeIds = deptEmployees?.map(e => e.id) || [];

      const { data: attendanceData, error: attendanceError } = await supabase
        .from('attendance')
        .select('*, employees(full_name)')
        .in('employee_id', employeeIds)
        .eq('date', today)
        .order('check_in', { ascending: false });

      if (attendanceError) throw attendanceError;
      setAttendance(attendanceData || []);

      // Calculate stats
      const presentToday = attendanceData?.filter(a => a.status === 'present').length || 0;
      const absentToday = attendanceData?.filter(a => a.status === 'absent').length || 0;

      // Get leave requests
      const { data: leaveData } = await supabase
        .from('leave_requests')
        .select('employee_id')
        .in('employee_id', employeeIds)
        .eq('status', 'approved')
        .lte('start_date', today)
        .gte('end_date', today);

      setStats({
        totalEmployees: deptEmployees?.length || 0,
        presentToday,
        absentToday,
        onLeave: leaveData?.length || 0,
      });

      // Live status by schedule
      const onLeaveIds = new Set((leaveData || []).map((l: any) => l.employee_id));
      const { data: schedules } = await supabase
        .from('work_schedules')
        .select('employee_id, start_time')
        .in('employee_id', employeeIds);
      const schedMap = new Map<string, string>();
      (schedules || []).forEach((s: any) => {
        if (s.start_time && !schedMap.has(s.employee_id)) {
          schedMap.set(s.employee_id, s.start_time);
        }
      });
      const attMap = new Map<string, any>();
      (attendanceData || []).forEach((a: any) => {
        if (!attMap.has(a.employee_id)) attMap.set(a.employee_id, a);
      });
      const nowHM = new Date().toTimeString().slice(0, 5);
      const live: LiveStatusRow[] = (deptEmployees || [])
        .filter((e: any) => !onLeaveIds.has(e.id))
        .map((e: any) => {
          const sched = schedMap.get(e.id) || null;
          const att = attMap.get(e.id);
          const checkIn = att?.check_in || null;
          let state: LiveStatusRow['state'] = 'pending';
          if (!sched) {
            state = checkIn ? 'on_time' : 'no_schedule';
          } else {
            const schedHM = sched.slice(0, 5);
            if (checkIn) {
              state = checkIn.slice(0, 5) <= schedHM ? 'on_time' : 'late';
            } else {
              state = nowHM > schedHM ? 'missed' : 'pending';
            }
          }
          return {
            employee_id: e.id,
            full_name: e.full_name,
            position: e.position,
            scheduled_start: sched,
            check_in: checkIn,
            state,
          };
        })
        .sort((a, b) => {
          const order = { missed: 0, late: 1, pending: 2, no_schedule: 3, on_time: 4 } as const;
          return order[a.state] - order[b.state];
        });
      setLiveStatus(live);
    } catch (error: any) {
      console.error('Error fetching department data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      present: 'default',
      absent: 'destructive',
      late: 'secondary',
      on_leave: 'outline',
    };
    return variants[status] || 'outline';
  };

  const getStatusText = (status: string) => {
    const texts: Record<string, string> = {
      present: 'დასწრებული',
      absent: 'არ არის',
      late: 'დაგვიანებული',
      on_leave: 'შვებულებაში',
    };
    return texts[status] || status;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">იტვირთება...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">დეპარტამენტის მართვა</h1>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Users className="h-5 w-5" />
          <p className="text-lg">{departmentName}</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">სულ თანამშრომლები</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalEmployees}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">დღეს დასწრებული</CardTitle>
            <CalendarCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.presentToday}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">არ არის</CardTitle>
            <CalendarCheck className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{stats.absentToday}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">შვებულებაში</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.onLeave}</div>
          </CardContent>
        </Card>
      </div>

      {/* Live Status - Current attendance vs schedule */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            მიმდინარე მდგომარეობა (განრიგის მიხედვით)
          </CardTitle>
          <CardDescription>
            დღევანდელი გამოცხადება სამუშაო გრაფიკთან შედარებით · განახლდება ყოველ წუთს
          </CardDescription>
        </CardHeader>
        <CardContent>
          {liveStatus.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground text-sm">
              დღეს მონიტორინგისთვის თანამშრომელი არ არის
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mb-4 text-xs">
                {[
                  { state: 'on_time', label: 'დროულად', icon: CheckCircle2, cls: 'text-green-600' },
                  { state: 'late', label: 'დაგვიანებით', icon: AlertTriangle, cls: 'text-amber-600' },
                  { state: 'pending', label: 'მოლოდინში', icon: Hourglass, cls: 'text-blue-600' },
                  { state: 'missed', label: 'ვერ გამოცხადდა', icon: XCircle, cls: 'text-destructive' },
                  { state: 'no_schedule', label: 'გრაფიკის გარეშე', icon: Clock, cls: 'text-muted-foreground' },
                ].map(({ state, label, icon: Icon, cls }) => {
                  const count = liveStatus.filter(r => r.state === state).length;
                  return (
                    <div key={state} className="rounded-lg border bg-card p-3 flex items-center gap-2">
                      <Icon className={`h-4 w-4 ${cls}`} />
                      <div>
                        <div className="font-semibold">{count}</div>
                        <div className="text-muted-foreground">{label}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>გრაფიკი</TableHead>
                      <TableHead>შემოსვლა</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {liveStatus.map((row) => {
                      const map = {
                        on_time: { label: 'დროულად', variant: 'default' as const, Icon: CheckCircle2, cls: 'text-green-600' },
                        late: { label: 'დაგვიანებით', variant: 'secondary' as const, Icon: AlertTriangle, cls: 'text-amber-600' },
                        pending: { label: 'მოლოდინში', variant: 'outline' as const, Icon: Hourglass, cls: 'text-blue-600' },
                        missed: { label: 'ვერ გამოცხადდა', variant: 'destructive' as const, Icon: XCircle, cls: 'text-destructive' },
                        no_schedule: { label: 'გრაფიკის გარეშე', variant: 'outline' as const, Icon: Clock, cls: 'text-muted-foreground' },
                      }[row.state];
                      const Icon = map.Icon;
                      return (
                        <TableRow key={row.employee_id}>
                          <TableCell className="font-medium">
                            <div>{row.full_name}</div>
                            <div className="text-xs text-muted-foreground">{row.position || '-'}</div>
                          </TableCell>
                          <TableCell className="font-mono text-sm">
                            {row.scheduled_start ? row.scheduled_start.slice(0, 5) : '-'}
                          </TableCell>
                          <TableCell className="font-mono text-sm">
                            {row.check_in ? row.check_in.slice(0, 5) : '-'}
                          </TableCell>
                          <TableCell>
                            <Badge variant={map.variant} className="gap-1">
                              <Icon className={`h-3 w-3 ${map.cls}`} />
                              {map.label}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="employees" className="space-y-4">
        <TabsList>
          <TabsTrigger value="employees">თანამშრომლები</TabsTrigger>
          <TabsTrigger value="attendance">დასწრება</TabsTrigger>
        </TabsList>

        <TabsContent value="employees" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>დეპარტამენტის თანამშრომლები</CardTitle>
              <CardDescription>
                {departmentName}-ის ყველა თანამშრომელი
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>სახელი</TableHead>
                      <TableHead>პოზიცია</TableHead>
                      <TableHead>ელ.ფოსტა</TableHead>
                      <TableHead>ტელეფონი</TableHead>
                      <TableHead>დაქირავების თარიღი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employees.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          თანამშრომლები არ მოიძებნა
                        </TableCell>
                      </TableRow>
                    ) : (
                      employees.map((emp) => (
                        <TableRow key={emp.id}>
                          <TableCell className="font-medium">{emp.full_name}</TableCell>
                          <TableCell>{emp.position}</TableCell>
                          <TableCell className="text-muted-foreground">{emp.email}</TableCell>
                          <TableCell>{emp.phone || '-'}</TableCell>
                          <TableCell>
                            {emp.hire_date
                              ? formatDistanceToNow(new Date(emp.hire_date), {
                                  addSuffix: true,
                                  locale: ka,
                                })
                              : '-'}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attendance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>დღევანდელი დასწრება</CardTitle>
              <CardDescription>
                {new Date().toLocaleDateString('ka-GE')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>შემოსვლა</TableHead>
                      <TableHead>გასვლა</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {attendance.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                          დღეს დასწრება არ არის რეგისტრირებული
                        </TableCell>
                      </TableRow>
                    ) : (
                      attendance.map((record) => (
                        <TableRow key={record.id}>
                          <TableCell className="font-medium">
                            {record.employees.full_name}
                          </TableCell>
                          <TableCell>{record.check_in || '-'}</TableCell>
                          <TableCell>{record.check_out || '-'}</TableCell>
                          <TableCell>
                            <Badge variant={getStatusBadge(record.status)}>
                              {getStatusText(record.status)}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
