import { useState, useRef, useEffect } from "react";
import { Send, User, Loader2, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";

import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { exportComprehensiveManual } from "@/lib/exportComprehensiveManual";
import { cleanNinaText } from "@/lib/cleanNinaText";
import { exportSetupGuide } from "@/lib/exportSetupGuide";
import { exportUserManual } from "@/lib/exportUserManual";
import ninaAvatar from "@/assets/nina-avatar.png";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const Help = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "გამარჯობა! 👋 მე ვარ ნინა, თქვენი HR ასისტენტი. შემიძლია დაგეხმაროთ სისტემის ფუნქციონალების გაგებაში. დამისვით ნებისმიერი კითხვა!"
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput("");
    
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setIsLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('ai-assistant', {
        body: { question: userMessage }
      });

      if (error) throw error;

      setMessages(prev => [...prev, { 
        role: "assistant", 
        content: cleanNinaText(data.response) 
      }]);
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "შეცდომა",
        description: "პასუხის მიღება ვერ მოხერხდა. გთხოვთ სცადოთ თავიდან.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-6 h-[calc(100vh-4rem)]">
      <Card className="h-full flex flex-col shadow-lg border-primary/10">
        <CardHeader className="border-b bg-gradient-to-r from-primary/5 to-accent/5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Avatar className="h-12 w-12">
                <AvatarImage src={ninaAvatar} alt="ნინა" />
                <AvatarFallback className="bg-primary/10 text-primary">ნი</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-xl sm:text-2xl">ნინა - AI ასისტენტი</CardTitle>
                <CardDescription>
                  დასვით კითხვები სისტემის ფუნქციონალების შესახებ
                </CardDescription>
              </div>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2 self-start md:self-auto">
                  <Download className="h-4 w-4" />
                  დოკუმენტები
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={exportUserManual}>სახელმძღვანელო</DropdownMenuItem>
                <DropdownMenuItem onClick={exportSetupGuide}>კონფიგურაციის გზამკვლევი</DropdownMenuItem>
                <DropdownMenuItem onClick={exportComprehensiveManual}>სრული სახელმძღვანელო</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        
        <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
          <div className="flex-1 overflow-y-auto p-6" ref={scrollRef}>
            <div className="space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex gap-3 ${
                    message.role === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  {message.role === "assistant" && (
                    <Avatar className="flex-shrink-0 w-8 h-8">
                      <AvatarImage src={ninaAvatar} alt="ნინა" />
                      <AvatarFallback className="bg-primary/10 text-primary text-xs">ნი</AvatarFallback>
                    </Avatar>
                  )}
                  
                  <div
                    className={`rounded-2xl px-4 py-3 max-w-[80%] ${
                      message.role === "user"
                        ? "bg-primary text-primary-foreground shadow-md"
                        : "bg-muted text-foreground"
                    }`}
                  >
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">
                      {message.content}
                    </p>
                  </div>
                  
                  {message.role === "user" && (
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center">
                      <User className="h-4 w-4 text-accent" />
                    </div>
                  )}
                </div>
              ))}
              
              {isLoading && (
                <div className="flex gap-3 justify-start">
                  <Avatar className="flex-shrink-0 w-8 h-8">
                    <AvatarImage src={ninaAvatar} alt="ნინა" />
                    <AvatarFallback className="bg-primary/10 text-primary text-xs">ნი</AvatarFallback>
                  </Avatar>
                  <div className="rounded-2xl px-4 py-3 bg-muted">
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="p-6 border-t bg-muted/30">
            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="დაწერეთ თქვენი კითხვა..."
                disabled={isLoading}
                className="flex-1"
              />
              <Button 
                type="submit" 
                disabled={isLoading || !input.trim()}
                className="gap-2"
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Help;
