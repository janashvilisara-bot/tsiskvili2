import { useState, useEffect } from "react";
import { Briefcase, MapPin, Clock, DollarSign, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { z } from "zod";

const applicationSchema = z.object({
  full_name: z.string().min(2, { message: "სახელი ძალიან მოკლეა" }),
  email: z.string().email({ message: "არასწორი ელ.ფოსტა" }),
  phone: z.string().min(9, { message: "არასწორი ტელეფონის ნომერი" }),
  cover_letter: z.string().min(10, { message: "საფარი წერილი ძალიან მოკლეა" }),
});

interface Vacancy {
  id: string;
  title: string;
  description: string;
  requirements: string;
  location: string;
  employment_type: string;
  salary_min: number;
  salary_max: number;
  status: string;
  opened_date: string;
  experience_level: string;
}

export default function JobApplications() {
  const [vacancies, setVacancies] = useState<Vacancy[]>([]);
  const [selectedVacancy, setSelectedVacancy] = useState<Vacancy | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    fetchVacancies();
    
    // Check if there's a vacancy ID in the URL query params
    const params = new URLSearchParams(window.location.search);
    const vacancyId = params.get('vacancy');
    
    if (vacancyId) {
      // Scroll to the vacancy after a short delay to ensure DOM is ready
      setTimeout(() => {
        const element = document.getElementById(`vacancy-${vacancyId}`);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth', block: 'center' });
          element.classList.add('ring-2', 'ring-primary', 'ring-offset-2');
        }
      }, 500);
    }
  }, []);

  const fetchVacancies = async () => {
    const { data, error } = await supabase
      .from('job_vacancies')
      .select('*')
      .eq('status', 'open')
      .order('opened_date', { ascending: false });

    if (error) {
      toast.error('ვაკანსიების ჩატვირთვა ვერ მოხერხდა');
    } else {
      setVacancies(data || []);
    }
  };

  const handleApply = (vacancy: Vacancy) => {
    setSelectedVacancy(vacancy);
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors({});
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const data = applicationSchema.parse({
        full_name: formData.get('full_name'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        cover_letter: formData.get('cover_letter'),
      });

      const { error } = await supabase
        .from('candidates')
        .insert([{
          vacancy_id: selectedVacancy?.id,
          full_name: data.full_name,
          email: data.email,
          phone: data.phone,
          cover_letter: data.cover_letter,
          status: 'new',
          source: 'website',
        }]);

      if (error) throw error;

      toast.success('განაცხადი წარმატებით გაიგზავნა');
      setIsDialogOpen(false);
      setSelectedVacancy(null);
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
      } else {
        toast.error(error.message || 'შეცდომა მოხდა');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const getEmploymentTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      full_time: 'სრული განაკვეთი',
      part_time: 'ნახევარი განაკვეთი',
      contract: 'კონტრაქტი',
      internship: 'სტაჟირება',
    };
    return types[type] || type;
  };

  const getExperienceLevelLabel = (level: string) => {
    const levels: Record<string, string> = {
      entry: 'დამწყები',
      mid: 'საშუალო',
      senior: 'უფროსი',
      lead: 'ლიდი',
    };
    return levels[level] || level;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-12">
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            კარიერის შესაძლებლობები
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">
            იპოვეთ თქვენი სამომავლო პოზიცია ჩვენს გუნდში
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {vacancies.map((vacancy) => (
            <Card 
              key={vacancy.id} 
              id={`vacancy-${vacancy.id}`}
              className="flex flex-col transition-all hover:shadow-lg"
            >
              <CardHeader>
                <CardTitle className="flex items-start justify-between gap-2">
                  <span className="flex-1">{vacancy.title}</span>
                  <Badge variant="secondary">
                    {getEmploymentTypeLabel(vacancy.employment_type)}
                  </Badge>
                </CardTitle>
                <CardDescription className="space-y-2">
                  {vacancy.location && (
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      <span>{vacancy.location}</span>
                    </div>
                  )}
                  {vacancy.experience_level && (
                    <div className="flex items-center gap-2">
                      <Briefcase className="h-4 w-4" />
                      <span>{getExperienceLevelLabel(vacancy.experience_level)}</span>
                    </div>
                  )}
                  {(vacancy.salary_min || vacancy.salary_max) && (
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      <span>
                        {vacancy.salary_min && `${vacancy.salary_min} ₾`}
                        {vacancy.salary_min && vacancy.salary_max && ' - '}
                        {vacancy.salary_max && `${vacancy.salary_max} ₾`}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-xs">
                    <Clock className="h-3 w-3" />
                    <span>გამოქვეყნდა: {new Date(vacancy.opened_date).toLocaleDateString('ka-GE')}</span>
                  </div>
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-1 flex-col gap-4">
                {vacancy.description && (
                  <div>
                    <h4 className="mb-2 font-semibold">აღწერა:</h4>
                    <p className="text-sm text-muted-foreground line-clamp-3">
                      {vacancy.description}
                    </p>
                  </div>
                )}
                {vacancy.requirements && (
                  <div>
                    <h4 className="mb-2 font-semibold">მოთხოვნები:</h4>
                    <p className="text-sm text-muted-foreground line-clamp-3">
                      {vacancy.requirements}
                    </p>
                  </div>
                )}
                <div className="mt-auto">
                  <Button
                    className="w-full gap-2"
                    onClick={() => handleApply(vacancy)}
                  >
                    <Send className="h-4 w-4" />
                    განაცხადის გაგზავნა
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {vacancies.length === 0 && (
          <Card>
            <CardContent className="flex h-64 items-center justify-center text-muted-foreground">
              ამჟამად ვაკანსიები არ არის
            </CardContent>
          </Card>
        )}

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>განაცხადის გაგზავნა - {selectedVacancy?.title}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="full_name">სრული სახელი *</Label>
                <Input
                  id="full_name"
                  name="full_name"
                  placeholder="თქვენი სრული სახელი"
                  required
                />
                {errors.full_name && <p className="mt-1 text-sm text-destructive">{errors.full_name}</p>}
              </div>

              <div>
                <Label htmlFor="email">ელ. ფოსტა *</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="your@email.com"
                  required
                />
                {errors.email && <p className="mt-1 text-sm text-destructive">{errors.email}</p>}
              </div>

              <div>
                <Label htmlFor="phone">ტელეფონი *</Label>
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  placeholder="+995 XXX XX XX XX"
                  required
                />
                {errors.phone && <p className="mt-1 text-sm text-destructive">{errors.phone}</p>}
              </div>

              <div>
                <Label htmlFor="cover_letter">საფარი წერილი *</Label>
                <Textarea
                  id="cover_letter"
                  name="cover_letter"
                  placeholder="მოგვიყევით თქვენს შესახებ და რატომ გსურთ ეს პოზიცია..."
                  rows={6}
                  required
                />
                {errors.cover_letter && <p className="mt-1 text-sm text-destructive">{errors.cover_letter}</p>}
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'გაგზავნა...' : 'განაცხადის გაგზავნა'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
