import { useState } from "react";
import { useWorkTimeData } from "@/hooks/useWorkTimeData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Award, Download, Search } from "lucide-react";
import { ReportPageShell } from "@/components/reports/ReportPageShell";
import { exportToExcel } from "@/lib/exportToExcel";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { useBranchFilter } from "@/hooks/useBranchFilter";


export default function ChillOutReport() {
  const [startDate, setStartDate] = useState(
    new Date(new Date().getFullYear(), new Date().getMonth(), 1)
      .toISOString()
      .split("T")[0]
  );
  const [endDate, setEndDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  const branchId = useBranchFilter();
  const { records, loading } = useWorkTimeData(
    startDate,
    endDate,
    selectedDepartment,
    "all",
    branchId
  );


  const { data: departments = [] } = useQuery({
    queryKey: ["departments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("departments")
        .select("name")
        .eq("is_active", true)
        .order("name");
      if (error) throw error;
      return data;
    },
  });

  // Filter to show only employees with overtime > 0
  const filteredRecords = records
    .filter((record) => record.overtime_hours > 0 || record.rest_holiday_hours > 0)
    .filter((record) => {
      if (!searchTerm) return true;
      return (
        record.employee_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.employee_number.toLowerCase().includes(searchTerm.toLowerCase())
      );
    })
    .sort((a, b) => {
      const totalA = a.overtime_hours + a.rest_holiday_hours;
      const totalB = b.overtime_hours + b.rest_holiday_hours;
      return totalB - totalA;
    });

  const handleExport = () => {
    const exportData = filteredRecords.map((record) => ({
      "თანამშრომლის ნომერი": record.employee_number,
      "სახელი და გვარი": record.employee_name,
      დეპარტამენტი: record.department,
      პოზიცია: record.position,
      "ზეგანაკვეთური საათები": record.overtime_hours.toFixed(2),
      "დასვენების დღეების საათები": record.rest_holiday_hours.toFixed(2),
      "ღამის საათები": record.night_overtime_hours.toFixed(2),
      "სულ ზედმეტი საათები": (
        record.overtime_hours + record.rest_holiday_hours
      ).toFixed(2),
    }));

    const success = exportToExcel(
      exportData,
      `chill-out-report_${startDate}_${endDate}`,
      "Chill Out Report"
    );

    if (success) {
      toast.success("რეპორტი წარმატებით ჩამოიტვირთა");
    } else {
      toast.error("რეპორტის ჩამოტვირთვა ვერ მოხერხდა");
    }
  };

  const totalOvertimeHours = filteredRecords.reduce(
    (sum, record) => sum + record.overtime_hours + record.rest_holiday_hours,
    0
  );

  return (
    <ReportPageShell
      title="Chill Out ანგარიში"
      description="დასვენების დროის და ზეგანაკვეთური საათების მონიტორინგი"
      icon={Award}
      gradient="from-emerald-400 via-teal-500 to-cyan-500"
      shadow="shadow-teal-500/30"
      actions={
        <Button onClick={handleExport} disabled={filteredRecords.length === 0} size="lg" className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 shadow-lg">
          <Download className="h-4 w-4 mr-2" />
          Excel-ში ჩამოტვირთვა
        </Button>
      }
    >

      <Card>
        <CardHeader>
          <CardTitle>ფილტრები</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">
                საწყისი თარიღი
              </label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">
                საბოლოო თარიღი
              </label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">
                დეპარტამენტი
              </label>
              <Select
                value={selectedDepartment}
                onValueChange={setSelectedDepartment}
              >
                <SelectTrigger>
                  <SelectValue placeholder="აირჩიეთ დეპარტამენტი" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept.name} value={dept.name}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">ძებნა</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="სახელი ან ნომერი..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>სტატისტიკა</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-primary/10 rounded-lg">
              <p className="text-sm text-muted-foreground">
                თანამშრომლების რაოდენობა
              </p>
              <p className="text-2xl font-bold">{filteredRecords.length}</p>
            </div>
            <div className="p-4 bg-accent/10 rounded-lg">
              <p className="text-sm text-muted-foreground">
                სულ ზედმეტი საათები
              </p>
              <p className="text-2xl font-bold">
                {totalOvertimeHours.toFixed(2)}
              </p>
            </div>
            <div className="p-4 bg-secondary/10 rounded-lg">
              <p className="text-sm text-muted-foreground">
                საშუალო თანამშრომელზე
              </p>
              <p className="text-2xl font-bold">
                {filteredRecords.length > 0
                  ? (totalOvertimeHours / filteredRecords.length).toFixed(2)
                  : "0.00"}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>
            თანამშრომლები ზეგანაკვეთური საათებით ({filteredRecords.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">იტვირთება...</div>
          ) : filteredRecords.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Award className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>ამ პერიოდში ზეგანაკვეთური საათები არ ფიქსირდება</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>თანამშრომლის ნომერი</TableHead>
                    <TableHead>სახელი და გვარი</TableHead>
                    <TableHead>დეპარტამენტი</TableHead>
                    <TableHead>პოზიცია</TableHead>
                    <TableHead className="text-right">
                      ზეგანაკვეთური
                    </TableHead>
                    <TableHead className="text-right">
                      დასვენების დღეები
                    </TableHead>
                    <TableHead className="text-right">ღამის საათები</TableHead>
                    <TableHead className="text-right">
                      სულ ზედმეტი საათები
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.employee_id}>
                      <TableCell className="font-medium">
                        {record.employee_number}
                      </TableCell>
                      <TableCell>{record.employee_name}</TableCell>
                      <TableCell>{record.department}</TableCell>
                      <TableCell>{record.position}</TableCell>
                      <TableCell className="text-right">
                        {record.overtime_hours.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right">
                        {record.rest_holiday_hours.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right">
                        {record.night_overtime_hours.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right font-bold">
                        {(
                          record.overtime_hours + record.rest_holiday_hours
                        ).toFixed(2)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </ReportPageShell>
  );
}
