import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Activity, Users, Clock, Eye, Monitor, Smartphone, Calendar } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { ka } from 'date-fns/locale';
import { PageTransition } from '@/components/PageTransition';

interface UserPresence {
  user_id: string;
  status: string;
  last_seen: string;
  user_name?: string;
}

interface UserSession {
  id: string;
  user_id: string;
  session_start: string;
  session_end: string | null;
  duration_minutes: number | null;
  device_type: string;
  browser: string;
  os: string;
  is_active: boolean;
  user_name?: string;
}

interface PageView {
  id: string;
  user_id: string;
  page_path: string;
  page_title: string;
  viewed_at: string;
  user_name?: string;
}

interface ActivitySummary {
  user_id: string;
  activity_date: string;
  total_sessions: number;
  total_page_views: number;
  total_time_minutes: number;
  pages_visited: string[];
  user_name?: string;
}

const UserActivityMonitoring = () => {
  const [presenceData, setPresenceData] = useState<UserPresence[]>([]);
  const [sessions, setSessions] = useState<UserSession[]>([]);
  const [pageViews, setPageViews] = useState<PageView[]>([]);
  const [activitySummaries, setActivitySummaries] = useState<ActivitySummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('7');

  useEffect(() => {
    fetchAllData();
  }, [dateRange]);

  const fetchAllData = async () => {
    setLoading(true);
    await Promise.all([
      fetchPresence(),
      fetchSessions(),
      fetchPageViews(),
      fetchActivitySummaries()
    ]);
    setLoading(false);
  };

  const fetchPresence = async () => {
    const { data, error } = await supabase
      .from('user_presence')
      .select('*')
      .order('last_seen', { ascending: false });

    if (!error && data) {
      const userIds = data.map(p => p.user_id);
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, full_name')
        .in('id', userIds);

      const enriched = data.map(p => ({
        ...p,
        user_name: profiles?.find(pr => pr.id === p.user_id)?.full_name || 'უცნობი'
      }));

      setPresenceData(enriched);
    }
  };

  const fetchSessions = async () => {
    const fromDate = subDays(new Date(), parseInt(dateRange)).toISOString();

    const { data, error } = await supabase
      .from('user_sessions' as any)
      .select('*')
      .gte('session_start', fromDate)
      .order('session_start', { ascending: false })
      .limit(100);

    if (!error && data) {
      const sessionsData = data as any[];
      const userIds = [...new Set(sessionsData.map(s => s.user_id))];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, full_name')
        .in('id', userIds);

      const enriched = sessionsData.map(s => ({
        ...s,
        user_name: profiles?.find(p => p.id === s.user_id)?.full_name || 'უცნობი'
      }));

      setSessions(enriched);
    }
  };

  const fetchPageViews = async () => {
    const fromDate = subDays(new Date(), parseInt(dateRange)).toISOString();

    const { data, error } = await supabase
      .from('page_views' as any)
      .select('*')
      .gte('viewed_at', fromDate)
      .order('viewed_at', { ascending: false })
      .limit(200);

    if (!error && data) {
      const pageViewsData = data as any[];
      const userIds = [...new Set(pageViewsData.map(p => p.user_id))];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, full_name')
        .in('id', userIds);

      const enriched = pageViewsData.map(pv => ({
        ...pv,
        user_name: profiles?.find(p => p.id === pv.user_id)?.full_name || 'უცნობი'
      }));

      setPageViews(enriched);
    }
  };

  const fetchActivitySummaries = async () => {
    const fromDate = subDays(new Date(), parseInt(dateRange)).toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('user_activity_summary' as any)
      .select('*')
      .gte('activity_date', fromDate)
      .order('activity_date', { ascending: false });

    if (!error && data) {
      const summariesData = data as any[];
      const userIds = [...new Set(summariesData.map(a => a.user_id))];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, full_name')
        .in('id', userIds);

      const enriched = summariesData.map(a => ({
        ...a,
        user_name: profiles?.find(p => p.id === a.user_id)?.full_name || 'უცნობი'
      }));

      setActivitySummaries(enriched);
    }
  };

  const onlineUsers = presenceData.filter(p => p.status === 'online').length;
  const totalSessions = sessions.length;
  const totalPageViews = pageViews.length;
  const avgSessionDuration = sessions.filter(s => s.duration_minutes).length > 0
    ? Math.round(sessions.filter(s => s.duration_minutes).reduce((acc, s) => acc + (s.duration_minutes || 0), 0) / sessions.filter(s => s.duration_minutes).length)
    : 0;

  const getDeviceIcon = (type: string) => {
    return type === 'mobile' ? <Smartphone className="h-4 w-4" /> : <Monitor className="h-4 w-4" />;
  };

  return (
    <PageTransition>
      <div className="space-y-6 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">მომხმარებლის აქტივობის მონიტორინგი</h1>
            <p className="text-muted-foreground">ISO 27001 A.12 - რეალურ დროში აქტივობის თრექინგი</p>
          </div>
          <div className="flex items-center gap-4">
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="პერიოდი" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">ბოლო 1 დღე</SelectItem>
                <SelectItem value="7">ბოლო 7 დღე</SelectItem>
                <SelectItem value="30">ბოლო 30 დღე</SelectItem>
                <SelectItem value="90">ბოლო 90 დღე</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={fetchAllData} variant="outline">
              განახლება
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">ონლაინ მომხმარებლები</CardTitle>
              <Users className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{onlineUsers}</div>
              <p className="text-xs text-muted-foreground">ამჟამად აქტიური</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">სესიები</CardTitle>
              <Activity className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalSessions}</div>
              <p className="text-xs text-muted-foreground">ბოლო {dateRange} დღე</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">გვერდების ნახვები</CardTitle>
              <Eye className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalPageViews}</div>
              <p className="text-xs text-muted-foreground">ბოლო {dateRange} დღე</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">საშ. სესიის ხანგრძ.</CardTitle>
              <Clock className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{avgSessionDuration} წთ</div>
              <p className="text-xs text-muted-foreground">საშუალო</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="presence" className="space-y-4">
          <TabsList>
            <TabsTrigger value="presence">ონლაინ სტატუსი</TabsTrigger>
            <TabsTrigger value="sessions">სესიები</TabsTrigger>
            <TabsTrigger value="pageviews">გვერდების ნახვები</TabsTrigger>
            <TabsTrigger value="summary">დღიური შეჯამება</TabsTrigger>
          </TabsList>

          {/* Online Status */}
          <TabsContent value="presence">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  მომხმარებლების ონლაინ სტატუსი
                </CardTitle>
                <CardDescription>რეალურ დროში მომხმარებლების აქტივობა</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>მომხმარებელი</TableHead>
                      <TableHead>სტატუსი</TableHead>
                      <TableHead>ბოლო აქტივობა</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {presenceData.map((presence) => (
                      <TableRow key={presence.user_id}>
                        <TableCell className="font-medium">{presence.user_name}</TableCell>
                        <TableCell>
                          <Badge variant={presence.status === 'online' ? 'default' : 'secondary'}>
                            <span className={`mr-2 h-2 w-2 rounded-full inline-block ${
                              presence.status === 'online' ? 'bg-green-500' : 'bg-gray-400'
                            }`} />
                            {presence.status === 'online' ? 'ონლაინ' : 'ოფლაინ'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {format(new Date(presence.last_seen), 'dd MMM yyyy HH:mm', { locale: ka })}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sessions */}
          <TabsContent value="sessions">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  მომხმარებლის სესიები
                </CardTitle>
                <CardDescription>ყველა სესიის დეტალური ჩანაწერი</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>მომხმარებელი</TableHead>
                      <TableHead>დაწყება</TableHead>
                      <TableHead>დასრულება</TableHead>
                      <TableHead>ხანგრძლივობა</TableHead>
                      <TableHead>მოწყობილობა</TableHead>
                      <TableHead>ბრაუზერი</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sessions.map((session) => (
                      <TableRow key={session.id}>
                        <TableCell className="font-medium">{session.user_name}</TableCell>
                        <TableCell>
                          {format(new Date(session.session_start), 'dd/MM/yyyy HH:mm')}
                        </TableCell>
                        <TableCell>
                          {session.session_end 
                            ? format(new Date(session.session_end), 'HH:mm')
                            : '-'
                          }
                        </TableCell>
                        <TableCell>
                          {session.duration_minutes ? `${session.duration_minutes} წთ` : '-'}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getDeviceIcon(session.device_type)}
                            <span className="capitalize">{session.device_type}</span>
                          </div>
                        </TableCell>
                        <TableCell>{session.browser}</TableCell>
                        <TableCell>
                          <Badge variant={session.is_active ? 'default' : 'secondary'}>
                            {session.is_active ? 'აქტიური' : 'დასრულებული'}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Page Views */}
          <TabsContent value="pageviews">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="h-5 w-5" />
                  გვერდების ნახვები
                </CardTitle>
                <CardDescription>რომელ გვერდებს უყურებენ მომხმარებლები</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>მომხმარებელი</TableHead>
                      <TableHead>გვერდი</TableHead>
                      <TableHead>სათაური</TableHead>
                      <TableHead>დრო</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pageViews.map((pv) => (
                      <TableRow key={pv.id}>
                        <TableCell className="font-medium">{pv.user_name}</TableCell>
                        <TableCell>
                          <code className="text-sm bg-muted px-2 py-1 rounded">{pv.page_path}</code>
                        </TableCell>
                        <TableCell>{pv.page_title || '-'}</TableCell>
                        <TableCell>
                          {format(new Date(pv.viewed_at), 'dd/MM/yyyy HH:mm:ss')}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Daily Summary */}
          <TabsContent value="summary">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  დღიური აქტივობის შეჯამება
                </CardTitle>
                <CardDescription>მომხმარებლების ყოველდღიური აქტივობა</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>მომხმარებელი</TableHead>
                      <TableHead>თარიღი</TableHead>
                      <TableHead>სესიები</TableHead>
                      <TableHead>გვერდების ნახვა</TableHead>
                      <TableHead>მონახულებული გვერდები</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {activitySummaries.map((summary) => (
                      <TableRow key={`${summary.user_id}-${summary.activity_date}`}>
                        <TableCell className="font-medium">{summary.user_name}</TableCell>
                        <TableCell>
                          {format(new Date(summary.activity_date), 'dd MMM yyyy', { locale: ka })}
                        </TableCell>
                        <TableCell>{summary.total_sessions}</TableCell>
                        <TableCell>{summary.total_page_views}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {summary.pages_visited?.slice(0, 3).map((page, i) => (
                              <Badge key={i} variant="outline" className="text-xs">
                                {page}
                              </Badge>
                            ))}
                            {summary.pages_visited?.length > 3 && (
                              <Badge variant="secondary" className="text-xs">
                                +{summary.pages_visited.length - 3}
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageTransition>
  );
};

export default UserActivityMonitoring;
