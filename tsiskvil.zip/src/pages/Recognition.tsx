import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Award, Trophy, Star, Gift, Target, Users, Clock, GraduationCap, TrendingUp, ShoppingCart, Medal, Zap, Calendar, Check, Sparkles, Flame, Crown } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge as UIBadge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { motion, AnimatePresence } from "framer-motion";

interface Employee {
  id: string;
  full_name: string;
  photo_url?: string;
}

interface BadgeType {
  id: string;
  name: string;
  name_en?: string;
  description?: string;
  icon: string;
  color: string;
  criteria_type: string;
  criteria_value: number;
}

interface EmployeeBadge {
  id: string;
  badge_id: string;
  earned_at: string;
  badges?: BadgeType;
}

interface Challenge {
  id: string;
  name: string;
  description?: string;
  challenge_type: string;
  target_value: number;
  points_reward: number;
  start_date: string;
  end_date: string;
  status: string;
}

interface Reward {
  id: string;
  name: string;
  name_en?: string;
  description?: string;
  reward_type: string;
  points_cost: number;
  quantity_available?: number;
  is_active: boolean;
}

interface PointTransaction {
  id: string;
  points: number;
  transaction_type: string;
  reason: string;
  reason_type: string;
  created_at: string;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
} as const;

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: "spring" as const,
      stiffness: 100,
      damping: 15
    }
  }
} as const;

const pulseAnimation = {
  scale: [1, 1.05, 1],
  transition: {
    duration: 2,
    repeat: Infinity,
    ease: "easeInOut" as const
  }
};

const floatAnimation = {
  y: [0, -10, 0],
  transition: {
    duration: 3,
    repeat: Infinity,
    ease: "easeInOut" as const
  }
};

const sparkleAnimation = {
  rotate: [0, 360],
  scale: [1, 1.2, 1],
  transition: {
    duration: 4,
    repeat: Infinity,
    ease: "linear" as const
  }
};

export default function Recognition() {
  const [myPoints, setMyPoints] = useState({ current: 0, total: 0, level: 1 });
  const [myBadges, setMyBadges] = useState<EmployeeBadge[]>([]);
  const [allBadges, setAllBadges] = useState<BadgeType[]>([]);
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [challengeProgress, setChallengeProgress] = useState<Record<string, { progress: number; joined: boolean }>>({});

  const [rewards, setRewards] = useState<Reward[]>([]);
  const [transactions, setTransactions] = useState<PointTransaction[]>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isRedeemDialogOpen, setIsRedeemDialogOpen] = useState(false);
  const [selectedReward, setSelectedReward] = useState<Reward | null>(null);
  const [currentEmployeeId, setCurrentEmployeeId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("rewards");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    let empId: string | null = null;

    if (user) {
      const { data: emp } = await supabase
        .from("employees")
        .select("id")
        .eq("user_id", user.id)
        .maybeSingle();

      if (emp) {
        empId = emp.id;
        setCurrentEmployeeId(emp.id);
        await Promise.all([
          fetchMyPoints(emp.id),
          fetchMyBadges(emp.id),
          fetchTransactions(emp.id)
        ]);
      }
    }

    await Promise.all([
      fetchAllBadges(),
      fetchChallenges(empId),
      fetchRewards(),
      fetchLeaderboard()
    ]);

    
    setLoading(false);
  };

  const fetchMyPoints = async (employeeId: string) => {
    const { data } = await supabase
      .from("employee_points")
      .select("current_points, total_earned, level")
      .eq("employee_id", employeeId)
      .maybeSingle();
    
    if (data) {
      setMyPoints({
        current: data.current_points || 0,
        total: data.total_earned || 0,
        level: data.level || 1
      });
    }
  };

  const fetchMyBadges = async (employeeId: string) => {
    const { data } = await supabase
      .from("employee_badges")
      .select(`*, badges(*)`)
      .eq("employee_id", employeeId);
    
    if (data) {
      setMyBadges(data as any);
    }
  };

  const fetchTransactions = async (employeeId: string) => {
    const { data } = await supabase
      .from("point_transactions")
      .select("*")
      .eq("employee_id", employeeId)
      .order("created_at", { ascending: false })
      .limit(10);
    
    if (data) {
      setTransactions(data as any);
    }
  };

  const fetchAllBadges = async () => {
    const { data } = await supabase
      .from("badges")
      .select("*")
      .eq("is_active", true);
    
    if (data) {
      setAllBadges(data as any);
    }
  };

  const fetchChallenges = async (employeeId?: string | null) => {
    const { data } = await supabase
      .from("team_challenges")
      .select("*")
      .eq("status", "active")
      .order("end_date");

    if (data) {
      setChallenges(data as any);
      const empId = employeeId ?? currentEmployeeId;
      if (empId && data.length > 0) {
        const { data: parts } = await supabase
          .from("challenge_participants")
          .select("challenge_id, current_progress")
          .eq("employee_id", empId)
          .in("challenge_id", data.map((c: any) => c.id));

        const map: Record<string, { progress: number; joined: boolean }> = {};
        for (const c of data as any[]) {
          const p = parts?.find((x: any) => x.challenge_id === c.id);
          const pct = p && c.target_value > 0
            ? Math.min(100, Math.round((Number(p.current_progress) / Number(c.target_value)) * 100))
            : 0;
          map[c.id] = { progress: pct, joined: !!p };
        }
        setChallengeProgress(map);
      }
    }
  };

  const handleJoinChallenge = async (challengeId: string) => {
    if (!currentEmployeeId) return;
    const { error } = await supabase
      .from("challenge_participants")
      .insert({ challenge_id: challengeId, employee_id: currentEmployeeId, current_progress: 0 });
    if (error) {
      toast.error("შეცდომა ჩელენჯში გაწევრიანებისას");
      return;
    }
    toast.success("შემოგვიერთდი ჩელენჯს! 🔥");
    await fetchChallenges(currentEmployeeId);
  };


  const fetchRewards = async () => {
    const { data } = await supabase
      .from("reward_catalog")
      .select("*")
      .eq("is_active", true)
      .order("points_cost");
    
    if (data) {
      setRewards(data as any);
    }
  };

  const fetchLeaderboard = async () => {
    const { data } = await supabase
      .from("employee_points")
      .select(`
        current_points,
        total_earned,
        level,
        employees(id, full_name)
      `)
      .order("total_earned", { ascending: false })
      .limit(10);
    
    if (data) {
      setLeaderboard(data as any);
    }
  };

  const handleRedeemReward = async () => {
    if (!selectedReward || !currentEmployeeId) return;

    if (myPoints.current < selectedReward.points_cost) {
      toast.error("არასაკმარისი ქულები");
      return;
    }

    const { data, error } = await supabase.rpc("redeem_reward", {
      _reward_id: selectedReward.id,
    });

    if (error) {
      const msg = error.message || "";
      if (msg.includes("INSUFFICIENT_POINTS")) toast.error("არასაკმარისი ქულები");
      else if (msg.includes("OUT_OF_STOCK")) toast.error("ჯილდო ამოწურულია");
      else if (msg.includes("REWARD_NOT_AVAILABLE")) toast.error("ჯილდო მიუწვდომელია");
      else toast.error("შეცდომა ჯილდოს მოთხოვნისას");
      console.error(error);
      return;
    }

    toast.success("ჯილდოს მოთხოვნა გაგზავნილია! 🎉");
    setIsRedeemDialogOpen(false);
    setSelectedReward(null);
    await fetchMyPoints(currentEmployeeId);
    await fetchTransactions(currentEmployeeId);
  };


  const getBadgeIcon = (iconName: string) => {
    const icons: Record<string, any> = {
      Clock: Clock,
      Trophy: Trophy,
      Users: Users,
      GraduationCap: GraduationCap,
      Star: Star,
      Award: Award,
      Medal: Medal,
      Target: Target,
      Zap: Zap,
      Flame: Flame,
      Crown: Crown
    };
    const Icon = icons[iconName] || Award;
    return Icon;
  };

  const getBadgeColor = (color: string) => {
    const colors: Record<string, string> = {
      emerald: "text-emerald-500 bg-emerald-500/10",
      gold: "text-yellow-500 bg-yellow-500/10",
      blue: "text-blue-500 bg-blue-500/10",
      purple: "text-purple-500 bg-purple-500/10",
      amber: "text-amber-500 bg-amber-500/10"
    };
    return colors[color] || "text-primary bg-primary/10";
  };

  const getRewardTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      gift_card: "სასაჩუქრე ბარათი",
      extra_leave: "დამატებითი შვებულება",
      cash_bonus: "ფულადი პრემია",
      privilege: "პრივილეგია",
      other: "სხვა"
    };
    return labels[type] || type;
  };

  const getLevelProgress = () => {
    const levelThresholds = [0, 100, 500, 1000, 2500, 5000, 10000];
    const currentThreshold = levelThresholds[myPoints.level - 1] || 0;
    const nextThreshold = levelThresholds[myPoints.level] || levelThresholds[levelThresholds.length - 1];
    const progress = ((myPoints.total - currentThreshold) / (nextThreshold - currentThreshold)) * 100;
    return Math.min(100, Math.max(0, progress));
  };

  const getPositionEmoji = (index: number) => {
    if (index === 0) return "🥇";
    if (index === 1) return "🥈";
    if (index === 2) return "🥉";
    return null;
  };

  return (
    <>
      <div className="space-y-6">
        {/* Animated Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex justify-between items-center"
        >
          <div className="relative">
            <motion.div
              animate={sparkleAnimation}
              className="absolute -top-2 -right-8"
            >
              <Sparkles className="h-6 w-6 text-amber-400" />
            </motion.div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 bg-clip-text text-transparent">
              წამახალისებელი სისტემა
            </h1>
            <p className="text-muted-foreground mt-1">ქულები, ბეჯები და ჯილდოები</p>
          </div>
        </motion.div>

        {/* Animated Stats Cards */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid gap-4 md:grid-cols-4"
        >
          <motion.div variants={itemVariants}>
            <motion.div whileHover={{ scale: 1.02, y: -5 }} transition={{ type: "spring", stiffness: 300 }}>
              <Card className="bg-gradient-to-br from-primary/20 via-primary/10 to-transparent border-primary/20 overflow-hidden relative">
                <div className="absolute top-0 right-0 w-20 h-20 bg-primary/10 rounded-full blur-2xl" />
                <CardContent className="pt-6 relative">
                  <div className="flex items-center gap-4">
                    <motion.div 
                      animate={pulseAnimation}
                      className="p-3 bg-primary/20 rounded-full ring-2 ring-primary/30"
                    >
                      <Star className="h-6 w-6 text-primary" />
                    </motion.div>
                    <div className="flex-1">
                      <p className="text-sm text-muted-foreground">ხელმისაწვდომი ქულები</p>
                      <motion.p 
                        key={myPoints.current}
                        initial={{ scale: 1.5, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="text-3xl font-bold"
                      >
                        {myPoints.current}
                      </motion.p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>

          <motion.div variants={itemVariants}>
            <motion.div whileHover={{ scale: 1.02, y: -5 }} transition={{ type: "spring", stiffness: 300 }}>
              <Card className="bg-gradient-to-br from-emerald-500/20 via-emerald-500/10 to-transparent border-emerald-500/20 overflow-hidden relative">
                <div className="absolute top-0 right-0 w-20 h-20 bg-emerald-500/10 rounded-full blur-2xl" />
                <CardContent className="pt-6 relative">
                  <div className="flex items-center gap-4">
                    <motion.div 
                      animate={floatAnimation}
                      className="p-3 bg-emerald-500/20 rounded-full ring-2 ring-emerald-500/30"
                    >
                      <TrendingUp className="h-6 w-6 text-emerald-600" />
                    </motion.div>
                    <div className="flex-1">
                      <p className="text-sm text-muted-foreground">სულ მოგროვებული</p>
                      <p className="text-3xl font-bold">{myPoints.total}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>

          <motion.div variants={itemVariants}>
            <motion.div whileHover={{ scale: 1.02, y: -5 }} transition={{ type: "spring", stiffness: 300 }}>
              <Card className="bg-gradient-to-br from-amber-500/20 via-amber-500/10 to-transparent border-amber-500/20 overflow-hidden relative">
                <div className="absolute top-0 right-0 w-20 h-20 bg-amber-500/10 rounded-full blur-2xl" />
                <CardContent className="pt-6 relative">
                  <div className="flex items-center gap-4">
                    <motion.div 
                      animate={{ rotate: [0, 10, -10, 0] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="p-3 bg-amber-500/20 rounded-full ring-2 ring-amber-500/30"
                    >
                      <Trophy className="h-6 w-6 text-amber-600" />
                    </motion.div>
                    <div className="flex-1">
                      <p className="text-sm text-muted-foreground">დონე</p>
                      <div className="flex items-center gap-2">
                        <p className="text-3xl font-bold">{myPoints.level}</p>
                        <div className="flex-1">
                          <Progress value={getLevelProgress()} className="h-2 bg-amber-500/20" />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>

          <motion.div variants={itemVariants}>
            <motion.div whileHover={{ scale: 1.02, y: -5 }} transition={{ type: "spring", stiffness: 300 }}>
              <Card className="bg-gradient-to-br from-purple-500/20 via-purple-500/10 to-transparent border-purple-500/20 overflow-hidden relative">
                <div className="absolute top-0 right-0 w-20 h-20 bg-purple-500/10 rounded-full blur-2xl" />
                <CardContent className="pt-6 relative">
                  <div className="flex items-center gap-4">
                    <motion.div 
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                      className="p-3 bg-purple-500/20 rounded-full ring-2 ring-purple-500/30"
                    >
                      <Medal className="h-6 w-6 text-purple-600" />
                    </motion.div>
                    <div className="flex-1">
                      <p className="text-sm text-muted-foreground">მიღებული ბეჯები</p>
                      <p className="text-3xl font-bold">{myBadges.length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </motion.div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-4 w-full max-w-xl bg-muted/50 p-1">
            <TabsTrigger value="rewards" className="gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500 data-[state=active]:to-orange-500 data-[state=active]:text-white">
              <Gift className="h-4 w-4" />
              ჯილდოები
            </TabsTrigger>
            <TabsTrigger value="badges" className="gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-pink-500 data-[state=active]:text-white">
              <Medal className="h-4 w-4" />
              ბეჯები
            </TabsTrigger>
            <TabsTrigger value="challenges" className="gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-cyan-500 data-[state=active]:text-white">
              <Target className="h-4 w-4" />
              გამოწვევები
            </TabsTrigger>
            <TabsTrigger value="leaderboard" className="gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-emerald-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">
              <Trophy className="h-4 w-4" />
              ლიდერბორდი
            </TabsTrigger>
          </TabsList>

          {/* Rewards Catalog */}
          <TabsContent value="rewards" className="space-y-4">
            <AnimatePresence mode="wait">
              <motion.div 
                key="rewards"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                exit={{ opacity: 0 }}
                className="grid gap-4 md:grid-cols-2 lg:grid-cols-3"
              >
                {rewards.map((reward, index) => (
                  <motion.div
                    key={reward.id}
                    variants={itemVariants}
                    whileHover={{ scale: 1.03, y: -5 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <Card className="group hover:shadow-xl hover:shadow-amber-500/10 transition-all duration-300 border-amber-500/10 overflow-hidden relative h-full">
                      <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                      <CardHeader className="relative">
                        <div className="flex items-start justify-between">
                          <motion.div 
                            whileHover={{ rotate: 15 }}
                            className="p-3 bg-gradient-to-br from-amber-500/20 to-orange-500/20 rounded-xl"
                          >
                            <Gift className="h-6 w-6 text-amber-500" />
                          </motion.div>
                          <UIBadge variant="outline" className="gap-1 border-amber-500/30 bg-amber-500/10">
                            <Star className="h-3 w-3 text-amber-500 fill-amber-500" />
                            {reward.points_cost}
                          </UIBadge>
                        </div>
                        <CardTitle className="text-lg mt-3">{reward.name}</CardTitle>
                        <CardDescription>{reward.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="relative">
                        <div className="flex items-center justify-between">
                          <UIBadge variant="secondary" className="bg-muted/50">
                            {getRewardTypeLabel(reward.reward_type)}
                          </UIBadge>
                          <Button 
                            size="sm"
                            disabled={myPoints.current < reward.points_cost}
                            onClick={() => {
                              setSelectedReward(reward);
                              setIsRedeemDialogOpen(true);
                            }}
                            className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white border-0"
                          >
                            <ShoppingCart className="h-4 w-4 mr-1" />
                            გაცვლა
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
                {rewards.length === 0 && (
                  <motion.div variants={itemVariants} className="col-span-full">
                    <Card className="p-8 text-center">
                      <motion.div animate={floatAnimation}>
                        <Gift className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                      </motion.div>
                      <p className="text-muted-foreground">ჯილდოები ჯერ არ არის დამატებული</p>
                    </Card>
                  </motion.div>
                )}
              </motion.div>
            </AnimatePresence>
          </TabsContent>

          {/* Badges */}
          <TabsContent value="badges" className="space-y-4">
            <AnimatePresence mode="wait">
              <motion.div 
                key="badges"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                exit={{ opacity: 0 }}
                className="grid gap-4 md:grid-cols-2 lg:grid-cols-3"
              >
                {allBadges.map((badge, index) => {
                  const earned = myBadges.some(b => b.badge_id === badge.id);
                  const Icon = getBadgeIcon(badge.icon);
                  return (
                    <motion.div
                      key={badge.id}
                      variants={itemVariants}
                      whileHover={{ scale: earned ? 1.05 : 1.02 }}
                    >
                      <Card 
                        className={`transition-all duration-300 overflow-hidden relative ${
                          earned 
                            ? 'ring-2 ring-emerald-500/50 shadow-lg shadow-emerald-500/10' 
                            : 'opacity-60 hover:opacity-100 grayscale hover:grayscale-0'
                        }`}
                      >
                        {earned && (
                          <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-br from-emerald-500/5 to-transparent" />
                        )}
                        <CardContent className="pt-6 relative">
                          <div className="flex items-center gap-4">
                            <motion.div 
                              animate={earned ? { 
                                scale: [1, 1.1, 1],
                                rotate: [0, 5, -5, 0]
                              } : {}}
                              transition={{ duration: 2, repeat: Infinity }}
                              className={`p-4 rounded-full ${getBadgeColor(badge.color)} ring-2 ring-current/20`}
                            >
                              <Icon className="h-8 w-8" />
                            </motion.div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <h3 className="font-semibold">{badge.name}</h3>
                                {earned && (
                                  <motion.div
                                    initial={{ scale: 0 }}
                                    animate={{ scale: 1 }}
                                    transition={{ type: "spring", stiffness: 500 }}
                                  >
                                    <Check className="h-5 w-5 text-emerald-500" />
                                  </motion.div>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground">{badge.description}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
                {allBadges.length === 0 && (
                  <motion.div variants={itemVariants} className="col-span-full">
                    <Card className="p-8 text-center">
                      <motion.div animate={floatAnimation}>
                        <Medal className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                      </motion.div>
                      <p className="text-muted-foreground">ბეჯები ჯერ არ არის დამატებული</p>
                    </Card>
                  </motion.div>
                )}
              </motion.div>
            </AnimatePresence>
          </TabsContent>

          {/* Challenges */}
          <TabsContent value="challenges" className="space-y-4">
            <AnimatePresence mode="wait">
              <motion.div 
                key="challenges"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                exit={{ opacity: 0 }}
                className="grid gap-4 md:grid-cols-2"
              >
                {challenges.map((challenge, index) => (
                  <motion.div
                    key={challenge.id}
                    variants={itemVariants}
                    whileHover={{ scale: 1.02, y: -3 }}
                  >
                    <Card className="group hover:shadow-xl hover:shadow-blue-500/10 transition-all duration-300 border-blue-500/10 overflow-hidden relative">
                      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                      <CardHeader className="relative">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            <motion.div
                              animate={{ rotate: [0, 360] }}
                              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                            >
                              <Target className="h-5 w-5 text-blue-500" />
                            </motion.div>
                            <CardTitle className="text-lg">{challenge.name}</CardTitle>
                          </div>
                          <UIBadge className="gap-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                            <Flame className="h-3 w-3" />
                            +{challenge.points_reward}
                          </UIBadge>
                        </div>
                        <CardDescription>{challenge.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-3 relative">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="h-4 w-4" />
                          {new Date(challenge.start_date).toLocaleDateString('ka-GE')} - {new Date(challenge.end_date).toLocaleDateString('ka-GE')}
                        </div>
                        <div className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">პროგრესი</span>
                            <span className="font-medium">{challengeProgress[challenge.id]?.progress ?? 0}%</span>
                          </div>
                          <Progress value={challengeProgress[challenge.id]?.progress ?? 0} className="h-2 bg-blue-500/20" />
                        </div>
                        <p className="text-sm text-muted-foreground">მიზანი: {challenge.target_value}</p>
                        {challengeProgress[challenge.id]?.joined ? (
                          <UIBadge variant="secondary" className="gap-1">
                            <Check className="h-3 w-3" /> შემოერთებული ხართ
                          </UIBadge>
                        ) : (
                          <Button size="sm" onClick={() => handleJoinChallenge(challenge.id)} className="w-full">
                            <Flame className="h-4 w-4 mr-2" /> შემოგვიერთდი
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}

                {challenges.length === 0 && (
                  <motion.div variants={itemVariants} className="col-span-full">
                    <Card className="p-8 text-center">
                      <motion.div animate={floatAnimation}>
                        <Target className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                      </motion.div>
                      <p className="text-muted-foreground">აქტიური გამოწვევები არ არის</p>
                    </Card>
                  </motion.div>
                )}
              </motion.div>
            </AnimatePresence>
          </TabsContent>

          {/* Leaderboard */}
          <TabsContent value="leaderboard" className="space-y-4">
            <AnimatePresence mode="wait">
              <motion.div
                key="leaderboard"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                exit={{ opacity: 0 }}
                className="grid gap-4 lg:grid-cols-2"
              >
                <motion.div variants={itemVariants}>
                  <Card className="overflow-hidden">
                    <CardHeader className="bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-red-500/10">
                      <CardTitle className="flex items-center gap-2">
                        <motion.div animate={{ rotate: [0, 10, -10, 0] }} transition={{ duration: 2, repeat: Infinity }}>
                          <Trophy className="h-5 w-5 text-amber-500" />
                        </motion.div>
                        საუკეთესო 10 თანამშრომელი
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="divide-y divide-border/50">
                        {leaderboard.map((entry, index) => (
                          <motion.div 
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            whileHover={{ x: 5, backgroundColor: "hsl(var(--muted) / 0.5)" }}
                            className={`flex items-center gap-4 p-4 transition-all ${
                              index === 0 ? 'bg-gradient-to-r from-amber-500/10 to-transparent' :
                              index === 1 ? 'bg-gradient-to-r from-slate-400/10 to-transparent' :
                              index === 2 ? 'bg-gradient-to-r from-orange-400/10 to-transparent' :
                              ''
                            }`}
                          >
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg ${
                              index === 0 ? 'bg-gradient-to-br from-amber-400 to-amber-600 text-white shadow-lg shadow-amber-500/30' :
                              index === 1 ? 'bg-gradient-to-br from-slate-300 to-slate-500 text-white shadow-lg shadow-slate-400/30' :
                              index === 2 ? 'bg-gradient-to-br from-orange-300 to-orange-500 text-white shadow-lg shadow-orange-400/30' :
                              'bg-muted text-muted-foreground'
                            }`}>
                              {getPositionEmoji(index) || index + 1}
                            </div>
                            <Avatar className="h-10 w-10 ring-2 ring-background">
                              <AvatarFallback className="bg-primary/10 text-primary font-medium">
                                {entry.employees?.full_name?.charAt(0) || '?'}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <p className="font-medium">{entry.employees?.full_name || 'უცნობი'}</p>
                              <p className="text-sm text-muted-foreground">დონე {entry.level}</p>
                            </div>
                            <div className="text-right">
                              <motion.p 
                                className="font-bold text-lg"
                                initial={{ scale: 1 }}
                                whileHover={{ scale: 1.1 }}
                              >
                                {entry.total_earned}
                              </motion.p>
                              <p className="text-xs text-muted-foreground">ქულა</p>
                            </div>
                          </motion.div>
                        ))}
                        {leaderboard.length === 0 && (
                          <div className="p-8 text-center">
                            <motion.div animate={floatAnimation}>
                              <Trophy className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                            </motion.div>
                            <p className="text-muted-foreground">ლიდერბორდი ცარიელია</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Recent Transactions */}
                <motion.div variants={itemVariants}>
                  {transactions.length > 0 ? (
                    <Card className="overflow-hidden">
                      <CardHeader className="bg-gradient-to-r from-primary/10 to-transparent">
                        <CardTitle className="flex items-center gap-2">
                          <Zap className="h-5 w-5 text-primary" />
                          ბოლო ტრანზაქციები
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-0">
                        <div className="divide-y divide-border/50">
                          {transactions.map((tx, index) => (
                            <motion.div 
                              key={tx.id}
                              initial={{ opacity: 0, x: 20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: index * 0.1 }}
                              className="flex items-center justify-between p-4 hover:bg-muted/30 transition-colors"
                            >
                              <div>
                                <p className="font-medium">{tx.reason}</p>
                                <p className="text-xs text-muted-foreground">
                                  {new Date(tx.created_at).toLocaleDateString('ka-GE')}
                                </p>
                              </div>
                              <motion.div whileHover={{ scale: 1.1 }}>
                                <UIBadge 
                                  variant={tx.points > 0 ? 'default' : 'destructive'}
                                  className={tx.points > 0 ? 'bg-emerald-500 hover:bg-emerald-600' : ''}
                                >
                                  {tx.points > 0 ? '+' : ''}{tx.points}
                                </UIBadge>
                              </motion.div>
                            </motion.div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ) : (
                    <Card className="p-8 text-center h-full flex items-center justify-center">
                      <div>
                        <motion.div animate={floatAnimation}>
                          <Zap className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                        </motion.div>
                        <p className="text-muted-foreground">ტრანზაქციები არ არის</p>
                      </div>
                    </Card>
                  )}
                </motion.div>
              </motion.div>
            </AnimatePresence>
          </TabsContent>
        </Tabs>

        {/* Redeem Dialog */}
        <Dialog open={isRedeemDialogOpen} onOpenChange={setIsRedeemDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Gift className="h-5 w-5 text-amber-500" />
                ჯილდოს გაცვლა
              </DialogTitle>
              <DialogDescription>
                დარწმუნებული ხართ, რომ გსურთ ამ ჯილდოს გაცვლა?
              </DialogDescription>
            </DialogHeader>
            {selectedReward && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-4"
              >
                <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/20">
                  <h3 className="font-semibold text-lg">{selectedReward.name}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{selectedReward.description}</p>
                  <div className="mt-3 flex items-center gap-2">
                    <Star className="h-5 w-5 text-amber-500 fill-amber-500" />
                    <span className="font-bold text-lg">{selectedReward.points_cost} ქულა</span>
                  </div>
                </div>
                <div className="space-y-2 p-4 bg-muted/50 rounded-lg">
                  <div className="flex items-center justify-between text-sm">
                    <span>თქვენი ქულები:</span>
                    <span className="font-bold">{myPoints.current}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>გაცვლის შემდეგ:</span>
                    <span className="font-bold text-emerald-500">{myPoints.current - selectedReward.points_cost}</span>
                  </div>
                </div>
                <div className="flex gap-2 justify-end">
                  <Button variant="outline" onClick={() => setIsRedeemDialogOpen(false)}>
                    გაუქმება
                  </Button>
                  <Button 
                    onClick={handleRedeemReward}
                    className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white border-0"
                  >
                    <Gift className="h-4 w-4 mr-2" />
                    გაცვლა
                  </Button>
                </div>
              </motion.div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}
