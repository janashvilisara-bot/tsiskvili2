import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { MessageSquare, Send, History, Bell } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

interface SMSNotificationSetting {
  id: string;
  notification_type: string;
  sms_enabled: boolean;
  description: string;
}

interface SMSLog {
  id: string;
  recipient: string;
  message: string;
  status: string;
  sent_at: string;
  twilio_sid: string | null;
}

export default function SMSSettings() {
  const [settings, setSettings] = useState<SMSNotificationSetting[]>([]);
  const [logs, setLogs] = useState<SMSLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [testPhone, setTestPhone] = useState("");
  const [testMessage, setTestMessage] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    fetchSettings();
    fetchLogs();
  }, []);

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('sms_notification_settings')
        .select('*')
        .order('notification_type');

      if (error) throw error;
      setSettings(data || []);
    } catch (error: any) {
      toast.error('პარამეტრების ჩატვირთვა ვერ მოხერხდა');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('sms_logs')
        .select('*')
        .order('sent_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setLogs(data || []);
    } catch (error: any) {
      console.error('SMS ლოგების ჩატვირთვა ვერ მოხერხდა', error);
    }
  };

  const handleToggleSMS = async (id: string, currentValue: boolean) => {
    try {
      const { error } = await supabase
        .from('sms_notification_settings')
        .update({ sms_enabled: !currentValue })
        .eq('id', id);

      if (error) throw error;
      
      toast.success(currentValue ? 'SMS გამორთულია' : 'SMS ჩართულია');
      fetchSettings();
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const handleSendTestSMS = async () => {
    if (!testPhone || !testMessage) {
      toast.error('შეავსეთ ყველა ველი');
      return;
    }

    try {
      setSending(true);
      const { error } = await supabase.functions.invoke('send-cloudsms', {
        body: {
          to: testPhone,
          message: testMessage
        }
      });

      if (error) throw error;
      
      toast.success('SMS გაიგზავნა წარმატებით');
      setTestPhone('');
      setTestMessage('');
      fetchLogs();
    } catch (error: any) {
      toast.error('გაგზავნა ვერ მოხერხდა: ' + error.message);
      console.error(error);
    } finally {
      setSending(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'sent':
        return 'default';
      case 'failed':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      leave_request_approved: 'შვებულება დამტკიცდა',
      leave_request_rejected: 'შვებულება უარყოფილია',
      payroll_processed: 'ხელფასი დამუშავდა',
      task_assigned: 'დავალება მიენიჭა',
      emergency_alert: 'გადაუდებელი შეტყობინება',
      contract_expiring: 'ხელშეკრულება იწურება',
      budget_overspending: 'ბიუჯეტის გადაჭარბება',
      expense_approved: 'ხარჯი დამტკიცდა',
      expense_rejected: 'ხარჯი უარყოფილია'
    };
    return labels[type] || type;
  };

  return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">SMS შეტყობინებების პარამეტრები</h1>
          <p className="text-muted-foreground">
            მართეთ SMS შეტყობინებები და კონფიგურაცია
          </p>
        </div>

        <Tabs defaultValue="settings" className="space-y-4">
          <TabsList>
            <TabsTrigger value="settings">
              <Bell className="h-4 w-4 mr-2" />
              კონფიგურაცია
            </TabsTrigger>
            <TabsTrigger value="test">
              <Send className="h-4 w-4 mr-2" />
              ტესტირება
            </TabsTrigger>
            <TabsTrigger value="logs">
              <History className="h-4 w-4 mr-2" />
              ისტორია
            </TabsTrigger>
          </TabsList>

          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>შეტყობინებების ტიპები</CardTitle>
                <CardDescription>
                  აირჩიეთ რომელი შეტყობინებები უნდა გაიგზავნოს SMS-ით
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <p>იტვირთება...</p>
                ) : (
                  <div className="space-y-4">
                    {settings.map((setting) => (
                      <div
                        key={setting.id}
                        className="flex items-center justify-between p-4 border rounded-lg"
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-3">
                            <MessageSquare className="h-5 w-5 text-muted-foreground" />
                            <div>
                              <h3 className="font-medium">
                                {getTypeLabel(setting.notification_type)}
                              </h3>
                              <p className="text-sm text-muted-foreground">
                                {setting.description}
                              </p>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Label htmlFor={`sms-${setting.id}`} className="cursor-pointer">
                            {setting.sms_enabled ? 'ჩართული' : 'გამორთული'}
                          </Label>
                          <Switch
                            id={`sms-${setting.id}`}
                            checked={setting.sms_enabled}
                            onCheckedChange={() =>
                              handleToggleSMS(setting.id, setting.sms_enabled)
                            }
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="test" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>SMS ტესტირება</CardTitle>
                <CardDescription>
                  გაგზავნეთ სატესტო SMS რათა შეამოწმოთ კონფიგურაცია
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="test-phone">ტელეფონის ნომერი</Label>
                  <Input
                    id="test-phone"
                    type="tel"
                    placeholder="+995555123456"
                    value={testPhone}
                    onChange={(e) => setTestPhone(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    ნომერი უნდა იყოს სრულ საერთაშორისო ფორმატში (+995...)
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="test-message">შეტყობინება</Label>
                  <Textarea
                    id="test-message"
                    placeholder="შეიყვანეთ სატესტო შეტყობინება..."
                    value={testMessage}
                    onChange={(e) => setTestMessage(e.target.value)}
                    rows={4}
                  />
                </div>

                <Button
                  onClick={handleSendTestSMS}
                  disabled={sending || !testPhone || !testMessage}
                  className="w-full"
                >
                  <Send className="h-4 w-4 mr-2" />
                  {sending ? 'იგზავნება...' : 'SMS-ის გაგზავნა'}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>გაგზავნილი SMS-ები</CardTitle>
                <CardDescription>
                  ბოლო 50 გაგზავნილი შეტყობინება
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {logs.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">
                      გაგზავნილი SMS-ები არ არის
                    </p>
                  ) : (
                    logs.map((log) => (
                      <div
                        key={log.id}
                        className="flex items-start justify-between p-4 border rounded-lg"
                      >
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2">
                            <Badge variant={getStatusColor(log.status)}>
                              {log.status === 'sent' ? 'გაგზავნილია' : 'წარუმატებელი'}
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              {log.sent_at && !isNaN(new Date(log.sent_at).getTime())
                                ? format(new Date(log.sent_at), 'dd/MM/yyyy HH:mm')
                                : "-"}
                            </span>
                          </div>
                          <p className="font-medium">{log.recipient}</p>
                          <p className="text-sm text-muted-foreground">{log.message}</p>
                          {log.twilio_sid && (
                            <p className="text-xs text-muted-foreground">
                              SID: {log.twilio_sid}
                            </p>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
  );
}
