import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Eye, BarChart3, ExternalLink, Megaphone } from "lucide-react";
import { format } from "date-fns";
import { useLanguage } from "@/contexts/LanguageContext";

interface Advertisement {
  id: string;
  title: string;
  description: string | null;
  image_url: string | null;
  link_url: string | null;
  ad_type: string;
  placement: string;
  priority: number;
  start_date: string | null;
  end_date: string | null;
  is_active: boolean;
  click_count: number;
  view_count: number;
  target_roles: string[];
  created_at: string;
}

const defaultFormData = {
  title: "",
  description: "",
  image_url: "",
  link_url: "",
  ad_type: "internal",
  placement: "dashboard",
  priority: 0,
  start_date: "",
  end_date: "",
  is_active: true,
  target_roles: [] as string[],
};

const AdvertisementManagement = () => {
  const { language } = useLanguage();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAd, setEditingAd] = useState<Advertisement | null>(null);
  const [formData, setFormData] = useState(defaultFormData);

  const t = {
    title: language === "ka" ? "სარეკლამო მოდული" : "Advertisement Management",
    subtitle: language === "ka" ? "მართეთ შიდა და გარე რეკლამები" : "Manage internal and external advertisements",
    addNew: language === "ka" ? "დამატება" : "Add New",
    adTitle: language === "ka" ? "სათაური" : "Title",
    description: language === "ka" ? "აღწერა" : "Description",
    imageUrl: language === "ka" ? "სურათის URL" : "Image URL",
    linkUrl: language === "ka" ? "ბმული" : "Link URL",
    adType: language === "ka" ? "ტიპი" : "Type",
    internal: language === "ka" ? "შიდა პრომო" : "Internal Promo",
    external: language === "ka" ? "გარე რეკლამა" : "External Ad",
    placement: language === "ka" ? "განთავსება" : "Placement",
    dashboard: language === "ka" ? "Dashboard" : "Dashboard",
    sidebar: language === "ka" ? "გვერდითა პანელი" : "Sidebar",
    popup: language === "ka" ? "Pop-up" : "Pop-up",
    custom: language === "ka" ? "სხვა" : "Custom",
    priority: language === "ka" ? "პრიორიტეტი" : "Priority",
    startDate: language === "ka" ? "დაწყების თარიღი" : "Start Date",
    endDate: language === "ka" ? "დასრულების თარიღი" : "End Date",
    isActive: language === "ka" ? "აქტიური" : "Active",
    save: language === "ka" ? "შენახვა" : "Save",
    cancel: language === "ka" ? "გაუქმება" : "Cancel",
    edit: language === "ka" ? "რედაქტირება" : "Edit",
    delete: language === "ka" ? "წაშლა" : "Delete",
    views: language === "ka" ? "ნახვები" : "Views",
    clicks: language === "ka" ? "კლიკები" : "Clicks",
    status: language === "ka" ? "სტატუსი" : "Status",
    actions: language === "ka" ? "მოქმედებები" : "Actions",
    active: language === "ka" ? "აქტიური" : "Active",
    inactive: language === "ka" ? "არააქტიური" : "Inactive",
    noAds: language === "ka" ? "რეკლამები არ არის დამატებული" : "No advertisements added",
    createFirst: language === "ka" ? "შექმენით პირველი რეკლამა" : "Create your first advertisement",
    addAdTitle: language === "ka" ? "ახალი რეკლამის დამატება" : "Add New Advertisement",
    editAdTitle: language === "ka" ? "რეკლამის რედაქტირება" : "Edit Advertisement",
    deleteConfirm: language === "ka" ? "ნამდვილად გსურთ წაშლა?" : "Are you sure you want to delete?",
    stats: language === "ka" ? "სტატისტიკა" : "Statistics",
    totalAds: language === "ka" ? "სულ რეკლამები" : "Total Ads",
    activeAds: language === "ka" ? "აქტიური" : "Active",
    totalViews: language === "ka" ? "სულ ნახვები" : "Total Views",
    totalClicks: language === "ka" ? "სულ კლიკები" : "Total Clicks",
  };

  const { data: advertisements = [], isLoading } = useQuery({
    queryKey: ["advertisements"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("advertisements")
        .select("*")
        .order("priority", { ascending: false });
      
      if (error) throw error;
      return data as Advertisement[];
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const { error } = await supabase.from("advertisements").insert({
        title: data.title,
        description: data.description || null,
        image_url: data.image_url || null,
        link_url: data.link_url || null,
        ad_type: data.ad_type,
        placement: data.placement,
        priority: data.priority,
        start_date: data.start_date || null,
        end_date: data.end_date || null,
        is_active: data.is_active,
        target_roles: data.target_roles,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["advertisements"] });
      toast.success(language === "ka" ? "რეკლამა დამატებულია" : "Advertisement added");
      handleCloseDialog();
    },
    onError: (error: any) => {
      toast.error(error.message);
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof formData }) => {
      const { error } = await supabase
        .from("advertisements")
        .update({
          title: data.title,
          description: data.description || null,
          image_url: data.image_url || null,
          link_url: data.link_url || null,
          ad_type: data.ad_type,
          placement: data.placement,
          priority: data.priority,
          start_date: data.start_date || null,
          end_date: data.end_date || null,
          is_active: data.is_active,
          target_roles: data.target_roles,
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["advertisements"] });
      toast.success(language === "ka" ? "რეკლამა განახლებულია" : "Advertisement updated");
      handleCloseDialog();
    },
    onError: (error: any) => {
      toast.error(error.message);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("advertisements").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["advertisements"] });
      toast.success(language === "ka" ? "რეკლამა წაშლილია" : "Advertisement deleted");
    },
    onError: (error: any) => {
      toast.error(error.message);
    },
  });

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingAd(null);
    setFormData(defaultFormData);
  };

  const handleEdit = (ad: Advertisement) => {
    setEditingAd(ad);
    setFormData({
      title: ad.title,
      description: ad.description || "",
      image_url: ad.image_url || "",
      link_url: ad.link_url || "",
      ad_type: ad.ad_type,
      placement: ad.placement,
      priority: ad.priority,
      start_date: ad.start_date ? ad.start_date.split("T")[0] : "",
      end_date: ad.end_date ? ad.end_date.split("T")[0] : "",
      is_active: ad.is_active,
      target_roles: ad.target_roles || [],
    });
    setIsDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingAd) {
      updateMutation.mutate({ id: editingAd.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const getPlacementLabel = (placement: string) => {
    const labels: Record<string, string> = {
      dashboard: t.dashboard,
      sidebar: t.sidebar,
      popup: t.popup,
      custom: t.custom,
    };
    return labels[placement] || placement;
  };

  const stats = {
    total: advertisements.length,
    active: advertisements.filter(a => a.is_active).length,
    totalViews: advertisements.reduce((sum, a) => sum + a.view_count, 0),
    totalClicks: advertisements.reduce((sum, a) => sum + a.click_count, 0),
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20">
            <Megaphone className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{t.title}</h1>
            <p className="text-muted-foreground">{t.subtitle}</p>
          </div>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2" onClick={() => setFormData(defaultFormData)}>
              <Plus className="h-4 w-4" />
              {t.addNew}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingAd ? t.editAdTitle : t.addAdTitle}</DialogTitle>
              <DialogDescription>
                {language === "ka" ? "შეავსეთ ველები რეკლამის შესაქმნელად" : "Fill in the fields to create an advertisement"}
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">{t.adTitle} *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="ad_type">{t.adType}</Label>
                  <Select
                    value={formData.ad_type}
                    onValueChange={(value) => setFormData({ ...formData, ad_type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="internal">{t.internal}</SelectItem>
                      <SelectItem value="external">{t.external}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">{t.description}</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="image_url">{t.imageUrl}</Label>
                  <Input
                    id="image_url"
                    type="url"
                    value={formData.image_url}
                    onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="link_url">{t.linkUrl}</Label>
                  <Input
                    id="link_url"
                    type="url"
                    value={formData.link_url}
                    onChange={(e) => setFormData({ ...formData, link_url: e.target.value })}
                    placeholder="https://example.com"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="placement">{t.placement}</Label>
                  <Select
                    value={formData.placement}
                    onValueChange={(value) => setFormData({ ...formData, placement: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dashboard">{t.dashboard}</SelectItem>
                      <SelectItem value="sidebar">{t.sidebar}</SelectItem>
                      <SelectItem value="popup">{t.popup}</SelectItem>
                      <SelectItem value="custom">{t.custom}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="priority">{t.priority}</Label>
                  <Input
                    id="priority"
                    type="number"
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value) || 0 })}
                    min={0}
                    max={100}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="start_date">{t.startDate}</Label>
                  <Input
                    id="start_date"
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="end_date">{t.endDate}</Label>
                  <Input
                    id="end_date"
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                  />
                  <Label htmlFor="is_active">{t.isActive}</Label>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={handleCloseDialog}>
                  {t.cancel}
                </Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                  {t.save}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card/50 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-sm text-muted-foreground">{t.totalAds}</p>
          </CardContent>
        </Card>
        <Card className="bg-card/50 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-success">{stats.active}</div>
            <p className="text-sm text-muted-foreground">{t.activeAds}</p>
          </CardContent>
        </Card>
        <Card className="bg-card/50 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold flex items-center gap-1">
              <Eye className="h-5 w-5 text-muted-foreground" />
              {stats.totalViews}
            </div>
            <p className="text-sm text-muted-foreground">{t.totalViews}</p>
          </CardContent>
        </Card>
        <Card className="bg-card/50 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold flex items-center gap-1">
              <BarChart3 className="h-5 w-5 text-muted-foreground" />
              {stats.totalClicks}
            </div>
            <p className="text-sm text-muted-foreground">{t.totalClicks}</p>
          </CardContent>
        </Card>
      </div>

      {/* Advertisements Table */}
      <Card className="bg-card/50 backdrop-blur-sm">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">Loading...</div>
          ) : advertisements.length === 0 ? (
            <div className="p-8 text-center">
              <Megaphone className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground mb-2">{t.noAds}</p>
              <p className="text-sm text-muted-foreground">{t.createFirst}</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t.adTitle}</TableHead>
                  <TableHead>{t.adType}</TableHead>
                  <TableHead>{t.placement}</TableHead>
                  <TableHead className="text-center">{t.views}</TableHead>
                  <TableHead className="text-center">{t.clicks}</TableHead>
                  <TableHead>{t.status}</TableHead>
                  <TableHead className="text-right">{t.actions}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {advertisements.map((ad) => (
                  <TableRow key={ad.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {ad.image_url && (
                          <img 
                            src={ad.image_url} 
                            alt={ad.title}
                            className="w-10 h-10 rounded object-cover"
                          />
                        )}
                        <div>
                          <div className="font-medium">{ad.title}</div>
                          {ad.link_url && (
                            <a 
                              href={ad.link_url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-xs text-primary flex items-center gap-1 hover:underline"
                            >
                              <ExternalLink className="h-3 w-3" />
                              {ad.link_url.slice(0, 30)}...
                            </a>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={ad.ad_type === "internal" ? "secondary" : "outline"}>
                        {ad.ad_type === "internal" ? t.internal : t.external}
                      </Badge>
                    </TableCell>
                    <TableCell>{getPlacementLabel(ad.placement)}</TableCell>
                    <TableCell className="text-center">{ad.view_count}</TableCell>
                    <TableCell className="text-center">{ad.click_count}</TableCell>
                    <TableCell>
                      <Badge variant={ad.is_active ? "default" : "secondary"}>
                        {ad.is_active ? t.active : t.inactive}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(ad)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            if (confirm(t.deleteConfirm)) {
                              deleteMutation.mutate(ad.id);
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdvertisementManagement;
