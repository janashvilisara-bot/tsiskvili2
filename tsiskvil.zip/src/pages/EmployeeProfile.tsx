import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { User, Mail, Phone, Upload, Lock, Save, Camera, MapPin, GraduationCap, Briefcase, AlertCircle, Building, DollarSign } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { PageTransition } from "@/components/PageTransition";
import { useNavigate } from "react-router-dom";
import { z } from "zod";
import { calculateProfileCompletion } from "@/lib/profileCompletion";
import { compressImageToWebP } from "@/lib/imageCompression";
import CareerTimeline from "@/components/CareerTimeline";

const profileSchema = z.object({
  full_name: z.string().trim().min(2, "სახელი უნდა იყოს მინიმუმ 2 სიმბოლო").max(100, "სახელი უნდა იყოს მაქსიმუმ 100 სიმბოლო"),
  phone: z.string().trim().regex(/^[0-9+\-\s()]*$/, "არასწორი ტელეფონის ნომერი").max(20, "ტელეფონის ნომერი უნდა იყოს მაქსიმუმ 20 სიმბოლო").optional().or(z.literal("")),
  email: z.string().trim().email("არასწორი ელფოსტის მისამართი").max(255, "ელფოსტა უნდა იყოს მაქსიმუმ 255 სიმბოლო"),
  actual_address: z.string().optional().or(z.literal("")),
  education: z.string().optional().or(z.literal("")),
  education_level: z.string().optional().or(z.literal("")),
  personal_id_number: z.string().optional().or(z.literal("")),
  previous_experience: z.string().optional().or(z.literal("")),
  emergency_contact_name: z.string().optional().or(z.literal("")),
  emergency_contact_phone: z.string().trim().regex(/^[0-9+\-\s()]*$/, "არასწორი ტელეფონის ნომერი").optional().or(z.literal("")),
  emergency_contact_relation: z.string().optional().or(z.literal("")),
  bank_account_number: z.string().optional().or(z.literal("")),
  bank_name: z.string().optional().or(z.literal("")),
  tax_benefits: z.string().optional().or(z.literal("")),
});

const passwordSchema = z.object({
  currentPassword: z.string().min(1, "შეიყვანეთ მიმდინარე პაროლი"),
  newPassword: z.string().min(6, "ახალი პაროლი უნდა იყოს მინიმუმ 6 სიმბოლო").max(50, "პაროლი უნდა იყოს მაქსიმუმ 50 სიმბოლო"),
  confirmPassword: z.string().min(1, "დაადასტურეთ ახალი პაროლი"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "პაროლები არ ემთხვევა",
  path: ["confirmPassword"],
});

export default function EmployeeProfile() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [employee, setEmployee] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    actual_address: "",
    education: "",
    education_level: "",
    personal_id_number: "",
    previous_experience: "",
    emergency_contact_name: "",
    emergency_contact_phone: "",
    emergency_contact_relation: "",
    bank_account_number: "",
    bank_name: "",
    tax_benefits: "",
  });
  const [profileCompletion, setProfileCompletion] = useState(0);
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (user) {
      fetchEmployeeData();
    }
  }, [user]);

  const fetchEmployeeData = async () => {
    setLoading(true);
    try {
      const { data: empData } = await supabase
        .from('employees')
        .select('*')
        .eq('email', user?.email)
        .maybeSingle();
      
      if (empData) {
        setEmployee(empData);
        setFormData({
          full_name: empData.full_name || "",
          email: empData.email || "",
          phone: empData.phone || "",
          actual_address: empData.actual_address || "",
          education: empData.education || "",
          education_level: empData.education_level || "",
          personal_id_number: empData.personal_id_number || "",
          previous_experience: empData.previous_experience || "",
          emergency_contact_name: empData.emergency_contact_name || "",
          emergency_contact_phone: empData.emergency_contact_phone || "",
          emergency_contact_relation: empData.emergency_contact_relation || "",
          bank_account_number: empData.bank_account_number || "",
          bank_name: empData.bank_name || "",
          tax_benefits: empData.tax_benefits || "",
        });
        setProfileCompletion(calculateProfileCompletion(empData));
      }
    } catch (error: any) {
      console.error('Error fetching employee data:', error);
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !employee) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('გთხოვთ აირჩიოთ სურათის ფაილი');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('ფაილის ზომა არ უნდა აღემატებოდეს 5MB-ს');
      return;
    }

    setUploadingAvatar(true);
    try {
      // Compress to WebP (max 512px, ~50-80% smaller)
      const compressed = await compressImageToWebP(file, { maxDimension: 512 });
      const fileExt = compressed.name.split('.').pop();
      const fileName = `${employee.id}-${Date.now()}.${fileExt}`;
      const filePath = `avatars/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('documents')
        .upload(filePath, compressed, { contentType: compressed.type });

      if (uploadError) throw uploadError;

      const { data: signedData, error: signedError } = await supabase.storage
        .from('documents')
        .createSignedUrl(filePath, 60 * 60 * 24 * 365);
      if (signedError) throw signedError;
      const publicUrl = signedData.signedUrl;

      const { error: updateError } = await supabase
        .from('employees')
        .update({ avatar_url: publicUrl })
        .eq('id', employee.id);

      if (updateError) throw updateError;

      setEmployee({ ...employee, avatar_url: publicUrl });
      toast.success('ავატარი წარმატებით განახლდა');
    } catch (error: any) {
      console.error('Error uploading avatar:', error);
      toast.error('ავატარის ატვირთვა ვერ მოხერხდა');
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleProfileUpdate = async () => {
    try {
      const validatedData = profileSchema.parse(formData);
      setSaving(true);
      setErrors({});

      const { error } = await supabase
        .from('employees')
        .update({
          full_name: validatedData.full_name,
          email: validatedData.email,
          phone: validatedData.phone || null,
          actual_address: validatedData.actual_address || null,
          education: validatedData.education || null,
          education_level: validatedData.education_level || null,
          personal_id_number: validatedData.personal_id_number || null,
          previous_experience: validatedData.previous_experience || null,
          emergency_contact_name: validatedData.emergency_contact_name || null,
          emergency_contact_phone: validatedData.emergency_contact_phone || null,
          emergency_contact_relation: validatedData.emergency_contact_relation || null,
          bank_account_number: validatedData.bank_account_number || null,
          bank_name: validatedData.bank_name || null,
          tax_benefits: validatedData.tax_benefits || null,
        })
        .eq('id', employee.id);

      if (error) throw error;

      toast.success('პროფილი წარმატებით განახლდა');
      await fetchEmployeeData();
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
        toast.error('გთხოვთ შეავსოთ ყველა ველი სწორად');
      } else {
        console.error('Error updating profile:', error);
        toast.error('პროფილის განახლება ვერ მოხერხდა');
      }
    } finally {
      setSaving(false);
    }
  };

  const handlePasswordUpdate = async () => {
    try {
      const validatedData = passwordSchema.parse(passwordData);
      setSaving(true);
      setErrors({});

      // Verify current password by signing in
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user?.email || '',
        password: validatedData.currentPassword,
      });

      if (signInError) {
        setErrors({ currentPassword: 'არასწორი მიმდინარე პაროლი' });
        toast.error('არასწორი მიმდინარე პაროლი');
        return;
      }

      // Update password
      const { error: updateError } = await supabase.auth.updateUser({
        password: validatedData.newPassword,
      });

      if (updateError) throw updateError;

      toast.success('პაროლი წარმატებით შეიცვალა');
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
        toast.error('გთხოვთ შეავსოთ ყველა ველი სწორად');
      } else {
        console.error('Error updating password:', error);
        toast.error('პაროლის შეცვლა ვერ მოხერხდა');
      }
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <PageTransition>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <div className="container max-w-4xl mx-auto py-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">პროფილის რედაქტირება</h1>
            <div className="mt-2 flex items-center gap-3">
              <span className="text-sm text-muted-foreground">პროფილის სისრულე:</span>
              <div className="flex-1 max-w-xs">
                <Progress value={profileCompletion} className="h-2" />
              </div>
              <span className="text-sm font-semibold text-primary">{profileCompletion}%</span>
            </div>
          </div>
          <Button variant="outline" onClick={() => navigate('/employee-portal')}>
            უკან დაბრუნება
          </Button>
        </div>

        {/* Avatar Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Camera className="h-5 w-5" />
              პროფილის სურათი
            </CardTitle>
          </CardHeader>
          <CardContent className="flex items-center gap-6">
            <Avatar className="h-32 w-32">
              <AvatarImage src={employee?.avatar_url} />
              <AvatarFallback className="bg-primary/10 text-4xl">
                {employee?.full_name?.charAt(0) || 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col gap-2">
              <Label htmlFor="avatar-upload" className="cursor-pointer">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-md hover:from-blue-600 hover:to-blue-700 transition-all shadow-md hover:shadow-lg">
                  <Upload className="h-4 w-4" />
                  {uploadingAvatar ? 'იტვირთება...' : 'ატვირთვა'}
                </div>
              </Label>
              <Input
                id="avatar-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleAvatarUpload}
                disabled={uploadingAvatar}
              />
              <p className="text-sm text-muted-foreground">
                JPG, PNG ან GIF. მაქს. 5MB.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              პირადი ინფორმაცია
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="full_name">სახელი და გვარი *</Label>
                <Input
                  id="full_name"
                  name="full_name"
                  value={formData.full_name}
                  onChange={handleInputChange}
                  placeholder="შეიყვანეთ სახელი და გვარი"
                  maxLength={100}
                />
                {errors.full_name && (
                  <p className="text-sm text-destructive">{errors.full_name}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">ელფოსტა *</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    className="pl-10"
                    disabled
                    maxLength={255}
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  ელფოსტის შეცვლა შეუძლებელია
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">ტელეფონი</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder="შეიყვანეთ ტელეფონის ნომერი"
                    className="pl-10"
                    maxLength={20}
                  />
                </div>
                {errors.phone && (
                  <p className="text-sm text-destructive">{errors.phone}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="personal_id_number">პირადი ნომერი</Label>
                <Input
                  id="personal_id_number"
                  name="personal_id_number"
                  value={formData.personal_id_number}
                  onChange={handleInputChange}
                  placeholder="შეიყვანეთ პირადი ნომერი"
                  maxLength={11}
                />
                {errors.personal_id_number && (
                  <p className="text-sm text-destructive">{errors.personal_id_number}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>თანამდებობა</Label>
                <Input
                  value={employee?.position || ''}
                  disabled
                />
                <p className="text-xs text-muted-foreground">
                  თანამდებობის შეცვლა შეუძლებელია
                </p>
              </div>
            </div>
            
            {/* Address Section */}
            <div className="pt-6 border-t">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                მისამართი
              </h3>
              <div className="space-y-2">
                <Label htmlFor="actual_address">ფაქტიური მისამართი</Label>
                <Textarea
                  id="actual_address"
                  name="actual_address"
                  value={formData.actual_address}
                  onChange={handleInputChange}
                  placeholder="შეავსეთ თქვენი ფაქტიური მისამართი"
                  rows={3}
                />
                {errors.actual_address && (
                  <p className="text-sm text-destructive">{errors.actual_address}</p>
                )}
              </div>
            </div>

            {/* Education & Experience */}
            <div className="pt-6 border-t">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <GraduationCap className="h-5 w-5" />
                განათლება და გამოცდილება
              </h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="education_level">განათლების დონე</Label>
                  <select
                    id="education_level"
                    name="education_level"
                    value={formData.education_level}
                    onChange={(e) => setFormData(prev => ({ ...prev, education_level: e.target.value }))}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="">აირჩიეთ განათლების დონე</option>
                    <option value="საშუალო">საშუალო</option>
                    <option value="ბაკალავრი">ბაკალავრი</option>
                    <option value="მაგისტრი">მაგისტრი</option>
                    <option value="დოქტორი">დოქტორი</option>
                    <option value="პროფესიული">პროფესიული</option>
                  </select>
                  {errors.education_level && (
                    <p className="text-sm text-destructive">{errors.education_level}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="education">განათლება (დეტალურად)</Label>
                  <Textarea
                    id="education"
                    name="education"
                    value={formData.education}
                    onChange={handleInputChange}
                    placeholder="უნივერსიტეტი, ხარისხი, სპეციალობა"
                    rows={2}
                  />
                  {errors.education && (
                    <p className="text-sm text-destructive">{errors.education}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="previous_experience">სამუშაო გამოცდილება</Label>
                <Textarea
                  id="previous_experience"
                  name="previous_experience"
                  value={formData.previous_experience}
                  onChange={handleInputChange}
                  placeholder="შეავსეთ თქვენი სამუშაო გამოცდილების შესახებ ინფორმაცია"
                  rows={4}
                />
                {errors.previous_experience && (
                  <p className="text-sm text-destructive">{errors.previous_experience}</p>
                )}
              </div>
            </div>

            {/* Emergency Contact */}
            <div className="pt-6 border-t">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                ემერჯენსი კონტაქტი
              </h3>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="emergency_contact_name">სახელი და გვარი</Label>
                  <Input
                    id="emergency_contact_name"
                    name="emergency_contact_name"
                    value={formData.emergency_contact_name}
                    onChange={handleInputChange}
                    placeholder="ემერჯენსი კონტაქტის სახელი"
                  />
                  {errors.emergency_contact_name && (
                    <p className="text-sm text-destructive">{errors.emergency_contact_name}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="emergency_contact_phone">ტელეფონი</Label>
                  <Input
                    id="emergency_contact_phone"
                    name="emergency_contact_phone"
                    value={formData.emergency_contact_phone}
                    onChange={handleInputChange}
                    placeholder="ემერჯენსი კონტაქტის ტელეფონი"
                  />
                  {errors.emergency_contact_phone && (
                    <p className="text-sm text-destructive">{errors.emergency_contact_phone}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="emergency_contact_relation">ნათესაური კავშირი</Label>
                  <Input
                    id="emergency_contact_relation"
                    name="emergency_contact_relation"
                    value={formData.emergency_contact_relation}
                    onChange={handleInputChange}
                    placeholder="მაგ: მეუღლე, მშობელი, ძმა, და"
                  />
                  {errors.emergency_contact_relation && (
                    <p className="text-sm text-destructive">{errors.emergency_contact_relation}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Banking & Tax */}
            <div className="pt-6 border-t">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Building className="h-5 w-5" />
                საბანკო და საგადასახადო ინფორმაცია
              </h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="bank_name">ბანკის დასახელება</Label>
                  <Input
                    id="bank_name"
                    name="bank_name"
                    value={formData.bank_name}
                    onChange={handleInputChange}
                    placeholder="შეავსეთ თქვენი ბანკის დასახელება"
                  />
                  {errors.bank_name && (
                    <p className="text-sm text-destructive">{errors.bank_name}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bank_account_number">საბანკო ანგარიშის ნომერი</Label>
                  <Input
                    id="bank_account_number"
                    name="bank_account_number"
                    value={formData.bank_account_number}
                    onChange={handleInputChange}
                    placeholder="შეავსეთ თქვენი ანგარიშის ნომერი (IBAN)"
                  />
                  {errors.bank_account_number && (
                    <p className="text-sm text-destructive">{errors.bank_account_number}</p>
                  )}
                </div>
              </div>

              <div className="mt-4 space-y-2">
                <Label htmlFor="tax_benefits">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4" />
                    საშემოსავლო შეღავათი (საქართველოს კანონის მიხედვით)
                  </div>
                </Label>
                <Textarea
                  id="tax_benefits"
                  name="tax_benefits"
                  value={formData.tax_benefits}
                  onChange={handleInputChange}
                  placeholder="შეავსეთ თქვენი საშემოსავლო შეღავათის შესახებ ინფორმაცია (მაგ: შვილების რაოდენობა, შეზღუდული შესაძლებლობები და ა.შ.)"
                  rows={3}
                />
                <p className="text-xs text-muted-foreground">
                  გთხოვთ მიუთითოთ საქართველოს კანონმდებლობით გათვალისწინებული საშემოსავლო შეღავათები
                </p>
                {errors.tax_benefits && (
                  <p className="text-sm text-destructive">{errors.tax_benefits}</p>
                )}
              </div>
            </div>

            <div className="flex justify-end pt-4">
              <Button onClick={handleProfileUpdate} disabled={saving} className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-md hover:shadow-lg">
                <Save className="h-4 w-4 mr-2" />
                {saving ? 'ინახება...' : 'ცვლილებების შენახვა'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Password Change */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              პაროლის შეცვლა
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4">
              <div className="space-y-2">
                <Label htmlFor="currentPassword">მიმდინარე პაროლი *</Label>
                <Input
                  id="currentPassword"
                  name="currentPassword"
                  type="password"
                  value={passwordData.currentPassword}
                  onChange={handlePasswordChange}
                  placeholder="შეიყვანეთ მიმდინარე პაროლი"
                  maxLength={50}
                />
                {errors.currentPassword && (
                  <p className="text-sm text-destructive">{errors.currentPassword}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="newPassword">ახალი პაროლი *</Label>
                <Input
                  id="newPassword"
                  name="newPassword"
                  type="password"
                  value={passwordData.newPassword}
                  onChange={handlePasswordChange}
                  placeholder="შეიყვანეთ ახალი პაროლი (მინ. 6 სიმბოლო)"
                  maxLength={50}
                />
                {errors.newPassword && (
                  <p className="text-sm text-destructive">{errors.newPassword}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">პაროლის დადასტურება *</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  value={passwordData.confirmPassword}
                  onChange={handlePasswordChange}
                  placeholder="გაიმეორეთ ახალი პაროლი"
                  maxLength={50}
                />
                {errors.confirmPassword && (
                  <p className="text-sm text-destructive">{errors.confirmPassword}</p>
                )}
              </div>
            </div>

            <div className="flex justify-end pt-4">
              <Button onClick={handlePasswordUpdate} disabled={saving} className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-md hover:shadow-lg">
                <Lock className="h-4 w-4 mr-2" />
                {saving ? 'იცვლება...' : 'პაროლის შეცვლა'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {employee?.id && (
          <CareerTimeline employeeId={employee.id} userId={employee?.user_id} canEdit={false} />
        )}
      </div>
    </PageTransition>
  );
}
