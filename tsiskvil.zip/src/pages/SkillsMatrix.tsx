import { useState, useEffect, useCallback } from "react";
import {
  Grid3X3, Search, RefreshCw, AlertTriangle, CheckCircle2,
  Target, BookOpen, Plus, Save, Settings2,
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface Skill {
  id: string;
  name_ka: string;
  name_en: string;
  category: string;
  target_level: number;
}

interface EmployeeSkillRow {
  id: string;
  employee_id: string;
  skill_id: string;
  level: number;
}

interface EmployeeRow {
  id: string;
  full_name: string;
  department: string;
  position: string;
}

const LEVEL_COLORS: Record<number, string> = {
  1: "bg-destructive/15 text-destructive border-destructive/30",
  2: "bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30",
  3: "bg-primary/10 text-primary border-primary/30",
  4: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
  5: "bg-emerald-500/25 text-emerald-700 dark:text-emerald-300 border-emerald-500/40",
};

export default function SkillsMatrix() {
  const { language } = useLanguage();
  const { toast } = useToast();
  const tr = (ka: string, en: string) => (language === "en" ? en : ka);

  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDept, setSelectedDept] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [skills, setSkills] = useState<Skill[]>([]);
  const [employees, setEmployees] = useState<EmployeeRow[]>([]);
  const [skillRows, setSkillRows] = useState<EmployeeSkillRow[]>([]);
  const [departments, setDepartments] = useState<string[]>([]);
  const [isHr, setIsHr] = useState(false);
  const [myEmployeeId, setMyEmployeeId] = useState<string | null>(null);

  // Editor state
  const [editOpen, setEditOpen] = useState(false);
  const [editEmployee, setEditEmployee] = useState<EmployeeRow | null>(null);
  const [editLevels, setEditLevels] = useState<Record<string, number>>({});
  const [saving, setSaving] = useState(false);

  // Catalog state
  const [catalogOpen, setCatalogOpen] = useState(false);
  const [newSkillName, setNewSkillName] = useState("");
  const [newSkillNameEn, setNewSkillNameEn] = useState("");
  const [newSkillCategory, setNewSkillCategory] = useState("ტექნიკური");
  const [newSkillTarget, setNewSkillTarget] = useState("3");

  const skillName = (s: Skill) => (language === "en" ? s.name_en || s.name_ka : s.name_ka || s.name_en);
  const skillIdOf = useCallback(() => new Map(skills.map((s) => [s.id, s])), [skills]);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const [{ data: skillsData }, { data: empData }, { data: roles }] = await Promise.all([
        supabase.from("skills").select("*").order("category").order("name_ka"),
        supabase.from("employees").select("id, full_name, department, position").eq("status", "active").order("full_name"),
        user?.id ? supabase.from("user_roles").select("role").eq("user_id", user.id) : Promise.resolve({ data: null } as any),
      ]);

      const hr = !!roles?.some((r: any) => r.role === "admin" || r.role === "hr_manager");
      setIsHr(hr);

      let visibleEmployees: EmployeeRow[] = (empData || []) as EmployeeRow[];
      let empId: string | null = null;
      if (!hr) {
        const { data: me } = await supabase
          .from("employees")
          .select("id, full_name, department, position")
          .eq("user_id", user?.id)
          .limit(1);
        if (me && me.length > 0) {
          empId = me[0].id;
          visibleEmployees = me as EmployeeRow[];
        } else {
          visibleEmployees = [];
        }
      }
      setMyEmployeeId(empId);

      const skillMap = new Map((skillsData || []).map((s: any) => [s.id, s]));

      const { data: esData, error: esError } = await supabase
        .from("employee_skills")
        .select("employee_id, skill_id, level")
        .in("employee_id", visibleEmployees.length > 0 ? visibleEmployees.map((e) => e.id) : ["00000000-0000-0000-0000-000000000000"]);

      setSkills((skillsData || []) as Skill[]);
      setEmployees(visibleEmployees);
      setSkillRows(esError ? [] : (esData || []) as EmployeeSkillRow[]);

      const deptNames = Array.from(new Set(visibleEmployees.map((e) => e.department).filter(Boolean)));
      setDepartments(deptNames as string[]);
      void skillMap;
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const filteredEmployees = employees.filter((e) => {
    const matchesSearch = !searchTerm || e.full_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = selectedDept === "all" || e.department === selectedDept;
    return matchesSearch && matchesDept;
  });

  const visibleSkills = skills.filter((s) => selectedCategory === "all" || s.category === selectedCategory);
  const categories = Array.from(new Set(skills.map((s) => s.category)));

  const levelOf = (empId: string, skillId: string): number | null => {
    const row = skillRows.find((r) => r.employee_id === empId && r.skill_id === skillId);
    return row ? row.level : null;
  };

  // Gap analysis: per skill, average actual vs target
  const gapAnalysis = visibleSkills
    .map((s) => {
      const levels = employees
        .map((e) => levelOf(e.id, s.id))
        .filter((l): l is number => l !== null);
      const avg = levels.length > 0 ? levels.reduce((a, b) => a + b, 0) / levels.length : 0;
      return { skill: s, avg, gap: Math.max(0, s.target_level - avg), covered: levels.length };
    })
    .sort((a, b) => b.gap - a.gap);

  const openEdit = (emp: EmployeeRow) => {
    setEditEmployee(emp);
    const levels: Record<string, number> = {};
    skills.forEach((s) => {
      levels[s.id] = levelOf(emp.id, s.id) ?? 0;
    });
    setEditLevels(levels);
    setEditOpen(true);
  };

  const saveEdit = async () => {
    if (!editEmployee) return;
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    const upserts = Object.entries(editLevels)
      .filter(([, level]) => level > 0)
      .map(([skill_id, level]) => ({
        employee_id: editEmployee.id,
        skill_id,
        level,
        updated_by: user?.id || null,
      }));
    const skillIdsToKeep = new Set(upserts.map((u) => u.skill_id));
    const deletes = skillRows
      .filter((r) => r.employee_id === editEmployee.id && !skillIdsToKeep.has(r.skill_id))
      .map((r) => r.id);

    try {
      if (upserts.length > 0) {
        const { error } = await supabase
          .from("employee_skills")
          .upsert(upserts, { onConflict: "employee_id,skill_id" });
        if (error) throw error;
      }
      if (deletes.length > 0) {
        const { error } = await supabase.from("employee_skills").delete().in("id", deletes);
        if (error) throw error;
      }
      toast({ title: tr("უნარები შენახულია", "Skills saved") });
      setEditOpen(false);
      await fetchData();
    } catch (error: any) {
      toast({ title: tr("შენახვის შეცდომა", "Save error"), description: error?.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const addSkillToCatalog = async () => {
    if (!newSkillName.trim()) return;
    const { error } = await supabase.from("skills").insert({
      name_ka: newSkillName.trim(),
      name_en: newSkillNameEn.trim() || newSkillName.trim(),
      category: newSkillCategory,
      target_level: parseInt(newSkillTarget, 10) || 3,
    } as any);
    if (error) {
      toast({ title: tr("დამატება ვერ მოხერხდა", "Could not add"), variant: "destructive" });
    } else {
      toast({ title: tr("უნარი დაემატა", "Skill added") });
      setNewSkillName("");
      setNewSkillNameEn("");
      setCatalogOpen(false);
      await fetchData();
    }
  };

  const avgFor = (empId: string) => {
    const levels = visibleSkills.map((s) => levelOf(empId, s.id)).filter((l): l is number => l !== null);
    if (levels.length === 0) return null;
    return levels.reduce((a, b) => a + b, 0) / levels.length;
  };

  const gapsFor = (empId: string) =>
    visibleSkills.filter((s) => {
      const l = levelOf(empId, s.id);
      return l !== null && l < s.target_level;
    }).length;

  const skillsWithLevel = (empId: string) =>
    skillRows.filter((r) => r.employee_id === empId).length;

  const catalogAction = isHr && (
    <Button size="sm" variant="outline" onClick={() => setCatalogOpen(true)}>
      <Settings2 className="h-4 w-4 mr-1" />
      {tr("კატალოგი", "Catalog")}
    </Button>
  );

  return (
    <PageTransition>
      <div className="space-y-6">
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-2">
              <Target className="h-7 w-7 text-primary" />
              {tr("უნარების მატრიცა", "Skills Matrix")}
            </h1>
            <p className="text-muted-foreground mt-1 text-sm">
              {tr(
                "ვინ რას ფლობს და სად არის ხარვეზები - კარიერული განვითარების საფუძველი",
                "Who knows what and where the gaps are - the basis for career development"
              )}
            </p>
          </div>
          {catalogAction}
        </div>

        <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={tr("ძებნა…", "Search…")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={selectedDept} onValueChange={setSelectedDept}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder={tr("დეპარტამენტი", "Department")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{tr("ყველა დეპარტამენტი", "All departments")}</SelectItem>
              {departments.map((d) => (
                <SelectItem key={d} value={d}>{d}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder={tr("კატეგორია", "Category")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{tr("ყველა კატეგორია", "All categories")}</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" onClick={() => fetchData()} className="shrink-0">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>

        <Tabs defaultValue="matrix">
          <TabsList className="flex-wrap h-auto">
            <TabsTrigger value="matrix" className="gap-1.5">
              <Grid3X3 className="h-4 w-4" />
              {tr("მატრიცა", "Matrix")}
            </TabsTrigger>
            <TabsTrigger value="gaps" className="gap-1.5">
              <AlertTriangle className="h-4 w-4" />
              {tr("ხარვეზები", "Gaps")}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="matrix">
            <Card>
              <CardContent className="p-0">
                {loading ? (
                  <div className="p-4 space-y-2">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Skeleton key={i} className="h-10 w-full" />
                    ))}
                  </div>
                ) : filteredEmployees.length === 0 ? (
                  <div className="p-8 text-center text-muted-foreground">
                    <BookOpen className="h-10 w-10 mx-auto mb-3 opacity-30" />
                    {isHr
                      ? tr("თანამშრომლები ვერ მოიძებნა", "No employees found")
                      : tr("უნარების პროფილი ჯერ არ არის შევსებული - HR შეავსებს", "Your skills profile is not filled in yet - HR will add it")}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm min-w-max">
                      <thead>
                        <tr className="border-b bg-muted/40">
                          <th className="text-left p-3 font-medium sticky left-0 bg-muted/40 z-10 min-w-[180px]">
                            {tr("თანამშრომელი", "Employee")}
                          </th>
                          {visibleSkills.map((s) => (
                            <th key={s.id} className="p-3 font-medium text-center whitespace-nowrap">
                              {skillName(s)}
                              <span className="block text-[10px] text-muted-foreground font-normal">
                                {tr("სამიზნე", "Target")}: {s.target_level}
                              </span>
                            </th>
                          ))}
                          <th className="p-3 font-medium text-center whitespace-nowrap">
                            {tr("საშ. დონე", "Avg")}
                          </th>
                          {isHr && <th className="p-3 font-medium text-center whitespace-nowrap">{tr("მოქმედება", "Action")}</th>}
                        </tr>
                      </thead>
                      <tbody>
                        {filteredEmployees.map((emp) => {
                          const avg = avgFor(emp.id);
                          const gaps = gapsFor(emp.id);
                          const filled = skillsWithLevel(emp.id);
                          return (
                            <tr key={emp.id} className="border-b last:border-0 hover:bg-muted/30">
                              <td className="p-3 sticky left-0 bg-card z-10 min-w-[180px]">
                                <div className="font-medium">{emp.full_name}</div>
                                <div className="text-xs text-muted-foreground">
                                  {emp.position || emp.department || "-"}
                                  {filled > 0 && (
                                    <span className="ml-1 text-[10px]">({filled}/{visibleSkills.length})</span>
                                  )}
                                </div>
                              </td>
                              {visibleSkills.map((s) => {
                                const lvl = levelOf(emp.id, s.id);
                                const isGap = lvl !== null && lvl < s.target_level;
                                return (
                                  <td key={s.id} className="p-2 text-center">
                                    {lvl === null ? (
                                      <span className="text-muted-foreground/50">–</span>
                                    ) : (
                                      <span
                                        className={cn(
                                          "inline-flex items-center justify-center h-7 w-7 rounded-full border text-xs font-semibold tabular-nums",
                                          LEVEL_COLORS[lvl],
                                          isGap && "ring-2 ring-amber-500/40"
                                        )}
                                        title={`${skillName(s)}: ${lvl}/5`}
                                      >
                                        {lvl}
                                      </span>
                                    )}
                                  </td>
                                );
                              })}
                              <td className="p-3 text-center font-semibold tabular-nums">
                                {avg === null ? "–" : avg.toFixed(1)}
                              </td>
                              {isHr && (
                                <td className="p-2 text-center">
                                  <Button size="sm" variant="ghost" onClick={() => openEdit(emp)}>
                                    <Plus className="h-4 w-4" />
                                  </Button>
                                </td>
                              )}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="gaps">
            <div className="grid gap-3 md:grid-cols-2">
              {gapAnalysis.filter((g) => g.gap > 0).length === 0 && !loading && (
                <Card className="md:col-span-2">
                  <CardContent className="p-8 text-center text-muted-foreground">
                    <CheckCircle2 className="h-10 w-10 mx-auto mb-3 text-emerald-500" />
                    {tr("ხარვეზები არ არის - ყველა უნარი სამიზნე დონეზეა", "No gaps - all skills meet target levels")}
                  </CardContent>
                </Card>
              )}
              {gapAnalysis.filter((g) => g.gap > 0).map(({ skill, avg, gap, covered }) => (
                <Card key={skill.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-medium">{skillName(skill)}</div>
                        <div className="text-xs text-muted-foreground">{skill.category}</div>
                      </div>
                      <Badge variant={gap >= 2 ? "destructive" : "outline"} className="shrink-0">
                        {tr("ხარვეზი", "Gap")}: {gap.toFixed(1)}
                      </Badge>
                    </div>
                    <div className="mt-3 space-y-1.5">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{tr("საშუალო დონე", "Average level")}</span>
                        <span className="tabular-nums">{covered > 0 ? avg.toFixed(1) : tr("მონაცემი არ არის", "No data")} / {skill.target_level}</span>
                      </div>
                      <div className="h-2 rounded-full bg-muted overflow-hidden">
                        <div
                          className={cn("h-full rounded-full", gap >= 2 ? "bg-destructive" : "bg-amber-500")}
                          style={{ width: `${Math.min(100, (avg / 5) * 100)}%` }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {tr("უნარები", "Skills")}: {editEmployee?.full_name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {categories.map((cat) => (
              <div key={cat}>
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">{cat}</div>
                <div className="space-y-2">
                  {skills.filter((s) => s.category === cat).map((s) => (
                    <div key={s.id} className="flex items-center justify-between gap-2">
                      <span className="text-sm min-w-0 truncate">
                        {skillName(s)}
                        <span className="text-xs text-muted-foreground ml-1">({tr("სამიზნე", "target")} {s.target_level})</span>
                      </span>
                      <Select
                        value={String(editLevels[s.id] ?? 0)}
                        onValueChange={(v) => setEditLevels((prev) => ({ ...prev, [s.id]: parseInt(v, 10) }))}
                      >
                        <SelectTrigger className="w-[130px] h-8 shrink-0">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">{tr("არ ფლობს", "Not assessed")}</SelectItem>
                          <SelectItem value="1">1 - {tr("საწყისი", "Beginner")}</SelectItem>
                          <SelectItem value="2">2 - {tr("საბაზისო", "Basic")}</SelectItem>
                          <SelectItem value="3">3 - {tr("საშუალო", "Intermediate")}</SelectItem>
                          <SelectItem value="4">4 - {tr("კარგი", "Good")}</SelectItem>
                          <SelectItem value="5">5 - {tr("ექსპერტი", "Expert")}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button onClick={saveEdit} disabled={saving}>
              <Save className="h-4 w-4 mr-1" />
              {saving ? tr("ინახება…", "Saving…") : tr("შენახვა", "Save")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Catalog dialog */}
      <Dialog open={catalogOpen} onOpenChange={setCatalogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{tr("ახალი უნარი", "New skill")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input value={newSkillName} onChange={(e) => setNewSkillName(e.target.value)} placeholder={tr("სახელი (ქართ.)", "Name (Georgian)")} />
            <Input value={newSkillNameEn} onChange={(e) => setNewSkillNameEn(e.target.value)} placeholder={tr("სახელი (ინგ.)", "Name (English)")} />
            <div className="grid grid-cols-2 gap-3">
              <Select value={newSkillCategory} onValueChange={setNewSkillCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={newSkillTarget} onValueChange={setNewSkillTarget}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <SelectItem key={n} value={String(n)}>{n}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={addSkillToCatalog}>{tr("დამატება", "Add")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageTransition>
  );
}
