import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Plane, CheckCircle, XCircle, Smartphone, MapPin, Calendar, Banknote, Hotel, Train, Clock, User } from "lucide-react";
import { formatters } from "@/lib/dateUtils";
import { useAuth } from "@/contexts/AuthContext";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import EsimOfferSection from "@/components/business-trips/EsimOfferSection";
import EsimRequestsTab from "@/components/business-trips/EsimRequestsTab";
import GlobalCellManager from "@/components/business-trips/GlobalCellManager";

interface BusinessTripRequest {
  id: string;
  employee_id: string;
  manager_id: string | null;
  destination: string;
  purpose: string;
  start_date: string;
  end_date: string;
  status: string;
  accommodation_needed: boolean | null;
  transportation_type: string | null;
  estimated_budget: number | null;
  rejection_reason: string | null;
  esim_needed: boolean | null;
  created_at: string;
  employees: {
    full_name: string;
    position: string | null;
  };
}

const transportLabels: Record<string, string> = {
  plane: "✈️ თვითმფრინავი",
  train: "🚂 მატარებელი",
  car: "🚗 ავტომობილი",
  bus: "🚌 ავტობუსი",
};

const BusinessTripRequests = () => {
  const { user, userRole } = useAuth();
  const [requests, setRequests] = useState<BusinessTripRequest[]>([]);
  const [managers, setManagers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState<any>(null);
  const [esimRequests, setEsimRequests] = useState<Record<string, any>>({});
  const [tripBookings, setTripBookings] = useState<Record<string, any[]>>({});
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const navigate = useNavigate();

  const isAdminOrHr = userRole === "admin" || userRole === "hr_manager";
  const activeBranchId = useBranchFilter();

  const canManageRequest = (request: BusinessTripRequest) => {
    if (isAdminOrHr) return true;
    if (currentEmployee && request.manager_id === currentEmployee.id) return true;
    return false;
  };

  const fetchTripBookings = async () => {
    const { data } = await supabase
      .from("travel_bookings")
      .select("id, trip_id, total_amount, per_diem_total, status");
    const map: Record<string, any[]> = {};
    (data || []).forEach((b: any) => {
      if (!b.trip_id) return;
      if (!map[b.trip_id]) map[b.trip_id] = [];
      map[b.trip_id].push(b);
    });
    setTripBookings(map);
  };

  useEffect(() => {
    fetchRequests();
    fetchManagers();
    fetchCurrentEmployee();
    fetchEsimRequests();
    fetchTripBookings();
  }, [user, activeBranchId]);


  const fetchManagers = async () => {
    try {
      let q = supabase
        .from("employees")
        .select("id, full_name, position")
        .eq("status", "active")
        .order("full_name");
      if (activeBranchId) q = q.eq("branch_id", activeBranchId);
      const { data, error } = await q;
      if (error) throw error;
      setManagers(data || []);
    } catch {
      toast.error("მენეჯერების ჩატვირთვა ვერ მოხერხდა");
    }
  };

  const fetchCurrentEmployee = async () => {
    if (!user) return;
    try {
      const { data: empData, error: empError } = await supabase
        .from('employees')
        .select('*')
        .eq('email', user.email)
        .maybeSingle();
      if (empError) throw empError;
      if (empData?.department) {
        const { data: deptData } = await supabase
          .from('departments')
          .select('manager_id')
          .eq('name', empData.department)
          .maybeSingle();
        setCurrentEmployee({ ...empData, direct_manager_id: deptData?.manager_id });
      } else {
        setCurrentEmployee(empData);
      }
    } catch (error) {
      console.error('Error fetching current employee:', error);
    }
  };

  const fetchRequests = async () => {
    try {
      let q = supabase
        .from("business_trip_requests")
        .select(`
          *,
          employees!business_trip_requests_employee_id_fkey (full_name, position)
        `)
        .order("created_at", { ascending: false });
      if (activeBranchId) q = q.eq("branch_id", activeBranchId);
      const { data, error } = await q;
      if (error) throw error;
      setRequests(data || []);
    } catch {
      toast.error("მონაცემების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const fetchEsimRequests = async () => {
    if (!user) return;
    try {
      const { data } = await supabase
        .from("esim_requests")
        .select("*, esim_plans(region, data_gb, validity_days, price)")
        .order("created_at", { ascending: false });
      if (data) {
        const map: Record<string, any> = {};
        data.forEach((r: any) => {
          if (!map[r.trip_id]) map[r.trip_id] = r;
        });
        setEsimRequests(map);
      }
    } catch {
      // silent
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const { data: currentEmp, error: empError } = await supabase
        .from("employees")
        .select("id")
        .eq("email", user?.email)
        .maybeSingle();
      if (empError) throw empError;
      if (!currentEmp?.id) {
        toast.error("თანამშრომლის პროფილი ვერ მოიძებნა");
        return;
      }

      const { error } = await supabase.from("business_trip_requests").insert([
        {
          employee_id: currentEmp.id,
          user_id: user?.id,
          manager_id: (formData.get("manager_id") as string) || null,
          destination: formData.get("destination") as string,
          purpose: formData.get("purpose") as string,
          start_date: formData.get("start_date") as string,
          end_date: formData.get("end_date") as string,
          accommodation_needed: formData.get("accommodation_needed") === "on",
          transportation_type: (formData.get("transportation_type") as string) || null,
          estimated_budget: parseFloat(formData.get("estimated_budget") as string) || null,
          esim_needed: formData.get("esim_needed") === "on",
          status: "pending",
        },
      ]);
      if (error) throw error;
      toast.success("მივლინების განაცხადი წარმატებით გაიგზავნა");
      setIsDialogOpen(false);
      fetchRequests();
    } catch {
      toast.error("განაცხადის გაგზავნა ვერ მოხერხდა");
    } finally {
      setIsLoading(false);
    }
  };

  const handleStatusUpdate = async (id: string, status: string, rejectionReason?: string) => {
    try {
      const updateData: any = { status };
      if (status === "rejected" && rejectionReason) {
        updateData.rejection_reason = rejectionReason;
      }
      const { error } = await supabase
        .from("business_trip_requests")
        .update(updateData)
        .eq("id", id);
      if (error) throw error;
      toast.success(`სტატუსი განახლდა: ${status === "approved" ? "დამტკიცებული" : "უარყოფილი"}`);
      fetchRequests();
    } catch {
      toast.error("სტატუსის განახლება ვერ მოხერხდა");
    }
  };

  const getStatusConfig = (status: string) => {
    const map: Record<string, { variant: any; label: string; dotColor: string }> = {
      pending: { variant: "secondary" as const, label: "მოლოდინში", dotColor: "bg-amber-500" },
      approved: { variant: "default" as const, label: "დამტკიცებული", dotColor: "bg-emerald-500" },
      rejected: { variant: "destructive" as const, label: "უარყოფილი", dotColor: "bg-destructive" },
    };
    return map[status] || map.pending;
  };

  // Stats
  const stats = {
    total: requests.length,
    pending: requests.filter(r => r.status === "pending").length,
    approved: requests.filter(r => r.status === "approved").length,
    rejected: requests.filter(r => r.status === "rejected").length,
  };

  const filteredRequests = statusFilter === "all" 
    ? requests 
    : requests.filter(r => r.status === statusFilter);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Plane className="h-6 w-6 text-primary" />
            სამსახურებრივი მივლინებები
          </h1>
          <p className="text-sm text-muted-foreground mt-1">მივლინების განაცხადების მართვა და თვალყურის დევნება</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 shadow-sm">
              <Plus className="h-4 w-4" />
              ახალი განაცხადი
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Plane className="h-5 w-5 text-primary" />
                სამსახურებრივი მივლინების განაცხადი
              </DialogTitle>
              <DialogDescription>შეავსეთ მივლინების დეტალები</DialogDescription>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="destination" className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    <MapPin className="h-3.5 w-3.5" /> დანიშნულების ადგილი *
                  </Label>
                  <Input id="destination" name="destination" required placeholder="ქალაქი, ქვეყანა" className="h-10" />
                </div>
                <div className="space-y-2">
                  <Label className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    <User className="h-3.5 w-3.5" /> უშუალო უფროსი
                  </Label>
                  {currentEmployee?.direct_manager_id ? (
                    <>
                      <Input
                        value={managers.find(m => m.id === currentEmployee.direct_manager_id)?.full_name || 'არ არის მინიჭებული'}
                        disabled
                        className="bg-muted h-10"
                      />
                      <input type="hidden" name="manager_id" value={currentEmployee.direct_manager_id} />
                    </>
                  ) : (
                    <Input value="არ არის მინიჭებული" disabled className="bg-muted text-muted-foreground h-10" />
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="purpose" className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  მიზანი *
                </Label>
                <Textarea id="purpose" name="purpose" required placeholder="აღწერეთ მივლინების მიზანი" rows={2} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="start_date" className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    <Calendar className="h-3.5 w-3.5" /> დაწყება *
                  </Label>
                  <Input id="start_date" name="start_date" type="date" required className="h-10" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="end_date" className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    <Calendar className="h-3.5 w-3.5" /> დასრულება *
                  </Label>
                  <Input id="end_date" name="end_date" type="date" required className="h-10" />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    <Train className="h-3.5 w-3.5" /> ტრანსპორტი
                  </Label>
                  <Select name="transportation_type">
                    <SelectTrigger className="h-10">
                      <SelectValue placeholder="აირჩიეთ" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="plane">✈️ თვითმფრინავი</SelectItem>
                      <SelectItem value="train">🚂 მატარებელი</SelectItem>
                      <SelectItem value="car">🚗 ავტომობილი</SelectItem>
                      <SelectItem value="bus">🚌 ავტობუსი</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="estimated_budget" className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    <Banknote className="h-3.5 w-3.5" /> ბიუჯეტი (₾)
                  </Label>
                  <Input id="estimated_budget" name="estimated_budget" type="number" step="0.01" placeholder="0.00" className="h-10" />
                </div>
              </div>

              <div className="flex flex-col gap-3 p-3 rounded-lg bg-muted/50 border">
                <div className="flex items-center space-x-2">
                  <Checkbox id="accommodation_needed" name="accommodation_needed" />
                  <Label htmlFor="accommodation_needed" className="cursor-pointer flex items-center gap-1.5 text-sm">
                    <Hotel className="h-4 w-4 text-muted-foreground" />
                    საჭიროა განთავსება
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="esim_needed" name="esim_needed" />
                  <Label htmlFor="esim_needed" className="cursor-pointer flex items-center gap-1.5 text-sm">
                    <Smartphone className="h-4 w-4 text-primary" />
                    მჭირდება eSIM (Global Cell)
                  </Label>
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>გაუქმება</Button>
                <Button type="submit" disabled={isLoading} className="gap-2">
                  {isLoading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary-foreground" />
                      იგზავნება...
                    </>
                  ) : (
                    <>
                      <Plane className="h-4 w-4" />
                      განაცხადის გაგზავნა
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "სულ", value: stats.total, color: "text-foreground", bg: "bg-muted/50", filter: "all" },
          { label: "მოლოდინში", value: stats.pending, color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-50 dark:bg-amber-950/30", filter: "pending" },
          { label: "დამტკიცებული", value: stats.approved, color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-50 dark:bg-emerald-950/30", filter: "approved" },
          { label: "უარყოფილი", value: stats.rejected, color: "text-destructive", bg: "bg-destructive/5", filter: "rejected" },
        ].map((stat) => (
          <button
            key={stat.filter}
            onClick={() => setStatusFilter(stat.filter)}
            className={`p-4 rounded-xl border text-left transition-all hover:shadow-md ${stat.bg} ${
              statusFilter === stat.filter ? "ring-2 ring-primary shadow-md" : ""
            }`}
          >
            <p className="text-2xl font-bold tabular-nums ${stat.color}">{stat.value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
          </button>
        ))}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="trips">
        <TabsList className="bg-muted/60 backdrop-blur-sm">
          <TabsTrigger value="trips" className="gap-1.5 data-[state=active]:bg-background">
            <Plane className="h-4 w-4" />
            მივლინებები
          </TabsTrigger>
          {isAdminOrHr && (
            <TabsTrigger value="esim" className="gap-1.5 data-[state=active]:bg-background">
              <Smartphone className="h-4 w-4" />
              eSIM მოთხოვნები
            </TabsTrigger>
          )}
          {isAdminOrHr && (
            <TabsTrigger value="globalcell" className="gap-1.5 data-[state=active]:bg-background">
              <Smartphone className="h-4 w-4" />
              Global Cell
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="trips" className="mt-4">
          <div className="space-y-3">
            {filteredRequests.map((request) => {
              const statusCfg = getStatusConfig(request.status);
              return (
                <Card key={request.id} className="overflow-hidden border transition-all hover:shadow-md group">
                  {/* Status strip */}
                  <div className={`h-1 ${statusCfg.dotColor}`} />
                  
                  <CardContent className="p-5">
                    {/* Top row: destination + employee + status */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-start gap-3">
                        <div className="p-2.5 rounded-xl bg-primary/10 text-primary shrink-0">
                          <Plane className="h-5 w-5" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-base text-foreground">{request.destination}</h3>
                          <p className="text-sm text-muted-foreground flex items-center gap-1 mt-0.5">
                            <User className="h-3.5 w-3.5" />
                            {request.employees?.full_name}
                            {request.employees?.position && (
                              <span className="text-muted-foreground/60"> · {request.employees.position}</span>
                            )}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {request.esim_needed && (
                          <Badge variant="outline" className="gap-1 text-xs border-primary/30 text-primary">
                            <Smartphone className="h-3 w-3" /> eSIM
                          </Badge>
                        )}
                        <Badge variant={statusCfg.variant} className="gap-1.5">
                          <span className={`h-2 w-2 rounded-full ${statusCfg.dotColor} inline-block`} />
                          {statusCfg.label}
                        </Badge>
                      </div>
                    </div>

                    {/* Purpose */}
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{request.purpose}</p>

                    {/* Info grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 rounded-lg bg-muted/30 border border-border/50">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground shrink-0" />
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">პერიოდი</p>
                          <p className="text-xs font-medium text-foreground">
                            {formatters.shortDate(request.start_date)} - {formatters.shortDate(request.end_date)}
                          </p>
                        </div>
                      </div>

                      {request.transportation_type && (
                        <div className="flex items-center gap-2">
                          <Train className="h-4 w-4 text-muted-foreground shrink-0" />
                          <div>
                            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">ტრანსპორტი</p>
                            <p className="text-xs font-medium text-foreground">
                              {transportLabels[request.transportation_type] || request.transportation_type}
                            </p>
                          </div>
                        </div>
                      )}

                      {request.estimated_budget != null && (
                        <div className="flex items-center gap-2">
                          <Banknote className="h-4 w-4 text-muted-foreground shrink-0" />
                          <div>
                            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">ბიუჯეტი</p>
                            <p className="text-xs font-medium text-foreground">{request.estimated_budget.toFixed(2)} ₾</p>
                          </div>
                        </div>
                      )}

                      <div className="flex items-center gap-2">
                        <Hotel className="h-4 w-4 text-muted-foreground shrink-0" />
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">განთავსება</p>
                          <p className="text-xs font-medium text-foreground">
                            {request.accommodation_needed ? "საჭიროა" : "არ არის საჭირო"}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Rejection reason */}
                    {request.rejection_reason && (
                      <div className="mt-3 p-3 rounded-lg bg-destructive/5 border border-destructive/20">
                        <p className="text-xs font-semibold text-destructive mb-0.5">უარყოფის მიზეზი:</p>
                        <p className="text-xs text-destructive/80">{request.rejection_reason}</p>
                      </div>
                    )}

                    {/* eSIM offer */}
                    {request.status === "approved" && request.employee_id && currentEmployee && user && (
                      <EsimOfferSection
                        tripId={request.id}
                        employeeId={request.employee_id}
                        userId={user.id}
                        destination={request.destination}
                        existingRequest={esimRequests[request.id]}
                        onRequestUpdated={fetchEsimRequests}
                      />
                    )}

                    {/* Hotel booking */}
                    {request.status === "approved" && (
                      <div className="mt-3 p-3 rounded-lg bg-muted/40 border border-border/60 flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <Hotel className="h-4 w-4 text-muted-foreground shrink-0" />
                          <p className="text-xs text-muted-foreground truncate">
                            {(tripBookings[request.id]?.length || 0) > 0
                              ? `ჯავშნები: ${tripBookings[request.id].length} · ${tripBookings[request.id]
                                  .reduce((s: number, b: any) => s + Number(b.total_amount || 0) + Number(b.per_diem_total || 0), 0)
                                  .toFixed(2)} ₾`
                              : "ჯავშანი ჯერ არ არის დარეგისტრირებული"}
                          </p>
                        </div>
                        <Button size="sm" variant="outline" onClick={() => navigate("/travel-desk")}>
                          მოგზაურობის ცენტრი
                        </Button>
                      </div>
                    )}


                    {/* Admin actions */}
                    {canManageRequest(request) && request.status === "pending" && (
                      <div className="flex gap-2 pt-3 mt-3 border-t">
                        <Button
                          size="sm"
                          variant="default"
                          className="gap-1.5 flex-1 sm:flex-none"
                          onClick={() => handleStatusUpdate(request.id, "approved")}
                        >
                          <CheckCircle className="h-4 w-4" />
                          დამტკიცება
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          className="gap-1.5 flex-1 sm:flex-none"
                          onClick={() => {
                            const reason = prompt("უარყოფის მიზეზი:");
                            if (reason) handleStatusUpdate(request.id, "rejected", reason);
                          }}
                        >
                          <XCircle className="h-4 w-4" />
                          უარყოფა
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}

            {filteredRequests.length === 0 && (
              <Card className="border-dashed">
                <CardContent className="flex flex-col items-center justify-center py-16">
                  <div className="p-4 rounded-full bg-muted mb-4">
                    <Plane className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <p className="text-muted-foreground font-medium">მივლინების განაცხადები არ მოიძებნა</p>
                  <p className="text-xs text-muted-foreground mt-1">დააჭირეთ "ახალი განაცხადი" ღილაკს ახლის შესაქმნელად</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {isAdminOrHr && (
          <TabsContent value="esim" className="mt-4">
            <EsimRequestsTab />
          </TabsContent>
        )}

        {isAdminOrHr && (
          <TabsContent value="globalcell" className="mt-4">
            <GlobalCellManager />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default BusinessTripRequests;
