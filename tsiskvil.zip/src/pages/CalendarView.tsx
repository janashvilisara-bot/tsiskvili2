import { useState, useEffect } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { formatters } from "@/lib/dateUtils";
import { isSameDay, startOfMonth, endOfMonth } from "date-fns";
import { CalendarIcon, Clock, CheckCircle2, AlertCircle, Plus, Users, Download } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { generateIcsCalendar, downloadIcsFile, type IcsEvent } from "@/lib/icsExport";

interface CalendarEvent {
  id: string;
  title: string;
  date: Date;
  type: "leave" | "task" | "deadline" | "meeting" | "holiday" | "other";
  status?: string;
  description?: string;
}

export default function CalendarView() {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newEvent, setNewEvent] = useState({
    title: "",
    description: "",
    event_date: formatters.isoDate(new Date()),
    event_type: "meeting" as "meeting" | "holiday" | "other",
  });

  useEffect(() => {
    if (user) {
      fetchEvents();
    }
  }, [user, currentMonth]);

  const fetchEvents = async () => {
    try {
      setLoading(true);
      const monthStart = startOfMonth(currentMonth);
      const monthEnd = endOfMonth(currentMonth);

      // Fetch leave requests
      const { data: leaves, error: leavesError } = await supabase
        .from("leave_requests")
        .select("id, start_date, end_date, leave_type, status, employee_id, employees!leave_requests_employee_id_fkey(full_name)")
        .gte("end_date", monthStart.toISOString())
        .lte("start_date", monthEnd.toISOString());

      if (leavesError) throw leavesError;

      // Fetch tasks with deadlines
      const { data: tasks, error: tasksError } = await supabase
        .from("tasks")
        .select("id, title, due_date, status, priority, assigned_to, employees!tasks_assigned_to_fkey(full_name)")
        .gte("due_date", monthStart.toISOString())
        .lte("due_date", monthEnd.toISOString())
        .not("due_date", "is", null);

      if (tasksError) throw tasksError;

      // Fetch custom events
      const { data: customEvents, error: eventsError } = await supabase
        .from("events")
        .select("*")
        .gte("event_date", monthStart.toISOString())
        .lte("event_date", monthEnd.toISOString());

      if (eventsError) throw eventsError;

      // Process leave requests into events
      const leaveEvents: CalendarEvent[] = [];
      leaves?.forEach((leave: any) => {
        const start = new Date(leave.start_date);
        const end = new Date(leave.end_date);
        const current = new Date(start);

        while (current <= end) {
          leaveEvents.push({
            id: `leave-${leave.id}-${current.toISOString()}`,
            title: `შვებულება - ${leave.employees?.full_name || 'თანამშრომელი'}`,
            date: new Date(current),
            type: "leave",
            status: leave.status,
            description: leave.leave_type,
          });
          current.setDate(current.getDate() + 1);
        }
      });

      // Process tasks into events
      const taskEvents: CalendarEvent[] = tasks?.map((task: any) => ({
        id: `task-${task.id}`,
        title: task.title,
        date: new Date(task.due_date),
        type: task.status === "completed" ? "task" : "deadline",
        status: task.status,
        description: `პრიორიტეტი: ${task.priority || 'საშუალო'}`,
      })) || [];

      // Process custom events
      const customEventsFormatted: CalendarEvent[] = customEvents?.map((event: any) => ({
        id: `event-${event.id}`,
        title: event.title,
        date: new Date(event.event_date),
        type: event.event_type as "meeting" | "holiday" | "other",
        description: event.description,
      })) || [];

      setEvents([...leaveEvents, ...taskEvents, ...customEventsFormatted]);
    } catch (error: any) {
      console.error("Error fetching events:", error);
      toast.error("ივენთების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const handleCreateEvent = async () => {
    if (!newEvent.title || !newEvent.event_date) {
      toast.error("გთხოვთ შეავსოთ ყველა სავალდებულო ველი");
      return;
    }

    try {
      const { error } = await supabase.from("events").insert({
        title: newEvent.title,
        description: newEvent.description,
        event_date: newEvent.event_date,
        event_type: newEvent.event_type,
        created_by: user?.id,
      });

      if (error) throw error;

      toast.success("ივენთი წარმატებით შეიქმნა");
      setIsDialogOpen(false);
      setNewEvent({
        title: "",
        description: "",
        event_date: formatters.isoDate(new Date()),
        event_type: "meeting",
      });
      fetchEvents();
    } catch (error: any) {
      console.error("Error creating event:", error);
      toast.error("ივენთის შექმნა ვერ მოხერხდა");
    }
  };

  const getEventsForDate = (date: Date) => {
    return events.filter((event) => isSameDay(event.date, date));
  };

  const selectedDateEvents = selectedDate ? getEventsForDate(selectedDate) : [];

  const getDayClassName = (date: Date) => {
    const dayEvents = getEventsForDate(date);
    if (dayEvents.length === 0) return "";
    
    const hasLeave = dayEvents.some(e => e.type === "leave");
    const hasDeadline = dayEvents.some(e => e.type === "deadline");
    
    if (hasLeave && hasDeadline) return "bg-orange-500/20 font-semibold";
    if (hasLeave) return "bg-blue-500/20 font-semibold";
    if (hasDeadline) return "bg-red-500/20 font-semibold";
    return "bg-green-500/20 font-semibold";
  };

  const getEventIcon = (type: string, status?: string) => {
    switch (type) {
      case "leave":
        return <CalendarIcon className="h-4 w-4" />;
      case "task":
        return <CheckCircle2 className="h-4 w-4" />;
      case "deadline":
        return <AlertCircle className="h-4 w-4" />;
      case "meeting":
        return <Users className="h-4 w-4" />;
      case "holiday":
        return <CalendarIcon className="h-4 w-4" />;
      case "other":
        return <Clock className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getEventBadgeVariant = (type: string, status?: string) => {
    if (type === "leave") {
      if (status === "approved") return "default";
      if (status === "pending") return "secondary";
      return "destructive";
    }
    if (type === "deadline") return "destructive";
    if (type === "meeting") return "default";
    if (type === "holiday") return "secondary";
    return "outline";
  };

  const getEventTypeLabel = (type: string) => {
    switch (type) {
      case "leave":
        return "შვებულება";
      case "task":
        return "დავალება";
      case "deadline":
        return "Deadline";
      case "meeting":
        return "შეხვედრა";
      case "holiday":
        return "დღესასწაული";
      case "other":
        return "სხვა";
      default:
        return type;
    }
  };

  const handleExportToIcs = async (exportType: 'all' | 'leaves' | 'trips' | 'birthdays' | 'tasks') => {
    try {
      const icsEvents: IcsEvent[] = [];
      const year = currentMonth.getFullYear();

      if (exportType === 'all' || exportType === 'leaves') {
        const { data: leaves } = await supabase
          .from("leave_requests")
          .select("id, start_date, end_date, leave_type, status, employees!leave_requests_employee_id_fkey(full_name)")
          .eq("status", "approved")
          .gte("start_date", `${year}-01-01`)
          .lte("end_date", `${year}-12-31`);

        leaves?.forEach((leave: any) => {
          const endDate = new Date(leave.end_date);
          endDate.setDate(endDate.getDate() + 1);
          icsEvents.push({
            uid: `leave-${leave.id}`,
            title: `🏖 შვებულება - ${leave.employees?.full_name || 'თანამშრომელი'}`,
            description: `ტიპი: ${leave.leave_type}`,
            startDate: new Date(leave.start_date),
            endDate,
            allDay: true,
            category: 'შვებულება',
          });
        });
      }

      if (exportType === 'all' || exportType === 'trips') {
        const { data: trips } = await supabase
          .from("business_trip_requests")
          .select("id, destination, purpose, start_date, end_date, status, employees!business_trip_requests_employee_id_fkey(full_name)")
          .eq("status", "approved")
          .gte("start_date", `${year}-01-01`)
          .lte("end_date", `${year}-12-31`);

        trips?.forEach((trip: any) => {
          const endDate = new Date(trip.end_date);
          endDate.setDate(endDate.getDate() + 1);
          icsEvents.push({
            uid: `trip-${trip.id}`,
            title: `✈️ მივლინება - ${trip.employees?.full_name || 'თანამშრომელი'}`,
            description: `მიზანი: ${trip.purpose}`,
            startDate: new Date(trip.start_date),
            endDate,
            allDay: true,
            location: trip.destination,
            category: 'მივლინება',
          });
        });
      }

      if (exportType === 'all' || exportType === 'birthdays') {
        const { data: employees } = await supabase
          .from("employees")
          .select("id, full_name, date_of_birth")
          .eq("status", "active")
          .not("date_of_birth", "is", null);

        employees?.forEach((emp: any) => {
          if (!emp.date_of_birth) return;
          const dob = new Date(emp.date_of_birth);
          const birthday = new Date(year, dob.getMonth(), dob.getDate());
          const nextDay = new Date(birthday);
          nextDay.setDate(nextDay.getDate() + 1);
          icsEvents.push({
            uid: `bday-${emp.id}-${year}`,
            title: `🎂 დაბადების დღე - ${emp.full_name}`,
            startDate: birthday,
            endDate: nextDay,
            allDay: true,
            category: 'დაბადების დღე',
          });
        });
      }

      if (exportType === 'all' || exportType === 'tasks') {
        const { data: tasks } = await supabase
          .from("tasks")
          .select("id, title, due_date, status, priority")
          .not("due_date", "is", null)
          .gte("due_date", `${year}-01-01`)
          .lte("due_date", `${year}-12-31`);

        tasks?.forEach((task: any) => {
          const dueDate = new Date(task.due_date);
          const nextDay = new Date(dueDate);
          nextDay.setDate(nextDay.getDate() + 1);
          icsEvents.push({
            uid: `task-${task.id}`,
            title: `📋 ${task.title}`,
            description: `პრიორიტეტი: ${task.priority || 'საშუალო'} | სტატუსი: ${task.status}`,
            startDate: dueDate,
            endDate: nextDay,
            allDay: true,
            category: 'დავალება',
          });
        });
      }

      if (icsEvents.length === 0) {
        toast.info("ექსპორტისთვის მონაცემები არ მოიძებნა");
        return;
      }

      const labels: Record<string, string> = {
        all: 'ყველა',
        leaves: 'შვებულებები',
        trips: 'მივლინებები',
        birthdays: 'დაბადების_დღეები',
        tasks: 'დავალებები',
      };

      const icsContent = generateIcsCalendar(icsEvents, `TalentOS - ${labels[exportType]}`);
      downloadIcsFile(icsContent, `talentos-${labels[exportType]}-${year}.ics`);
      toast.success(`${icsEvents.length} ივენთი ექსპორტირებულია .ics ფაილში`);
    } catch (error) {
      console.error("Export error:", error);
      toast.error("ექსპორტი ვერ მოხერხდა");
    }
  };

  return (
    <div className="container mx-auto p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">კალენდარი</h1>
          <p className="text-muted-foreground">
            შვებულებები, დავალებების deadline-ები და მნიშვნელოვანი ივენთები
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Google Calendar-ში ექსპორტი
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleExportToIcs('all')}>
                📅 ყველა ივენთი
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => handleExportToIcs('leaves')}>
                🏖 შვებულებები
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportToIcs('trips')}>
                ✈️ მივლინებები
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportToIcs('birthdays')}>
                🎂 დაბადების დღეები
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportToIcs('tasks')}>
                📋 დავალებების deadline-ები
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                ახალი ივენთი
              </Button>
            </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>ახალი ივენთის შექმნა</DialogTitle>
              <DialogDescription>
                დაამატეთ მნიშვნელოვანი შეხვედრა, დღესასწაული ან სხვა ივენთი
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title">სათაური *</Label>
                <Input
                  id="title"
                  value={newEvent.title}
                  onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                  placeholder="შეიყვანეთ ივენთის სათაური"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="event_type">ტიპი *</Label>
                <Select
                  value={newEvent.event_type}
                  onValueChange={(value: "meeting" | "holiday" | "other") =>
                    setNewEvent({ ...newEvent, event_type: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="meeting">შეხვედრა</SelectItem>
                    <SelectItem value="holiday">დღესასწაული</SelectItem>
                    <SelectItem value="other">სხვა</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="event_date">თარიღი *</Label>
                <Input
                  id="event_date"
                  type="date"
                  value={newEvent.event_date}
                  onChange={(e) => setNewEvent({ ...newEvent, event_date: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">აღწერა</Label>
                <Textarea
                  id="description"
                  value={newEvent.description}
                  onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                  placeholder="შეიყვანეთ დამატებითი დეტალები"
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                გაუქმება
              </Button>
              <Button onClick={handleCreateEvent}>შექმნა</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>კალენდარი</CardTitle>
            <CardDescription>
              აირჩიეთ თარიღი დეტალების სანახავად
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center p-8">
                <Skeleton className="h-[350px] w-full max-w-md mx-auto" />
              </div>
            ) : (
              <div className="flex justify-center w-full">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  onMonthChange={setCurrentMonth}
                  className="rounded-md border"
                  modifiers={{
                    hasEvents: (date) => getEventsForDate(date).length > 0,
                  }}
                  modifiersClassNames={{
                    hasEvents: "relative after:absolute after:bottom-1 after:left-1/2 after:-translate-x-1/2 after:h-1 after:w-1 after:rounded-full after:bg-primary",
                  }}
                  components={{
                    Day: ({ date, ...props }) => {
                      const dayClassName = getDayClassName(date);
                      return (
                        <div className={dayClassName}>
                          <button {...props as any} />
                        </div>
                      );
                    },
                  }}
                />
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              {selectedDate ? formatters.longDate(selectedDate) : "აირჩიეთ თარიღი"}
            </CardTitle>
            <CardDescription>
              ივენთები არჩეულ თარიღზე
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : selectedDateEvents.length > 0 ? (
              <div className="space-y-3">
                {selectedDateEvents.map((event) => (
                  <Card key={event.id} className="border-l-4 border-l-primary">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="mt-0.5">
                          {getEventIcon(event.type, event.status)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant={getEventBadgeVariant(event.type, event.status)} className="text-xs">
                              {getEventTypeLabel(event.type)}
                            </Badge>
                            {event.status && (
                              <Badge variant="outline" className="text-xs">
                                {event.status}
                              </Badge>
                            )}
                          </div>
                          <h4 className="font-medium text-sm leading-tight">{event.title}</h4>
                          {event.description && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {event.description}
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <CalendarIcon className="h-12 w-12 mx-auto mb-3 opacity-20" />
                <p className="text-sm">ამ თარიღზე ივენთები არ არის</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>ლეგენდა</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-4 lg:grid-cols-6">
            <div className="flex items-center gap-2">
              <div className="h-4 w-4 rounded bg-blue-500/20 border border-blue-500/40" />
              <span className="text-sm">შვებულება</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-4 w-4 rounded bg-red-500/20 border border-red-500/40" />
              <span className="text-sm">Deadline</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-4 w-4 rounded bg-green-500/20 border border-green-500/40" />
              <span className="text-sm">დასრულებული</span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              <span className="text-sm">შეხვედრა</span>
            </div>
            <div className="flex items-center gap-2">
              <CalendarIcon className="h-4 w-4 text-secondary" />
              <span className="text-sm">დღესასწაული</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">სხვა</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
