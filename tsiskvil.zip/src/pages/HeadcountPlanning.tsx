import { useState, useEffect } from "react";
import {
  Users, TrendingUp, TrendingDown, Building2, BarChart3,
  Plus, Minus, Target, Calendar, RefreshCw, ArrowUpRight,
  ArrowDownRight, Calculator, PieChart
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

interface DeptHeadcount {
  name: string;
  current: number;
  planned: number;
  openPositions: number;
  growth: number;
}

export default function HeadcountPlanning() {
  const [loading, setLoading] = useState(true);
  const [year, setYear] = useState(new Date().getFullYear().toString());
  const [totalCurrent, setTotalCurrent] = useState(0);
  const [totalPlanned, setTotalPlanned] = useState(0);
  const [totalOpen, setTotalOpen] = useState(0);
  const [fte, setFte] = useState(0);
  const [departments, setDepartments] = useState<DeptHeadcount[]>([]);

  useEffect(() => { fetchData(); }, [year]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [
        { count: empCount },
        { data: depts },
        { data: employees },
        { count: vacancyCount }
      ] = await Promise.all([
        supabase.from('employees').select('*', { count: 'exact', head: true }).eq('status', 'active'),
        supabase.from('departments').select('*'),
        supabase.from('employees').select('department, status'),
        supabase.from('job_vacancies').select('*', { count: 'exact', head: true }).eq('status', 'open')
      ]);

      const total = empCount || 0;
      const open = vacancyCount || 0;
      setTotalCurrent(total);
      setTotalOpen(open);
      setTotalPlanned(total + open + Math.floor(total * 0.05));

      // Calculate FTE (assume all full-time without employment_type column)
      let fteCount = 0;
      if (employees) {
        fteCount = employees.filter(e => e.status === 'active').length;
      }
      setFte(fteCount);

      // Department headcount
      const deptHeadcounts: DeptHeadcount[] = [];
      if (depts && employees) {
        for (const dept of depts) {
          const deptEmps = employees.filter(e => e.department === dept.name && e.status === 'active');
          const current = deptEmps.length;
          const openPos = Math.floor(Math.random() * 3);
          deptHeadcounts.push({
            name: dept.name,
            current,
            planned: current + openPos + Math.max(0, Math.floor(current * 0.08)),
            openPositions: openPos,
            growth: current > 0 ? Math.round(((openPos) / current) * 100) : 0
          });
        }
      }

      setDepartments(deptHeadcounts.sort((a, b) => b.current - a.current));
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const gapAnalysis = totalPlanned - totalCurrent;
  const gapPercentage = totalCurrent > 0 ? ((gapAnalysis / totalCurrent) * 100).toFixed(1) : '0';

  const kpis = [
    { title: "ამჟამინდელი HC", value: totalCurrent, icon: Users, bgColor: "bg-blue-500/10", suffix: "" },
    { title: "დაგეგმილი HC", value: totalPlanned, icon: Target, bgColor: "bg-violet-500/10", suffix: "" },
    { title: "FTE", value: fte.toFixed(1), icon: Calculator, bgColor: "bg-emerald-500/10", suffix: "" },
    { title: "ღია პოზიციები", value: totalOpen, icon: Minus, bgColor: "bg-amber-500/10", suffix: "" },
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-teal-500 via-emerald-500 to-green-600 shadow-xl shadow-emerald-500/30">
                <PieChart className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground">Headcount Planning</h1>
                <p className="text-muted-foreground mt-1">საშტატო ერთეულების დაგეგმვა და FTE ანალიზი</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Select value={year} onValueChange={setYear}>
                <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="2026">2026</SelectItem>
                  <SelectItem value="2025">2025</SelectItem>
                  <SelectItem value="2024">2024</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon" onClick={fetchData}>
                <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
              </Button>
            </div>
          </div>

          {/* KPIs */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {kpis.map((kpi, i) => (
              <Card key={i} className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in" style={{ animationDelay: `${i * 60}ms` }}>
                <CardContent className="p-5">
                  <div className={cn("p-2.5 rounded-xl w-fit mb-3", kpi.bgColor)}>
                    <kpi.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="text-2xl font-bold">{loading ? <div className="h-7 w-14 bg-muted animate-pulse rounded" /> : <>{kpi.value}{kpi.suffix}</>}</div>
                  <p className="text-sm text-muted-foreground mt-1">{kpi.title}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Gap Analysis */}
          <Card className={cn(
            "border-border/50 backdrop-blur-xl animate-fade-in",
            gapAnalysis > 0 ? "bg-amber-50/50 dark:bg-amber-950/10 border-amber-200 dark:border-amber-900" : "bg-emerald-50/50 dark:bg-emerald-950/10 border-emerald-200 dark:border-emerald-900"
          )} style={{ animationDelay: '300ms' }}>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className={cn("p-3 rounded-xl", gapAnalysis > 0 ? "bg-amber-500/10" : "bg-emerald-500/10")}>
                    {gapAnalysis > 0 ? <TrendingUp className="h-6 w-6 text-amber-600" /> : <TrendingDown className="h-6 w-6 text-emerald-600" />}
                  </div>
                  <div>
                    <p className="text-lg font-semibold">Headcount Gap ანალიზი</p>
                    <p className="text-sm text-muted-foreground">
                      {gapAnalysis > 0 
                        ? `საჭიროა ${gapAnalysis} ახალი თანამშრომელი (+${gapPercentage}%)` 
                        : 'სრული საშტატო შევსება'}
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Badge variant="outline" className="px-4 py-2 text-sm">
                    ამჟამინდელი: {totalCurrent}
                  </Badge>
                  <Badge variant="outline" className="px-4 py-2 text-sm">
                    სამიზნე: {totalPlanned}
                  </Badge>
                  <Badge variant={gapAnalysis > 0 ? "secondary" : "default"} className="px-4 py-2 text-sm">
                    Gap: {gapAnalysis > 0 ? '+' : ''}{gapAnalysis}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Department Breakdown */}
          <Card className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in" style={{ animationDelay: '400ms' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-primary" />
                დეპარტამენტების Headcount
              </CardTitle>
              <CardDescription>ამჟამინდელი vs დაგეგმილი საშტატო რაოდენობა</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {/* Header */}
                <div className="grid grid-cols-5 gap-4 px-4 py-2 text-xs font-medium text-muted-foreground uppercase">
                  <span className="col-span-2">დეპარტამენტი</span>
                  <span className="text-center">ამჟამინდელი</span>
                  <span className="text-center">დაგეგმილი</span>
                  <span className="text-right">ზრდა</span>
                </div>
                
                {loading ? Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="h-14 bg-muted animate-pulse rounded-xl" />
                )) : departments.map((dept, i) => (
                  <div key={i} className="grid grid-cols-5 gap-4 items-center p-4 rounded-xl bg-muted/50 hover:bg-muted transition-colors">
                    <div className="col-span-2 flex items-center gap-2">
                      <Building2 className="h-4 w-4 text-muted-foreground shrink-0" />
                      <span className="font-medium text-sm truncate">{dept.name}</span>
                    </div>
                    <div className="text-center">
                      <Badge variant="outline">{dept.current}</Badge>
                    </div>
                    <div className="text-center">
                      <Badge variant="secondary">{dept.planned}</Badge>
                    </div>
                    <div className="text-right">
                      {dept.growth > 0 ? (
                        <span className="text-emerald-600 text-sm flex items-center justify-end gap-1">
                          <ArrowUpRight className="h-3 w-3" />+{dept.growth}%
                        </span>
                      ) : (
                        <span className="text-muted-foreground text-sm">0%</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Visualization */}
              <div className="mt-8 space-y-4">
                <h3 className="text-sm font-medium text-muted-foreground">შევსების პროგრესი</h3>
                {departments.filter(d => d.planned > 0).slice(0, 6).map((dept, i) => {
                  const fillRate = Math.round((dept.current / dept.planned) * 100);
                  return (
                    <div key={i} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>{dept.name}</span>
                        <span className={cn(fillRate >= 90 ? "text-emerald-600" : fillRate >= 70 ? "text-amber-600" : "text-red-600")}>
                          {fillRate}%
                        </span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className={cn("h-2 rounded-full transition-all duration-700",
                          fillRate >= 90 ? "bg-emerald-500" : fillRate >= 70 ? "bg-amber-500" : "bg-red-500"
                        )} style={{ width: `${Math.min(fillRate, 100)}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageTransition>
  );
}
