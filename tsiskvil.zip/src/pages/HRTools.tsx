import { useNavigate } from "react-router-dom";
import { useFeatureLock, FeatureLockOverlay } from "@/components/FeatureCardLock";
import { Card, CardContent } from "@/components/ui/card";
import {
  Heart,
  Users,
  BarChart3,
  Activity,
  Grid3X3,
  ArrowRightLeft,
  LogOut,
  Sparkles,
  Workflow,
  GitBranch,
  BookOpen,
  FileText,
  Trophy,
  Hotel,
  Scale,
} from "lucide-react";

const hrToolCards = [
  {
    title: "კეთილდღეობა",
    description: "თანამშრომელთა ბერნაუტის ინდიკატორები, სტრესის მონიტორინგი და Mood Check-in",
    icon: Heart,
    url: "/employee-wellness",
    gradient: "from-rose-500 to-pink-500",
    bgGlow: "bg-rose-500/10",
  },
  {
    title: "Headcount Planning",
    description: "FTE ანალიზი, ზრდის პროგნოზირება და რესურსების დაგეგმვა",
    icon: Users,
    url: "/headcount-planning",
    gradient: "from-blue-500 to-cyan-500",
    bgGlow: "bg-blue-500/10",
  },
  {
    title: "ჩართულობის ანალიტიკა",
    description: "eNPS, ჩართულობის ინდექსი და თანამშრომელთა კმაყოფილება",
    icon: BarChart3,
    url: "/engagement-analytics",
    gradient: "from-emerald-500 to-teal-500",
    bgGlow: "bg-emerald-500/10",
  },
  {
    title: "კომპეტენციები",
    description: "კომპეტენციების რუკა, Skill Gap ანალიზი და განვითარების გეგმა",
    icon: Grid3X3,
    url: "/skills-matrix",
    gradient: "from-violet-500 to-purple-500",
    bgGlow: "bg-violet-500/10",
  },
  {
    title: "HR ანალიტიკა",
    description: "Turnover, Retention, Tenure ანალიზი და ტრენდები",
    icon: Activity,
    url: "/hr-analytics",
    gradient: "from-amber-500 to-orange-500",
    bgGlow: "bg-amber-500/10",
  },
  {
    title: "შიდა მობილობა",
    description: "როტაციები, შიდა ვაკანსიები და კარიერული განვითარება",
    icon: ArrowRightLeft,
    url: "/internal-mobility",
    gradient: "from-indigo-500 to-blue-500",
    bgGlow: "bg-indigo-500/10",
  },
  {
    title: "გასვლის ინტერვიუ",
    description: "Exit Interview, ციფრული ჩეკლისტები და მიზეზების ანალიტიკა",
    icon: LogOut,
    url: "/exit-interview",
    gradient: "from-slate-500 to-gray-500",
    bgGlow: "bg-slate-500/10",
  },
  {
    title: "Workflow კონსტრუქტორი",
    description: "ბიზნეს პროცესების ვიზუალური აწყობა და ავტომატიზაცია",
    icon: Workflow,
    url: "/workflow-builder",
    gradient: "from-fuchsia-500 to-pink-500",
    bgGlow: "bg-fuchsia-500/10",
  },
  {
    title: "დამტკიცების ჯაჭვები",
    description: "მრავალდონიანი approval flow-ების კონფიგურაცია",
    icon: GitBranch,
    url: "/approval-chains",
    gradient: "from-cyan-500 to-blue-500",
    bgGlow: "bg-cyan-500/10",
  },
  {
    title: "ოფბორდინგი",
    description: "გათავისუფლების პროცესი, ჩეკლისტები და დოკუმენტები",
    icon: LogOut,
    url: "/offboarding",
    gradient: "from-zinc-500 to-stone-500",
    bgGlow: "bg-zinc-500/10",
  },
  {
    title: "Wiki",
    description: "შიდა ცოდნის ბაზა, სახელმძღვანელოები და დოკუმენტაცია",
    icon: BookOpen,
    url: "/wiki",
    gradient: "from-teal-500 to-emerald-500",
    bgGlow: "bg-teal-500/10",
  },
  {
    title: "AI დოკუმენტები",
    description: "ხელშეკრულებების და დოკუმენტების ავტომატური გენერაცია AI-ით",
    icon: FileText,
    url: "/ai-documents",
    gradient: "from-purple-500 to-violet-500",
    bgGlow: "bg-purple-500/10",
  },
  {
    title: "გემიფიკაცია",
    description: "ქულები, ნიშნები, ჯილდოები და თანამშრომელთა აღიარება",
    icon: Trophy,
    url: "/recognition",
    gradient: "from-yellow-500 to-amber-500",
    bgGlow: "bg-yellow-500/10",
  },
  {
    title: "მოგზაურობის ცენტრი",
    description: "სასტუმროების ჯავშნები, სადღეღამისო და მივლინების ხარჯების ერთიანი ციკლი",
    icon: Hotel,
    url: "/travel-desk",
    gradient: "from-sky-500 to-blue-600",
    bgGlow: "bg-sky-500/10",
  },
  {
    title: "ხელფასების ბენჩმარკინგი",
    description: "ანონიმური ბაზრის შედარება, retention რისკები და ბიუჯეტის სიმულატორი",
    icon: Scale,
    url: "/salary-benchmarking",
    gradient: "from-indigo-500 to-purple-600",
    bgGlow: "bg-indigo-500/10",
  },
];

const HRTools = () => {
  const navigate = useNavigate();
  const { isLocked, handleLockedClick } = useFeatureLock();
  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center gap-3 mb-1">
          <div className="p-2 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5">
            <Sparkles className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">HR ინსტრუმენტები</h1>
            <p className="text-sm text-muted-foreground">მოწინავე HR მოდულები და ანალიტიკა</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {hrToolCards.map((card) => {
          const Icon = card.icon;
          return (
            <Card
              key={card.url}
              className="group cursor-pointer border border-border/50 hover:border-primary/30 hover:shadow-lg transition-all duration-300 overflow-hidden relative"
              onClick={(e) => isLocked(card.url) ? handleLockedClick(e) : navigate(card.url)}
            >
              {isLocked(card.url) && <FeatureLockOverlay />}
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <div className={`p-2.5 rounded-xl ${card.bgGlow} group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className={`h-5 w-5 bg-gradient-to-br ${card.gradient} bg-clip-text`} style={{ color: `var(--${card.gradient.split('-')[1]}-500, hsl(var(--primary)))` }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                      {card.title}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {card.description}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default HRTools;
