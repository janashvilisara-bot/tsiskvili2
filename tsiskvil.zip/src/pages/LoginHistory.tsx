import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertTriangle, Search, MapPin, Shield, RefreshCw } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { Navigate } from 'react-router-dom';

interface LoginRecord {
  id: string;
  user_id: string;
  email: string;
  ip_address: string | null;
  user_agent: string | null;
  country: string | null;
  city: string | null;
  is_suspicious: boolean;
  anomaly_reason: string | null;
  login_at: string;
}

export default function LoginHistory() {
  const { userRole } = useAuth();
  const [logins, setLogins] = useState<LoginRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<'all' | 'suspicious'>('all');
  const [search, setSearch] = useState('');

  // Only admin and HR can access
  if (userRole !== 'admin' && userRole !== 'hr_manager') {
    return <Navigate to="/employee-portal" replace />;
  }

  const fetchLogins = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('login_history')
        .select('*')
        .order('login_at', { ascending: false })
        .limit(200);

      if (filter === 'suspicious') {
        query = query.eq('is_suspicious', true);
      }

      const { data, error } = await query;

      if (error) throw error;
      setLogins(data || []);
    } catch (err) {
      console.error('Error fetching login history:', err);
      toast.error('ლოგინების ისტორიის ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogins();
  }, [filter]);

  const filteredLogins = logins.filter(login => {
    if (!search) return true;
    const searchLower = search.toLowerCase();
    return (
      login.email?.toLowerCase().includes(searchLower) ||
      login.ip_address?.toLowerCase().includes(searchLower) ||
      login.country?.toLowerCase().includes(searchLower) ||
      login.city?.toLowerCase().includes(searchLower)
    );
  });

  const suspiciousCount = logins.filter(l => l.is_suspicious).length;

  const getBrowserFromUserAgent = (ua: string | null): string => {
    if (!ua) return 'უცნობი';
    if (ua.includes('Firefox')) return 'Firefox';
    if (ua.includes('Chrome')) return 'Chrome';
    if (ua.includes('Safari')) return 'Safari';
    if (ua.includes('Edge')) return 'Edge';
    return 'სხვა';
  };

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold">შესვლების ისტორია</h1>
              <p className="text-muted-foreground">
                IP/Geo Anomaly Detection - საეჭვო ლოგინების მონიტორინგი
              </p>
            </div>
          </div>
          <Button onClick={fetchLogins} variant="outline" disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            განახლება
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">სულ შესვლები</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{logins.length}</p>
            </CardContent>
          </Card>
          <Card className={suspiciousCount > 0 ? 'border-amber-500' : ''}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
                საეჭვო შესვლები
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className={`text-2xl font-bold ${suspiciousCount > 0 ? 'text-amber-500' : ''}`}>
                {suspiciousCount}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">უნიკალური IP-ები</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">
                {new Set(logins.map(l => l.ip_address).filter(Boolean)).size}
              </p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>შესვლების ჟურნალი</CardTitle>
            <CardDescription>
              ახალი IP მისამართიდან შესვლისას ავტომატურად იგზავნება ალერტი HR/Admin-ზე
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Filters */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="ძიება email, IP, ქვეყანა..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filter} onValueChange={(v) => setFilter(v as 'all' | 'suspicious')}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="ფილტრი" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  <SelectItem value="suspicious">მხოლოდ საეჭვო</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {loading ? (
              <div className="text-center py-8 text-muted-foreground">იტვირთება...</div>
            ) : filteredLogins.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                შესვლების ჩანაწერები არ მოიძებნა
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>მომხმარებელი</TableHead>
                      <TableHead>IP მისამართი</TableHead>
                      <TableHead>ლოკაცია</TableHead>
                      <TableHead>ბრაუზერი</TableHead>
                      <TableHead>თარიღი</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredLogins.map((login) => (
                      <TableRow key={login.id} className={login.is_suspicious ? 'bg-amber-50 dark:bg-amber-950/20' : ''}>
                        <TableCell className="font-medium">{login.email}</TableCell>
                        <TableCell className="font-mono text-sm">
                          {login.ip_address || 'N/A'}
                        </TableCell>
                        <TableCell>
                          {login.country || login.city ? (
                            <div className="flex items-center gap-1">
                              <MapPin className="h-3 w-3 text-muted-foreground" />
                              <span>
                                {[login.city, login.country].filter(Boolean).join(', ')}
                              </span>
                            </div>
                          ) : (
                            <span className="text-muted-foreground">უცნობი</span>
                          )}
                        </TableCell>
                        <TableCell>{getBrowserFromUserAgent(login.user_agent)}</TableCell>
                        <TableCell>
                          {format(new Date(login.login_at), 'dd.MM.yyyy HH:mm')}
                        </TableCell>
                        <TableCell>
                          {login.is_suspicious ? (
                            <div>
                              <Badge variant="destructive" className="flex items-center gap-1 w-fit">
                                <AlertTriangle className="h-3 w-3" />
                                საეჭვო
                              </Badge>
                              {login.anomaly_reason && (
                                <p className="text-xs text-muted-foreground mt-1 max-w-[200px] truncate">
                                  {login.anomaly_reason}
                                </p>
                              )}
                            </div>
                          ) : (
                            <Badge variant="secondary">ნორმალური</Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
