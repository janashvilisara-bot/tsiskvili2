import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Mail, Phone, FileText, Calendar, Briefcase, MapPin, DollarSign, 
  User, Search, Upload, Eye, Sparkles, UserPlus, Users, TrendingUp,
  CheckCircle2, Clock, Star, Filter
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AddCandidateDialog } from "@/components/candidates/AddCandidateDialog";
import { motion } from "framer-motion";

interface Vacancy {
  id: string;
  title: string;
  description: string;
  requirements: string;
  location: string;
  salary_min: number;
  salary_max: number;
  employment_type: string;
  experience_level: string;
  status: string;
}

interface Candidate {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  cover_letter: string | null;
  applied_date: string;
  status: string;
  vacancy_id: string | null;
  photo_url: string | null;
  resume_file_path: string | null;
  resume_url?: string | null;
  source?: string | null;
  external_source?: string | null;
  external_application_id?: string | null;
  match_score?: number;
  ai_analysis?: string;
  vacancy?: {
    title: string;
  };
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4 } }
};

export default function Candidates() {
  const { userRole } = useAuth();
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [vacancies, setVacancies] = useState<Vacancy[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [showApplicationForm, setShowApplicationForm] = useState(false);
  const [selectedVacancy, setSelectedVacancy] = useState<Vacancy | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [sortBy, setSortBy] = useState<'date' | 'score'>('date');
  const [selectedVacancyForAnalysis, setSelectedVacancyForAnalysis] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analyzingCandidateId, setAnalyzingCandidateId] = useState<string | null>(null);
  const [vacancyFilter, setVacancyFilter] = useState<string>('all');
  const [showAddCandidateDialog, setShowAddCandidateDialog] = useState(false);

  useEffect(() => {
    fetchVacancies();
    if (userRole === 'admin' || userRole === 'hr_manager') {
      fetchCandidates();
    }
  }, [userRole]);

  const fetchVacancies = async () => {
    const { data, error } = await supabase
      .from('job_vacancies')
      .select('*')
      .eq('status', 'open')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching vacancies:', error);
    } else {
      setVacancies(data || []);
    }
  };

  const fetchCandidates = async () => {
    const { data, error } = await supabase
      .from('candidates')
      .select(`
        *,
        vacancy:job_vacancies(title)
      `)
      .order('applied_date', { ascending: false });

    if (error) {
      console.error('Error fetching candidates:', error);
    } else {
      setCandidates(data || []);
    }
  };

  const handleApply = (vacancy: Vacancy) => {
    setSelectedVacancy(vacancy);
    setShowApplicationForm(true);
  };

  const handleSubmitApplication = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const formData = new FormData(e.currentTarget);

    try {
      let photoUrl = null;
      let resumePath = null;

      if (photoFile) {
        const photoExt = photoFile.name.split('.').pop();
        const photoPath = `${Date.now()}_${Math.random().toString(36).substring(7)}.${photoExt}`;
        
        const { error: photoError } = await supabase.storage
          .from('candidate-photos')
          .upload(photoPath, photoFile);

        if (photoError) throw photoError;
        
        const { data: signedUrlData } = await supabase.storage
          .from('candidate-photos')
          .createSignedUrl(photoPath, 60 * 60 * 24 * 365);
        
        photoUrl = signedUrlData?.signedUrl || null;
      }

      if (resumeFile) {
        const resumeExt = resumeFile.name.split('.').pop();
        resumePath = `${Date.now()}_${Math.random().toString(36).substring(7)}.${resumeExt}`;
        
        const { error: resumeError } = await supabase.storage
          .from('candidate-resumes')
          .upload(resumePath, resumeFile);

        if (resumeError) throw resumeError;
      }

      const payload = {
        full_name: formData.get('full_name') as string,
        email: formData.get('email') as string,
        phone: formData.get('phone') as string || null,
        cover_letter: formData.get('cover_letter') as string || null,
        vacancy_id: selectedVacancy?.id,
        status: 'new',
        photo_url: photoUrl,
        resume_file_path: resumePath,
      };

      const { error } = await supabase
        .from('candidates')
        .insert([payload]);

      if (error) throw error;

      toast.success('განაცხადი წარმატებით გაიგზავნა!');
      setShowApplicationForm(false);
      setPhotoFile(null);
      setResumeFile(null);
      (e.target as HTMLFormElement).reset();
      
      if (userRole === 'admin' || userRole === 'hr_manager') {
        fetchCandidates();
      }
    } catch (error: any) {
      console.error('Error:', error);
      toast.error(error.message || 'შეცდომა განაცხადის გაგზავნისას');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredCandidates = candidates
    .filter((candidate) => {
      const matchesSearch = 
        candidate.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        candidate.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        candidate.vacancy?.title?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesVacancy = vacancyFilter === 'all' || candidate.vacancy_id === vacancyFilter;
      
      return matchesSearch && matchesVacancy;
    })
    .sort((a, b) => {
      if (sortBy === 'score') {
        const scoreA = a.match_score ?? -1;
        const scoreB = b.match_score ?? -1;
        return scoreB - scoreA;
      }
      return new Date(b.applied_date).getTime() - new Date(a.applied_date).getTime();
    });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20';
      case 'screening': return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20';
      case 'interview': return 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20';
      case 'offer': return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20';
      case 'hired': return 'bg-green-600 text-white border-green-600';
      case 'rejected': return 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusText = (status: string) => {
    const statuses: Record<string, string> = {
      'new': 'ახალი',
      'screening': 'შერჩევა',
      'interview': 'ინტერვიუ',
      'offer': 'შეთავაზება',
      'hired': 'დაქირავებული',
      'rejected': 'უარყოფილი'
    };
    return statuses[status] || status;
  };

  const getEmploymentTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      'full_time': 'სრული განაკვეთი',
      'part_time': 'ნახევარი განაკვეთი',
      'contract': 'კონტრაქტი',
      'internship': 'სტაჟირება'
    };
    return types[type] || type;
  };

  const getExperienceLevelLabel = (level: string) => {
    const levels: Record<string, string> = {
      'junior': 'დამწყები',
      'mid': 'საშუალო',
      'senior': 'უფროსი',
      'lead': 'ლიდერი'
    };
    return levels[level] || level;
  };

  const handleAnalyzeCandidate = async (candidateId: string) => {
    if (!selectedVacancyForAnalysis) {
      toast.error('გთხოვთ აირჩიოთ ვაკანსია ანალიზისთვის');
      return;
    }
    
    setIsAnalyzing(true);
    setAnalyzingCandidateId(candidateId);

    try {
      const { data, error } = await supabase.functions.invoke('analyze-cv-match', {
        body: { candidateId, vacancyId: selectedVacancyForAnalysis }
      });

      if (error) throw error;

      toast.success(`AI ანალიზი დასრულდა: ${data.score}/100`);
      fetchCandidates();
    } catch (error: any) {
      console.error('Error:', error);
      if (error.message?.includes('429')) {
        toast.error('ძალიან ბევრი მოთხოვნა, გთხოვთ სცადოთ მოგვიანებით');
      } else if (error.message?.includes('402')) {
        toast.error('საჭიროა თანხის დამატება Lovable AI-ში');
      } else {
        toast.error('შეცდომა AI ანალიზისას');
      }
    } finally {
      setIsAnalyzing(false);
      setAnalyzingCandidateId(null);
    }
  };

  const handleAnalyzeAll = async () => {
    if (!selectedVacancyForAnalysis) {
      toast.error('გთხოვთ აირჩიოთ ვაკანსია ანალიზისთვის');
      return;
    }
    
    if (filteredCandidates.length === 0) return;
    
    setIsAnalyzing(true);
    
    for (const candidate of filteredCandidates) {
      try {
        setAnalyzingCandidateId(candidate.id);
        await handleAnalyzeCandidate(candidate.id);
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        console.error('Error analyzing candidate:', candidate.id, error);
      }
    }
    
    setIsAnalyzing(false);
    setAnalyzingCandidateId(null);
    toast.success('ყველა კანდიდატის ანალიზი დასრულდა');
  };

  // Stats
  const stats = {
    total: candidates.length,
    newCandidates: candidates.filter(c => c.status === 'new').length,
    inInterview: candidates.filter(c => c.status === 'interview').length,
    hired: candidates.filter(c => c.status === 'hired').length,
  };

  return (
    <div className="space-y-8 p-1">
      {/* Hero Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/10 via-accent/5 to-background border border-border/50 p-8"
      >
        <div className="absolute inset-0 bg-grid-white/5 [mask-image:linear-gradient(0deg,transparent,black)]" />
        <div className="relative">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
            ვაკანსიები და კანდიდატები
          </h1>
          <p className="mt-2 text-muted-foreground max-w-2xl">
            იხილეთ ღია ვაკანსიები, მართეთ კანდიდატები და გამოიყენეთ AI ანალიზი საუკეთესო ტალანტების მოსაძებნად
          </p>
        </div>
      </motion.div>

      {/* Stats Cards */}
      {(userRole === 'admin' || userRole === 'hr_manager') && (
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-2 md:grid-cols-4 gap-4"
        >
          <motion.div variants={itemVariants}>
            <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-blue-500/10 via-blue-500/5 to-transparent backdrop-blur-sm">
              <div className="absolute top-0 right-0 w-20 h-20 bg-blue-500/10 rounded-full -translate-y-1/2 translate-x-1/2" />
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-medium text-blue-600 dark:text-blue-400 uppercase tracking-wider">სულ კანდიდატი</p>
                    <p className="text-3xl font-bold text-blue-700 dark:text-blue-300 mt-1">{stats.total}</p>
                  </div>
                  <div className="p-3 bg-blue-500/20 rounded-xl">
                    <Users className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-transparent backdrop-blur-sm">
              <div className="absolute top-0 right-0 w-20 h-20 bg-amber-500/10 rounded-full -translate-y-1/2 translate-x-1/2" />
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-medium text-amber-600 dark:text-amber-400 uppercase tracking-wider">ახალი</p>
                    <p className="text-3xl font-bold text-amber-700 dark:text-amber-300 mt-1">{stats.newCandidates}</p>
                  </div>
                  <div className="p-3 bg-amber-500/20 rounded-xl">
                    <Star className="h-6 w-6 text-amber-600 dark:text-amber-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-purple-500/10 via-purple-500/5 to-transparent backdrop-blur-sm">
              <div className="absolute top-0 right-0 w-20 h-20 bg-purple-500/10 rounded-full -translate-y-1/2 translate-x-1/2" />
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-medium text-purple-600 dark:text-purple-400 uppercase tracking-wider">ინტერვიუზე</p>
                    <p className="text-3xl font-bold text-purple-700 dark:text-purple-300 mt-1">{stats.inInterview}</p>
                  </div>
                  <div className="p-3 bg-purple-500/20 rounded-xl">
                    <Clock className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="relative overflow-hidden border-0 bg-gradient-to-br from-emerald-500/10 via-emerald-500/5 to-transparent backdrop-blur-sm">
              <div className="absolute top-0 right-0 w-20 h-20 bg-emerald-500/10 rounded-full -translate-y-1/2 translate-x-1/2" />
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">დაქირავებული</p>
                    <p className="text-3xl font-bold text-emerald-700 dark:text-emerald-300 mt-1">{stats.hired}</p>
                  </div>
                  <div className="p-3 bg-emerald-500/20 rounded-xl">
                    <CheckCircle2 className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      )}

      {/* Open Vacancies Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Briefcase className="h-5 w-5 text-primary" />
          </div>
          <h2 className="text-2xl font-bold">ღია ვაკანსიები</h2>
          <Badge variant="secondary" className="ml-auto">{vacancies.length} აქტიური</Badge>
        </div>

        {vacancies.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="p-12 text-center">
              <Briefcase className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">ამჟამად ღია ვაკანსიები არ არის</p>
            </CardContent>
          </Card>
        ) : (
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid gap-5 md:grid-cols-2 lg:grid-cols-3"
          >
            {vacancies.map((vacancy) => (
              <motion.div key={vacancy.id} variants={itemVariants}>
                <Card className="group h-full hover:shadow-xl hover:shadow-primary/5 transition-all duration-300 border-border/50 hover:border-primary/30 bg-gradient-to-br from-card to-card/80">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="p-2.5 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl group-hover:scale-110 transition-transform">
                        <Briefcase className="h-5 w-5 text-primary" />
                      </div>
                      <Badge variant="secondary" className="shrink-0 bg-secondary/50">
                        {getEmploymentTypeLabel(vacancy.employment_type)}
                      </Badge>
                    </div>
                    <CardTitle className="text-lg mt-3 group-hover:text-primary transition-colors">
                      {vacancy.title}
                    </CardTitle>
                    <CardDescription className="line-clamp-2">
                      {vacancy.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {vacancy.location && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4 shrink-0" />
                        <span>{vacancy.location}</span>
                      </div>
                    )}
                    {(vacancy.salary_min || vacancy.salary_max) && (
                      <div className="flex items-center gap-2 text-sm font-medium text-emerald-600 dark:text-emerald-400">
                        <DollarSign className="h-4 w-4 shrink-0" />
                        <span>
                          {vacancy.salary_min && vacancy.salary_max
                            ? `${vacancy.salary_min.toLocaleString()} - ${vacancy.salary_max.toLocaleString()} ₾`
                            : vacancy.salary_min
                            ? `${vacancy.salary_min.toLocaleString()}+ ₾`
                            : `${vacancy.salary_max?.toLocaleString()} ₾`}
                        </span>
                      </div>
                    )}
                    {vacancy.experience_level && (
                      <Badge variant="outline" className="text-xs">
                        {getExperienceLevelLabel(vacancy.experience_level)}
                      </Badge>
                    )}
                    <Button 
                      className="w-full mt-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors" 
                      variant="outline"
                      onClick={() => handleApply(vacancy)}
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      განაცხადის გაგზავნა
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        )}
      </motion.section>

      {/* Application Form Dialog */}
      <Dialog open={showApplicationForm} onOpenChange={setShowApplicationForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl">
              განაცხადის გაგზავნა - {selectedVacancy?.title}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmitApplication} className="space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="full_name">სახელი და გვარი *</Label>
                <Input id="full_name" name="full_name" required placeholder="მაგ. გიორგი ბერიძე" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">ელ. ფოსტა *</Label>
                <Input id="email" name="email" type="email" required placeholder="example@mail.com" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">ტელეფონი</Label>
              <Input id="phone" name="phone" type="tel" placeholder="+995 555 123 456" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="photo">ფოტო</Label>
              <Input
                id="photo"
                type="file"
                accept="image/*"
                onChange={(e) => setPhotoFile(e.target.files?.[0] || null)}
                className="cursor-pointer"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="resume">CV / რეზიუმე *</Label>
              <Input
                id="resume"
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={(e) => setResumeFile(e.target.files?.[0] || null)}
                required
                className="cursor-pointer"
              />
              <p className="text-xs text-muted-foreground">PDF, DOC ან DOCX ფორმატი</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="cover_letter">სამოტივაციო წერილი</Label>
              <Textarea
                id="cover_letter"
                name="cover_letter"
                rows={4}
                placeholder="ჩაწერეთ რატომ გსურთ ამ პოზიციაზე მუშაობა..."
              />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowApplicationForm(false);
                  setPhotoFile(null);
                  setResumeFile(null);
                }}
              >
                გაუქმება
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'იგზავნება...' : 'განაცხადის გაგზავნა'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Candidates List - Only for Admin/HR */}
      {(userRole === 'admin' || userRole === 'hr_manager') && (
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-accent/10 rounded-lg">
                <Users className="h-5 w-5 text-accent" />
              </div>
              <h2 className="text-2xl font-bold">კანდიდატების სია</h2>
            </div>
            <Button onClick={() => setShowAddCandidateDialog(true)} className="gap-2 shadow-lg shadow-primary/20">
              <UserPlus className="h-4 w-4" />
              კანდიდატის დამატება
            </Button>
          </div>
          
          {/* Filters */}
          <Card className="mb-6 border-border/50 bg-card/50 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="ძებნა სახელით, ელ.ფოსტით ან ვაკანსიით..."
                    className="pl-10 bg-background"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Select value={vacancyFilter} onValueChange={setVacancyFilter}>
                  <SelectTrigger className="w-full lg:w-[220px] bg-background">
                    <Filter className="h-4 w-4 mr-2 text-muted-foreground" />
                    <SelectValue placeholder="ფილტრაცია" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა ვაკანსია</SelectItem>
                    {vacancies.map((vacancy) => (
                      <SelectItem key={vacancy.id} value={vacancy.id}>
                        {vacancy.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={(value: 'date' | 'score') => setSortBy(value)}>
                  <SelectTrigger className="w-full lg:w-[180px] bg-background">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="date">თარიღის მიხედვით</SelectItem>
                    <SelectItem value="score">AI ქულის მიხედვით</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
          
          {/* AI Analysis Card */}
          <Card className="mb-6 border-primary/20 bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row items-center gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl">
                    <Sparkles className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">AI ანალიზი</h3>
                    <p className="text-sm text-muted-foreground">შეადარეთ კანდიდატები ვაკანსიასთან</p>
                  </div>
                </div>
                <div className="flex-1 w-full md:w-auto">
                  <Select 
                    value={selectedVacancyForAnalysis} 
                    onValueChange={setSelectedVacancyForAnalysis}
                  >
                    <SelectTrigger className="bg-background">
                      <SelectValue placeholder="აირჩიეთ ვაკანსია ანალიზისთვის" />
                    </SelectTrigger>
                    <SelectContent>
                      {vacancies.map((vacancy) => (
                        <SelectItem key={vacancy.id} value={vacancy.id}>
                          {vacancy.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  onClick={handleAnalyzeAll}
                  disabled={isAnalyzing || !selectedVacancyForAnalysis || filteredCandidates.length === 0}
                  className="shrink-0 shadow-lg shadow-primary/20"
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  {isAnalyzing ? 'მიმდინარეობს...' : 'ყველას ანალიზი'}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Candidates Grid */}
          {filteredCandidates.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="p-12 text-center">
                <Users className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                <p className="text-muted-foreground">კანდიდატები ჯერ არ არის</p>
              </CardContent>
            </Card>
          ) : (
            <motion.div 
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid gap-4 md:grid-cols-2 lg:grid-cols-3"
            >
              {filteredCandidates.map((candidate) => (
                <motion.div key={candidate.id} variants={itemVariants}>
                  <Card 
                    className="group cursor-pointer hover:shadow-xl hover:shadow-primary/5 transition-all duration-300 border-border/50 hover:border-primary/30"
                    onClick={() => setSelectedCandidate(candidate)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-12 w-12 ring-2 ring-border group-hover:ring-primary/30 transition-all">
                            <AvatarImage src={candidate.photo_url || undefined} />
                            <AvatarFallback className="bg-gradient-to-br from-primary/80 to-accent/80 text-primary-foreground font-semibold">
                              {candidate.full_name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <CardTitle className="text-base flex items-center gap-2 truncate">
                              <span className="truncate">{candidate.full_name}</span>
                              {candidate.match_score !== null && candidate.match_score !== undefined && (
                                <Badge 
                                  variant="outline"
                                  className={`shrink-0 ${
                                    candidate.match_score >= 80 
                                      ? 'border-emerald-500/50 bg-emerald-500/10 text-emerald-600' 
                                      : candidate.match_score >= 60 
                                      ? 'border-amber-500/50 bg-amber-500/10 text-amber-600' 
                                      : 'border-border'
                                  }`}
                                >
                                  🤖 {candidate.match_score}
                                </Badge>
                              )}
                            </CardTitle>
                            {candidate.vacancy && (
                              <p className="text-sm text-muted-foreground truncate">
                                {candidate.vacancy.title}
                              </p>
                            )}
                          </div>
                        </div>
                        <Badge className={`${getStatusColor(candidate.status)} shrink-0`}>
                          {getStatusText(candidate.status)}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-2.5">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Mail className="h-4 w-4 shrink-0" />
                        <span className="truncate">{candidate.email}</span>
                      </div>
                      {candidate.phone && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Phone className="h-4 w-4 shrink-0" />
                          <span>{candidate.phone}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4 shrink-0" />
                        <span>{new Date(candidate.applied_date).toLocaleDateString('ka-GE')}</span>
                      </div>
                      <div className="flex gap-2 pt-2">
                        {selectedVacancyForAnalysis && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAnalyzeCandidate(candidate.id);
                            }}
                            disabled={isAnalyzing}
                          >
                            <Sparkles className="mr-1.5 h-3.5 w-3.5" />
                            {analyzingCandidateId === candidate.id ? 'ანალიზი...' : 'AI'}
                          </Button>
                        )}
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="mr-1.5 h-3.5 w-3.5" />
                          დეტალები
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          )}
        </motion.section>
      )}

      {/* Candidate Details Dialog */}
      <Dialog open={!!selectedCandidate} onOpenChange={() => setSelectedCandidate(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedCandidate && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl">კანდიდატის დეტალები</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Header with Photo */}
                <div className="flex items-start gap-6">
                  <Avatar className="h-24 w-24 ring-4 ring-primary/10">
                    <AvatarImage src={selectedCandidate.photo_url || undefined} />
                    <AvatarFallback className="text-2xl bg-gradient-to-br from-primary to-accent text-white">
                      {selectedCandidate.full_name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 space-y-2">
                    <h3 className="text-2xl font-bold">{selectedCandidate.full_name}</h3>
                    <Badge className={`${getStatusColor(selectedCandidate.status)} text-sm`}>
                      {getStatusText(selectedCandidate.status)}
                    </Badge>
                    <p className="text-sm text-muted-foreground flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      განაცხადის თარიღი: {new Date(selectedCandidate.applied_date).toLocaleDateString('ka-GE')}
                    </p>
                  </div>
                </div>

                <Separator />

                {/* Contact Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="bg-muted/30">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Mail className="h-4 w-4 text-primary" />
                        ელ. ფოსტა
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <a href={`mailto:${selectedCandidate.email}`} className="text-primary hover:underline">
                        {selectedCandidate.email}
                      </a>
                    </CardContent>
                  </Card>

                  <Card className="bg-muted/30">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Phone className="h-4 w-4 text-primary" />
                        ტელეფონი
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {selectedCandidate.phone ? (
                        <a href={`tel:${selectedCandidate.phone}`} className="text-primary hover:underline">
                          {selectedCandidate.phone}
                        </a>
                      ) : (
                        <span className="text-muted-foreground">არ არის მითითებული</span>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Cover Letter */}
                {selectedCandidate.cover_letter && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">სამოტივაციო წერილი</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="whitespace-pre-wrap text-sm leading-relaxed">
                        {selectedCandidate.cover_letter}
                      </p>
                    </CardContent>
                  </Card>
                )}

                {/* AI Analysis Results */}
                {selectedCandidate.ai_analysis && (
                  <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Sparkles className="h-5 w-5 text-primary" />
                        AI ანალიზის შედეგები
                        {selectedCandidate.match_score !== null && selectedCandidate.match_score !== undefined && (
                          <Badge className="ml-auto">
                            {selectedCandidate.match_score}/100
                          </Badge>
                        )}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="whitespace-pre-wrap text-sm leading-relaxed">
                        {selectedCandidate.ai_analysis}
                      </p>
                    </CardContent>
                  </Card>
                )}

                {/* Resume Download */}
                {(selectedCandidate.resume_file_path || selectedCandidate.resume_url) && (
                  <Card className="bg-primary/5 border-primary/20">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <FileText className="h-5 w-5 text-primary" />
                        CV / რეზიუმე
                        {selectedCandidate.external_source && (
                          <Badge variant="outline" className="ml-auto text-xs">
                            {selectedCandidate.external_source}
                          </Badge>
                        )}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Button
                        onClick={async () => {
                          // Prefer storage file if present, otherwise open external URL
                          if (selectedCandidate.resume_file_path) {
                            const { data } = await supabase.storage
                              .from('candidate-resumes')
                              .createSignedUrl(selectedCandidate.resume_file_path, 60 * 60);
                            if (data?.signedUrl) {
                              window.open(data.signedUrl, '_blank');
                              return;
                            }
                            toast.error('CV-ის ფაილის გახსნა ვერ მოხერხდა');
                            return;
                          }
                          if (selectedCandidate.resume_url) {
                            window.open(selectedCandidate.resume_url, '_blank', 'noopener,noreferrer');
                          }
                        }}
                        className="w-full"
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        CV-ის ნახვა/ჩამოტვირთვა
                      </Button>
                    </CardContent>
                  </Card>
                )}

                {/* Status Update */}
                {userRole && ['admin', 'hr_manager'].includes(userRole) && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">სტატუსის განახლება</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Select
                        defaultValue={selectedCandidate.status}
                        onValueChange={async (newStatus) => {
                          const { error } = await supabase
                            .from('candidates')
                            .update({ status: newStatus })
                            .eq('id', selectedCandidate.id);

                          if (error) {
                            toast.error('სტატუსის განახლება ვერ მოხერხდა');
                          } else {
                            toast.success('სტატუსი განახლდა');
                            setSelectedCandidate({ ...selectedCandidate, status: newStatus });
                            fetchCandidates();
                          }
                        }}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new">ახალი</SelectItem>
                          <SelectItem value="screening">შერჩევა</SelectItem>
                          <SelectItem value="interview">ინტერვიუ</SelectItem>
                          <SelectItem value="offer">შეთავაზება</SelectItem>
                          <SelectItem value="hired">დაქირავებული</SelectItem>
                          <SelectItem value="rejected">უარყოფილი</SelectItem>
                        </SelectContent>
                      </Select>
                    </CardContent>
                  </Card>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Add Candidate Dialog */}
      <AddCandidateDialog
        open={showAddCandidateDialog}
        onOpenChange={setShowAddCandidateDialog}
        vacancies={vacancies}
        onSuccess={fetchCandidates}
      />
    </div>
  );
}