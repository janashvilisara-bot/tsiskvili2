import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Clock, TrendingUp, DollarSign, Download, Calendar, Filter, Users, Info } from "lucide-react";
import { ReportPageShell } from "@/components/reports/ReportPageShell";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ResponsiveTable, MobileCard, MobileCardRow } from "@/components/ResponsiveTable";
import { useIsMobile } from "@/hooks/use-mobile";
import { exportToExcel } from "@/lib/exportToExcel";
import { format, startOfMonth, endOfMonth } from "date-fns";
import { ka } from "date-fns/locale";
import { useBranchFilter } from "@/hooks/useBranchFilter";


interface OvertimeStats {
  employee_id: string;
  employee_name: string;
  department: string;
  position: string;
  hourly_rate: number;
  total_hours: number;
  weekday_hours: number;
  weekend_hours: number;
  holiday_hours: number;
  total_cost: number;
  approved_count: number;
  pending_count: number;
}

interface MonthlyStats {
  total_hours: number;
  total_cost: number;
  total_employees: number;
  weekday_hours: number;
  weekend_hours: number;
  holiday_hours: number;
}

export default function OvertimeReports() {
  const [overtimeStats, setOvertimeStats] = useState<OvertimeStats[]>([]);
  const [monthlyStats, setMonthlyStats] = useState<MonthlyStats>({
    total_hours: 0,
    total_cost: 0,
    total_employees: 0,
    weekday_hours: 0,
    weekend_hours: 0,
    holiday_hours: 0,
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [departments, setDepartments] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), 'yyyy-MM'));
  const isMobile = useIsMobile();
  const branchId = useBranchFilter();

  // Overtime multipliers
  const MULTIPLIERS = {
    weekday: 1.5,
    weekend: 2.0,
    holiday: 2.5,
  };

  useEffect(() => {
    fetchDepartments();
    fetchOvertimeStats();
  }, [selectedMonth, branchId]);


  const fetchDepartments = async () => {
    try {
      const { data, error } = await supabase
        .from('departments')
        .select('name')
        .eq('is_active', true);

      if (error) throw error;
      setDepartments(data?.map(d => d.name) || []);
    } catch (error: any) {
      console.error('Error fetching departments:', error);
    }
  };

  const fetchOvertimeStats = async () => {
    try {
      setIsLoading(true);
      
      const monthStart = startOfMonth(new Date(selectedMonth + '-01'));
      const monthEnd = endOfMonth(new Date(selectedMonth + '-01'));

      // Fetch approved overtime requests with employee data
      let overtimeQuery = supabase
        .from('overtime_requests' as any)
        .select(`
          *,
          employees:employee_id (
            full_name,
            department,
            position,
            salary
          )
        `)
        .eq('status', 'approved')
        .gte('work_date', format(monthStart, 'yyyy-MM-dd'))
        .lte('work_date', format(monthEnd, 'yyyy-MM-dd'));

      if (branchId) overtimeQuery = overtimeQuery.eq('branch_id', branchId);

      const { data: overtimeData, error: overtimeError } = await overtimeQuery;

      if (overtimeError) throw overtimeError;


      // Group by employee
      const employeeMap = new Map<string, OvertimeStats>();

      (overtimeData || []).forEach((record: any) => {
        const employeeId = record.employee_id;
        const employeeName = record.employees?.full_name || 'უცნობი';
        const department = record.employees?.department || 'უცნობი';
        const position = record.employees?.position || 'უცნობი';
        const monthlySalary = record.employees?.salary || 0;
        
        // Calculate hourly rate (assuming 160 work hours per month)
        const hourlyRate = monthlySalary / 160;
        
        if (!employeeMap.has(employeeId)) {
          employeeMap.set(employeeId, {
            employee_id: employeeId,
            employee_name: employeeName,
            department: department,
            position: position,
            hourly_rate: hourlyRate,
            total_hours: 0,
            weekday_hours: 0,
            weekend_hours: 0,
            holiday_hours: 0,
            total_cost: 0,
            approved_count: 0,
            pending_count: 0,
          });
        }

        const stats = employeeMap.get(employeeId)!;
        const hours = record.hours || 0;
        const type = record.overtime_type;

        stats.total_hours += hours;
        stats.approved_count += 1;

        if (type === 'weekday') {
          stats.weekday_hours += hours;
          stats.total_cost += hours * hourlyRate * MULTIPLIERS.weekday;
        } else if (type === 'weekend') {
          stats.weekend_hours += hours;
          stats.total_cost += hours * hourlyRate * MULTIPLIERS.weekend;
        } else if (type === 'holiday') {
          stats.holiday_hours += hours;
          stats.total_cost += hours * hourlyRate * MULTIPLIERS.holiday;
        }
      });

      const statsArray = Array.from(employeeMap.values());
      setOvertimeStats(statsArray);

      // Calculate monthly totals
      const monthlyTotals = statsArray.reduce((acc, stat) => ({
        total_hours: acc.total_hours + stat.total_hours,
        total_cost: acc.total_cost + stat.total_cost,
        total_employees: acc.total_employees + 1,
        weekday_hours: acc.weekday_hours + stat.weekday_hours,
        weekend_hours: acc.weekend_hours + stat.weekend_hours,
        holiday_hours: acc.holiday_hours + stat.holiday_hours,
      }), {
        total_hours: 0,
        total_cost: 0,
        total_employees: 0,
        weekday_hours: 0,
        weekend_hours: 0,
        holiday_hours: 0,
      });

      setMonthlyStats(monthlyTotals);
    } catch (error: any) {
      console.error('Error fetching overtime stats:', error);
      toast.error('ზეგანაკვეთური სტატისტიკის ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleExport = () => {
    const exportData = filteredStats.map(stat => ({
      'თანამშრომელი': stat.employee_name,
      'დეპარტამენტი': stat.department,
      'პოზიცია': stat.position,
      'საათობრივი განაკვეთი (₾)': stat.hourly_rate.toFixed(2),
      'სულ საათები': stat.total_hours.toFixed(2),
      'სამუშაო დღე (საათები)': stat.weekday_hours.toFixed(2),
      'შაბათ-კვირა (საათები)': stat.weekend_hours.toFixed(2),
      'უქმე დღე (საათები)': stat.holiday_hours.toFixed(2),
      'სულ ღირებულება (₾)': stat.total_cost.toFixed(2),
      'დამტკიცებული მოთხოვნები': stat.approved_count,
    }));

    exportToExcel(exportData, `ზეგანაკვეთური_ანგარიში_${selectedMonth}`);
    toast.success('ანგარიში ექსპორტირებულია');
  };

  const filteredStats = overtimeStats.filter(stat => {
    const matchesSearch = 
      stat.employee_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      stat.department.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDepartment = departmentFilter === 'all' || stat.department === departmentFilter;

    return matchesSearch && matchesDepartment;
  });

  return (
    <ReportPageShell
      title="ზეგანაკვეთური სამუშაოს ანგარიში"
      description="დეტალური სტატისტიკა და ფინანსური ანალიზი"
      icon={Clock}
      gradient="from-orange-400 via-amber-500 to-yellow-500"
      shadow="shadow-orange-500/30"
      actions={
        <Button onClick={handleExport} size="lg" className="bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 shadow-lg">
          <Download className="mr-2 h-4 w-4" />
          ექსპორტი
        </Button>
      }
    >

      {/* Info Banner */}
      <Alert className="border-orange-200 bg-orange-50">
        <Info className="h-4 w-4 text-orange-600" />
        <AlertTitle className="text-orange-900">ზეგანაკვეთური სამუშაოს ანგარიში</AlertTitle>
        <AlertDescription className="text-orange-800">
          ეს გვერდი აჩვენებს <strong>მხოლოდ ზეგანაკვეთურ საათებს</strong> (overtime_requests ცხრილიდან) - კვირის დღე (1.5x), შაბათ-კვირა (2.0x), უქმე დღე (2.5x). 
          სრული სამუშაო დროის აღრიცხვისთვის იხილეთ{" "}
          <Link to="/work-time-tracking" className="underline font-semibold">სამუშაო დროის აღრიცხვა</Link>.
        </AlertDescription>
      </Alert>

      {/* Month Selector */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            პერიოდის არჩევა
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="max-w-xs"
          />
        </CardContent>
      </Card>

      {/* Summary Statistics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">სულ თანამშრომელი</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{monthlyStats.total_employees}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">სულ საათები</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{monthlyStats.total_hours.toFixed(1)} სთ</div>
            <div className="text-xs text-muted-foreground mt-2">
              სამუშაო: {monthlyStats.weekday_hours.toFixed(1)} | 
              შაბ-კვირა: {monthlyStats.weekend_hours.toFixed(1)} | 
              უქმე: {monthlyStats.holiday_hours.toFixed(1)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">სულ ღირებულება</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {monthlyStats.total_cost.toFixed(2)} ₾
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">საშუალო საათი</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {monthlyStats.total_employees > 0 
                ? (monthlyStats.total_hours / monthlyStats.total_employees).toFixed(1)
                : 0
              } სთ
            </div>
            <p className="text-xs text-muted-foreground mt-1">თანამშრომელზე</p>
          </CardContent>
        </Card>
      </div>

      {/* Type Distribution */}
      <Card>
        <CardHeader>
          <CardTitle>ზეგანაკვეთურის განაწილება ტიპის მიხედვით</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">სამუშაო დღე (x1.5)</span>
                <span className="text-sm text-muted-foreground">
                  {monthlyStats.weekday_hours.toFixed(1)} სთ
                </span>
              </div>
              <Progress 
                value={monthlyStats.total_hours > 0 
                  ? (monthlyStats.weekday_hours / monthlyStats.total_hours) * 100 
                  : 0
                }
                className="h-2"
              />
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">შაბათ-კვირა (x2.0)</span>
                <span className="text-sm text-muted-foreground">
                  {monthlyStats.weekend_hours.toFixed(1)} სთ
                </span>
              </div>
              <Progress 
                value={monthlyStats.total_hours > 0 
                  ? (monthlyStats.weekend_hours / monthlyStats.total_hours) * 100 
                  : 0
                }
                className="h-2"
              />
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">უქმე დღე (x2.5)</span>
                <span className="text-sm text-muted-foreground">
                  {monthlyStats.holiday_hours.toFixed(1)} სთ
                </span>
              </div>
              <Progress 
                value={monthlyStats.total_hours > 0 
                  ? (monthlyStats.holiday_hours / monthlyStats.total_hours) * 100 
                  : 0
                }
                className="h-2"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            ფილტრები
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <Input
              placeholder="ძიება თანამშრომლის ან დეპარტამენტის მიხედვით..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger>
                <SelectValue placeholder="დეპარტამენტი" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                {departments.map((dept) => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Employee Details Table */}
      <Card>
        <CardHeader>
          <CardTitle>თანამშრომლების დეტალური ინფორმაცია</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveTable
            data={filteredStats}
            mobileCards={(stat: OvertimeStats) => (
              <MobileCard key={stat.employee_id}>
                <MobileCardRow label="თანამშრომელი" value={stat.employee_name} />
                <MobileCardRow label="დეპარტამენტი" value={stat.department} />
                <MobileCardRow label="პოზიცია" value={stat.position} />
                <MobileCardRow label="საათობრივი განაკვეთი" value={`${stat.hourly_rate.toFixed(2)} ₾`} />
                <MobileCardRow label="სულ საათები" value={`${stat.total_hours.toFixed(1)} სთ`} />
                <MobileCardRow 
                  label="განაწილება" 
                  value={
                    <div className="text-xs space-y-1">
                      <div>სამუშაო: {stat.weekday_hours.toFixed(1)} სთ</div>
                      <div>შაბ-კვირა: {stat.weekend_hours.toFixed(1)} სთ</div>
                      <div>უქმე: {stat.holiday_hours.toFixed(1)} სთ</div>
                    </div>
                  } 
                />
                <MobileCardRow 
                  label="ღირებულება" 
                  value={<Badge variant="default">{stat.total_cost.toFixed(2)} ₾</Badge>} 
                />
              </MobileCard>
            )}
          >
            <TableHeader>
              <TableRow>
                <TableHead>თანამშრომელი</TableHead>
                <TableHead>დეპარტამენტი</TableHead>
                <TableHead>საათობრივი განაკვეთი</TableHead>
                <TableHead>სულ საათები</TableHead>
                <TableHead>სამუშაო დღე</TableHead>
                <TableHead>შაბათ-კვირა</TableHead>
                <TableHead>უქმე დღე</TableHead>
                <TableHead>სულ ღირებულება</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center">
                    იტვირთება...
                  </TableCell>
                </TableRow>
              ) : filteredStats.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center text-muted-foreground">
                    მონაცემები არ მოიძებნა
                  </TableCell>
                </TableRow>
              ) : (
                filteredStats.map((stat) => (
                  <TableRow key={stat.employee_id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{stat.employee_name}</div>
                        <div className="text-sm text-muted-foreground">{stat.position}</div>
                      </div>
                    </TableCell>
                    <TableCell>{stat.department}</TableCell>
                    <TableCell>{stat.hourly_rate.toFixed(2)} ₾</TableCell>
                    <TableCell className="font-medium">{stat.total_hours.toFixed(1)} სთ</TableCell>
                    <TableCell>{stat.weekday_hours.toFixed(1)} სთ</TableCell>
                    <TableCell>{stat.weekend_hours.toFixed(1)} სთ</TableCell>
                    <TableCell>{stat.holiday_hours.toFixed(1)} სთ</TableCell>
                    <TableCell>
                      <Badge variant="default" className="font-semibold">
                        {stat.total_cost.toFixed(2)} ₾
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </ResponsiveTable>
        </CardContent>
      </Card>
    </ReportPageShell>
  );
}
