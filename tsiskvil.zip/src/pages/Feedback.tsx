import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { MessageSquare, Lightbulb, AlertCircle, Loader2, Brain } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface Feedback {
  id: string;
  employee_id: string | null;
  is_anonymous: boolean;
  type: "complaint" | "concern" | "idea";
  subject: string;
  description: string;
  status: "pending" | "in_review" | "resolved" | "dismissed";
  ai_recommendation: string | null;
  manager_notes: string | null;
  hr_notes: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
  employees?: {
    full_name: string;
  };
}

const Feedback = () => {
  const { userRole } = useAuth();
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [generatingAI, setGeneratingAI] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    type: "idea" as "complaint" | "concern" | "idea",
    subject: "",
    description: "",
    is_anonymous: false,
  });

  const canManage = userRole === "admin" || userRole === "hr_manager";

  useEffect(() => {
    fetchFeedbacks();
    
    const channel = supabase
      .channel('employee_feedback_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'employee_feedback' },
        () => fetchFeedbacks()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchFeedbacks = async () => {
    try {
      const { data, error } = await supabase
        .from('employee_feedback')
        .select(`
          *,
          employees (
            full_name
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setFeedbacks(data || []);
    } catch (error: any) {
      console.error('Error fetching feedbacks:', error);
      toast.error('ჩატვირთვის შეცდომა');
    } finally {
      setLoading(false);
    }
  };

  const generateAIRecommendation = async (feedback: Feedback) => {
    setGeneratingAI(feedback.id);
    try {
      const response = await supabase.functions.invoke('ai-feedback-recommendation', {
        body: {
          feedbackType: feedback.type,
          subject: feedback.subject,
          description: feedback.description,
        }
      });

      if (response.error) {
        console.error('Function error:', response.error);
        throw new Error(response.error.message || 'AI რეკომენდაციის გენერირება ვერ მოხერხდა');
      }

      if (!response.data) {
        throw new Error('პასუხი არ მოიძებნა');
      }

      const { recommendation, error } = response.data;
      
      if (error) {
        if (error.includes('Rate limits exceeded')) {
          toast.error('ბევრი მოთხოვნა გაიგზავნა. გთხოვთ სცადოთ ცოტა ხანში.');
        } else if (error.includes('Payment required')) {
          toast.error('საჭიროა კრედიტების დამატება. გთხოვთ დაუკავშირდეთ ადმინისტრატორს.');
        } else {
          toast.error(error);
        }
        return;
      }

      if (!recommendation) {
        throw new Error('რეკომენდაცია ვერ მოიძებნა');
      }

      const { error: updateError } = await supabase
        .from('employee_feedback')
        .update({ ai_recommendation: recommendation })
        .eq('id', feedback.id);

      if (updateError) throw updateError;

      toast.success('AI რეკომენდაცია წარმატებით გენერირებულია');
      await fetchFeedbacks();
    } catch (error: any) {
      console.error('Error generating AI recommendation:', error);
      toast.error(error.message || 'AI რეკომენდაციის შეცდომა');
    } finally {
      setGeneratingAI(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      let employeeId = null;
      if (!formData.is_anonymous) {
        const { data: employee } = await supabase
          .from('employees')
          .select('id')
          .eq('email', user.email)
          .single();
        employeeId = employee?.id;
      }

      const { error } = await supabase
        .from('employee_feedback')
        .insert([{
          employee_id: employeeId,
          is_anonymous: formData.is_anonymous,
          type: formData.type,
          subject: formData.subject,
          description: formData.description,
        }]);

      if (error) throw error;

      toast.success('უკუკავშირი წარმატებით გაიგზავნა');
      setFormData({
        type: "idea",
        subject: "",
        description: "",
        is_anonymous: false,
      });
    } catch (error: any) {
      console.error('Error submitting feedback:', error);
      toast.error('გაგზავნის შეცდომა');
    } finally {
      setIsSubmitting(false);
    }
  };

  const updateStatus = async (id: string, status: Feedback['status']) => {
    try {
      const { error } = await supabase
        .from('employee_feedback')
        .update({ 
          status,
          reviewed_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;
      toast.success('სტატუსი განახლდა');
    } catch (error: any) {
      toast.error('სტატუსის განახლების შეცდომა');
    }
  };

  const updateNotes = async (id: string, field: 'manager_notes' | 'hr_notes', value: string) => {
    try {
      const patch: Partial<{ manager_notes: string; hr_notes: string }> = {};
      patch[field] = value;
      const { error } = await supabase
        .from('employee_feedback')
        .update(patch)
        .eq('id', id);

      if (error) throw error;
      toast.success('შენიშვნა შენახულია');
    } catch (error: any) {
      toast.error('შენახვის შეცდომა');
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'complaint': return <AlertCircle className="h-5 w-5 text-destructive" />;
      case 'concern': return <MessageSquare className="h-5 w-5 text-warning" />;
      case 'idea': return <Lightbulb className="h-5 w-5 text-primary" />;
      default: return <MessageSquare className="h-5 w-5" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'complaint': return 'საჩივარი';
      case 'concern': return 'წუხილი';
      case 'idea': return 'იდეა';
      default: return type;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending': return 'მოლოდინში';
      case 'in_review': return 'განხილვაში';
      case 'resolved': return 'გადაწყვეტილი';
      case 'dismissed': return 'უარყოფილი';
      default: return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500';
      case 'in_review': return 'bg-blue-500';
      case 'resolved': return 'bg-green-500';
      case 'dismissed': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  if (loading) {
    return (
      <>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </>
    );
  }

  return (
    <>
      <div className="container mx-auto p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">წუწუნის დაფა</h1>
          <p className="text-muted-foreground">გააზიარეთ თქვენი შენიშვნები, იდეები და საჩივრები</p>
        </div>

        <Tabs defaultValue="create" className="space-y-6">
          <TabsList>
            <TabsTrigger value="create">ახალი უკუკავშირი</TabsTrigger>
            <TabsTrigger value="view">ყველა უკუკავშირი</TabsTrigger>
          </TabsList>

          <TabsContent value="create">
            <Card>
              <CardHeader>
                <CardTitle>შექმენით უკუკავშირი</CardTitle>
                <CardDescription>გააზიარეთ თქვენი აზრი, იდეა ან საჩივარი</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">ტიპი</Label>
                    <Select
                      value={formData.type}
                      onValueChange={(value: any) => setFormData({ ...formData, type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="idea">💡 იდეა</SelectItem>
                        <SelectItem value="concern">💬 წუხილი</SelectItem>
                        <SelectItem value="complaint">⚠️ საჩივარი</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject">თემა</Label>
                    <Input
                      id="subject"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">აღწერა</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      rows={5}
                      required
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      id="anonymous"
                      checked={formData.is_anonymous}
                      onCheckedChange={(checked) => setFormData({ ...formData, is_anonymous: checked })}
                    />
                    <Label htmlFor="anonymous">ანონიმური გაგზავნა</Label>
                  </div>

                  <Button type="submit" disabled={isSubmitting} className="w-full">
                    {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                    გაგზავნა
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="view">
            <div className="grid gap-4">
              {feedbacks.length === 0 ? (
                <Card>
                  <CardContent className="flex items-center justify-center h-32">
                    <p className="text-muted-foreground">უკუკავშირი არ არის</p>
                  </CardContent>
                </Card>
              ) : (
                feedbacks.map((feedback) => (
                  <Card key={feedback.id}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          {getTypeIcon(feedback.type)}
                          <div>
                            <CardTitle className="text-lg">{feedback.subject}</CardTitle>
                            <CardDescription>
                              {feedback.is_anonymous ? 'ანონიმური' : feedback.employees?.full_name || 'უცნობი'}
                              {' • '}
                              {new Date(feedback.created_at).toLocaleDateString('ka-GE')}
                            </CardDescription>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">{getTypeLabel(feedback.type)}</Badge>
                          <Badge className={getStatusColor(feedback.status)}>
                            {getStatusLabel(feedback.status)}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm">{feedback.description}</p>

                      {feedback.ai_recommendation && (
                        <div className="bg-muted p-4 rounded-lg space-y-2">
                          <div className="flex items-center gap-2 font-semibold">
                            <Brain className="h-4 w-4" />
                            AI რეკომენდაცია
                          </div>
                          <p className="text-sm whitespace-pre-wrap">{feedback.ai_recommendation}</p>
                        </div>
                      )}

                      {canManage && (
                        <div className="space-y-4 border-t pt-4">
                          {!feedback.ai_recommendation && (
                            <Button
                              onClick={() => generateAIRecommendation(feedback)}
                              disabled={generatingAI === feedback.id}
                              variant="outline"
                              size="sm"
                            >
                              {generatingAI === feedback.id ? (
                                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                              ) : (
                                <Brain className="h-4 w-4 mr-2" />
                              )}
                              AI რეკომენდაციის გენერირება
                            </Button>
                          )}

                          <div className="space-y-2">
                            <Label>სტატუსი</Label>
                            <Select
                              value={feedback.status}
                              onValueChange={(value: any) => updateStatus(feedback.id, value)}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pending">მოლოდინში</SelectItem>
                                <SelectItem value="in_review">განხილვაში</SelectItem>
                                <SelectItem value="resolved">გადაწყვეტილი</SelectItem>
                                <SelectItem value="dismissed">უარყოფილი</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label>HR შენიშვნა</Label>
                            <Textarea
                              defaultValue={feedback.hr_notes || ''}
                              onBlur={(e) => updateNotes(feedback.id, 'hr_notes', e.target.value)}
                              rows={3}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label>მენეჯერის შენიშვნა</Label>
                            <Textarea
                              defaultValue={feedback.manager_notes || ''}
                              onBlur={(e) => updateNotes(feedback.id, 'manager_notes', e.target.value)}
                              rows={3}
                            />
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default Feedback;