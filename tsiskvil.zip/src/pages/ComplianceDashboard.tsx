import { useState, useMemo } from "react";
import { format, startOfMonth, endOfMonth, subMonths } from "date-fns";
import { ka } from "date-fns/locale";
import {
  Shield,
  Clock,
  Calendar,
  Wallet,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Users,
  Info,
  ChevronDown,
  Timer,
  Baby,
  Moon,
  BedDouble,
  BarChart3,
  RefreshCcw,
  FileText,
  Stethoscope,
  HardHat,
  UserCheck,
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useWorkTimeData } from "@/hooks/useWorkTimeData";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import { supabase } from "@/integrations/supabase/client";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from "recharts";

export default function ComplianceDashboard() {
  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState(format(now, "yyyy-MM"));
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [expandedSection, setExpandedSection] = useState<string | null>("workHours");
  const [runningCheck, setRunningCheck] = useState(false);
  const [renewingId, setRenewingId] = useState<string | null>(null);
  const queryClient = useQueryClient();


  const monthStart = startOfMonth(new Date(selectedMonth + "-01"));
  const monthEnd = endOfMonth(monthStart);
  const startDate = format(monthStart, "yyyy-MM-dd");
  const endDate = format(monthEnd, "yyyy-MM-dd");

  const branchId = useBranchFilter();
  const { records, loading } = useWorkTimeData(startDate, endDate, selectedDepartment, "all", branchId);


  const { data: departments = [] } = useQuery({
    queryKey: ["departments-compliance"],
    queryFn: async () => {
      const { data } = await supabase.from("departments").select("id, name").order("name");
      return data || [];
    },
  });

  const { data: leaveRequests = [] } = useQuery({
    queryKey: ["leave-compliance", startDate, endDate],
    queryFn: async () => {
      const { data } = await supabase
        .from("leave_requests")
        .select("employee_id, start_date, end_date, leave_type, status")
        .eq("status", "approved")
        .gte("end_date", startDate)
        .lte("start_date", endDate);
      return data || [];
    },
  });

  const { data: pensionData = [] } = useQuery({
    queryKey: ["pension-compliance"],
    queryFn: async () => {
      const { data } = await supabase
        .from("employees")
        .select("id, full_name, salary, date_of_birth, gender, is_pension_payer, status")
        .eq("status", "active");
      return data || [];
    },
  });

  // Maternity/Paternity leave data
  const { data: maternityLeaves = [] } = useQuery({
    queryKey: ["maternity-compliance"],
    queryFn: async () => {
      const { data } = await supabase
        .from("leave_requests")
        .select("employee_id, start_date, end_date, leave_type, status, notes")
        .eq("status", "approved")
        .in("leave_type", ["maternity", "paternity", "parental"]);
      return data || [];
    },
  });

  // Attendance records for rest period analysis
  const { data: attendanceRecords = [] } = useQuery({
    queryKey: ["attendance-rest-period", startDate, endDate],
    queryFn: async () => {
      const { data } = await supabase
        .from("attendance")
        .select("employee_id, date, check_in, check_out")
        .gte("date", startDate)
        .lte("date", endDate)
        .is("deleted_at", null)
        .not("check_in", "is", null)
        .not("check_out", "is", null)
        .order("date", { ascending: true });
      return data || [];
    },
  });

  // Historical compliance snapshots
  const { data: snapshots = [], refetch: refetchSnapshots } = useQuery({
    queryKey: ["compliance-snapshots"],
    queryFn: async () => {
      const { data } = await supabase
        .from("compliance_snapshots")
        .select("*")
        .eq("department", "all")
        .order("snapshot_date", { ascending: true })
        .limit(12);
      return (data || []) as any[];
    },
  });

  // Contract compliance data
  const { data: contractsData = [] } = useQuery({
    queryKey: ["contracts-compliance"],
    queryFn: async () => {
      const { data } = await supabase
        .from("contracts")
        .select("id, employee_id, contract_type, start_date, end_date, status, signed_at, position, renewal_status, renewed_at, renewal_notes, employees(first_name, last_name)")
        .is("deleted_at", null)
        .in("status", ["active", "pending", "expired"]);
      return data || [];
    },
  });


  // Safety training records
  const { data: safetyTrainings = [] } = useQuery({
    queryKey: ["safety-training-compliance"],
    queryFn: async () => {
      const { data } = await supabase
        .from("safety_training_records")
        .select("id, employee_id, training_type, training_date, next_due_date, is_valid");
      return (data || []) as any[];
    },
  });

  // Medical checkups
  const { data: medicalCheckups = [] } = useQuery({
    queryKey: ["medical-checkups-compliance"],
    queryFn: async () => {
      const { data } = await supabase
        .from("medical_checkups")
        .select("id, employee_id, checkup_type, checkup_date, next_checkup_date, result, is_valid");
      return (data || []) as any[];
    },
  });

  const monthOptions = useMemo(() => {
    const options = [];
    for (let i = 0; i < 12; i++) {
      const d = subMonths(now, i);
      options.push({
        value: format(d, "yyyy-MM"),
        label: format(d, "MMMM yyyy", { locale: ka }),
      });
    }
    return options;
  }, []);

  // Rest period violations (11h between shifts, 24h weekly rest)
  const restPeriodAnalysis = useMemo(() => {
    const violations: Array<{
      employee_id: string;
      employee_name: string;
      type: "11h" | "24h";
      date1: string;
      date2: string;
      restHours: number;
    }> = [];

    // Group attendance by employee
    const byEmployee = new Map<string, any[]>();
    attendanceRecords.forEach((rec: any) => {
      const list = byEmployee.get(rec.employee_id) || [];
      list.push(rec);
      byEmployee.set(rec.employee_id, list);
    });

    byEmployee.forEach((recs, empId) => {
      const sorted = recs.sort(
        (a: any, b: any) => new Date(a.date).getTime() - new Date(b.date).getTime()
      );

      const emp = records.find((r) => r.employee_id === empId);
      const empName = emp?.employee_name || "Unknown";

      // Check 11h rest between consecutive shifts
      for (let i = 1; i < sorted.length; i++) {
        const prevCheckOut = new Date(sorted[i - 1].check_out);
        const currCheckIn = new Date(sorted[i].check_in);
        const restHours = (currCheckIn.getTime() - prevCheckOut.getTime()) / (1000 * 60 * 60);

        if (restHours >= 0 && restHours < 11) {
          violations.push({
            employee_id: empId,
            employee_name: empName,
            type: "11h",
            date1: sorted[i - 1].date,
            date2: sorted[i].date,
            restHours: Math.round(restHours * 10) / 10,
          });
        }
      }

      // Check 24h weekly rest (check if any 7-day window lacks a day off)
      const dates = sorted.map((r: any) => r.date);
      for (let i = 0; i <= dates.length - 7; i++) {
        const window = dates.slice(i, i + 7);
        if (window.length === 7) {
          // If 7 consecutive days all have attendance, potential violation
          const firstDate = new Date(window[0]);
          const lastDate = new Date(window[6]);
          const daySpan = (lastDate.getTime() - firstDate.getTime()) / (1000 * 60 * 60 * 24);
          if (daySpan <= 7) {
            violations.push({
              employee_id: empId,
              employee_name: empName,
              type: "24h",
              date1: window[0],
              date2: window[6],
              restHours: 0,
            });
            break; // One per employee
          }
        }
      }
    });

    return violations;
  }, [attendanceRecords, records]);

  // Maternity/Paternity leave analysis
  const maternityAnalysis = useMemo(() => {
    const byEmployee = new Map<
      string,
      { totalDays: number; paidDays: number; unpaidDays: number; leaves: any[] }
    >();

    maternityLeaves.forEach((lr: any) => {
      const days =
        Math.ceil(
          (new Date(lr.end_date).getTime() - new Date(lr.start_date).getTime()) /
            (1000 * 60 * 60 * 24)
        ) + 1;

      const existing = byEmployee.get(lr.employee_id) || {
        totalDays: 0,
        paidDays: 0,
        unpaidDays: 0,
        leaves: [],
      };
      existing.totalDays += days;
      existing.leaves.push(lr);
      byEmployee.set(lr.employee_id, existing);
    });

    // Calculate paid vs unpaid (first 183 days paid per Georgian law)
    byEmployee.forEach((data) => {
      data.paidDays = Math.min(data.totalDays, 183);
      data.unpaidDays = Math.max(0, data.totalDays - 183);
    });

    // Also use work time data for maternity info
    records.forEach((r) => {
      if (r.paid_maternity_leave_days > 0 || r.unpaid_maternity_leave_days > 0) {
        const existing = byEmployee.get(r.employee_id) || {
          totalDays: 0,
          paidDays: 0,
          unpaidDays: 0,
          leaves: [],
        };
        if (existing.totalDays === 0) {
          existing.paidDays = r.paid_maternity_leave_days;
          existing.unpaidDays = r.unpaid_maternity_leave_days;
          existing.totalDays = r.paid_maternity_leave_days + r.unpaid_maternity_leave_days;
          byEmployee.set(r.employee_id, existing);
        }
      }
    });

    return {
      employees: byEmployee,
      totalOnLeave: byEmployee.size,
      maxDays: 730,
      paidDays: 183,
    };
  }, [maternityLeaves, records]);

  // Minor employee analysis (under 18, 36h/week limit, no night work)
  const minorEmployeeAnalysis = useMemo(() => {
    const today = new Date();
    const minors = pensionData.filter((emp: any) => {
      if (!emp.date_of_birth) return false;
      const age = (today.getTime() - new Date(emp.date_of_birth).getTime()) / (1000 * 60 * 60 * 24 * 365.25);
      return age < 18;
    });

    const violations: Array<{ empId: string; empName: string; type: string; details: string }> = [];

    minors.forEach((minor: any) => {
      const rec = records.find((r) => r.employee_id === minor.id);
      if (!rec) return;

      const avgWeekly = (rec.regular_hours + rec.overtime_hours) / 4;
      if (avgWeekly > 36) {
        violations.push({
          empId: minor.id,
          empName: minor.full_name,
          type: "36h_limit",
          details: `კვირეული: ${avgWeekly.toFixed(1)} სთ (ლიმიტი: 36 სთ)`,
        });
      }
      if (rec.night_work_hours > 0) {
        violations.push({
          empId: minor.id,
          empName: minor.full_name,
          type: "night_ban",
          details: `ღამის სამუშაო: ${rec.night_work_hours.toFixed(1)} სთ (აკრძალულია)`,
        });
      }
    });

    return { minors, violations };
  }, [pensionData, records]);

  // Contract compliance analysis
  const contractAnalysis = useMemo(() => {
    const today = new Date();
    const notRenewed = (c: any) => c.renewal_status !== "renewed";
    const expired = contractsData.filter((c: any) => c.end_date && new Date(c.end_date) < today && c.status !== "expired" && notRenewed(c));
    const unsigned = contractsData.filter((c: any) => !c.signed_at && c.status === "active" && notRenewed(c));
    const expiringSoon = contractsData.filter((c: any) => {
      if (!c.end_date) return false;
      if (!notRenewed(c)) return false;
      const daysLeft = (new Date(c.end_date).getTime() - today.getTime()) / (1000 * 60 * 60 * 24);
      return daysLeft > 0 && daysLeft <= 60;
    });
    return { expired, unsigned, expiringSoon, total: contractsData.length };
  }, [contractsData]);

  const markContractRenewed = async (contractId: string, renewed: boolean) => {
    setRenewingId(contractId);
    try {
      const { data: userData } = await supabase.auth.getUser();
      const { error } = await supabase
        .from("contracts")
        .update({
          renewal_status: renewed ? "renewed" : "pending",
          renewed_at: renewed ? new Date().toISOString() : null,
          renewed_by: renewed ? userData.user?.id ?? null : null,
        })
        .eq("id", contractId);
      if (error) throw error;
      toast.success(renewed ? "მონიშნულია, როგორც განახლებული" : "სტატუსი დაბრუნდა");
      await queryClient.invalidateQueries({ queryKey: ["contracts-compliance"] });
    } catch (e: any) {
      toast.error(`ვერ მოხერხდა განახლება: ${e?.message || "უცნობი შეცდომა"}`);
    } finally {
      setRenewingId(null);
    }
  };



  // Safety training compliance
  const safetyAnalysis = useMemo(() => {
    const today = new Date();
    const employeesWithTraining = new Set(safetyTrainings.map((t: any) => t.employee_id));
    const employeesWithoutTraining = records.filter((r) => !employeesWithTraining.has(r.employee_id));
    const overdue = safetyTrainings.filter((t: any) => t.next_due_date && new Date(t.next_due_date) < today);
    const valid = safetyTrainings.filter((t: any) => t.is_valid);
    return { withoutTraining: employeesWithoutTraining, overdue, valid, total: safetyTrainings.length };
  }, [safetyTrainings, records]);

  // Medical checkup compliance
  const medicalAnalysis = useMemo(() => {
    const today = new Date();
    const employeesWithCheckup = new Set(medicalCheckups.map((c: any) => c.employee_id));
    const withoutCheckup = records.filter((r) => !employeesWithCheckup.has(r.employee_id));
    const overdue = medicalCheckups.filter((c: any) => c.next_checkup_date && new Date(c.next_checkup_date) < today);
    const valid = medicalCheckups.filter((c: any) => c.is_valid);
    const unfit = medicalCheckups.filter((c: any) => c.result === "unfit");
    return { withoutCheckup, overdue, valid, unfit, total: medicalCheckups.length };
  }, [medicalCheckups, records]);

  // Compliance calculations
  const compliance = useMemo(() => {
    const weeklyLimit = 40;
    const overtimeWeeklyLimit = 48;

    const workHourViolations = records.filter((r) => {
      const avgWeeklyHours = (r.regular_hours + r.overtime_hours) / 4;
      return avgWeeklyHours > weeklyLimit;
    });

    const overtimeLimitViolations = records.filter((r) => {
      const avgWeeklyTotal = (r.regular_hours + r.overtime_hours) / 4;
      return avgWeeklyTotal > overtimeWeeklyLimit;
    });

    const nightWorkers = records.filter((r) => r.night_work_hours > 0);

    const leaveByEmployee = new Map<string, number>();
    leaveRequests.forEach((lr: any) => {
      if (lr.leave_type === "annual") {
        const days =
          Math.ceil(
            (new Date(lr.end_date).getTime() - new Date(lr.start_date).getTime()) /
              (1000 * 60 * 60 * 24)
          ) + 1;
        leaveByEmployee.set(lr.employee_id, (leaveByEmployee.get(lr.employee_id) || 0) + days);
      }
    });

    const pensionEligible = pensionData.filter((emp: any) => {
      if (!emp.date_of_birth) return false;
      return new Date(emp.date_of_birth).getFullYear() >= 1984;
    });
    const pensionCompliant = pensionEligible.filter((emp: any) => emp.is_pension_payer);
    const pensionNonCompliant = pensionEligible.filter((emp: any) => !emp.is_pension_payer);

    const totalChecks = records.length + pensionEligible.length + records.length; // +rest period
    const violations =
      workHourViolations.length +
      pensionNonCompliant.length +
      restPeriodAnalysis.filter((v) => v.type === "11h").length;
    const score = totalChecks > 0 ? Math.round(((totalChecks - violations) / totalChecks) * 100) : 100;

    return {
      workHourViolations,
      overtimeLimitViolations,
      nightWorkers,
      leaveByEmployee,
      pensionEligible,
      pensionCompliant,
      pensionNonCompliant,
      score,
      totalEmployees: records.length,
    };
  }, [records, leaveRequests, pensionData, restPeriodAnalysis]);

  const runComplianceCheck = async () => {
    setRunningCheck(true);
    try {
      const { data, error } = await supabase.functions.invoke("compliance-check");
      if (error) throw error;
      toast.success(
        `შემოწმება დასრულდა: ${data.violations_count} დარღვევა აღმოჩნდა`
      );
      refetchSnapshots();
    } catch (e: any) {
      toast.error("შემოწმება ვერ მოხერხდა: " + (e.message || "Unknown error"));
    } finally {
      setRunningCheck(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-emerald-600 dark:text-emerald-400";
    if (score >= 70) return "text-amber-600 dark:text-amber-400";
    return "text-destructive";
  };

  const getScoreBg = (score: number) => {
    if (score >= 90) return "from-emerald-500/20 to-emerald-600/10";
    if (score >= 70) return "from-amber-500/20 to-amber-600/10";
    return "from-destructive/20 to-destructive/10";
  };

  // Trend chart data
  const trendData = useMemo(() => {
    return snapshots.map((s: any) => ({
      date: format(new Date(s.snapshot_date), "dd MMM", { locale: ka }),
      score: Number(s.overall_score),
      workHour: s.work_hour_violations,
      overtime: s.overtime_violations,
      rest: s.rest_period_violations,
    }));
  }, [snapshots]);

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-foreground flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-primary/10">
                  <Shield className="h-7 w-7 text-primary" />
                </div>
                შესაბამისობის დაშბორდი
              </h1>
              <p className="text-muted-foreground mt-1">
                საქართველოს შრომის კანონმდებლობასთან შესაბამისობის რეალურ დროში მონიტორინგი
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={runComplianceCheck}
                disabled={runningCheck}
              >
                <RefreshCcw className={cn("h-4 w-4 mr-2", runningCheck && "animate-spin")} />
                {runningCheck ? "მიმდინარეობს..." : "შემოწმება"}
              </Button>
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {monthOptions.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="ყველა დეპარტამენტი" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                  {departments.map((dept: any) => (
                    <SelectItem key={dept.id} value={dept.name}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Info Banner */}
          <Card className="border-primary/20 bg-gradient-to-r from-primary/5 to-accent/5">
            <CardContent className="p-4 flex items-start gap-3">
              <Info className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground">შესაბამისობის დაშბორდი</span> - აკონტროლებს
                საქართველოს შრომის კოდექსის ძირითად მოთხოვნებს: 40-საათიანი სამუშაო კვირა (მუხ. 14),
                ზეგანაკვეთური ≤48 სთ/კვირა, ცვლებს შორის 11სთ დასვენება (მუხ. 24),
                დედობის შვებულება 730 დღე / 183 ანაზღაურებადი, 24 დღე ყოველწლიური შვებულება (მუხ. 22),
                და საპენსიო ფონდის 2%+2% შენატანები.
              </div>
            </CardContent>
          </Card>

          {/* Overall Score + Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <Card className={cn("md:col-span-2 relative overflow-hidden border-border/40")}>
              <div className={cn("absolute inset-0 bg-gradient-to-br opacity-50", getScoreBg(compliance.score))} />
              <CardContent className="p-6 relative z-10 flex flex-col items-center justify-center text-center">
                <p className="text-sm font-medium text-muted-foreground mb-2">შესაბამისობის ქულა</p>
                <div className={cn("text-6xl font-bold tracking-tight", getScoreColor(compliance.score))}>
                  {loading ? "-" : compliance.score}%
                </div>
                <div className="mt-3 w-full max-w-xs">
                  <Progress value={compliance.score} className="h-2" />
                </div>
                <p className="text-xs text-muted-foreground mt-3">
                  {compliance.score >= 90
                    ? "✅ სისტემა შესაბამისობაშია"
                    : compliance.score >= 70
                    ? "⚠️ ნაწილობრივი შესაბამისობა"
                    : "🚨 საჭიროა დაუყოვნებელი ყურადღება"}
                </p>
              </CardContent>
            </Card>

            <StatMini
              icon={Clock}
              label="40 სთ/კვირა"
              value={compliance.workHourViolations.length}
              total={compliance.totalEmployees}
              status={compliance.workHourViolations.length === 0 ? "ok" : "warning"}
              description="დარღვევა"
            />
            <StatMini
              icon={BedDouble}
              label="11სთ დასვენება"
              value={restPeriodAnalysis.filter((v) => v.type === "11h").length}
              total={compliance.totalEmployees}
              status={restPeriodAnalysis.filter((v) => v.type === "11h").length === 0 ? "ok" : "danger"}
              description="დარღვევა"
            />
            <StatMini
              icon={Baby}
              label="დედობის შვებულება"
              value={maternityAnalysis.totalOnLeave}
              total={compliance.totalEmployees}
              status="ok"
              description="შვებულებაზე"
            />
            <StatMini
              icon={Wallet}
              label="საპენსიო 2%+2%"
              value={compliance.pensionNonCompliant.length}
              total={compliance.pensionEligible.length}
              status={compliance.pensionNonCompliant.length === 0 ? "ok" : "danger"}
              description="შეუსაბამო"
            />
          </div>

          {/* Historical Trends */}
          {trendData.length > 1 && (
            <Card className="border-border/40 bg-card">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <BarChart3 className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-base">შესაბამისობის ტრენდი</CardTitle>
                    <CardDescription className="text-xs">ისტორიული compliance score დინამიკა</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={trendData}>
                      <defs>
                        <linearGradient id="scoreGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                      <XAxis dataKey="date" className="text-xs" tick={{ fill: "hsl(var(--muted-foreground))" }} />
                      <YAxis domain={[0, 100]} className="text-xs" tick={{ fill: "hsl(var(--muted-foreground))" }} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          borderColor: "hsl(var(--border))",
                          borderRadius: "8px",
                        }}
                        labelStyle={{ color: "hsl(var(--foreground))" }}
                      />
                      <Area
                        type="monotone"
                        dataKey="score"
                        stroke="hsl(var(--primary))"
                        fill="url(#scoreGradient)"
                        strokeWidth={2}
                        name="შესაბამისობა %"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-6 mt-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1.5">
                    <span className="w-3 h-0.5 rounded bg-primary inline-block" /> შესაბამისობის ქულა
                  </span>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Detailed Sections */}
          <div className="space-y-4">
            {/* Work Hours Section */}
            <ComplianceSection
              id="workHours"
              title="სამუშაო საათების კონტროლი"
              subtitle="შრომის კოდექსის მუხ. 14 - მაქსიმუმ 40 საათი კვირაში"
              icon={Clock}
              expanded={expandedSection === "workHours"}
              onToggle={() => setExpandedSection(expandedSection === "workHours" ? null : "workHours")}
              status={compliance.workHourViolations.length === 0 ? "ok" : "warning"}
              violationCount={compliance.workHourViolations.length}
            >
              {compliance.workHourViolations.length === 0 ? (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="h-5 w-5" />
                  <span>ყველა თანამშრომელი შესაბამისობაშია - 40-საათიანი ლიმიტი არ არის დარღვეული</span>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>პოზიცია</TableHead>
                      <TableHead>რეგულარული სთ</TableHead>
                      <TableHead>ზეგანაკვეთური სთ</TableHead>
                      <TableHead>საშ. კვირაში</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {compliance.workHourViolations.map((r) => {
                      const avgWeekly = ((r.regular_hours + r.overtime_hours) / 4).toFixed(1);
                      return (
                        <TableRow key={r.employee_id}>
                          <TableCell className="font-medium">{r.employee_name}</TableCell>
                          <TableCell className="text-muted-foreground">{r.position}</TableCell>
                          <TableCell>{r.regular_hours.toFixed(1)}</TableCell>
                          <TableCell>{r.overtime_hours.toFixed(1)}</TableCell>
                          <TableCell className="font-semibold text-destructive">{avgWeekly} სთ</TableCell>
                          <TableCell>
                            <Badge variant="destructive" className="text-xs">
                              <AlertTriangle className="h-3 w-3 mr-1" /> დარღვევა
                            </Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}

              {compliance.nightWorkers.length > 0 && (
                <div className="mt-4">
                  <h4 className="text-sm font-semibold text-foreground mb-2 flex items-center gap-2">
                    <Moon className="h-4 w-4 text-primary" />
                    ღამის სამუშაო (22:00–06:00) - {compliance.nightWorkers.length} თანამშრომელი
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {compliance.nightWorkers.slice(0, 6).map((r) => (
                      <div key={r.employee_id} className="p-3 rounded-lg border border-border/40 bg-card">
                        <p className="text-sm font-medium text-foreground">{r.employee_name}</p>
                        <p className="text-xs text-muted-foreground">{r.position}</p>
                        <p className="text-sm font-semibold text-primary mt-1">
                          {r.night_work_hours.toFixed(1)} სთ ღამის
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </ComplianceSection>

            {/* Rest Period Section */}
            <ComplianceSection
              id="restPeriod"
              title="დასვენების პერიოდის მონიტორინგი"
              subtitle="შრომის კოდექსის მუხ. 24 - ცვლებს შორის მინ. 11 სთ, კვირაში მინ. 24 სთ"
              icon={BedDouble}
              expanded={expandedSection === "restPeriod"}
              onToggle={() => setExpandedSection(expandedSection === "restPeriod" ? null : "restPeriod")}
              status={restPeriodAnalysis.length === 0 ? "ok" : "danger"}
              violationCount={restPeriodAnalysis.length}
            >
              {restPeriodAnalysis.length === 0 ? (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="h-5 w-5" />
                  <span>ყველა თანამშრომლის დასვენების პერიოდი შესაბამისობაშია</span>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="p-4 rounded-lg bg-destructive/5 border border-destructive/10">
                      <p className="text-xs text-muted-foreground">11 სთ ცვლებს შორის</p>
                      <p className="text-2xl font-bold text-destructive">
                        {restPeriodAnalysis.filter((v) => v.type === "11h").length}
                      </p>
                      <p className="text-xs text-muted-foreground">დარღვევა</p>
                    </div>
                    <div className="p-4 rounded-lg bg-amber-500/5 border border-amber-500/10">
                      <p className="text-xs text-muted-foreground">24 სთ კვირეული</p>
                      <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">
                        {restPeriodAnalysis.filter((v) => v.type === "24h").length}
                      </p>
                      <p className="text-xs text-muted-foreground">დარღვევა</p>
                    </div>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>თანამშრომელი</TableHead>
                        <TableHead>ტიპი</TableHead>
                        <TableHead>თარიღი 1</TableHead>
                        <TableHead>თარიღი 2</TableHead>
                        <TableHead>დასვენება</TableHead>
                        <TableHead>სტატუსი</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {restPeriodAnalysis.slice(0, 20).map((v, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="font-medium">{v.employee_name}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">
                              {v.type === "11h" ? "11სთ ცვლებს შორის" : "24სთ კვირეული"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-muted-foreground">{v.date1}</TableCell>
                          <TableCell className="text-muted-foreground">{v.date2}</TableCell>
                          <TableCell className="font-semibold text-destructive">
                            {v.type === "11h" ? `${v.restHours} სთ` : "არ არის"}
                          </TableCell>
                          <TableCell>
                            <Badge variant="destructive" className="text-xs">
                              <XCircle className="h-3 w-3 mr-1" /> დარღვევა
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </>
              )}
            </ComplianceSection>

            {/* Overtime Section */}
            <ComplianceSection
              id="overtime"
              title="ზეგანაკვეთური საათების კონტროლი"
              subtitle="შრომის კოდექსის მუხ. 17 - კვირაში ≤48 საათი ზეგანაკვეთურის ჩათვლით"
              icon={TrendingUp}
              expanded={expandedSection === "overtime"}
              onToggle={() => setExpandedSection(expandedSection === "overtime" ? null : "overtime")}
              status={compliance.overtimeLimitViolations.length === 0 ? "ok" : "danger"}
              violationCount={compliance.overtimeLimitViolations.length}
            >
              {compliance.overtimeLimitViolations.length === 0 ? (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="h-5 w-5" />
                  <span>ზეგანაკვეთური საათები ლიმიტის ფარგლებშია (≤48 სთ/კვირა)</span>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>დეპარტამენტი</TableHead>
                      <TableHead>სულ სთ (თვე)</TableHead>
                      <TableHead>საშ. კვირაში</TableHead>
                      <TableHead>ზეგანაკვეთური</TableHead>
                      <TableHead>რისკი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {compliance.overtimeLimitViolations.map((r) => {
                      const avgWeekly = ((r.regular_hours + r.overtime_hours) / 4).toFixed(1);
                      return (
                        <TableRow key={r.employee_id}>
                          <TableCell className="font-medium">{r.employee_name}</TableCell>
                          <TableCell className="text-muted-foreground">{r.department}</TableCell>
                          <TableCell>{(r.regular_hours + r.overtime_hours).toFixed(1)}</TableCell>
                          <TableCell className="font-semibold text-destructive">{avgWeekly} სთ</TableCell>
                          <TableCell>{r.overtime_hours.toFixed(1)} სთ</TableCell>
                          <TableCell>
                            <Badge variant="destructive" className="text-xs">კრიტიკული</Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </ComplianceSection>

            {/* Maternity/Paternity Leave Section */}
            <ComplianceSection
              id="maternity"
              title="დედობის / მამობის შვებულების ტრეკერი"
              subtitle="შრომის კოდექსი - 730 კალენდარული დღე, 183 დღე ანაზღაურებადი"
              icon={Baby}
              expanded={expandedSection === "maternity"}
              onToggle={() => setExpandedSection(expandedSection === "maternity" ? null : "maternity")}
              status="ok"
              violationCount={0}
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="p-4 rounded-lg bg-pink-500/5 border border-pink-500/10">
                  <p className="text-xs text-muted-foreground">შვებულებაზე მყოფი</p>
                  <p className="text-2xl font-bold text-foreground">{maternityAnalysis.totalOnLeave}</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <p className="text-xs text-muted-foreground">მაქს. დღეები</p>
                  <p className="text-2xl font-bold text-foreground">{maternityAnalysis.maxDays}</p>
                </div>
                <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                  <p className="text-xs text-muted-foreground">ანაზღაურებადი</p>
                  <p className="text-2xl font-bold text-emerald-600">{maternityAnalysis.paidDays} დღე</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/30 border border-border/40">
                  <p className="text-xs text-muted-foreground">არაანაზღაურებადი</p>
                  <p className="text-2xl font-bold text-foreground">{maternityAnalysis.maxDays - maternityAnalysis.paidDays} დღე</p>
                </div>
              </div>

              {maternityAnalysis.totalOnLeave === 0 ? (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/30 text-muted-foreground">
                  <Info className="h-5 w-5" />
                  <span>ამჟამად დედობის/მამობის შვებულებაზე მყოფი თანამშრომელი არ არის</span>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>სულ დღეები</TableHead>
                      <TableHead>ანაზღაურებადი</TableHead>
                      <TableHead>არაანაზღაურებადი</TableHead>
                      <TableHead>დარჩენილი</TableHead>
                      <TableHead>პროგრესი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Array.from(maternityAnalysis.employees.entries()).map(([empId, data]) => {
                      const emp = records.find((r) => r.employee_id === empId);
                      const remaining = 730 - data.totalDays;
                      const progress = Math.min(100, (data.totalDays / 730) * 100);
                      return (
                        <TableRow key={empId}>
                          <TableCell className="font-medium">
                            {emp?.employee_name || empId.slice(0, 8)}
                          </TableCell>
                          <TableCell>{data.totalDays}</TableCell>
                          <TableCell className="text-emerald-600 font-medium">{data.paidDays}</TableCell>
                          <TableCell className="text-muted-foreground">{data.unpaidDays}</TableCell>
                          <TableCell className={cn("font-semibold", remaining < 30 ? "text-amber-600" : "text-foreground")}>
                            {remaining} დღე
                          </TableCell>
                          <TableCell className="w-32">
                            <div className="flex items-center gap-2">
                              <Progress value={progress} className="h-2 flex-1" />
                              <span className="text-xs text-muted-foreground">{progress.toFixed(0)}%</span>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </ComplianceSection>

            {/* Leave Balance Section */}
            <ComplianceSection
              id="leave"
              title="შვებულებების ბალანსი"
              subtitle="შრომის კოდექსის მუხ. 22 - მინიმუმ 24 სამუშაო დღე წელიწადში"
              icon={Calendar}
              expanded={expandedSection === "leave"}
              onToggle={() => setExpandedSection(expandedSection === "leave" ? null : "leave")}
              status="ok"
              violationCount={0}
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <p className="text-xs text-muted-foreground">კანონით მინიმუმი</p>
                  <p className="text-2xl font-bold text-foreground">24 დღე</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <p className="text-xs text-muted-foreground">შვებულებით მოსარგებლე</p>
                  <p className="text-2xl font-bold text-foreground">{compliance.leaveByEmployee.size}</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <p className="text-xs text-muted-foreground">სულ თანამშრომელი</p>
                  <p className="text-2xl font-bold text-foreground">{records.length}</p>
                </div>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>თანამშრომელი</TableHead>
                    <TableHead>პოზიცია</TableHead>
                    <TableHead>გამოყენებული (დღე)</TableHead>
                    <TableHead>ბალანსი</TableHead>
                    <TableHead>სტატუსი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {records.slice(0, 20).map((r) => {
                    const used = compliance.leaveByEmployee.get(r.employee_id) || 0;
                    const remaining = 24 - used;
                    return (
                      <TableRow key={r.employee_id}>
                        <TableCell className="font-medium">{r.employee_name}</TableCell>
                        <TableCell className="text-muted-foreground">{r.position}</TableCell>
                        <TableCell>{used}</TableCell>
                        <TableCell className={cn("font-semibold", remaining <= 5 ? "text-amber-600" : "text-foreground")}>
                          {remaining} დღე
                        </TableCell>
                        <TableCell>
                          {remaining <= 0 ? (
                            <Badge variant="destructive" className="text-xs">ამოწურულია</Badge>
                          ) : remaining <= 5 ? (
                            <Badge variant="secondary" className="text-xs bg-amber-500/10 text-amber-700">ცოტაა</Badge>
                          ) : (
                            <Badge variant="secondary" className="text-xs bg-emerald-500/10 text-emerald-700">
                              <CheckCircle2 className="h-3 w-3 mr-1" /> ნორმა
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </ComplianceSection>

            {/* Pension Section */}
            <ComplianceSection
              id="pension"
              title="საპენსიო ფონდის შენატანები"
              subtitle="დაგროვებითი პენსია - 2% თანამშრომელი + 2% დამსაქმებელი (1984+ დაბადებულები)"
              icon={Wallet}
              expanded={expandedSection === "pension"}
              onToggle={() => setExpandedSection(expandedSection === "pension" ? null : "pension")}
              status={compliance.pensionNonCompliant.length === 0 ? "ok" : "danger"}
              violationCount={compliance.pensionNonCompliant.length}
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <p className="text-xs text-muted-foreground">სავალდებულო (1984+)</p>
                  <p className="text-2xl font-bold text-foreground">{compliance.pensionEligible.length}</p>
                </div>
                <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                  <p className="text-xs text-muted-foreground">შესაბამისი</p>
                  <p className="text-2xl font-bold text-emerald-600">{compliance.pensionCompliant.length}</p>
                </div>
                <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
                  <p className="text-xs text-muted-foreground">შეუსაბამო</p>
                  <p className="text-2xl font-bold text-destructive">{compliance.pensionNonCompliant.length}</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <p className="text-xs text-muted-foreground">შენატანის განაკვეთი</p>
                  <p className="text-2xl font-bold text-foreground">2% + 2%</p>
                </div>
              </div>

              {compliance.pensionNonCompliant.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>დაბადების წელი</TableHead>
                      <TableHead>ხელფასი</TableHead>
                      <TableHead>შენატანი (2%)</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {compliance.pensionNonCompliant.map((emp: any) => {
                      const birthYear = emp.date_of_birth ? new Date(emp.date_of_birth).getFullYear() : "-";
                      const contribution = emp.salary ? (emp.salary * 0.02).toFixed(2) : "-";
                      return (
                        <TableRow key={emp.id}>
                          <TableCell className="font-medium">{emp.full_name}</TableCell>
                          <TableCell>{birthYear}</TableCell>
                          <TableCell>{emp.salary ? `₾${emp.salary.toLocaleString()}` : "-"}</TableCell>
                          <TableCell className="text-primary font-medium">₾{contribution}</TableCell>
                          <TableCell>
                            <Badge variant="destructive" className="text-xs">
                              <XCircle className="h-3 w-3 mr-1" /> არ იხდის
                            </Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="h-5 w-5" />
                  <span>ყველა სავალდებულო თანამშრომელი იხდის საპენსიო შენატანს</span>
                </div>
              )}
            </ComplianceSection>

            {/* Minor Employees Section */}
            <ComplianceSection
              id="minors"
              title="არასრულწლოვანი თანამშრომლები"
              subtitle="შრომის კოდექსის მუხ. 74 - მაქს. 36 სთ/კვირა, ღამის სამუშაოს აკრძალვა"
              icon={UserCheck}
              expanded={expandedSection === "minors"}
              onToggle={() => setExpandedSection(expandedSection === "minors" ? null : "minors")}
              status={minorEmployeeAnalysis.violations.length === 0 ? "ok" : "danger"}
              violationCount={minorEmployeeAnalysis.violations.length}
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <p className="text-xs text-muted-foreground">არასრულწლოვანი</p>
                  <p className="text-2xl font-bold text-foreground">{minorEmployeeAnalysis.minors.length}</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <p className="text-xs text-muted-foreground">კვირეული ლიმიტი</p>
                  <p className="text-2xl font-bold text-foreground">36 სთ</p>
                </div>
                <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
                  <p className="text-xs text-muted-foreground">დარღვევები</p>
                  <p className="text-2xl font-bold text-destructive">{minorEmployeeAnalysis.violations.length}</p>
                </div>
              </div>
              {minorEmployeeAnalysis.minors.length === 0 ? (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/30 text-muted-foreground">
                  <Info className="h-5 w-5" />
                  <span>არასრულწლოვანი თანამშრომელი არ არის სისტემაში</span>
                </div>
              ) : minorEmployeeAnalysis.violations.length === 0 ? (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="h-5 w-5" />
                  <span>ყველა არასრულწლოვანი თანამშრომელი შესაბამისობაშია</span>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>დარღვევის ტიპი</TableHead>
                      <TableHead>დეტალები</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {minorEmployeeAnalysis.violations.map((v, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="font-medium">{v.empName}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs">
                            {v.type === "36h_limit" ? "36სთ ლიმიტი" : "ღამის აკრძალვა"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">{v.details}</TableCell>
                        <TableCell>
                          <Badge variant="destructive" className="text-xs">
                            <XCircle className="h-3 w-3 mr-1" /> დარღვევა
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </ComplianceSection>

            {/* Safety Training Section */}
            <ComplianceSection
              id="safety"
              title="შრომის უსაფრთხოების ინსტრუქტაჟი"
              subtitle="სავალდებულო ტრენინგების ჩატარების და ვადების კონტროლი"
              icon={HardHat}
              expanded={expandedSection === "safety"}
              onToggle={() => setExpandedSection(expandedSection === "safety" ? null : "safety")}
              status={safetyAnalysis.withoutTraining.length === 0 && safetyAnalysis.overdue.length === 0 ? "ok" : "warning"}
              violationCount={safetyAnalysis.withoutTraining.length + safetyAnalysis.overdue.length}
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <p className="text-xs text-muted-foreground">სულ ტრენინგი</p>
                  <p className="text-2xl font-bold text-foreground">{safetyAnalysis.total}</p>
                </div>
                <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                  <p className="text-xs text-muted-foreground">ვალიდური</p>
                  <p className="text-2xl font-bold text-emerald-600">{safetyAnalysis.valid.length}</p>
                </div>
                <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
                  <p className="text-xs text-muted-foreground">ვადაგასული</p>
                  <p className="text-2xl font-bold text-amber-600">{safetyAnalysis.overdue.length}</p>
                </div>
                <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
                  <p className="text-xs text-muted-foreground">ტრენინგის გარეშე</p>
                  <p className="text-2xl font-bold text-destructive">{safetyAnalysis.withoutTraining.length}</p>
                </div>
              </div>
              {safetyAnalysis.withoutTraining.length > 0 && (
                <div className="mb-4">
                  <h4 className="text-sm font-semibold text-foreground mb-2">ტრენინგის გარეშე მყოფი თანამშრომლები</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                    {safetyAnalysis.withoutTraining.slice(0, 9).map((r) => (
                      <div key={r.employee_id} className="p-2 rounded border border-destructive/20 bg-destructive/5 text-sm">
                        <span className="font-medium text-foreground">{r.employee_name}</span>
                        <span className="text-xs text-muted-foreground ml-2">{r.position}</span>
                      </div>
                    ))}
                  </div>
                  {safetyAnalysis.withoutTraining.length > 9 && (
                    <p className="text-xs text-muted-foreground mt-2">
                      +{safetyAnalysis.withoutTraining.length - 9} სხვა თანამშრომელი
                    </p>
                  )}
                </div>
              )}
              {safetyAnalysis.total === 0 && safetyAnalysis.withoutTraining.length === 0 && (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/30 text-muted-foreground">
                  <Info className="h-5 w-5" />
                  <span>შრომის უსაფრთხოების ტრენინგის ჩანაწერები ჯერ არ არის დამატებული</span>
                </div>
              )}
            </ComplianceSection>

            {/* Contract Compliance Section */}
            <ComplianceSection
              id="contracts"
              title="ხელშეკრულებების შესაბამისობა"
              subtitle="ვადაგასული, ხელმოუწერელი და მალე ამოწურვადი კონტრაქტები"
              icon={FileText}
              expanded={expandedSection === "contracts"}
              onToggle={() => setExpandedSection(expandedSection === "contracts" ? null : "contracts")}
              status={contractAnalysis.expired.length + contractAnalysis.unsigned.length === 0 ? "ok" : "warning"}
              violationCount={contractAnalysis.expired.length + contractAnalysis.unsigned.length}
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <p className="text-xs text-muted-foreground">სულ კონტრაქტი</p>
                  <p className="text-2xl font-bold text-foreground">{contractAnalysis.total}</p>
                </div>
                <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
                  <p className="text-xs text-muted-foreground">ვადაგასული</p>
                  <p className="text-2xl font-bold text-destructive">{contractAnalysis.expired.length}</p>
                </div>
                <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
                  <p className="text-xs text-muted-foreground">ხელმოუწერელი</p>
                  <p className="text-2xl font-bold text-amber-600">{contractAnalysis.unsigned.length}</p>
                </div>
                <div className="p-4 rounded-lg bg-amber-500/5 border border-amber-500/10">
                  <p className="text-xs text-muted-foreground">60 დღეში ამოიწურება</p>
                  <p className="text-2xl font-bold text-amber-600">{contractAnalysis.expiringSoon.length}</p>
                </div>
              </div>
              {contractAnalysis.expired.length === 0 && contractAnalysis.unsigned.length === 0 && contractAnalysis.expiringSoon.length === 0 ? (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="h-5 w-5" />
                  <span>ყველა კონტრაქტი შესაბამისობაშია</span>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>პოზიცია</TableHead>
                      <TableHead>ტიპი</TableHead>
                      <TableHead>ვადა</TableHead>
                      <TableHead>დარჩ. დღე</TableHead>
                      <TableHead>ხელმოწერა</TableHead>
                      <TableHead>სტატუსი</TableHead>
                      <TableHead className="text-right">მოქმედება</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[...contractAnalysis.expired, ...contractAnalysis.unsigned, ...contractAnalysis.expiringSoon]
                      .slice(0, 30)
                      .map((c: any) => {
                        const today = new Date();
                        const isExpired = c.end_date && new Date(c.end_date) < today;
                        const isUnsigned = !c.signed_at && c.status === "active";
                        const daysLeft = c.end_date
                          ? Math.ceil((new Date(c.end_date).getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
                          : null;
                        const employeeName = c.employees
                          ? `${c.employees.first_name ?? ""} ${c.employees.last_name ?? ""}`.trim()
                          : "-";
                        const isRenewed = c.renewal_status === "renewed";
                        return (
                          <TableRow key={c.id}>
                            <TableCell className="font-medium">{employeeName}</TableCell>
                            <TableCell className="text-muted-foreground">{c.position || "-"}</TableCell>
                            <TableCell className="text-muted-foreground">{c.contract_type}</TableCell>
                            <TableCell>{c.end_date || "უვადო"}</TableCell>
                            <TableCell>
                              {daysLeft === null ? "-" : daysLeft < 0 ? (
                                <span className="text-destructive font-medium">{daysLeft} დღე</span>
                              ) : (
                                <span className={daysLeft <= 30 ? "text-amber-600 font-medium" : "text-muted-foreground"}>
                                  {daysLeft} დღე
                                </span>
                              )}
                            </TableCell>
                            <TableCell>{c.signed_at ? "✅" : "❌"}</TableCell>
                            <TableCell>
                              {isRenewed ? (
                                <Badge variant="secondary" className="text-xs bg-emerald-500/10 text-emerald-700">განახლებულია</Badge>
                              ) : isExpired ? (
                                <Badge variant="destructive" className="text-xs">ვადაგასული</Badge>
                              ) : isUnsigned ? (
                                <Badge variant="secondary" className="text-xs bg-amber-500/10 text-amber-700">ხელმოუწერელი</Badge>
                              ) : (
                                <Badge variant="secondary" className="text-xs bg-amber-500/10 text-amber-700">მალე ამოიწურება</Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              {isRenewed ? (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  disabled={renewingId === c.id}
                                  onClick={() => markContractRenewed(c.id, false)}
                                >
                                  დააბრუნე
                                </Button>
                              ) : (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  disabled={renewingId === c.id}
                                  onClick={() => markContractRenewed(c.id, true)}
                                >
                                  <CheckCircle2 className="h-4 w-4 mr-1" />
                                  მონიშნე განახლებულად
                                </Button>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                  </TableBody>
                </Table>
              )}
            </ComplianceSection>


            {/* Medical Checkups Section */}
            <ComplianceSection
              id="medical"
              title="სამედიცინო შემოწმება"
              subtitle="პერიოდული ჯანმრთელობის შემოწმების ტრეკინგი და ვადების კონტროლი"
              icon={Stethoscope}
              expanded={expandedSection === "medical"}
              onToggle={() => setExpandedSection(expandedSection === "medical" ? null : "medical")}
              status={medicalAnalysis.overdue.length === 0 ? "ok" : "warning"}
              violationCount={medicalAnalysis.overdue.length + medicalAnalysis.unfit.length}
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                  <p className="text-xs text-muted-foreground">სულ შემოწმება</p>
                  <p className="text-2xl font-bold text-foreground">{medicalAnalysis.total}</p>
                </div>
                <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                  <p className="text-xs text-muted-foreground">ვალიდური</p>
                  <p className="text-2xl font-bold text-emerald-600">{medicalAnalysis.valid.length}</p>
                </div>
                <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
                  <p className="text-xs text-muted-foreground">ვადაგასული</p>
                  <p className="text-2xl font-bold text-amber-600">{medicalAnalysis.overdue.length}</p>
                </div>
                <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
                  <p className="text-xs text-muted-foreground">შემოწმების გარეშე</p>
                  <p className="text-2xl font-bold text-destructive">{medicalAnalysis.withoutCheckup.length}</p>
                </div>
              </div>
              {medicalAnalysis.total === 0 && medicalAnalysis.withoutCheckup.length === 0 ? (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/30 text-muted-foreground">
                  <Info className="h-5 w-5" />
                  <span>სამედიცინო შემოწმების ჩანაწერები ჯერ არ არის დამატებული</span>
                </div>
              ) : medicalAnalysis.withoutCheckup.length > 0 ? (
                <div>
                  <h4 className="text-sm font-semibold text-foreground mb-2">შემოწმების გარეშე მყოფი თანამშრომლები</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                    {medicalAnalysis.withoutCheckup.slice(0, 9).map((r) => (
                      <div key={r.employee_id} className="p-2 rounded border border-amber-500/20 bg-amber-500/5 text-sm">
                        <span className="font-medium text-foreground">{r.employee_name}</span>
                        <span className="text-xs text-muted-foreground ml-2">{r.department}</span>
                      </div>
                    ))}
                  </div>
                  {medicalAnalysis.withoutCheckup.length > 9 && (
                    <p className="text-xs text-muted-foreground mt-2">
                      +{medicalAnalysis.withoutCheckup.length - 9} სხვა თანამშრომელი
                    </p>
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-3 p-4 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="h-5 w-5" />
                  <span>ყველა სამედიცინო შემოწმება შესაბამისობაშია</span>
                </div>
              )}
            </ComplianceSection>
          </div>
          <Card className="border-border/40 bg-card/50">
            <CardContent className="p-4">
              <h3 className="text-sm font-semibold text-foreground mb-2">📚 სამართლებრივი ბაზა</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-xs text-muted-foreground">
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">მუხ. 14</span> - სამუშაო დრო: მაქს. 40 სთ/კვირა
                </div>
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">მუხ. 17</span> - ზეგანაკვეთური: მაქს. 48 სთ/კვირა
                </div>
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">მუხ. 22</span> - შვებულება: მინ. 24 სამუშაო დღე
                </div>
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">მუხ. 24</span> - დასვენება: 11სთ ცვლებს შორის
                </div>
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">მუხ. 27</span> - დედობა: 730 დღე / 183 ანაზღაურებადი
                </div>
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">საპენსიო კანონი</span> - 2%+2% (1984+ დაბ.)
                </div>
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">ღამის სამუშაო</span> - 22:00–06:00 სპეც. რეჟიმი
                </div>
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">კვირეული</span> - მინ. 24სთ უწყვეტი დასვენება
                </div>
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">მუხ. 74</span> - არასრულწლოვანი: მაქს. 36 სთ/კვირა
                </div>
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">შრომის უსაფრთხოება</span> - სავალდებულო ინსტრუქტაჟი
                </div>
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">სამედიცინო</span> - პერიოდული შემოწმება
                </div>
                <div className="p-2 rounded bg-muted/30">
                  <span className="font-medium text-foreground">ხელშეკრულება</span> - ვადიანი კონტრაქტები
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageTransition>
  );
}

// Helper Components

function StatMini({
  icon: Icon,
  label,
  value,
  total,
  status,
  description,
}: {
  icon: any;
  label: string;
  value: number;
  total: number;
  status: "ok" | "warning" | "danger";
  description: string;
}) {
  const statusConfig = {
    ok: { bg: "bg-emerald-500/10", text: "text-emerald-600 dark:text-emerald-400", icon: CheckCircle2 },
    warning: { bg: "bg-amber-500/10", text: "text-amber-600 dark:text-amber-400", icon: AlertTriangle },
    danger: { bg: "bg-destructive/10", text: "text-destructive", icon: XCircle },
  };
  const cfg = statusConfig[status];
  const StatusIcon = cfg.icon;

  return (
    <Card className="border-border/40 bg-card relative overflow-hidden group hover:shadow-lg hover:border-primary/20 transition-all duration-300">
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-3">
          <div className={cn("p-2 rounded-lg", cfg.bg)}>
            <Icon className={cn("h-4 w-4", cfg.text)} />
          </div>
          <StatusIcon className={cn("h-4 w-4", cfg.text)} />
        </div>
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <div className="flex items-baseline gap-1.5 mt-1">
          <span className={cn("text-2xl font-bold", cfg.text)}>{value}</span>
          <span className="text-xs text-muted-foreground">/ {total}</span>
        </div>
        <p className="text-xs text-muted-foreground mt-1">{description}</p>
      </CardContent>
    </Card>
  );
}

function ComplianceSection({
  id,
  title,
  subtitle,
  icon: Icon,
  expanded,
  onToggle,
  status,
  violationCount,
  children,
}: {
  id: string;
  title: string;
  subtitle: string;
  icon: any;
  expanded: boolean;
  onToggle: () => void;
  status: "ok" | "warning" | "danger";
  violationCount: number;
  children: React.ReactNode;
}) {
  const statusConfig = {
    ok: { badge: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/20", label: "შესაბამისი" },
    warning: { badge: "bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/20", label: `${violationCount} გაფრთხილება` },
    danger: { badge: "bg-destructive/10 text-destructive border-destructive/20", label: `${violationCount} დარღვევა` },
  };
  const cfg = statusConfig[status];

  return (
    <Collapsible open={expanded} onOpenChange={onToggle}>
      <Card className="border-border/40 bg-card">
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors rounded-t-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-base">{title}</CardTitle>
                  <CardDescription className="text-xs mt-0.5">{subtitle}</CardDescription>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="outline" className={cn("text-xs border", cfg.badge)}>
                  {cfg.label}
                </Badge>
                <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", expanded && "rotate-180")} />
              </div>
            </div>
          </CardHeader>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="pt-0 pb-5">{children}</CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}
