import { useState, useEffect } from "react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import {
  TrendingUp, RefreshCw, ShieldCheck, AlertTriangle, Users, Scale, Calculator, Lock,
} from "lucide-react";

interface Benchmark {
  id: string;
  position_category: string;
  region: string;
  company_size_band: string;
  p25: number;
  p50: number;
  p75: number;
  sample_size: number;
  calculated_at: string;
}

interface OwnStat {
  category: string;
  count: number;
  avg: number;
  median: number;
}

export default function SalaryBenchmarking() {
  const { userRole } = useAuth();
  const isAllowed = userRole === "admin" || userRole === "hr_manager";
  const isAdmin = userRole === "admin";

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [optIn, setOptIn] = useState<any>(null);
  const [benchmarks, setBenchmarks] = useState<Benchmark[]>([]);
  const [ownStats, setOwnStats] = useState<OwnStat[]>([]);

  useEffect(() => {
    if (isAllowed) loadData();
    else setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAllowed]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [o, b, e] = await Promise.all([
        supabase.from("benchmark_opt_in").select("*").order("created_at").limit(1).maybeSingle(),
        supabase.from("salary_benchmarks").select("*").order("position_category"),
        supabase.from("employees").select("position, salary, status").eq("status", "active"),
      ]);
      setOptIn(o.data);
      setBenchmarks((b.data as any) || []);

      const grouped = new Map<string, number[]>();
      (e.data || []).forEach((emp: any) => {
        const cat = (emp.position || "").trim() || "სხვა";
        const s = Number(emp.salary) || 0;
        if (s <= 0) return;
        if (!grouped.has(cat)) grouped.set(cat, []);
        grouped.get(cat)!.push(s);
      });

      const stats: OwnStat[] = Array.from(grouped.entries()).map(([category, arr]) => {
        const sorted = [...arr].sort((a, b) => a - b);
        const mid = Math.floor(sorted.length / 2);
        const median = sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
        return {
          category,
          count: arr.length,
          avg: arr.reduce((s, x) => s + x, 0) / arr.length,
          median,
        };
      });
      setOwnStats(stats.sort((a, b) => b.count - a.count));
    } catch {
      toast.error("მონაცემების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const toggleOptIn = async (enabled: boolean) => {
    if (!optIn) return;
    const { error } = await supabase
      .from("benchmark_opt_in")
      .update({ is_enabled: enabled, enabled_at: enabled ? new Date().toISOString() : null })
      .eq("id", optIn.id);
    if (error) return toast.error("ცვლილება ვერ მოხერხდა");
    setOptIn({ ...optIn, is_enabled: enabled });
    toast.success(enabled ? "ანონიმური მონაცემების გაზიარება ჩართულია" : "გაზიარება გამორთულია");
  };

  const refresh = async () => {
    setRefreshing(true);
    try {
      const { data, error } = await supabase.rpc("refresh_salary_benchmarks");
      if (error) throw error;
      const row: any = Array.isArray(data) ? data[0] : data;
      toast.success(
        `განახლდა ${row?.categories_updated ?? 0} კატეგორია. ${row?.categories_skipped ?? 0} გამოტოვდა (5-ზე ნაკლები თანამშრომელი).`
      );
      loadData();
    } catch {
      toast.error("გადათვლა ვერ მოხერხდა");
    } finally {
      setRefreshing(false);
    }
  };

  const gel = (n: number) => `${(Number(n) || 0).toFixed(0)} ₾`;

  const rows = benchmarks.map((b) => {
    const own = ownStats.find((o) => o.category === b.position_category);
    const diffPct = own && b.p50 > 0 ? ((own.median - b.p50) / b.p50) * 100 : null;
    return { b, own, diffPct };
  });

  const belowMarket = rows.filter((r) => r.diffPct !== null && r.diffPct < -5);
  const gapCost = belowMarket.reduce((sum, r) => {
    if (!r.own) return sum;
    return sum + (r.b.p50 - r.own.median) * r.own.count * 12;
  }, 0);

  if (!isAllowed) {
    return (
      <PageTransition>
        <div className="p-8 flex items-center justify-center min-h-[60vh]">
          <Card className="max-w-md">
            <CardContent className="p-8 text-center space-y-3">
              <Lock className="h-10 w-10 mx-auto text-muted-foreground" />
              <p className="font-semibold">წვდომა შეზღუდულია</p>
              <p className="text-sm text-muted-foreground">
                ხელფასების ბენჩმარკინგი ხელმისაწვდომია მხოლოდ ადმინისტრატორისა და HR-ისთვის.
              </p>
            </CardContent>
          </Card>
        </div>
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <div className="p-4 md:p-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-indigo-400 via-violet-500 to-purple-600 shadow-lg shadow-violet-500/25">
              <Scale className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">ხელფასების ბენჩმარკინგი</h1>
              <p className="text-muted-foreground text-sm">
                სად დგას თქვენი ანაზღაურება ბაზრის მიმართ - ანონიმური, აგრეგირებული მონაცემებით
              </p>
            </div>
          </div>
          <Button onClick={refresh} disabled={refreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
            გადათვლა
          </Button>
        </div>

        <Card className="border-primary/20">
          <CardContent className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <ShieldCheck className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-medium text-sm">ანონიმური მონაცემების გაზიარება</p>
                <p className="text-xs text-muted-foreground max-w-2xl">
                  გაზიარებისას სისტემა იყენებს მხოლოდ აგრეგირებულ პერცენტილებს პოზიციის კატეგორიის, რეგიონისა და
                  კომპანიის ზომის ჭრილში. ინდივიდუალური ხელფასი, თანამშრომლის სახელი ან კომპანიის იდენტიფიკატორი
                  არასდროს გადის. კატეგორია ჩნდება მხოლოდ 5 და მეტი თანამშრომლის შემთხვევაში.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <Label htmlFor="opt-in" className="text-sm">
                {optIn?.is_enabled ? "ჩართულია" : "გამორთულია"}
              </Label>
              <Switch
                id="opt-in"
                checked={!!optIn?.is_enabled}
                onCheckedChange={toggleOptIn}
                disabled={!isAdmin}
                aria-label="ანონიმური მონაცემების გაზიარება"
              />
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs">
                <Users className="h-4 w-4" /> კატეგორიები ბენჩმარკში
              </div>
              <p className="text-2xl font-bold mt-1">{benchmarks.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs">
                <AlertTriangle className="h-4 w-4" /> ბაზარზე დაბალი პოზიციები
              </div>
              <p className="text-2xl font-bold mt-1 text-amber-600">{belowMarket.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs">
                <Calculator className="h-4 w-4" /> მედიანამდე აყვანის ღირებულება (წელი)
              </div>
              <p className="text-2xl font-bold mt-1">{gel(gapCost)}</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">პოზიციები ბაზრის მიმართ</CardTitle>
            <CardDescription>25/50/75 პერცენტილი და ჩვენი პოზიციონირება</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p className="text-muted-foreground">იტვირთება...</p>
            ) : rows.length === 0 ? (
              <div className="text-center py-10 space-y-2">
                <p className="text-muted-foreground">ბენჩმარკის მონაცემები ჯერ არ არის</p>
                <p className="text-xs text-muted-foreground">
                  დააჭირეთ „გადათვლა"-ს. კატეგორია ჩნდება მინიმუმ 5 თანამშრომლის არსებობისას.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {rows.map(({ b, own, diffPct }) => (
                  <div key={b.id} className="border border-border/60 rounded-lg p-4 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="font-semibold truncate">{b.position_category}</p>
                        <p className="text-xs text-muted-foreground">
                          {b.region} · {b.company_size_band} თანამშრომელი · ნიმუში: {b.sample_size}
                        </p>
                      </div>
                      {diffPct !== null && (
                        <Badge
                          variant="outline"
                          className={
                            diffPct < -5
                              ? "bg-destructive/10 text-destructive border-destructive/30"
                              : diffPct > 5
                              ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/30"
                              : "bg-muted"
                          }
                        >
                          {diffPct > 0 ? "+" : ""}{diffPct.toFixed(1)}% მედიანასთან
                        </Badge>
                      )}
                    </div>

                    <div className="grid grid-cols-3 gap-3 text-sm">
                      <div>
                        <p className="text-xs text-muted-foreground">P25</p>
                        <p className="font-medium">{gel(b.p25)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">მედიანა (P50)</p>
                        <p className="font-medium">{gel(b.p50)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">P75</p>
                        <p className="font-medium">{gel(b.p75)}</p>
                      </div>
                    </div>

                    {own && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>ჩვენი მედიანა: {gel(own.median)} ({own.count} თანამშრომელი)</span>
                          {diffPct !== null && diffPct < -5 && (
                            <span className="text-destructive flex items-center gap-1">
                              <AlertTriangle className="h-3 w-3" /> retention რისკი
                            </span>
                          )}
                        </div>
                        <Progress
                          value={Math.min(100, b.p75 > 0 ? (own.median / b.p75) * 100 : 0)}
                          className="h-2"
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4" /> ბიუჯეტის სიმულატორი
            </CardTitle>
            <CardDescription>ყველა ჩამორჩენილი პოზიციის ბაზრის მედიანამდე აყვანა</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {belowMarket.length === 0 ? (
              <p className="text-muted-foreground">ჩამორჩენილი პოზიცია არ ფიქსირდება</p>
            ) : (
              <>
                {belowMarket.map(({ b, own, diffPct }) => (
                  <div key={b.id} className="flex justify-between border-b border-border/50 pb-1">
                    <span className="truncate">{b.position_category} ({own?.count})</span>
                    <span className="font-medium">
                      +{gel(((b.p50 - (own?.median || 0)) * (own?.count || 0)) * 12)} / წელი
                    </span>
                  </div>
                ))}
                <div className="flex justify-between pt-2 font-semibold">
                  <span>სულ</span>
                  <span>{gel(gapCost)}</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </PageTransition>
  );
}
