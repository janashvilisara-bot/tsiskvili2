import { useState, useEffect } from "react";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Laptop, Monitor, Smartphone, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface Asset {
  id: string;
  asset_name: string;
  asset_type: string;
  serial_number: string | null;
  status: string;
  assigned_to: string | null;
  location: string | null;
  purchase_date: string | null;
  purchase_price: number | null;
  notes: string | null;
  created_at: string | null;
  updated_at: string | null;
  created_by: string | null;
}

export default function AssetManagement() {
  const [myAssets, setMyAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const activeBranchId = useBranchFilter();

  useEffect(() => {
    fetchMyAssets();
  }, [activeBranchId]);

  const fetchMyAssets = async () => {
    let query = supabase.from("assets").select("*").order("asset_name");
    if (activeBranchId) query = query.eq("branch_id", activeBranchId);
    const { data, error } = await query;

    if (error) {
      toast.error("შეცდომა აქტივების ჩატვირთვისას");
      console.error(error);
    } else {
      setMyAssets(data || []);
    }
    setLoading(false);
  };

  const getAssetIcon = (type: string) => {
    switch (type) {
      case "laptop": return <Laptop className="h-5 w-5" />;
      case "monitor": return <Monitor className="h-5 w-5" />;
      case "phone": return <Smartphone className="h-5 w-5" />;
      default: return <Laptop className="h-5 w-5" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: "default" | "secondary" | "destructive" | "outline" } = {
      available: "outline",
      assigned: "default",
      maintenance: "secondary",
      retired: "destructive"
    };
    return <Badge variant={variants[status] || "outline"}>{status}</Badge>;
  };


  return (
    <>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">აქტივების მართვა</h1>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            ახალი აქტივი
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/10 rounded-lg">
                <Laptop className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">ჩემი აქტივები</p>
                <p className="text-2xl font-bold">{myAssets.filter(a => a.assigned_to).length}</p>
              </div>
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-500/10 rounded-lg">
                <Monitor className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">ხელმისაწვდომი</p>
                <p className="text-2xl font-bold">{myAssets.filter(a => a.status === 'available').length}</p>
              </div>
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-orange-500/10 rounded-lg">
                <Smartphone className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">მოვლაში</p>
                <p className="text-2xl font-bold">{myAssets.filter(a => a.status === 'maintenance').length}</p>
              </div>
            </div>
          </Card>
        </div>

        <Card className="p-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>დასახელება</TableHead>
                <TableHead>ტიპი</TableHead>
                <TableHead>სერიული ნომერი</TableHead>
                <TableHead>სტატუსი</TableHead>
                <TableHead>ლოკაცია</TableHead>
                <TableHead>შეძენის თარიღი</TableHead>
                <TableHead>შეძენის ფასი</TableHead>
                <TableHead>შენიშვნები</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {myAssets.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center text-muted-foreground">
                    აქტივები არ მოიძებნა
                  </TableCell>
                </TableRow>
              ) : (
                myAssets.map((asset) => (
                  <TableRow key={asset.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getAssetIcon(asset.asset_type)}
                        <span className="font-medium">{asset.asset_name}</span>
                      </div>
                    </TableCell>
                    <TableCell>{asset.asset_type}</TableCell>
                    <TableCell className="font-mono text-sm">{asset.serial_number || '-'}</TableCell>
                    <TableCell>{getStatusBadge(asset.status)}</TableCell>
                    <TableCell>{asset.location || '-'}</TableCell>
                    <TableCell>
                      {asset.purchase_date 
                        ? new Date(asset.purchase_date).toLocaleDateString('ka-GE')
                        : '-'}
                    </TableCell>
                    <TableCell>{asset.purchase_price ? `${asset.purchase_price} ₾` : '-'}</TableCell>
                    <TableCell className="max-w-xs truncate">{asset.notes || '-'}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Card>
      </div>
    </>
  );
}