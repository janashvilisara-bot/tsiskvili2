import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MoreHorizontal } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Calendar as CalendarIcon, Plus, Clock, Users, Trash2, Pencil, Download, Upload, AlertTriangle, BarChart3, Moon, Calendar as CalendarDays, Copy, FileDown, Save, BookmarkPlus, PartyPopper, Briefcase, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addDays, addWeeks, isBefore, isAfter, startOfWeek, endOfWeek, differenceInDays, parseISO } from "date-fns";
import { ka } from "date-fns/locale";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { exportShiftSchedulesToExcel } from "@/lib/exportShiftSchedulesToExcel";
import { importShiftSchedulesFromExcel } from "@/lib/importShiftSchedulesFromExcel";
import { downloadShiftImportTemplate } from "@/lib/downloadShiftImportTemplate";
import { exportHolidayWorkToExcel } from "@/lib/exportHolidayWorkToExcel";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface ShiftSchedule {
  id: string;
  employee_id: string;
  shift_date: string;
  shift_name: string | null;
  start_time: string;
  end_time: string;
  break_duration: number;
  notes: string | null;
  employees: {
    full_name: string;
    position: string;
  };
}

interface PublicHoliday {
  id: string;
  name: string;
  holiday_date: string;
  is_recurring: boolean;
  year: number | null;
  is_active: boolean;
}

interface ShiftTemplate {
  id: string;
  name: string;
  description: string | null;
  shift_name: string | null;
  start_time: string;
  end_time: string;
  break_duration: number;
  is_active: boolean;
}

const SHIFT_TEMPLATES = [
  { name: 'დილის ცვლა', start: '08:00', end: '16:00', break: 60 },
  { name: 'დღის ცვლა', start: '09:00', end: '18:00', break: 60 },
  { name: 'საღამოს ცვლა', start: '16:00', end: '00:00', break: 60 },
  { name: 'ღამის ცვლა', start: '22:00', end: '06:00', break: 60 },
  { name: '12-საათიანი დღის', start: '08:00', end: '20:00', break: 60 },
  { name: '12-საათიანი ღამის', start: '20:00', end: '08:00', break: 60 },
];

export default function ShiftSchedules() {
  const { user, userRole } = useAuth();
  const navigate = useNavigate();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [shifts, setShifts] = useState<ShiftSchedule[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [templates, setTemplates] = useState<ShiftTemplate[]>([]);
  const [holidays, setHolidays] = useState<PublicHoliday[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(true);
  const [selectedEmployees, setSelectedEmployees] = useState<string[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('18:00');
  const [breakDuration, setBreakDuration] = useState(60);
  const [editingShift, setEditingShift] = useState<ShiftSchedule | null>(null);
  const [shiftName, setShiftName] = useState('');
  const [repeatType, setRepeatType] = useState<'once' | 'daily' | 'weekly' | 'monthly'>('once');
  const [repeatEndDate, setRepeatEndDate] = useState<Date | undefined>(undefined);
  const [selectedWeekDays, setSelectedWeekDays] = useState<number[]>([]);
  const [conflicts, setConflicts] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showStats, setShowStats] = useState(false);
  const [isCopyDialogOpen, setIsCopyDialogOpen] = useState(false);
  const [copyType, setCopyType] = useState<'week' | 'month'>('week');
  const [copySourceDate, setCopySourceDate] = useState<Date | undefined>(undefined);
  const [copyTargetDate, setCopyTargetDate] = useState<Date | undefined>(undefined);
  
  // Template form state
  const [templateName, setTemplateName] = useState('');
  const [templateDescription, setTemplateDescription] = useState('');
  
  // Holiday work report state
  const [holidayWorkRecords, setHolidayWorkRecords] = useState<any[]>([]);
  const [reportYear, setReportYear] = useState<number>(new Date().getFullYear());
  const [loadingReport, setLoadingReport] = useState(false);
  const [departments, setDepartments] = useState<any[]>([]);
  const [selectedDepartment, setSelectedDepartment] = useState<string>('all');

  const canManage = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    fetchShifts();
    fetchEmployees();
    fetchTemplates();
    fetchHolidays();
    fetchHolidayWorkReport();
    fetchDepartments();
  }, [currentMonth, reportYear]);

  const fetchDepartments = async () => {
    try {
      const { data, error } = await supabase
        .from('departments')
        .select('id, name')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      setDepartments(data || []);
    } catch (error: any) {
      console.error('Error fetching departments:', error);
    }
  };

  const fetchHolidays = async () => {
    try {
      const { data, error } = await supabase
        .from('public_holidays')
        .select('*')
        .eq('is_active', true)
        .order('holiday_date');
      
      if (error) throw error;
      setHolidays(data || []);
    } catch (error: any) {
      console.error('Error fetching holidays:', error);
    }
  };

  const isPublicHoliday = (date: Date): PublicHoliday | null => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return holidays.find(h => h.holiday_date === dateStr) || null;
  };

  const fetchTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('shift_templates')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      setTemplates(data || []);
    } catch (error: any) {
      console.error('Error fetching templates:', error);
    }
  };

  const fetchEmployees = async () => {
    try {
      // Fetch all work_schedules and filter in JavaScript for reliable Georgian text matching
      const { data: allWorkSchedules, error: wsError } = await supabase
        .from('work_schedules')
        .select('employee_id, schedule_type');
      
      if (wsError) {
        console.error('Work schedules error:', wsError);
        throw wsError;
      }
      
      // Filter for shift-related schedule types (contains "ცვლ" or "shift")
      const shiftWorkSchedules = (allWorkSchedules || []).filter(ws => {
        const scheduleType = ws.schedule_type || '';
        return scheduleType.includes('ცვლ') || 
               scheduleType.includes('ცვლა') || 
               scheduleType.toLowerCase().includes('shift');
      });
      
      
      // Get unique employee IDs
      const shiftEmployeeIds = [...new Set(shiftWorkSchedules.map(ws => ws.employee_id))];
      
      
      if (shiftEmployeeIds.length === 0) {
        setEmployees([]);
        return;
      }
      
      const { data, error } = await supabase
        .from('employees')
        .select('id, full_name, position, department')
        .eq('status', 'active')
        .in('id', shiftEmployeeIds)
        .order('full_name');
      
      if (error) throw error;
      setEmployees(data || []);
    } catch (error: any) {
      console.error('Error fetching employees:', error);
    }
  };

  // Filter employees by department
  const filteredEmployees = selectedDepartment === 'all' 
    ? employees 
    : employees.filter(e => e.department === selectedDepartment);

  const fetchShifts = async () => {
    setIsFetching(true);
    try {
      const start = startOfMonth(currentMonth);
      const end = endOfMonth(currentMonth);

      const { data, error } = await supabase
        .from('shift_schedules')
        .select('*, employees(full_name, position)')
        .gte('shift_date', format(start, 'yyyy-MM-dd'))
        .lte('shift_date', format(end, 'yyyy-MM-dd'))
        .order('shift_date', { ascending: true });

      if (error) throw error;
      setShifts((data as any[]) || []);
    } catch (error: any) {
      toast.error('ცვლების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsFetching(false);
    }
  };

  const checkForConflicts = async (employeeIds: string[], dates: Date[], newStartTime: string, newEndTime: string) => {
    const conflictMessages: string[] = [];
    
    for (const empId of employeeIds) {
      const employee = employees.find(e => e.id === empId);
      const employeeName = employee?.full_name || 'თანამშრომელი';
      
      for (const date of dates) {
        const dateStr = format(date, 'yyyy-MM-dd');
        
        // Check existing shifts for this employee on this date
        const existingShifts = shifts.filter(
          shift => shift.employee_id === empId && shift.shift_date === dateStr
        );
        
        if (existingShifts.length > 0) {
          // Check if there's overlap
          const [newStart, newEnd] = [newStartTime, newEndTime].map(t => {
            const [h, m] = t.split(':').map(Number);
            return h * 60 + m;
          });
          
          for (const existing of existingShifts) {
            const [existStart, existEnd] = [existing.start_time, existing.end_time].map(t => {
              const [h, m] = t.split(':').map(Number);
              return h * 60 + m;
            });
            
            // Handle overnight shifts
            const newEndAdjusted = newEnd < newStart ? newEnd + 24 * 60 : newEnd;
            const existEndAdjusted = existEnd < existStart ? existEnd + 24 * 60 : existEnd;
            
            // Check for overlap or too close (less than 8 hours between shifts)
            const hasOverlap = (newStart < existEndAdjusted && newEndAdjusted > existStart);
            const timeBetween = Math.min(
              Math.abs(newStart - existEndAdjusted),
              Math.abs(existStart - newEndAdjusted)
            );
            
            if (hasOverlap) {
              conflictMessages.push(
                `⚠️ ${employeeName} - ${format(date, 'PPP', { locale: ka })}: ცვლები გადაფარავს ერთმანეთს (${existing.start_time}-${existing.end_time} და ${newStartTime}-${newEndTime})`
              );
            } else if (timeBetween < 480) { // Less than 8 hours
              conflictMessages.push(
                `⚠️ ${employeeName} - ${format(date, 'PPP', { locale: ka })}: ცვლები ძალიან ახლოსაა (დასვენება: ${Math.floor(timeBetween / 60)} სთ)`
              );
            }
          }
        }
      }
    }
    
    return conflictMessages;
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setConflicts([]);
    const formData = new FormData(e.currentTarget);

    try {
      if (editingShift) {
        // Update existing shift
        const { error } = await supabase
          .from('shift_schedules')
          .update({
            shift_name: formData.get('shift_name') as string || null,
            start_time: formData.get('start_time') as string,
            end_time: formData.get('end_time') as string,
            break_duration: formData.get('break_duration') ? Number(formData.get('break_duration')) : 0,
            notes: formData.get('notes') as string || null,
          })
          .eq('id', editingShift.id);

        if (error) throw error;
        toast.success('ცვლა წარმატებით განახლდა');
      } else {
        // Create new shifts with repeat logic
        const employeeIds = selectedEmployees.length > 0 
          ? selectedEmployees 
          : [formData.get('employee_id') as string];

        const basePayload = {
          shift_name: formData.get('shift_name') as string || null,
          start_time: formData.get('start_time') as string,
          end_time: formData.get('end_time') as string,
          break_duration: formData.get('break_duration') ? Number(formData.get('break_duration')) : 0,
          notes: formData.get('notes') as string || null,
          created_by: user?.id,
        };

        // Generate dates based on repeat type
        const dates: Date[] = [];
        
        if (repeatType === 'once') {
          dates.push(selectedDate);
        } else {
          let currentDate = selectedDate;
          const endDate = repeatEndDate || addWeeks(selectedDate, 4); // Default 4 weeks if no end date
          
          while (isBefore(currentDate, endDate) || isSameDay(currentDate, endDate)) {
            if (repeatType === 'daily') {
              dates.push(currentDate);
              currentDate = addDays(currentDate, 1);
            } else if (repeatType === 'weekly') {
              // Add shifts for selected week days
              if (selectedWeekDays.length > 0) {
                const dayOfWeek = currentDate.getDay();
                if (selectedWeekDays.includes(dayOfWeek)) {
                  dates.push(currentDate);
                }
                currentDate = addDays(currentDate, 1);
              } else {
                // If no days selected, repeat on the same day of week
                dates.push(currentDate);
                currentDate = addWeeks(currentDate, 1);
              }
            } else if (repeatType === 'monthly') {
              dates.push(currentDate);
              // Add one month (approximate with 30 days for simplicity)
              currentDate = addDays(currentDate, 30);
            }
          }
        }

        // Check for conflicts before creating shifts
        const conflictMessages = await checkForConflicts(
          employeeIds, 
          dates, 
          basePayload.start_time, 
          basePayload.end_time
        );

        if (conflictMessages.length > 0) {
          setConflicts(conflictMessages);
          setIsLoading(false);
          return; // Don't proceed with creation if there are conflicts
        }

        // Create payload for each date and employee
        const payloads = [];
        for (const date of dates) {
          for (const empId of employeeIds) {
            payloads.push({
              ...basePayload,
              employee_id: empId,
              shift_date: format(date, 'yyyy-MM-dd'),
            });
          }
        }

        const { error } = await supabase
          .from('shift_schedules')
          .insert(payloads);

        if (error) throw error;
        
        const totalShifts = dates.length * employeeIds.length;
        toast.success(
          repeatType === 'once' 
            ? (selectedEmployees.length > 1 
                ? `${selectedEmployees.length} თანამშრომლისთვის ცვლა დაემატა` 
                : 'ცვლა წარმატებით დაემატა')
            : `${totalShifts} ცვლა წარმატებით შეიქმნა (${dates.length} დღე × ${employeeIds.length} თანამშრომელი)`
        );
      }
      
      setIsDialogOpen(false);
      setEditingShift(null);
      setSelectedEmployees([]);
      setShiftName('');
      setSelectedTemplate('');
      setRepeatType('once');
      setRepeatEndDate(undefined);
      setSelectedWeekDays([]);
      fetchShifts();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditShift = (shift: ShiftSchedule) => {
    setEditingShift(shift);
    setSelectedDate(new Date(shift.shift_date));
    setShiftName(shift.shift_name || '');
    setStartTime(shift.start_time);
    setEndTime(shift.end_time);
    setBreakDuration(shift.break_duration);
    setIsDialogOpen(true);
  };

  const handleDeleteShift = async (shiftId: string) => {
    try {
      const { error } = await supabase
        .from('shift_schedules')
        .delete()
        .eq('id', shiftId);

      if (error) throw error;
      toast.success('ცვლა წაშლილია');
      fetchShifts();
    } catch (error: any) {
      toast.error('წაშლა ვერ მოხერხდა');
    }
  };

  const toggleEmployeeSelection = (employeeId: string) => {
    setSelectedEmployees(prev => 
      prev.includes(employeeId) 
        ? prev.filter(id => id !== employeeId)
        : [...prev, employeeId]
    );
  };

  const toggleAllEmployees = () => {
    setSelectedEmployees(prev => 
      prev.length === employees.length ? [] : employees.map(e => e.id)
    );
  };

  const toggleWeekDay = (day: number) => {
    setSelectedWeekDays(prev => 
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  const handleTemplateChange = (templateId: string) => {
    setSelectedTemplate(templateId);
    
    // Try to find in database templates first
    const dbTemplate = templates.find(t => t.id === templateId);
    if (dbTemplate) {
      setShiftName(dbTemplate.shift_name || '');
      setStartTime(dbTemplate.start_time);
      setEndTime(dbTemplate.end_time);
      setBreakDuration(dbTemplate.break_duration);
      return;
    }
    
    // Fallback to hardcoded templates
    const selectedShift = SHIFT_TEMPLATES.find(t => t.name === templateId);
    if (selectedShift) {
      setShiftName(selectedShift.name);
      setStartTime(selectedShift.start);
      setEndTime(selectedShift.end);
      setBreakDuration(selectedShift.break);
    }
  };

  const handleSaveAsTemplate = async () => {
    if (!templateName.trim()) {
      toast.error('გთხოვთ მიუთითოთ შაბლონის სახელი');
      return;
    }

    try {
      const { error } = await supabase
        .from('shift_templates')
        .insert({
          name: templateName,
          description: templateDescription,
          shift_name: shiftName,
          start_time: startTime,
          end_time: endTime,
          break_duration: breakDuration,
          created_by: user?.id,
        });

      if (error) throw error;

      toast.success('შაბლონი წარმატებით შეინახა');
      setIsTemplateDialogOpen(false);
      setTemplateName('');
      setTemplateDescription('');
      fetchTemplates();
    } catch (error: any) {
      toast.error('შაბლონის შენახვა ვერ მოხერხდა');
    }
  };

  const fetchHolidayWorkReport = async () => {
    setLoadingReport(true);
    try {
      const { data: yearHolidays, error: holidaysError } = await supabase
        .from("public_holidays")
        .select("*")
        .eq("is_active", true);

      if (holidaysError) throw holidaysError;

      const startDate = `${reportYear}-01-01`;
      const endDate = `${reportYear}-12-31`;

      const { data: attendanceData, error: attendanceError } = await supabase
        .from("attendance")
        .select(`
          *,
          employees:employee_id (
            id,
            full_name,
            employee_number,
            position,
            department
          )
        `)
        .gte("date", startDate)
        .lte("date", endDate)
        .not("check_in", "is", null)
        .not("check_out", "is", null);

      if (attendanceError) throw attendanceError;

      const workRecords: any[] = [];

      attendanceData?.forEach((attendance: any) => {
        const attendanceDate = attendance.date;
        
        const matchingHoliday = yearHolidays?.find(holiday => {
          if (holiday.is_recurring) {
            const holidayMonthDay = holiday.holiday_date.substring(5);
            const attendanceMonthDay = attendanceDate.substring(5);
            return holidayMonthDay === attendanceMonthDay;
          }
          return holiday.holiday_date === attendanceDate;
        });

        if (matchingHoliday && attendance.employees) {
          const checkIn = attendance.check_in;
          const checkOut = attendance.check_out;
          
          const [inHours, inMinutes] = checkIn.split(':').map(Number);
          const [outHours, outMinutes] = checkOut.split(':').map(Number);
          const totalMinutes = (outHours * 60 + outMinutes) - (inHours * 60 + inMinutes);
          const totalHours = totalMinutes / 60;
          const multiplier = matchingHoliday.overtime_multiplier || 1.5;

          workRecords.push({
            employee_id: attendance.employees.id,
            employee_name: attendance.employees.full_name,
            employee_number: attendance.employees.employee_number || "-",
            position: attendance.employees.position || "-",
            department: attendance.employees.department || "-",
            holiday_name: matchingHoliday.name,
            holiday_date: attendanceDate,
            check_in: checkIn,
            check_out: checkOut,
            total_hours: Math.round(totalHours * 100) / 100,
            overtime_hours: Math.round(totalHours * 100) / 100,
            overtime_multiplier: multiplier,
            calculated_overtime: Math.round(totalHours * multiplier * 100) / 100,
          });
        }
      });

      setHolidayWorkRecords(workRecords);
    } catch (error: any) {
      console.error("Error fetching holiday work report:", error);
      toast.error('ანგარიშის ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setLoadingReport(false);
    }
  };

  const calculateHolidayWorkStats = () => {
    const totalHours = holidayWorkRecords.reduce((sum, r) => sum + r.total_hours, 0);
    const totalOvertime = holidayWorkRecords.reduce((sum, r) => sum + r.overtime_hours, 0);
    const totalCalculated = holidayWorkRecords.reduce((sum, r) => sum + r.calculated_overtime, 0);
    const uniqueEmployees = new Set(holidayWorkRecords.map(r => r.employee_id)).size;
    
    return {
      totalHours: Math.round(totalHours * 100) / 100,
      totalOvertime: Math.round(totalOvertime * 100) / 100,
      totalCalculated: Math.round(totalCalculated * 100) / 100,
      uniqueEmployees,
      totalRecords: holidayWorkRecords.length,
    };
  };

  const handleDeleteTemplate = async (templateId: string) => {
    if (!confirm('დარწმუნებული ხართ რომ გსურთ შაბლონის წაშლა?')) return;

    try {
      const { error } = await supabase
        .from('shift_templates')
        .update({ is_active: false })
        .eq('id', templateId);

      if (error) throw error;

      toast.success('შაბლონი წაშლილია');
      fetchTemplates();
    } catch (error: any) {
      toast.error('წაშლა ვერ მოხერხდა');
    }
  };

  const getShiftsForDate = (date: Date) => {
    return shifts.filter(shift => 
      isSameDay(new Date(shift.shift_date), date)
    );
  };

  const getDaysInMonth = () => {
    const start = startOfMonth(currentMonth);
    const end = endOfMonth(currentMonth);
    return eachDayOfInterval({ start, end });
  };

  const calculateEmployeeStats = () => {
    const start = startOfMonth(currentMonth);
    const end = endOfMonth(currentMonth);
    
    // Group shifts by employee
    const employeeShifts = shifts.reduce((acc, shift) => {
      if (!acc[shift.employee_id]) {
        acc[shift.employee_id] = {
          employee: shift.employees,
          shifts: [],
        };
      }
      acc[shift.employee_id].shifts.push(shift);
      return acc;
    }, {} as Record<string, { employee: any; shifts: ShiftSchedule[] }>);

    // Calculate stats for each employee
    const stats = Object.entries(employeeShifts).map(([employeeId, { employee, shifts: empShifts }]) => {
      let totalHours = 0;
      let nightShifts = 0;
      let weekendShifts = 0;
      let holidayShifts = 0;

      empShifts.forEach((shift) => {
        // Calculate hours
        const [startHour, startMin] = shift.start_time.split(':').map(Number);
        const [endHour, endMin] = shift.end_time.split(':').map(Number);

        let hours = endHour - startHour;
        let minutes = endMin - startMin;

        // Handle overnight shifts
        if (hours < 0) {
          hours += 24;
        }

        const totalMinutes = hours * 60 + minutes - shift.break_duration;
        totalHours += totalMinutes / 60;

        // Check if it's a night shift (22:00-06:00)
        const isNightShift = (startHour >= 22 || startHour < 6) || (endHour >= 22 || endHour <= 6);
        if (isNightShift) {
          nightShifts++;
        }

        // Check if it's a weekend shift
        const shiftDate = new Date(shift.shift_date);
        const dayOfWeek = shiftDate.getDay();
        if (dayOfWeek === 0 || dayOfWeek === 6) {
          weekendShifts++;
        }

        // Check if it's a public holiday shift
        if (isPublicHoliday(shiftDate)) {
          holidayShifts++;
        }
      });

      return {
        employeeId,
        employeeName: employee.full_name,
        position: employee.position,
        totalHours: totalHours.toFixed(1),
        nightShifts,
        weekendShifts,
        holidayShifts,
        totalShifts: empShifts.length,
      };
    });

    return stats.sort((a, b) => parseFloat(b.totalHours) - parseFloat(a.totalHours));
  };

  const handleCopyShifts = async () => {
    if (!copySourceDate || !copyTargetDate) {
      toast.error('გთხოვთ აირჩიოთ საწყისი და სამიზნე პერიოდი');
      return;
    }

    try {
      let sourceStart: Date, sourceEnd: Date, targetStart: Date;
      let dayOffset: number;

      if (copyType === 'week') {
        // Week copy
        sourceStart = startOfWeek(copySourceDate, { weekStartsOn: 1 });
        sourceEnd = endOfWeek(copySourceDate, { weekStartsOn: 1 });
        targetStart = startOfWeek(copyTargetDate, { weekStartsOn: 1 });
        dayOffset = differenceInDays(targetStart, sourceStart);
      } else {
        // Month copy
        sourceStart = startOfMonth(copySourceDate);
        sourceEnd = endOfMonth(copySourceDate);
        targetStart = startOfMonth(copyTargetDate);
        dayOffset = differenceInDays(targetStart, sourceStart);
      }

      // Get shifts in source period
      const { data: sourceShifts, error: fetchError } = await supabase
        .from('shift_schedules')
        .select('*')
        .gte('shift_date', format(sourceStart, 'yyyy-MM-dd'))
        .lte('shift_date', format(sourceEnd, 'yyyy-MM-dd'));

      if (fetchError) throw fetchError;

      if (!sourceShifts || sourceShifts.length === 0) {
        toast.error('არ მოიძებნა ცვლები არჩეულ პერიოდში');
        return;
      }

      // Create new shifts with offset dates
      const newShifts = sourceShifts.map((shift) => {
        const originalDate = parseISO(shift.shift_date);
        const newDate = addDays(originalDate, dayOffset);
        
        return {
          employee_id: shift.employee_id,
          shift_date: format(newDate, 'yyyy-MM-dd'),
          shift_name: shift.shift_name,
          start_time: shift.start_time,
          end_time: shift.end_time,
          break_duration: shift.break_duration,
          notes: shift.notes,
          created_by: user?.id,
        };
      });

      // Insert new shifts
      const { error: insertError } = await supabase
        .from('shift_schedules')
        .insert(newShifts);

      if (insertError) throw insertError;

      toast.success(
        `${newShifts.length} ცვლა წარმატებით დაკოპირდა ${copyType === 'week' ? 'კვირიდან' : 'თვიდან'} ${format(sourceStart, 'PPP', { locale: ka })} - ${copyType === 'week' ? 'კვირაზე' : 'თვეზე'} ${format(targetStart, 'PPP', { locale: ka })}`
      );

      setIsCopyDialogOpen(false);
      setCopySourceDate(undefined);
      setCopyTargetDate(undefined);
      fetchShifts();
    } catch (error: any) {
      toast.error('კოპირება ვერ მოხერხდა: ' + error.message);
    }
  };

  const handleExportToExcel = () => {
    exportShiftSchedulesToExcel(shifts, currentMonth, 'თქვენი კომპანია');
    toast.success('Excel ფაილი ჩამოიტვირთა');
  };

  const handleImportFromExcel = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const importedData = await importShiftSchedulesFromExcel(file);
      
      if (importedData.length === 0) {
        toast.error('Excel ფაილი ცარიელია');
        return;
      }

      // Match employees by name and create shifts
      const shiftsToCreate = [];
      const errors = [];
      const warnings = [];

      for (const item of importedData) {
        // Trim and normalize employee name
        const normalizedName = item.employee_name?.trim().toLowerCase();
        
        if (!normalizedName) {
          errors.push(`ცარიელი სახელი ხაზზე ${importedData.indexOf(item) + 1}`);
          continue;
        }

        // Try to find employee with flexible matching
        const employee = employees.find(e => {
          const empName = e.full_name?.trim().toLowerCase();
          return empName === normalizedName || 
                 empName.includes(normalizedName) || 
                 normalizedName.includes(empName);
        });

        if (!employee) {
          errors.push(`თანამშრომელი არ მოიძებნა: "${item.employee_name}"`);
          warnings.push(`მოსალოდნელი ფორმატი: სახელი გვარი (მაგ: "გიორგი მელაძე")`);
          continue;
        }

        // Validate date format
        const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
        if (!item.shift_date || !dateRegex.test(item.shift_date)) {
          errors.push(`არასწორი თარიღის ფორმატი: ${item.shift_date || 'ცარიელი'} (უნდა იყოს YYYY-MM-DD, მაგ: 2024-01-15)`);
          continue;
        }

        // Validate time format
        const timeRegex = /^\d{2}:\d{2}$/;
        if (!item.start_time || !timeRegex.test(item.start_time)) {
          errors.push(`არასწორი დაწყების დროის ფორმატი: ${item.start_time || 'ცარიელი'} (უნდა იყოს HH:MM, მაგ: 09:00)`);
          continue;
        }
        if (!item.end_time || !timeRegex.test(item.end_time)) {
          errors.push(`არასწორი დასრულების დროის ფორმატი: ${item.end_time || 'ცარიელი'} (უნდა იყოს HH:MM, მაგ: 18:00)`);
          continue;
        }

        shiftsToCreate.push({
          employee_id: employee.id,
          shift_date: item.shift_date,
          shift_name: item.shift_name || null,
          start_time: item.start_time,
          end_time: item.end_time,
          break_duration: item.break_duration || 0,
          notes: item.notes || null,
          created_by: user?.id,
        });
      }

      // Show detailed results
      if (errors.length > 0) {
        const uniqueWarnings = [...new Set(warnings)];
        toast.error(
          <div className="space-y-2">
            <div className="font-semibold">იმპორტის შეცდომები ({errors.length}):</div>
            <ul className="list-disc list-inside text-sm max-h-60 overflow-y-auto">
              {errors.slice(0, 5).map((err, i) => <li key={i}>{err}</li>)}
              {errors.length > 5 && <li>... და კიდევ {errors.length - 5} შეცდომა</li>}
            </ul>
            {uniqueWarnings.length > 0 && (
              <div className="text-sm mt-2 p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded">
                💡 რჩევა: {uniqueWarnings[0]}
              </div>
            )}
          </div>,
          { duration: 10000 }
        );
      }

      if (shiftsToCreate.length > 0) {
        const { error } = await supabase
          .from('shift_schedules')
          .insert(shiftsToCreate);

        if (error) throw error;

        toast.success(
          `✅ ${shiftsToCreate.length} ცვლა წარმატებით იმპორტირდა${errors.length > 0 ? ` (${errors.length} შეცდომა)` : ''}`
        );
        fetchShifts();
      } else if (errors.length > 0) {
        toast.error('არცერთი ცვლა ვერ იმპორტირდა. გთხოვთ შეამოწმოთ ფაილის ფორმატი.');
      }
    } catch (error: any) {
      console.error('Import error:', error);
      toast.error('იმპორტი ვერ მოხერხდა: ' + error.message);
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-6">
      {isFetching && (
        <div className="flex h-24 items-center justify-center text-muted-foreground">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      )}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <h1 className="text-2xl sm:text-3xl font-bold">ცვლების გრაფიკი</h1>
          <p className="mt-1 sm:mt-2 text-sm sm:text-base text-muted-foreground">კალენდარზე თარიღების მიხედვით სამუშაო დროის მართვა</p>
        </div>
        <div className="flex gap-2 sm:hidden">
          <Button onClick={handleExportToExcel} className="flex-1 gap-2">
            <Download className="h-4 w-4" />
            Excel-ში ექსპორტი
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-1" aria-label="მეტი მოქმედება">
                <MoreHorizontal className="h-4 w-4" />
                მეტი
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setShowStats(!showStats)}><BarChart3 className="mr-2 h-4 w-4" />სტატისტიკა</DropdownMenuItem>
              {canManage && <DropdownMenuItem onClick={() => setIsTemplateDialogOpen(true)}><BookmarkPlus className="mr-2 h-4 w-4" />შაბლონები</DropdownMenuItem>}
              {canManage && <DropdownMenuItem onClick={() => setIsCopyDialogOpen(true)}><Copy className="mr-2 h-4 w-4" />კოპირება</DropdownMenuItem>}
              {canManage && <DropdownMenuItem onClick={() => fileInputRef.current?.click()}><Upload className="mr-2 h-4 w-4" />Excel-დან იმპორტი</DropdownMenuItem>}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <div className="hidden sm:flex flex-wrap gap-2">
          <Button 
            onClick={() => setShowStats(!showStats)} 
            variant={showStats ? "default" : "outline"}
            className="gap-2"
          >
            <BarChart3 className="h-4 w-4" />
            სტატისტიკა
          </Button>
          {canManage && (
            <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <BookmarkPlus className="h-4 w-4" />
                  შაბლონები
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>ცვლების შაბლონები</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {/* Existing Templates */}
                  <div>
                    <h3 className="font-semibold mb-3">შენახული შაბლონები</h3>
                    {templates.length > 0 ? (
                      <div className="space-y-2">
                        {templates.map((template) => (
                          <Card key={template.id} className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <h4 className="font-medium">{template.name}</h4>
                                  <Badge variant="outline">
                                    {template.start_time} - {template.end_time}
                                  </Badge>
                                </div>
                                {template.description && (
                                  <p className="text-sm text-muted-foreground mt-1">
                                    {template.description}
                                  </p>
                                )}
                                <div className="flex gap-4 text-sm text-muted-foreground mt-2">
                                  <span>ცვლა: {template.shift_name || '-'}</span>
                                  <span>შესვენება: {template.break_duration} წთ</span>
                                </div>
                              </div>
                              <div className="flex flex-wrap gap-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => {
                                    handleTemplateChange(template.id);
                                    setIsTemplateDialogOpen(false);
                                    setIsDialogOpen(true);
                                  }}
                                >
                                  გამოყენება
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleDeleteTemplate(template.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        შენახული შაბლონები არ არის
                      </p>
                    )}
                  </div>

                  {/* Save Current as Template */}
                  <div className="border-t pt-4">
                    <h3 className="font-semibold mb-3">შენახვა ახალი შაბლონით</h3>
                    <div className="space-y-3">
                      <div>
                        <Label htmlFor="template_name">შაბლონის სახელი *</Label>
                        <Input
                          id="template_name"
                          value={templateName}
                          onChange={(e) => setTemplateName(e.target.value)}
                          placeholder="მაგ: დღესასწაულის გრაფიკი"
                        />
                      </div>
                      <div>
                        <Label htmlFor="template_description">აღწერა</Label>
                        <Textarea
                          id="template_description"
                          value={templateDescription}
                          onChange={(e) => setTemplateDescription(e.target.value)}
                          placeholder="შაბლონის დეტალები..."
                          rows={2}
                        />
                      </div>
                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <Label>დაწყება</Label>
                          <Input
                            type="time"
                            value={startTime}
                            onChange={(e) => setStartTime(e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>დასრულება</Label>
                          <Input
                            type="time"
                            value={endTime}
                            onChange={(e) => setEndTime(e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>შესვენება (წთ)</Label>
                          <Input
                            type="number"
                            value={breakDuration}
                            onChange={(e) => setBreakDuration(Number(e.target.value))}
                          />
                        </div>
                      </div>
                        <Button onClick={handleSaveAsTemplate} className="w-full gap-2">
                        <Save className="h-4 w-4" />
                        შენახვა შაბლონად
                      </Button>
                      
                      {/* Template Download Button */}
                      <div className="border-t pt-4">
                        <Button 
                          onClick={() => {
                            downloadShiftImportTemplate();
                            toast.success('შაბლონი ჩამოიტვირთა');
                          }} 
                          variant="outline"
                          className="w-full gap-2"
                        >
                          <FileDown className="h-4 w-4" />
                          Excel შაბლონის ჩამოტვირთვა
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          )}
          {canManage && (
            <Dialog open={isCopyDialogOpen} onOpenChange={setIsCopyDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Copy className="h-4 w-4" />
                  კოპირება
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>ცვლების კოპირება</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>კოპირების ტიპი</Label>
                    <Select value={copyType} onValueChange={(value: 'week' | 'month') => setCopyType(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="week">კვირა</SelectItem>
                        <SelectItem value="month">თვე</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>საწყისი {copyType === 'week' ? 'კვირა' : 'თვე'}</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {copySourceDate ? format(copySourceDate, 'PPP', { locale: ka }) : 'აირჩიეთ თარიღი'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={copySourceDate}
                          onSelect={setCopySourceDate}
                          locale={ka}
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    {copySourceDate && (
                      <p className="text-sm text-muted-foreground mt-1">
                        {copyType === 'week' 
                          ? `${format(startOfWeek(copySourceDate, { weekStartsOn: 1 }), 'PPP', { locale: ka })} - ${format(endOfWeek(copySourceDate, { weekStartsOn: 1 }), 'PPP', { locale: ka })}`
                          : `${format(startOfMonth(copySourceDate), 'MMMM yyyy', { locale: ka })}`
                        }
                      </p>
                    )}
                  </div>

                  <div>
                    <Label>სამიზნე {copyType === 'week' ? 'კვირა' : 'თვე'}</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {copyTargetDate ? format(copyTargetDate, 'PPP', { locale: ka }) : 'აირჩიეთ თარიღი'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={copyTargetDate}
                          onSelect={setCopyTargetDate}
                          locale={ka}
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    {copyTargetDate && (
                      <p className="text-sm text-muted-foreground mt-1">
                        {copyType === 'week' 
                          ? `${format(startOfWeek(copyTargetDate, { weekStartsOn: 1 }), 'PPP', { locale: ka })} - ${format(endOfWeek(copyTargetDate, { weekStartsOn: 1 }), 'PPP', { locale: ka })}`
                          : `${format(startOfMonth(copyTargetDate), 'MMMM yyyy', { locale: ka })}`
                        }
                      </p>
                    )}
                  </div>

                  <Button 
                    onClick={handleCopyShifts} 
                    className="w-full"
                    disabled={!copySourceDate || !copyTargetDate}
                  >
                    კოპირება
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
          {canManage && (
            <>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImportFromExcel}
                accept=".xlsx,.xls"
                className="hidden"
              />
              <Button 
                onClick={() => fileInputRef.current?.click()} 
                variant="outline"
                className="gap-2"
              >
                <Upload className="h-4 w-4" />
                Excel-დან იმპორტი
              </Button>
            </>
          )}
          <Button onClick={handleExportToExcel} className="gap-2">
            <Download className="h-4 w-4" />
            Excel-ში ექსპორტი
          </Button>
        </div>
      </div>

      {/* Tabs for Monthly View, Statistics and Holiday Work Report */}
      <Tabs defaultValue="monthly-view" className="w-full">
        <TabsList className="flex w-full max-w-2xl overflow-x-auto justify-start sm:grid sm:grid-cols-3">
          <TabsTrigger value="monthly-view">თვის ჭრილი</TabsTrigger>
          <TabsTrigger value="shifts">ცვლების სტატისტიკა</TabsTrigger>
          <TabsTrigger value="holiday-work">დასვენების დღეების ანგარიში</TabsTrigger>
        </TabsList>

        {/* Monthly View Tab */}
        <TabsContent value="monthly-view" className="mt-6 space-y-6">
          {/* Month selector */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                onClick={() => setCurrentMonth(addDays(startOfMonth(currentMonth), -1))}
              >
                ← წინა თვე
              </Button>
              <h3 className="text-lg font-semibold">
                {format(currentMonth, 'MMMM yyyy', { locale: ka })}
              </h3>
              <Button
                variant="outline"
                onClick={() => setCurrentMonth(addDays(endOfMonth(currentMonth), 1))}
              >
                შემდეგი თვე →
              </Button>
            </div>
            <div className="flex items-center gap-3">
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="დეპარტამენტი" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Badge variant="secondary">{shifts.length} ცვლა</Badge>
              <Badge variant="outline">{filteredEmployees.length} თანამშრომელი</Badge>
            </div>
          </div>

          {/* Calendar Grid View - All Employees */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <CardTitle className="flex items-center gap-2">
                  <CalendarDays className="h-5 w-5" />
                  თვის კალენდარი (ყველა თანამშრომელი)
                </CardTitle>
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => navigate("/vacancies?tab=herio&new=1")}
                  className="gap-2"
                >
                  <Briefcase className="h-4 w-4" />
                  გაკლია თანამშრომელი? Herio-ზე განთავსება
                </Button>
              </div>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <div className="min-w-[1200px]">
                {/* Header with days */}
                <div className="grid grid-cols-[200px_repeat(31,minmax(40px,1fr))] gap-1 mb-2">
                  <div className="font-semibold p-2 bg-muted rounded">თანამშრომელი</div>
                  {getDaysInMonth().map((day, idx) => {
                    const dayOfWeek = day.getDay();
                    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
                    const holiday = isPublicHoliday(day);
                    return (
                      <div 
                        key={idx} 
                        className={`text-center text-xs p-1 rounded font-medium
                          ${isWeekend ? 'bg-orange-100 dark:bg-orange-900/30' : 'bg-muted'}
                          ${holiday ? 'bg-red-100 dark:bg-red-900/30' : ''}
                        `}
                      >
                        <div>{format(day, 'd')}</div>
                        <div className="text-muted-foreground">{format(day, 'EEE', { locale: ka })}</div>
                      </div>
                    );
                  })}
                </div>

                {/* Employee rows */}
                {filteredEmployees.map((employee) => {
                  const employeeShifts = shifts.filter(s => s.employee_id === employee.id);
                  return (
                    <div 
                      key={employee.id}
                      className="grid grid-cols-[200px_repeat(31,minmax(40px,1fr))] gap-1 mb-1"
                    >
                      <div className="p-2 bg-muted/50 rounded text-sm truncate" title={employee.full_name}>
                        <div className="font-medium truncate">{employee.full_name}</div>
                        <div className="text-xs text-muted-foreground truncate">{employee.position}</div>
                      </div>
                      {getDaysInMonth().map((day, idx) => {
                        const dateStr = format(day, 'yyyy-MM-dd');
                        const dayShift = employeeShifts.find(s => s.shift_date === dateStr);
                        const dayOfWeek = day.getDay();
                        const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
                        const holiday = isPublicHoliday(day);
                        
                        return (
                          <div 
                            key={idx}
                            className={`text-center rounded text-xs min-h-[40px] flex items-center justify-center
                              ${isWeekend && !dayShift ? 'bg-orange-50 dark:bg-orange-950/20' : ''}
                              ${holiday && !dayShift ? 'bg-red-50 dark:bg-red-950/20' : ''}
                              ${dayShift ? 'bg-primary/20 border border-primary/40 cursor-pointer hover:bg-primary/30' : 'border border-transparent'}
                            `}
                            title={dayShift ? `${dayShift.start_time} - ${dayShift.end_time}` : undefined}
                            onClick={() => {
                              if (dayShift) {
                                setSelectedDate(day);
                              }
                            }}
                          >
                            {dayShift && (
                              <div className="leading-tight">
                                <div className="font-medium">{dayShift.start_time.substring(0, 5)}</div>
                                <div className="text-muted-foreground">{dayShift.end_time.substring(0, 5)}</div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  );
                })}

                {filteredEmployees.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    {selectedDepartment === 'all' ? 'ცვლაში მომუშავე თანამშრომლები ვერ მოიძებნა' : 'ამ დეპარტამენტში ცვლაში მომუშავე თანამშრომლები ვერ მოიძებნა'}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Listing View */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                თვის ცვლების ჩამონათვალი
              </CardTitle>
            </CardHeader>
            <CardContent>
              {shifts.filter(shift => filteredEmployees.some(emp => emp.id === shift.employee_id)).length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {selectedDepartment === 'all' ? 'ამ თვეში ცვლები არ არის დამატებული' : 'ამ დეპარტამენტში ცვლები ვერ მოიძებნა'}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თარიღი</TableHead>
                      <TableHead>კვირის დღე</TableHead>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>პოზიცია</TableHead>
                      <TableHead>ცვლის სახელი</TableHead>
                      <TableHead>დაწყება</TableHead>
                      <TableHead>დასრულება</TableHead>
                      <TableHead className="text-right">შესვენება</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[...shifts]
                      .filter(shift => filteredEmployees.some(emp => emp.id === shift.employee_id))
                      .sort((a, b) => new Date(a.shift_date).getTime() - new Date(b.shift_date).getTime())
                      .map((shift) => {
                        const shiftDate = new Date(shift.shift_date);
                        const dayOfWeek = shiftDate.getDay();
                        const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
                        const holiday = isPublicHoliday(shiftDate);
                        
                        return (
                          <TableRow 
                            key={shift.id}
                            className={`
                              ${isWeekend ? 'bg-orange-50/50 dark:bg-orange-950/20' : ''}
                              ${holiday ? 'bg-red-50/50 dark:bg-red-950/20' : ''}
                            `}
                          >
                            <TableCell className="font-medium">
                              {format(shiftDate, 'dd.MM.yyyy')}
                              {holiday && (
                                <Badge variant="destructive" className="ml-2 text-xs">
                                  დღესასწაული
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              {format(shiftDate, 'EEEE', { locale: ka })}
                            </TableCell>
                            <TableCell className="font-medium">{shift.employees?.full_name}</TableCell>
                            <TableCell className="text-muted-foreground">{shift.employees?.position}</TableCell>
                            <TableCell>
                              {shift.shift_name && <Badge variant="outline">{shift.shift_name}</Badge>}
                            </TableCell>
                            <TableCell>{shift.start_time}</TableCell>
                            <TableCell>
                              {shift.end_time}
                              {shift.end_time < shift.start_time && (
                                <Badge variant="secondary" className="ml-2 text-xs">ღამის</Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-right">{shift.break_duration} წთ</TableCell>
                          </TableRow>
                        );
                      })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shifts" className="mt-6">
          {/* Statistics Section */}
          {showStats && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  ბალანსური ანგარიში - {format(currentMonth, 'MMMM yyyy', { locale: ka })}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-3">თანამშრომელი</th>
                        <th className="text-left p-3">პოზიცია</th>
                        <th className="text-center p-3">
                          <div className="flex items-center justify-center gap-2">
                            <Clock className="h-4 w-4" />
                            მთლიანი საათები
                          </div>
                        </th>
                        <th className="text-center p-3">
                          <div className="flex items-center justify-center gap-2">
                            <Moon className="h-4 w-4" />
                            ღამის ცვლები
                          </div>
                        </th>
                        <th className="text-center p-3">
                          <div className="flex items-center justify-center gap-2">
                            <CalendarDays className="h-4 w-4" />
                            შაბათ-კვირა
                          </div>
                        </th>
                        <th className="text-center p-3">
                          <div className="flex items-center justify-center gap-2">
                            <PartyPopper className="h-4 w-4" />
                            დასვენების დღეები
                          </div>
                        </th>
                        <th className="text-center p-3">სულ ცვლები</th>
                      </tr>
                    </thead>
                    <tbody>
                      {calculateEmployeeStats().map((stat, index) => (
                        <tr key={stat.employeeId} className={index % 2 === 0 ? 'bg-muted/50' : ''}>
                          <td className="p-3 font-medium">{stat.employeeName}</td>
                          <td className="p-3 text-muted-foreground">{stat.position}</td>
                          <td className="p-3 text-center">
                            <Badge variant="secondary" className="font-mono">
                              {stat.totalHours} სთ
                            </Badge>
                          </td>
                          <td className="p-3 text-center">
                            <Badge variant={stat.nightShifts > 0 ? "default" : "outline"}>
                              {stat.nightShifts}
                            </Badge>
                          </td>
                          <td className="p-3 text-center">
                            <Badge variant={stat.weekendShifts > 0 ? "default" : "outline"}>
                              {stat.weekendShifts}
                            </Badge>
                          </td>
                          <td className="p-3 text-center">
                            <Badge variant={stat.holidayShifts > 0 ? "destructive" : "outline"}>
                              {stat.holidayShifts}
                            </Badge>
                          </td>
                          <td className="p-3 text-center text-muted-foreground">
                            {stat.totalShifts}
                          </td>
                        </tr>
                      ))}
                      {calculateEmployeeStats().length === 0 && (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-muted-foreground">
                            არ არის ცვლები ამ თვისთვის
                          </td>
                        </tr>
                      )}
                    </tbody>
                    {calculateEmployeeStats().length > 0 && (
                      <tfoot className="border-t-2 font-bold">
                        <tr className="bg-muted">
                          <td colSpan={2} className="p-3">სულ:</td>
                          <td className="p-3 text-center">
                            <Badge variant="secondary" className="font-mono">
                              {calculateEmployeeStats().reduce((sum, stat) => sum + parseFloat(stat.totalHours), 0).toFixed(1)} სთ
                            </Badge>
                          </td>
                          <td className="p-3 text-center">
                            <Badge variant="default">
                              {calculateEmployeeStats().reduce((sum, stat) => sum + stat.nightShifts, 0)}
                            </Badge>
                          </td>
                          <td className="p-3 text-center">
                            <Badge variant="default">
                              {calculateEmployeeStats().reduce((sum, stat) => sum + stat.weekendShifts, 0)}
                            </Badge>
                          </td>
                          <td className="p-3 text-center">
                            <Badge variant="destructive">
                              {calculateEmployeeStats().reduce((sum, stat) => sum + stat.holidayShifts, 0)}
                            </Badge>
                          </td>
                          <td className="p-3 text-center text-muted-foreground">
                            {calculateEmployeeStats().reduce((sum, stat) => sum + stat.totalShifts, 0)}
                          </td>
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="holiday-work" className="mt-6">
          <div className="space-y-6">
            {/* Year Selector and Export */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Label>წელი:</Label>
                <Select
                  value={reportYear.toString()}
                  onValueChange={(value) => setReportYear(parseInt(value))}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[2024, 2025, 2026].map((year) => (
                      <SelectItem key={year} value={year.toString()}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button
                onClick={() => exportHolidayWorkToExcel(holidayWorkRecords, reportYear)}
                disabled={holidayWorkRecords.length === 0}
                variant="outline"
              >
                <Download className="h-4 w-4 mr-2" />
                Excel ექსპორტი
              </Button>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    სულ ჩანაწერი
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{calculateHolidayWorkStats().totalRecords}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    თანამშრომლები
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{calculateHolidayWorkStats().uniqueEmployees}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    სულ საათები
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{calculateHolidayWorkStats().totalHours}h</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    ოვერთაიმი
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-600">{calculateHolidayWorkStats().totalOvertime}h</div>
                </CardContent>
              </Card>
              <Card className="border-orange-500/50 bg-orange-50 dark:bg-orange-950/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-orange-900 dark:text-orange-100">
                    გაანგარიშებული
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-700 dark:text-orange-400">
                    {calculateHolidayWorkStats().totalCalculated}h
                  </div>
                  <p className="text-xs text-orange-600 dark:text-orange-500 mt-1">
                    კოეფიციენტით
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Report Table */}
            <Card>
              <CardHeader>
                <CardTitle>დასვენების დღეებში მუშაობის დეტალური ანგარიში</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingReport ? (
                  <div className="text-center py-8 text-muted-foreground">
                    იტვირთება...
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>თანამშრომელი</TableHead>
                        <TableHead>პირადი ნომერი</TableHead>
                        <TableHead>თანამდებობა</TableHead>
                        <TableHead>დეპარტამენტი</TableHead>
                        <TableHead>დღესასწაული</TableHead>
                        <TableHead>თარიღი</TableHead>
                        <TableHead>შემოსვლა</TableHead>
                        <TableHead>გასვლა</TableHead>
                        <TableHead className="text-right">საათები</TableHead>
                        <TableHead className="text-right">კოეფ.</TableHead>
                        <TableHead className="text-right">გაანგარიშებული</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {holidayWorkRecords.map((record, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="font-medium">{record.employee_name}</TableCell>
                          <TableCell>{record.employee_number}</TableCell>
                          <TableCell>{record.position}</TableCell>
                          <TableCell>{record.department}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <PartyPopper className="h-4 w-4 text-orange-500" />
                              {record.holiday_name}
                            </div>
                          </TableCell>
                          <TableCell>{format(new Date(record.holiday_date), "dd.MM.yyyy")}</TableCell>
                          <TableCell>{record.check_in}</TableCell>
                          <TableCell>{record.check_out}</TableCell>
                          <TableCell className="text-right font-semibold">
                            {record.total_hours}h
                          </TableCell>
                          <TableCell className="text-right">
                            <Badge variant="outline" className="font-mono">
                              {record.overtime_multiplier}x
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Badge variant="destructive" className="font-semibold">
                              {record.calculated_overtime}h
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                      {holidayWorkRecords.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={11} className="text-center text-muted-foreground py-8">
                            არჩეულ პერიოდში დასვენების დღეებში მუშაობის ჩანაწერები არ მოიძებნა
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar Section */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              კალენდარი
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => date && setSelectedDate(date)}
              month={currentMonth}
              onMonthChange={setCurrentMonth}
              locale={ka}
              className="rounded-md border"
            />
            {canManage && (
              <Dialog open={isDialogOpen} onOpenChange={(open) => {
                setIsDialogOpen(open);
                if (!open) {
                  setEditingShift(null);
                  setSelectedEmployees([]);
                  setShiftName('');
                  setSelectedTemplate('');
                  setRepeatType('once');
                  setRepeatEndDate(undefined);
                  setSelectedWeekDays([]);
                }
              }}>
                <DialogTrigger asChild>
                  <Button className="w-full mt-4 gap-2">
                    <Plus className="h-4 w-4" />
                    ცვლის დამატება
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>
                      {editingShift ? 'ცვლის რედაქტირება' : 'ცვლის დამატება'} - {format(selectedDate, 'PPP', { locale: ka })}
                    </DialogTitle>
                  </DialogHeader>
                  
                  {conflicts.length > 0 && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>კონფლიქტები აღმოჩენილია</AlertTitle>
                      <AlertDescription>
                        <ul className="list-disc list-inside space-y-1 mt-2">
                          {conflicts.map((conflict, idx) => (
                            <li key={idx} className="text-sm">{conflict}</li>
                          ))}
                        </ul>
                        <p className="text-sm mt-3 font-semibold">
                          გთხოვთ შეცვალოთ დრო ან აირჩიოთ სხვა თანამშრომლები
                        </p>
                      </AlertDescription>
                    </Alert>
                  )}

                  <form onSubmit={handleSubmit} className="space-y-4">
                    {!editingShift && (
                      <div className="space-y-4">
                        {/* Department Filter */}
                        <div>
                          <Label>დეპარტამენტი</Label>
                          <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                            <SelectTrigger>
                              <SelectValue placeholder="ყველა დეპარტამენტი" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                              {departments.map((dept) => (
                                <SelectItem key={dept.id} value={dept.name}>
                                  {dept.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        {/* Employee Selection */}
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <Label>თანამშრომლები * <span className="text-xs text-muted-foreground">(მხოლოდ ცვლაში მომუშავეები)</span></Label>
                            <div className="flex items-center gap-2">
                              <Checkbox 
                                id="select-all" 
                                checked={filteredEmployees.length > 0 && selectedEmployees.length === filteredEmployees.length}
                                onCheckedChange={() => {
                                  if (selectedEmployees.length === filteredEmployees.length) {
                                    setSelectedEmployees([]);
                                  } else {
                                    setSelectedEmployees(filteredEmployees.map(e => e.id));
                                  }
                                }}
                              />
                              <Label htmlFor="select-all" className="cursor-pointer">
                                ყველა მონიშვნა
                              </Label>
                            </div>
                          </div>
                          {filteredEmployees.length === 0 ? (
                            <div className="border rounded-md p-4 text-center text-muted-foreground">
                              <p>ცვლაში მომუშავე თანამშრომლები ვერ მოიძებნა</p>
                              <p className="text-xs mt-1">დარწმუნდით, რომ თანამშრომლებს აქვთ "ცვლები" ტიპის გრაფიკი მინიჭებული</p>
                            </div>
                          ) : selectedEmployees.length > 0 ? (
                            <div className="border rounded-md p-3 space-y-2 max-h-48 overflow-y-auto">
                              {filteredEmployees.map((emp) => (
                                <div key={emp.id} className="flex items-center gap-2">
                                  <Checkbox 
                                    id={emp.id}
                                    checked={selectedEmployees.includes(emp.id)}
                                    onCheckedChange={() => toggleEmployeeSelection(emp.id)}
                                  />
                                  <Label htmlFor={emp.id} className="cursor-pointer flex-1">
                                    {emp.full_name} - {emp.position}
                                  </Label>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <Select name="employee_id" required={selectedEmployees.length === 0}>
                              <SelectTrigger>
                                <SelectValue placeholder="აირჩიეთ თანამშრომელი" />
                              </SelectTrigger>
                              <SelectContent>
                                {filteredEmployees.map((emp) => (
                                  <SelectItem key={emp.id} value={emp.id}>
                                    {emp.full_name} - {emp.position}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          )}
                          {selectedEmployees.length > 0 && (
                            <p className="text-sm text-muted-foreground mt-2">
                              მონიშნულია: {selectedEmployees.length} თანამშრომელი
                            </p>
                          )}
                        </div>
                      </div>
                    )}

                    {editingShift && (
                      <div>
                        <Label>თანამშრომელი</Label>
                        <Input 
                          value={editingShift.employees?.full_name || ''}
                          disabled
                          className="bg-muted"
                        />
                      </div>
                    )}

                    <div>
                      <Label htmlFor="shift_template">სწრაფი არჩევანი (შაბლონები)</Label>
                      <Select value={selectedTemplate} onValueChange={handleTemplateChange}>
                        <SelectTrigger>
                          <SelectValue placeholder="აირჩიეთ შაბლონი" />
                        </SelectTrigger>
                        <SelectContent>
                          {templates.length > 0 && (
                            <>
                              {templates.map((template) => (
                                <SelectItem key={template.id} value={template.id}>
                                  ⭐ {template.name} ({template.start_time} - {template.end_time})
                                </SelectItem>
                              ))}
                            </>
                          )}
                          {SHIFT_TEMPLATES.map((template) => (
                            <SelectItem key={template.name} value={template.name}>
                              {template.name} ({template.start} - {template.end})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="shift_name">ცვლის სახელი</Label>
                      <Input
                        id="shift_name"
                        name="shift_name"
                        placeholder="მაგ: დილის ცვლა, საღამოს ცვლა"
                        value={shiftName || selectedTemplate}
                        onChange={(e) => {
                          setShiftName(e.target.value);
                          setSelectedTemplate(e.target.value);
                        }}
                      />
                    </div>

                    {!editingShift && (
                      <div className="space-y-4 border-t pt-4">
                        <div>
                          <Label>განმეორების ტიპი</Label>
                          <Select value={repeatType} onValueChange={(value: any) => setRepeatType(value)}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="once">ერთჯერადი</SelectItem>
                              <SelectItem value="daily">ყოველდღიური</SelectItem>
                              <SelectItem value="weekly">ყოველკვირეული</SelectItem>
                              <SelectItem value="monthly">ყოველთვიური</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {repeatType === 'weekly' && (
                          <div>
                            <Label>კვირის დღეები</Label>
                            <div className="grid grid-cols-7 gap-2 mt-2">
                              {['კვ', 'ორშ', 'სამ', 'ოთხ', 'ხუთ', 'პარ', 'შაბ'].map((day, index) => (
                                <Button
                                  key={index}
                                  type="button"
                                  variant={selectedWeekDays.includes(index) ? 'default' : 'outline'}
                                  size="sm"
                                  onClick={() => toggleWeekDay(index)}
                                  className="h-10"
                                >
                                  {day}
                                </Button>
                              ))}
                            </div>
                            <p className="text-xs text-muted-foreground mt-2">
                              {selectedWeekDays.length === 0 
                                ? 'თუ არცერთი დღე არ არის მონიშნული, განმეორდება იგივე კვირის დღე'
                                : `მონიშნულია: ${selectedWeekDays.length} დღე`}
                            </p>
                          </div>
                        )}

                        {repeatType !== 'once' && (
                          <div>
                            <Label htmlFor="repeat_end_date">განმეორების დასასრული (არასავალდებულო)</Label>
                            <div className="mt-2">
                              <Calendar
                                mode="single"
                                selected={repeatEndDate}
                                onSelect={setRepeatEndDate}
                                locale={ka}
                                className="rounded-md border"
                                disabled={(date) => 
                                  isBefore(date, selectedDate) || isSameDay(date, selectedDate)
                                }
                              />
                            </div>
                            <p className="text-xs text-muted-foreground mt-2">
                              {repeatEndDate 
                                ? `განმეორდება ${format(repeatEndDate, 'PPP', { locale: ka })}-მდე`
                                : 'თუ არ მიუთითებთ, შეიქმნება 4 კვირის განმავლობაში'}
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="start_time">დაწყება *</Label>
                        <Input 
                          id="start_time" 
                          name="start_time" 
                          type="time" 
                          required 
                          value={startTime}
                          onChange={(e) => setStartTime(e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor="end_time">დასრულება *</Label>
                        <Input 
                          id="end_time" 
                          name="end_time" 
                          type="time" 
                          required 
                          value={endTime}
                          onChange={(e) => setEndTime(e.target.value)}
                        />
                        {endTime < startTime && (
                          <p className="text-xs text-muted-foreground mt-1">
                            * ცვლა გრძელდება შემდეგ დღეს
                          </p>
                        )}
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="break_duration">შესვენება (წუთებში)</Label>
                      <Input
                        id="break_duration"
                        name="break_duration"
                        type="number"
                        placeholder="60"
                        min="0"
                        value={breakDuration}
                        onChange={(e) => setBreakDuration(Number(e.target.value))}
                      />
                    </div>

                    <div>
                      <Label htmlFor="notes">შენიშვნები</Label>
                      <Textarea
                        id="notes"
                        name="notes"
                        placeholder="დამატებითი ინფორმაცია..."
                        rows={3}
                      />
                    </div>

                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading 
                        ? (editingShift ? 'განახლება...' : 'დამატება...') 
                        : (editingShift ? 'ცვლის განახლება' : 'ცვლის დამატება')
                      }
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            )}
          </CardContent>
        </Card>

        {/* Shifts List Section */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              ცვლები - {format(selectedDate, 'PPP', { locale: ka })}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {getShiftsForDate(selectedDate).length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                <Users className="h-12 w-12 mb-4 opacity-20" />
                <p>ამ თარიღზე ცვლები არ არის დამატებული</p>
              </div>
            ) : (
              <div className="space-y-3">
                {getShiftsForDate(selectedDate).map((shift) => (
                  <Card key={shift.id} className="border-l-4 border-l-primary">
                    <CardContent className="pt-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold">{shift.employees?.full_name}</h3>
                            {shift.shift_name && (
                              <Badge variant="outline">{shift.shift_name}</Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {shift.employees?.position}
                          </p>
                          <div className="flex items-center gap-4 text-sm">
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              <span>{shift.start_time} - {shift.end_time}</span>
                              {shift.end_time < shift.start_time && (
                                <Badge variant="secondary" className="ml-2">
                                  ღამის
                                </Badge>
                              )}
                            </div>
                            {shift.break_duration > 0 && (
                              <span className="text-muted-foreground">
                                შესვენება: {shift.break_duration} წთ
                              </span>
                            )}
                          </div>
                          {shift.notes && (
                            <p className="text-sm text-muted-foreground mt-2 italic">
                              {shift.notes}
                            </p>
                          )}
                        </div>
                        {canManage && (
                          <div className="flex flex-wrap gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEditShift(shift)}
                              className="hover:bg-primary/10"
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-destructive hover:text-destructive"
                              onClick={() => handleDeleteShift(shift.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Month Overview */}
      <Card>
        <CardHeader>
          <CardTitle>თვის მიმოხილვა - {format(currentMonth, 'MMMM yyyy', { locale: ka })}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {['ორ', 'სამ', 'ოთხ', 'ხუთ', 'პარ', 'შაბ', 'კვი'].map(day => (
              <div key={day} className="text-center font-semibold text-sm p-2">
                {day}
              </div>
            ))}
            {getDaysInMonth().map((day, idx) => {
              const dayShifts = getShiftsForDate(day);
              const isSelected = isSameDay(day, selectedDate);
              const holiday = isPublicHoliday(day);
              
              return (
                <button
                  key={idx}
                  onClick={() => setSelectedDate(day)}
                  className={`
                    relative p-2 rounded-md border text-sm transition-colors
                    ${isSelected ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-accent'}
                    ${dayShifts.length > 0 ? 'border-primary/50' : ''}
                    ${holiday ? 'bg-red-50 dark:bg-red-950 border-red-300 dark:border-red-700' : ''}
                  `}
                >
                  <div className="font-medium">{format(day, 'd')}</div>
                  {holiday && (
                    <div className="absolute top-0 right-0 text-xs">
                      <PartyPopper className="h-3 w-3 text-red-500" />
                    </div>
                  )}
                  {dayShifts.length > 0 && (
                    <div className="absolute bottom-1 right-1">
                      <Badge variant={holiday ? "destructive" : "secondary"} className="h-5 w-5 p-0 flex items-center justify-center text-xs">
                        {dayShifts.length}
                      </Badge>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
