import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Plus, LogOut, Trash2, Laptop, Key, BookOpen, MessageSquare, Wallet, FileText } from "lucide-react";

interface OffProcess {
  id: string;
  employee_id: string;
  user_id: string | null;
  last_day: string;
  reason: string | null;
  status: string;
  notes: string | null;
  created_at: string;
}

interface OffTask {
  id: string;
  process_id: string;
  title: string;
  description: string | null;
  category: string;
  due_date: string | null;
  status: string;
  notes: string | null;
  order_index: number;
}

interface Employee {
  id: string;
  user_id: string | null;
  first_name: string;
  last_name: string;
}

const CATEGORIES = [
  { value: "equipment", ka: "აღჭურვილობის დაბრუნება", en: "Equipment Return", icon: Laptop, color: "hsl(217 91% 60%)" },
  { value: "access", ka: "წვდომების მოხსნა", en: "Access Revocation", icon: Key, color: "hsl(340 75% 55%)" },
  { value: "knowledge", ka: "ცოდნის გადაცემა", en: "Knowledge Transfer", icon: BookOpen, color: "hsl(45 93% 47%)" },
  { value: "exit_interview", ka: "გასვლის ინტერვიუ", en: "Exit Interview", icon: MessageSquare, color: "hsl(280 84% 60%)" },
  { value: "final_payment", ka: "ბოლო ანაზღაურება", en: "Final Payment", icon: Wallet, color: "hsl(142 71% 45%)" },
  { value: "documents", ka: "დოკუმენტები", en: "Documents", icon: FileText, color: "hsl(25 95% 53%)" },
];

const REASONS = [
  { value: "resignation", ka: "გადადგომა", en: "Resignation" },
  { value: "termination", ka: "გათავისუფლება", en: "Termination" },
  { value: "retirement", ka: "პენსიონერობა", en: "Retirement" },
  { value: "end_of_contract", ka: "კონტრაქტის დასასრული", en: "End of Contract" },
];

const DEFAULT_TASKS = [
  { title: "ლეპტოპის დაბრუნება", titleEn: "Return laptop", category: "equipment" },
  { title: "ID ბარათისა და გასაღების ჩაბარება", titleEn: "Return ID card & keys", category: "equipment" },
  { title: "ელფოსტის წვდომის შეჩერება", titleEn: "Revoke email access", category: "access" },
  { title: "VPN და სისტემური წვდომების მოხსნა", titleEn: "Remove VPN & system access", category: "access" },
  { title: "მიმდინარე პროექტების გადაცემა", titleEn: "Hand over current projects", category: "knowledge" },
  { title: "დოკუმენტაციის განახლება", titleEn: "Update documentation", category: "knowledge" },
  { title: "გასვლის ინტერვიუს ჩატარება", titleEn: "Conduct exit interview", category: "exit_interview" },
  { title: "გამოუყენებელი შვებულების ანაზღაურება", titleEn: "Pay unused vacation", category: "final_payment" },
  { title: "ბოლო ხელფასი + ანგარიშსწორება", titleEn: "Final salary + settlement", category: "final_payment" },
  { title: "შრომის წიგნაკი / ცნობების მომზადება", titleEn: "Prepare reference letters", category: "documents" },
];

export default function Offboarding() {
  const { language } = useLanguage();
  const { toast } = useToast();
  const tr = (ka: string, en: string) => (language === "en" ? en : ka);

  const [processes, setProcesses] = useState<OffProcess[]>([]);
  const [tasks, setTasks] = useState<Record<string, OffTask[]>>({});
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [createOpen, setCreateOpen] = useState(false);
  const [empId, setEmpId] = useState("");
  const [lastDay, setLastDay] = useState("");
  const [reason, setReason] = useState("resignation");
  const [notes, setNotes] = useState("");

  const load = async () => {
    const procsRes = await supabase.from("offboarding_processes" as any).select("*").order("created_at", { ascending: false });
    const empsRes = await (supabase.from("employees") as any).select("id, user_id, first_name, last_name").eq("is_active", true).limit(500);
    const procs = procsRes.data;
    const emps = empsRes.data;
    if (procs) {
      setProcesses(procs as any);
      const ids = (procs as any).map((p: any) => p.id);
      if (ids.length) {
        const { data: t } = await supabase
          .from("offboarding_tasks" as any)
          .select("*")
          .in("process_id", ids)
          .order("order_index");
        if (t) {
          const grouped: Record<string, OffTask[]> = {};
          (t as any[]).forEach((it) => {
            grouped[it.process_id] = grouped[it.process_id] || [];
            grouped[it.process_id].push(it);
          });
          setTasks(grouped);
        }
      }
    }
    if (emps) setEmployees(emps as any);
  };

  useEffect(() => {
    load();
  }, []);

  const createProcess = async () => {
    if (!empId || !lastDay) return;
    const emp = employees.find((e) => e.id === empId);
    const { data: proc, error } = await supabase
      .from("offboarding_processes" as any)
      .insert({
        employee_id: empId,
        user_id: emp?.user_id ?? null,
        last_day: lastDay,
        reason,
        notes: notes || null,
      } as any)
      .select()
      .single();
    if (error || !proc) {
      toast({ title: tr("შეცდომა", "Error"), variant: "destructive" });
      return;
    }
    // Seed default tasks
    const taskRows = DEFAULT_TASKS.map((t, i) => ({
      process_id: (proc as any).id,
      title: language === "en" ? t.titleEn : t.title,
      category: t.category,
      order_index: i,
    }));
    await supabase.from("offboarding_tasks" as any).insert(taskRows as any);
    toast({ title: tr("შექმნილია", "Created") });
    setCreateOpen(false);
    setEmpId("");
    setLastDay("");
    setNotes("");
    load();
  };

  const toggleTask = async (task: OffTask) => {
    const newStatus = task.status === "completed" ? "pending" : "completed";
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase
      .from("offboarding_tasks" as any)
      .update({
        status: newStatus,
        completed_at: newStatus === "completed" ? new Date().toISOString() : null,
        completed_by: newStatus === "completed" ? user?.id : null,
      } as any)
      .eq("id", task.id);
    if (error) { toast({ title: tr("შეცდომა: ცვლილება ვერ შეინახა", "Error: change not saved"), variant: "destructive" }); return; }
    load();
  };

  const removeProcess = async (id: string) => {
    if (!confirm(tr("წავშალოთ?", "Delete?"))) return;
    const { error } = await supabase.from("offboarding_processes" as any).delete().eq("id", id);
    if (error) { toast({ title: tr("შეცდომა: ცვლილება ვერ შეინახა", "Error: change not saved"), variant: "destructive" }); return; }
    load();
  };

  const completeProcess = async (id: string) => {
    const { error } = await supabase
      .from("offboarding_processes" as any)
      .update({ status: "completed", completed_at: new Date().toISOString() } as any)
      .eq("id", id);
    if (error) { toast({ title: tr("შეცდომა: ცვლილება ვერ შეინახა", "Error: change not saved"), variant: "destructive" }); return; }
    toast({ title: tr("დასრულდა", "Completed") });
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <LogOut className="h-8 w-8 text-primary" />
            {tr("ოფბორდინგი", "Offboarding")}
          </h1>
          <p className="text-muted-foreground mt-1">
            {tr("გასვლის Checklist: აღჭურვილობა, წვდომები, ცოდნის გადაცემა", "Exit checklist: equipment, access, knowledge transfer")}
          </p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button variant="gradient">
              <Plus className="mr-2 h-4 w-4" />
              {tr("ახალი პროცესი", "New Process")}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{tr("ახალი ოფბორდინგი", "New Offboarding")}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>{tr("თანამშრომელი", "Employee")}</Label>
                <Select value={empId} onValueChange={setEmpId}>
                  <SelectTrigger><SelectValue placeholder={tr("აირჩიე", "Select")} /></SelectTrigger>
                  <SelectContent>
                    {employees.map((e) => (
                      <SelectItem key={e.id} value={e.id}>{e.first_name} {e.last_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>{tr("ბოლო დღე", "Last Day")}</Label>
                <Input type="date" value={lastDay} onChange={(e) => setLastDay(e.target.value)} />
              </div>
              <div>
                <Label>{tr("მიზეზი", "Reason")}</Label>
                <Select value={reason} onValueChange={setReason}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {REASONS.map((r) => (
                      <SelectItem key={r.value} value={r.value}>{tr(r.ka, r.en)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>{tr("შენიშვნა", "Notes")}</Label>
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={createProcess}>{tr("შექმნა", "Create")}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {processes.length === 0 && (
        <Card><CardContent className="py-12 text-center text-muted-foreground">
          {tr("აქტიური ოფბორდინგი არ არის", "No active offboardings")}
        </CardContent></Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {processes.map((p) => {
          const procTasks = tasks[p.id] || [];
          const completed = procTasks.filter((t) => t.status === "completed").length;
          const pct = procTasks.length ? Math.round((completed / procTasks.length) * 100) : 0;
          const emp = employees.find((e) => e.id === p.employee_id);
          const reasonLabel = REASONS.find((r) => r.value === p.reason);
          return (
            <Card key={p.id} className={p.status === "completed" ? "opacity-70" : ""}>
              <CardHeader>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <CardTitle>{emp ? `${emp.first_name} ${emp.last_name}` : p.employee_id.slice(0, 8)}</CardTitle>
                    <div className="flex gap-2 mt-1 flex-wrap">
                      <Badge variant="outline">{tr("ბოლო დღე:", "Last day:")} {p.last_day}</Badge>
                      {reasonLabel && <Badge variant="secondary">{tr(reasonLabel.ka, reasonLabel.en)}</Badge>}
                      <Badge variant={p.status === "completed" ? "default" : "outline"}>{p.status}</Badge>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => removeProcess(p.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <div className="mt-3">
                  <div className="flex justify-between text-xs mb-1">
                    <span>{tr("პროგრესი", "Progress")}</span>
                    <span>{completed}/{procTasks.length} ({pct}%)</span>
                  </div>
                  <Progress value={pct} />
                </div>
              </CardHeader>
              <CardContent className="space-y-2 max-h-[400px] overflow-y-auto">
                {CATEGORIES.map((cat) => {
                  const catTasks = procTasks.filter((t) => t.category === cat.value);
                  if (catTasks.length === 0) return null;
                  return (
                    <div key={cat.value}>
                      <div className="flex items-center gap-2 mt-3 mb-1">
                        <cat.icon className="h-4 w-4" style={{ color: cat.color }} />
                        <span className="text-sm font-semibold">{tr(cat.ka, cat.en)}</span>
                      </div>
                      {catTasks.map((t) => (
                        <div key={t.id} className="flex items-center gap-2 pl-6 py-1">
                          <Checkbox
                            checked={t.status === "completed"}
                            onCheckedChange={() => toggleTask(t)}
                          />
                          <span className={`text-sm ${t.status === "completed" ? "line-through text-muted-foreground" : ""}`}>
                            {t.title}
                          </span>
                        </div>
                      ))}
                    </div>
                  );
                })}
                {p.status !== "completed" && pct === 100 && (
                  <Button className="w-full mt-4" variant="success" onClick={() => completeProcess(p.id)}>
                    {tr("პროცესის დახურვა", "Close process")}
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
