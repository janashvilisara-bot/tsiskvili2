import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Cookie,
  Shield,
  Server,
  Globe,
  Settings,
} from 'lucide-react';
import { PageTransition } from '@/components/PageTransition';

const CookiePolicy = () => {
  return (
    <PageTransition>
      <div className="max-w-4xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <Cookie className="h-16 w-16 mx-auto text-primary" />
          <h1 className="text-4xl font-bold">ქუქი-ფაილების პოლიტიკა</h1>
          <p className="text-muted-foreground">Cookie Policy - Talent OS</p>
          <p className="text-sm text-muted-foreground">ბოლო განახლება: 19 ივნისი, 2026</p>
        </div>

        <Card className="bg-muted/30 border-muted">
          <CardContent className="py-6">
            <p className="text-sm text-muted-foreground leading-relaxed">
              ტექნიკური და უსაფრთხოების სპეციფიკიდან გამომდინარე, Talent OS არ იყენებს მარკეტინგულ ან სარეკლამო ქუქი-ფაილებს სისტემის შიგნით. ჩვენ ვიყენებთ მხოლოდ იმ ფაილებს, რომლებიც აუცილებელია პლატფორმის სტაბილური და უსაფრთხო მუშაობისთვის.
            </p>
          </CardContent>
        </Card>

        {/* Section 1 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Cookie className="h-5 w-5 text-primary" />
              1. რა ტიპის ქუქი-ფაილებს ვიყენებთ?
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
              <p className="font-semibold text-foreground">ა) მკაცრად აუცილებელი (Strictly Necessary) ქუქი-ფაილები</p>
              <p>
                ეს ფაილები უზრუნველყოფენ სისტემის ძირითად ფუნქციონირებას და უსაფრთხოების მექანიზმებს. მათ გარეშე SaaS პლატფორმა ვერ იმუშავებს.
              </p>
              <ul className="list-disc ml-5 space-y-2">
                <li><strong>ავტორიზაციის ქუქი (Session Cookie):</strong> აიდენტიფიცირებს დამსაქმებლის ავტორიზებულ სესიას. მისი წყალობით სისტემამ იცის, რომ თქვენ ხართ შესული კონკრეტულ სამუშაო სივრცეში და გვერდიდან გვერდზე გადასვლისას ხელახლა არ გთხოვთ პაროლს. (იშლება ბრაუზერის დახურვისას).</li>
                <li><strong>უსაფრთხოების ქუქი (CSRF Token):</strong> იცავს პლატფორმას ე.წ. „სესიის გატაცებისა" და ვებ-გვერდზე გარედან განხორციელებული არასანქცირებული მოთხოვნებისგან.</li>
                <li><strong>დატვირთვის ბალანსირება (Load Balancing):</strong> ეხმარება Lovable პლატფორმის ევროპულ სერვერებს შორის ტრაფიკის სწორად განაწილებაში, რათა HR პანელმა შეფერხების გარეშე იმუშაოს.</li>
              </ul>

              <p className="font-semibold text-foreground mt-4">ბ) ფუნქციონალური (Functional) ქუქი-ფაილები</p>
              <p>
                გამოიყენება მომხმარებლის ინტერფეისის პარამეტრების დასამახსოვრებლად.
              </p>
              <ul className="list-disc ml-5 space-y-2">
                <li><strong>ენის პარამეტრი:</strong> იმახსოვრებს, თუ რომელი ენა გაქვთ არჩეული HR პანელში (ქართული/ინგლისური).</li>
                <li><strong>ცხრილებისა და ფილტრების ქეში:</strong> იმახსოვრებს თანამშრომელთა სიაში თქვენ მიერ ბოლოს გამოყენებულ ფილტრებს ან გვერდზე ნაჩვენები ჩანაწერების რაოდენობას, რათა მუშაობა უფრო კომფორტული იყოს.</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Section 2 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Globe className="h-5 w-5 text-primary" />
              2. მესამე მხარის ქუქი-ფაილები
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
              <p>
                Talent OS-ის სამუშაო გარემოში მესამე მხარის ქუქი-ფაილები მინიმუმამდეა დაყვანილი. ისინი შეიძლება გააქტიურდეს მხოლოდ იმ შემთხვევაში, თუ ორგანიზაცია იყენებს გარე ავტორიზაციის სისტემებს (მაგ. Microsoft Azure AD, Google Workspace SSO) სისტემაში შესასვლელად.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Section 3 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Settings className="h-5 w-5 text-primary" />
              3. როგორ ვმართოთ ქუქი-ფაილები?
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
              <p>
                ვინაიდან Talent OS იყენებს მხოლოდ აუცილებელ და ფუნქციონალურ ფაილებს, მათი გამორთვა ბრაუზერის პარამეტრებიდან გამოიწვევს პლატფორმიდან ავტომატურ გამოსვლას (Logout) და სისტემის მუშაობის სრულ ბლოკირებას.
              </p>
              <p>
                უსაფრთხოების სტანდარტების შესასრულებლად, რეკომენდებულია კორპორატიულმა მომხმარებლებმა არ გამორთონ აუცილებელი ქუქი-ფაილები ამ პლატფორმისთვის.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageTransition>
  );
};

export default CookiePolicy;
