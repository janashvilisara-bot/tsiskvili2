import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RotateCcw, Trash2, AlertTriangle, Users, FileText, Calendar, Briefcase } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { restoreRecord, permanentDelete, SoftDeletableTable } from '@/lib/softDelete';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { DeleteConfirmDialog } from '@/components/org-structure/DeleteConfirmDialog';
import { useAuth } from '@/contexts/AuthContext';
import { Navigate } from 'react-router-dom';

interface DeletedRecord {
  id: string;
  deleted_at: string;
  [key: string]: any;
}

export default function DeletedRecords() {
  const { userRole } = useAuth();
  const [activeTab, setActiveTab] = useState<SoftDeletableTable>('employees');
  const [deletedRecords, setDeletedRecords] = useState<DeletedRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    type: 'restore' | 'permanent';
    recordId: string;
    recordName: string;
  }>({ open: false, type: 'restore', recordId: '', recordName: '' });

  // Only admin and HR can access
  if (userRole !== 'admin' && userRole !== 'hr_manager') {
    return <Navigate to="/employee-portal" replace />;
  }

  const fetchDeletedRecords = async (table: SoftDeletableTable) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from(table)
        .select('*')
        .not('deleted_at', 'is', null)
        .order('deleted_at', { ascending: false });

      if (error) throw error;
      setDeletedRecords(data || []);
    } catch (err) {
      console.error('Error fetching deleted records:', err);
      toast.error('წაშლილი ჩანაწერების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDeletedRecords(activeTab);
  }, [activeTab]);

  const handleRestore = async (recordId: string) => {
    const success = await restoreRecord(activeTab, recordId);
    if (success) {
      toast.success('ჩანაწერი აღდგენილია');
      fetchDeletedRecords(activeTab);
    } else {
      toast.error('აღდგენა ვერ მოხერხდა');
    }
    setConfirmDialog({ ...confirmDialog, open: false });
  };

  const handlePermanentDelete = async (recordId: string) => {
    const success = await permanentDelete(activeTab, recordId);
    if (success) {
      toast.success('ჩანაწერი სამუდამოდ წაიშალა');
      fetchDeletedRecords(activeTab);
    } else {
      toast.error('წაშლა ვერ მოხერხდა');
    }
    setConfirmDialog({ ...confirmDialog, open: false });
  };

  const getRecordDisplayName = (record: DeletedRecord): string => {
    switch (activeTab) {
      case 'employees':
        return record.full_name || record.email || record.id;
      case 'documents':
        return record.title || record.id;
      case 'leave_requests':
        return `შვებულება ${record.start_date} - ${record.end_date}`;
      case 'contracts':
        return record.contract_number || `კონტრაქტი ${record.id.slice(0, 8)}`;
      case 'candidates':
        return record.full_name || record.email || record.id;
      case 'attendance':
        return `დასწრება ${record.date}`;
      default:
        return record.id;
    }
  };

  const getTableIcon = (table: SoftDeletableTable) => {
    switch (table) {
      case 'employees':
        return <Users className="h-4 w-4" />;
      case 'documents':
        return <FileText className="h-4 w-4" />;
      case 'leave_requests':
        return <Calendar className="h-4 w-4" />;
      case 'contracts':
        return <Briefcase className="h-4 w-4" />;
      case 'candidates':
        return <Users className="h-4 w-4" />;
      case 'attendance':
        return <Calendar className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const tabs: { value: SoftDeletableTable; label: string }[] = [
    { value: 'employees', label: 'თანამშრომლები' },
    { value: 'documents', label: 'დოკუმენტები' },
    { value: 'leave_requests', label: 'შვებულებები' },
    { value: 'contracts', label: 'კონტრაქტები' },
    { value: 'candidates', label: 'კანდიდატები' },
    { value: 'attendance', label: 'დასწრება' },
  ];

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <AlertTriangle className="h-8 w-8 text-amber-500" />
          <div>
            <h1 className="text-3xl font-bold">წაშლილი ჩანაწერები</h1>
            <p className="text-muted-foreground">
              აღადგინეთ შეცდომით წაშლილი ჩანაწერები ან წაშალეთ სამუდამოდ (GDPR)
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Soft-Deleted Records</CardTitle>
            <CardDescription>
              წაშლილი ჩანაწერები შენახულია 90 დღის განმავლობაში აღდგენის შესაძლებლობით
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as SoftDeletableTable)}>
              <TabsList className="grid grid-cols-3 lg:grid-cols-6 mb-4">
                {tabs.map((tab) => (
                  <TabsTrigger key={tab.value} value={tab.value} className="flex items-center gap-2">
                    {getTableIcon(tab.value)}
                    <span className="hidden sm:inline">{tab.label}</span>
                  </TabsTrigger>
                ))}
              </TabsList>

              <TabsContent value={activeTab}>
                {loading ? (
                  <div className="text-center py-8 text-muted-foreground">იტვირთება...</div>
                ) : deletedRecords.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    წაშლილი ჩანაწერები არ მოიძებნა
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ჩანაწერი</TableHead>
                        <TableHead>წაშლის თარიღი</TableHead>
                        <TableHead>სტატუსი</TableHead>
                        <TableHead className="text-right">მოქმედებები</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {deletedRecords.map((record) => (
                        <TableRow key={record.id}>
                          <TableCell className="font-medium">
                            {getRecordDisplayName(record)}
                          </TableCell>
                          <TableCell>
                            {format(new Date(record.deleted_at), 'dd.MM.yyyy HH:mm')}
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary">წაშლილი</Badge>
                          </TableCell>
                          <TableCell className="text-right space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setConfirmDialog({
                                open: true,
                                type: 'restore',
                                recordId: record.id,
                                recordName: getRecordDisplayName(record)
                              })}
                            >
                              <RotateCcw className="h-4 w-4 mr-1" />
                              აღდგენა
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => setConfirmDialog({
                                open: true,
                                type: 'permanent',
                                recordId: record.id,
                                recordName: getRecordDisplayName(record)
                              })}
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              სამუდამო წაშლა
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <DeleteConfirmDialog
          open={confirmDialog.open}
          onOpenChange={(open) => setConfirmDialog({ ...confirmDialog, open })}
          onConfirm={() => {
            if (confirmDialog.type === 'restore') {
              handleRestore(confirmDialog.recordId);
            } else {
              handlePermanentDelete(confirmDialog.recordId);
            }
          }}
          title={confirmDialog.type === 'restore' ? 'ჩანაწერის აღდგენა' : 'სამუდამო წაშლა'}
          description={
            confirmDialog.type === 'restore'
              ? 'დარწმუნებული ხართ, რომ გსურთ ამ ჩანაწერის აღდგენა?'
              : 'დარწმუნებული ხართ, რომ გსურთ ამ ჩანაწერის სამუდამოდ წაშლა? ეს მოქმედება შეუქცევადია!'
          }
          itemName={confirmDialog.recordName}
        />
      </div>
    </>
  );
}
