import { useState, useMemo, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ResponsiveTable, MobileCard, MobileCardRow } from "@/components/ResponsiveTable";
import { TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Plus, Edit2, Trash2, DollarSign, Calendar, Filter, Upload, Download, CheckCircle, XCircle, Clock, BarChart3 } from "lucide-react";
import { format } from "date-fns";
import { XLSX } from '@/lib/xlsxCompat';
import { Badge } from "@/components/ui/badge";
import { PieChart, Pie, Cell, LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

interface BudgetExpense {
  id: string;
  budget_plan_id: string | null;
  expense_date: string;
  amount: number;
  category: string;
  description: string | null;
  department_id: string | null;
  fiscal_year: number;
  fiscal_quarter: number | null;
  fiscal_month: number | null;
  status: string;
  approval_required: boolean;
  approved_by: string | null;
  approved_at: string | null;
  rejection_reason: string | null;
  created_at: string;
  department_name?: string;
}

interface Department {
  id: string;
  name: string;
}

const expenseCategories = [
  "ხელფასები",
  "ბონუსები",
  "ტრენინგები",
  "ოფისის ხარჯები",
  "მარკეტინგი",
  "IT და ტექნოლოგია",
  "მგზავრობა",
  "კომუნალური",
  "სხვა",
];

export default function BudgetExpenses() {
  const { toast } = useToast();
  const [expenses, setExpenses] = useState<BudgetExpense[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<BudgetExpense | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  
  const [formData, setFormData] = useState({
    expense_date: format(new Date(), "yyyy-MM-dd"),
    amount: "",
    category: "",
    description: "",
    department_id: "",
    fiscal_year: new Date().getFullYear(),
    fiscal_quarter: Math.ceil((new Date().getMonth() + 1) / 3),
    fiscal_month: new Date().getMonth() + 1,
  });

  const [filters, setFilters] = useState({
    category: "all",
    department: "all",
    year: new Date().getFullYear().toString(),
    quarter: "all",
    status: "all",
  });
  
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [rejectingExpense, setRejectingExpense] = useState<BudgetExpense | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");
  const [showAnalytics, setShowAnalytics] = useState(false);

  useEffect(() => {
    fetchUserRole();
    fetchExpenses();
    fetchDepartments();
  }, []);

  const fetchUserRole = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .single();

    setUserRole(data?.role || null);
  };

  const fetchExpenses = async () => {
    const { data, error } = await supabase
      .from("budget_expenses")
      .select(`
        *,
        departments!budget_expenses_department_id_fkey(name)
      `)
      .order("expense_date", { ascending: false });

    if (error) {
      toast({
        title: "შეცდომა",
        description: "ხარჯების ჩატვირთვა ვერ მოხერხდა",
        variant: "destructive",
      });
      return;
    }

    const formattedExpenses = data.map((expense) => ({
      ...expense,
      department_name: expense.departments?.name,
    }));

    setExpenses(formattedExpenses);
  };

  const fetchDepartments = async () => {
    const { data, error } = await supabase
      .from("departments")
      .select("id, name")
      .eq("is_active", true)
      .order("name");

    if (error) {
      toast({
        title: "შეცდომა",
        description: "დეპარტამენტების ჩატვირთვა ვერ მოხერხდა",
        variant: "destructive",
      });
      return;
    }

    setDepartments(data || []);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const expenseData = {
      expense_date: formData.expense_date,
      amount: parseFloat(formData.amount),
      category: formData.category,
      description: formData.description || null,
      department_id: formData.department_id || null,
      fiscal_year: formData.fiscal_year,
      fiscal_quarter: formData.fiscal_quarter,
      fiscal_month: formData.fiscal_month,
      created_by: user.id,
    };

    if (editingExpense) {
      const { error } = await supabase
        .from("budget_expenses")
        .update(expenseData)
        .eq("id", editingExpense.id);

      if (error) {
        toast({
          title: "შეცდომა",
          description: "ხარჯის განახლება ვერ მოხერხდა",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "წარმატება",
        description: "ხარჯი წარმატებით განახლდა",
      });
    } else {
      const { error } = await supabase
        .from("budget_expenses")
        .insert([expenseData]);

      if (error) {
        toast({
          title: "შეცდომა",
          description: "ხარჯის დამატება ვერ მოხერხდა",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "წარმატება",
        description: "ხარჯი წარმატებით დაემატა",
      });
    }

    setIsDialogOpen(false);
    resetForm();
    fetchExpenses();
  };

  const handleEdit = (expense: BudgetExpense) => {
    setEditingExpense(expense);
    setFormData({
      expense_date: expense.expense_date,
      amount: expense.amount.toString(),
      category: expense.category,
      description: expense.description || "",
      department_id: expense.department_id || "",
      fiscal_year: expense.fiscal_year,
      fiscal_quarter: expense.fiscal_quarter || Math.ceil((new Date().getMonth() + 1) / 3),
      fiscal_month: expense.fiscal_month || new Date().getMonth() + 1,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("დარწმუნებული ხართ, რომ გსურთ ამ ხარჯის წაშლა?")) return;

    const { error } = await supabase
      .from("budget_expenses")
      .delete()
      .eq("id", id);

    if (error) {
      toast({
        title: "შეცდომა",
        description: "ხარჯის წაშლა ვერ მოხერხდა",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "წარმატება",
      description: "ხარჯი წარმატებით წაიშალა",
    });

    fetchExpenses();
  };

  const resetForm = () => {
    setEditingExpense(null);
    setFormData({
      expense_date: format(new Date(), "yyyy-MM-dd"),
      amount: "",
      category: "",
      description: "",
      department_id: "",
      fiscal_year: new Date().getFullYear(),
      fiscal_quarter: Math.ceil((new Date().getMonth() + 1) / 3),
      fiscal_month: new Date().getMonth() + 1,
    });
  };

  const filteredExpenses = useMemo(() => {
    return expenses.filter((expense) => {
      if (filters.category !== "all" && expense.category !== filters.category) return false;
      if (filters.department !== "all" && expense.department_id !== filters.department) return false;
      if (filters.year !== "all" && expense.fiscal_year.toString() !== filters.year) return false;
      if (filters.quarter !== "all" && expense.fiscal_quarter?.toString() !== filters.quarter) return false;
      if (filters.status !== "all" && expense.status !== filters.status) return false;
      return true;
    });
  }, [expenses, filters]);

  const pendingExpenses = useMemo(() => {
    return expenses.filter(e => e.status === "pending" && e.approval_required);
  }, [expenses]);

  const totalExpenses = useMemo(() => {
    return filteredExpenses
      .filter(e => e.status === "approved")
      .reduce((sum, expense) => sum + Number(expense.amount), 0);
  }, [filteredExpenses]);

  const handleApproveExpense = async (expense: BudgetExpense) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { error } = await supabase
      .from("budget_expenses")
      .update({
        status: "approved",
        approved_by: user.id,
        approved_at: new Date().toISOString(),
      })
      .eq("id", expense.id);

    if (error) {
      toast({
        title: "შეცდომა",
        description: "ხარჯის დამტკიცება ვერ მოხერხდა",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "წარმატება",
      description: "ხარჯი წარმატებით დამტკიცდა",
    });

    fetchExpenses();
  };

  const handleRejectExpense = async () => {
    if (!rejectingExpense || !rejectionReason.trim()) {
      toast({
        title: "შეცდომა",
        description: "გთხოვთ მიუთითოთ უარყოფის მიზეზი",
        variant: "destructive",
      });
      return;
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { error } = await supabase
      .from("budget_expenses")
      .update({
        status: "rejected",
        approved_by: user.id,
        approved_at: new Date().toISOString(),
        rejection_reason: rejectionReason,
      })
      .eq("id", rejectingExpense.id);

    if (error) {
      toast({
        title: "შეცდომა",
        description: "ხარჯის უარყოფა ვერ მოხერხდა",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "წარმატება",
      description: "ხარჯი უარყოფილია",
    });

    setIsRejectDialogOpen(false);
    setRejectingExpense(null);
    setRejectionReason("");
    fetchExpenses();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return (
          <Badge variant="default" className="bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20">
            <CheckCircle className="h-3 w-3 mr-1" />
            დამტკიცებული
          </Badge>
        );
      case "pending":
        return (
          <Badge variant="default" className="bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20">
            <Clock className="h-3 w-3 mr-1" />
            მოლოდინში
          </Badge>
        );
      case "rejected":
        return (
          <Badge variant="destructive">
            <XCircle className="h-3 w-3 mr-1" />
            უარყოფილი
          </Badge>
        );
      default:
        return null;
    }
  };

  // Analytics Data Preparation
  const categoryData = useMemo(() => {
    const grouped = filteredExpenses.reduce((acc, expense) => {
      const category = expense.category;
      if (!acc[category]) {
        acc[category] = 0;
      }
      acc[category] += Number(expense.amount);
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(grouped).map(([name, value]) => ({
      name,
      value: Number(value.toFixed(2))
    }));
  }, [filteredExpenses]);

  const timelineData = useMemo(() => {
    const grouped = filteredExpenses.reduce((acc, expense) => {
      const month = new Date(expense.expense_date).toLocaleDateString('ka-GE', { year: 'numeric', month: 'short' });
      if (!acc[month]) {
        acc[month] = 0;
      }
      acc[month] += Number(expense.amount);
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(grouped)
      .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
      .map(([month, amount]) => ({
        month,
        amount: Number(amount.toFixed(2))
      }));
  }, [filteredExpenses]);

  const departmentData = useMemo(() => {
    const grouped = filteredExpenses.reduce((acc, expense) => {
      const deptName = departments.find(d => d.id === expense.department_id)?.name || 'უცნობი';
      if (!acc[deptName]) {
        acc[deptName] = 0;
      }
      acc[deptName] += Number(expense.amount);
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(grouped).map(([name, amount]) => ({
      name,
      amount: Number(amount.toFixed(2))
    }));
  }, [filteredExpenses, departments]);

  const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

  const handleExportTemplate = () => {
    const template = [
      {
        თარიღი: "2025-01-15",
        თანხა: 1000,
        კატეგორია: "ხელფასები",
        აღწერა: "მაგალითი",
        დეპარტამენტი: departments[0]?.name || "",
        წელი: 2025,
        კვარტალი: 1,
        თვე: 1,
      },
    ];

    const ws = XLSX.utils.json_to_sheet(template);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Template");
    XLSX.writeFile(wb, "budget_expenses_template.xlsx");

    toast({
      title: "შაბლონი ჩამოტვირთულია",
      description: "გამოიყენეთ ეს შაბლონი ხარჯების იმპორტისთვის",
    });
  };

  const handleImportExcel = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsImporting(true);

    try {
      const data = await file.arrayBuffer();
      const workbook = await XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "შეცდომა",
          description: "მომხმარებელი არ არის ავტორიზებული",
          variant: "destructive",
        });
        return;
      }

      const expensesToImport = jsonData.map((row: any) => {
        // Find department by name
        const dept = departments.find(d => d.name === row["დეპარტამენტი"] || d.name === row["department"]);
        
        return {
          expense_date: row["თარიღი"] || row["date"] || format(new Date(), "yyyy-MM-dd"),
          amount: parseFloat(row["თანხა"] || row["amount"] || 0),
          category: row["კატეგორია"] || row["category"] || "სხვა",
          description: row["აღწერა"] || row["description"] || null,
          department_id: dept?.id || null,
          fiscal_year: parseInt(row["წელი"] || row["year"] || new Date().getFullYear()),
          fiscal_quarter: parseInt(row["კვარტალი"] || row["quarter"] || Math.ceil((new Date().getMonth() + 1) / 3)),
          fiscal_month: parseInt(row["თვე"] || row["month"] || new Date().getMonth() + 1),
          created_by: user.id,
        };
      });

      const { error } = await supabase
        .from("budget_expenses")
        .insert(expensesToImport);

      if (error) {
        toast({
          title: "შეცდომა",
          description: "ხარჯების იმპორტი ვერ მოხერხდა: " + error.message,
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "წარმატება",
        description: `${expensesToImport.length} ხარჯი წარმატებით დაიმატა`,
      });

      fetchExpenses();
    } catch (error) {
      toast({
        title: "შეცდომა",
        description: "ფაილის წაკითხვა ვერ მოხერხდა",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
      event.target.value = "";
    }
  };

  const isAdmin = userRole === "admin" || userRole === "hr_manager";

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 p-4 sm:p-6 lg:p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              ბიუჯეტის ხარჯები
            </h1>
            <p className="text-muted-foreground mt-1">დეტალური ხარჯების აღრიცხვა</p>
          </div>
          
          {isAdmin && (
            <div className="flex flex-wrap gap-2">
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={resetForm}>
                    <Plus className="mr-2 h-4 w-4" />
                    ახალი ხარჯი
                  </Button>
                </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>
                    {editingExpense ? "ხარჯის რედაქტირება" : "ახალი ხარჯის დამატება"}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expense_date">თარიღი *</Label>
                      <Input
                        id="expense_date"
                        type="date"
                        value={formData.expense_date}
                        onChange={(e) => setFormData({ ...formData, expense_date: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="amount">თანხა *</Label>
                      <Input
                        id="amount"
                        type="number"
                        step="0.01"
                        value={formData.amount}
                        onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="category">კატეგორია *</Label>
                      <Select
                        value={formData.category}
                        onValueChange={(value) => setFormData({ ...formData, category: value })}
                        required
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="აირჩიეთ კატეგორია" />
                        </SelectTrigger>
                        <SelectContent>
                          {expenseCategories.map((cat) => (
                            <SelectItem key={cat} value={cat}>
                              {cat}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="department_id">დეპარტამენტი</Label>
                      <Select
                        value={formData.department_id}
                        onValueChange={(value) => setFormData({ ...formData, department_id: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="აირჩიეთ დეპარტამენტი" />
                        </SelectTrigger>
                        <SelectContent>
                          {departments.map((dept) => (
                            <SelectItem key={dept.id} value={dept.id}>
                              {dept.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fiscal_year">ფისკალური წელი</Label>
                      <Input
                        id="fiscal_year"
                        type="number"
                        value={formData.fiscal_year}
                        onChange={(e) => setFormData({ ...formData, fiscal_year: parseInt(e.target.value) })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fiscal_quarter">კვარტალი</Label>
                      <Select
                        value={formData.fiscal_quarter.toString()}
                        onValueChange={(value) => setFormData({ ...formData, fiscal_quarter: parseInt(value) })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">Q1</SelectItem>
                          <SelectItem value="2">Q2</SelectItem>
                          <SelectItem value="3">Q3</SelectItem>
                          <SelectItem value="4">Q4</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fiscal_month">თვე</Label>
                      <Input
                        id="fiscal_month"
                        type="number"
                        min="1"
                        max="12"
                        value={formData.fiscal_month}
                        onChange={(e) => setFormData({ ...formData, fiscal_month: parseInt(e.target.value) })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">აღწერა</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      rows={3}
                      placeholder="დეტალური აღწერა..."
                    />
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button type="submit" className="flex-1">
                      {editingExpense ? "განახლება" : "დამატება"}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setIsDialogOpen(false);
                        resetForm();
                      }}
                    >
                      გაუქმება
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
            
            <Button 
              variant={showAnalytics ? "default" : "outline"}
              onClick={() => setShowAnalytics(!showAnalytics)}
            >
              <BarChart3 className="mr-2 h-4 w-4" />
              ანალიტიკა
            </Button>
            
            <Button variant="outline" onClick={handleExportTemplate}>
              <Download className="mr-2 h-4 w-4" />
              შაბლონის ჩამოტვირთვა
            </Button>
            
            <Button variant="outline" disabled={isImporting} asChild>
              <label className="cursor-pointer">
                <Upload className="mr-2 h-4 w-4" />
                {isImporting ? "იმპორტი..." : "Excel-დან იმპორტი"}
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleImportExcel}
                  className="hidden"
                  disabled={isImporting}
                />
              </label>
            </Button>
          </div>
          )}
        </div>

        {/* Analytics Dashboard */}
        {showAnalytics && (
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                ხარჯების ანალიტიკა
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {/* Pie Chart - By Category */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">კატეგორიების მიხედვით</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={categoryData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="hsl(var(--primary))"
                          dataKey="value"
                        >
                          {categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `₾${Number(value).toLocaleString()}`} />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                {/* Line Chart - Timeline */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">დროის მიხედვით</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={timelineData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                        <YAxis stroke="hsl(var(--muted-foreground))" />
                        <Tooltip 
                          formatter={(value) => `₾${Number(value).toLocaleString()}`}
                          contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                        />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="amount" 
                          stroke="hsl(var(--primary))" 
                          name="თანხა" 
                          strokeWidth={2}
                          dot={{ fill: 'hsl(var(--primary))' }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                {/* Bar Chart - Department Comparison */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">დეპარტამენტების შედარება</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={departmentData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                        <YAxis stroke="hsl(var(--muted-foreground))" />
                        <Tooltip 
                          formatter={(value) => `₾${Number(value).toLocaleString()}`}
                          contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                        />
                        <Legend />
                        <Bar 
                          dataKey="amount" 
                          fill="hsl(var(--chart-2))" 
                          name="თანხა"
                          radius={[8, 8, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        )}

        {isAdmin && pendingExpenses.length > 0 && (
          <Card className="border-yellow-500/20 bg-yellow-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Clock className="h-5 w-5 text-yellow-600" />
                დადასტურების მოლოდინში ({pendingExpenses.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {pendingExpenses.slice(0, 5).map((expense) => (
                <div key={expense.id} className="flex items-center justify-between p-3 rounded-lg bg-background/50 border">
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{expense.category}</span>
                      {expense.department_name && (
                        <span className="text-sm text-muted-foreground">({expense.department_name})</span>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {format(new Date(expense.expense_date), "dd/MM/yyyy")} • 
                      <span className="font-semibold text-primary ml-1">
                        ₾{expense.amount.toLocaleString("ka-GE", { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    {expense.description && (
                      <p className="text-sm text-muted-foreground">{expense.description}</p>
                    )}
                  </div>
                  <div className="flex gap-2 ml-4">
                    <Button
                      size="sm"
                      onClick={() => handleApproveExpense(expense)}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <CheckCircle className="h-3 w-3 mr-1" />
                      დამტკიცება
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => {
                        setRejectingExpense(expense);
                        setIsRejectDialogOpen(true);
                      }}
                    >
                      <XCircle className="h-3 w-3 mr-1" />
                      უარყოფა
                    </Button>
                  </div>
                </div>
              ))}
              {pendingExpenses.length > 5 && (
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setFilters({ ...filters, status: "pending" });
                    setShowFilters(true);
                  }}
                >
                  ყველას ნახვა ({pendingExpenses.length})
                </Button>
              )}
            </CardContent>
          </Card>
        )}

        <Card>

          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                სულ ხარჯი: ₾{totalExpenses.toLocaleString("ka-GE", { minimumFractionDigits: 2 })}
              </CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="h-4 w-4 mr-2" />
                ფილტრები
              </Button>
            </div>
          </CardHeader>
          
          {showFilters && (
            <CardContent className="border-t pt-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>კატეგორია</Label>
                  <Select value={filters.category} onValueChange={(value) => setFilters({ ...filters, category: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა</SelectItem>
                      {expenseCategories.map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>დეპარტამენტი</Label>
                  <Select value={filters.department} onValueChange={(value) => setFilters({ ...filters, department: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა</SelectItem>
                      {departments.map((dept) => (
                        <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>წელი</Label>
                  <Select value={filters.year} onValueChange={(value) => setFilters({ ...filters, year: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა</SelectItem>
                      {[2024, 2025, 2026].map((year) => (
                        <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>კვარტალი</Label>
                  <Select value={filters.quarter} onValueChange={(value) => setFilters({ ...filters, quarter: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა</SelectItem>
                      <SelectItem value="1">Q1</SelectItem>
                      <SelectItem value="2">Q2</SelectItem>
                      <SelectItem value="3">Q3</SelectItem>
                      <SelectItem value="4">Q4</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>სტატუსი</Label>
                  <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა</SelectItem>
                      <SelectItem value="pending">მოლოდინში</SelectItem>
                      <SelectItem value="approved">დამტკიცებული</SelectItem>
                      <SelectItem value="rejected">უარყოფილი</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          )}
        </Card>

        <Card>
          <CardContent className="p-6">
            <ResponsiveTable
              data={filteredExpenses}
              mobileCards={(expense: BudgetExpense) => (
                <MobileCard key={expense.id}>
                  <MobileCardRow
                    label="თარიღი"
                    value={<span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{format(new Date(expense.expense_date), "dd/MM/yyyy")}</span>}
                  />
                  <MobileCardRow label="კატეგორია" value={expense.category} />
                  <MobileCardRow label="დეპარტამენტი" value={expense.department_name || "-"} />
                  <MobileCardRow
                    label="თანხა"
                    value={<span className="font-semibold text-primary">₾{expense.amount.toLocaleString("ka-GE", { minimumFractionDigits: 2 })}</span>}
                  />
                  <MobileCardRow label="სტატუსი" value={getStatusBadge(expense.status)} />
                  {expense.description && <MobileCardRow label="აღწერა" value={expense.description} />}
                  {expense.rejection_reason && (
                    <MobileCardRow label="უარყოფის მიზეზი" value={expense.rejection_reason} />
                  )}
                  {isAdmin && (
                    <div className="flex gap-2 mt-2">
                      {expense.status === "pending" ? (
                        <>
                          <Button size="sm" onClick={() => handleApproveExpense(expense)} className="flex-1 bg-green-600 hover:bg-green-700">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            დამტკიცება
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive" 
                            onClick={() => {
                              setRejectingExpense(expense);
                              setIsRejectDialogOpen(true);
                            }}
                          >
                            <XCircle className="h-3 w-3" />
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button size="sm" variant="outline" onClick={() => handleEdit(expense)} className="flex-1">
                            <Edit2 className="h-3 w-3 mr-1" />
                            რედაქტირება
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => handleDelete(expense.id)}>
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </>
                      )}
                    </div>
                  )}
                </MobileCard>
              )}
            >
              <TableHeader>
                <TableRow>
                  <TableHead>თარიღი</TableHead>
                  <TableHead>კატეგორია</TableHead>
                  <TableHead>დეპარტამენტი</TableHead>
                  <TableHead>აღწერა</TableHead>
                  <TableHead>წელი</TableHead>
                  <TableHead>კვარტალი</TableHead>
                  <TableHead>სტატუსი</TableHead>
                  <TableHead className="text-right">თანხა</TableHead>
                  {isAdmin && <TableHead className="text-right">მოქმედებები</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredExpenses.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={isAdmin ? 9 : 8} className="text-center text-muted-foreground py-8">
                      ხარჯები არ მოიძებნა
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredExpenses.map((expense) => (
                    <TableRow key={expense.id}>
                      <TableCell>{format(new Date(expense.expense_date), "dd/MM/yyyy")}</TableCell>
                      <TableCell>{expense.category}</TableCell>
                      <TableCell>{expense.department_name || "-"}</TableCell>
                      <TableCell className="max-w-xs truncate">
                        {expense.description || "-"}
                        {expense.rejection_reason && (
                          <div className="text-xs text-destructive mt-1">
                            უარყოფის მიზეზი: {expense.rejection_reason}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>{expense.fiscal_year}</TableCell>
                      <TableCell>Q{expense.fiscal_quarter}</TableCell>
                      <TableCell>{getStatusBadge(expense.status)}</TableCell>
                      <TableCell className="text-right font-semibold">
                        ₾{expense.amount.toLocaleString("ka-GE", { minimumFractionDigits: 2 })}
                      </TableCell>
                      {isAdmin && (
                        <TableCell className="text-right">
                          {expense.status === "pending" ? (
                            <div className="flex justify-end gap-2">
                              <Button 
                                size="sm" 
                                onClick={() => handleApproveExpense(expense)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="h-3 w-3" />
                              </Button>
                              <Button 
                                size="sm" 
                                variant="destructive" 
                                onClick={() => {
                                  setRejectingExpense(expense);
                                  setIsRejectDialogOpen(true);
                                }}
                              >
                                <XCircle className="h-3 w-3" />
                              </Button>
                            </div>
                          ) : (
                            <div className="flex justify-end gap-2">
                              <Button size="sm" variant="outline" onClick={() => handleEdit(expense)}>
                                <Edit2 className="h-3 w-3" />
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => handleDelete(expense.id)}>
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          )}
                        </TableCell>
                      )}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </ResponsiveTable>
          </CardContent>
        </Card>

        <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>ხარჯის უარყოფა</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>უარყოფის მიზეზი *</Label>
                <Textarea
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="მიუთითეთ უარყოფის მიზეზი..."
                  rows={4}
                />
              </div>
              <div className="flex gap-3">
                <Button
                  variant="destructive"
                  onClick={handleRejectExpense}
                  className="flex-1"
                  disabled={!rejectionReason.trim()}
                >
                  უარყოფა
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsRejectDialogOpen(false);
                    setRejectingExpense(null);
                    setRejectionReason("");
                  }}
                >
                  გაუქმება
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}