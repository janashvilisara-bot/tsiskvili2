import { useState, useEffect } from "react";
import { getScheduleTypeLabel, VALID_SCHEDULE_TYPES } from "@/lib/scheduleUtils";
import { usePersistedState } from "@/hooks/usePersistedState";
import { Plus, Search, Pencil, Trash2, Eye, EyeOff, CheckCircle2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface ScheduleTemplate {
  id: string;
  name: string;
  schedule_type: string;
  schedule_category: string | null;
  description: string | null;
  start_time: string | null;
  end_time: string | null;
  weekly_hours: number | null;
  work_days: string[] | null;
  work_days_location: any;
  break_duration: number | null;
  break_start_time: string | null;
  break_end_time: string | null;
  no_break: boolean | null;
  conditions: string | null;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

const SCHEDULE_CATEGORIES = [
  { value: 'full', label: 'სრული' },
  { value: 'part_time', label: 'არასრული' },
  { value: 'shifts', label: 'ცვლები' },
  { value: 'flexible', label: 'თავისუფალი' },
  { value: 'remote', label: 'დისტანციური' },
  { value: 'hybrid', label: 'ჰიბრიდული' },
] as const;

const getCategoryLabel = (category: string | null) => {
  const found = SCHEDULE_CATEGORIES.find(c => c.value === category);
  return found?.label || 'სრული';
};

export default function ScheduleTemplates() {
  const { userRole } = useAuth();
  const [templates, setTemplates] = useState<ScheduleTemplate[]>([]);
  const [searchQuery, setSearchQuery] = usePersistedState<string>("schedule-templates:search", "");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(true);
  const [editingTemplate, setEditingTemplate] = useState<ScheduleTemplate | null>(null);
  const [deleteTemplateId, setDeleteTemplateId] = useState<string | null>(null);

  const canManage = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    setIsFetching(true);
    try {
      const { data, error } = await supabase
        .from('schedule_templates')
        .select('*')
        .order('name');

      if (error) throw error;
      setTemplates(data || []);
    } catch (error: any) {
      toast.error('შაბლონების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsFetching(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const workDays: string[] = [];
    const workDaysLocation: Record<string, string> = {};
    
    ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].forEach(day => {
      if (formData.get(`work_day_${day}`) === 'on') {
        workDays.push(day);
        const location = formData.get(`work_location_${day}`) as string;
        if (location) {
          workDaysLocation[day] = location;
        }
      }
    });

    const startTime = formData.get('start_time') as string;
    const endTime = formData.get('end_time') as string;
    const weeklyHours = formData.get('weekly_hours') as string;
    const breakDuration = formData.get('break_duration') as string;
    const breakStartTime = formData.get('break_start_time') as string;
    const breakEndTime = formData.get('break_end_time') as string;
    
    // Auto-generate schedule_type from start/end times
    const autoScheduleType = startTime && endTime ? `${startTime} - ${endTime}` : '';
    
    const templateData = {
      name: formData.get('name') as string,
      schedule_type: autoScheduleType,
      schedule_category: formData.get('schedule_category') as string || 'full',
      description: formData.get('description') as string || null,
      start_time: startTime && startTime.trim() !== '' ? startTime : null,
      end_time: endTime && endTime.trim() !== '' ? endTime : null,
      weekly_hours: weeklyHours && weeklyHours.trim() !== '' ? Number(weeklyHours) : null,
      work_days: workDays.length > 0 ? workDays : null,
      work_days_location: Object.keys(workDaysLocation).length > 0 ? workDaysLocation : null,
      break_duration: breakDuration && breakDuration.trim() !== '' ? Number(breakDuration) : 0,
      break_start_time: breakStartTime && breakStartTime.trim() !== '' ? breakStartTime : null,
      break_end_time: breakEndTime && breakEndTime.trim() !== '' ? breakEndTime : null,
      no_break: formData.get('no_break') === 'on',
      conditions: formData.get('conditions') as string || null,
      is_default: formData.get('is_default') === 'on',
    };

    try {
      if (editingTemplate) {
        const { error } = await supabase
          .from('schedule_templates')
          .update(templateData)
          .eq('id', editingTemplate.id);

        if (error) throw error;
        toast.success('შაბლონი წარმატებით განახლდა');
      } else {
        const { error } = await supabase
          .from('schedule_templates')
          .insert([templateData]);

        if (error) throw error;
        toast.success('შაბლონი წარმატებით შეიქმნა');
      }

      setIsDialogOpen(false);
      setEditingTemplate(null);
      fetchTemplates();
    } catch (error: any) {
      toast.error(error.message || 'ოპერაცია ვერ შესრულდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTemplateId) return;

    try {
      // Check if template is used by any employees
      const { data: usedByEmployees } = await supabase
        .from('employees')
        .select('full_name')
        .eq('work_schedule_id', deleteTemplateId)
        .limit(5);

      if (usedByEmployees && usedByEmployees.length > 0) {
        const names = usedByEmployees.map(e => e.full_name).join(', ');
        toast.error(`შაბლონი გამოიყენება თანამშრომლებით: ${names}. ჯერ შეცვალეთ მათი გრაფიკი.`);
        setDeleteTemplateId(null);
        return;
      }

      const { error } = await supabase
        .from('schedule_templates')
        .delete()
        .eq('id', deleteTemplateId);

      if (error) throw error;
      toast.success('შაბლონი წაიშალა');
      fetchTemplates();
    } catch (error: any) {
      toast.error('შაბლონის წაშლა ვერ მოხერხდა');
    } finally {
      setDeleteTemplateId(null);
    }
  };

  const toggleDefault = async (templateId: string, currentDefault: boolean) => {
    try {
      // First, unset all defaults
      if (!currentDefault) {
        await supabase
          .from('schedule_templates')
          .update({ is_default: false })
          .neq('id', templateId);
      }

      // Then set the new default
      const { error } = await supabase
        .from('schedule_templates')
        .update({ is_default: !currentDefault })
        .eq('id', templateId);

      if (error) throw error;
      toast.success(currentDefault ? 'ნაგულისხმევი მოხსნილია' : 'დაყენდა ნაგულისხმევად');
      fetchTemplates();
    } catch (error: any) {
      toast.error('ოპერაცია ვერ შესრულდა');
    }
  };

  const filteredTemplates = templates.filter(template =>
    template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    template.schedule_type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Component for schedule time fields with auto-generated schedule type
  const ScheduleTimeFields = ({ editingTemplate }: { editingTemplate: ScheduleTemplate | null }) => {
    const [startTime, setStartTime] = useState(editingTemplate?.start_time || '');
    const [endTime, setEndTime] = useState(editingTemplate?.end_time || '');
    const [selectedCategory, setSelectedCategory] = useState(editingTemplate?.schedule_category || 'full');
    const [templateName, setTemplateName] = useState(editingTemplate?.name || '');
    
    const categoryLabel = SCHEDULE_CATEGORIES.find(c => c.value === selectedCategory)?.label || '';

    // Auto-generate name from start/end times
    useEffect(() => {
      if (startTime && endTime) {
        setTemplateName(`${startTime} - ${endTime}`);
      }
    }, [startTime, endTime]);

    return (
      <>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="name">დასახელება *</Label>
            <Input
              id="name"
              name="name"
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              placeholder="მაგ: 09:00 - 18:00"
              required
            />
          </div>
          <div>
            <Label htmlFor="schedule_category">გრაფიკის კატეგორია *</Label>
            <Select 
              name="schedule_category" 
              value={selectedCategory}
              onValueChange={setSelectedCategory}
            >
              <SelectTrigger>
                <SelectValue placeholder="აირჩიეთ კატეგორია" />
              </SelectTrigger>
              <SelectContent>
                {SCHEDULE_CATEGORIES.map(cat => (
                  <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="start_time">დაწყების დრო</Label>
            <Input
              id="start_time"
              name="start_time"
              type="time"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="end_time">დასრულების დრო</Label>
            <Input
              id="end_time"
              name="end_time"
              type="time"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
            />
          </div>
        </div>

        <div>
          <Label>გრაფიკის ტიპი</Label>
          <Input
            value={categoryLabel}
            disabled
            className="mt-1 bg-muted"
            placeholder="კატეგორია ავტომატურად გამოჩნდება"
          />
          <input type="hidden" name="schedule_type" value={categoryLabel} />
        </div>

        <div>
          <Label htmlFor="description">აღწერა</Label>
          <Textarea
            id="description"
            name="description"
            defaultValue={editingTemplate?.description || ''}
            placeholder="შაბლონის მოკლე აღწერა"
          />
        </div>
      </>
    );
  };

  const getWeekDayLabel = (day: string) => {
    const days: Record<string, string> = {
      monday: 'ორშ',
      tuesday: 'სამ',
      wednesday: 'ოთხ',
      thursday: 'ხუთ',
      friday: 'პარ',
      saturday: 'შაბ',
      sunday: 'კვი'
    };
    return days[day] || day;
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold">სამუშაო გრაფიკების შაბლონები</h1>
          <p className="mt-2 text-muted-foreground">შექმენით და მართეთ სამუშაო გრაფიკების შაბლონები</p>
        </div>
        {canManage && (
          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) setEditingTemplate(null);
          }}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                ახალი შაბლონი
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {editingTemplate ? 'შაბლონის რედაქტირება' : 'ახალი შაბლონის შექმნა'}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <ScheduleTimeFields editingTemplate={editingTemplate} />

                <div>
                  <Label htmlFor="weekly_hours">კვირაში საათები</Label>
                  <Input
                    id="weekly_hours"
                    name="weekly_hours"
                    type="number"
                    step="0.01"
                    defaultValue={editingTemplate?.weekly_hours || ''}
                    placeholder="40"
                  />
                </div>

                <div>
                  <Label>სამუშაო დღეები და ლოკაცია</Label>
                  <div className="space-y-3 mt-2">
                    {[
                      { key: 'monday', label: 'ორშაბათი' },
                      { key: 'tuesday', label: 'სამშაბათი' },
                      { key: 'wednesday', label: 'ოთხშაბათი' },
                      { key: 'thursday', label: 'ხუთშაბათი' },
                      { key: 'friday', label: 'პარასკევი' },
                      { key: 'saturday', label: 'შაბათი' },
                      { key: 'sunday', label: 'კვირა' }
                    ].map(day => {
                      const WorkDayRow = () => {
                        const [isDayChecked, setIsDayChecked] = useState(
                          editingTemplate?.work_days?.includes(day.key) || false
                        );

                        return (
                          <div className="flex items-center gap-4">
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id={`work_day_${day.key}`}
                                name={`work_day_${day.key}`}
                                checked={isDayChecked}
                                onCheckedChange={(checked) => setIsDayChecked(!!checked)}
                              />
                              <label
                                htmlFor={`work_day_${day.key}`}
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 min-w-[80px]"
                              >
                                {day.label}
                              </label>
                            </div>
                            {isDayChecked && (
                              <Select
                                name={`work_location_${day.key}`}
                                defaultValue={editingTemplate?.work_days_location?.[day.key] || 'office'}
                              >
                                <SelectTrigger className="w-[180px]">
                                  <SelectValue placeholder="აირჩიეთ ლოკაცია" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="office">ოფისში</SelectItem>
                                  <SelectItem value="remote">დისტანციურად</SelectItem>
                                  <SelectItem value="hybrid">ჰიბრიდული</SelectItem>
                                </SelectContent>
                              </Select>
                            )}
                          </div>
                        );
                      };

                      return <WorkDayRow key={day.key} />;
                    })}
                  </div>
                </div>

                <div>
                  <Label htmlFor="break_duration">შესვენება (წუთებში)</Label>
                  <Input
                    id="break_duration"
                    name="break_duration"
                    type="number"
                    defaultValue={editingTemplate?.break_duration || 0}
                    placeholder="60"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="break_start_time">შესვენების დაწყება</Label>
                    <Input
                      id="break_start_time"
                      name="break_start_time"
                      type="time"
                      defaultValue={editingTemplate?.break_start_time || ''}
                    />
                  </div>
                  <div>
                    <Label htmlFor="break_end_time">შესვენების დასრულება</Label>
                    <Input
                      id="break_end_time"
                      name="break_end_time"
                      type="time"
                      defaultValue={editingTemplate?.break_end_time || ''}
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="no_break"
                    name="no_break"
                    defaultChecked={editingTemplate?.no_break || false}
                  />
                  <Label htmlFor="no_break" className="font-normal cursor-pointer">
                    შესვენების გარეშე
                  </Label>
                </div>

                <div>
                  <Label htmlFor="conditions">პირობები და დეტალები</Label>
                  <Textarea
                    id="conditions"
                    name="conditions"
                    defaultValue={editingTemplate?.conditions || ''}
                    placeholder="დეტალური ინფორმაცია სამუშაო გრაფიკის შესახებ"
                    rows={3}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="is_default"
                    name="is_default"
                    defaultChecked={editingTemplate?.is_default || false}
                  />
                  <Label htmlFor="is_default" className="font-normal cursor-pointer">
                    დააყენე ნაგულისხმევად
                  </Label>
                </div>

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'მიმდინარეობს...' : editingTemplate ? 'განახლება' : 'შექმნა'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="ძებნა შაბლონების მიხედვით..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <Card>
          <CardHeader>
            <CardTitle>შაბლონების სია ({filteredTemplates.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>დასახელება</TableHead>
                  <TableHead>კატეგორია</TableHead>
                  <TableHead>სამუშაო საათები</TableHead>
                  <TableHead>სამუშაო დღეები</TableHead>
                  <TableHead>შესვენება</TableHead>
                  <TableHead>სტატუსი</TableHead>
                  {canManage && <TableHead className="text-right">მოქმედებები</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {isFetching ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                      <Loader2 className="h-6 w-6 animate-spin mx-auto" />
                    </TableCell>
                  </TableRow>
                ) : filteredTemplates.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                      შაბლონები არ მოიძებნა
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTemplates.map((template) => (
                    <TableRow key={template.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{template.name}</span>
                          {template.is_default && (
                            <Badge variant="secondary" className="text-xs">
                              <CheckCircle2 className="h-3 w-3 mr-1" />
                              ნაგულისხმევი
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{getCategoryLabel(template.schedule_category)}</Badge>
                      </TableCell>
                      <TableCell>
                        {template.start_time && template.end_time ? (
                          <span>{template.start_time} - {template.end_time}</span>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {template.work_days && template.work_days.length > 0 ? (
                          <div className="flex gap-1 flex-wrap">
                            {template.work_days.map(day => (
                              <Badge key={day} variant="secondary" className="text-xs">
                                {getWeekDayLabel(day)}
                              </Badge>
                            ))}
                          </div>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {template.no_break ? (
                          <Badge variant="outline">შესვენების გარეშე</Badge>
                        ) : (
                          <div className="space-y-1">
                            {template.break_start_time && template.break_end_time ? (
                              <span>{template.break_start_time} - {template.break_end_time}</span>
                            ) : template.break_duration ? (
                              <span>{template.break_duration} წთ</span>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleDefault(template.id, template.is_default)}
                          disabled={!canManage}
                        >
                          {template.is_default ? (
                            <EyeOff className="h-4 w-4 text-muted-foreground" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                        </Button>
                      </TableCell>
                      {canManage && (
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setEditingTemplate(template);
                                setIsDialogOpen(true);
                              }}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setDeleteTemplateId(template.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <AlertDialog open={!!deleteTemplateId} onOpenChange={() => setDeleteTemplateId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>დარწმუნებული ხართ?</AlertDialogTitle>
            <AlertDialogDescription>
              ეს მოქმედება შეუქცევადია. შაბლონი სამუდამოდ წაიშლება.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>გაუქმება</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              წაშლა
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
