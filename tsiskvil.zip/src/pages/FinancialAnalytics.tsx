import { useEffect, useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageTransition } from "@/components/PageTransition";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, Receipt, Wallet, Users, BarChart3 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip as RTooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";
import { toast } from "sonner";

type PayrollRow = { month: number; year: number; gross_salary: number | null; base_salary: number; bonuses: number | null; deductions: number | null };

const MONTHS_KA = ["იან", "თებ", "მარ", "აპრ", "მაი", "ივნ", "ივლ", "აგვ", "სექ", "ოქტ", "ნოე", "დეკ"];
const fmt = (n: number) => `₾${Math.round(n).toLocaleString("ka-GE")}`;

export default function FinancialAnalytics() {
  const [loading, setLoading] = useState(true);
  const [year, setYear] = useState<number>(new Date().getFullYear());
  const [activeEmps, setActiveEmps] = useState(0);
  const [current, setCurrent] = useState<PayrollRow[]>([]);
  const [previous, setPrevious] = useState<PayrollRow[]>([]);

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year]);

  const load = async () => {
    setLoading(true);
    try {
      const [empRes, curRes, prevRes] = await Promise.all([
        supabase.from("employees").select("id", { count: "exact", head: true }).eq("status", "active"),
        supabase.from("payroll").select("month, year, gross_salary, base_salary, bonuses, deductions").eq("year", year),
        supabase.from("payroll").select("month, year, gross_salary, base_salary, bonuses, deductions").eq("year", year - 1),
      ]);
      setActiveEmps(empRes.count ?? 0);
      setCurrent((curRes.data ?? []) as PayrollRow[]);
      setPrevious((prevRes.data ?? []) as PayrollRow[]);
    } catch (e) {
      console.error(e);
      toast.error("მონაცემების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const stats = useMemo(() => {
    const grossOf = (r: PayrollRow) => r.gross_salary ?? (r.base_salary + (r.bonuses ?? 0));
    const totalGross = current.reduce((s, r) => s + grossOf(r), 0);
    const totalTax = totalGross * 0.2 + current.reduce((s, r) => s + grossOf(r) * 0.02, 0);
    const totalExpense = totalGross + current.reduce((s, r) => s + (r.deductions ?? 0), 0);
    return { totalGross, totalTax, totalExpense };
  }, [current]);

  const chartData = useMemo(() => {
    const sumByMonth = (rows: PayrollRow[]) => {
      const map = new Map<number, number>();
      for (const r of rows) {
        const g = r.gross_salary ?? (r.base_salary + (r.bonuses ?? 0));
        map.set(r.month, (map.get(r.month) ?? 0) + g);
      }
      return map;
    };
    const cur = sumByMonth(current);
    const prev = sumByMonth(previous);
    return MONTHS_KA.map((label, i) => ({
      month: label,
      ხელფასი: cur.get(i + 1) ?? 0,
      წინანდელი: prev.get(i + 1) ?? 0,
    }));
  }, [current, previous]);

  const yearOptions = useMemo(() => {
    const y = new Date().getFullYear();
    return [y + 1, y, y - 1, y - 2, y - 3];
  }, []);

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 shadow-lg">
                <BarChart3 className="h-7 w-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold">ფინანსური ანალიტიკა</h1>
                <p className="text-sm text-muted-foreground">ხარჯები დეპარტამენტებისა და თვეების მიხედვით</p>
              </div>
            </div>
            <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
              <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                {yearOptions.map((y) => <SelectItem key={y} value={String(y)}>{y} წ.</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {/* KPIs */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Kpi label="სულ ხელფასი" value={loading ? "…" : fmt(stats.totalGross)} sub={`${year} წ.`} icon={TrendingUp} tone="emerald" />
            <Kpi label="სულ გადასახ." value={loading ? "…" : fmt(stats.totalTax)} sub="საშ. + სოც." icon={Receipt} tone="amber" />
            <Kpi label="სულ ხარჯები" value={loading ? "…" : fmt(stats.totalExpense)} sub="დამტ. ხარჯები" icon={Wallet} tone="green" />
            <Kpi label="აქტ. თანამშ." value={loading ? "…" : String(activeEmps)} sub="ამჟამად" icon={Users} tone="indigo" />
          </div>

          {/* Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Wallet className="h-4 w-4 text-amber-500" />
                ხელფასი თვეების მიხედვით - {year}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-72 w-full" />
              ) : (
                <ResponsiveContainer width="100%" height={340}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `₾${Math.round(Number(v) / 1000)}k`} />
                    <RTooltip
                      formatter={(v: number) => fmt(v)}
                      contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: 8 }}
                    />
                    <Legend />
                    <Bar dataKey="ხელფასი" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
                    <Bar dataKey="წინანდელი" fill="hsl(142 71% 45%)" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </PageTransition>
  );
}

function Kpi({ label, value, sub, icon: Icon, tone }: { label: string; value: string; sub?: string; icon: any; tone: "emerald" | "amber" | "green" | "indigo" }) {
  const tones: Record<string, string> = {
    emerald: "from-emerald-500/15 to-emerald-500/5 text-emerald-600 dark:text-emerald-400",
    amber: "from-amber-500/15 to-amber-500/5 text-amber-600 dark:text-amber-400",
    green: "from-green-500/15 to-green-500/5 text-green-600 dark:text-green-400",
    indigo: "from-indigo-500/15 to-indigo-500/5 text-indigo-600 dark:text-indigo-400",
  };
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`p-2.5 rounded-xl bg-gradient-to-br ${tones[tone]}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <div className="text-xs text-muted-foreground truncate">{label}</div>
          <div className="text-lg font-bold truncate">{value}</div>
          {sub && <div className="text-[11px] text-muted-foreground truncate">{sub}</div>}
        </div>
      </CardContent>
    </Card>
  );
}
