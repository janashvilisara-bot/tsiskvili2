import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/components/ui/use-toast";
import { Send, Video, Users, Bot, Circle, Paperclip, X, Smile, MessageCircle, Clock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import EnhancedVideoCall from "@/components/EnhancedVideoCall";
import EmojiPicker, { EmojiClickData } from "emoji-picker-react";

interface Employee {
  id: string;
  full_name: string;
  avatar_url: string | null;
  status: string;
}

interface ChatRoom {
  id: string;
  name: string | null;
  type: string;
  created_at: string;
  unread_count?: number;
  other_user?: Employee;
}

interface Message {
  id: string;
  room_id: string;
  sender_id: string;
  content: string;
  type: string;
  created_at: string;
  sender_name?: string;
  sender_avatar?: string;
  file_url?: string;
  file_name?: string;
  file_type?: string;
  file_size?: number;
}

interface UserPresence {
  user_id: string;
  status: string;
  last_seen: string;
}

export default function Chat() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [rooms, setRooms] = useState<ChatRoom[]>([]);
  const [selectedRoom, setSelectedRoom] = useState<ChatRoom | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [userPresence, setUserPresence] = useState<Record<string, UserPresence>>({});
  const [showAI, setShowAI] = useState(false);
  const [aiInput, setAiInput] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [showVideoCall, setShowVideoCall] = useState(false);
  const [incomingCall, setIncomingCall] = useState<{ roomId: string; fromUserId: string; offer: any } | null>(null);
  const [videoCallRemoteUserId, setVideoCallRemoteUserId] = useState<string | null>(null);
  const [videoCallInitiator, setVideoCallInitiator] = useState<boolean>(true);
  const [initialSignal, setInitialSignal] = useState<any>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const emojiPickerRef = useRef<HTMLDivElement>(null);

  // Update user presence
  useEffect(() => {
    if (!user?.id) return;

    const updatePresence = async () => {
      await supabase
        .from("user_presence")
        .upsert({ user_id: user.id, status: "online", updated_at: new Date().toISOString() });
    };

    updatePresence();
    const interval = setInterval(updatePresence, 30000);

    return () => {
      clearInterval(interval);
      supabase
        .from("user_presence")
        .upsert({ user_id: user.id, status: "offline", updated_at: new Date().toISOString() });
    };
  }, [user?.id]);

  // Fetch employees
  useEffect(() => {
    if (!user?.id) return;

    const fetchEmployees = async () => {
      try {
        // Get active employees only
        const { data: activeEmployees, error: empError } = await supabase
          .from("employees")
          .select("id, user_id, full_name, avatar_url")
          .eq("status", "active")
          .neq("user_id", user.id)
          .not("user_id", "is", null);

        if (empError) {
          console.error("Error fetching employees:", empError);
          return;
        }

        if (activeEmployees) {
          // Get presence for each active user
          const { data: presenceData } = await supabase.from("user_presence").select("*");

          const presenceMap = presenceData?.reduce((acc, p) => {
            acc[p.user_id] = p.status;
            return acc;
          }, {} as Record<string, string>) || {};

          const employeesWithStatus = activeEmployees
            .filter(emp => emp.user_id)
            .map((emp) => ({
              id: emp.user_id!,
              full_name: emp.full_name,
              avatar_url: emp.avatar_url,
              status: presenceMap[emp.user_id!] || "offline",
            }));

          setEmployees(employeesWithStatus);
        }
      } catch (error) {
        console.error("Error in fetchEmployees:", error);
      }
    };

    fetchEmployees();

    // Subscribe to presence changes
    const channel = supabase
      .channel("presence-all")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "user_presence",
        },
        () => {
          fetchEmployees();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  // Fetch rooms
  useEffect(() => {
    if (!user?.id) return;

    const fetchRooms = async () => {
      try {
        const { data: participantData, error: partError } = await supabase
          .from("chat_participants")
          .select("room_id")
          .eq("user_id", user.id);

        if (partError) {
          console.error("Error fetching participants:", partError);
          return;
        }

        if (participantData && participantData.length > 0) {
          const roomIds = participantData.map((p) => p.room_id);
          const { data: roomsData, error: roomsError } = await supabase
            .from("chat_rooms")
            .select("*")
            .in("id", roomIds)
            .order("updated_at", { ascending: false });

          if (roomsError) {
            console.error("Error fetching rooms:", roomsError);
            return;
          }

          if (roomsData) {
            const roomsWithDetails = await Promise.all(
              roomsData.map(async (room) => {
                try {
                  // Get unread count
                  const { data: participant } = await supabase
                    .from("chat_participants")
                    .select("last_read_at")
                    .eq("room_id", room.id)
                    .eq("user_id", user.id)
                    .single();

                  const { count } = await supabase
                    .from("chat_messages")
                    .select("*", { count: "exact", head: true })
                    .eq("room_id", room.id)
                    .gt("created_at", participant?.last_read_at || "1970-01-01");

                  // Get other user in direct chat
                  let otherUser: Employee | undefined;
                  if (room.type === "direct") {
                    const { data: participants } = await supabase
                      .from("chat_participants")
                      .select("user_id")
                      .eq("room_id", room.id)
                      .neq("user_id", user.id);

                    if (participants && participants.length > 0) {
                      // First try to get from employees table
                      const { data: employee } = await supabase
                        .from("employees")
                        .select("user_id, full_name, avatar_url")
                        .eq("user_id", participants[0].user_id)
                        .single();

                      if (employee) {
                        const { data: presence } = await supabase
                          .from("user_presence")
                          .select("status")
                          .eq("user_id", employee.user_id)
                          .single();

                        otherUser = {
                          id: employee.user_id,
                          full_name: employee.full_name,
                          avatar_url: employee.avatar_url,
                          status: presence?.status || "offline",
                        };
                      } else {
                        // Fallback to profiles table
                        const { data: profile } = await supabase
                          .from("profiles")
                          .select("id, full_name, avatar_url")
                          .eq("id", participants[0].user_id)
                          .single();

                        if (profile) {
                          const { data: presence } = await supabase
                            .from("user_presence")
                            .select("status")
                            .eq("user_id", profile.id)
                            .single();

                          otherUser = {
                            id: profile.id,
                            full_name: profile.full_name,
                            avatar_url: profile.avatar_url,
                            status: presence?.status || "offline",
                          };
                        }
                      }
                    }
                  }

                  return { ...room, unread_count: count || 0, other_user: otherUser };
                } catch (error) {
                  console.error("Error processing room:", room.id, error);
                  return { ...room, unread_count: 0, other_user: undefined };
                }
              })
            );

            setRooms(roomsWithDetails);
          }
        }
      } catch (error) {
        console.error("Error in fetchRooms:", error);
      }
    };

    fetchRooms();

    const channel = supabase
      .channel("room-updates")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "chat_messages",
        },
        () => {
          fetchRooms();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  // Subscribe to incoming WebRTC offers
  useEffect(() => {
    if (!user?.id) return;

    const incoming = supabase
      .channel("webrtc-incoming")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "webrtc_signals",
          filter: `receiver_id=eq.${user.id}`,
        },
        (payload) => {
          const row: any = payload.new;
          if (row.signal_type !== "offer") return;
          setIncomingCall({ roomId: row.room_id, fromUserId: row.sender_id, offer: row.signal_data });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(incoming);
    };
  }, [user?.id]);

  // Fetch messages for selected room
  useEffect(() => {
    if (!selectedRoom) return;

    const fetchMessages = async () => {
      try {
        const { data, error } = await supabase
          .from("chat_messages")
          .select("*")
          .eq("room_id", selectedRoom.id)
          .order("created_at", { ascending: true });

        if (error) {
          console.error("Error fetching messages:", error);
          return;
        }

        if (data) {
          const messagesWithSenders = await Promise.all(
            data.map(async (msg) => {
              // Try employees first
              const { data: employee } = await supabase
                .from("employees")
                .select("full_name, avatar_url")
                .eq("user_id", msg.sender_id)
                .single();

              if (employee) {
                return {
                  ...msg,
                  sender_name: employee.full_name,
                  sender_avatar: employee.avatar_url,
                };
              }

              // Fallback to profiles
              const { data: profile } = await supabase
                .from("profiles")
                .select("full_name, avatar_url")
                .eq("id", msg.sender_id)
                .single();

              return {
                ...msg,
                sender_name: profile?.full_name || "უცნობი",
                sender_avatar: profile?.avatar_url,
              };
            })
          );

          setMessages(messagesWithSenders);
        }

        await supabase
          .from("chat_participants")
          .update({ last_read_at: new Date().toISOString() })
          .eq("room_id", selectedRoom.id)
          .eq("user_id", user?.id || "");
      } catch (error) {
        console.error("Error in fetchMessages:", error);
      }
    };

    fetchMessages();

    const channel = supabase
      .channel(`room-${selectedRoom.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "chat_messages",
          filter: `room_id=eq.${selectedRoom.id}`,
        },
        async (payload) => {
          try {
            // Try employees first
            const { data: employee } = await supabase
              .from("employees")
              .select("full_name, avatar_url")
              .eq("user_id", payload.new.sender_id)
              .single();

            let senderName = "უცნობი";
            let senderAvatar = null;

            if (employee) {
              senderName = employee.full_name;
              senderAvatar = employee.avatar_url;
            } else {
              // Fallback to profiles
              const { data: profile } = await supabase
                .from("profiles")
                .select("full_name, avatar_url")
                .eq("id", payload.new.sender_id)
                .single();

              if (profile) {
                senderName = profile.full_name;
                senderAvatar = profile.avatar_url;
              }
            }

            setMessages((prev) => [
              ...prev,
              {
                ...payload.new,
                sender_name: senderName,
                sender_avatar: senderAvatar,
              } as Message,
            ]);

            await supabase
              .from("chat_participants")
              .update({ last_read_at: new Date().toISOString() })
              .eq("room_id", selectedRoom.id)
              .eq("user_id", user?.id || "");
          } catch (error) {
            console.error("Error handling new message:", error);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [selectedRoom, user?.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Close emoji picker when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (emojiPickerRef.current && !emojiPickerRef.current.contains(event.target as Node)) {
        setShowEmojiPicker(false);
      }
    };

    if (showEmojiPicker) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showEmojiPicker]);

  const handleEmojiClick = (emojiData: any) => {
    setNewMessage((prev) => prev + (emojiData.emoji || ""));
  };

  const startChatWithEmployee = async (employee: Employee) => {
    if (!user?.id) return;

    // Check if a direct chat already exists
    const { data: existingParticipants } = await supabase
      .from("chat_participants")
      .select("room_id")
      .eq("user_id", user.id);

    if (existingParticipants) {
      for (const participant of existingParticipants) {
        const { data: otherParticipants } = await supabase
          .from("chat_participants")
          .select("user_id")
          .eq("room_id", participant.room_id)
          .neq("user_id", user.id);

        if (otherParticipants?.some((p) => p.user_id === employee.id)) {
          // Room exists, select it
          const { data: room } = await supabase
            .from("chat_rooms")
            .select("*")
            .eq("id", participant.room_id)
            .single();

          if (room) {
            setSelectedRoom({ ...room, other_user: employee });
            return;
          }
        }
      }
    }

    // Create new direct chat
    const { data: room, error: roomError } = await supabase
      .from("chat_rooms")
      .insert({
        type: "direct",
        created_by: user.id,
      })
      .select()
      .single();

    if (roomError || !room) {
      console.error("Room creation error:", roomError);
      toast({
        title: "შეცდომა",
        description: roomError?.message || "ჩატის შექმნა ვერ მოხერხდა",
        variant: "destructive",
      });
      return;
    }

    // Add participants
    const { error: participantError } = await supabase.from("chat_participants").insert([
      { room_id: room.id, user_id: user.id },
      { room_id: room.id, user_id: employee.id },
    ]);

    if (participantError) {
      console.error("Participant creation error:", participantError);
      toast({
        title: "შეცდომა",
        description: "მონაწილეების დამატება ვერ მოხერხდა",
        variant: "destructive",
      });
      return;
    }

    setSelectedRoom({ ...room, other_user: employee });
    
    toast({
      title: "წარმატება",
      description: `ჩატი ${employee.full_name}-თან შეიქმნა`,
    });
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        toast({
          title: "შეცდომა",
          description: "ფაილის ზომა არ უნდა აღემატებოდეს 10MB-ს",
          variant: "destructive",
        });
        return;
      }
      setSelectedFile(file);
    }
  };

  const uploadFile = async (file: File): Promise<string | null> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Math.random()}.${fileExt}`;
    const filePath = `${user?.id}/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('documents')
      .upload(filePath, file);

    if (uploadError) {
      console.error('Upload error:', uploadError);
      return null;
    }

    const { data: signedData, error: signedError } = await supabase.storage
      .from('documents')
      .createSignedUrl(filePath, 60 * 60 * 24 * 365);

    if (signedError) {
      console.error('Sign URL error:', signedError);
      return null;
    }

    setUploadProgress(100);
    return signedData.signedUrl;
  };

  const sendMessage = async () => {
    if ((!newMessage.trim() && !selectedFile) || !selectedRoom || !user?.id) return;

    let fileUrl = null;
    if (selectedFile) {
      fileUrl = await uploadFile(selectedFile);
      if (!fileUrl) {
        toast({
          title: "შეცდომა",
          description: "ფაილის ატვირთვა ვერ მოხერხდა",
          variant: "destructive",
        });
        return;
      }
    }

    const { error } = await supabase.from("chat_messages").insert({
      room_id: selectedRoom.id,
      sender_id: user.id,
      content: newMessage || (selectedFile ? selectedFile.name : ''),
      type: selectedFile ? "file" : "text",
      file_url: fileUrl,
      file_name: selectedFile?.name,
      file_type: selectedFile?.type,
      file_size: selectedFile?.size,
    });

    if (error) {
      toast({
        title: "შეცდომა",
        description: "შეტყობინების გაგზავნა ვერ მოხერხდა",
        variant: "destructive",
      });
    } else {
      setNewMessage("");
      setSelectedFile(null);
      setUploadProgress(0);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const askAI = async () => {
    if (!aiInput.trim()) return;

    setIsAiLoading(true);
    setAiResponse("");

    try {
      const { data, error } = await supabase.functions.invoke("ai-assistant", {
        body: { question: aiInput },
      });

      if (error) throw error;

      setAiResponse(data.response);
    } catch (error) {
      toast({
        title: "შეცდომა",
        description: "AI ასისტენტთან დაკავშირება ვერ მოხერხდა",
        variant: "destructive",
      });
    } finally {
      setIsAiLoading(false);
    }
  };

  const startVideoCall = () => {
    if (!selectedRoom?.other_user?.id) {
      toast({ title: "შეცდომა", description: "მოსაუბრის ID ვერ მოიძებნა", variant: "destructive" });
      return;
    }
    setVideoCallRemoteUserId(selectedRoom.other_user.id);
    setVideoCallInitiator(true);
    setInitialSignal(null);
    setShowVideoCall(true);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "bg-green-500";
      case "busy":
        return "bg-red-500";
      case "away":
        return "bg-yellow-500";
      default:
        return "bg-gray-400";
    }
  };

  if (showVideoCall && selectedRoom && user?.id && videoCallRemoteUserId) {
    return (
      <EnhancedVideoCall
        roomId={selectedRoom.id}
        userId={user.id}
        remoteUserIds={[videoCallRemoteUserId]}
        isInitiator={videoCallInitiator}
        initialSignal={initialSignal}
        onEnd={() => {
          setShowVideoCall(false);
          setVideoCallRemoteUserId(null);
          setVideoCallInitiator(true);
          setInitialSignal(null);
        }}
      />
    );
  }

  return (
    <div className="flex h-screen gap-4 p-4 bg-gradient-to-br from-background via-background/95 to-primary/5">
      {/* Employees List */}
      <Card className="w-80 flex-shrink-0 p-0 overflow-hidden backdrop-blur-xl bg-card/80 border-border/30 shadow-2xl shadow-primary/5 animate-fade-in rounded-2xl">
        <div className="p-5 bg-gradient-to-r from-cyan-500/10 via-sky-500/10 to-blue-500/10 border-b border-border/30 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-cyan-400 via-sky-500 to-blue-500 shadow-lg shadow-sky-500/30">
                <MessageCircle className="h-5 w-5 text-white" />
              </div>
              <h2 className="text-xl font-bold bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 bg-clip-text text-transparent">
                მესენჯერი
              </h2>
            </div>
            <Button 
              size="sm" 
              variant="ghost" 
              onClick={() => setShowAI(true)}
              className="hover:bg-primary/10 transition-all duration-300 hover:scale-110 rounded-xl"
            >
              <Bot className="h-5 w-5 text-primary" />
            </Button>
          </div>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-3 space-y-2">
            <p className="px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              თანამშრომლები
            </p>
            {employees.map((employee) => (
              <Button
                key={employee.id}
                variant="ghost"
                className="w-full justify-start hover:bg-gradient-to-r hover:from-primary/5 hover:to-accent/5 transition-all duration-300 hover:translate-x-1 rounded-xl py-3 h-auto"
                onClick={() => startChatWithEmployee(employee)}
              >
                <div className="flex w-full items-center gap-3">
                  <div className="relative">
                    <Avatar className="h-11 w-11 ring-2 ring-primary/10 transition-all duration-300 group-hover:ring-primary/30 shadow-md">
                      <AvatarImage src={employee.avatar_url || undefined} />
                      <AvatarFallback className="bg-gradient-to-br from-cyan-400 via-sky-500 to-blue-500 text-white font-semibold">
                        {employee.full_name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className={`absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-card ${getStatusColor(
                        employee.status
                      )} shadow-lg ${employee.status === 'online' ? 'animate-pulse' : ''}`}
                    />
                  </div>
                  <div className="flex-1 text-left">
                    <span className="font-medium block truncate">{employee.full_name}</span>
                    <span className={`text-xs ${employee.status === 'online' ? 'text-green-500' : 'text-muted-foreground'}`}>
                      {employee.status === 'online' ? 'ონლაინ' : 'ოფლაინ'}
                    </span>
                  </div>
                </div>
              </Button>
            ))}
          </div>
        </ScrollArea>

        {/* Recent Chats */}
        {rooms.length > 0 && (
          <div className="border-t border-border/30 bg-gradient-to-b from-muted/20 to-muted/40 backdrop-blur-sm">
            <div className="p-4">
              <h3 className="mb-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                <Clock className="h-3.5 w-3.5" />
                ბოლო საუბრები
              </h3>
              <div className="space-y-2">
                {rooms.slice(0, 5).map((room) => (
                  <Button
                    key={room.id}
                    variant={selectedRoom?.id === room.id ? "secondary" : "ghost"}
                    className={`w-full justify-between transition-all duration-300 rounded-xl h-auto py-2.5 ${
                      selectedRoom?.id === room.id 
                        ? 'bg-gradient-to-r from-cyan-500/10 via-sky-500/10 to-blue-500/10 border-l-3 border-sky-500 shadow-md shadow-sky-500/10' 
                        : 'hover:bg-gradient-to-r hover:from-muted/50 hover:to-muted/30'
                    }`}
                    onClick={() => setSelectedRoom(room)}
                  >
                    <div className="flex items-center gap-3">
                      {room.type === "group" ? (
                        <div className="p-1.5 rounded-lg bg-gradient-to-br from-cyan-400 to-blue-500">
                          <Users className="h-4 w-4 text-white" />
                        </div>
                      ) : (
                        <Avatar className="h-8 w-8 ring-2 ring-border/50 shadow-sm">
                          <AvatarImage src={room.other_user?.avatar_url || undefined} />
                          <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-blue-500 text-white text-xs">
                            {room.other_user?.full_name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                      )}
                      <span className="truncate text-sm font-medium">
                        {room.name || room.other_user?.full_name || "პირადი ჩატი"}
                      </span>
                    </div>
                    {room.unread_count! > 0 && (
                      <Badge className="ml-2 animate-fade-in shadow-md bg-gradient-to-r from-red-500 to-pink-500 border-0">
                        {room.unread_count}
                      </Badge>
                    )}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        )}
      </Card>

      {/* Chat Area */}
      <Card className="flex flex-1 flex-col p-0 overflow-hidden backdrop-blur-xl bg-card/80 border-border/30 shadow-2xl shadow-primary/5 animate-fade-in rounded-2xl">
        {selectedRoom ? (
          <>
            <div className="p-5 bg-gradient-to-r from-cyan-500/10 via-sky-500/10 to-blue-500/10 border-b border-border/30 backdrop-blur-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  {selectedRoom.other_user && (
                    <div className="relative">
                      <Avatar className="h-14 w-14 ring-3 ring-sky-500/20 transition-all duration-300 shadow-xl shadow-sky-500/10">
                        <AvatarImage src={selectedRoom.other_user.avatar_url || undefined} />
                        <AvatarFallback className="bg-gradient-to-br from-cyan-400 via-sky-500 to-blue-500 text-white text-xl font-bold">
                          {selectedRoom.other_user.full_name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div
                        className={`absolute -bottom-0.5 -right-0.5 h-4 w-4 rounded-full border-3 border-card ${getStatusColor(
                          selectedRoom.other_user.status
                        )} shadow-lg ${selectedRoom.other_user.status === 'online' ? 'animate-pulse' : ''}`}
                      />
                    </div>
                  )}
                  <div>
                    <h2 className="text-xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
                      {selectedRoom.name || selectedRoom.other_user?.full_name || "ჩატი"}
                    </h2>
                    {selectedRoom.other_user && (
                      <p className="text-sm text-muted-foreground flex items-center gap-2 mt-0.5">
                        <span className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${
                          selectedRoom.other_user.status === "online" 
                            ? "bg-green-500/10 text-green-600" 
                            : "bg-muted text-muted-foreground"
                        }`}>
                          <Circle className={`h-2 w-2 fill-current ${
                            selectedRoom.other_user.status === "online" ? "text-green-500" : "text-gray-400"
                          }`} />
                          {selectedRoom.other_user.status === "online" ? "ონლაინ" : "ოფლაინ"}
                        </span>
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex gap-3">
                  <Button 
                    size="lg" 
                    variant="outline" 
                    onClick={startVideoCall}
                    className="hover:bg-gradient-to-r hover:from-cyan-500/10 hover:to-blue-500/10 hover:border-sky-500/50 transition-all duration-300 hover:scale-105 shadow-md rounded-xl gap-2"
                  >
                    <Video className="h-5 w-5 text-sky-500" />
                    <span className="hidden sm:inline">ვიდეო ზარი</span>
                  </Button>
                </div>
              </div>
            </div>

            <ScrollArea className="flex-1 p-6 bg-gradient-to-b from-background/50 via-background/30 to-transparent">
              <div className="space-y-6">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex gap-4 animate-fade-in ${msg.sender_id === user?.id ? "flex-row-reverse" : ""}`}
                  >
                    <Avatar className="h-10 w-10 ring-2 ring-border/30 shadow-md flex-shrink-0">
                      <AvatarImage src={msg.sender_avatar || undefined} />
                      <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-blue-500 text-white font-medium">
                        {msg.sender_name?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className={`flex flex-col max-w-[70%] ${msg.sender_id === user?.id ? "items-end" : ""}`}
                    >
                      <div className={`flex items-center gap-2 mb-1.5 ${msg.sender_id === user?.id ? "flex-row-reverse" : ""}`}>
                        <span className="text-xs font-semibold text-foreground/80">{msg.sender_name}</span>
                        <span className="text-xs text-muted-foreground/60">
                          {new Date(msg.created_at).toLocaleTimeString("ka-GE", {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>
                      <div
                        className={`rounded-2xl px-5 py-3 shadow-lg transition-all duration-300 hover:shadow-xl ${
                          msg.sender_id === user?.id
                            ? "bg-gradient-to-br from-cyan-500 via-sky-500 to-blue-500 text-white rounded-br-md shadow-sky-500/20"
                            : "bg-card/90 backdrop-blur-sm border border-border/50 rounded-bl-md shadow-card/50"
                        }`}
                      >
                        {msg.type === 'file' && msg.file_url ? (
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <Paperclip className="h-4 w-4" />
                              <a 
                                href={msg.file_url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="underline hover:no-underline font-medium"
                              >
                                {msg.file_name || 'ფაილი'}
                              </a>
                            </div>
                            {msg.file_size && (
                              <div className="text-xs opacity-70">
                                {(msg.file_size / 1024).toFixed(1)} KB
                              </div>
                            )}
                            {msg.content && msg.content !== msg.file_name && (
                              <div className="mt-2">{msg.content}</div>
                            )}
                          </div>
                        ) : (
                          <p className="text-sm leading-relaxed">{msg.content}</p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            <div className="p-5 border-t border-border/30 bg-gradient-to-t from-muted/40 to-muted/20 backdrop-blur-xl space-y-3">
              {selectedFile && (
                <div className="flex items-center gap-3 rounded-2xl bg-gradient-to-r from-cyan-500/5 via-sky-500/5 to-blue-500/5 p-4 border border-sky-500/20 animate-fade-in shadow-lg shadow-sky-500/5">
                  <div className="p-3 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-500 shadow-md">
                    <Paperclip className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="truncate text-sm font-semibold">{selectedFile.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(selectedFile.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setSelectedFile(null);
                      if (fileInputRef.current) {
                        fileInputRef.current.value = '';
                      }
                    }}
                    className="hover:bg-destructive/10 hover:text-destructive transition-all duration-300 rounded-xl"
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              )}
              
              <div className="flex gap-3 relative">
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  onChange={handleFileSelect}
                />
                <Button
                  size="icon"
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  className="h-12 w-12 hover:bg-gradient-to-r hover:from-cyan-500/10 hover:to-blue-500/10 hover:border-sky-500/50 transition-all duration-300 hover:scale-110 shadow-md rounded-xl"
                >
                  <Paperclip className="h-5 w-5 text-sky-500" />
                </Button>
                <div className="relative">
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                    className="h-12 w-12 hover:bg-gradient-to-r hover:from-amber-500/10 hover:to-orange-500/10 hover:border-amber-500/50 transition-all duration-300 hover:scale-110 shadow-md rounded-xl"
                  >
                    <Smile className="h-5 w-5 text-amber-500" />
                  </Button>
                  {showEmojiPicker && (
                    <div 
                      ref={emojiPickerRef}
                      className="absolute bottom-14 left-0 z-50 animate-fade-in shadow-2xl rounded-2xl overflow-hidden"
                    >
                      <EmojiPicker 
                        onEmojiClick={handleEmojiClick}
                        searchPlaceHolder="ძებნა..."
                        width={350}
                        height={400}
                      />
                    </div>
                  )}
                </div>
                <Input
                  placeholder="დაწერეთ შეტყობინება..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
                  className="h-12 border-border/30 focus:border-sky-500/50 focus:ring-2 focus:ring-sky-500/20 transition-all duration-300 bg-card/50 backdrop-blur-sm rounded-xl text-base"
                />
                <Button 
                  onClick={sendMessage} 
                  disabled={!newMessage.trim() && !selectedFile}
                  className="h-12 px-6 bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-500 hover:opacity-90 transition-all duration-300 hover:scale-105 shadow-xl shadow-sky-500/30 disabled:opacity-50 rounded-xl gap-2"
                >
                  <Send className="h-5 w-5" />
                  <span className="hidden sm:inline font-medium">გაგზავნა</span>
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex h-full items-center justify-center bg-gradient-to-br from-background via-background/95 to-cyan-500/5">
            <div className="text-center space-y-6 animate-fade-in max-w-md px-8">
              <div className="mx-auto w-28 h-28 rounded-3xl bg-gradient-to-br from-cyan-400 via-sky-500 to-blue-500 flex items-center justify-center shadow-2xl shadow-sky-500/30 animate-pulse">
                <MessageCircle className="h-14 w-14 text-white" />
              </div>
              <div className="space-y-3">
                <h3 className="text-2xl font-bold bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 bg-clip-text text-transparent">
                  მესენჯერი
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  აირჩიეთ თანამშრომელი მარცხენა პანელიდან ან გააგრძელეთ წინა საუბარი
                </p>
              </div>
              <div className="flex items-center justify-center gap-4 pt-4">
                <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-green-500/10 text-green-600 text-sm font-medium">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  რეალ-ტაიმ
                </div>
                <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-sky-500/10 text-sky-600 text-sm font-medium">
                  <Video className="w-4 h-4" />
                  ვიდეო ზარი
                </div>
              </div>
            </div>
          </div>
        )}
      </Card>

      {/* Incoming Call Dialog */}
      <Dialog open={!!incomingCall} onOpenChange={(open) => !open && setIncomingCall(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>შემომავალი ვიდეო ზარი</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p>
              მომხმარებელი {employees.find(e => e.id === incomingCall?.fromUserId)?.full_name || 'უცნობი'} გირეკავთ
            </p>
            <div className="flex flex-wrap gap-2">
              <Button
                className="flex-1"
                onClick={() => {
                  if (!incomingCall) return;
                  const room = rooms.find(r => r.id === incomingCall.roomId);
                  if (room) {
                    setSelectedRoom(room);
                    setVideoCallRemoteUserId(incomingCall.fromUserId);
                    setVideoCallInitiator(false);
                    setInitialSignal({ signal_type: 'offer', signal_data: incomingCall.offer });
                    setShowVideoCall(true);
                    setIncomingCall(null);
                  }
                }}
              >
                <Video className="mr-2 h-4 w-4" />
                პასუხი
              </Button>
              <Button
                variant="destructive"
                className="flex-1"
                onClick={() => setIncomingCall(null)}
              >
                უარყოფა
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* AI Assistant Dialog */}
      <Dialog open={showAI} onOpenChange={setShowAI}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bot className="h-5 w-5" />
              AI ასისტენტი
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              <Input
                placeholder="დასვით შეკითხვა (მაგ: რა არის შრომის კოდექსი?)"
                value={aiInput}
                onChange={(e) => setAiInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && askAI()}
              />
              <Button onClick={askAI} disabled={isAiLoading}>
                {isAiLoading ? "..." : "გაგზავნა"}
              </Button>
            </div>
            {aiResponse && (
              <Card className="p-4">
                <p className="whitespace-pre-wrap">{aiResponse}</p>
              </Card>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
