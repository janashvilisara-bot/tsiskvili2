import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { 
  Clock, User, Mail, Phone, Calendar, Briefcase, 
  CheckCircle, XCircle, AlertCircle, Umbrella, DollarSign,
  FileText, Send, MapPin, Plane, TrendingUp, Target, Car,
  Plus, ListTodo, FileSignature, Download, Eye, Search, Filter, Bell, Check, Star
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { PageTransition } from "@/components/PageTransition";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatters, safeFormatDate } from "@/lib/dateUtils";
import { format, startOfMonth, endOfMonth, isSameDay, parseISO } from "date-fns";
import { ka } from "date-fns/locale";
import SurveysSection from "@/components/portal/SurveysSection";
import AttendanceHistory from "@/components/portal/AttendanceHistory";
import MonthlyAttendanceConfirmation from "@/components/portal/MonthlyAttendanceConfirmation";
import hrDashboardBg from "@/assets/hr-dashboard-bg.jpg";
import HRCommandCenter from "@/components/portal/HRCommandCenter";

interface LeaveBalance {
  annual: number;
  sick: number;
  personal: number;
  unpaid: number;
}

interface PendingRequest {
  id: string;
  type: 'leave' | 'business_trip' | 'vehicle';
  title: string;
  dates: string;
  status: string;
  created_at: string;
}

interface CalendarEvent {
  date: Date;
  type: 'leave' | 'business_trip' | 'shift';
  title: string;
  employeeName?: string;
  department?: string;
  leaveType?: string;
}

interface MonthStats {
  attendancePercentage: number;
  overtimeHours: number;
  completedTasks: number;
}

interface Task {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  due_date: string;
  progress: number;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  is_read: boolean;
  created_at: string;
  created_by?: string;
}

interface FavoritePage {
  id: string;
  page_path: string;
  page_title: string;
  icon?: string;
}

export default function EmployeePortal() {
  const { user, userRole } = useAuth();
  const isEmpOnly = userRole === "employee";
  const navigate = useNavigate();
  const [employee, setEmployee] = useState<any>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [todayAttendance, setTodayAttendance] = useState<any>(null);
  const [leaveBalance, setLeaveBalance] = useState<LeaveBalance>({
    annual: 0,
    sick: 0,
    personal: 0,
    unpaid: 0,
  });
  const [pendingRequests, setPendingRequests] = useState<PendingRequest[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [monthStats, setMonthStats] = useState<MonthStats>({
    attendancePercentage: 0,
    overtimeHours: 0,
    completedTasks: 0,
  });
  const [activeTasks, setActiveTasks] = useState<Task[]>([]);
  const [pendingSignatures, setPendingSignatures] = useState<any[]>([]);
  const [signifyRequests, setSignifyRequests] = useState<any[]>([]);
  const [signedDocuments, setSignedDocuments] = useState<any[]>([]);
  const [showSignedHistory, setShowSignedHistory] = useState(false);
  const [documentSearchQuery, setDocumentSearchQuery] = useState("");
  const [documentCategoryFilter, setDocumentCategoryFilter] = useState<string>("all");
  const [documentDateFrom, setDocumentDateFrom] = useState<Date | undefined>();
  const [documentDateTo, setDocumentDateTo] = useState<Date | undefined>();
  const [selectedDateDetails, setSelectedDateDetails] = useState<{date: Date, employees: any[]} | null>(null);
  const [showDateDetailsDialog, setShowDateDetailsDialog] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [notificationFilter, setNotificationFilter] = useState<string>("all");
  const [showAllNotifications, setShowAllNotifications] = useState(false);
  const [favorites, setFavorites] = useState<FavoritePage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchEmployeeData();
    }
  }, [user]);

  // Realtime subscriptions
  useEffect(() => {
    if (!employee?.id) return;

    const tasksChannel = supabase
      .channel('employee-tasks-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'tasks',
          filter: `assigned_to=eq.${employee.id}`,
        },
        () => {
          fetchActiveTasks(employee.id);
          fetchMonthStats(employee.id);
        }
      )
      .subscribe();

    const leaveChannel = supabase
      .channel('employee-leave-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'leave_requests',
          filter: `employee_id=eq.${employee.id}`,
        },
        () => {
          fetchPendingRequests(employee.id);
          fetchLeaveBalance(employee.id);
          fetchCalendarEvents(employee.id);
        }
      )
      .subscribe();

    const tripChannel = supabase
      .channel('employee-trip-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'business_trip_requests',
          filter: `employee_id=eq.${employee.id}`,
        },
        () => {
          fetchPendingRequests(employee.id);
          fetchCalendarEvents(employee.id);
        }
      )
      .subscribe();

    const vehicleChannel = supabase
      .channel('employee-vehicle-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'vehicle_requests',
          filter: `employee_id=eq.${employee.id}`,
        },
        () => {
          fetchPendingRequests(employee.id);
        }
      )
      .subscribe();

    const notificationsChannel = supabase
      .channel('employee-notifications-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user?.id}`,
        },
        () => {
          fetchNotifications();
        }
      )
      .subscribe();

    // Refetch signify requests when user returns from signing tab
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        fetchSignifyRequests();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    const signifyChannel = supabase
      .channel('employee-signify-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'signify_signing_requests',
        },
        () => {
          fetchSignifyRequests();
        }
      )
      .subscribe();

    // Realtime subscription for attendance (turnstile check-in/check-out)
    const attendanceChannel = supabase
      .channel('employee-attendance-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'attendance',
          filter: `employee_id=eq.${employee.id}`,
        },
        () => {
          fetchEmployeeData();
        }
      )
      .subscribe();

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      supabase.removeChannel(tasksChannel);
      supabase.removeChannel(leaveChannel);
      supabase.removeChannel(tripChannel);
      supabase.removeChannel(vehicleChannel);
      supabase.removeChannel(notificationsChannel);
      supabase.removeChannel(signifyChannel);
      supabase.removeChannel(attendanceChannel);
    };
  }, [employee?.id, user?.id]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const fetchEmployeeData = async () => {
    setLoading(true);
    try {
      // Get employee first (needed for subsequent queries)
      const { data: empData } = await supabase
        .from('employees')
        .select('*')
        .eq('user_id', user?.id)
        .maybeSingle();
      
      setEmployee(empData);

      if (!empData) return;

      // Run all independent fetches in parallel
      const today = new Date().toISOString().split('T')[0];
      const [attendanceResult] = await Promise.all([
        supabase
          .from('attendance')
          .select('*')
          .eq('employee_id', empData.id)
          .eq('date', today)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle(),
        fetchLeaveBalance(empData.id),
        fetchPendingRequests(empData.id),
        fetchAnnouncements(),
        fetchCalendarEvents(empData.id),
        fetchMonthStats(empData.id),
        fetchActiveTasks(empData.id),
        fetchPendingSignatures(empData.id),
        fetchSignifyRequests(),
        fetchSignedDocuments(empData.id),
        fetchNotifications(),
        fetchFavorites(),
      ]);

      setTodayAttendance(attendanceResult.data);
      setIsCheckedIn(attendanceResult.data?.check_in && !attendanceResult.data?.check_out);

    } catch (error: any) {
      console.error('Error fetching employee data:', error);
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setLoading(false);
    }
  };

  const fetchNotifications = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      setNotifications(data || []);
      const unread = data?.filter(n => !n.is_read).length || 0;
      setUnreadNotifications(unread);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    }
  };

  const markNotificationAsRead = async (notificationId: string) => {
    try {
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notificationId);

      if (error) throw error;

      await fetchNotifications();
      toast.success('შეტყობინება წაკითხულად მონიშნულია');
    } catch (error) {
      toast.error('შეცდომა მოხდა');
    }
  };

  const markAllNotificationsAsRead = async () => {
    if (!user) return;
    
    try {
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('user_id', user.id)
        .eq('is_read', false);

      if (error) throw error;

      await fetchNotifications();
      toast.success('ყველა შეტყობინება წაკითხულად მონიშნულია');
    } catch (error) {
      toast.error('შეცდომა მოხდა');
    }
  };

  const fetchFavorites = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('user_favorites')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setFavorites(data || []);
    } catch (error) {
      console.error('Error fetching favorites:', error);
    }
  };

  const addToFavorites = async (path: string, title: string, icon?: string) => {
    if (!user) return;
    
    try {
      const { error } = await supabase
        .from('user_favorites')
        .insert({
          user_id: user.id,
          page_path: path,
          page_title: title,
          icon: icon
        });

      if (error) throw error;
      
      await fetchFavorites();
      toast.success('ფავორიტებში დაემატა');
    } catch (error: any) {
      if (error.code === '23505') {
        toast.error('ეს გვერდი უკვე ფავორიტებშია');
      } else {
        toast.error('შეცდომა მოხდა');
      }
    }
  };

  const removeFromFavorites = async (favoriteId: string) => {
    try {
      const { error } = await supabase
        .from('user_favorites')
        .delete()
        .eq('id', favoriteId);

      if (error) throw error;
      
      await fetchFavorites();
      toast.success('ფავორიტებიდან წაიშალა');
    } catch (error) {
      toast.error('შეცდომა მოხდა');
    }
  };

  const fetchLeaveBalance = async (employeeId: string) => {
    try {
      const currentYear = new Date().getFullYear();
      const startOfYear = `${currentYear}-01-01`;
      const endOfYear = `${currentYear}-12-31`;

      const { data: approvedLeaves } = await supabase
        .from('leave_requests')
        .select('leave_type, start_date, end_date')
        .eq('employee_id', employeeId)
        .eq('status', 'approved')
        .gte('start_date', startOfYear)
        .lte('end_date', endOfYear);

      const usedDays = {
        annual: 0,
        sick: 0,
        personal: 0,
        unpaid: 0,
      };

      if (approvedLeaves) {
        approvedLeaves.forEach((leave) => {
          const start = new Date(leave.start_date);
          const end = new Date(leave.end_date);
          const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
          
          if (leave.leave_type === 'annual') usedDays.annual += days;
          else if (leave.leave_type === 'sick') usedDays.sick += days;
          else if (leave.leave_type === 'personal') usedDays.personal += days;
          else if (leave.leave_type === 'unpaid') usedDays.unpaid += days;
        });
      }

      const standardAllocation = {
        annual: 24,
        sick: 15,
        personal: 5,
        unpaid: 30,
      };

      setLeaveBalance({
        annual: Math.max(0, standardAllocation.annual - usedDays.annual),
        sick: Math.max(0, standardAllocation.sick - usedDays.sick),
        personal: Math.max(0, standardAllocation.personal - usedDays.personal),
        unpaid: Math.max(0, standardAllocation.unpaid - usedDays.unpaid),
      });
    } catch (error) {
      console.error('Error fetching leave balance:', error);
    }
  };

  const fetchPendingRequests = async (employeeId: string) => {
    try {
      const requests: PendingRequest[] = [];

      // Leave requests
      const { data: leaves } = await supabase
        .from('leave_requests')
        .select('*')
        .eq('employee_id', employeeId)
        .eq('status', 'pending');

      if (leaves) {
        leaves.forEach(leave => {
          requests.push({
            id: leave.id,
            type: 'leave',
            title: 'შვებულების მოთხოვნა',
            dates: `${formatters.shortDateWithMonth(leave.start_date)} - ${formatters.longDate(leave.end_date)}`,
            status: leave.status,
            created_at: leave.created_at,
          });
        });
      }

      // Business trip requests
      const { data: trips } = await supabase
        .from('business_trip_requests')
        .select('*')
        .eq('employee_id', employeeId)
        .eq('status', 'pending');

      if (trips) {
        trips.forEach(trip => {
          requests.push({
            id: trip.id,
            type: 'business_trip',
            title: 'მივლინების მოთხოვნა',
            dates: `${formatters.shortDateWithMonth(trip.start_date)} - ${formatters.longDate(trip.end_date)}`,
            status: trip.status,
            created_at: trip.created_at,
          });
        });
      }

      // Vehicle requests
      const { data: vehicles } = await supabase
        .from('vehicle_requests')
        .select('*')
        .eq('employee_id', employeeId)
        .eq('status', 'pending');

      if (vehicles) {
        vehicles.forEach(vehicle => {
          requests.push({
            id: vehicle.id,
            type: 'vehicle',
            title: 'ტრანსპორტის მოთხოვნა',
            dates: formatters.longDate(vehicle.start_date),
            status: vehicle.status,
            created_at: vehicle.created_at,
          });
        });
      }

      setPendingRequests(requests.sort((a, b) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      ));
    } catch (error) {
      console.error('Error fetching pending requests:', error);
    }
  };

  const fetchAnnouncements = async () => {
    try {
      const { data } = await supabase
        .from('announcements')
        .select('*')
        .eq('published', true)
        .order('created_at', { ascending: false })
        .limit(5);

      setAnnouncements(data || []);
    } catch (error) {
      console.error('Error fetching announcements:', error);
    }
  };

  const fetchCalendarEvents = async (employeeId: string) => {
    try {
      const events: CalendarEvent[] = [];
      const today = new Date();

      // Check if user is admin or HR to show all employees' leaves
      const { data: { user } } = await supabase.auth.getUser();
      const { data: userRoles } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user?.id);
      
      const isAdminOrHR = userRoles?.some(r => r.role === 'admin' || r.role === 'hr_manager');

      // Fetch approved leave requests
      let leaveQuery = supabase
        .from('leave_requests')
        .select(`
          *,
          employee:employees!leave_requests_employee_id_fkey (
            full_name,
            department
          )
        `)
        .eq('status', 'approved')
        .gte('end_date', today.toISOString().split('T')[0]);

      if (!isAdminOrHR) {
        leaveQuery = leaveQuery.eq('employee_id', employeeId);
      }

      const { data: leaves } = await leaveQuery;

      if (leaves) {
        leaves.forEach(leave => {
          const start = new Date(leave.start_date);
          const end = new Date(leave.end_date);
          for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
            events.push({
              date: new Date(d),
              type: 'leave',
              title: isAdminOrHR ? `${leave.employee?.full_name} - შვებულება` : 'შვებულება',
              employeeName: leave.employee?.full_name,
              department: leave.employee?.department,
              leaveType: leave.leave_type,
            });
          }
        });
      }

      // Fetch approved business trips (only own for non-admins)
      let tripQuery = supabase
        .from('business_trip_requests')
        .select(`
          *,
          employee:employees!business_trip_requests_employee_id_fkey (
            full_name
          )
        `)
        .eq('status', 'approved')
        .gte('end_date', today.toISOString().split('T')[0]);

      if (!isAdminOrHR) {
        tripQuery = tripQuery.eq('employee_id', employeeId);
      }

      const { data: trips } = await tripQuery;

      if (trips) {
        trips.forEach(trip => {
          const start = new Date(trip.start_date);
          const end = new Date(trip.end_date);
          for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
            events.push({
              date: new Date(d),
              type: 'business_trip',
              title: isAdminOrHR ? `${trip.employee?.full_name} - ${trip.destination}` : `მივლინება - ${trip.destination}`,
              employeeName: trip.employee?.full_name,
            });
          }
        });
      }

      // Fetch shift schedules (only own)
      const { data: shifts } = await supabase
        .from('shift_schedules')
        .select('*')
        .eq('employee_id', employeeId)
        .gte('shift_date', today.toISOString().split('T')[0]);

      if (shifts) {
        shifts.forEach(shift => {
          events.push({
            date: new Date(shift.shift_date),
            type: 'shift',
            title: `ცვლა: ${shift.start_time} - ${shift.end_time}`,
          });
        });
      }

      setCalendarEvents(events);
    } catch (error) {
      console.error('Error fetching calendar events:', error);
    }
  };

  const fetchMonthStats = async (employeeId: string) => {
    try {
      const now = new Date();
      const monthStart = startOfMonth(now);
      const monthEnd = endOfMonth(now);

      // Attendance percentage
      const { data: attendanceData } = await supabase
        .from('attendance')
        .select('*')
        .eq('employee_id', employeeId)
        .gte('date', format(monthStart, 'yyyy-MM-dd'))
        .lte('date', format(monthEnd, 'yyyy-MM-dd'));

      const workingDays = attendanceData?.length || 0;
      const totalDaysInMonth = now.getDate();
      const attendancePercentage = workingDays > 0 ? Math.round((workingDays / totalDaysInMonth) * 100) : 0;

      // Overtime hours
      const overtimeHours = attendanceData?.reduce((sum, record) => {
        return sum + (record.overtime_hours || 0);
      }, 0) || 0;

      // Completed tasks
      const { data: tasksData } = await supabase
        .from('tasks')
        .select('*')
        .eq('assigned_to', employeeId)
        .eq('status', 'approved')
        .gte('updated_at', monthStart.toISOString())
        .lte('updated_at', monthEnd.toISOString());

      const completedTasks = tasksData?.length || 0;

      setMonthStats({
        attendancePercentage,
        overtimeHours,
        completedTasks,
      });
    } catch (error) {
      console.error('Error fetching month stats:', error);
    }
  };

  const fetchActiveTasks = async (employeeId: string) => {
    try {
      const { data: tasksData } = await supabase
        .from('tasks')
        .select('*')
        .eq('assigned_to', employeeId)
        .in('status', ['pending', 'in_progress', 'submitted'])
        .order('due_date', { ascending: true })
        .limit(5);

      if (tasksData) {
        const tasks = tasksData.map(task => ({
          ...task,
          progress: task.status === 'pending' ? 0 : 
                   task.status === 'in_progress' ? 50 : 
                   task.status === 'submitted' ? 100 : 0
        }));
        setActiveTasks(tasks);
      }
    } catch (error) {
      console.error('Error fetching active tasks:', error);
    }
  };

  const fetchPendingSignatures = async (employeeId: string) => {
    try {
      const { data, error } = await supabase
        .from('document_signatures')
        .select(`
          *,
          documents (
            id,
            title,
            file_path,
            category,
            created_at
          )
        `)
        .eq('employee_id', employeeId)
        .eq('is_acknowledged', false)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPendingSignatures(data || []);
    } catch (error) {
      console.error('Error fetching pending signatures:', error);
    }
  };

  const fetchSignifyRequests = async () => {
    try {
      if (!user?.email) return;
      const { data, error } = await supabase
        .from('signify_signing_requests' as any)
        .select('*')
        .eq('recipient_email', user.email)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setSignifyRequests((data as any[]) || []);
    } catch (error) {
      console.error('Error fetching signify requests:', error);
    }
  };

  const handleOpenSignifyLink = async (request: any) => {
    const openAndRefresh = (url: string) => {
      const newWindow = window.open(url, '_blank');
      // Refresh signing requests when user returns to this tab
      const handleFocus = () => {
        fetchSignifyRequests();
        if (employee?.id) {
          fetchSignedDocuments(employee.id);
          fetchPendingSignatures(employee.id);
        }
        window.removeEventListener('focus', handleFocus);
      };
      window.addEventListener('focus', handleFocus);
    };

    if (request.signing_url) {
      openAndRefresh(request.signing_url);
    } else if (request.signify_document_id && request.signify_recipient_id) {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session?.access_token) {
          toast.error('გთხოვთ გაიაროთ ავტორიზაცია');
          return;
        }
        const res = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/signify-sign`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${session.access_token}`,
            },
            body: JSON.stringify({
              action: 'generate-document-link',
              documentId: Number(request.signify_document_id),
              recipientId: Number(request.signify_recipient_id),
            }),
          }
        );
        const result = await res.json();
        if (result.success && result.url) {
          openAndRefresh(result.url);
        } else {
          toast.error(result.error || 'ბმულის გენერაცია ვერ მოხერხდა');
        }
      } catch (err) {
        toast.error('შეცდომა ბმულის გენერაციისას');
      }
    } else {
      toast.error('ხელმოწერის ბმული არ არის ხელმისაწვდომი');
    }
  };

  const fetchSignedDocuments = async (employeeId: string) => {
    try {
      const { data, error } = await supabase
        .from('document_signatures')
        .select(`
          *,
          documents (
            id,
            title,
            file_path,
            category,
            created_at
          )
        `)
        .eq('employee_id', employeeId)
        .eq('is_acknowledged', true)
        .order('signed_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setSignedDocuments(data || []);
    } catch (error) {
      console.error('Error fetching signed documents:', error);
    }
  };

  const handleDownloadDocument = async (filePath: string, title: string, documentId?: string) => {
    try {
      // Log document access
      if (documentId) {
        const { logSensitiveDataAccess } = await import('@/lib/securityLogger');
        await logSensitiveDataAccess('documents', documentId);
      }

      const { data, error } = await supabase.storage
        .from('documents')
        .download(filePath);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = title;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('დოკუმენტი ჩამოტვირთულია');
    } catch (error: any) {
      toast.error('ჩამოტვირთვა ვერ მოხერხდა');
    }
  };

  const handleSignDocument = async (signatureId: string) => {
    try {
      const { error } = await supabase
        .from('document_signatures')
        .update({
          is_acknowledged: true,
          signed_at: new Date().toISOString(),
          signature_data: 'Electronic Signature',
          ip_address: 'Unknown',
        })
        .eq('id', signatureId);

      if (error) throw error;
      toast.success('დოკუმენტი ხელმოწერილია');
      if (employee?.id) {
        fetchPendingSignatures(employee.id);
        fetchSignedDocuments(employee.id);
      }
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    }
  };

  const getTaskPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'destructive';
      case 'medium':
        return 'default';
      case 'low':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  const getTaskStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'მოლოდინში';
      case 'in_progress':
        return 'მიმდინარე';
      case 'submitted':
        return 'გაგზავნილი';
      case 'approved':
        return 'დამტკიცებული';
      default:
        return status;
    }
  };

  const handleCheckInOut = async () => {
    if (!employee) return;

    try {
      const today = new Date().toISOString().split('T')[0];
      const now = new Date().toTimeString().split(' ')[0];

      if (!isCheckedIn) {
        // Check in - allow multiple entries per day (new record after previous check_out)

        const { error } = await supabase
          .from('attendance')
          .insert({
            employee_id: employee.id,
            date: today,
            check_in: now,
            status: 'present',
            check_in_method: 'portal',
          });

        if (error) throw error;
        toast.success('შესვლა წარმატებით აღირიცხა');
        setIsCheckedIn(true);
        await fetchEmployeeData();
      } else {
        // Check out
        if (!todayAttendance) {
          toast.error('შესვლა არ არის აღრიცხული');
          return;
        }

        const { error } = await supabase
          .from('attendance')
          .update({
            check_out: now,
            check_out_method: 'portal',
          })
          .eq('id', todayAttendance.id);

        if (error) throw error;
        toast.success('გასვლა წარმატებით აღირიცხა');
        setIsCheckedIn(false);
        await fetchEmployeeData();
      }
    } catch (error: any) {
      console.error('Error checking in/out:', error);
      toast.error('შეცდომა დასწრების აღრიცხვისას');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'rejected':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'pending':
        return <AlertCircle className="h-4 w-4 text-orange-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'approved':
        return 'დამტკიცებული';
      case 'rejected':
        return 'უარყოფილი';
      case 'pending':
        return 'განხილვაში';
      default:
        return status;
    }
  };

  const getRequestIcon = (type: string) => {
    switch (type) {
      case 'leave':
        return <Umbrella className="h-5 w-5" />;
      case 'business_trip':
        return <Plane className="h-5 w-5" />;
      case 'vehicle':
        return <MapPin className="h-5 w-5" />;
      default:
        return <FileText className="h-5 w-5" />;
    }
  };

  if (loading) {
    return (
      <PageTransition>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </PageTransition>
    );
  }

  const getEventsForDate = (date: Date) => {
    return calendarEvents.filter(event => isSameDay(event.date, date));
  };

  const handleDateClick = async (date: Date | undefined) => {
    if (!date || !employee) return;
    
    const eventsOnDate = calendarEvents.filter(event => isSameDay(event.date, date));
    const leaveEventsOnDate = eventsOnDate.filter(e => e.type === 'leave');
    
    if (leaveEventsOnDate.length > 0) {
      // Check if user is admin/HR to see all employees on leave
      const { data: userRoles } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user?.id);
      
      const isAdminOrHR = userRoles?.some(r => r.role === 'admin' || r.role === 'hr_manager');
      
      if (isAdminOrHR) {
        // Group employees by department
        const employeesGrouped = leaveEventsOnDate.map(event => ({
          name: event.employeeName,
          department: event.department,
          leaveType: event.leaveType,
        }));
        
        setSelectedDateDetails({
          date,
          employees: employeesGrouped,
        });
        setShowDateDetailsDialog(true);
      }
    }
    
    setSelectedDate(date);
  };

  const modifiers = {
    leave: calendarEvents.filter(e => e.type === 'leave').map(e => e.date),
    businessTrip: calendarEvents.filter(e => e.type === 'business_trip').map(e => e.date),
    shift: calendarEvents.filter(e => e.type === 'shift').map(e => e.date),
  };

  const modifiersClassNames = {
    leave: 'bg-blue-500/20 text-blue-600 font-semibold',
    businessTrip: 'bg-purple-500/20 text-purple-600 font-semibold',
    shift: 'bg-green-500/20 text-green-600 font-semibold',
  };

  // Cards reused in the stacked layout (admin/HR) and the horizontal strip (employee)
  const newsCard = (
          <Card className={`group relative overflow-hidden border-border/50 bg-card/95`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  <h3 className="font-display text-lg font-semibold">სიახლეები</h3>
                  {announcements.length > 0 && (
                    <Badge variant="secondary" className="text-xs">
                      {announcements.length}
                    </Badge>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate('/announcements')}
                  className="h-8"
                >
                  ყველას ნახვა
                </Button>
              </div>

              {announcements.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  სიახლეები არ არის
                </div>
              ) : (
                <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                  {announcements.slice(0, 6).map((announcement) => (
                    <div 
                      key={announcement.id}
                      className={`p-4 rounded-lg border transition-all ${
                        announcement.priority === 'high'
                          ? 'border-destructive/30 bg-destructive/5 shadow-sm'
                          : 'border-border/50 bg-muted/10 hover:bg-muted/20'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h4 className={`text-sm font-semibold line-clamp-1 ${announcement.priority === 'high' ? 'text-destructive' : ''}`}>
                          {announcement.title}
                        </h4>
                        <Badge 
                          variant={announcement.priority === 'high' ? 'destructive' : 'secondary'}
                          className="shrink-0 text-xs"
                        >
                          {announcement.announcement_type}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                        {announcement.content}
                      </p>
                      <div className="text-xs text-muted-foreground">
                        {formatters.shortDateTime(announcement.created_at)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
  );

  const tasksCard = (
            <Card className="group relative overflow-hidden border-border/50 bg-card/95">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <ListTodo className="h-5 w-5 text-primary" />
                    <h3 className="font-display text-lg font-semibold">აქტიური დავალებები</h3>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate('/tasks')}
                  >
                    ყველა
                  </Button>
                </div>

                {/* Signify signing requests as tasks */}
                {signifyRequests.length > 0 && (
                  <div className="space-y-3 mb-4">
                    {signifyRequests.map((req: any) => (
                      <div
                        key={req.id}
                        className="p-4 rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/20 space-y-3"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <FileSignature className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0" />
                              <span className="font-medium text-sm">ხელმოსაწერი დოკუმენტი</span>
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {req.recipient_name || req.recipient_email}
                            </div>
                          </div>
                          <Badge variant="outline" className="border-amber-300 text-amber-700 dark:border-amber-700 dark:text-amber-400 shrink-0">
                            მოლოდინში
                          </Badge>
                        </div>
                        <Button
                          size="sm"
                          className="w-full bg-amber-600 hover:bg-amber-700 text-white"
                          onClick={() => handleOpenSignifyLink(req)}
                        >
                          <FileSignature className="mr-2 h-4 w-4" />
                          ხელმოწერა
                        </Button>
                      </div>
                    ))}
                  </div>
                )}

                {activeTasks.length === 0 && signifyRequests.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    აქტიური დავალებები არ გაქვთ
                  </div>
                ) : (
                  <div className="space-y-4">
                    {activeTasks.slice(0, 3).map((task) => (
                      <div 
                        key={task.id}
                        className="p-4 rounded-lg border border-border/50 hover:bg-muted/30 transition-colors space-y-3"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm mb-1">{task.title}</div>
                            <div className="text-xs text-muted-foreground line-clamp-2">
                              {task.description}
                            </div>
                          </div>
                          <Badge variant={getTaskPriorityColor(task.priority)}>
                            {task.priority === 'high' ? 'მაღალი' : 
                             task.priority === 'medium' ? 'საშუალო' : 'დაბალი'}
                          </Badge>
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-muted-foreground">
                              {getTaskStatusText(task.status)}
                            </span>
                            <span className="font-medium">{task.progress}%</span>
                          </div>
                          <Progress value={task.progress} className="h-2" />
                        </div>

                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            <span>
                              {task.due_date ? formatters.longDate(task.due_date) : 'N/A'}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
  );

  const notificationsCard = (
        <Card className={`group relative overflow-hidden border-border/50 bg-card/95`}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                <h3 className="font-display text-lg font-semibold">შეტყობინებები</h3>
                {unreadNotifications > 0 && (
                  <Badge variant="destructive" className="ml-2">
                    {unreadNotifications}
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate('/notifications')}
                  className="h-8"
                >
                  ყველას ნახვა
                </Button>
                <Select value={notificationFilter} onValueChange={setNotificationFilter}>
                  <SelectTrigger className="w-[140px] h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა</SelectItem>
                    <SelectItem value="general">ზოგადი</SelectItem>
                    <SelectItem value="leave">შვებულება</SelectItem>
                    <SelectItem value="document">დოკუმენტი</SelectItem>
                    <SelectItem value="new_employee">ახალი თანამშრომელი</SelectItem>
                  </SelectContent>
                </Select>
                {unreadNotifications > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={markAllNotificationsAsRead}
                    className="h-8"
                  >
                    <Check className="h-4 w-4 mr-1" />
                    ყველა
                  </Button>
                )}
              </div>
            </div>

            {notifications.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                შეტყობინებები არ არის
              </div>
            ) : (
              <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                {notifications
                  .filter(n => notificationFilter === 'all' || n.type === notificationFilter)
                  .slice(0, 6)
                  .map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 rounded-lg border transition-all ${
                        notification.is_read
                          ? 'border-border/30 bg-muted/10'
                          : 'border-destructive/30 bg-destructive/5 shadow-sm'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className={`text-sm font-semibold ${!notification.is_read ? 'text-destructive' : ''}`}>
                              {notification.title}
                            </h4>
                            {!notification.is_read && (
                              <Badge variant="destructive" className="text-xs">ახალი</Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                            {notification.message}
                          </p>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground">
                            <span>{formatters.shortDateTime(notification.created_at)}</span>
                          </div>
                        </div>
                        {!notification.is_read && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => markNotificationAsRead(notification.id)}
                            className="h-8 shrink-0"
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </CardContent>
        </Card>
  );

  const surveysCard = employee?.id ? (
    <SurveysSection employeeId={employee.id} />
  ) : null;

  return (
    <PageTransition>
      <div className={isEmpOnly ? "flex flex-col gap-6 animate-fade-in" : "space-y-6 animate-fade-in"}>
          {/* Solid hero header */}
          <div className={`${isEmpOnly ? "order-[-10] " : ""}relative overflow-hidden rounded-2xl border border-white/10 portal-hero shadow-xl`}>
            <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '26px 26px' }} />
            <div className="absolute -top-24 -right-16 h-80 w-80 rounded-full bg-primary/30 blur-[90px]" />
            <div className="absolute -bottom-24 -left-10 h-64 w-64 rounded-full bg-accent/25 blur-[80px]" />

            <div className="relative z-10 flex flex-col gap-5 p-5 sm:p-8 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:gap-5">
                <Avatar className="h-16 w-16 sm:h-20 sm:w-20 ring-2 ring-white/25 shadow-lg">
                  <AvatarImage src={employee?.avatar_url} />
                  <AvatarFallback className="bg-white/10 text-xl text-white">
                    {employee?.full_name?.charAt(0) || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 space-y-1.5">
                  <p className="text-xs sm:uppercase sm:tracking-[0.18em] text-white/50">
                    {currentTime.getHours() < 12 ? 'დილა მშვიდობისა' : currentTime.getHours() < 18 ? 'შუადღე მშვიდობისა' : 'საღამო მშვიდობისა'}
                  </p>
                  <h1 className="truncate font-display text-2xl font-bold tracking-tight sm:text-3xl">{employee?.full_name || 'თანამშრომელი'}</h1>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-white/70">
                    {employee?.position && (
                      <span className="rounded-full border border-white/15 bg-white/10 px-2.5 py-1">{employee.position}</span>
                    )}
                    <span className="rounded-full border border-white/15 bg-white/10 px-2.5 py-1">
                      {format(currentTime, 'dd MMMM yyyy', { locale: ka })}
                    </span>
                    <span className={`rounded-full border px-2.5 py-1 ${isCheckedIn ? 'border-emerald-400/30 bg-emerald-400/15 text-emerald-200' : 'border-white/15 bg-white/10'}`}>
                      {isCheckedIn ? 'სამსახურში ხართ' : 'არ ხართ დაფიქსირებული'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 sm:flex sm:items-stretch sm:gap-3">
                <div className="sm:min-w-[104px] rounded-xl border border-white/10 bg-white/[0.07] px-2 py-2.5 sm:px-4 sm:py-3 text-center backdrop-blur-sm">
                  <div className="font-display text-xl font-bold tabular-nums sm:text-2xl">{format(currentTime, 'HH:mm')}</div>
                  <div className="text-[10px] uppercase tracking-wider text-white/45">დრო</div>
                </div>
                <div className="sm:min-w-[104px] rounded-xl border border-white/10 bg-white/[0.07] px-2 py-2.5 sm:px-4 sm:py-3 text-center backdrop-blur-sm">
                  <div className="font-display text-xl font-bold tabular-nums sm:text-2xl">{leaveBalance.annual}</div>
                  <div className="text-[10px] uppercase tracking-wider text-white/45">შვებულება</div>
                </div>
                <div className="sm:min-w-[104px] rounded-xl border border-white/10 bg-white/[0.07] px-2 py-2.5 sm:px-4 sm:py-3 text-center backdrop-blur-sm">
                  <div className="font-display text-xl font-bold tabular-nums sm:text-2xl">{activeTasks.length}</div>
                  <div className="text-[10px] uppercase tracking-wider text-white/45">დავალება</div>
                </div>
              </div>
            </div>
          </div>

          {/* Attendance toggle - prominent second row */}
          {!isEmpOnly && (
          <Card className="group relative overflow-hidden border-white/10 portal-hero shadow-xl">
            <CardContent className="p-4 sm:p-5">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="rounded-xl bg-white/10 p-2.5 shrink-0">
                    <Clock className="h-6 w-6" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs uppercase tracking-wider text-white/50">დასწრება</p>
                    <p className={`font-display text-lg font-semibold ${isCheckedIn ? 'text-emerald-300' : 'text-white'}`}>
                      {isCheckedIn ? 'სამსახურში ხართ' : 'არ ხართ დაფიქსირებული'}
                    </p>
                    {todayAttendance?.check_in && (
                      <p className="text-xs text-white/60">
                        შესვლა: {todayAttendance.check_in}{todayAttendance?.check_out ? ` · გასვლა: ${todayAttendance.check_out}` : ''}
                      </p>
                    )}
                  </div>
                </div>
                <Button
                  onClick={handleCheckInOut}
                  size="lg"
                  className={`w-full sm:w-auto font-semibold ${isCheckedIn ? 'bg-white/15 text-white hover:bg-white/25' : 'bg-white text-primary hover:bg-white/90'}`}
                >
                  {isCheckedIn ? 'სამუშაოს დასრულება' : 'სამუშაოს დაწყება'}
                </Button>
              </div>
            </CardContent>
          </Card>
          )}

          {/* HR Command Center - exception-first view for admins/HR */}
          <HRCommandCenter />

          {/* Full Width - Announcements Section */}
          {/* Employee quick-nav buttons: news / tasks / notifications / surveys */}
          {isEmpOnly && (
            <div className="order-[-2] w-full flex gap-3 overflow-x-auto pb-1 [&::-webkit-scrollbar]:hidden [scrollbar-width:none]">
              {[
                { key: 'news', icon: FileText, label: 'სიახლეები', count: announcements.length, to: '/announcements' },
                { key: 'tasks', icon: ListTodo, label: 'დავალებები', count: activeTasks.length, to: '/tasks' },
                { key: 'notifications', icon: Bell, label: 'შეტყობინებები', count: 0, to: '/notifications' },
                { key: 'surveys', icon: Send, label: 'კვლევები', count: 0, to: '/pulse-surveys' },
              ].map((s) => (
                <button
                  key={s.key}
                  onClick={() => navigate(s.to)}
                  className="flex shrink-0 items-center gap-2.5 rounded-2xl border-2 border-primary/30 bg-card/95 px-4 py-3.5 shadow-md ring-1 ring-inset ring-white/5 transition-all hover:-translate-y-0.5 hover:border-primary hover:shadow-xl active:translate-y-0"
                >
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/40">
                    <s.icon className="h-5 w-5" />
                  </span>
                  <span className="whitespace-nowrap font-display text-sm font-semibold tracking-tight">{s.label}</span>
                  <span
                    className={`rounded-full px-2.5 py-1 text-xs font-bold tabular-nums ${
                      s.count > 0
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {s.count}
                  </span>
                </button>
              ))}
            </div>
          )}
          {!isEmpOnly && newsCard}

          {/* Statistics Row - შვებულებების ბალანსი */}
          <div className={isEmpOnly ? "w-full order-[-4]" : "w-full"}>
          <Card className="group relative overflow-hidden border-border/60 bg-card shadow-sm hover:shadow-md transition-all">
            <CardContent className="p-3 sm:p-4 md:p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <Umbrella className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                  <h3 className="font-display text-base sm:text-lg font-semibold">შვებულებების ბალანსი</h3>
                </div>

                <Button
                  onClick={() => navigate('/leave-requests')}
                  size="sm"
                  className="w-full sm:w-auto text-sm"
                >
                  შვებულების მოთხოვნა
                </Button>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3 md:gap-4">
                {/* Annual Leave */}
                <div className="p-3 sm:p-4 rounded-lg border border-border/70 bg-card hover:border-primary/40 transition-colors">
                  <div className="flex items-center gap-2 mb-2 sm:mb-3">
                    <div className="p-1.5 sm:p-2 rounded-md bg-primary/10">
                      <Umbrella className="h-3 w-3 sm:h-4 sm:w-4 text-primary" />
                    </div>
                    <span className="text-xs sm:text-sm font-medium">ყოველწლიური</span>
                  </div>
                  <div className="font-display text-xl sm:text-2xl md:text-3xl font-bold text-foreground mb-1 sm:mb-2">{leaveBalance.annual}</div>
                  <Progress value={(leaveBalance.annual / 24) * 100} className="h-1 sm:h-1.5 mb-1" />
                  <div className="text-[10px] sm:text-xs text-muted-foreground">{leaveBalance.annual}/24 დღე</div>
                </div>

                {/* Sick Leave */}
                <div className="p-3 sm:p-4 rounded-lg border border-border/70 bg-card hover:border-primary/40 transition-colors">
                  <div className="flex items-center gap-2 mb-2 sm:mb-3">
                    <div className="p-1.5 sm:p-2 rounded-md bg-primary/10">
                      <Plus className="h-3 w-3 sm:h-4 sm:w-4 text-primary" />
                    </div>
                    <span className="text-xs sm:text-sm font-medium">სამედიცინო</span>
                  </div>
                  <div className="font-display text-xl sm:text-2xl md:text-3xl font-bold text-foreground mb-1 sm:mb-2">{leaveBalance.sick}</div>
                  <Progress value={(leaveBalance.sick / 15) * 100} className="h-1 sm:h-1.5 mb-1" />
                  <div className="text-[10px] sm:text-xs text-muted-foreground">{leaveBalance.sick}/15 დღე</div>
                </div>

                {/* Personal Leave */}
                <div className="p-3 sm:p-4 rounded-lg border border-border/70 bg-card hover:border-primary/40 transition-colors">
                  <div className="flex items-center gap-2 mb-2 sm:mb-3">
                    <div className="p-1.5 sm:p-2 rounded-md bg-primary/10">
                      <User className="h-3 w-3 sm:h-4 sm:w-4 text-primary" />
                    </div>
                    <span className="text-xs sm:text-sm font-medium">პირადი</span>
                  </div>
                  <div className="font-display text-xl sm:text-2xl md:text-3xl font-bold text-foreground mb-1 sm:mb-2">{leaveBalance.personal}</div>
                  <Progress value={(leaveBalance.personal / 5) * 100} className="h-1 sm:h-1.5 mb-1" />
                  <div className="text-[10px] sm:text-xs text-muted-foreground">{leaveBalance.personal}/5 დღე</div>
                </div>

                {/* Unpaid Leave */}
                <div className="p-3 sm:p-4 rounded-lg border border-border/70 bg-card hover:border-primary/40 transition-colors">
                  <div className="flex items-center gap-2 mb-2 sm:mb-3">
                    <div className="p-1.5 sm:p-2 rounded-md bg-primary/10">
                      <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-primary" />
                    </div>
                    <span className="text-xs sm:text-sm font-medium">უხელფასო</span>
                  </div>
                  <div className="font-display text-xl sm:text-2xl md:text-3xl font-bold text-foreground mb-1 sm:mb-2">{leaveBalance.unpaid}</div>
                  <Progress value={(leaveBalance.unpaid / 30) * 100} className="h-1 sm:h-1.5 mb-1" />
                  <div className="text-[10px] sm:text-xs text-muted-foreground">{leaveBalance.unpaid}/30 დღე</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main 3-column layout */}
        <div className={isEmpOnly ? "contents" : "grid gap-6 lg:grid-cols-3"}>
          {/* Left Column - პირადი ინფო და საათი */}
          <div className={isEmpOnly ? "contents" : "space-y-6"}>
            {/* Clock and Check-in */}
            {!isEmpOnly && (
            <Card className="group relative overflow-hidden border-white/10 portal-hero shadow-xl">
              <CardContent className="p-4 sm:p-6 space-y-3 sm:space-y-4">
                <div className="flex items-center gap-2 sm:gap-3">
                  <Clock className="h-6 w-6 sm:h-8 sm:w-8" />
                  <div>
                    <div className="text-xs sm:text-sm opacity-90">
                      {format(currentTime, 'EEEE, dd MMMM yyyy წ', { locale: ka })}
                    </div>
                    <div className="text-3xl font-bold">
                      {format(currentTime, 'HH:mm:ss')}
                    </div>
                  </div>
                </div>

                {todayAttendance && (
                  <div className="text-sm space-y-1 bg-white/10 rounded-lg p-3">
                    {todayAttendance.check_in && (
                      <div>შესვლა: {todayAttendance.check_in}</div>
                    )}
                    {todayAttendance.check_out && (
                      <div>გასვლა: {todayAttendance.check_out}</div>
                    )}
                  </div>
                )}

              </CardContent>
            </Card>
            )}

            {/* Employee Info */}
            <Card className={`${isEmpOnly ? "order-[-6] " : ""}group relative overflow-hidden border-border/50 bg-card/95`}>
              <CardContent className="p-6 space-y-4">
                {/* name/avatar block removed – hero card above already shows it */}
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mail className="h-4 w-4" />
                    <span>{employee?.email}</span>
                  </div>
                  {employee?.phone && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-4 w-4" />
                      <span>{employee?.phone}</span>
                    </div>
                  )}
                </div>

                {!isEmpOnly && (
                  <Button
                    onClick={() => navigate('/employee-profile')}
                    variant="outline"
                    className="w-full"
                  >
                    <User className="h-4 w-4 mr-2" />
                    პროფილის რედაქტირება
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Active Tasks - მოთავსებულია პროფილის ქვემოთ */}
            {!isEmpOnly && tasksCard}

          </div>

          {/* Middle Column */}
          <div className={isEmpOnly ? "contents" : "space-y-6"}>
            {/* Quick Actions (hidden for employees) */}
            <Card className={`group relative overflow-hidden border-border/50 bg-card/95 ${isEmpOnly ? "hidden" : ""}`}>

              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Plus className="h-5 w-5 text-primary" />
                  <h3 className="font-display text-lg font-semibold">სწრაფი მოქმედებები</h3>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <Button 
                    onClick={() => navigate('/leave-requests')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                    variant="outline"
                  >
                    <Umbrella className="h-6 w-6" />
                    <span className="text-xs">შვებულება</span>
                  </Button>

                  <Button 
                    onClick={() => navigate('/business-trip-requests')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                    variant="outline"
                  >
                    <Plane className="h-6 w-6" />
                    <span className="text-xs">მივლინება</span>
                  </Button>

                  <Button 
                    onClick={() => navigate('/vehicle-requests')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                    variant="outline"
                  >
                    <Car className="h-6 w-6" />
                    <span className="text-xs">ავტომობილი</span>
                  </Button>

                  <Button 
                    onClick={() => navigate('/tasks')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                    variant="outline"
                  >
                    <ListTodo className="h-6 w-6" />
                    <span className="text-xs">დავალებები</span>
                  </Button>

                  <Button 
                    onClick={() => navigate('/calendar')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                    variant="outline"
                  >
                    <Calendar className="h-6 w-6" />
                    <span className="text-xs">გრაფიკი/ცვლები</span>
                  </Button>

                  <Button 
                    onClick={() => navigate('/pulse-surveys')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                    variant="outline"
                  >
                    <Target className="h-6 w-6" />
                    <span className="text-xs">გამოკითხვები</span>
                  </Button>

                  <Button 
                    onClick={() => navigate('/employee-profile')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                    variant="outline"
                  >
                    <User className="h-6 w-6" />
                    <span className="text-xs">პირადი ინფორმაცია</span>
                  </Button>

                  <Button 
                    onClick={() => navigate('/documents')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                    variant="outline"
                  >
                    <FileSignature className="h-6 w-6" />
                    <span className="text-xs">დოკუმენტები</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Favorites Section (hidden for employees) */}
            <Card className={`group relative overflow-hidden border-border/50 bg-card/95 ${isEmpOnly ? "hidden" : ""}`}>

              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Star className="h-5 w-5 text-primary" />
                  <h3 className="font-display text-lg font-semibold">ფავორიტები</h3>
                </div>

                {favorites.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground text-sm">
                    <p>ფავორიტები არ გაქვთ</p>
                    <p className="text-xs mt-1">დაამატეთ ხშირად გამოყენებული გვერდები</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {favorites.map((fav) => (
                      <div
                        key={fav.id}
                        className="flex items-center gap-3 p-3 rounded-lg border border-border/50 bg-background/50 hover:bg-accent/10 transition-all group/fav"
                      >
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => navigate(fav.page_path)}
                          className="flex-1 justify-start gap-2 h-auto py-2"
                        >
                          <Briefcase className="h-4 w-4" />
                          <span className="text-sm">{fav.page_title}</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFromFavorites(fav.id)}
                          className="opacity-0 group-hover/fav:opacity-100 transition-opacity h-8 w-8 p-0"
                        >
                          <XCircle className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="mt-4 pt-4 border-t">
                  <div className="text-xs text-muted-foreground mb-2">სწრაფი დამატება:</div>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => addToFavorites('/employees', 'თანამშრომლები')}
                      className="text-xs"
                    >
                      თანამშრომლები
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => addToFavorites('/reports', 'ანგარიშები')}
                      className="text-xs"
                    >
                      ანგარიშები
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => addToFavorites('/payroll', 'ხელფასები')}
                      className="text-xs"
                    >
                      ხელფასები
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => addToFavorites('/attendance', 'დასწრება')}
                      className="text-xs"
                    >
                      დასწრება
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

          </div>

          {/* Middle Column - Calendar + Pending Requests */}
          <div className={isEmpOnly ? "contents" : "space-y-6"}>
            {/* Interactive Calendar (hidden for employees) */}
            <Card className={`group relative overflow-hidden border-border/50 bg-card/95 ${isEmpOnly ? "hidden" : ""}`}>

              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Calendar className="h-5 w-5 text-primary" />
                  <h3 className="font-display text-lg font-semibold">კალენდარი</h3>
                </div>

                <div className="overflow-x-auto">
                  <CalendarComponent
                    mode="single"
                    selected={selectedDate}
                    onSelect={handleDateClick}
                    locale={ka}
                    modifiers={modifiers}
                    modifiersClassNames={modifiersClassNames}
                    className="rounded-lg border mx-auto"
                  />
                </div>

                {selectedDate && getEventsForDate(selectedDate).length > 0 && (
                  <div className="mt-3 p-3 rounded-lg bg-muted/30 border border-border/50">
                    <div className="text-sm font-semibold mb-2">
                      {safeFormatDate(selectedDate, 'd MMMM yyyy', { locale: ka })}
                    </div>
                    <div className="space-y-1.5">
                      {getEventsForDate(selectedDate).map((event, idx) => (
                        <div 
                          key={idx}
                          className="flex items-center gap-2 text-xs p-1.5 rounded bg-background/60"
                        >
                          <div className={`w-2 h-2 rounded-full shrink-0 ${
                            event.type === 'leave' ? 'bg-blue-500' : 
                            event.type === 'business_trip' ? 'bg-purple-500' : 
                            'bg-green-500'
                          }`}></div>
                          <span className="truncate">{event.title}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Legend - Clean horizontal pills */}
                <div className="mt-3 pt-3 border-t border-border/30">
                  <div className="flex items-center justify-center gap-2 flex-wrap">
                    <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-blue-500/10 border border-blue-500/20">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                      <span className="text-[10px] font-medium text-blue-600 dark:text-blue-400">შვებულება</span>
                    </div>
                    <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-purple-500/10 border border-purple-500/20">
                      <div className="w-1.5 h-1.5 rounded-full bg-purple-500"></div>
                      <span className="text-[10px] font-medium text-purple-600 dark:text-purple-400">მივლინება</span>
                    </div>
                    <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-green-500/10 border border-green-500/20">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                      <span className="text-[10px] font-medium text-green-600 dark:text-green-400">ცვლა</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Pending Requests - გადატანილია კალენდრის ქვემოთ */}
            <Card className={`${isEmpOnly ? "order-[-5] " : ""}group relative overflow-hidden border-border/50 bg-card/95`}>
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Send className="h-5 w-5 text-primary" />
                  <h3 className="font-display text-lg font-semibold">დასადასტურებელი განაცხადები</h3>
                  {pendingRequests.length > 0 && (
                    <Badge variant="secondary" className="text-xs">
                      {pendingRequests.length}
                    </Badge>
                  )}
                </div>

                {pendingRequests.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <Send className="h-8 w-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">დასადასტურებელი განაცხადები არ გაქვთ</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {pendingRequests.slice(0, 4).map((request) => (
                      <div 
                        key={request.id}
                        className="flex items-start gap-3 p-3 rounded-lg border border-border/50 bg-muted/10 hover:bg-muted/20 transition-all"
                      >
                        <div className="p-2 rounded-lg bg-primary/10">
                          {getRequestIcon(request.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm">{request.title}</div>
                          <div className="text-xs text-muted-foreground">{request.dates}</div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {getStatusIcon(request.status)}
                          <span className="text-xs font-medium">{getStatusText(request.status)}</span>
                        </div>
                      </div>
                    ))}
                   </div>
                 )}

                 {/* Signify Signing Requests inside pending section */}
                 {signifyRequests.length > 0 && (
                   <div className="mt-4 pt-4 border-t border-border/30">
                     <div className="flex items-center gap-2 mb-3">
                       <FileSignature className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                       <span className="text-sm font-semibold">Signify ხელმოწერები</span>
                       <Badge variant="outline" className="text-xs border-amber-300 text-amber-700 dark:border-amber-700 dark:text-amber-400">
                         {signifyRequests.length}
                       </Badge>
                     </div>
                     <div className="space-y-3">
                       {signifyRequests.map((req: any) => (
                         <div
                           key={req.id}
                           className="flex items-start gap-3 p-3 rounded-lg border border-amber-200/50 bg-amber-50/30 dark:border-amber-900/30 dark:bg-amber-950/10 hover:bg-amber-50/50 dark:hover:bg-amber-950/20 transition-all"
                         >
                           <div className="p-2 rounded-lg bg-amber-500/10">
                             <FileSignature className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                           </div>
                           <div className="flex-1 min-w-0">
                             <div className="font-medium text-sm">{req.document_name || 'დოკუმენტი'}</div>
                             <div className="text-xs text-muted-foreground">
                               {req.created_at && formatters.shortDateTime(req.created_at)}
                             </div>
                           </div>
                           <Button
                             size="sm"
                             variant="outline"
                             className="shrink-0 border-amber-300 text-amber-700 hover:bg-amber-100 dark:border-amber-700 dark:text-amber-400 dark:hover:bg-amber-950/30"
                             onClick={() => handleOpenSignifyLink(req)}
                           >
                             <FileSignature className="mr-1 h-3 w-3" />
                             ხელმოწერა
                           </Button>
                         </div>
                       ))}
                     </div>
                   </div>
                 )}
               </CardContent>
             </Card>

          </div>

        </div>



        {/* Full Width - Surveys Section */}
        {!isEmpOnly && surveysCard}

        {/* Pending Document Signatures */}
            {pendingSignatures.length > 0 && (
              <Card className={`${isEmpOnly ? "order-[-3] " : ""}group relative overflow-hidden border-border/50 bg-card/95`}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <FileSignature className="h-5 w-5 text-primary" />
                      <h3 className="font-display text-lg font-semibold">ხელმოსაწერი დოკუმენტები</h3>
                    </div>
                    {signedDocuments.length > 0 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowSignedHistory(!showSignedHistory)}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        {showSignedHistory ? 'დამალვა' : 'ისტორია'}
                      </Button>
                    )}
                  </div>

                  <div className="space-y-4">
                    {pendingSignatures.filter(signature => {
                      const doc = signature.documents;
                      if (!doc) return false;

                      // Search filter
                      const matchesSearch = documentSearchQuery === "" || 
                        doc.title?.toLowerCase().includes(documentSearchQuery.toLowerCase());

                      // Category filter
                      const matchesCategory = documentCategoryFilter === "all" || 
                        doc.category === documentCategoryFilter;

                      // Date filter
                      let matchesDate = true;
                      if (documentDateFrom || documentDateTo) {
                        const docDate = new Date(doc.created_at);
                        if (documentDateFrom && docDate < documentDateFrom) matchesDate = false;
                        if (documentDateTo && docDate > documentDateTo) matchesDate = false;
                      }

                      return matchesSearch && matchesCategory && matchesDate;
                    }).map((signature) => (
                      <div 
                        key={signature.id}
                        className="p-4 rounded-lg border border-border/50 hover:bg-muted/30 transition-colors space-y-3"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <div className="font-medium">{signature.documents?.title}</div>
                            {signature.documents?.category && (
                              <Badge variant="outline" className="mt-1">
                                {signature.documents.category}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {signature.documents?.created_at && 
                            formatters.longDate(signature.documents.created_at)}
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="flex-1"
                            onClick={() => handleDownloadDocument(
                              signature.documents?.file_path || '', 
                              signature.documents?.title || 'document',
                              signature.documents?.id
                            )}
                          >
                            <Download className="mr-1 h-3 w-3" />
                            ჩამოტვირთვა
                          </Button>
                          <Button
                            size="sm"
                            className="flex-1"
                            onClick={() => handleSignDocument(signature.id)}
                          >
                            <FileSignature className="mr-1 h-3 w-3" />
                            ხელმოწერა
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Signed Documents History */}
                  {showSignedHistory && signedDocuments.length > 0 && (
                    <div className="mt-6 pt-6 border-t border-border/50 space-y-4">
                      <h4 className="text-sm font-semibold flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        ხელმოწერილი დოკუმენტები
                      </h4>

                      {/* Filters for signed documents */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            placeholder="ძიება..."
                            value={documentSearchQuery}
                            onChange={(e) => setDocumentSearchQuery(e.target.value)}
                            className="pl-9 h-9"
                          />
                        </div>

                        <Select value={documentCategoryFilter} onValueChange={setDocumentCategoryFilter}>
                          <SelectTrigger className="h-9">
                            <SelectValue placeholder="კატეგორია" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">ყველა</SelectItem>
                            <SelectItem value="contract">ხელშეკრულება</SelectItem>
                            <SelectItem value="order">ბრძანება</SelectItem>
                            <SelectItem value="certificate">სერტიფიკატი</SelectItem>
                            <SelectItem value="notification">შეტყობინება</SelectItem>
                            <SelectItem value="other">სხვა</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs text-muted-foreground">თარიღიდან</label>
                          <CalendarComponent
                            mode="single"
                            selected={documentDateFrom}
                            onSelect={setDocumentDateFrom}
                            locale={ka}
                            className="rounded-md border p-3"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs text-muted-foreground">თარიღამდე</label>
                          <CalendarComponent
                            mode="single"
                            selected={documentDateTo}
                            onSelect={setDocumentDateTo}
                            locale={ka}
                            className="rounded-md border p-3"
                          />
                        </div>
                      </div>

                      {(documentSearchQuery || documentCategoryFilter !== "all" || documentDateFrom || documentDateTo) && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setDocumentSearchQuery("");
                            setDocumentCategoryFilter("all");
                            setDocumentDateFrom(undefined);
                            setDocumentDateTo(undefined);
                          }}
                          className="w-full"
                        >
                          <Filter className="h-3 w-3 mr-2" />
                          ფილტრების გასუფთავება
                        </Button>
                      )}

                      <div className="space-y-3">
                        {signedDocuments.filter(signature => {
                          const doc = signature.documents;
                          if (!doc) return false;

                          // Search filter
                          const matchesSearch = documentSearchQuery === "" || 
                            doc.title?.toLowerCase().includes(documentSearchQuery.toLowerCase());

                          // Category filter
                          const matchesCategory = documentCategoryFilter === "all" || 
                            doc.category === documentCategoryFilter;

                          // Date filter
                          let matchesDate = true;
                          if (documentDateFrom || documentDateTo) {
                            const docDate = new Date(signature.signed_at);
                            if (documentDateFrom && docDate < documentDateFrom) matchesDate = false;
                            if (documentDateTo && docDate > documentDateTo) matchesDate = false;
                          }

                          return matchesSearch && matchesCategory && matchesDate;
                        }).map((signature) => (
                          <div 
                            key={signature.id}
                            className="p-3 rounded-lg bg-muted/30 space-y-2"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <div className="text-sm font-medium">{signature.documents?.title}</div>
                                {signature.documents?.category && (
                                  <Badge variant="secondary" className="mt-1 text-xs">
                                    {signature.documents.category}
                                  </Badge>
                                )}
                              </div>
                              <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                            </div>
                            <div className="flex items-center justify-between text-xs text-muted-foreground">
                              <span>
                                ხელმოწერილია: {signature.signed_at && 
                                  formatters.shortDateTime(signature.signed_at)}
                              </span>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-6 px-2"
                                onClick={() => handleDownloadDocument(
                                  signature.documents?.file_path || '', 
                                  signature.documents?.title || 'document',
                                  signature.documents?.id
                                )}
                              >
                                <Download className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        ))}
                        
                        {signedDocuments.filter(signature => {
                          const doc = signature.documents;
                          if (!doc) return false;
                          const matchesSearch = documentSearchQuery === "" || doc.title?.toLowerCase().includes(documentSearchQuery.toLowerCase());
                          const matchesCategory = documentCategoryFilter === "all" || doc.category === documentCategoryFilter;
                          let matchesDate = true;
                          if (documentDateFrom || documentDateTo) {
                            const docDate = new Date(signature.signed_at);
                            if (documentDateFrom && docDate < documentDateFrom) matchesDate = false;
                            if (documentDateTo && docDate > documentDateTo) matchesDate = false;
                          }
                          return matchesSearch && matchesCategory && matchesDate;
                        }).length === 0 && (
                          <div className="text-center py-4 text-sm text-muted-foreground">
                            დოკუმენტები არ მოიძებნა
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}


        {/* Monthly Attendance Confirmation - shown from day 3 of month for previous month */}
        {employee?.id && <MonthlyAttendanceConfirmation employeeId={employee.id} />}

        {/* Attendance History - Full Width */}
        {employee?.id && <AttendanceHistory employeeId={employee.id} />}

        {/* Profile editing – all the way at the bottom for employees */}
        {isEmpOnly && employee && (
          <Button
            onClick={() => navigate('/employee-profile')}
            variant="outline"
            className="w-full"
          >
            <User className="h-4 w-4 mr-2" />
            პროფილის რედაქტირება
          </Button>
        )}

        {/* Notifications Center - Full Width at Bottom */}
        {!isEmpOnly && notificationsCard}

        {/* Date Details Dialog */}
        <Dialog open={showDateDetailsDialog} onOpenChange={setShowDateDetailsDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                შვებულებაში მყოფი თანამშრომლები - {selectedDateDetails?.date && safeFormatDate(selectedDateDetails.date, 'd MMMM yyyy', { locale: ka })}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {selectedDateDetails?.employees.map((emp, idx) => (
                <Card key={idx} className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-semibold">{emp.name}</div>
                      {emp.department && (
                        <div className="text-sm text-muted-foreground mt-1">
                          {emp.department}
                        </div>
                      )}
                    </div>
                    <Badge variant="secondary">
                      {emp.leaveType === 'annual' ? 'ხელფასიანი' :
                       emp.leaveType === 'sick' ? 'სამედიცინო' :
                       emp.leaveType === 'personal' ? 'პირადი' :
                       emp.leaveType === 'unpaid' ? 'უხელფასო' : emp.leaveType}
                    </Badge>
                  </div>
                </Card>
              ))}
              {(!selectedDateDetails?.employees || selectedDateDetails.employees.length === 0) && (
                <div className="text-center py-8 text-muted-foreground">
                  თანამშრომლები არ მოიძებნა
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
        </div>
      </PageTransition>
  );
}
