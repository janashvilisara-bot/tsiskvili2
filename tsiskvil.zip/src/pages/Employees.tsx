import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { VALID_SCHEDULE_TYPES, getScheduleTypeLabel } from "@/lib/scheduleUtils";
import { Plus, Search, Edit, Trash2, Upload as UploadIcon, User, Users, Filter, Download, CheckSquare, Square, UserX, Mail, Phone, Briefcase, Copy, Eye, EyeOff, RefreshCw, CheckCircle, XCircle, Grid3x3, List, ArrowUpDown, ArrowUp, ArrowDown, Building2, Globe, FileText, Settings, Shield } from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { EmployeeListSkeleton } from "@/components/ui/skeleton-loader";
import { ResponsiveTable, MobileCard, MobileCardRow } from "@/components/ResponsiveTable";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useIsMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import { useBranch } from "@/contexts/BranchContext";
import { z } from "zod";
import { usePersistedState } from "@/hooks/usePersistedState";
import { exportToExcel } from "@/lib/exportToExcel";
import { EmployeeMigrationDialog } from "@/components/employees/EmployeeMigrationDialog";
import { validateEmployeeSchedules } from "@/lib/validateEmployeeSchedules";
import { compressImageToWebP } from "@/lib/imageCompression";
import { AddPositionDialog } from "@/components/org-structure/AddPositionDialog";

const employeeSchema = z.object({
  full_name: z.string().min(2, { message: "სახელი ძალიან მოკლეა" }),
  email: z.string().email({ message: "არასწორი ელ.ფოსტა" }),
  father_name: z.string().nullable().optional(),
  phone: z.string().nullable().optional()
    .refine((v) => !v || /^[+\d\s()-]{9,20}$/.test(v.trim()), { message: "მობილურის ნომერი არასწორია" }),
  position: z.string().min(2, { message: "პოზიცია ძალიან მოკლეა" }),
  department: z.string().nullable().optional(),
  salary: z.string().nullable().optional()
    .refine((v) => !v || (!isNaN(Number(v)) && Number(v) >= 0), { message: "ხელფასი უნდა იყოს დადებითი რიცხვი" }),
  status: z.enum(['active', 'inactive']),
  gender: z.enum(['male', 'female']).nullable().optional(),
  date_of_birth: z.string().nullable().optional()
    .refine((v) => !v || !isNaN(new Date(v).getTime()), { message: "დაბადების თარიღი არასწორია" }),
  hire_date: z.string().nullable().optional()
    .refine((v) => !v || !isNaN(new Date(v).getTime()), { message: "დაქირავების თარიღი არასწორია" }),
  termination_date: z.string().nullable().optional(),
  termination_reason: z.string().nullable().optional(),
  personal_id_number: z.string().nullable().optional()
    .refine((v) => !v || /^\d{11}$/.test(v.trim()), { message: "პირადი ნომერი უნდა შედგებოდეს 11 ციფრისგან" }),
  bank_account: z.string().nullable().optional(),
  pension_account_number: z.string().nullable().optional(),
  has_pension: z.boolean().optional(),
  actual_address: z.string().nullable().optional(),
  legal_address: z.string().nullable().optional(),
  education: z.string().nullable().optional(),
  education_level: z.string().nullable().optional(),
  previous_experience: z.string().nullable().optional(),
  emergency_contact_name: z.string().nullable().optional(),
  emergency_contact_phone: z.string().nullable().optional(),
  emergency_contact_relation: z.string().nullable().optional(),
  bank_account_number: z.string().nullable().optional(),
  bank_name: z.string().nullable().optional(),
  tax_benefits: z.string().nullable().optional(),
  turnstile_card_number: z.string().nullable().optional(),
  attendance_method: z.enum(['mobile', 'turnstile']).optional(),
  residency_status: z.enum(['resident', 'non_resident']).optional(),
  foreign_country: z.string().nullable().optional(),
  lateness_control_enabled: z.boolean().optional(),
  receive_lateness_sms: z.boolean().optional(),
  receive_subordinate_lateness_sms: z.boolean().optional(),
  show_phone_on_list: z.boolean().optional(),
  show_email_on_list: z.boolean().optional(),
  is_pension_payer: z.boolean().optional(),
  employee_comment: z.string().nullable().optional(),
  is_minor: z.boolean().optional(),
  has_disability: z.boolean().optional(),
  is_intern: z.boolean().optional(),
  is_pregnant: z.boolean().optional(),
  secondary_manager_id: z.string().nullable().optional(),
});

interface Employee {
  id: string;
  full_name: string;
  email: string;
  father_name?: string | null;
  phone: string | null;
  position: string;
  department: string | null;
  salary: number | null;
  status: string;
  hire_date: string;
  avatar_url: string | null;
  gender: string | null;
  date_of_birth: string | null;
  termination_date: string | null;
  termination_reason: string | null;
  personal_id_number: string | null;
  bank_account: string | null;
  has_pension: boolean | null;
  work_schedule_id: string | null;
  user_id: string | null;
  education_level: string | null;
  actual_address: string | null;
  education: string | null;
  previous_experience: string | null;
  emergency_contact_name: string | null;
  emergency_contact_phone: string | null;
  emergency_contact_relation: string | null;
  bank_account_number: string | null;
  bank_name: string | null;
  tax_benefits: string | null;
  turnstile_card_number: string | null;
  attendance_method: string | null;
  residency_status: string | null;
  foreign_country: string | null;
  lateness_control_enabled: boolean | null;
  receive_lateness_sms: boolean | null;
  receive_subordinate_lateness_sms: boolean | null;
  show_phone_on_list: boolean | null;
  show_email_on_list: boolean | null;
  is_pension_payer: boolean | null;
  employee_comment: string | null;
  is_minor: boolean | null;
  has_disability: boolean | null;
  is_intern: boolean | null;
  is_pregnant: boolean | null;
  secondary_manager_id: string | null;
  is_probation: boolean | null;
  probation_months: number | null;
  is_dual_citizen: boolean | null;
  citizenship_countries: string[] | null;
  custom_start_time: string | null;
  custom_end_time: string | null;
  role?: string | null;
  created_at: string;
  updated_at: string;
}

type SystemRole = 'admin' | 'hr_manager' | 'department_manager' | 'employee';
const SYSTEM_ROLE_PRIORITY: SystemRole[] = ['admin', 'hr_manager', 'department_manager', 'employee'];
const normalizeSystemRole = (role?: string | null): SystemRole =>
  role === 'manager' ? 'department_manager' : SYSTEM_ROLE_PRIORITY.includes(role as SystemRole) ? (role as SystemRole) : 'employee';
const getPrimaryRoleForUser = (roles: any[] | undefined, userId?: string | null): SystemRole | null =>
  SYSTEM_ROLE_PRIORITY.find((role) => (roles || []).some((r: any) => r.user_id === userId && r.role === role)) || null;

const getScheduleCategoryLabel = (category?: string | null) => {
  switch (category) {
    case 'full':
      return 'სრული';
    case 'part_time':
      return 'არასრული';
    case 'shifts':
      return 'ცვლები';
    case 'flexible':
      return 'თავისუფალი';
    case 'remote':
      return 'დისტანციური';
    case 'hybrid':
      return 'ჰიბრიდული';
    default:
      return '';
  }
};

export default function Employees() {
  const navigate = useNavigate();
  const { user, userRole, registerEmployee } = useAuth();
  const activeBranchId = useBranchFilter();
  const { branches, canViewAll: canViewAllBranches, hasMultipleBranches } = useBranch();
  const [employees, setEmployees] = useState<Employee[]>([]);
  // Lite lookup list - id/name/position/department/secondary_manager_id only.
  // Always loaded (small payload) to power manager dropdowns and id→name lookups
  // even when the main list runs in server-paginated mode.
  const [lookupEmployees, setLookupEmployees] = useState<Array<{
    id: string; full_name: string; position: string; department: string | null; secondary_manager_id: string | null;
  }>>([]);
  const [serverMode, setServerMode] = useState(false);
  const [serverTotalCount, setServerTotalCount] = useState(0);
  const SERVER_PAGINATION_THRESHOLD = 100;
  const [departments, setDepartments] = useState<any[]>([]);
  const [positions, setPositions] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = usePersistedState<string>("employees:search", "");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [addPositionOpen, setAddPositionOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [uploadingImage, setUploadingImage] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [filterGender, setFilterGender] = usePersistedState<string>("employees:filterGender", "all");
  const [filterStatus, setFilterStatus] = usePersistedState<string>("employees:filterStatus", "all");
  const [filterPosition, setFilterPosition] = usePersistedState<string>("employees:filterPosition", "all");
  const [filterDepartment, setFilterDepartment] = usePersistedState<string>("employees:filterDepartment", "all");
  const [filterEducationLevel, setFilterEducationLevel] = usePersistedState<string>("employees:filterEducationLevel", "all");
  const [filterSalaryMin, setFilterSalaryMin] = usePersistedState<string>("employees:filterSalaryMin", "");
  const [filterSalaryMax, setFilterSalaryMax] = usePersistedState<string>("employees:filterSalaryMax", "");
  const [filterHireDate, setFilterHireDate] = usePersistedState<string>("employees:filterHireDate", "");
  const [filterTerminationDate, setFilterTerminationDate] = usePersistedState<string>("employees:filterTerminationDate", "");
  const [filterScheduleType, setFilterScheduleType] = usePersistedState<string>("employees:filterScheduleType", "all");
  const [filterIsMinor, setFilterIsMinor] = usePersistedState<string>("employees:filterIsMinor", "all");
  const [filterHasDisability, setFilterHasDisability] = usePersistedState<string>("employees:filterHasDisability", "all");
  const [filterPersonalId, setFilterPersonalId] = usePersistedState<string>("employees:filterPersonalId", "");
  const [showFilters, setShowFilters] = useState(false);
  const [formStatus, setFormStatus] = useState<string>("active");
  const [formUserRole, setFormUserRole] = useState<string>("employee");
  const [formGender, setFormGender] = useState<string>("none");
  const [formPosition, setFormPosition] = useState<string>("");
  const [formDepartment, setFormDepartment] = useState<string>("none");
  const [formBranchId, setFormBranchId] = useState<string>("none");
  const [formEducationLevel, setFormEducationLevel] = useState<string>("none");
  const [formScheduleCategory, setFormScheduleCategory] = useState<string>("none");
  const [formWorkSchedule, setFormWorkSchedule] = useState<string>("none");
  const [selectedEmployees, setSelectedEmployees] = useState<string[]>([]);
  const [scheduleTemplates, setScheduleTemplates] = useState<any[]>([]);
  const [defaultScheduleId, setDefaultScheduleId] = useState<string>('');
  const [generatedPassword, setGeneratedPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState(false);
  const [resetPasswordDialogOpen, setResetPasswordDialogOpen] = useState(false);
  const [resetPasswordData, setResetPasswordData] = useState<{ email: string; password: string } | null>(null);
  const [customPassword, setCustomPassword] = useState<string>('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [sortField, setSortField] = useState<'full_name' | 'position' | 'department' | 'hire_date' | 'salary'>('full_name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [formTurnstileCard, setFormTurnstileCard] = useState<string>('');
  const [formAttendanceMethod, setFormAttendanceMethod] = useState<string>('mobile');
  const [formResidencyStatus, setFormResidencyStatus] = useState<string>('resident');
  const [formForeignCountry, setFormForeignCountry] = useState<string>('');
  const [formLatenessControl, setFormLatenessControl] = useState<boolean>(false);
  const [formReceiveLateness, setFormReceiveLateness] = useState<boolean>(false);
  const [formReceiveSubLateness, setFormReceiveSubLateness] = useState<boolean>(false);
  const [formShowPhone, setFormShowPhone] = useState<boolean>(true);
  const [formShowEmail, setFormShowEmail] = useState<boolean>(true);
  const [formIsPensionPayer, setFormIsPensionPayer] = useState<boolean>(false);
  const [formComment, setFormComment] = useState<string>('');
  const [formIsMinor, setFormIsMinor] = useState<boolean>(false);
  const [formHasDisability, setFormHasDisability] = useState<boolean>(false);
  const [formIsIntern, setFormIsIntern] = useState<boolean>(false);
  const [formIsPregnant, setFormIsPregnant] = useState<boolean>(false);
  const [formSecondaryManagerId, setFormSecondaryManagerId] = useState<string>('');
  const [secondaryManagerSearch, setSecondaryManagerSearch] = useState<string>('');
  const [showSecondaryManagerDropdown, setShowSecondaryManagerDropdown] = useState<boolean>(false);
  const [benefitPlans, setBenefitPlans] = useState<any[]>([]);
  const [formBenefitPlans, setFormBenefitPlans] = useState<string[]>([]);
  const [formIsProbation, setFormIsProbation] = useState<boolean>(false);
  const [formProbationMonths, setFormProbationMonths] = useState<number>(3);
  const [formIsDualCitizen, setFormIsDualCitizen] = useState<boolean>(false);
  const [formCitizenshipCountries, setFormCitizenshipCountries] = useState<string[]>([]);
  const [formCustomStartTime, setFormCustomStartTime] = useState<string>('');
  const [formCustomEndTime, setFormCustomEndTime] = useState<string>('');

  const canManageEmployees = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    fetchEmployees();
    fetchDepartments();
    fetchPositions();
    fetchScheduleTemplates();
    fetchBenefitPlans();
  }, []);
  
  useEffect(() => {
    fetchEmployees();
    fetchDepartments();
    fetchPositions();
    fetchScheduleTemplates();
    fetchBenefitPlans();

    // Validate schedules on mount
    validateSchedulesOnLoad();
  }, []);

  // Refetch when the user switches active branch
  useEffect(() => {
    fetchEmployees();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeBranchId]);

  const validateSchedulesOnLoad = async () => {
    try {
      const result = await validateEmployeeSchedules();
      if (!result.valid && result.employeesWithoutSchedules.length > 0) {
        const employeeNames = result.employeesWithoutSchedules.map(e => e.full_name).join(', ');
        toast.warning(
          `გაფრთხილება: ${result.employeesWithoutSchedules.length} თანამშრომელს არ აქვს აქტიური სამუშაო გრაფიკი`,
          { 
            duration: 8000,
            description: `თანამშრომლები: ${employeeNames}`
          }
        );
      }
    } catch (error) {
      console.error('Schedule validation error:', error);
    }
  };
  // Ensure form fields populate once data lists are loaded
  useEffect(() => {
    if (!isDialogOpen) return;
    if (editingEmployee) {
      const mapGender = (g?: string | null) => {
        if (!g) return "none";
        if (["male", "მამრობითი"].includes(g)) return "male";
        if (["female", "მდედრობითი"].includes(g)) return "female";
        return "none";
      };
      setFormStatus(editingEmployee.status);
      setFormGender(mapGender(editingEmployee.gender));
      setFormUserRole(editingEmployee.role || "employee");
      // Find position by title and set its ID
      const position = positions.find(p => p.title === editingEmployee.position);
      setFormPosition(position?.id || "none");
      // Find department by name and set its ID
      const department = departments.find(d => d.name === editingEmployee.department);
      setFormDepartment(department?.id || "none");
      // Find schedule template and set category
      const scheduleTemplate = scheduleTemplates.find((t: any) => t.id === editingEmployee.work_schedule_id);
      setFormScheduleCategory(scheduleTemplate?.schedule_category || "none");
      setFormWorkSchedule(editingEmployee.work_schedule_id || defaultScheduleId || "");
      setFormTurnstileCard(editingEmployee.turnstile_card_number || '');
      setFormAttendanceMethod(editingEmployee.attendance_method || 'mobile');
      setFormResidencyStatus(editingEmployee.residency_status || 'resident');
      setFormForeignCountry(editingEmployee.foreign_country || '');
      setFormLatenessControl(editingEmployee.lateness_control_enabled || false);
      setFormReceiveLateness(editingEmployee.receive_lateness_sms || false);
      setFormReceiveSubLateness(editingEmployee.receive_subordinate_lateness_sms || false);
      setFormShowPhone(editingEmployee.show_phone_on_list !== null ? editingEmployee.show_phone_on_list : true);
      setFormShowEmail(editingEmployee.show_email_on_list !== null ? editingEmployee.show_email_on_list : true);
      setFormIsPensionPayer(editingEmployee.is_pension_payer || false);
      setFormComment(editingEmployee.employee_comment || '');
      setFormIsMinor(editingEmployee.is_minor || false);
      setFormHasDisability(editingEmployee.has_disability || false);
      setFormIsIntern(editingEmployee.is_intern || false);
      setFormIsPregnant(editingEmployee.is_pregnant || false);
      setFormSecondaryManagerId(editingEmployee.secondary_manager_id || '');
      setFormIsProbation(editingEmployee.is_probation || false);
      setFormProbationMonths(editingEmployee.probation_months || 3);
      setFormIsDualCitizen(editingEmployee.is_dual_citizen || false);
      setFormCitizenshipCountries(editingEmployee.citizenship_countries || []);
      setFormCustomStartTime(editingEmployee.custom_start_time || '');
      setFormCustomEndTime(editingEmployee.custom_end_time || '');
      setFormBranchId((editingEmployee as any).branch_id || "none");
      
      // Fetch employee's benefit enrollments
      if (editingEmployee.id) {
        fetchEmployeeBenefitEnrollments(editingEmployee.id);
      }
    } else {
      setFormScheduleCategory("none");
      if (!formWorkSchedule && defaultScheduleId) setFormWorkSchedule(defaultScheduleId);
      setFormTurnstileCard('');
      setFormAttendanceMethod('mobile');
      setFormResidencyStatus('resident');
      setFormForeignCountry('');
      setFormLatenessControl(false);
      setFormReceiveLateness(false);
      setFormReceiveSubLateness(false);
      setFormShowPhone(true);
      setFormShowEmail(true);
      setFormIsPensionPayer(false);
      setFormComment('');
      setFormIsMinor(false);
      setFormHasDisability(false);
      setFormIsIntern(false);
      setFormIsPregnant(false);
      setFormSecondaryManagerId('');
      setSecondaryManagerSearch('');
      setShowSecondaryManagerDropdown(false);
      setFormBenefitPlans([]);
      setFormIsProbation(false);
      setFormProbationMonths(3);
      setFormIsDualCitizen(false);
      setFormCitizenshipCountries([]);
      setFormCustomStartTime('');
      setFormCustomEndTime('');
      setFormBranchId(activeBranchId || "none");
    }
    // Only re-initialize when dialog opens or the edited employee changes - NOT when
    // background lists (positions/departments/scheduleTemplates) refresh, otherwise the
    // user's in-progress selections (e.g. schedule type/name) get wiped intermittently.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDialogOpen, editingEmployee?.id]);

  const fetchEmployeeBenefitEnrollments = async (employeeId: string) => {
    try {
      const { data, error } = await supabase
        .from('employee_benefit_enrollments')
        .select('benefit_plan_id')
        .eq('employee_id', employeeId)
        .eq('status', 'active');

      if (error) throw error;
      const benefitPlanIds = (data || []).map(enrollment => enrollment.benefit_plan_id);
      setFormBenefitPlans(benefitPlanIds);
    } catch (error: any) {
      console.error('სარგებლების ჩატვირთვა ვერ მოხერხდა', error);
    }
  };

  const fetchScheduleTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('schedule_templates')
        .select('*')
        .order('name');

    if (error) throw error;
    setScheduleTemplates(data || []);
    const def = (data || []).find((t: any) => t.is_default);
    if (def) setDefaultScheduleId(def.id);
    } catch (error: any) {
      console.error('სამუშაო გრაფიკების ჩატვირთვა ვერ მოხერხდა', error);
    }
  };

  // Optimization: only fetch columns needed for list view, filters, and dropdowns.
  // Heavy/rarely-used columns (addresses, comments, bank, emergency contacts, flags)
  // are loaded on demand via fetchFullEmployee() when editing/exporting.
  const EMPLOYEE_LIST_COLUMNS = [
    'id','user_id','full_name','last_name','email','phone','phone_number','avatar_url',
    'position','department','status','gender','hire_date','termination_date',
    'salary','salary_type','hourly_rate','personal_id_number','personal_id',
    'education_level','is_minor','has_disability','is_intern','is_probation','is_pregnant',
    'secondary_manager_id','work_schedule_id','employee_number','has_changed_password',
    'branch_id','deleted_at','created_at'
  ].join(',');

  const fetchFullEmployee = async (id: string): Promise<Employee | null> => {
    const { data, error } = await supabase
      .from('employees')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (error) {
      toast.error('თანამშრომლის სრული მონაცემების ჩატვირთვა ვერ მოხერხდა');
      return null;
    }
    return data as any;
  };

  // Apply current filter UI state to a Supabase query builder.
  // Used in server-paginated mode for both data and count queries.
  const applyServerFilters = (q: any) => {
    if (debouncedSearch.trim()) {
      const s = debouncedSearch.trim().replace(/[%_,]/g, ' ');
      q = q.or(`full_name.ilike.%${s}%,position.ilike.%${s}%,email.ilike.%${s}%`);
    }
    if (filterGender !== 'all') q = q.eq('gender', filterGender);
    if (filterStatus !== 'all') q = q.eq('status', filterStatus);
    if (filterPosition !== 'all') q = q.eq('position', filterPosition);
    if (filterDepartment !== 'all') q = q.eq('department', filterDepartment);
    if (filterEducationLevel !== 'all') q = q.eq('education_level', filterEducationLevel);
    if (filterSalaryMin) q = q.gte('salary', parseFloat(filterSalaryMin));
    if (filterSalaryMax) q = q.lte('salary', parseFloat(filterSalaryMax));
    if (filterHireDate) q = q.eq('hire_date', filterHireDate);
    if (filterTerminationDate) q = q.eq('termination_date', filterTerminationDate);
    if (filterScheduleType !== 'all') q = q.eq('work_schedule_id', filterScheduleType);
    if (filterIsMinor !== 'all') q = q.eq('is_minor', filterIsMinor === 'true');
    if (filterHasDisability !== 'all') q = q.eq('has_disability', filterHasDisability === 'true');
    if (filterPersonalId) q = q.ilike('personal_id_number', `%${filterPersonalId}%`);
    if (activeBranchId) q = q.eq('branch_id', activeBranchId);
    return q;
  };

  // Server-paginated fetch - only the current page is loaded.
  const fetchPage = async (rolesData?: any[]) => {
    try {
      setIsLoading(true);
      let roles = rolesData;
      if (!roles) {
        const { data: r } = await supabase.from('user_roles').select('user_id, role');
        roles = r || [];
      }
      const from = (currentPage - 1) * pageSize;
      const to = from + pageSize - 1;
      let q = supabase
        .from('employees')
        .select(EMPLOYEE_LIST_COLUMNS, { count: 'exact' })
        .order(sortField as string, { ascending: sortDirection === 'asc' })
        .range(from, to);
      q = applyServerFilters(q);
      const { data, count, error } = await q;
      if (error) throw error;
      const withRoles = (data || []).map((emp: any) => ({
        ...emp,
        role: getPrimaryRoleForUser(roles, emp.user_id),
      }));
      setEmployees(withRoles);
      setServerTotalCount(count || 0);
    } catch (error: any) {
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchEmployees = async () => {
    try {
      setIsLoading(true);

      // 1. Always fetch lite lookup list - small payload (~5 cols), powers manager
      //    dropdowns and id→name lookups in both client + server modes.
      const { data: lookupData } = await supabase
        .from('employees')
        .select('id, full_name, position, department, secondary_manager_id')
        .order('full_name');
      setLookupEmployees((lookupData || []) as any);

      // 2. Fetch user roles once
      const { data: rolesData, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role');
      if (rolesError) throw rolesError;

      // 3. Decide mode based on total count
      const total = (lookupData || []).length;
      const useServerMode = total >= SERVER_PAGINATION_THRESHOLD;
      setServerMode(useServerMode);

      if (!useServerMode) {
        // Client mode - load all lite columns, filter/paginate in memory
        let q = supabase
          .from('employees')
          .select(EMPLOYEE_LIST_COLUMNS)
          .order('created_at', { ascending: false });
        if (activeBranchId) q = q.eq('branch_id', activeBranchId);
        const { data: employeesData, error: employeesError } = await q;
        if (employeesError) throw employeesError;
        const employeesWithRoles = (employeesData || []).map((emp: any) => ({
          ...emp,
          role: getPrimaryRoleForUser(rolesData || [], emp.user_id),
        }));
        setEmployees(employeesWithRoles);
        setServerTotalCount(employeesWithRoles.length);
        setIsLoading(false);
      } else {
        // Server mode - load only current page
        await fetchPage(rolesData || []);
      }
    } catch (error: any) {
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
      setIsLoading(false);
    }
  };

  const fetchDepartments = async () => {
    try {
      const { data, error } = await supabase
        .from('departments')
        .select('id, name, parent_department_id')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setDepartments(data || []);
    } catch (error: any) {
      console.error('დეპარტამენტების ჩატვირთვა ვერ მოხერხდა', error);
    }
  };

  const fetchPositions = async () => {
    try {
      const { data, error } = await supabase
        .from('positions')
        .select('id, title, department_id, department:departments(name)')
        .eq('is_active', true)
        .order('title');

      if (error) throw error;
      setPositions(data || []);
    } catch (error: any) {
      console.error('პოზიციების ჩატვირთვა ვერ მოხერხდა', error);
    }
  };

  const fetchBenefitPlans = async () => {
    try {
      const { data, error } = await supabase
        .from('benefit_plans')
        .select('*')
        .eq('is_active', true)
        .order('plan_name');

      if (error) throw error;
      setBenefitPlans(data || []);
    } catch (error: any) {
      console.error('სარგებლების ჩატვირთვა ვერ მოხერხდა', error);
    }
  };

  const handleImageUpload = async (file: File, employeeId?: string): Promise<string | null> => {
    try {
      setUploadingImage(true);
      // Compress to WebP (max 512px) before upload - drastically cuts storage/egress
      const compressed = await compressImageToWebP(file, { maxDimension: 512 });
      const fileExt = compressed.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `avatars/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('documents')
        .upload(filePath, compressed, { contentType: compressed.type });

      if (uploadError) throw uploadError;

      const { data: signedData, error: signedError } = await supabase.storage
        .from('documents')
        .createSignedUrl(filePath, 60 * 60 * 24 * 365);
      if (signedError) throw signedError;

      return signedData.signedUrl;
    } catch (error: any) {
      toast.error('სურათის ატვირთვა ვერ მოხერხდა');
      return null;
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors({});
    setIsLoading(true);
    setGeneratedPassword('');
    const formData = new FormData(e.currentTarget);

    try {
      // Get position title from position ID
      const selectedPosition = positions.find(p => p.id === formPosition);
      const positionTitle = selectedPosition?.title || formData.get('position') || '';
      
      // Get department name from department ID or name
      let departmentValue = formDepartment;
      if (formDepartment && formDepartment !== 'none') {
        const selectedDept = departments.find(d => d.id === formDepartment);
        departmentValue = selectedDept?.name || formDepartment;
      }
      
      const selectedSystemRole = normalizeSystemRole(formUserRole);
      const data = employeeSchema.parse({
        full_name: formData.get('full_name'),
        email: formData.get('email'),
        father_name: formData.get('father_name'),
        phone: formData.get('phone'),
        position: positionTitle,
        department: departmentValue === 'none' ? undefined : departmentValue,
        salary: formData.get('salary'),
        status: formStatus,
        gender: formGender === 'none' ? undefined : formGender,
        date_of_birth: formData.get('date_of_birth'),
        hire_date: formData.get('hire_date'),
        termination_date: formData.get('termination_date'),
        termination_reason: formData.get('termination_reason'),
        personal_id_number: formData.get('personal_id_number'),
        bank_account: formData.get('bank_account'),
        pension_account_number: formData.get('pension_account_number'),
        has_pension: formData.get('has_pension') === 'on',
        actual_address: formData.get('actual_address'),
        legal_address: formData.get('legal_address'),
        education: formData.get('education'),
        previous_experience: formData.get('previous_experience'),
        emergency_contact_name: formData.get('emergency_contact_name'),
        emergency_contact_phone: formData.get('emergency_contact_phone'),
        emergency_contact_relation: formData.get('emergency_contact_relation'),
        bank_account_number: formData.get('bank_account_number'),
        bank_name: formData.get('bank_name'),
        tax_benefits: formData.get('tax_benefits'),
        turnstile_card_number: formTurnstileCard || null,
        attendance_method: formAttendanceMethod,
        residency_status: formResidencyStatus,
        foreign_country: formResidencyStatus === 'non_resident' ? formForeignCountry : null,
        lateness_control_enabled: formLatenessControl,
        receive_lateness_sms: formReceiveLateness,
        receive_subordinate_lateness_sms: formReceiveSubLateness,
        show_phone_on_list: formShowPhone,
        show_email_on_list: formShowEmail,
        is_pension_payer: formIsPensionPayer,
        employee_comment: formComment,
      });

      if (!user?.id) {
        toast.error('გთხოვთ, გაიაროთ ავტორიზაცია');
        setIsLoading(false);
        return;
      }

      // Calculate age-based pension exemption
      let isPensionPayerValue = data.is_pension_payer || false;
      
      if (data.date_of_birth && data.gender) {
        const birthDate = new Date(data.date_of_birth);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDiff = today.getMonth() - birthDate.getMonth();
        
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
          age--;
        }
        
        // Male over 65 or female over 60 are exempt from pension
        if ((data.gender === 'male' && age > 65) || (data.gender === 'female' && age > 60)) {
          isPensionPayerValue = false;
        }
      }

      const payload: any = {
        ...data,
        department: data.department === 'none' ? null : data.department,
        salary: data.salary ? parseFloat(data.salary) : null,
        gender: data.gender || null,
        date_of_birth: data.date_of_birth || null,
        hire_date: data.hire_date || null,
        termination_date: data.termination_date || null,
        termination_reason: data.termination_reason || null,
        personal_id_number: data.personal_id_number || null,
        bank_account: data.bank_account || null,
        has_pension: data.has_pension || false,
        actual_address: data.actual_address || null,
        education: data.education || null,
        education_level: formEducationLevel && formEducationLevel !== 'none' ? formEducationLevel : null,
        previous_experience: data.previous_experience || null,
        emergency_contact_name: data.emergency_contact_name || null,
        emergency_contact_phone: data.emergency_contact_phone || null,
        emergency_contact_relation: data.emergency_contact_relation || null,
        bank_account_number: data.bank_account_number || null,
        bank_name: data.bank_name || null,
        tax_benefits: data.tax_benefits || null,
        turnstile_card_number: data.turnstile_card_number || null,
        attendance_method: data.attendance_method || 'mobile',
        residency_status: data.residency_status || 'resident',
        foreign_country: data.foreign_country || null,
        lateness_control_enabled: data.lateness_control_enabled || false,
        receive_lateness_sms: data.receive_lateness_sms || false,
        receive_subordinate_lateness_sms: data.receive_subordinate_lateness_sms || false,
        show_phone_on_list: data.show_phone_on_list !== undefined ? data.show_phone_on_list : true,
        show_email_on_list: data.show_email_on_list !== undefined ? data.show_email_on_list : true,
        is_pension_payer: isPensionPayerValue,
        employee_comment: data.employee_comment || null,
        is_minor: formIsMinor,
        has_disability: formHasDisability,
        is_intern: formIsIntern,
        is_pregnant: formIsPregnant,
        secondary_manager_id: formSecondaryManagerId || null,
        is_probation: formIsProbation,
        probation_months: formIsProbation ? formProbationMonths : null,
        is_dual_citizen: formIsDualCitizen,
        citizenship_countries: formIsDualCitizen ? formCitizenshipCountries : null,
        custom_start_time: formCustomStartTime || null,
        custom_end_time: formCustomEndTime || null,
        created_by: user.id,
        work_schedule_id: formWorkSchedule && formWorkSchedule !== 'none' ? formWorkSchedule : null,
        branch_id: formBranchId && formBranchId !== 'none' ? formBranchId : null,
      };

      // Function to save benefit enrollments
      const saveBenefitEnrollments = async (employeeId: string) => {
        try {
          // Delete existing enrollments
          await supabase
            .from('employee_benefit_enrollments')
            .delete()
            .eq('employee_id', employeeId);

          // Insert new enrollments
          if (formBenefitPlans.length > 0) {
            const enrollments = formBenefitPlans.map(planId => ({
              employee_id: employeeId,
              benefit_plan_id: planId,
              enrollment_date: new Date().toISOString().split('T')[0],
              status: 'active',
            }));

            const { error: enrollError } = await supabase
              .from('employee_benefit_enrollments')
              .insert(enrollments);

            if (enrollError) throw enrollError;
          }
        } catch (error: any) {
          console.error('სარგებლების შენახვის შეცდომა:', error);
          toast.error('სარგებლების შენახვა ვერ მოხერხდა');
        }
      };

      // Upload image if selected
      if (selectedImage) {
        const avatarUrl = await handleImageUpload(selectedImage);
        if (avatarUrl) {
          payload.avatar_url = avatarUrl;
        }
      }

      if (editingEmployee) {
        const { error } = await supabase
          .from('employees')
          .update(payload)
          .eq('id', editingEmployee.id);

        if (error) throw error;

        // Update user role in user_roles table
        if (editingEmployee.user_id) {
          const { error: roleError } = await supabase.functions.invoke('manage-user-role', {
            body: {
              targetUserId: editingEmployee.user_id,
              role: selectedSystemRole,
            },
          });
          if (roleError) throw roleError;
        }
        
        // Update work_schedules when schedule template changes
        if (formWorkSchedule && formWorkSchedule !== 'none') {
          // Get schedule template info
          const { data: scheduleTemplate } = await supabase
            .from('schedule_templates')
            .select('schedule_type, name, start_time, end_time, break_duration')
            .eq('id', formWorkSchedule)
            .maybeSingle();
          
          if (scheduleTemplate) {
            // Check if employee already has a work_schedule
            const { data: existingSchedule } = await supabase
              .from('work_schedules')
              .select('id')
              .eq('employee_id', editingEmployee.id)
              .maybeSingle();
            
            if (existingSchedule) {
              // Update existing work_schedule - use custom times if provided, otherwise template times
              await supabase
                .from('work_schedules')
                .update({
                  template_id: formWorkSchedule,
                  schedule_type: formCustomStartTime && formCustomEndTime 
                    ? `${formCustomStartTime} - ${formCustomEndTime}` 
                    : (scheduleTemplate.schedule_type || scheduleTemplate.name),
                  start_time: formCustomStartTime || scheduleTemplate.start_time,
                  end_time: formCustomEndTime || scheduleTemplate.end_time,
                  break_duration: scheduleTemplate.break_duration || 0,
                })
                .eq('employee_id', editingEmployee.id);
            } else {
              // Insert new work_schedule - use custom times if provided, otherwise template times
              await supabase
                .from('work_schedules')
                .insert({
                  employee_id: editingEmployee.id,
                  template_id: formWorkSchedule,
                  schedule_type: formCustomStartTime && formCustomEndTime 
                    ? `${formCustomStartTime} - ${formCustomEndTime}` 
                    : (scheduleTemplate.schedule_type || scheduleTemplate.name),
                  start_time: formCustomStartTime || scheduleTemplate.start_time,
                  end_time: formCustomEndTime || scheduleTemplate.end_time,
                  break_duration: scheduleTemplate.break_duration || 0,
                  effective_from: new Date().toISOString().split('T')[0],
                  created_by: user?.id,
                });
            }
          }
        }
        
        // Save benefit enrollments
        await saveBenefitEnrollments(editingEmployee.id);
        
        toast.success('თანამშრომელი განახლდა');
      } else {
        // Use registerEmployee for new employees to create auth account
        const passwordToUse = customPassword?.trim() || undefined;
        const { password, error: regError } = await registerEmployee(
          data.email,
          data.full_name,
          'employee',
          data.department,
          positionTitle,
          data.phone || undefined,
          data.gender || undefined,
          formWorkSchedule && formWorkSchedule !== 'none' ? formWorkSchedule : undefined,
          passwordToUse,
          formEducationLevel && formEducationLevel !== 'none' ? formEducationLevel : undefined,
          data.personal_id_number || undefined
        );

        if (regError) {
          // registerEmployee already showed a clear message
          return;
        }

        // Update additional fields if provided (always update when branch is set explicitly)
        if (data.salary || data.date_of_birth || data.hire_date || data.personal_id_number || data.bank_account || data.actual_address || data.education || data.previous_experience || data.emergency_contact_name || data.emergency_contact_phone || data.emergency_contact_relation || data.bank_account_number || data.bank_name || data.tax_benefits || selectedImage || data.turnstile_card_number || data.employee_comment || (formBranchId && formBranchId !== 'none')) {
          const { data: newEmployee } = await supabase
            .from('employees')
            .select('id')
            .eq('email', data.email)
            .maybeSingle();

          if (newEmployee) {
            const updatePayload: any = {
              salary: data.salary ? parseFloat(data.salary) : null,
              date_of_birth: data.date_of_birth || null,
              hire_date: data.hire_date || null,
              personal_id_number: data.personal_id_number || null,
              bank_account: data.bank_account || null,
              has_pension: data.has_pension || false,
              actual_address: data.actual_address || null,
              education: data.education || null,
              education_level: formEducationLevel && formEducationLevel !== 'none' ? formEducationLevel : null,
              previous_experience: data.previous_experience || null,
              emergency_contact_name: data.emergency_contact_name || null,
              emergency_contact_phone: data.emergency_contact_phone || null,
              emergency_contact_relation: data.emergency_contact_relation || null,
              bank_account_number: data.bank_account_number || null,
              bank_name: data.bank_name || null,
              tax_benefits: data.tax_benefits || null,
              turnstile_card_number: data.turnstile_card_number || null,
              attendance_method: data.attendance_method || 'mobile',
              residency_status: data.residency_status || 'resident',
              foreign_country: data.foreign_country || null,
              lateness_control_enabled: data.lateness_control_enabled || false,
              receive_lateness_sms: data.receive_lateness_sms || false,
              receive_subordinate_lateness_sms: data.receive_subordinate_lateness_sms || false,
              show_phone_on_list: data.show_phone_on_list !== undefined ? data.show_phone_on_list : true,
              show_email_on_list: data.show_email_on_list !== undefined ? data.show_email_on_list : true,
              is_pension_payer: data.is_pension_payer || false,
              employee_comment: data.employee_comment || null,
              branch_id: formBranchId && formBranchId !== 'none' ? formBranchId : null,
            };

            // Upload image if selected
            if (selectedImage) {
              const avatarUrl = await handleImageUpload(selectedImage);
              if (avatarUrl) {
                updatePayload.avatar_url = avatarUrl;
              }
            }

            const { error: extraErr } = await supabase
              .from('employees')
              .update(updatePayload)
              .eq('id', newEmployee.id);
            if (extraErr) {
              console.error('Extra fields update error:', extraErr);
              toast.error('თანამშრომელი შეიქმნა, მაგრამ დამატებითი ველები ვერ შეინახა. გახსენით რედაქტირებით.');
            }
            
            // Save benefit enrollments for new employee
            await saveBenefitEnrollments(newEmployee.id);
          }
        }

        setGeneratedPassword(password);
        setShowPassword(true);
        toast.success('თანამშრომელი წარმატებით დარეგისტრირდა! SMS გაიგზავნა.');
        
        // Don't close dialog, show password instead
        fetchEmployees();
        
        // Navigate to work schedules page after successful registration
        setTimeout(() => {
          navigate('/work-schedules');
        }, 2000);
      }

      if (!generatedPassword) {
        setIsDialogOpen(false);
        setEditingEmployee(null);
        setSelectedImage(null);
      }
      fetchEmployees();
      if (!generatedPassword) {
        (e.target as HTMLFormElement).reset();
      }
    } catch (error: any) {
      console.error('Submit error:', error);
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
        setTimeout(() => {
          const first = Object.keys(fieldErrors)[0];
          const el = first && (document.getElementById(first) || document.querySelector(`[name="${first}"]`)) as HTMLElement | null;
          el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
          el?.focus?.();
        }, 0);
        toast.error('გთხოვთ შეავსეთ ყველა სავალდებულო ველი');
      } else {
        console.error('Database error:', error);
        toast.error(error.message || 'შეცდომა მოხდა: ' + JSON.stringify(error));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetPassword = async (employee: Employee) => {
    // Check if employee has user_id
    if (!employee.user_id) {
      toast.error('თანამშრომელს არ აქვს ავტორიზაციის ანგარიში. გთხოვთ, პირველ რიგში დაარეგისტრიროთ სისტემაში.');
      return;
    }

    if (!confirm(`დარწმუნებული ხართ რომ გსურთ პაროლის განახლება: ${employee.full_name}?`)) return;

    try {
      setIsLoading(true);
      
      // Use secure edge function for password reset (server-side admin validation)
      const { data: resetData, error: resetError } = await supabase.functions.invoke('admin-reset-password', {
        body: { email: employee.email }
      });

      if (resetError) {
        console.error('Password reset error:', resetError);
        throw new Error(resetError.message || 'პაროლის განახლება ვერ მოხერხდა');
      }

      if (!resetData?.success) {
        throw new Error(resetData?.error || 'პაროლის განახლება ვერ მოხერხდა');
      }

      const defaultPassword = resetData.newPassword;

      // Reset password changed flag
      const { error: dbError } = await supabase
        .from('employees')
        .update({
          has_changed_password: false
        })
        .eq('id', employee.id);

      if (dbError) {
        console.error('DB update error:', dbError);
        throw dbError;
      }

      const loginLink = `${window.location.origin}/auth`;
      let sentVia: string[] = [];

      // Send SMS if phone number exists
      if (employee.phone) {
        const message = `თქვენი პაროლი განახლდა.\n\nმომხმარებელი: ${employee.email}\nახალი პაროლი: ${defaultPassword}\n\nშესვლის ბმული: ${loginLink}`;
        
        try {
          await supabase.functions.invoke('send-cloudsms', {
            body: { to: employee.phone, message }
          });
          sentVia.push('SMS');
        } catch (smsError) {
          console.error('SMS sending error:', smsError);
        }
      }

      // Send Email via transactional email pipeline
      if (employee.email) {
        try {
          const { error: emailErr } = await supabase.functions.invoke('send-employee-password-email', {
            body: {
              employeeId: employee.id,
              password: defaultPassword,
              loginUrl: loginLink,
            }
          });
          if (emailErr) throw emailErr;
          sentVia.push('ელ. ფოსტა');
        } catch (emailError) {
          console.error('Email sending error:', emailError);
        }
      }

      // Show password dialog
      setResetPasswordData({
        email: employee.email,
        password: defaultPassword
      });
      setResetPasswordDialogOpen(true);

      const sentMessage = sentVia.length > 0 
        ? ` შეტყობინება გაიგზავნა: ${sentVia.join(' და ')}`
        : '';
      
      toast.success(`პაროლი წარმატებით განახლდა!${sentMessage}`);
      fetchEmployees();
    } catch (error: any) {
      console.error('Password reset error:', error);
      toast.error('პაროლის განახლება ვერ მოხერხდა: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Permanent delete runs in one database transaction: either everything is removed or nothing.
  const deleteEmployeesPermanently = async (ids: string[]): Promise<boolean> => {
    const { data, error } = await supabase.rpc('delete_employees_permanently', { p_ids: ids });
    if (error) {
      console.error('Employee delete error:', error);
      const msg = error.message?.includes('cannot_delete_self')
        ? 'საკუთარი ანგარიშის წაშლა შეუძლებელია'
        : error.code === '42501' || error.message?.includes('forbidden')
        ? 'წაშლის უფლება მხოლოდ ადმინს და HR-ს აქვს'
        : 'წაშლა ვერ მოხერხდა. მონაცემები არ შეცვლილა.';
      toast.error(msg);
      return false;
    }
    const authIds = ((data as { user_id: string }[] | null) || []).map((r) => r.user_id).filter(Boolean);
    if (authIds.length > 0) {
      const { error: authErr } = await supabase.functions.invoke('delete-auth-user', { body: { user_ids: authIds } });
      if (authErr) console.error('Auth user delete error:', authErr);
    }
    return true;
  };

  const DELETE_WARNING = 'სამუდამოდ წაიშლება თანამშრომელი და მისი ყველა ჩანაწერი: დასწრება, შვებულებები, ხელფასების ისტორია, კონტრაქტები. თუ მონაცემების შენახვა გინდათ, სჯობს სტატუსი „არააქტიური" გახადოთ.';

  const handleDelete = async (id: string) => {
    if (!confirm(`${DELETE_WARNING}\n\nგავაგრძელოთ?`)) return;
    if (await deleteEmployeesPermanently([id])) {
      toast.success('თანამშრომელი წაიშალა');
      fetchEmployees();
    }
  };

  const handleBulkDelete = async () => {
    if (selectedEmployees.length === 0) {
      toast.error('აირჩიეთ მინიმუმ ერთი თანამშრომელი');
      return;
    }
    if (!confirm(`${selectedEmployees.length} თანამშრომელი. ${DELETE_WARNING}\n\nგავაგრძელოთ?`)) return;
    if (await deleteEmployeesPermanently(selectedEmployees)) {
      toast.success(`${selectedEmployees.length} თანამშრომელი წაიშალა`);
      setSelectedEmployees([]);
      fetchEmployees();
    }
  };

  const toggleEmployeeSelection = (id: string) => {
    setSelectedEmployees(prev => 
      prev.includes(id) 
        ? prev.filter(empId => empId !== id)
        : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedEmployees.length === filteredEmployees.length) {
      setSelectedEmployees([]);
    } else {
      setSelectedEmployees(filteredEmployees.map(emp => emp.id));
    }
  };

  const handleBulkExport = async () => {
    if (selectedEmployees.length === 0) {
      toast.error('აირჩიეთ მინიმუმ ერთი თანამშრომელი');
      return;
    }

    // In server mode `employees` only holds the current page; fetch the
    // full records for selected IDs so bulk export captures everything.
    let selectedData: any[] = employees.filter(emp => selectedEmployees.includes(emp.id));
    if (serverMode && selectedData.length < selectedEmployees.length) {
      const { data } = await supabase
        .from('employees').select('*').in('id', selectedEmployees);
      selectedData = data || selectedData;
    }
    const exportData = selectedData.map(emp => ({
      'სახელი და გვარი': emp.full_name,
      'ელ. ფოსტა': emp.email,
      'ტელეფონი': emp.phone || '',
      'პირადი ნომერი': emp.personal_id_number || '',
      'პოზიცია': emp.position,
      'დეპარტამენტი': emp.department || '',
      'ხელფასი': emp.salary || 0,
      'მოსვლის თარიღი': emp.hire_date,
      'სქესი': emp.gender === 'male' ? 'მამრობითი' : emp.gender === 'female' ? 'მდედრობითი' : '',
      'დაბადების თარიღი': emp.date_of_birth || '',
      'სტატუსი': emp.status === 'active' ? 'აქტიური' : emp.status === 'terminated' ? 'დათხოვნილი' : 'შვებულებაში',
      'არასრულწლოვანი': emp.is_minor ? 'კი' : 'არა',
      'შშმპ': emp.has_disability ? 'კი' : 'არა',
      'სტაჟიორი': emp.is_intern ? 'კი' : 'არა',
      'ორსული': emp.is_pregnant ? 'კი' : 'არა',
      'მეორე ხელმძღვანელი': emp.secondary_manager_id ? lookupEmployees.find(m => m.id === emp.secondary_manager_id)?.full_name || '' : '',
    }));

    const success = exportToExcel(exportData, `არჩეული_თანამშრომლები_${new Date().toISOString().split('T')[0]}`, 'თანამშრომლები');
    if (success) {
      toast.success(`${selectedEmployees.length} თანამშრომლის ექსპორტი წარმატებით განხორციელდა`);
    } else {
      toast.error('ექსპორტის შეცდომა');
    }
  };

  const handleBulkStatusChange = async (newStatus: string) => {
    if (selectedEmployees.length === 0) {
      toast.error('აირჩიეთ მინიმუმ ერთი თანამშრომელი');
      return;
    }

    try {
      const { error } = await supabase
        .from('employees')
        .update({ status: newStatus })
        .in('id', selectedEmployees);

      if (error) throw error;
      
      toast.success(`${selectedEmployees.length} თანამშრომლის სტატუსი შეიცვალა`);
      setSelectedEmployees([]);
      fetchEmployees();
    } catch (error: any) {
      toast.error('სტატუსის შეცვლა ვერ მოხერხდა');
    }
  };

  const handleExportEmployees = async () => {
    try {
      // Fetch employee history for all employees
      const { data: historyData } = await supabase
        .from('employee_history')
        .select('*')
        .order('effective_date', { ascending: false });

      // Fetch work schedules (latest per employee)
      const { data: schedulesData, error: scheduleError } = await supabase
        .from('work_schedules')
        .select('employee_id, schedule_type, effective_from')
        .order('effective_from', { ascending: false });

      if (scheduleError) {
        console.error('Work schedules fetch error:', scheduleError);
      }

      // Fetch all schedule templates (day, night, custom etc.)
      const { data: templatesData, error: templateError } = await supabase
        .from('schedule_templates')
        .select('schedule_type, name');

      if (templateError) {
        console.error('Template fetch error:', templateError);
      }

      // Build map from schedule_type -> name (e.g. "სრული 09:00 - 17:00 (სრული 1)")
      const templateMap: Record<string, string> = {};
      (templatesData || []).forEach((t: any) => {
        if (t.schedule_type) {
          templateMap[t.schedule_type] = t.name || t.schedule_type;
        }
      });

  // Fetch full employee data on demand for export (list view uses lite columns)
      const { data: fullEmployees, error: fullErr } = await supabase
        .from('employees')
        .select('*')
        .order('created_at', { ascending: false });
      if (fullErr) throw fullErr;

      const exportData = (fullEmployees || []).map((emp: any) => {
        // Get history for this employee
        const empHistory = (historyData || []).filter((h: any) => h.employee_id === emp.id);
        
        // Get most recent schedule for this employee
        const empSchedule = (schedulesData || []).find((s: any) => s.employee_id === emp.id);
        let scheduleType = 'მითითებული არ არის';
        
        if (empSchedule?.schedule_type) {
          scheduleType = templateMap[empSchedule.schedule_type] || empSchedule.schedule_type || 'მითითებული არ არის';
        }
        
        return {
          'სახელი და გვარი': emp.full_name,
          'ელ. ფოსტა': emp.email,
          'ტელეფონი': emp.phone || '',
          'პირადი ნომერი': emp.personal_id_number || '',
          'დაბადების თარიღი': emp.date_of_birth || '',
          'სქესი': emp.gender === 'male' ? 'მამრობითი' : emp.gender === 'female' ? 'მდედრობითი' : '',
          'პოზიცია': emp.position,
          'დეპარტამენტი': emp.department || '',
          'ფაქტობრივი მისამართი': emp.actual_address || '',
          'განათლება': emp.education || '',
          'განათლების დონე': emp.education_level || '',
          'სამუშაო გამოცდილება': emp.previous_experience || '',
          'საგანგებო კონტაქტი': emp.emergency_contact_name || '',
          'საგანგებო ტელეფონი': emp.emergency_contact_phone || '',
          'ნათესაური კავშირი': emp.emergency_contact_relation || '',
          'ბანკის ანგარიში': emp.bank_account_number || '',
          'ბანკის სახელი': emp.bank_name || '',
          'საგადასახადო შეღავათები': emp.tax_benefits || '',
          'ხელფასი': emp.salary || 0,
          'დაქირავების თარიღი': emp.hire_date,
          'დათხოვნის თარიღი': emp.termination_date || '',
          'დათხოვნის მიზეზი': emp.termination_reason || '',
          'სტატუსი': emp.status === 'active' ? 'აქტიური' : emp.status === 'terminated' ? 'დათხოვნილი' : 'შვებულებაში',
          'გრაფიკის ტიპი': scheduleType,
          'არასრულწლოვანი': emp.is_minor ? 'კი' : 'არა',
          'შშმპ': emp.has_disability ? 'კი' : 'არა',
          'სტაჟიორი': emp.is_intern ? 'კი' : 'არა',
          'ორსული': emp.is_pregnant ? 'კი' : 'არა',
          'მეორე ხელმძღვანელი': emp.secondary_manager_id ? lookupEmployees.find(m => m.id === emp.secondary_manager_id)?.full_name || '' : '',
          'ისტორია': empHistory.map((h: any) => 
            `${h.change_type}: ${h.effective_date} - ${h.reason || ''}`
          ).join('; ') || 'ისტორია არ არის'
        };
      });

      const success = exportToExcel(exportData, `თანამშრომლები_სრული_${new Date().toISOString().split('T')[0]}`, 'თანამშრომლები');
      if (success) {
        toast.success('ექსპორტი წარმატებით განხორციელდა');
      } else {
        toast.error('ექსპორტის შეცდომა');
      }
    } catch (error) {
      console.error('Export error:', error);
      toast.error('ექსპორტის შეცდომა');
    }
  };

  const handleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // In server mode the `employees` array is already the filtered + sorted + paginated
  // page returned by the backend, so we skip client-side filtering entirely.
  const filteredEmployees = serverMode ? employees : employees.filter((employee) => {
    const matchesSearch = employee.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.position.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGender = filterGender === "all" || employee.gender === filterGender;
    const matchesStatus = filterStatus === "all" || employee.status === filterStatus;
    const matchesPosition = filterPosition === "all" || employee.position === filterPosition;
    const matchesDepartment = filterDepartment === "all" || employee.department === filterDepartment;
    const matchesEducationLevel = filterEducationLevel === "all" || employee.education_level === filterEducationLevel;
    
    const matchesSalaryMin = !filterSalaryMin || (employee.salary && employee.salary >= parseFloat(filterSalaryMin));
    const matchesSalaryMax = !filterSalaryMax || (employee.salary && employee.salary <= parseFloat(filterSalaryMax));
    
    const matchesHireDate = !filterHireDate || (employee.hire_date && employee.hire_date === filterHireDate);
    const matchesTerminationDate = !filterTerminationDate || (employee.termination_date && employee.termination_date === filterTerminationDate);
    
    // New filters
    const matchesScheduleType = filterScheduleType === "all" || employee.work_schedule_id === filterScheduleType;
    const matchesIsMinor = filterIsMinor === "all" || (filterIsMinor === "true" && employee.is_minor) || (filterIsMinor === "false" && !employee.is_minor);
    const matchesHasDisability = filterHasDisability === "all" || (filterHasDisability === "true" && employee.has_disability) || (filterHasDisability === "false" && !employee.has_disability);
    const matchesPersonalId = !filterPersonalId || (employee.personal_id_number && employee.personal_id_number.includes(filterPersonalId));
    
    return matchesSearch && matchesGender && matchesStatus && matchesPosition && matchesDepartment && matchesEducationLevel &&
           matchesSalaryMin && matchesSalaryMax && 
           matchesHireDate && matchesTerminationDate &&
           matchesScheduleType && matchesIsMinor && matchesHasDisability && matchesPersonalId;
  }).sort((a, b) => {
    let aValue: any = a[sortField];
    let bValue: any = b[sortField];
    
    // Handle null values
    if (aValue === null) return 1;
    if (bValue === null) return -1;
    
    // Convert to lowercase for string comparison
    if (typeof aValue === 'string') aValue = aValue.toLowerCase();
    if (typeof bValue === 'string') bValue = bValue.toLowerCase();
    
    if (sortDirection === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });

  // Pagination - slice the filtered list for rendering (client mode only).
  // In server mode, totalCount comes from the backend and `employees` is the page itself.
  const totalCount = serverMode ? serverTotalCount : filteredEmployees.length;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));
  const safePage = Math.min(currentPage, totalPages);
  const pagedEmployees = serverMode
    ? employees
    : filteredEmployees.slice((safePage - 1) * pageSize, safePage * pageSize);

  // Debounce search input → server queries (300ms)
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(searchQuery), 300);
    return () => clearTimeout(t);
  }, [searchQuery]);

  // Reset to page 1 when filters/search change
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearch, filterStatus, filterDepartment, filterGender, filterPosition,
      filterEducationLevel, filterSalaryMin, filterSalaryMax, filterHireDate,
      filterTerminationDate, filterScheduleType, filterIsMinor, filterHasDisability,
      filterPersonalId, pageSize]);

  // Server mode: refetch page when filters/page/sort change
  useEffect(() => {
    if (!serverMode) return;
    fetchPage();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [serverMode, currentPage, pageSize, sortField, sortDirection,
      debouncedSearch, filterStatus, filterDepartment, filterGender, filterPosition,
      filterEducationLevel, filterSalaryMin, filterSalaryMax, filterHireDate,
      filterTerminationDate, filterScheduleType, filterIsMinor, filterHasDisability,
      filterPersonalId]);

  const PaginationControls = () => (
    totalCount > pageSize ? (
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mt-6 px-2">
        <div className="text-sm text-muted-foreground">
          {((safePage - 1) * pageSize) + 1}–{Math.min(safePage * pageSize, totalCount)} / {totalCount}
        </div>
        <div className="flex items-center gap-2">
          <Select value={String(pageSize)} onValueChange={(v) => setPageSize(Number(v))}>
            <SelectTrigger className="h-8 w-[80px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="25">25</SelectItem>
              <SelectItem value="50">50</SelectItem>
              <SelectItem value="100">100</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={safePage <= 1}
          >
            წინა
          </Button>
          <span className="text-sm font-medium px-2">
            {safePage} / {totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={safePage >= totalPages}
          >
            შემდეგი
          </Button>
        </div>
      </div>
    ) : null
  );

  return (
    <PageTransition>
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 -mx-4 -my-6 md:-mx-8 md:-my-8 p-4 md:p-8">
      <div className="max-w-[1600px] mx-auto space-y-8 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-teal-400 flex items-center justify-center shadow-lg shadow-indigo-200/60 dark:shadow-none animate-scale-in">
            <Users className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white tracking-tight">
              თანამშრომლები
            </h1>
            <p className="mt-1 text-sm md:text-base text-slate-500 dark:text-slate-400 font-medium">მართეთ თქვენი გუნდის წევრები</p>
          </div>
        </div>
        {canManageEmployees && (

          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) {
              setEditingEmployee(null);
              setErrors({});
              setSelectedImage(null);
              setFormStatus("active");
              setFormUserRole("employee");
              setFormGender("none");
              setFormPosition("");
              setFormDepartment("none");
              setFormWorkSchedule(defaultScheduleId || "");
              setFormBenefitPlans([]);
            } else if (editingEmployee) {
              // Initialize values from existing employee
              const mapGender = (g?: string | null) => {
                if (!g) return "none";
                if (["male", "მამრობითი"].includes(g)) return "male";
                if (["female", "მდედრობითი"].includes(g)) return "female";
                return "none";
              };
              setFormStatus(editingEmployee.status);
              setFormGender(mapGender(editingEmployee.gender));
              setFormUserRole(editingEmployee.role || "employee");
              const position = positions.find(p => p.title === editingEmployee.position);
              setFormPosition(position?.id || "");
              setFormDepartment(editingEmployee.department || "none");
              setFormWorkSchedule(editingEmployee.work_schedule_id || defaultScheduleId || "");
            } else {
              // New employee defaults
              setFormStatus("active");
              setFormGender("none");
              setFormPosition("");
              setFormDepartment("none");
              setFormWorkSchedule(defaultScheduleId || "");
            }
          }}>
            <DialogTrigger asChild>
              <Button className="gap-2 px-6 py-3.5 h-auto bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-semibold shadow-lg shadow-indigo-200/60 dark:shadow-none active:scale-95 transition-all">
                <Plus className="h-5 w-5" />
                ახალი თანამშრომელი
              </Button>
            </DialogTrigger>
            <DialogContent className="w-[calc(100vw-1rem)] sm:w-full max-w-6xl max-h-[90dvh] overflow-y-auto overflow-x-hidden p-4 sm:p-6 bg-gradient-to-br from-background/95 via-background to-background/95 backdrop-blur-xl border-2 border-primary/20 shadow-2xl">
              <DialogHeader className="pb-6 border-b border-primary/20">
                <DialogTitle className="text-lg sm:text-2xl font-bold break-words bg-gradient-to-r from-teal-600 via-teal-500 to-teal-600 dark:from-teal-400 dark:via-teal-300 dark:to-teal-400 bg-clip-text text-transparent">
                  {editingEmployee ? 'თანამშრომლის რედაქტირება' : 'თანამშრომლის დამატება'}
                </DialogTitle>
                <p className="text-sm text-muted-foreground mt-2">შეავსეთ თანამშრომლის ინფორმაცია ყველა აუცილებელ ველში</p>
              </DialogHeader>
              
              {generatedPassword && !editingEmployee ? (
                <div className="space-y-4 p-4 border border-primary rounded-lg bg-primary/5">
                  <div className="text-center">
                    <h3 className="text-lg font-semibold text-primary mb-2">თანამშრომელი წარმატებით დარეგისტრირდა!</h3>
                    <p className="text-sm text-muted-foreground mb-4">SMS შეტყობინება გაიგზავნა მითითებულ ნომერზე</p>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-background rounded-md">
                      <div>
                        <Label className="text-xs text-muted-foreground">მომხმარებელი</Label>
                        <p className="font-mono text-sm">{employees[0]?.email}</p>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          navigator.clipboard.writeText(employees[0]?.email || '');
                          toast.success('დაკოპირდა!');
                        }}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-background rounded-md">
                      <div className="flex-1">
                        <Label className="text-xs text-muted-foreground">პაროლი</Label>
                        <p className="font-mono text-sm">
                          {showPassword ? generatedPassword : '••••••••••'}
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            navigator.clipboard.writeText(generatedPassword);
                            toast.success('პაროლი დაკოპირდა!');
                          }}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-background rounded-md">
                      <div>
                        <Label className="text-xs text-muted-foreground">შესვლის ბმული</Label>
                        <p className="font-mono text-xs break-all">{window.location.origin}/auth</p>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          navigator.clipboard.writeText(`${window.location.origin}/auth`);
                          toast.success('ბმული დაკოპირდა!');
                        }}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <Button
                    className="w-full"
                    onClick={() => {
                      setIsDialogOpen(false);
                      setGeneratedPassword('');
                      setShowPassword(false);
                      setEditingEmployee(null);
                      setSelectedImage(null);
                    }}
                  >
                    დახურვა
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="space-y-8 pt-6">
                  {/* Avatar Upload Section */}
                  <div className="flex flex-col items-center gap-4 pb-8">
                    <div className="relative group">
                      <div className="absolute inset-0 bg-gradient-to-r from-teal-500 to-teal-600 rounded-full blur-xl opacity-50 group-hover:opacity-75 transition-opacity"></div>
                      <Avatar className="relative h-36 w-36 border-4 border-teal-500/30 dark:border-teal-400/30 shadow-2xl ring-4 ring-teal-500/10">
                        <AvatarImage 
                          src={selectedImage ? URL.createObjectURL(selectedImage) : editingEmployee?.avatar_url || ''} 
                          className="object-cover"
                        />
                        <AvatarFallback className="bg-gradient-to-br from-teal-50 to-teal-100 dark:from-teal-900/50 dark:to-teal-800/50">
                          <User className="h-20 w-20 text-teal-600 dark:text-teal-400" />
                        </AvatarFallback>
                      </Avatar>
                      <Label htmlFor="avatar" className="absolute bottom-2 right-2 cursor-pointer">
                        <div className="p-3 rounded-full bg-gradient-to-br from-teal-600 to-teal-700 text-white hover:from-teal-700 hover:to-teal-800 transition-all shadow-lg hover:shadow-xl hover:scale-110 transform">
                          <UploadIcon className="h-5 w-5" />
                        </div>
                        <Input
                          id="avatar"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              setSelectedImage(file);
                            }
                          }}
                        />
                      </Label>
                    </div>
                    <div className="text-center">
                      <p className="text-sm font-medium text-foreground mb-1">სურათის ატვირთვა</p>
                      {selectedImage && (
                        <p className="text-xs text-teal-600 dark:text-teal-400 font-medium mb-1">{selectedImage.name}</p>
                      )}
                      <p className="text-xs text-muted-foreground">მაქს. 5MB • JPG, PNG, GIF</p>
                    </div>
                  </div>

                  {/* Personal Information Section */}
                  <div className="space-y-6 p-6 rounded-2xl bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm border border-primary/10 shadow-lg">
                    <div className="flex items-center gap-3 pb-3 border-b border-primary/10">
                      <div className="p-2 rounded-lg bg-gradient-to-br from-teal-600/20 to-teal-500/20">
                        <User className="h-5 w-5 text-teal-600 dark:text-teal-400" />
                      </div>
                      <h3 className="text-lg font-bold text-foreground">თანამშრომლის პირადი ინფორმაცია</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="full_name" className="text-sm font-semibold text-foreground flex items-center gap-2">
                          სახელი 
                          <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="full_name"
                          name="full_name"
                          defaultValue={editingEmployee?.full_name}
                          placeholder="გივი გივიშვილი"
                          required
                          className="h-11 border-2 border-input hover:border-primary/50 focus:border-primary transition-colors bg-background/50"
                        />
                        {errors.full_name && <p className="mt-1 text-sm text-destructive">{errors.full_name}</p>}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-sm font-semibold text-foreground flex items-center gap-2">
                          ელ. ფოსტა
                          <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          defaultValue={editingEmployee?.email}
                          placeholder="მაგალითად: givi@company.ge"
                          required
                          className="h-11 border-2 border-input hover:border-primary/50 focus:border-primary transition-colors bg-background/50"
                        />
                        {errors.email && <p className="mt-1 text-sm text-destructive">{errors.email}</p>}
                      </div>
                      <div>
                        <Label htmlFor="father_name" className="text-sm">მამის სახელი</Label>
                        <Input
                          id="father_name"
                          name="father_name"
                          defaultValue={editingEmployee?.father_name || ''}
                          placeholder="მამის სახელი"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone" className="text-sm">მობილური ნომერი *</Label>
                        <Input
                          id="phone"
                          name="phone"
                          defaultValue={editingEmployee?.phone || ''}
                          placeholder="11111111111"
                          className="mt-1"
                        />
                        {errors.phone && <p className="mt-1 text-sm text-destructive">{errors.phone}</p>}
                      </div>
                      <div>
                        <Label htmlFor="personal_id_number" className="text-sm">პირადი ნომერი *</Label>
                        <Input
                          id="personal_id_number"
                          name="personal_id_number"
                          defaultValue={editingEmployee?.personal_id_number || ''}
                          placeholder="11111111111"
                          className="mt-1"
                        />
                        {errors.personal_id_number && <p className="mt-1 text-sm text-destructive">{errors.personal_id_number}</p>}
                      </div>
                      <div>
                        <Label htmlFor="date_of_birth" className="text-sm">დაბადების თარიღი</Label>
                        <Input
                          id="date_of_birth"
                          name="date_of_birth"
                          type="date"
                          defaultValue={editingEmployee?.date_of_birth || ''}
                          className="mt-1"
                        />
                        {errors.date_of_birth && <p className="mt-1 text-sm text-destructive">{errors.date_of_birth}</p>}
                        <p className="text-xs text-muted-foreground mt-1">
                          ⓘ თარიღის ფორმატი ავტომატურად გადამოწმდება სისტემის მიერ
                        </p>
                      </div>
                    </div>
                    
                    {/* Status Checkboxes */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-primary/10">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="is_minor"
                          checked={formIsMinor}
                          onCheckedChange={(checked) => setFormIsMinor(checked as boolean)}
                        />
                        <Label htmlFor="is_minor" className="text-sm font-normal cursor-pointer">
                          არასრულწლოვანი
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="has_disability"
                          checked={formHasDisability}
                          onCheckedChange={(checked) => setFormHasDisability(checked as boolean)}
                        />
                        <Label htmlFor="has_disability" className="text-sm font-normal cursor-pointer">
                          შშმპ
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="is_intern"
                          checked={formIsIntern}
                          onCheckedChange={(checked) => setFormIsIntern(checked as boolean)}
                        />
                        <Label htmlFor="is_intern" className="text-sm font-normal cursor-pointer">
                          სტაჟიორი
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="is_pregnant"
                          checked={formIsPregnant}
                          onCheckedChange={(checked) => setFormIsPregnant(checked as boolean)}
                        />
                        <Label htmlFor="is_pregnant" className="text-sm font-normal cursor-pointer">
                          ორსული
                        </Label>
                      </div>
                    </div>
                  </div>

                  {/* Address Information Section */}
                  <div className="space-y-6 p-6 rounded-2xl bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm border border-primary/10 shadow-lg">
                    <div className="flex items-center gap-3 pb-3 border-b border-primary/10">
                      <div className="p-2 rounded-lg bg-gradient-to-br from-blue-600/20 to-blue-500/20">
                        <Building2 className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <h3 className="text-lg font-bold text-foreground">მისამართები</h3>
                    </div>
                    <div className="grid grid-cols-1 gap-6">
                      <div>
                        <Label htmlFor="actual_address" className="text-sm">ფაქტიური მისამართი</Label>
                        <Input
                          id="actual_address"
                          name="actual_address"
                          defaultValue={editingEmployee?.actual_address || ''}
                          placeholder="ქალაქი, ქუჩა, ბინა"
                          className="mt-1"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          ⓘ მიუთითეთ თანამშრომლის ფაქტიური საცხოვრებელი მისამართი
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Education & Experience Section */}
                  <div className="space-y-6 p-6 rounded-2xl bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm border border-primary/10 shadow-lg">
                    <div className="flex items-center gap-3 pb-3 border-b border-primary/10">
                      <div className="p-2 rounded-lg bg-gradient-to-br from-purple-600/20 to-purple-500/20">
                        <Briefcase className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                      </div>
                      <h3 className="text-lg font-bold text-foreground">განათლება და გამოცდილება</h3>
                    </div>
                    <div className="grid grid-cols-1 gap-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="education_level" className="text-sm">განათლების დონე</Label>
                          <Select value={formEducationLevel} onValueChange={setFormEducationLevel}>
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="აირჩიეთ განათლების დონე" />
                            </SelectTrigger>
                            <SelectContent position="popper">
                              <SelectItem value="none">არჩევანის გარეშე</SelectItem>
                              <SelectItem value="საშუალო">საშუალო</SelectItem>
                              <SelectItem value="ბაკალავრი">ბაკალავრი</SelectItem>
                              <SelectItem value="მაგისტრი">მაგისტრი</SelectItem>
                              <SelectItem value="დოქტორი">დოქტორი</SelectItem>
                              <SelectItem value="პროფესიული">პროფესიული</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="education" className="text-sm">განათლება (დეტალურად)</Label>
                        <textarea
                          id="education"
                          name="education"
                          defaultValue={editingEmployee?.education || ''}
                          placeholder="სასწავლებელი/უნივერსიტეტი, ფაკულტეტი, სპეციალობა, წელი"
                          className="mt-1 w-full min-h-[80px] rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                          rows={3}
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          ⓘ თანამშრომლის მიერ შეივსება განათლების შესახებ დეტალური ინფორმაცია
                        </p>
                      </div>
                      <div>
                        <Label htmlFor="previous_experience" className="text-sm">სამუშაო გამოცდილება</Label>
                        <textarea
                          id="previous_experience"
                          name="previous_experience"
                          defaultValue={editingEmployee?.previous_experience || ''}
                          placeholder="კომპანია, პოზიცია, პერიოდი, მოკლე აღწერა"
                          className="mt-1 w-full min-h-[100px] rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                          rows={4}
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          ⓘ თანამშრომლის მიერ შეივსება წინა სამსახურებრივი გამოცდილების შესახებ
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Emergency Contact Section */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-teal-600 dark:text-teal-400">საგანგებო კონტაქტი</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="emergency_contact_name" className="text-sm">სახელი</Label>
                        <Input
                          id="emergency_contact_name"
                          name="emergency_contact_name"
                          defaultValue={editingEmployee?.emergency_contact_name || ''}
                          placeholder="ახლობელი პირის სახელი"
                          className="mt-1"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          ⓘ საგანგებო შემთხვევაში დასაკონტაქტებელი პირი
                        </p>
                      </div>
                      <div>
                        <Label htmlFor="emergency_contact_phone" className="text-sm">ტელეფონი</Label>
                        <Input
                          id="emergency_contact_phone"
                          name="emergency_contact_phone"
                          defaultValue={editingEmployee?.emergency_contact_phone || ''}
                          placeholder="+995 555 123456"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="emergency_contact_relation" className="text-sm">ნათესაური კავშირი</Label>
                        <Input
                          id="emergency_contact_relation"
                          name="emergency_contact_relation"
                          defaultValue={editingEmployee?.emergency_contact_relation || ''}
                          placeholder="მაგ: ცოლი, ძმა, დედა"
                          className="mt-1"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Financial Information Section */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-teal-600 dark:text-teal-400">ფინანსური ინფორმაცია</h3>
                    <div className="grid grid-cols-1 gap-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="bank_name" className="text-sm">ბანკის დასახელება</Label>
                          <Input
                            id="bank_name"
                            name="bank_name"
                            defaultValue={editingEmployee?.bank_name || ''}
                            placeholder="მაგ: თიბისი ბანკი, საქართველოს ბანკი"
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label htmlFor="bank_account_number" className="text-sm">საბანკო ანგარიშის ნომერი (IBAN)</Label>
                          <Input
                            id="bank_account_number"
                            name="bank_account_number"
                            defaultValue={editingEmployee?.bank_account_number || ''}
                            placeholder="GE00TB0000000000000000"
                            className="mt-1"
                          />
                          <p className="text-xs text-muted-foreground mt-1">
                            ⓘ ხელფასის ჩარიცხვისთვის გამოყენებული ანგარიში
                          </p>
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="tax_benefits" className="text-sm">საშემოსავლო შეღავათი</Label>
                        <textarea
                          id="tax_benefits"
                          name="tax_benefits"
                          defaultValue={editingEmployee?.tax_benefits || ''}
                          placeholder="საქართველოს საგადასახადო კოდექსის მიხედვით შეღავათები"
                          className="mt-1 w-full min-h-[100px] rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                          rows={4}
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          ⓘ თანამშრომლის მიერ შეივსება შეღავათები: <br/>
                          • უძრავი ქონების იპოთეკური დაკრედიტება (წლიურად 40,000 ლარამდე)<br/>
                          • განათლებაზე გაწეული ხარჯები (3,000 ლარამდე)<br/>
                          • სამედიცინო ხარჯები (10,000 ლარამდე)<br/>
                          • შვილზე შეღავათი (თითო შვილზე 60 ლარი თვეში)<br/>
                          • საპენსიო შენატანები (200 ლარამდე თვეში)
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-teal-600 dark:text-teal-400">სისტემური ინფორმაცია</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="user_role" className="text-sm">მომხმარებლის როლი *</Label>
                        <Select value={formUserRole} onValueChange={setFormUserRole}>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="აირჩიეთ როლი" />
                          </SelectTrigger>
                          <SelectContent position="popper">
                            <SelectItem value="employee">თანამშრომელი</SelectItem>
                            <SelectItem value="department_manager">მენეჯერი</SelectItem>
                            {userRole === 'admin' && <SelectItem value="hr_manager">HR მენეჯერი</SelectItem>}
                            {userRole === 'admin' && <SelectItem value="admin">ადმინისტრატორი</SelectItem>}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="department" className="text-sm">დეპარტამენტი *</Label>
                        <Select value={formDepartment} onValueChange={setFormDepartment}>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="აირჩიეთ დეპარტამენტი" />
                          </SelectTrigger>
                          <SelectContent position="popper" className="max-h-[300px]">
                            <SelectItem value="none">არჩევანის გარეშე</SelectItem>
                            {departments
                              .filter(dept => !dept.parent_department_id)
                              .map((dept) => (
                                <>
                                  <SelectItem key={dept.id} value={dept.id}>
                                    {dept.name}
                                  </SelectItem>
                                  {departments
                                    .filter(subDept => subDept.parent_department_id === dept.id)
                                    .map((subDept) => (
                                      <SelectItem key={subDept.id} value={subDept.id} className="pl-6">
                                        └─ {subDept.name}
                                      </SelectItem>
                                    ))}
                                </>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {(hasMultipleBranches || canViewAllBranches) && branches.length > 0 && (
                        <div>
                          <Label htmlFor="branch_id" className="text-sm">ფილიალი</Label>
                          <Select value={formBranchId} onValueChange={setFormBranchId}>
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="აირჩიეთ ფილიალი" />
                            </SelectTrigger>
                            <SelectContent position="popper" className="max-h-[300px]">
                              <SelectItem value="none">არჩევანის გარეშე</SelectItem>
                              {branches.map((b) => (
                                <SelectItem key={b.id} value={b.id}>
                                  {b.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                      <div>
                        <div className="flex items-center justify-between">
                          <Label htmlFor="position" className="text-sm">თანამდებობა *</Label>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="h-7 text-xs"
                            onClick={() => setAddPositionOpen(true)}
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            ახალი პოზიცია
                          </Button>
                        </div>
                        <Select value={formPosition} onValueChange={setFormPosition} required>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="აირჩიეთ თანამდებობა" />
                          </SelectTrigger>
                          <SelectContent position="popper" className="max-h-[300px]">
                            <SelectItem value="none">არჩევანის გარეშე</SelectItem>
                            {formDepartment && formDepartment !== 'none' 
                              ? positions
                                  .filter((pos) => pos.department_id === formDepartment)
                                  .map((pos) => (
                                    <SelectItem key={pos.id} value={pos.id}>
                                      {pos.title}
                                    </SelectItem>
                                  ))
                              : positions.map((pos) => (
                                  <SelectItem key={pos.id} value={pos.id}>
                                    {pos.title} {pos.department?.name ? `(${pos.department.name})` : ''}
                                  </SelectItem>
                                ))
                            }
                          </SelectContent>
                        </Select>
                        {errors.position && <p className="mt-1 text-sm text-destructive">{errors.position}</p>}
                      </div>
                      <div>
                        <Label className="text-sm">გრაფიკის ტიპი *</Label>
                        <Select value={formScheduleCategory} onValueChange={(value) => {
                          setFormScheduleCategory(value);
                          // Reset schedule selection when category changes
                          setFormWorkSchedule("none");
                        }}>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="აირჩიეთ გრაფიკის ტიპი" />
                          </SelectTrigger>
                          <SelectContent position="popper" className="max-h-[300px]">
                            <SelectItem value="full">სრული</SelectItem>
                            <SelectItem value="part_time">არასრული</SelectItem>
                            <SelectItem value="shifts">ცვლები</SelectItem>
                            <SelectItem value="flexible">თავისუფალი</SelectItem>
                            <SelectItem value="remote">დისტანციური</SelectItem>
                            <SelectItem value="hybrid">ჰიბრიდული</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      {formScheduleCategory !== "shifts" && (
                        <>
                          <div>
                            <Label htmlFor="work_schedule" className="text-sm">გრაფიკის დასახელება *</Label>
                            <Select value={formWorkSchedule} onValueChange={(value) => {
                              setFormWorkSchedule(value);
                              // Auto-fill times from template
                              const template = scheduleTemplates.find((t: any) => t.id === value);
                              if (template) {
                                setFormCustomStartTime(template.start_time || '');
                                setFormCustomEndTime(template.end_time || '');
                              }
                            }} disabled={formScheduleCategory === "none"}>
                              <SelectTrigger className="mt-1">
                                <SelectValue placeholder={formScheduleCategory === "none" ? "ჯერ აირჩიეთ გრაფიკის ტიპი" : "აირჩიეთ გრაფიკი"} />
                              </SelectTrigger>
                              <SelectContent position="popper" className="max-h-[300px]">
                                {scheduleTemplates
                                  .filter((template: any) => template.schedule_category === formScheduleCategory)
                                  .map((template: any) => (
                                    <SelectItem key={template.id} value={template.id}>
                                      {template.name}
                                    </SelectItem>
                                  ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                              <Label className="text-sm">დაწყების დრო</Label>
                              <Input
                                type="time"
                                value={formCustomStartTime}
                                onChange={(e) => setFormCustomStartTime(e.target.value)}
                                className="mt-1"
                              />
                            </div>
                            <div>
                              <Label className="text-sm">დასრულების დრო</Label>
                              <Input
                                type="time"
                                value={formCustomEndTime}
                                onChange={(e) => setFormCustomEndTime(e.target.value)}
                                className="mt-1"
                              />
                            </div>
                          </div>
                        </>
                      )}
                      <div>
                        <Label htmlFor="hire_date" className="text-sm">დაქირავების თარიღი</Label>
                        <Input
                          id="hire_date"
                          name="hire_date"
                          type="date"
                          defaultValue={editingEmployee?.hire_date || ''}
                          className="mt-1"
                        />
                        {errors.hire_date && <p className="mt-1 text-sm text-destructive">{errors.hire_date}</p>}
                      </div>
                      <div>
                        <Label htmlFor="salary" className="text-sm">ხელფასი</Label>
                        <Input
                          id="salary"
                          name="salary"
                          type="number"
                          step="0.01"
                          defaultValue={editingEmployee?.salary || ''}
                          placeholder="0.00"
                          className="mt-1"
                        />
                        {errors.salary && <p className="mt-1 text-sm text-destructive">{errors.salary}</p>}
                      </div>
                      <div>
                        <Label htmlFor="turnstile_card" className="text-sm">ბარათის ნომერი (ტურნიკეტის შემთხვევაში)</Label>
                        <Input
                          id="turnstile_card"
                          value={formTurnstileCard}
                          onChange={(e) => setFormTurnstileCard(e.target.value)}
                          placeholder="ბარათის ნომერი"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="attendance_method" className="text-sm">აღრიცხვის მეთოდი</Label>
                        <Select value={formAttendanceMethod} onValueChange={setFormAttendanceMethod}>
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="mobile">მობილური</SelectItem>
                            <SelectItem value="turnstile">ტურნიკეტი</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="secondary_manager_id" className="text-sm">მეორე ხელმძღვანელი</Label>
                        <div className="relative mt-1">
                          <Input
                            placeholder="ჩაწერეთ თანამშრომლის გვარი..."
                            value={
                              formSecondaryManagerId 
                                ? lookupEmployees.find(e => e.id === formSecondaryManagerId)?.full_name || ''
                                : secondaryManagerSearch
                            }
                            onChange={(e) => {
                              setSecondaryManagerSearch(e.target.value);
                              if (formSecondaryManagerId) {
                                setFormSecondaryManagerId('');
                              }
                            }}
                            onFocus={() => setShowSecondaryManagerDropdown(true)}
                          />
                          {formSecondaryManagerId && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="absolute right-1 top-1/2 -translate-y-1/2 h-6 w-6 p-0"
                              onClick={() => {
                                setFormSecondaryManagerId('');
                                setSecondaryManagerSearch('');
                              }}
                            >
                              <XCircle className="h-4 w-4" />
                            </Button>
                          )}
                          {showSecondaryManagerDropdown && secondaryManagerSearch && !formSecondaryManagerId && (
                            <div className="absolute z-50 mt-1 w-full rounded-md border border-border bg-popover shadow-md max-h-[200px] overflow-y-auto">
                              {lookupEmployees
                                .filter(emp => 
                                  emp.full_name.toLowerCase().includes(secondaryManagerSearch.toLowerCase()) &&
                                  emp.id !== editingEmployee?.id
                                )
                                .slice(0, 10)
                                .map((emp) => (
                                  <div
                                    key={emp.id}
                                    className="px-3 py-2 cursor-pointer hover:bg-accent text-sm"
                                    onClick={() => {
                                      setFormSecondaryManagerId(emp.id);
                                      setSecondaryManagerSearch('');
                                      setShowSecondaryManagerDropdown(false);
                                    }}
                                  >
                                    {emp.full_name} - {emp.position}
                                  </div>
                                ))}
                              {lookupEmployees.filter(emp => 
                                emp.full_name.toLowerCase().includes(secondaryManagerSearch.toLowerCase())
                              ).length === 0 && (
                                <div className="px-3 py-2 text-sm text-muted-foreground">
                                  თანამშრომელი ვერ მოიძებნა
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {/* Probation Period */}
                    <div className="flex items-center gap-4 p-4 rounded-lg border border-border/50 bg-muted/30">
                      <Checkbox
                        id="is_probation"
                        checked={formIsProbation}
                        onCheckedChange={(checked) => setFormIsProbation(checked as boolean)}
                      />
                      <Label htmlFor="is_probation" className="text-sm cursor-pointer flex-1">
                        გამოსაცდელი ვადა
                      </Label>
                      {formIsProbation && (
                        <Select 
                          value={formProbationMonths.toString()} 
                          onValueChange={(value) => setFormProbationMonths(parseInt(value))}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">1 თვე</SelectItem>
                            <SelectItem value="2">2 თვე</SelectItem>
                            <SelectItem value="3">3 თვე</SelectItem>
                            <SelectItem value="4">4 თვე</SelectItem>
                            <SelectItem value="6">6 თვე</SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                  </div>

              {/* Citizenship Information */}
              <div className="space-y-6 p-6 rounded-2xl bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm border border-primary/10 shadow-lg">
                <div className="flex items-center gap-3 pb-3 border-b border-primary/10">
                  <div className="p-2 rounded-lg bg-gradient-to-br from-amber-600/20 to-amber-500/20">
                    <Globe className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                  </div>
                  <h3 className="text-lg font-bold text-foreground">მოქალაქეობის ინფორმაცია</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="residency_status" className="text-sm">მოქალაქეობა</Label>
                        <Select value={formResidencyStatus} onValueChange={setFormResidencyStatus}>
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="resident">რეზიდენტი</SelectItem>
                            <SelectItem value="non_resident">არარეზიდენტი</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      {formResidencyStatus === 'non_resident' && (
                        <div>
                          <Label htmlFor="foreign_country" className="text-sm">უცხო ქვეყანა</Label>
                          <Select value={formForeignCountry} onValueChange={setFormForeignCountry}>
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="აირჩიეთ ქვეყანა" />
                            </SelectTrigger>
                            <SelectContent position="popper" className="max-h-[300px]">
                              <SelectItem value="USA">ამერიკის შეერთებული შტატები</SelectItem>
                              <SelectItem value="UK">გაერთიანებული სამეფო</SelectItem>
                              <SelectItem value="Germany">გერმანია</SelectItem>
                              <SelectItem value="France">საფრანგეთი</SelectItem>
                              <SelectItem value="Italy">იტალია</SelectItem>
                              <SelectItem value="Spain">ესპანეთი</SelectItem>
                              <SelectItem value="Turkey">თურქეთი</SelectItem>
                              <SelectItem value="Russia">რუსეთი</SelectItem>
                              <SelectItem value="Armenia">სომხეთი</SelectItem>
                              <SelectItem value="Azerbaijan">აზერბაიჯანი</SelectItem>
                              <SelectItem value="Ukraine">უკრაინა</SelectItem>
                              <SelectItem value="Poland">პოლონეთი</SelectItem>
                              <SelectItem value="Greece">საბერძნეთი</SelectItem>
                              <SelectItem value="Israel">ისრაელი</SelectItem>
                              <SelectItem value="UAE">არაბეთის გაერთიანებული საემიროები</SelectItem>
                              <SelectItem value="China">ჩინეთი</SelectItem>
                              <SelectItem value="Japan">იაპონია</SelectItem>
                              <SelectItem value="India">ინდოეთი</SelectItem>
                              <SelectItem value="Other">სხვა</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                    </div>
                    
                    {/* Dual Citizenship */}
                    <div className="flex items-start gap-4 p-4 rounded-lg border border-border/50 bg-muted/30">
                      <Checkbox
                        id="is_dual_citizen"
                        checked={formIsDualCitizen}
                        onCheckedChange={(checked) => setFormIsDualCitizen(checked as boolean)}
                        className="mt-1"
                      />
                      <div className="flex-1">
                        <Label htmlFor="is_dual_citizen" className="text-sm cursor-pointer">
                          ორმაგი მოქალაქე
                        </Label>
                        {formIsDualCitizen && (
                          <div className="mt-3 space-y-2">
                            <Label className="text-xs text-muted-foreground">აირჩიეთ ქვეყნები:</Label>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {[
                                { value: 'USA', label: 'ამერიკის შეერთებული შტატები' },
                                { value: 'UK', label: 'გაერთიანებული სამეფო' },
                                { value: 'Germany', label: 'გერმანია' },
                                { value: 'France', label: 'საფრანგეთი' },
                                { value: 'Italy', label: 'იტალია' },
                                { value: 'Spain', label: 'ესპანეთი' },
                                { value: 'Turkey', label: 'თურქეთი' },
                                { value: 'Russia', label: 'რუსეთი' },
                                { value: 'Armenia', label: 'სომხეთი' },
                                { value: 'Azerbaijan', label: 'აზერბაიჯანი' },
                                { value: 'Ukraine', label: 'უკრაინა' },
                                { value: 'Poland', label: 'პოლონეთი' },
                                { value: 'Greece', label: 'საბერძნეთი' },
                                { value: 'Israel', label: 'ისრაელი' },
                              ].map((country) => (
                                <div key={country.value} className="flex items-center gap-2">
                                  <Checkbox
                                    id={`country_${country.value}`}
                                    checked={formCitizenshipCountries.includes(country.value)}
                                    onCheckedChange={(checked) => {
                                      setFormCitizenshipCountries((prev) =>
                                        checked
                                          ? [...prev, country.value]
                                          : prev.filter((c) => c !== country.value)
                                      );
                                    }}
                                  />
                                  <Label htmlFor={`country_${country.value}`} className="text-xs cursor-pointer">
                                    {country.label}
                                  </Label>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

              {/* Comment Section */}
              <div className="space-y-6 p-6 rounded-2xl bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm border border-primary/10 shadow-lg">
                <div className="flex items-center gap-3 pb-3 border-b border-primary/10">
                  <div className="p-2 rounded-lg bg-gradient-to-br from-gray-600/20 to-gray-500/20">
                    <FileText className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                  </div>
                  <h3 className="text-lg font-bold text-foreground">კომენტარი</h3>
                </div>
                    <div>
                      <Label htmlFor="employee_comment" className="text-sm">კომენტარი</Label>
                      <textarea
                        id="employee_comment"
                        value={formComment}
                        onChange={(e) => setFormComment(e.target.value)}
                        placeholder="დამატებითი ინფორმაცია თანამშრომლის შესახებ"
                        className="mt-1 w-full min-h-[100px] rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                        rows={4}
                      />
                    </div>
                  </div>

                  {/* Configuration Toggles */}
                  <div className="space-y-6 p-6 rounded-2xl bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm border border-primary/10 shadow-lg">
                    <div className="flex items-center gap-3 pb-3 border-b border-primary/10">
                      <div className="p-2 rounded-lg bg-gradient-to-br from-green-600/20 to-green-500/20">
                        <Settings className="h-5 w-5 text-green-600 dark:text-green-400" />
                      </div>
                      <h3 className="text-lg font-bold text-foreground">კონფიგურაცია</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <Label className="text-sm mb-3 block">სქესი</Label>
                      <div className="flex gap-4">
                        <Button
                          type="button"
                          variant={formGender === 'male' ? 'default' : 'outline'}
                          className={formGender === 'male' ? 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-lg hover:shadow-xl transition-all flex-1' : 'flex-1'}
                          onClick={() => setFormGender('male')}
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          მამრობითი
                        </Button>
                        <Button
                          type="button"
                          variant={formGender === 'female' ? 'default' : 'outline'}
                          className={formGender === 'female' ? 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-lg hover:shadow-xl transition-all flex-1' : 'flex-1'}
                          onClick={() => setFormGender('female')}
                        >
                          <XCircle className="h-4 w-4 mr-2" />
                          მდედრობითი
                        </Button>
                      </div>
                    </div>


                    {/* Compact Toggle Settings */}
                    <div className="space-y-3 p-4 rounded-xl bg-muted/30 border border-border/50">
                      <div className="flex items-center justify-between py-2">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-emerald-500" />
                          <Label htmlFor="pension-payer" className="text-sm cursor-pointer">პენსიის გადამხდელი</Label>
                        </div>
                        <Switch
                          id="pension-payer"
                          checked={formIsPensionPayer}
                          onCheckedChange={setFormIsPensionPayer}
                          className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-emerald-500 data-[state=checked]:to-green-600"
                        />
                      </div>
                      
                      <div className="flex items-center justify-between py-2 border-t border-border/30">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-cyan-500" />
                          <Label htmlFor="lateness-control" className="text-sm cursor-pointer">დაგვიანების დროის კონტროლი</Label>
                        </div>
                        <Switch
                          id="lateness-control"
                          checked={formLatenessControl}
                          onCheckedChange={setFormLatenessControl}
                          className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-cyan-500 data-[state=checked]:to-teal-600"
                        />
                      </div>
                      
                      <div className="flex items-center justify-between py-2 border-t border-border/30">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-amber-500" />
                          <Label htmlFor="receive-lateness" className="text-sm cursor-pointer">დაგვიანების SMS მიღება</Label>
                        </div>
                        <Switch
                          id="receive-lateness"
                          checked={formReceiveLateness}
                          onCheckedChange={setFormReceiveLateness}
                          className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-amber-500 data-[state=checked]:to-orange-600"
                        />
                      </div>
                      
                      <div className="flex items-center justify-between py-2 border-t border-border/30">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-violet-500" />
                          <Label htmlFor="receive-sub-lateness" className="text-sm cursor-pointer">დაქვემდებარებულის დაგვიანების SMS</Label>
                        </div>
                        <Switch
                          id="receive-sub-lateness"
                          checked={formReceiveSubLateness}
                          onCheckedChange={setFormReceiveSubLateness}
                          className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-violet-500 data-[state=checked]:to-purple-600"
                        />
                      </div>
                      
                      <div className="flex items-center justify-between py-2 border-t border-border/30">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-blue-500" />
                          <Label htmlFor="show-phone" className="text-sm cursor-pointer">მობილურის ნომრის გამოჩენა</Label>
                        </div>
                        <Switch
                          id="show-phone"
                          checked={formShowPhone}
                          onCheckedChange={setFormShowPhone}
                          className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-blue-500 data-[state=checked]:to-indigo-600"
                        />
                      </div>
                      
                      <div className="flex items-center justify-between py-2 border-t border-border/30">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-rose-500" />
                          <Label htmlFor="show-email" className="text-sm cursor-pointer">ელ.ფოსტის გამოჩენა</Label>
                        </div>
                        <Switch
                          id="show-email"
                          checked={formShowEmail}
                          onCheckedChange={setFormShowEmail}
                          className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-rose-500 data-[state=checked]:to-pink-600"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Benefits Section */}
                  <div className="space-y-6 p-6 rounded-2xl bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm border border-primary/10 shadow-lg">
                    <div className="flex items-center gap-3 pb-3 border-b border-primary/10">
                      <div className="p-2 rounded-lg bg-gradient-to-br from-blue-600/20 to-blue-500/20">
                        <Shield className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <h3 className="text-lg font-bold text-foreground">სარგებლები</h3>
                    </div>
                    <div className="space-y-4">
                      <Label className="text-sm">აირჩიეთ სარგებლები თანამშრომლისთვის</Label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {benefitPlans.map((plan) => (
                          <div
                            key={plan.id}
                            className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                              formBenefitPlans.includes(plan.id)
                                ? 'border-teal-600 bg-teal-600/10'
                                : 'border-border hover:border-teal-600/50'
                            }`}
                          >
                            <div className="flex items-start gap-3">
                              <Checkbox
                                checked={formBenefitPlans.includes(plan.id)}
                                onCheckedChange={(checked) => {
                                  setFormBenefitPlans((prev) =>
                                    checked
                                      ? [...prev, plan.id]
                                      : prev.filter((id) => id !== plan.id)
                                  );
                                }}
                                className="mt-1"
                              />
                              <div className="flex-1 pointer-events-none">
                                <h4 className="font-semibold text-sm">{plan.plan_name}</h4>
                                <p className="text-xs text-muted-foreground mt-1">
                                  {plan.plan_type} - {plan.provider_name}
                                </p>
                                <div className="flex gap-2 mt-2">
                                  <Badge variant="outline" className="text-xs">
                                    თანამშრომელი: {plan.employee_contribution} ₾
                                  </Badge>
                                  <Badge variant="outline" className="text-xs">
                                    დამსაქმებელი: {plan.employer_contribution} ₾
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                      {benefitPlans.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">
                          სარგებლები არ არის კონფიგურირებული. გადადით{' '}
                          <span className="text-teal-600 cursor-pointer" onClick={() => navigate('/benefits-admin')}>
                            სარგებლების ადმინისტრირებაში
                          </span>{' '}
                          დასამატებლად.
                        </p>
                      )}
                    </div>
                  </div>

                  {!editingEmployee && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="custom_password" className="text-sm">პაროლი (არჩევითი)</Label>
                        <Input
                          id="custom_password"
                          name="custom_password"
                          type="password"
                          value={customPassword}
                          onChange={(e) => setCustomPassword(e.target.value)}
                          placeholder="ავტომატურად შეიქმნება"
                          className="mt-1"
                        />
                        <p className="text-xs text-muted-foreground mt-1">თუ არ შეავსებთ, შეიქმნება ძლიერი დროებითი პაროლი. საკუთარი: მინიმუმ 8 სიმბოლო, ასოები და ციფრები.</p>
                      </div>
                    </div>
                  )}

                  <div>
                    <Label htmlFor="status" className="text-sm">სტატუსი *</Label>
                    <Select value={formStatus} onValueChange={setFormStatus}>
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">აქტიური</SelectItem>
                        <SelectItem value="inactive">არააქტიური</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {formStatus === 'inactive' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="termination_date" className="text-sm">წასვლის თარიღი</Label>
                        <Input
                          id="termination_date"
                          name="termination_date"
                          type="date"
                          defaultValue={editingEmployee?.termination_date || ''}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="termination_reason" className="text-sm">წასვლის მიზეზი</Label>
                        <Input
                          id="termination_reason"
                          name="termination_reason"
                          defaultValue={editingEmployee?.termination_reason || ''}
                          placeholder="მიუთითეთ მიზეზი"
                          className="mt-1"
                        />
                      </div>
                    </div>
                  )}

                  <div className="flex gap-4 pt-8 mt-8 border-t-2 border-primary/20">
                    <Button 
                      type="button" 
                      variant="ghost" 
                      className="flex-1 h-14 text-base font-semibold rounded-2xl border-2 border-slate-300 dark:border-slate-600 hover:border-slate-400 dark:hover:border-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all duration-300 group"
                      onClick={() => setIsDialogOpen(false)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center group-hover:bg-slate-300 dark:group-hover:bg-slate-600 transition-colors">
                          <XCircle className="h-4 w-4 text-slate-600 dark:text-slate-300" />
                        </div>
                        <span className="text-slate-700 dark:text-slate-200">უკან დაბრუნება</span>
                      </div>
                    </Button>
                    <Button 
                      type="submit" 
                      className="flex-1 h-14 text-base font-semibold rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-600 hover:via-teal-600 hover:to-cyan-600 text-white shadow-lg hover:shadow-xl hover:shadow-teal-500/25 transition-all duration-300 group" 
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <span className="flex items-center gap-3">
                          <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                          მიმდინარეობს...
                        </span>
                      ) : (
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-colors">
                            <CheckCircle className="h-4 w-4 text-white" />
                          </div>
                          <span>შენახვა და განახლება</span>
                        </div>
                      )}
                    </Button>
                  </div>
                </form>
              )}
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="space-y-4">
        <div className="flex gap-2 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="ძებნა თანამშრომლების მიხედვით..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          {/* View Toggle Buttons */}
          <div className="flex gap-1 border rounded-md p-1">
            <Button
              size="sm"
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              onClick={() => setViewMode('list')}
              className="gap-2"
            >
              <List className="h-4 w-4" />
              სია
            </Button>
            <Button
              size="sm"
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              onClick={() => setViewMode('grid')}
              className="gap-2"
            >
              <Grid3x3 className="h-4 w-4" />
              ბადე
            </Button>
          </div>

          {canManageEmployees && selectedEmployees.length > 0 && (
            <Button 
              variant="destructive" 
              onClick={handleBulkDelete}
              className="gap-2"
            >
              <Trash2 className="h-4 w-4" />
              წაშლა ({selectedEmployees.length})
            </Button>
          )}
          {canManageEmployees && (
            <>
              <EmployeeMigrationDialog onSuccess={fetchEmployees} />
              <Button onClick={handleExportEmployees} variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                ექსპორტი
              </Button>
              {selectedEmployees.length > 0 && (
                <>
                  <Button onClick={handleBulkExport} variant="outline" className="gap-2">
                    <Download className="h-4 w-4" />
                    არჩეულის ექსპორტი ({selectedEmployees.length})
                  </Button>
                  <Button 
                    onClick={() => handleBulkStatusChange('active')} 
                    variant="outline" 
                    className="gap-2"
                  >
                    <CheckSquare className="h-4 w-4" />
                    გააქტიურება
                  </Button>
                  <Button 
                    onClick={() => handleBulkStatusChange('inactive')} 
                    variant="outline" 
                    className="gap-2"
                  >
                    <UserX className="h-4 w-4" />
                    დეაქტივაცია
                  </Button>
                  <Button 
                    onClick={handleBulkDelete} 
                    variant="destructive" 
                    className="gap-2"
                  >
                    <Trash2 className="h-4 w-4" />
                    წაშლა ({selectedEmployees.length})
                  </Button>
                </>
              )}
            </>
          )}
        </div>
        
        <div className="flex items-center gap-2 flex-wrap">
          {canManageEmployees && (
            <Button 
              onClick={toggleSelectAll} 
              variant={selectedEmployees.length === filteredEmployees.length && filteredEmployees.length > 0 ? "default" : "outline"}
              size="sm"
              className="gap-2"
            >
              {selectedEmployees.length === filteredEmployees.length && filteredEmployees.length > 0 ? (
                <CheckSquare className="h-4 w-4" />
              ) : (
                <Square className="h-4 w-4" />
              )}
              {selectedEmployees.length > 0 ? `არჩეულია ${selectedEmployees.length}` : 'ყველას არჩევა'}
            </Button>
          )}
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            className="gap-2"
          >
            <Filter className="h-4 w-4" />
            ფილტრები
          </Button>
          {(filterGender !== "all" || filterStatus !== "all" || filterPosition !== "all" || filterEducationLevel !== "all" ||
            filterSalaryMin || filterSalaryMax || filterHireDate || filterTerminationDate || 
            filterScheduleType !== "all" || filterIsMinor !== "all" || filterHasDisability !== "all" || filterPersonalId) && (
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => {
                setFilterGender("all");
                setFilterStatus("all");
                setFilterPosition("all");
                setFilterDepartment("all");
                setFilterEducationLevel("all");
                setFilterSalaryMin("");
                setFilterSalaryMax("");
                setFilterHireDate("");
                setFilterTerminationDate("");
                setFilterScheduleType("all");
                setFilterIsMinor("all");
                setFilterHasDisability("all");
                setFilterPersonalId("");
              }}
            >
              გასუფთავება
            </Button>
          )}
        </div>

        {showFilters && (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 p-4 border rounded-lg bg-muted/50">
            <div>
              <Label>სქესი</Label>
              <Select value={filterGender} onValueChange={setFilterGender}>
                <SelectTrigger>
                  <SelectValue placeholder="ყველა" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  <SelectItem value="male">მამრობითი</SelectItem>
                  <SelectItem value="female">მდედრობითი</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>სტატუსი</Label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="ყველა" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  <SelectItem value="active">აქტიური</SelectItem>
                  <SelectItem value="inactive">არააქტიური</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>პოზიცია</Label>
              <Select value={filterPosition} onValueChange={setFilterPosition}>
                <SelectTrigger>
                  <SelectValue placeholder="ყველა" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  {positions.map((pos) => (
                    <SelectItem key={pos.id} value={pos.title}>
                      {pos.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>დეპარტამენტი</Label>
              <Select value={filterDepartment} onValueChange={setFilterDepartment}>
                <SelectTrigger>
                  <SelectValue placeholder="ყველა" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.name}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>განათლების დონე</Label>
              <Select value={filterEducationLevel} onValueChange={setFilterEducationLevel}>
                <SelectTrigger>
                  <SelectValue placeholder="ყველა" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  <SelectItem value="საშუალო">საშუალო</SelectItem>
                  <SelectItem value="ბაკალავრი">ბაკალავრი</SelectItem>
                  <SelectItem value="მაგისტრი">მაგისტრი</SelectItem>
                  <SelectItem value="დოქტორი">დოქტორი</SelectItem>
                  <SelectItem value="პროფესიული">პროფესიული</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>ხელფასი (დან)</Label>
              <Input
                type="number"
                placeholder="0"
                value={filterSalaryMin}
                onChange={(e) => setFilterSalaryMin(e.target.value)}
              />
            </div>
            <div>
              <Label>ხელფასი (მდე)</Label>
              <Input
                type="number"
                placeholder="0"
                value={filterSalaryMax}
                onChange={(e) => setFilterSalaryMax(e.target.value)}
              />
            </div>
            
            <div>
              <Label>გრაფიკის ტიპი</Label>
              <Select value={filterScheduleType} onValueChange={setFilterScheduleType}>
                <SelectTrigger>
                  <SelectValue placeholder="ყველა" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  {scheduleTemplates.map((template: any) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name} ({template.schedule_type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>არასრულწლოვანი</Label>
              <Select value={filterIsMinor} onValueChange={setFilterIsMinor}>
                <SelectTrigger>
                  <SelectValue placeholder="ყველა" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  <SelectItem value="true">კი</SelectItem>
                  <SelectItem value="false">არა</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>შშმპ</Label>
              <Select value={filterHasDisability} onValueChange={setFilterHasDisability}>
                <SelectTrigger>
                  <SelectValue placeholder="ყველა" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  <SelectItem value="true">კი</SelectItem>
                  <SelectItem value="false">არა</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>პირადი ნომერი</Label>
              <Input
                type="text"
                placeholder="ძებნა პირადი ნომრით..."
                value={filterPersonalId}
                onChange={(e) => setFilterPersonalId(e.target.value)}
              />
            </div>
            
            <div>
              <Label>დაქირავების თარიღი</Label>
              <Input
                type="date"
                value={filterHireDate}
                onChange={(e) => setFilterHireDate(e.target.value)}
              />
            </div>
            
            <div>
              <Label>წასვლის თარიღი</Label>
              <Input
                type="date"
                value={filterTerminationDate}
                onChange={(e) => setFilterTerminationDate(e.target.value)}
              />
            </div>
          </div>
        )}
      </div>

      {/* Filter result summary card */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="flex flex-wrap items-center gap-4 p-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Users className="h-6 w-6" />
          </div>
          <div className="min-w-0">
            <p className="text-xs uppercase tracking-wider text-muted-foreground">
              {(filterGender !== "all" || filterStatus !== "all" || filterPosition !== "all" || filterDepartment !== "all" || filterEducationLevel !== "all" || filterScheduleType !== "all" || filterIsMinor !== "all" || filterHasDisability !== "all" || filterSalaryMin || filterSalaryMax || filterHireDate || filterTerminationDate || filterPersonalId || searchQuery)
                ? 'გაფილტრული შედეგი'
                : 'სულ თანამშრომელი'}
            </p>
            <p className="font-display text-3xl font-bold leading-tight">
              {isLoading ? '…' : totalCount}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {filterGender !== "all" && (
              <Badge variant="secondary">{filterGender === 'female' ? 'მდედრობითი' : 'მამრობითი'}</Badge>
            )}
            {filterStatus !== "all" && (
              <Badge variant="secondary">{filterStatus === 'active' ? 'აქტიური' : filterStatus === 'inactive' ? 'არააქტიური' : filterStatus}</Badge>
            )}
            {filterDepartment !== "all" && <Badge variant="secondary">{filterDepartment}</Badge>}
            {filterPosition !== "all" && <Badge variant="secondary">{filterPosition}</Badge>}
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <EmployeeListSkeleton count={8} />
      ) : viewMode === 'grid' ? (
        <>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {pagedEmployees.map((employee) => (
          <div
            key={employee.id}
            className={`group bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800 rounded-[2rem] p-6 transition-all duration-300 hover:shadow-2xl hover:shadow-indigo-500/10 hover:-translate-y-1 ${selectedEmployees.includes(employee.id) ? 'ring-2 ring-indigo-500/60' : ''}`}
          >
            <div className="flex justify-between items-start mb-5">
              <div
                className="relative cursor-pointer"
                onClick={() => navigate(`/employees/${employee.id}`)}
              >
                <Avatar className="w-16 h-16 rounded-2xl">
                  <AvatarImage src={employee.avatar_url || ''} alt={employee.full_name} className="object-cover rounded-2xl" />
                  <AvatarFallback className="rounded-2xl bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-xl font-bold">
                    {employee.full_name.split(" ").map((n) => n[0]).join("")}
                  </AvatarFallback>
                </Avatar>
                <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-4 border-white dark:border-slate-900 ${employee.status === 'active' ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'}`}></div>
              </div>
              <div className="flex items-center gap-3">
                <span className={`px-3 py-1 text-[10px] font-bold rounded-full tracking-wide uppercase ${
                  employee.status === 'active'
                    ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                }`}>
                  {employee.status === 'active' ? 'აქტიური' : 'არააქტიური'}
                </span>
                {canManageEmployees && (
                  <div
                    className="cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleEmployeeSelection(employee.id);
                    }}
                  >
                    {selectedEmployees.includes(employee.id) ? (
                      <CheckSquare className="h-5 w-5 text-indigo-600" />
                    ) : (
                      <Square className="h-5 w-5 text-slate-300 dark:text-slate-600" />
                    )}
                  </div>
                )}
              </div>
            </div>

            <div
              className="space-y-1 mb-5 cursor-pointer"
              onClick={() => navigate(`/employees/${employee.id}`)}
            >
              <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors truncate">{employee.full_name}</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium truncate">{employee.position}</p>
              {employee.department && (
                <p className="text-xs text-indigo-500/70 dark:text-indigo-400/70 font-semibold truncate">{employee.department}</p>
              )}
            </div>

            <div className="space-y-2 border-t border-slate-100 dark:border-slate-800 pt-4">
              <div className="flex items-center gap-3 text-slate-500 dark:text-slate-400 min-w-0">
                <Mail className="w-4 h-4 shrink-0" />
                <span className="text-sm truncate">{employee.email}</span>
              </div>
              {employee.phone && (
                <div className="flex items-center gap-3 text-slate-500 dark:text-slate-400">
                  <Phone className="w-4 h-4 shrink-0" />
                  <span className="text-sm font-medium">{employee.phone}</span>
                </div>
              )}
              {employee.personal_id_number && (
                <p className="text-xs text-slate-400 dark:text-slate-500 pl-7">პირადი ნომერი: {employee.personal_id_number}</p>
              )}
            </div>

            {canManageEmployees && (
              <div className="mt-6 flex gap-2">
                <button
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white text-slate-700 dark:text-slate-300 rounded-xl transition-all font-semibold text-sm inline-flex items-center justify-center gap-2"
                  onClick={async (e) => {
                    e.stopPropagation();
                    const full = await fetchFullEmployee(employee.id);
                    const target = { ...employee, ...(full || {}) } as Employee;
                    setEditingEmployee(target);
                    setIsDialogOpen(true);
                    setFormStatus(target.status);
                    setFormGender(target.gender || 'none');
                    const positionId = positions.find(p => p.title === target.position)?.id || '';
                    setFormPosition(positionId);
                    setFormDepartment(target.department || 'none');
                  }}
                >
                  <Edit className="h-4 w-4" />
                  რედაქტირება
                </button>
                <button
                  className="p-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 rounded-xl transition-all disabled:opacity-50"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleResetPassword(employee);
                  }}
                  disabled={isLoading}
                  title="პაროლის განახლება"
                >
                  <RefreshCw className="h-4 w-4" />
                </button>
                <button
                  className="p-2.5 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-500 hover:text-white text-rose-500 rounded-xl transition-all"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete(employee.id);
                  }}
                  title="წაშლა"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
          ))}
        </div>

        {filteredEmployees.length === 0 && !isLoading && (
          <div className="flex h-64 items-center justify-center text-muted-foreground">
            თანამშრომლები არ მოიძებნა
          </div>
        )}
        <PaginationControls />
      </>
      ) : (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1100px]">
              <thead>
                <tr className="border-b bg-muted/50">
                {canManageEmployees && (
                  <th className="p-3 text-left">
                    <div 
                      className="flex items-center cursor-pointer"
                      onClick={() => {
                        if (selectedEmployees.length === filteredEmployees.length) {
                          setSelectedEmployees([]);
                        } else {
                          setSelectedEmployees(filteredEmployees.map(e => e.id));
                        }
                      }}
                    >
                      {selectedEmployees.length === filteredEmployees.length && filteredEmployees.length > 0 ? (
                        <CheckSquare className="h-4 w-4 text-primary" />
                      ) : (
                        <Square className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                  </th>
                )}
                  <th className="p-3 text-left w-12 text-xs font-medium">#</th>
                  <th className="min-w-[280px] p-3 text-left">
                    <button 
                      onClick={() => handleSort('full_name')}
                      className="flex items-center gap-1 hover:text-primary transition-colors text-xs font-medium"
                    >
                      სახელი და გვარი
                      {sortField === 'full_name' && (
                        sortDirection === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
                      )}
                    </button>
                  </th>
                  <th className="p-3 text-left text-xs font-medium">პირადი ნომერი</th>
                  <th className="p-3 text-left">
                    <button 
                      onClick={() => handleSort('position')}
                      className="flex items-center gap-1 hover:text-primary transition-colors text-xs font-medium"
                    >
                      პოზიცია
                      {sortField === 'position' && (
                        sortDirection === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
                      )}
                    </button>
                  </th>
                  <th className="p-3 text-left">
                    <button 
                      onClick={() => handleSort('department')}
                      className="flex items-center gap-1 hover:text-primary transition-colors text-xs font-medium"
                    >
                      დეპარტამენტი
                      {sortField === 'department' && (
                        sortDirection === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
                      )}
                    </button>
                  </th>
                  {(hasMultipleBranches || canViewAllBranches) && (
                    <th className="p-3 text-left text-xs font-medium">ფილიალი</th>
                  )}
                  {(userRole === 'admin' || userRole === 'hr_manager') && (
                    <th className="p-3 text-left">
                      <button 
                        onClick={() => handleSort('salary')}
                        className="flex items-center gap-1 hover:text-primary transition-colors text-xs font-medium"
                      >
                        ხელფასი
                        {sortField === 'salary' && (
                          sortDirection === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
                        )}
                      </button>
                    </th>
                  )}
                  <th className="p-3 text-left text-xs font-medium">სტატუსი</th>
                  <th className="p-3 text-left">
                    <button 
                      onClick={() => handleSort('hire_date')}
                      className="flex items-center gap-1 hover:text-primary transition-colors text-xs font-medium"
                    >
                      დაქირავების თარიღი
                      {sortField === 'hire_date' && (
                        sortDirection === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
                      )}
                    </button>
                  </th>
                  {canManageEmployees && <th className="p-3 text-right text-xs font-medium">მოქმედებები</th>}
                </tr>
              </thead>
              <tbody>
                {pagedEmployees.map((employee, index) => (
                  <tr key={employee.id} className={`border-b hover:bg-muted/30 transition-colors ${selectedEmployees.includes(employee.id) ? 'bg-primary/5' : ''}`}>
                    {canManageEmployees && (
                      <td className="p-3">
                        <div 
                          className="flex items-center cursor-pointer"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleEmployeeSelection(employee.id);
                          }}
                        >
                          {selectedEmployees.includes(employee.id) ? (
                            <CheckSquare className="h-4 w-4 text-primary" />
                          ) : (
                            <Square className="h-4 w-4 text-muted-foreground" />
                          )}
                        </div>
                      </td>
                    )}
                    <td className="p-3 text-xs text-muted-foreground font-medium">{index + 1}</td>
                    <td className="min-w-[280px] p-3">
                      <div 
                        className="flex items-center gap-2 cursor-pointer"
                        onClick={() => navigate(`/employees/${employee.id}`)}
                      >
                        <Avatar className="h-8 w-8 shrink-0">
                          <AvatarImage src={employee.avatar_url || ''} alt={employee.full_name} />
                          <AvatarFallback className="text-xs">
                            {employee.full_name.split(" ").map((n) => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="whitespace-nowrap text-sm font-medium">{employee.full_name}</p>
                          <p className="whitespace-nowrap text-xs text-muted-foreground">{employee.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-3 text-sm">{employee.personal_id_number || '-'}</td>
                    <td className="p-3 text-sm">{employee.position}</td>
                    <td className="p-3 text-sm">{employee.department || '-'}</td>
                    {(hasMultipleBranches || canViewAllBranches) && (
                      <td className="p-3 text-sm">
                        {branches.find((b) => b.id === (employee as any).branch_id)?.name || '-'}
                      </td>
                    )}
                    {(userRole === 'admin' || userRole === 'hr_manager') && (
                      <td className="p-3 text-sm">{employee.salary ? `₾${employee.salary.toLocaleString()}` : '-'}</td>
                    )}
                    <td className="p-3">
                      <span className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-medium ${
                        employee.status === 'active' 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {employee.status === 'active' ? 'აქტიური' : 'არააქტიური'}
                      </span>
                    </td>
                    <td className="p-3 text-xs text-muted-foreground">
                      {employee.hire_date ? new Date(employee.hire_date).toLocaleDateString('ka-GE') : '-'}
                    </td>
                    {canManageEmployees && (
                      <td className="p-3">
                        <div className="flex justify-end gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 w-7 p-0"
                            onClick={async (e) => {
                              e.stopPropagation();
                              const full = await fetchFullEmployee(employee.id);
                              setEditingEmployee({ ...employee, ...(full || {}) } as Employee);
                              setIsDialogOpen(true);
                            }}
                            title="რედაქტირება"
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 w-7 p-0"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleResetPassword(employee);
                            }}
                            disabled={isLoading}
                            title="პაროლის აღდგენა"
                          >
                            <RefreshCw className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            className="h-7 w-7 p-0"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDelete(employee.id);
                            }}
                            title="წაშლა"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredEmployees.length === 0 && (
            <div className="flex h-64 items-center justify-center text-muted-foreground">
              თანამშრომლები არ მოიძებნა
            </div>
          )}
        </Card>
      )}
      <PaginationControls />

      {/* Password Reset Dialog */}
      <AlertDialog open={resetPasswordDialogOpen} onOpenChange={setResetPasswordDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>პაროლი წარმატებით განახლდა!</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-4 pt-4">
                <p className="text-sm text-muted-foreground">
                  SMS შეტყობინება გაიგზავნა მითითებულ ნომერზე
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-muted rounded-md">
                    <div>
                      <Label className="text-xs text-muted-foreground">მომხმარებელი</Label>
                      <p className="font-mono text-sm">{resetPasswordData?.email}</p>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        if (resetPasswordData?.email) {
                          navigator.clipboard.writeText(resetPasswordData.email);
                          toast.success('დაკოპირდა!');
                        }
                      }}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-muted rounded-md">
                    <div className="flex-1">
                      <Label className="text-xs text-muted-foreground">ახალი პაროლი</Label>
                      <p className="font-mono text-sm">
                        {showPassword ? resetPasswordData?.password : '••••••••••'}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          if (resetPasswordData?.password) {
                            navigator.clipboard.writeText(resetPasswordData.password);
                            toast.success('პაროლი დაკოპირდა!');
                          }
                        }}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => {
              setResetPasswordDialogOpen(false);
              setResetPasswordData(null);
              setShowPassword(false);
            }}>
              დახურვა
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AddPositionDialog
        open={addPositionOpen}
        onOpenChange={setAddPositionOpen}
        departments={departments}
        onSuccess={() => {
          fetchPositions();
          toast.success('პოზიცია წარმატებით დაემატა');
        }}
      />
      </div>
    </div>
    </PageTransition>
  );
}
