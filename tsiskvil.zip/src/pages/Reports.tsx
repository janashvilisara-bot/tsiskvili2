import { useState, useEffect } from "react";
import { useFeatureLock, FeatureLockOverlay } from "@/components/FeatureCardLock";
import { 
  FileText, 
  Clock, 
  Users, 
  TrendingUp, 
  Calendar, 
  ArrowRight,
  BarChart3,
  DollarSign,
  FileDown,
  Shield,
  LogOut,
  MessageSquare,
  Award,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  PieChart,
  Database,
  Building2,
  Hotel,
  Scale,
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { exportFinancialGuideToWord } from "@/lib/exportFinancialGuideToWord";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

interface ReportStats {
  totalReports: number;
  monthlyReports: number;
  pendingReviews: number;
  generatedToday: number;
}

export default function Reports() {
  const navigate = useNavigate();
  const { isLocked, handleLockedClick } = useFeatureLock();
  const [stats, setStats] = useState<ReportStats>({
    totalReports: 10,
    monthlyReports: 45,
    pendingReviews: 3,
    generatedToday: 12
  });
  const [loading, setLoading] = useState(false);

  const quickStats = [
    {
      title: "სულ ანგარიშები",
      value: "10",
      icon: FileText,
      color: "from-violet-500 to-purple-600",
      bgColor: "bg-violet-500/10",
      trend: "ხელმისაწვდომი",
      trendUp: true,
      description: "ტიპი"
    },
    {
      title: "თვიური გენერაცია",
      value: stats.monthlyReports.toString(),
      icon: BarChart3,
      color: "from-blue-500 to-indigo-600",
      bgColor: "bg-blue-500/10",
      trend: "+18%",
      trendUp: true,
      description: "ანგარიში"
    },
    {
      title: "განსახილველი",
      value: stats.pendingReviews.toString(),
      icon: Clock,
      color: "from-orange-500 to-amber-600",
      bgColor: "bg-orange-500/10",
      trend: stats.pendingReviews > 0 ? "მომლოდინე" : "დასრულებული",
      trendUp: stats.pendingReviews === 0,
      description: "ანგარიში"
    },
    {
      title: "დღეს გენერირებული",
      value: stats.generatedToday.toString(),
      icon: TrendingUp,
      color: "from-emerald-500 to-green-600",
      bgColor: "bg-emerald-500/10",
      trend: "+5",
      trendUp: true,
      description: "ანგარიში"
    }
  ];

  const reportSections = [
    {
      title: "ფინანსური ანგარიშები",
      description: "ხელფასები, ბიუჯეტები და ფინანსური ანალიზი",
      icon: DollarSign,
      color: "from-violet-400 via-purple-500 to-fuchsia-500",
      shadowColor: "shadow-purple-500/25",
      reports: [
        { 
          name: "ფინანსური ანგარიშები", 
          description: "სრული ფინანსური ანგარიშების სისტემა",
          url: "/financial-reports",
          icon: BarChart3,
          stats: "დეტალური"
        },
        { 
          name: "სამუშაო დროის ანგარიში", 
          description: "სრული სამუშაო დროის ანალიზი, რეგულარული და ღამის საათები",
          url: "/work-time-report",
          icon: Clock,
          stats: "ყოველთვიური"
        },
        { 
          name: "დაგეგმილი vs რეალური", 
          description: "დაგეგმილი და რეალური დასწრების შედარება",
          url: "/ideal-attendance-report",
          icon: Calendar,
          stats: "შედარებითი"
        },
        { 
          name: "დასწრება გრაფიკის გარეშე", 
          description: "დღეები, როცა თანამშრომელს ფიქსირდება დასწრება, მაგრამ გრაფიკი არ აქვს",
          url: "/unscheduled-attendance-report",
          icon: Calendar,
          stats: "ანომალია"
        },
        { 
          name: "ზეგანაკვეთურის ანგარიში", 
          description: "ზეგანაკვეთური საათების დეტალური ანგარიში და ხარჯები",
          url: "/overtime-reports",
          icon: TrendingUp,
          stats: "ხარჯები"
        },
        { 
          name: "Chill Out ანგარიში", 
          description: "დასვენების დროის მონიტორინგი",
          url: "/chill-out-report",
          icon: Award,
          stats: "დასვენება"
        },
        { 
          name: "შვებულებების სტატისტიკა", 
          description: "შვებულებების ბალანსი და ხარჯვა დეპარტამენტების მიხედვით",
          url: "/leave-statistics",
          icon: PieChart,
          stats: "სტატისტიკა"
        },
      ]
    },
    {
      title: "შრომის ინსპექცია",
      description: "შრომის კოდექსთან შესაბამისობა და lms.gov.ge რეპორტინგი",
      icon: Shield,
      color: "from-red-400 via-rose-500 to-orange-500",
      shadowColor: "shadow-red-500/25",
      reports: [
        {
          name: "შრომის ინსპექციის ანგარიში",
          description: "სამუშაო საათები, შვებულებები, ზეგანაკვეთური - lms.gov.ge ფორმატში Excel/PDF",
          url: "/labor-inspection-report",
          icon: Shield,
          stats: "შესაბამისობა"
        },
        {
          name: "შესაბამისობის დაშბორდი",
          description: "რეალურ დროში მონიტორინგი: 40-საათიანი კვირა, შვებულებები, საპენსიო შენატანები",
          url: "/compliance-dashboard",
          icon: Shield,
          stats: "მონიტორინგი"
        },
      ]
    },
    {
      title: "სხვა ანგარიშები",
      description: "დოკუმენტები, კომუნიკაცია და სისტემის აქტივობა",
      icon: Users,
      color: "from-blue-400 via-blue-500 to-indigo-500",
      shadowColor: "shadow-blue-500/25",
      reports: [
        { 
          name: "დოკუმენტების ანგარიში", 
          description: "დოკუმენტების სტატუსი და ხელმოწერები",
          url: "/document-reports",
          icon: FileText,
          stats: "დოკუმენტები"
        },
        { 
          name: "SMS ანგარიში", 
          description: "გაგზავნილი SMS შეტყობინებების ისტორია",
          url: "/sms-reports",
          icon: MessageSquare,
          stats: "შეტყობინებები"
        },
        { 
          name: "ავტორიზაციების ანგარიში", 
          description: "სისტემაში შესვლის ანგარიში და უსაფრთხოება",
          url: "/authorization-report",
          icon: Shield,
          stats: "უსაფრთხოება"
        },
        { 
          name: "ავტო გასვლების ანგარიში", 
          description: "ავტომატური გასვლების ჩანაწერები",
          url: "/auto-logout-report",
          icon: LogOut,
          stats: "სესიები"
        },
        { 
          name: "დასწრება გრაფიკის გარეშე", 
          description: "თანამშრომლების შემოსვლა/გასვლა, რომელთაც სამუშაო გრაფიკი არ აქვთ გაწერილი",
          url: "/attendance-without-schedule",
          icon: Clock,
          stats: "მონიტორინგი"
        },
      ]
    },
    {
      title: "Report Builder",
      description: "შექმენით მორგებული ანგარიშები ნებისმიერი მონაცემებიდან",
      icon: Database,
      color: "from-indigo-400 via-purple-500 to-pink-500",
      shadowColor: "shadow-indigo-500/25",
      reports: [
        {
          name: "Report Builder",
          description: "ვიზუალური ანგარიშების აგება - აირჩიეთ ცხრილი, სვეტები, ფილტრები და ჩარტის ტიპი",
          url: "/report-builder",
          icon: Database,
          stats: "მორგებული"
        },
      ]
    },
    {
      title: "პერსონალის მოძრაობა",
      description: "დანიშვნა, გათავისუფლება და ფილიალების სტატისტიკა",
      icon: Building2,
      color: "from-emerald-400 via-teal-500 to-cyan-500",
      shadowColor: "shadow-emerald-500/25",
      reports: [
        { 
          name: "დანიშვნა / გათავისუფლება ფილიალების მიხედვით", 
          description: "კადრების მოძრაობის სტატისტიკა ფილიალების მიხედვით - დანიშნული, გათავისუფლებული, ტარნოვერი",
          url: "/branch-hiring-stats",
          icon: Building2,
          stats: "სტატისტიკა"
        },
        { 
          name: "გაცემული ბენეფიტები / სერვისები", 
          description: "ყველა გაცემული ბენეფიტი, სერვისი და ტექნიკა თანამშრომლების მიხედვით",
          url: "/granted-benefits",
          icon: Award,
          stats: "მონიტორინგი"
        },
      ]
    },
    {
      title: "მოგზაურობა და ანაზღაურება",
      description: "მივლინების ხარჯები და ბაზრის შედარება",
      icon: Hotel,
      color: "from-sky-400 via-blue-500 to-indigo-500",
      shadowColor: "shadow-blue-500/25",
      reports: [
        {
          name: "მოგზაურობის ცენტრი",
          description: "სასტუმროების ჯავშნები, სადღეღამისო და მივლინების ხარჯების ერთიანი ციკლი",
          url: "/travel-desk",
          icon: Hotel,
          stats: "ჯავშნები"
        },
        {
          name: "ხელფასების ბენჩმარკინგი",
          description: "ბაზრის პერცენტილები, retention რისკები და ბიუჯეტის სიმულატორი",
          url: "/salary-benchmarking",
          icon: Scale,
          stats: "ანალიტიკა"
        },
      ]
    },
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 animate-fade-in">
            <div className="flex items-center gap-3 sm:gap-4 min-w-0">
              <div className="p-3 sm:p-4 shrink-0 rounded-2xl bg-gradient-to-br from-violet-400 via-purple-500 to-fuchsia-500 shadow-xl shadow-purple-500/30 animate-scale-in">
                <BarChart3 className="h-7 w-7 sm:h-10 sm:w-10 text-white" />
              </div>
              <div className="min-w-0">
                <h1 className="text-2xl sm:text-4xl md:text-5xl break-words font-bold bg-gradient-to-r from-foreground via-foreground/90 to-foreground/70 bg-clip-text text-transparent">
                  ანგარიშების ცენტრი
                </h1>
                <p className="text-muted-foreground mt-1 text-sm sm:text-lg">
                  დეტალური ანალიზი და სტატისტიკა ყველა მიმართულებით
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button 
                onClick={() => navigate('/report-builder')}
                className="gap-2 shadow-lg bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700"
                size="lg"
              >
                <Database className="h-5 w-5" />
                Report Builder
              </Button>
              <Button 
                onClick={() => {
                  exportFinancialGuideToWord();
                  toast.success("Word დოკუმენტი გენერირდება...");
                }}
                className="gap-2 shadow-lg bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
                size="lg"
              >
                <FileDown className="h-5 w-5" />
                ფინანსური გზამკვლევი
              </Button>
            </div>
          </div>

          {/* Quick Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {quickStats.map((stat, index) => (
              <Card 
                key={index}
                className={cn(
                  "group relative overflow-hidden border-border/50 bg-card/80 backdrop-blur-xl",
                  "hover:shadow-2xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-2",
                  "animate-fade-in"
                )}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <CardContent className="p-6 relative">
                  <div className="flex items-start justify-between mb-4">
                    <div className={cn(
                      "p-3 rounded-xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-3",
                      stat.bgColor
                    )}>
                      <stat.icon className={cn(
                        "h-6 w-6"
                      )} style={{ color: `hsl(var(--primary))` }} />
                    </div>
                    
                    <div className={cn(
                      "flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full transition-all duration-300",
                      stat.trendUp 
                        ? "text-emerald-600 bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-400" 
                        : "text-amber-600 bg-amber-100 dark:bg-amber-950/50 dark:text-amber-400"
                    )}>
                      {stat.trendUp ? (
                        <ArrowUpRight className="h-3 w-3" />
                      ) : (
                        <ArrowDownRight className="h-3 w-3" />
                      )}
                      <span>{stat.trend}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-2xl md:text-3xl font-bold tracking-tight group-hover:scale-105 transition-transform duration-300 origin-left">
                      {stat.value}
                    </div>
                    <div className="text-sm text-muted-foreground font-medium">
                      {stat.title}
                    </div>
                    <div className="text-xs text-muted-foreground/70">
                      {stat.description}
                    </div>
                  </div>

                  <div className={cn(
                    "absolute -right-8 -bottom-8 w-32 h-32 rounded-full blur-3xl opacity-0 group-hover:opacity-30 transition-opacity duration-500",
                    `bg-gradient-to-br ${stat.color}`
                  )} />
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Report Sections */}
          <div className="space-y-10">
            {reportSections.map((section, sectionIdx) => (
              <div 
                key={sectionIdx} 
                className="space-y-6 animate-fade-in"
                style={{ animationDelay: `${(sectionIdx + 4) * 100}ms` }}
              >
                {/* Section Header */}
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "p-3 rounded-xl bg-gradient-to-br shadow-xl",
                    section.color,
                    section.shadowColor
                  )}>
                    <section.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl md:text-3xl font-bold text-foreground">{section.title}</h2>
                    <p className="text-sm text-muted-foreground">{section.description}</p>
                  </div>
                </div>

                {/* Report Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                  {section.reports.map((report, reportIdx) => (
                    <Card
                      key={reportIdx}
                      className={cn(
                        "group cursor-pointer overflow-hidden",
                        "border-border/50 bg-card/80 backdrop-blur-xl",
                        "hover:border-primary/50 transition-all duration-500",
                        "hover:shadow-2xl hover:-translate-y-2",
                        "animate-fade-in"
                      )}
                      style={{ animationDelay: `${(sectionIdx * 6 + reportIdx + 5) * 50}ms` }}
                      onClick={(e) => isLocked(report.url) ? handleLockedClick(e) : navigate(report.url)}
                    >
                      {isLocked(report.url) && <FeatureLockOverlay />}
                      <CardHeader className={cn(
                        "bg-gradient-to-br text-white pb-4 relative overflow-hidden",
                        section.color
                      )}>
                        <div className="flex items-center gap-3 relative z-10">
                          <div className="p-2.5 bg-white/20 rounded-xl backdrop-blur-sm group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                            <report.icon className="h-5 w-5" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{report.name}</CardTitle>
                            <span className="text-xs text-white/80">{report.stats}</span>
                          </div>
                        </div>
                        
                        <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700" />
                        <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white/5 rounded-full group-hover:scale-125 transition-transform duration-500" />
                      </CardHeader>
                      
                      <CardContent className="pt-6 relative">
                        <CardDescription className="text-muted-foreground mb-4 min-h-[48px] leading-relaxed">
                          {report.description}
                        </CardDescription>
                        
                        <div className="flex items-center gap-2 text-primary font-semibold text-sm group-hover:gap-4 transition-all duration-300">
                          <span>ნახვა</span>
                          <ArrowRight className="h-4 w-4 group-hover:translate-x-2 transition-transform duration-300" />
                        </div>

                        <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Enhanced Footer Stats */}
          <div 
            className="mt-12 p-6 md:p-8 rounded-2xl bg-gradient-to-r from-primary/5 via-primary/10 to-accent/10 border border-primary/20 backdrop-blur-xl animate-fade-in"
            style={{ animationDelay: '800ms' }}
          >
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-primary/10 animate-pulse">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-lg font-semibold text-foreground">
                    სულ <span className="text-2xl font-bold text-primary">{reportSections.reduce((acc, section) => acc + section.reports.length, 0)}</span> ანგარიში ხელმისაწვდომია
                  </p>
                  <p className="text-sm text-muted-foreground">
                    თქვენი ანალიზისა და მონიტორინგისთვის
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-violet-500/10 text-violet-600 dark:text-violet-400">
                  <BarChart3 className="h-4 w-4" />
                  <span className="text-sm font-medium">რეალ-ტაიმ მონაცემები</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
