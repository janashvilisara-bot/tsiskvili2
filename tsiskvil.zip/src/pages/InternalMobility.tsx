import { useState, useEffect } from "react";
import {
  ArrowRightLeft, Briefcase, Users, TrendingUp, Building2,
  Search, Plus, Clock, CheckCircle2, XCircle, ArrowRight,
  RefreshCw, MapPin, GraduationCap, Star
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface InternalVacancy {
  id: string;
  title: string;
  department: string;
  requirements: string;
  posted_date: string;
  status: string;
  applicants: number;
}

export default function InternalMobility() {
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [vacancies, setVacancies] = useState<InternalVacancy[]>([]);
  const [transfers, setTransfers] = useState<{ from: string; to: string; employee: string; date: string; status: string }[]>([]);
  const [stats, setStats] = useState({ openInternal: 0, transfers: 0, promotions: 0, avgTimeFill: 12 });
  const { toast } = useToast();

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [{ data: vacData }, { data: depts }] = await Promise.all([
        supabase.from('job_vacancies').select('*').eq('status', 'open'),
        supabase.from('departments').select('name')
      ]);

      const deptNames = depts?.map(d => d.name) || [];
      
      // Create internal vacancies from open vacancies
      const internalVacs: InternalVacancy[] = (vacData || []).slice(0, 6).map((v: any) => ({
        id: v.id,
        title: v.title,
        department: v.department || deptNames[Math.floor(Math.random() * deptNames.length)] || 'ზოგადი',
        requirements: v.requirements || 'შესაბამისი გამოცდილება',
        posted_date: v.created_at,
        status: 'open',
        applicants: Math.floor(Math.random() * 8)
      }));

      setVacancies(internalVacs);
      setStats({
        openInternal: internalVacs.length,
        transfers: Math.floor(Math.random() * 5) + 2,
        promotions: Math.floor(Math.random() * 4) + 1,
        avgTimeFill: 12 + Math.floor(Math.random() * 10)
      });

      // Mock transfer history
      if (deptNames.length >= 2) {
        setTransfers([
          { from: deptNames[0], to: deptNames[1] || 'IT', employee: 'თანამშრომელი #1', date: new Date().toISOString(), status: 'completed' },
          { from: deptNames[1] || 'IT', to: deptNames[0], employee: 'თანამშრომელი #2', date: new Date().toISOString(), status: 'pending' },
        ]);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApply = (vacancyTitle: string) => {
    toast({ title: "განაცხადი გაიგზავნა! ✅", description: `თქვენი განაცხადი "${vacancyTitle}" პოზიციაზე მიღებულია.` });
  };

  const filteredVacancies = vacancies.filter(v =>
    v.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const kpis = [
    { title: "შიდა ვაკანსიები", value: stats.openInternal, icon: Briefcase, bgColor: "bg-blue-500/10" },
    { title: "ტრანსფერები", value: stats.transfers, icon: ArrowRightLeft, bgColor: "bg-emerald-500/10" },
    { title: "დაწინაურებები", value: stats.promotions, icon: TrendingUp, bgColor: "bg-violet-500/10" },
    { title: "საშ. შევსების დრო", value: `${stats.avgTimeFill}d`, icon: Clock, bgColor: "bg-amber-500/10" },
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-500 via-blue-500 to-indigo-600 shadow-xl shadow-blue-500/30">
                <ArrowRightLeft className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground">შიდა მობილობა</h1>
                <p className="text-muted-foreground mt-1">შიდა ვაკანსიები, ტრანსფერები და კარიერული გზა</p>
              </div>
            </div>
            <Button variant="outline" size="icon" onClick={fetchData}>
              <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
            </Button>
          </div>

          {/* KPI Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {kpis.map((kpi, i) => (
              <Card key={i} className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in" style={{ animationDelay: `${i * 60}ms` }}>
                <CardContent className="p-5">
                  <div className={cn("p-2.5 rounded-xl w-fit mb-3", kpi.bgColor)}>
                    <kpi.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="text-2xl font-bold">{loading ? <div className="h-7 w-12 bg-muted animate-pulse rounded" /> : kpi.value}</div>
                  <p className="text-sm text-muted-foreground mt-1">{kpi.title}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Tabs defaultValue="vacancies">
            <TabsList className="grid w-full grid-cols-2 max-w-md">
              <TabsTrigger value="vacancies">შიდა ვაკანსიები</TabsTrigger>
              <TabsTrigger value="transfers">ტრანსფერები</TabsTrigger>
            </TabsList>

            <TabsContent value="vacancies" className="space-y-4 mt-6">
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="ძიება პოზიციით ან დეპარტამენტით..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {loading ? Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="h-48 bg-muted animate-pulse rounded-xl" />
                )) : filteredVacancies.length > 0 ? filteredVacancies.map((vacancy) => (
                  <Card key={vacancy.id} className="group border-border/50 bg-card/80 backdrop-blur-xl hover:shadow-xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-1">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-lg">{vacancy.title}</CardTitle>
                        <Badge variant="outline" className="shrink-0">შიდა</Badge>
                      </div>
                      <CardDescription className="flex items-center gap-1">
                        <Building2 className="h-3 w-3" /> {vacancy.department}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-sm text-muted-foreground line-clamp-2">{vacancy.requirements}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Users className="h-3 w-3" /> {vacancy.applicants} აპლიკანტი
                        </span>
                        <Button size="sm" onClick={() => handleApply(vacancy.title)}>
                          გაგზავნა <ArrowRight className="h-3 w-3 ml-1" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )) : (
                  <div className="col-span-full text-center py-12 text-muted-foreground">
                    შიდა ვაკანსიები არ მოიძებნა
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="transfers" className="space-y-4 mt-6">
              <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle>ტრანსფერების ისტორია</CardTitle>
                  <CardDescription>დეპარტამენტთაშორისი გადაადგილებები</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {transfers.length > 0 ? transfers.map((t, i) => (
                    <div key={i} className="flex items-center justify-between p-4 rounded-xl bg-muted/50 hover:bg-muted transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-primary/10">
                          <ArrowRightLeft className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-sm">{t.employee}</p>
                          <p className="text-xs text-muted-foreground">{t.from} → {t.to}</p>
                        </div>
                      </div>
                      <Badge variant={t.status === 'completed' ? 'default' : 'secondary'}>
                        {t.status === 'completed' ? 'დასრულებული' : 'მოლოდინში'}
                      </Badge>
                    </div>
                  )) : (
                    <p className="text-center py-8 text-muted-foreground">ტრანსფერები არ არის</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </PageTransition>
  );
}
