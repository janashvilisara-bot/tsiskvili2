import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowLeftRight, Loader2, RefreshCw, FileText, TrendingUp } from "lucide-react";
import { PageTransition } from "@/components/PageTransition";

const CURRENCIES = ["GEL", "USD", "EUR", "GBP", "RUB", "TRY", "AZN", "UAH"];

type Settlement = {
  id: number;
  startDate: string;
  endDate: string;
  status: "ACTIVE" | "AWAITING_PAYMENT" | "PAID_BY_MERCHANT" | "FULLY_SETTLED";
};

type Order = {
  orderId: number;
  sourceCurrency: string;
  targetCurrency: string;
  buyRate: number;
  sellRate: number;
  amount: number;
  convertedAmount: number;
  createdAt: string;
};

const STATUS_LABEL: Record<Settlement["status"], string> = {
  ACTIVE: "აქტიური",
  AWAITING_PAYMENT: "გადახდის მოლოდინში",
  PAID_BY_MERCHANT: "მერჩანტმა გადაიხადა",
  FULLY_SETTLED: "სრულად დაფარული",
};

const STATUS_VARIANT: Record<Settlement["status"], "default" | "secondary" | "outline" | "destructive"> = {
  ACTIVE: "default",
  AWAITING_PAYMENT: "destructive",
  PAID_BY_MERCHANT: "secondary",
  FULLY_SETTLED: "outline",
};

async function callKursi(endpoint: string, params: Record<string, string | number | string[]> = {}, body?: any) {
  const usp = new URLSearchParams();
  usp.set("endpoint", endpoint);
  for (const [k, v] of Object.entries(params)) {
    if (Array.isArray(v)) v.forEach(x => usp.append(k, String(x)));
    else usp.append(k, String(v));
  }
  const { data, error } = await supabase.functions.invoke(`kursi-api?${usp.toString()}`, {
    method: "POST",
    body: body ?? {},
  });
  if (error) throw new Error(error.message);
  if (data?.error) throw new Error(data.error);
  return data;
}

export default function CurrencyExchange() {
  // Convert tab
  const [amount, setAmount] = useState<string>("100");
  const [src, setSrc] = useState("USD");
  const [tgt, setTgt] = useState("GEL");
  const [creating, setCreating] = useState(false);
  const [lastOrder, setLastOrder] = useState<any>(null);

  // Settlements tab
  const [settlements, setSettlements] = useState<Settlement[]>([]);
  const [loadingS, setLoadingS] = useState(false);
  const [selectedSettlement, setSelectedSettlement] = useState<number | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingO, setLoadingO] = useState(false);

  const refreshSettlements = async () => {
    setLoadingS(true);
    try {
      const d = await callKursi("get-settlements", {
        page: 0,
        size: 50,
        statuses: ["ACTIVE", "AWAITING_PAYMENT", "PAID_BY_MERCHANT", "FULLY_SETTLED"],
      });
      setSettlements(d?.content ?? []);
      if ((d?.content?.length ?? 0) > 0 && !selectedSettlement) {
        setSelectedSettlement(d.content[0].id);
      }
    } catch (e: any) {
      toast.error("settlement-ების ჩატვირთვა ვერ მოხერხდა: " + e.message);
    } finally {
      setLoadingS(false);
    }
  };

  const refreshOrders = async (sid: number) => {
    setLoadingO(true);
    try {
      const d = await callKursi("get-orders-by-settlement", {
        settlementId: sid,
        page: 0,
        size: 50,
      });
      setOrders(d?.content ?? []);
    } catch (e: any) {
      toast.error("ორდერების ჩატვირთვა ვერ მოხერხდა: " + e.message);
    } finally {
      setLoadingO(false);
    }
  };

  useEffect(() => { refreshSettlements(); }, []);
  useEffect(() => { if (selectedSettlement) refreshOrders(selectedSettlement); }, [selectedSettlement]);

  const createOrder = async () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return toast.error("არასწორი თანხა");
    if (src === tgt) return toast.error("ვალუტები განსხვავებული უნდა იყოს");
    setCreating(true);
    try {
      const d = await callKursi("create-order", {}, {
        amount: amt,
        sourceCurrency: src,
        targetCurrency: tgt,
      });
      setLastOrder(d);
      toast.success(`ორდერი #${d.orderId} შეიქმნა`);
      refreshSettlements();
    } catch (e: any) {
      toast.error("ორდერის შექმნა ვერ მოხერხდა: " + e.message);
    } finally {
      setCreating(false);
    }
  };

  const totals = useMemo(() => {
    const byTarget: Record<string, number> = {};
    orders.forEach(o => { byTarget[o.targetCurrency] = (byTarget[o.targetCurrency] || 0) + o.convertedAmount; });
    return byTarget;
  }, [orders]);

  return (
    <PageTransition>
      <div className="p-4 md:p-8 space-y-6 max-w-7xl mx-auto">
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg shadow-emerald-500/30">
            <ArrowLeftRight className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">ვალუტის კონვერტაცია</h1>
            <p className="text-muted-foreground">Kursi.ge Merchant API ინტეგრაცია - ორდერები და სეთლმენტები</p>
          </div>
        </div>

        <Tabs defaultValue="convert" className="space-y-4">
          <TabsList>
            <TabsTrigger value="convert" className="gap-2"><ArrowLeftRight className="h-4 w-4" /> კონვერტაცია</TabsTrigger>
            <TabsTrigger value="settlements" className="gap-2"><FileText className="h-4 w-4" /> სეთლმენტები</TabsTrigger>
            <TabsTrigger value="orders" className="gap-2"><TrendingUp className="h-4 w-4" /> ორდერები</TabsTrigger>
          </TabsList>

          <TabsContent value="convert">
            <Card>
              <CardHeader>
                <CardTitle>ახალი ორდერი</CardTitle>
                <CardDescription>შექმენით კონვერტაციის მოთხოვნა Kursi.ge-სთან</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="space-y-2">
                    <Label>თანხა</Label>
                    <Input type="number" min="0" step="0.01" value={amount} onChange={e => setAmount(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>გასაცვლელი ვალუტა</Label>
                    <Select value={src} onValueChange={setSrc}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{CURRENCIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>მისაღები ვალუტა</Label>
                    <Select value={tgt} onValueChange={setTgt}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{CURRENCIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-end">
                    <Button onClick={createOrder} disabled={creating} className="w-full gap-2">
                      {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowLeftRight className="h-4 w-4" />}
                      ორდერის შექმნა
                    </Button>
                  </div>
                </div>

                {lastOrder && (
                  <div className="p-4 rounded-xl border bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30">
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-sm">
                      <Info label="Order ID" value={`#${lastOrder.orderId}`} />
                      <Info label="Settlement" value={`#${lastOrder.settlementId}`} />
                      <Info label="კონვერტირებული" value={`${lastOrder.convertedAmount} ${tgt}`} />
                      <Info label="Buy rate" value={lastOrder.buyRate} />
                      <Info label="Sell rate" value={lastOrder.sellRate} />
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settlements">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>სეთლმენტები</CardTitle>
                  <CardDescription>ყველა გადახდის პერიოდი მერჩანტისთვის</CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={refreshSettlements} disabled={loadingS} className="gap-2">
                  <RefreshCw className={`h-4 w-4 ${loadingS ? "animate-spin" : ""}`} /> განახლება
                </Button>
              </CardHeader>
              <CardContent>
                {loadingS ? (
                  <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></div>
                ) : settlements.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">სეთლმენტები ვერ მოიძებნა</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>დაწყება</TableHead>
                        <TableHead>დასრულება</TableHead>
                        <TableHead>სტატუსი</TableHead>
                        <TableHead className="text-right">მოქმედება</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {settlements.map(s => (
                        <TableRow key={s.id}>
                          <TableCell className="font-medium">#{s.id}</TableCell>
                          <TableCell>{s.startDate}</TableCell>
                          <TableCell>{s.endDate}</TableCell>
                          <TableCell><Badge variant={STATUS_VARIANT[s.status]}>{STATUS_LABEL[s.status]}</Badge></TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm" onClick={() => setSelectedSettlement(s.id)}>ორდერების ნახვა</Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="orders">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>ორდერები {selectedSettlement ? `(Settlement #${selectedSettlement})` : ""}</CardTitle>
                  <CardDescription>
                    {Object.entries(totals).length > 0
                      ? `ჯამი: ${Object.entries(totals).map(([c, v]) => `${v.toFixed(2)} ${c}`).join(" · ")}`
                      : "აირჩიეთ სეთლმენტი ან შექმენით ახალი ორდერი"}
                  </CardDescription>
                </div>
                {selectedSettlement && (
                  <Button variant="outline" size="sm" onClick={() => refreshOrders(selectedSettlement)} disabled={loadingO} className="gap-2">
                    <RefreshCw className={`h-4 w-4 ${loadingO ? "animate-spin" : ""}`} /> განახლება
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                {!selectedSettlement ? (
                  <p className="text-muted-foreground text-center py-8">სეთლმენტი არ არის არჩეული</p>
                ) : loadingO ? (
                  <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></div>
                ) : orders.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">ორდერები ვერ მოიძებნა</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>თარიღი</TableHead>
                        <TableHead>დან</TableHead>
                        <TableHead>ში</TableHead>
                        <TableHead className="text-right">თანხა</TableHead>
                        <TableHead className="text-right">კონვერტ.</TableHead>
                        <TableHead className="text-right">Buy / Sell</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.map(o => (
                        <TableRow key={o.orderId}>
                          <TableCell className="font-medium">#{o.orderId}</TableCell>
                          <TableCell>{new Date(o.createdAt).toLocaleString("ka-GE")}</TableCell>
                          <TableCell>{o.sourceCurrency}</TableCell>
                          <TableCell>{o.targetCurrency}</TableCell>
                          <TableCell className="text-right">{o.amount.toFixed(2)}</TableCell>
                          <TableCell className="text-right font-medium">{o.convertedAmount.toFixed(2)}</TableCell>
                          <TableCell className="text-right text-xs text-muted-foreground">{o.buyRate} / {o.sellRate}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageTransition>
  );
}

function Info({ label, value }: { label: string; value: any }) {
  return (
    <div>
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="font-semibold">{value}</div>
    </div>
  );
}
