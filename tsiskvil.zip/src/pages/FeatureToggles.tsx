import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useFeatureAccess } from "@/hooks/useFeatureAccess";
import { toast } from "sonner";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, Search, Sparkles, Lock, ToggleRight } from "lucide-react";
import { Navigate } from "react-router-dom";

interface FeatureDef {
  id: string;
  feature_key: string;
  name: string;
  name_ka: string;
  category: string;
  sort_order: number;
}

interface CompanyFeatureRow {
  feature_key: string;
  is_enabled: boolean;
}

const CATEGORY_LABELS: Record<string, string> = {
  core: "ძირითადი",
  attendance: "დასწრება და გრაფიკი",
  leave: "შვებულებები",
  finance: "ფინანსები",
  recruitment: "რეკრუტმენტი",
  communication: "კომუნიკაცია",
  performance: "შესრულება",
  development: "განვითარება",
  analytics: "ანალიტიკა",
  advanced: "გაფართოებული",
};

export default function FeatureToggles() {
  const { userRole } = useAuth();
  const { refreshFeatures } = useFeatureAccess();
  const [features, setFeatures] = useState<FeatureDef[]>([]);
  const [companyId, setCompanyId] = useState<string | null>(null);
  const [enabledMap, setEnabledMap] = useState<Record<string, boolean>>({});
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      const { data: company } = await supabase
        .from("companies")
        .select("id")
        .eq("is_active", true)
        .limit(1)
        .maybeSingle();

      if (!company?.id) {
        toast.error("აქტიური კომპანია ვერ მოიძებნა");
        setLoading(false);
        return;
      }
      setCompanyId(company.id);

      const [defsRes, cfRes] = await Promise.all([
        supabase.from("feature_definitions").select("*").order("sort_order"),
        supabase.from("company_features").select("feature_key, is_enabled").eq("company_id", company.id),
      ]);

      const defs = (defsRes.data || []) as FeatureDef[];
      setFeatures(defs);

      const map: Record<string, boolean> = {};
      // default: if no row, treat as enabled
      defs.forEach((d) => (map[d.feature_key] = true));
      (cfRes.data as CompanyFeatureRow[] | null)?.forEach((row) => {
        map[row.feature_key] = row.is_enabled;
      });
      setEnabledMap(map);
    } catch (e) {
      console.error(e);
      toast.error("მონაცემების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const toggle = async (key: string, next: boolean) => {
    if (!companyId) return;
    setSaving(key);
    const prev = enabledMap[key];
    setEnabledMap((m) => ({ ...m, [key]: next }));
    try {
      const { error } = await supabase
        .from("company_features")
        .upsert(
          { company_id: companyId, feature_key: key, is_enabled: next },
          { onConflict: "company_id,feature_key" }
        );
      if (error) throw error;
      toast.success(next ? "ჩაირთო" : "გამოირთო");
      refreshFeatures();
    } catch (e: any) {
      setEnabledMap((m) => ({ ...m, [key]: prev }));
      toast.error("ცვლილება ვერ შეინახა");
    } finally {
      setSaving(null);
    }
  };

  const bulkSet = async (keys: string[], value: boolean) => {
    if (!companyId) return;
    setSaving("__bulk__");
    try {
      const rows = keys.map((k) => ({ company_id: companyId, feature_key: k, is_enabled: value }));
      const { error } = await supabase
        .from("company_features")
        .upsert(rows, { onConflict: "company_id,feature_key" });
      if (error) throw error;
      setEnabledMap((m) => {
        const copy = { ...m };
        keys.forEach((k) => (copy[k] = value));
        return copy;
      });
      toast.success(value ? "ყველა ჩაირთო" : "ყველა გამოირთო");
      refreshFeatures();
    } catch (e) {
      toast.error("ცვლილებები ვერ შეინახა");
    } finally {
      setSaving(null);
    }
  };

  const grouped = useMemo(() => {
    const q = search.trim().toLowerCase();
    const filtered = q
      ? features.filter(
          (f) =>
            f.name_ka.toLowerCase().includes(q) ||
            f.name.toLowerCase().includes(q) ||
            f.feature_key.toLowerCase().includes(q)
        )
      : features;
    const groups: Record<string, FeatureDef[]> = {};
    filtered.forEach((f) => {
      (groups[f.category] = groups[f.category] || []).push(f);
    });
    return groups;
  }, [features, search]);

  if (userRole !== "admin") {
    return <Navigate to="/" replace />;
  }

  const allKeys = features.map((f) => f.feature_key);

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 shadow-xl shadow-indigo-500/30">
              <ToggleRight className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">მენიუს მართვა</h1>
              <p className="text-muted-foreground mt-1">
                ჩართეთ ან გამორთეთ აპლიკაციის მოდულები - გაუჩინარდება როგორც გვერდიდან, ისე გვერდითა მენიუდან
              </p>
            </div>
          </div>

          {/* Controls */}
          <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
            <CardContent className="p-4 flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="მოდულის ძებნა..."
                  className="pl-9"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  disabled={saving === "__bulk__" || loading}
                  onClick={() => bulkSet(allKeys, true)}
                >
                  <Sparkles className="h-4 w-4 mr-1" /> ყველას ჩართვა
                </Button>
                <Button
                  variant="outline"
                  disabled={saving === "__bulk__" || loading}
                  onClick={() => bulkSet(allKeys, false)}
                >
                  <Lock className="h-4 w-4 mr-1" /> ყველას გამორთვა
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Groups */}
          {loading ? (
            <div className="text-center text-muted-foreground py-12">იტვირთება...</div>
          ) : (
            <div className="space-y-3">
              {Object.entries(grouped).map(([cat, items]) => {
                const enabledCount = items.filter((i) => enabledMap[i.feature_key]).length;
                return (
                  <Collapsible key={cat} defaultOpen>
                    <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                      <CollapsibleTrigger className="w-full">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0">
                          <div className="flex items-center gap-3">
                            <ChevronDown className="h-4 w-4 transition-transform data-[state=closed]:-rotate-90" />
                            <CardTitle className="text-base">
                              {CATEGORY_LABELS[cat] || cat}
                            </CardTitle>
                          </div>
                          <Badge variant="secondary">
                            {enabledCount} / {items.length} ჩართული
                          </Badge>
                        </CardHeader>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <CardContent className="pt-0 space-y-1">
                          {items.map((f) => {
                            const enabled = !!enabledMap[f.feature_key];
                            return (
                              <div
                                key={f.id}
                                className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-muted/50 transition-colors"
                              >
                                <div className="min-w-0">
                                  <div className="font-medium text-sm">{f.name_ka}</div>
                                  <div className="text-xs text-muted-foreground">{f.name}</div>
                                </div>
                                <Switch
                                  checked={enabled}
                                  disabled={saving === f.feature_key}
                                  onCheckedChange={(v) => toggle(f.feature_key, v)}
                                />
                              </div>
                            );
                          })}
                        </CardContent>
                      </CollapsibleContent>
                    </Card>
                  </Collapsible>
                );
              })}
              {Object.keys(grouped).length === 0 && (
                <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
                  <CardContent className="p-8 text-center text-muted-foreground">
                    შედეგი ვერ მოიძებნა
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </div>
      </div>
    </PageTransition>
  );
}
