import { useState, useEffect } from "react";
import { 
  TrendingUp, TrendingDown, Users, UserMinus, Clock, DollarSign, 
  Target, BarChart3, ArrowUpRight, ArrowDownRight, Percent,
  Calendar, Building2, RefreshCw
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

interface AnalyticsData {
  totalEmployees: number;
  newHires: number;
  terminations: number;
  turnoverRate: number;
  retentionRate: number;
  avgTenure: number;
  openPositions: number;
  avgTimeToHire: number;
  departmentStats: { name: string; count: number; turnover: number }[];
  branchStats: { name: string; hires: number; terminations: number; active: number }[];
}

export default function HRAnalytics() {
  const [data, setData] = useState<AnalyticsData>({
    totalEmployees: 0, newHires: 0, terminations: 0, turnoverRate: 0,
    retentionRate: 0, avgTenure: 0, openPositions: 0, avgTimeToHire: 0,
    departmentStats: [], branchStats: []
  });
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState("month");

  useEffect(() => { fetchAnalytics(); }, [period]);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const now = new Date();
      const periodStart = new Date();
      if (period === "month") periodStart.setMonth(now.getMonth() - 1);
      else if (period === "quarter") periodStart.setMonth(now.getMonth() - 3);
      else periodStart.setFullYear(now.getFullYear() - 1);

      const [
        { count: totalCount },
        { count: newHireCount },
        { count: terminatedCount },
        { count: openVacancies },
        { data: employees },
        { data: deptData }
      ] = await Promise.all([
        supabase.from('employees').select('*', { count: 'exact', head: true }).eq('status', 'active'),
        supabase.from('employees').select('*', { count: 'exact', head: true }).eq('status', 'active').gte('hire_date', periodStart.toISOString()),
        supabase.from('employees').select('*', { count: 'exact', head: true }).eq('status', 'terminated').gte('updated_at', periodStart.toISOString()),
        supabase.from('job_vacancies').select('*', { count: 'exact', head: true }).eq('status', 'open'),
        supabase.from('employees').select('hire_date, department, status, office_location_id, updated_at'),
        supabase.from('departments').select('name')
      ]);

      const total = totalCount || 0;
      const newHires = newHireCount || 0;
      const terminations = terminatedCount || 0;
      const turnoverRate = total > 0 ? (terminations / total) * 100 : 0;
      const retentionRate = 100 - turnoverRate;

      // Calculate avg tenure
      let avgTenure = 0;
      if (employees && employees.length > 0) {
        const tenures = employees
          .filter(e => e.hire_date && e.status === 'active')
          .map(e => {
            const hire = new Date(e.hire_date!);
            return (now.getTime() - hire.getTime()) / (1000 * 60 * 60 * 24 * 365);
          });
        avgTenure = tenures.length > 0 ? tenures.reduce((a, b) => a + b, 0) / tenures.length : 0;
      }

      // Department stats
      const deptStats: { name: string; count: number; turnover: number }[] = [];
      if (deptData) {
        for (const dept of deptData) {
          const deptEmployees = employees?.filter(e => e.department === dept.name) || [];
          const activeCount = deptEmployees.filter(e => e.status === 'active').length;
          const termCount = deptEmployees.filter(e => e.status === 'terminated').length;
          deptStats.push({
            name: dept.name,
            count: activeCount,
            turnover: activeCount > 0 ? (termCount / activeCount) * 100 : 0
          });
        }
      }

      // Branch stats by office_location_id
      const { data: offices } = await supabase.from('office_locations').select('id, name');
      const branchStats: { name: string; hires: number; terminations: number; active: number }[] = [];
      const officeMap = new Map((offices || []).map((o: any) => [o.id, o.name]));
      const branchGroups = new Map<string, { hires: number; terminations: number; active: number }>();
      (employees || []).forEach((e: any) => {
        const key = e.office_location_id || '__unassigned__';
        const cur = branchGroups.get(key) || { hires: 0, terminations: 0, active: 0 };
        if (e.status === 'active') cur.active += 1;
        if (e.hire_date && new Date(e.hire_date) >= periodStart) cur.hires += 1;
        if (e.status === 'terminated' && e.updated_at && new Date(e.updated_at) >= periodStart) cur.terminations += 1;
        branchGroups.set(key, cur);
      });
      branchGroups.forEach((v, k) => {
        branchStats.push({
          name: k === '__unassigned__' ? 'ფილიალის გარეშე' : (officeMap.get(k) as string) || 'უცნობი',
          ...v,
        });
      });
      branchStats.sort((a, b) => (b.hires + b.terminations) - (a.hires + a.terminations));

      setData({
        totalEmployees: total, newHires, terminations, turnoverRate,
        retentionRate, avgTenure, openPositions: openVacancies || 0,
        avgTimeToHire: 18, departmentStats: deptStats.sort((a, b) => b.count - a.count),
        branchStats
      });
    } catch (error) {
      console.error('Error fetching HR analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const kpis = [
    { title: "სულ თანამშრომლები", value: data.totalEmployees, icon: Users, color: "from-blue-500 to-indigo-600", bgColor: "bg-blue-500/10", suffix: "" },
    { title: "ახალი დაქირავებულები", value: data.newHires, icon: UserMinus, color: "from-emerald-500 to-green-600", bgColor: "bg-emerald-500/10", suffix: "", trend: "+", trendUp: true },
    { title: "გათავისუფლებულები", value: data.terminations, icon: UserMinus, color: "from-red-500 to-rose-600", bgColor: "bg-red-500/10", suffix: "", trend: "", trendUp: false },
    { title: "Turnover Rate", value: data.turnoverRate.toFixed(1), icon: TrendingDown, color: "from-amber-500 to-orange-600", bgColor: "bg-amber-500/10", suffix: "%", trend: "", trendUp: data.turnoverRate < 10 },
    { title: "Retention Rate", value: data.retentionRate.toFixed(1), icon: Target, color: "from-teal-500 to-cyan-600", bgColor: "bg-teal-500/10", suffix: "%", trend: "", trendUp: data.retentionRate > 90 },
    { title: "საშ. სტაჟი (წელი)", value: data.avgTenure.toFixed(1), icon: Calendar, color: "from-violet-500 to-purple-600", bgColor: "bg-violet-500/10", suffix: "", trend: "", trendUp: true },
    { title: "ღია პოზიციები", value: data.openPositions, icon: Target, color: "from-sky-500 to-blue-600", bgColor: "bg-sky-500/10", suffix: "" },
    { title: "საშ. Time-to-Hire", value: data.avgTimeToHire, icon: Clock, color: "from-pink-500 to-fuchsia-600", bgColor: "bg-pink-500/10", suffix: " დღე" },
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-violet-500 via-purple-500 to-indigo-600 shadow-xl shadow-purple-500/30">
                <BarChart3 className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground">HR ანალიტიკა</h1>
                <p className="text-muted-foreground mt-1">ადამიანური რესურსების ძირითადი მეტრიკები</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Select value={period} onValueChange={setPeriod}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="month">ბოლო თვე</SelectItem>
                  <SelectItem value="quarter">ბოლო კვარტალი</SelectItem>
                  <SelectItem value="year">ბოლო წელი</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon" onClick={fetchAnalytics}>
                <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
              </Button>
            </div>
          </div>

          {/* KPI Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {kpis.map((kpi, index) => (
              <Card key={index} className={cn(
                "group overflow-hidden border-border/50 bg-card/80 backdrop-blur-xl",
                "hover:shadow-xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-1",
                "animate-fade-in"
              )} style={{ animationDelay: `${index * 60}ms` }}>
                <CardContent className="p-5 relative">
                  <div className="flex items-start justify-between mb-3">
                    <div className={cn("p-2.5 rounded-xl", kpi.bgColor)}>
                      <kpi.icon className="h-5 w-5 text-primary" />
                    </div>
                    {kpi.trendUp !== undefined && (
                      <Badge variant="outline" className={cn(
                        "text-xs",
                        kpi.trendUp ? "text-emerald-600 border-emerald-200 bg-emerald-50 dark:bg-emerald-950/30" : "text-red-600 border-red-200 bg-red-50 dark:bg-red-950/30"
                      )}>
                        {kpi.trendUp ? <ArrowUpRight className="h-3 w-3 mr-1" /> : <ArrowDownRight className="h-3 w-3 mr-1" />}
                        {kpi.trendUp ? "კარგი" : "ყურადღება"}
                      </Badge>
                    )}
                  </div>
                  <div className="text-2xl font-bold tracking-tight">
                    {loading ? <div className="h-7 w-16 bg-muted animate-pulse rounded" /> : <>{kpi.value}{kpi.suffix}</>}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{kpi.title}</p>
                  <div className={cn("absolute -right-6 -bottom-6 w-24 h-24 rounded-full blur-3xl opacity-0 group-hover:opacity-20 transition-opacity", `bg-gradient-to-br ${kpi.color}`)} />
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Department Stats */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in" style={{ animationDelay: '500ms' }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  დეპარტამენტები თანამშრომლებით
                </CardTitle>
                <CardDescription>აქტიური თანამშრომლების განაწილება</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {loading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="h-10 bg-muted animate-pulse rounded" />
                  ))
                ) : data.departmentStats.length > 0 ? (
                  data.departmentStats.slice(0, 8).map((dept, i) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-muted/50 hover:bg-muted transition-colors">
                      <span className="font-medium text-sm">{dept.name}</span>
                      <div className="flex items-center gap-3">
                        <Badge variant="secondary">{dept.count} თანამშრომელი</Badge>
                        <div className="w-24 bg-muted rounded-full h-2">
                          <div 
                            className="h-2 rounded-full bg-gradient-to-r from-primary to-primary/70 transition-all duration-700"
                            style={{ width: `${Math.min((dept.count / (data.totalEmployees || 1)) * 100, 100)}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground text-center py-8">მონაცემები არ არის</p>
                )}
              </CardContent>
            </Card>

            <Card className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in" style={{ animationDelay: '600ms' }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Percent className="h-5 w-5 text-primary" />
                  Turnover დეპარტამენტებით
                </CardTitle>
                <CardDescription>გათავისუფლების მაჩვენებელი</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {loading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="h-10 bg-muted animate-pulse rounded" />
                  ))
                ) : data.departmentStats.length > 0 ? (
                  data.departmentStats
                    .filter(d => d.count > 0)
                    .sort((a, b) => b.turnover - a.turnover)
                    .slice(0, 8)
                    .map((dept, i) => (
                      <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-muted/50 hover:bg-muted transition-colors">
                        <span className="font-medium text-sm">{dept.name}</span>
                        <div className="flex items-center gap-3">
                          <Badge variant={dept.turnover > 15 ? "destructive" : dept.turnover > 8 ? "secondary" : "outline"}>
                            {dept.turnover.toFixed(1)}%
                          </Badge>
                          <div className="w-24 bg-muted rounded-full h-2">
                            <div 
                              className={cn(
                                "h-2 rounded-full transition-all duration-700",
                                dept.turnover > 15 ? "bg-red-500" : dept.turnover > 8 ? "bg-amber-500" : "bg-emerald-500"
                              )}
                              style={{ width: `${Math.min(dept.turnover * 2, 100)}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ))
                ) : (
                  <p className="text-muted-foreground text-center py-8">მონაცემები არ არის</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Branch hire/termination stats */}
          <Card className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in" style={{ animationDelay: '650ms' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-primary" />
                დაქირავება/გათავისუფლება ფილიალების მიხედვით
              </CardTitle>
              <CardDescription>სტატისტიკა მიმდინარე პერიოდისთვის</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="h-12 bg-muted animate-pulse rounded" />
                  ))}
                </div>
              ) : data.branchStats.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">მონაცემები არ არის</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border/50 text-left">
                        <th className="py-2 px-3 font-medium">ფილიალი</th>
                        <th className="py-2 px-3 font-medium text-center">აქტიური</th>
                        <th className="py-2 px-3 font-medium text-center text-emerald-600 dark:text-emerald-400">დაქირავება</th>
                        <th className="py-2 px-3 font-medium text-center text-red-600 dark:text-red-400">გათავისუფლება</th>
                        <th className="py-2 px-3 font-medium text-center">წმინდა ცვლილება</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.branchStats.map((b, i) => {
                        const net = b.hires - b.terminations;
                        return (
                          <tr key={i} className="border-b border-border/30 hover:bg-muted/30 transition-colors">
                            <td className="py-2 px-3 font-medium">{b.name}</td>
                            <td className="py-2 px-3 text-center">
                              <Badge variant="secondary">{b.active}</Badge>
                            </td>
                            <td className="py-2 px-3 text-center text-emerald-600 dark:text-emerald-400 font-semibold">+{b.hires}</td>
                            <td className="py-2 px-3 text-center text-red-600 dark:text-red-400 font-semibold">−{b.terminations}</td>
                            <td className="py-2 px-3 text-center">
                              <Badge variant={net >= 0 ? "outline" : "destructive"}>
                                {net >= 0 ? '+' : ''}{net}
                              </Badge>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>



          {/* Summary Card */}
          <Card className="border-primary/20 bg-gradient-to-r from-primary/5 via-primary/10 to-accent/10 backdrop-blur-xl animate-fade-in" style={{ animationDelay: '700ms' }}>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-xl bg-primary/10">
                    <TrendingUp className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-lg font-semibold">HR ანალიტიკის შეჯამება</p>
                    <p className="text-sm text-muted-foreground">
                      {data.retentionRate >= 90 
                        ? "✅ რეტენციის მაჩვენებელი კარგ დონეზეა" 
                        : "⚠️ რეტენციის მაჩვენებელი საჭიროებს ყურადღებას"
                      }
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Badge variant="outline" className="text-sm px-4 py-2">
                    Retention: {data.retentionRate.toFixed(1)}%
                  </Badge>
                  <Badge variant="outline" className="text-sm px-4 py-2">
                    Turnover: {data.turnoverRate.toFixed(1)}%
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageTransition>
  );
}
