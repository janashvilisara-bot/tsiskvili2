import { useState, useEffect } from "react";
import { 
  Heart, Brain, Smile, Frown, Meh, TrendingUp, TrendingDown,
  Activity, AlertTriangle, CheckCircle2, Users, BarChart3,
  Flame, Battery, BatteryLow, BatteryMedium, BatteryFull,
  RefreshCw, Send
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { markCheckedInToday } from "@/lib/dailyCheckin";
import { Lock } from "lucide-react";

interface WellnessMetrics {
  overallScore: number;
  stressLevel: number;
  burnoutRisk: number;
  workLifeBalance: number;
  teamMorale: number;
  totalResponses: number;
}

interface WellnessEntry {
  id: string;
  employee_name: string;
  mood: number;
  stress: number;
  notes: string;
  date: string;
}

export default function EmployeeWellness() {
  const [metrics, setMetrics] = useState<WellnessMetrics>({
    overallScore: 78, stressLevel: 35, burnoutRisk: 18,
    workLifeBalance: 72, teamMorale: 81, totalResponses: 0
  });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [myMood, setMyMood] = useState<number | null>(null);
  const [myStress, setMyStress] = useState<number | null>(null);
  const [myNotes, setMyNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchMetrics();
  }, []);

  const fetchMetrics = async () => {
    setLoading(true);
    try {
      // Get employee count for baseline metrics
      const { count } = await supabase
        .from('employees')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Get overtime data for burnout risk
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const { data: overtimeData } = await supabase
        .from('attendance')
        .select('overtime_hours')
        .gte('date', thirtyDaysAgo.toISOString().split('T')[0])
        .not('overtime_hours', 'is', null);

      const totalOvertime = overtimeData?.reduce((sum, r) => sum + (r.overtime_hours || 0), 0) || 0;
      const avgOvertime = overtimeData && overtimeData.length > 0 ? totalOvertime / overtimeData.length : 0;
      
      // Calculate burnout risk based on overtime
      const burnoutRisk = Math.min(Math.round(avgOvertime * 8), 100);
      const stressLevel = Math.min(Math.round(25 + avgOvertime * 5), 100);
      
      // Get leave usage for work-life balance indicator
      const { count: leaveCount } = await supabase
        .from('leave_requests')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'approved')
        .gte('start_date', thirtyDaysAgo.toISOString().split('T')[0]);

      const leaveRate = count && count > 0 ? ((leaveCount || 0) / count) * 100 : 0;
      const workLifeBalance = Math.max(Math.min(Math.round(60 + leaveRate * 2), 95), 40);

      setMetrics({
        overallScore: Math.round(100 - (burnoutRisk * 0.3 + stressLevel * 0.3 - workLifeBalance * 0.4 + 30)),
        stressLevel,
        burnoutRisk,
        workLifeBalance,
        teamMorale: Math.round(85 - burnoutRisk * 0.3),
        totalResponses: count || 0
      });
    } catch (error) {
      console.error('Error fetching wellness metrics:', error);
    } finally {
      setLoading(false);
    }
  };

  const submitMoodCheck = async () => {
    if (myMood === null) return;
    setSubmitting(true);
    try {
      const { error } = await supabase.from("wellness_checkins").insert({
        employee_id: null,
        is_anonymous: true,
        checkin_date: new Date().toISOString().split("T")[0],
        mood_rating: myMood,
        stress_level: myStress,
        notes: myNotes.trim() || null,
      });
      if (error) throw error;
      markCheckedInToday();
      toast({
        title: "მადლობა!",
        description: "თქვენი კეთილდღეობის შეფასება მიღებულია",
      });
      setMyMood(null);
      setMyStress(null);
      setMyNotes("");
    } catch (error) {
      console.error(error);
      toast({ title: "გაგზავნა ვერ მოხერხდა", description: "სცადეთ თავიდან", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  const getScoreColor = (score: number, inverted = false) => {
    const effective = inverted ? 100 - score : score;
    if (effective >= 70) return "text-emerald-600";
    if (effective >= 40) return "text-amber-600";
    return "text-red-600";
  };

  const getProgressColor = (score: number, inverted = false) => {
    const effective = inverted ? 100 - score : score;
    if (effective >= 70) return "bg-emerald-500";
    if (effective >= 40) return "bg-amber-500";
    return "bg-red-500";
  };

  const moodOptions = [
    { value: 5, icon: Smile, label: "შესანიშნავი", color: "text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-950/30" },
    { value: 4, icon: Smile, label: "კარგი", color: "text-teal-500 hover:bg-teal-50 dark:hover:bg-teal-950/30" },
    { value: 3, icon: Meh, label: "ნორმალური", color: "text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/30" },
    { value: 2, icon: Frown, label: "ცუდი", color: "text-orange-500 hover:bg-orange-50 dark:hover:bg-orange-950/30" },
    { value: 1, icon: Frown, label: "ძალიან ცუდი", color: "text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30" },
  ];

  const wellnessCards = [
    { title: "ზოგადი კეთილდღეობა", value: metrics.overallScore, icon: Heart, color: "from-rose-500 to-pink-600", bgColor: "bg-rose-500/10" },
    { title: "სტრესის დონე", value: metrics.stressLevel, icon: Brain, color: "from-amber-500 to-orange-600", bgColor: "bg-amber-500/10", inverted: true },
    { title: "Burnout რისკი", value: metrics.burnoutRisk, icon: Flame, color: "from-red-500 to-rose-600", bgColor: "bg-red-500/10", inverted: true },
    { title: "Work-Life Balance", value: metrics.workLifeBalance, icon: Activity, color: "from-teal-500 to-cyan-600", bgColor: "bg-teal-500/10" },
    { title: "გუნდის მორალი", value: metrics.teamMorale, icon: Users, color: "from-indigo-500 to-violet-600", bgColor: "bg-indigo-500/10" },
  ];

  const burnoutIndicators = [
    { label: "ზეგანაკვეთური სამუშაო", risk: metrics.burnoutRisk > 30 ? "high" : metrics.burnoutRisk > 15 ? "medium" : "low" },
    { label: "შვებულების გამოუყენებლობა", risk: metrics.workLifeBalance < 50 ? "high" : metrics.workLifeBalance < 70 ? "medium" : "low" },
    { label: "დაგვიანებული წასვლა", risk: metrics.stressLevel > 60 ? "high" : metrics.stressLevel > 35 ? "medium" : "low" },
    { label: "უქმე დღეებში მუშაობა", risk: metrics.burnoutRisk > 40 ? "high" : metrics.burnoutRisk > 20 ? "medium" : "low" },
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-rose-400 via-pink-500 to-fuchsia-500 shadow-xl shadow-pink-500/30">
                <Heart className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground">კეთილდღეობა</h1>
                <p className="text-muted-foreground mt-1">თანამშრომლების ჯანმრთელობა და კეთილდღეობა</p>
              </div>
            </div>
            <Button variant="outline" size="icon" onClick={fetchMetrics}>
              <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
            </Button>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3 max-w-md">
              <TabsTrigger value="overview">მიმოხილვა</TabsTrigger>
              <TabsTrigger value="burnout">Burnout</TabsTrigger>
              <TabsTrigger value="checkin">შეფასება</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6 mt-6">
              {/* Wellness Score Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                {wellnessCards.map((card, i) => (
                  <Card key={i} className={cn(
                    "group overflow-hidden border-border/50 bg-card/80 backdrop-blur-xl",
                    "hover:shadow-xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-1",
                    "animate-fade-in"
                  )} style={{ animationDelay: `${i * 80}ms` }}>
                    <CardContent className="p-5 relative">
                      <div className={cn("p-2.5 rounded-xl w-fit mb-3", card.bgColor)}>
                        <card.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div className={cn("text-3xl font-bold tracking-tight mb-1", getScoreColor(card.value, card.inverted))}>
                        {loading ? <div className="h-8 w-14 bg-muted animate-pulse rounded" /> : `${card.value}%`}
                      </div>
                      <p className="text-xs text-muted-foreground">{card.title}</p>
                      <div className="mt-3">
                        <div className="w-full bg-muted rounded-full h-1.5">
                          <div className={cn("h-1.5 rounded-full transition-all duration-1000", getProgressColor(card.value, card.inverted))}
                            style={{ width: `${card.value}%` }} />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Recommendations */}
              <Card className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in" style={{ animationDelay: '500ms' }}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-primary" />
                    რეკომენდაციები
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {metrics.burnoutRisk > 25 && (
                    <div className="flex items-start gap-3 p-4 rounded-xl bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900">
                      <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5 shrink-0" />
                      <div>
                        <p className="font-medium text-red-700 dark:text-red-400">ზეგანაკვეთური სამუშაოს შემცირება</p>
                        <p className="text-sm text-red-600/80 dark:text-red-400/80">თანამშრომლების burnout რისკი მაღალია. გადახედეთ დატვირთვას.</p>
                      </div>
                    </div>
                  )}
                  {metrics.workLifeBalance < 65 && (
                    <div className="flex items-start gap-3 p-4 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900">
                      <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 shrink-0" />
                      <div>
                        <p className="font-medium text-amber-700 dark:text-amber-400">შვებულების წახალისება</p>
                        <p className="text-sm text-amber-600/80 dark:text-amber-400/80">თანამშრომლები არასაკმარისად იყენებენ შვებულებას.</p>
                      </div>
                    </div>
                  )}
                  <div className="flex items-start gap-3 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900">
                    <CheckCircle2 className="h-5 w-5 text-emerald-500 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-medium text-emerald-700 dark:text-emerald-400">რეგულარული Check-in</p>
                      <p className="text-sm text-emerald-600/80 dark:text-emerald-400/80">ჩაატარეთ ყოველკვირეული კეთილდღეობის გამოკითხვა.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="burnout" className="space-y-6 mt-6">
              {/* Burnout Risk Dashboard */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Flame className="h-5 w-5 text-orange-500" />
                      Burnout ინდიკატორები
                    </CardTitle>
                    <CardDescription>რისკის ფაქტორების მონიტორინგი</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {burnoutIndicators.map((indicator, i) => (
                      <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-muted/50">
                        <span className="text-sm font-medium">{indicator.label}</span>
                        <Badge variant={indicator.risk === "high" ? "destructive" : indicator.risk === "medium" ? "secondary" : "outline"}>
                          {indicator.risk === "high" ? "მაღალი" : indicator.risk === "medium" ? "საშუალო" : "დაბალი"}
                        </Badge>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Battery className="h-5 w-5 text-primary" />
                      ენერგიის დონე
                    </CardTitle>
                    <CardDescription>გუნდის ენერგიის საერთო მაჩვენებელი</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col items-center py-6">
                      <div className="relative mb-6">
                        {metrics.overallScore >= 70 ? (
                          <BatteryFull className="h-24 w-24 text-emerald-500" />
                        ) : metrics.overallScore >= 40 ? (
                          <BatteryMedium className="h-24 w-24 text-amber-500" />
                        ) : (
                          <BatteryLow className="h-24 w-24 text-red-500" />
                        )}
                      </div>
                      <p className={cn("text-4xl font-bold", getScoreColor(metrics.overallScore))}>
                        {metrics.overallScore}%
                      </p>
                      <p className="text-muted-foreground mt-2">საერთო ენერგიის დონე</p>
                      <p className="text-xs text-muted-foreground/70 mt-1">
                        {metrics.overallScore >= 70 ? "გუნდი კარგ მდგომარეობაშია" : 
                         metrics.overallScore >= 40 ? "საჭიროა ყურადღება" : 
                         "კრიტიკული მდგომარეობა"}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="checkin" className="space-y-6 mt-6">
              {/* Mood Check-in */}
              <Card className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in max-w-2xl mx-auto">
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl">როგორ გრძნობ თავს დღეს?</CardTitle>
                  <CardDescription>თქვენი კეთილდღეობის ყოველდღიური შეფასება</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-start gap-2.5 rounded-xl border border-primary/30 bg-primary/10 p-3 text-sm">
                    <Lock className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                    <p className="font-medium">ეს გამოკითხვა სრულიად ანონიმურია. თქვენი სახელი და გვარი არავის უჩანს - არც HR-ს, არც ადმინისტრატორს.</p>
                  </div>
                  {/* Mood Selection */}
                  <div className="flex justify-center gap-3 flex-wrap">
                    {moodOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => setMyMood(option.value)}
                        className={cn(
                          "flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all duration-300",
                          myMood === option.value 
                            ? "border-primary bg-primary/5 scale-110 shadow-lg" 
                            : "border-transparent hover:border-border",
                          option.color
                        )}
                      >
                        <option.icon className="h-10 w-10" />
                        <span className="text-xs font-medium">{option.label}</span>
                      </button>
                    ))}
                  </div>

                  {/* Stress Level */}
                  <div className="space-y-3">
                    <p className="text-sm font-medium text-center">სტრესის დონე (1-5)</p>
                    <div className="flex justify-center gap-2">
                      {[1, 2, 3, 4, 5].map(level => (
                        <button
                          key={level}
                          onClick={() => setMyStress(level)}
                          className={cn(
                            "w-12 h-12 rounded-xl font-bold text-lg transition-all duration-200",
                            myStress === level
                              ? "bg-primary text-primary-foreground scale-110 shadow-lg"
                              : "bg-muted hover:bg-muted/80"
                          )}
                        >
                          {level}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Notes */}
                  <Textarea
                    value={myNotes}
                    onChange={(e) => setMyNotes(e.target.value)}
                    placeholder="დამატებითი კომენტარი (არასავალდებულო)..."
                    className="resize-none"
                    rows={3}
                  />

                  <Button 
                    onClick={submitMoodCheck} 
                    disabled={myMood === null || submitting}
                    className="w-full"
                    size="lg"
                  >
                    <Send className="h-4 w-4 mr-2" />
                    გაგზავნა
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </PageTransition>
  );
}
