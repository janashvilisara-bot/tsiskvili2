import { useState, useEffect } from "react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Clock, Users, Calendar, Download, AlertTriangle, CheckCircle, XCircle, MessageSquare, Send, Info } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { ka } from "date-fns/locale";
import { useAuth } from "@/contexts/AuthContext";
import { exportToExcel } from "@/lib/exportToExcel";
import AttendanceAnalyticsCharts from "@/components/attendance/AttendanceAnalyticsCharts";

interface AttendanceRecord {
  id: string;
  employee_id: string;
  date: string;
  check_in: string | null;
  check_out: string | null;
  break_duration: number | null;
  notes: string | null;
  lateness_comment: string | null;
  lateness_justified: boolean | null;
  justified_by: string | null;
  justified_at: string | null;
  justification_note: string | null;
  employee_name: string;
  employee_number: string;
  scheduled_start?: string;
  scheduled_end?: string;
  department?: string | null;
}

const AttendanceAnalytics = () => {
  const { user, userRole } = useAuth();
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [selectedEmployee, setSelectedEmployee] = useState("all");
  const [employees, setEmployees] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<"all" | "lateness" | "charts">("charts");
  const [stats, setStats] = useState({
    totalRecords: 0,
    totalEmployees: 0,
    avgCheckInTime: "",
    totalLateArrivals: 0,
    totalEarlyDepartures: 0,
  });
  const [justificationDialog, setJustificationDialog] = useState<{
    open: boolean;
    record: AttendanceRecord | null;
    action: 'excuse' | 'unexcuse' | null;
  }>({ open: false, record: null, action: null });
  const [justificationNote, setJustificationNote] = useState("");
  const [sendingSms, setSendingSms] = useState<string | null>(null);

  useEffect(() => {
    fetchEmployees();
    fetchAttendanceRecords();
  }, [startDate, endDate, selectedEmployee]);

  const fetchEmployees = async () => {
    try {
      const { data, error } = await supabase
        .from("employees")
        .select("id, full_name, employee_number")
        .eq("status", "active")
        .order("full_name");

      if (error) throw error;
      setEmployees(data || []);
    } catch (error: any) {
      toast.error("თანამშრომლების ჩატვირთვა ვერ მოხერხდა");
    }
  };

  const fetchAttendanceRecords = async () => {
    try {
      let query = supabase
        .from("attendance")
        .select(`
          *,
          employees!attendance_employee_id_fkey (
            full_name,
            employee_number,
            department,
            id
          )
        `)
        .order("date", { ascending: false })
        .order("check_in", { ascending: false });

      if (startDate) query = query.gte("date", startDate);
      if (endDate) query = query.lte("date", endDate);
      if (selectedEmployee !== "all") query = query.eq("employee_id", selectedEmployee);

      const { data, error } = await query;

      if (error) throw error;

      // Fetch work schedules for all employees
      const { data: schedules } = await supabase
        .from("work_schedules")
        .select("employee_id, schedule_type, start_time, end_time");

      const schedulesMap = new Map(
        schedules?.map(s => [s.employee_id, s]) || []
      );

      const formattedRecords = (data || []).map((record: any) => {
        const schedule = schedulesMap.get(record.employee_id);
        return {
          ...record,
          employee_name: record.employees?.full_name || "უცნობი",
          employee_number: record.employees?.employee_number || "-",
          department: record.employees?.department || null,
          scheduled_start: schedule?.start_time,
          scheduled_end: schedule?.end_time,
        };
      });

      setRecords(formattedRecords);
      calculateStats(formattedRecords);
    } catch (error: any) {
      toast.error("დასწრების ჩანაწერების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const calculateStats = (data: AttendanceRecord[]) => {
    const totalRecords = data.length;
    const uniqueEmployees = new Set(data.map(r => r.employee_id)).size;
    
    const checkIns = data.filter(r => r.check_in).map(r => r.check_in!);
    const avgCheckInTime = checkIns.length > 0
      ? calculateAverageTime(checkIns)
      : "-";

    // Calculate lateness and early departures
    let lateArrivals = 0;
    let earlyDepartures = 0;

    data.forEach(record => {
      if (record.check_in && record.scheduled_start) {
        const checkInTime = record.check_in.substring(0, 5);
        if (checkInTime > record.scheduled_start) {
          lateArrivals++;
        }
      }
      if (record.check_out && record.scheduled_end) {
        const checkOutTime = record.check_out.substring(0, 5);
        if (checkOutTime < record.scheduled_end) {
          earlyDepartures++;
        }
      }
    });

    setStats({
      totalRecords,
      totalEmployees: uniqueEmployees,
      avgCheckInTime,
      totalLateArrivals: lateArrivals,
      totalEarlyDepartures: earlyDepartures,
    });
  };

  const calculateAverageTime = (times: string[]): string => {
    const totalMinutes = times.reduce((sum, time) => {
      const [hours, minutes] = time.split(':').map(Number);
      return sum + hours * 60 + minutes;
    }, 0);
    
    const avgMinutes = Math.round(totalMinutes / times.length);
    const hours = Math.floor(avgMinutes / 60);
    const minutes = avgMinutes % 60;
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  };

  const isLate = (record: AttendanceRecord): boolean => {
    if (!record.check_in || !record.scheduled_start) return false;
    const checkInTime = record.check_in.substring(0, 5);
    return checkInTime > record.scheduled_start;
  };

  const isEarly = (record: AttendanceRecord): boolean => {
    if (!record.check_out || !record.scheduled_end) return false;
    const checkOutTime = record.check_out.substring(0, 5);
    return checkOutTime < record.scheduled_end;
  };

  const calculateLateness = (record: AttendanceRecord): string => {
    if (!record.check_in || !record.scheduled_start) return "-";
    const [checkInHours, checkInMinutes] = record.check_in.substring(0, 5).split(':').map(Number);
    const [schedHours, schedMinutes] = record.scheduled_start.split(':').map(Number);
    
    const checkInTotal = checkInHours * 60 + checkInMinutes;
    const schedTotal = schedHours * 60 + schedMinutes;
    const diff = checkInTotal - schedTotal;
    
    if (diff <= 0) return "-";
    
    const hours = Math.floor(diff / 60);
    const minutes = diff % 60;
    return hours > 0 ? `${hours}სთ ${minutes}წთ` : `${minutes}წთ`;
  };

  const calculateEarliness = (record: AttendanceRecord): string => {
    if (!record.check_out || !record.scheduled_end) return "-";
    const [checkOutHours, checkOutMinutes] = record.check_out.substring(0, 5).split(':').map(Number);
    const [schedHours, schedMinutes] = record.scheduled_end.split(':').map(Number);
    
    const checkOutTotal = checkOutHours * 60 + checkOutMinutes;
    const schedTotal = schedHours * 60 + schedMinutes;
    const diff = schedTotal - checkOutTotal;
    
    if (diff <= 0) return "-";
    
    const hours = Math.floor(diff / 60);
    const minutes = diff % 60;
    return hours > 0 ? `${hours}სთ ${minutes}წთ` : `${minutes}წთ`;
  };

  const filteredRecords = records.filter((record) => {
    const matchesSearch =
      record.employee_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.employee_number.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (activeTab === "lateness") {
      return matchesSearch && (isLate(record) || isEarly(record));
    }
    
    return matchesSearch;
  });

  const exportToExcelHandler = () => {
    const exportData = filteredRecords.map((record, index) => ({
      "№": index + 1,
      "თანამშრომელი": record.employee_name,
      "პირადი ნომერი": record.employee_number,
      "თარიღი": format(new Date(record.date), "dd/MM/yyyy", { locale: ka }),
      "დღე": format(new Date(record.date), "EEEE", { locale: ka }),
      "დაგეგმილი შემოსვლა": record.scheduled_start || "-",
      "ფაქტობრივი შემოსვლა": record.check_in || "-",
      "დაგვიანება": calculateLateness(record),
      "დაგეგმილი გასვლა": record.scheduled_end || "-",
      "ფაქტობრივი გასვლა": record.check_out || "-",
      "ადრე გასვლა": calculateEarliness(record),
      "შესვენება (წთ)": record.break_duration || 0,
      "კომენტარი": record.lateness_comment || "-",
    }));

    const fileName = activeTab === "lateness" 
      ? `დაგვიანების_რეპორტი_${format(new Date(), "yyyy-MM-dd")}`
      : `დასწრების_ანალიტიკა_${format(new Date(), "yyyy-MM-dd")}`;
    
    exportToExcel(exportData, fileName, "დასწრება");
    toast.success("Excel ფაილი ჩამოიტვირთა");
  };

  const formatTime = (time: string | null) => {
    if (!time) return "-";
    return time.substring(0, 5);
  };

  const getDayName = (dateStr: string) => {
    return format(new Date(dateStr), "EEEE", { locale: ka });
  };

  const handleJustify = async () => {
    if (!justificationDialog.record) return;

    try {
      const { error } = await supabase
        .from("attendance")
        .update({
          lateness_justified: justificationDialog.action === 'excuse',
          justified_by: user?.id,
          justified_at: new Date().toISOString(),
          justification_note: justificationNote || null,
        })
        .eq("id", justificationDialog.record.id);

      if (error) throw error;

      toast.success(
        justificationDialog.action === 'excuse' 
          ? "დაგვიანება საპატიოდ მიჩნეულია" 
          : "დაგვიანება არასაპატიოდ მიჩნეულია"
      );
      
      setJustificationDialog({ open: false, record: null, action: null });
      setJustificationNote("");
      fetchAttendanceRecords();
    } catch (error: any) {
      toast.error("შეცდომა: " + error.message);
    }
  };

  const sendLatenessSms = async (employeeId: string) => {
    setSendingSms(employeeId);
    try {
      // Get employee phone
      const { data: employee, error: empError } = await supabase
        .from("employees")
        .select("phone, full_name")
        .eq("id", employeeId)
        .single();

      if (empError) throw empError;

      if (!employee?.phone) {
        toast.error("თანამშრომელს ტელეფონის ნომერი არ აქვს მითითებული");
        return;
      }

      // Send SMS
      const { error: smsError } = await supabase.functions.invoke("send-cloudsms", {
        body: {
          to: employee.phone,
          message: "გთხოვთ დააფიქსირეთ თქვენი დაგვიანების მიზეზი",
        },
      });

      if (smsError) throw smsError;

      toast.success(`SMS გაეგზავნა ${employee.full_name}-ს`);
    } catch (error: any) {
      toast.error("SMS გაგზავნა ვერ მოხერხდა: " + error.message);
    } finally {
      setSendingSms(null);
    }
  };

  const canJustify = userRole === 'admin' || userRole === 'hr_manager';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">დასწრების ანალიტიკა</h1>
          <p className="text-muted-foreground">თანამშრომელთა დასწრების დეტალური ანალიზი</p>
        </div>
        <Button onClick={exportToExcelHandler}>
          <Download className="h-4 w-4 mr-2" />
          Excel ექსპორტი
        </Button>
      </div>

      <Card className="border-border/50 bg-muted/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-primary mt-0.5 shrink-0" />
            <div className="space-y-1 text-sm text-muted-foreground">
              <p className="font-medium text-foreground">რა არის წარმოდგენილი ამ გვერდზე?</p>
              <p>ეს გვერდი აანალიზებს თანამშრომლების დასწრების მონაცემებს არჩეული პერიოდისთვის:</p>
              <p><strong>სულ ჩანაწერი</strong> - დასწრების ჩანაწერების საერთო რაოდენობა</p>
              <p><strong>დაგვიანებები</strong> - გვიან შემოსვლის შემთხვევები</p>
              <p><strong>ადრე გასვლა</strong> - სამუშაო დროის დასრულებამდე გასვლის შემთხვევები</p>
              <p><strong>⏰ საშუალო საათები</strong> - ერთ დღეში ნამუშევარი საშუალო საათები</p>
              <p><strong>Excel ექსპორტი</strong> - ანალიტიკის მონაცემების ჩამოტვირთვა ცხრილის სახით</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-5">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">სულ ჩანაწერი</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalRecords}</div>
            <p className="text-xs text-muted-foreground">არჩეულ პერიოდში</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">დაგვიანებები</CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">{stats.totalLateArrivals}</div>
            <p className="text-xs text-muted-foreground">გვიანი შემოსვლა</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">ადრე გასვლა</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.totalEarlyDepartures}</div>
            <p className="text-xs text-muted-foreground">დროზე ადრე</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">თანამშრომლები</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalEmployees}</div>
            <p className="text-xs text-muted-foreground">უნიკალური</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">საშ. შემოსვლა</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgCheckInTime}</div>
            <p className="text-xs text-muted-foreground">საშუალოდ</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>ფილტრები</CardTitle>
          <CardDescription>მონაცემების გაფილტვრა</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <Label>თანამშრომელი</Label>
              <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                <SelectTrigger>
                  <SelectValue placeholder="ყველა" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა</SelectItem>
                  {employees.map((emp) => (
                    <SelectItem key={emp.id} value={emp.id}>
                      {emp.full_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>დაწყების თარიღი</Label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>დასრულების თარიღი</Label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>ძებნა</Label>
              <Input
                placeholder="თანამშრომლის სახელი..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Records Tables with Tabs */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "all" | "lateness" | "charts")} className="space-y-4">
        <TabsList className="grid w-full max-w-2xl grid-cols-3">
          <TabsTrigger value="charts">ანალიტიკა</TabsTrigger>
          <TabsTrigger value="all">ყველა ჩანაწერი</TabsTrigger>
          <TabsTrigger value="lateness">
            დაგვიანების რეპორტი
            {stats.totalLateArrivals + stats.totalEarlyDepartures > 0 && (
              <Badge variant="destructive" className="ml-2">
                {stats.totalLateArrivals + stats.totalEarlyDepartures}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="charts">
          <AttendanceAnalyticsCharts
            records={records}
            totalEmployees={employees.length}
            startDate={startDate}
            endDate={endDate}
          />
        </TabsContent>

        <TabsContent value="all">
          <Card>
            <CardHeader>
              <CardTitle>დასწრების ჩანაწერები</CardTitle>
              <CardDescription>
                ნაპოვნია {filteredRecords.length} ჩანაწერი
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">#</TableHead>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>პირადი №</TableHead>
                      <TableHead>თარიღი</TableHead>
                      <TableHead>დღე</TableHead>
                      <TableHead>შემოსვლა</TableHead>
                      <TableHead>გასვლა</TableHead>
                      <TableHead>შესვენება</TableHead>
                      <TableHead>კომენტარი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRecords.map((record, index) => (
                      <TableRow key={record.id}>
                        <TableCell className="text-muted-foreground">{index + 1}</TableCell>
                        <TableCell className="font-medium">{record.employee_name}</TableCell>
                        <TableCell>{record.employee_number}</TableCell>
                        <TableCell>{format(new Date(record.date), "dd/MM/yyyy", { locale: ka })}</TableCell>
                        <TableCell>{getDayName(record.date)}</TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={isLate(record) 
                              ? "bg-amber-50 text-amber-700 border-amber-200" 
                              : "bg-green-50 text-green-700 border-green-200"
                            }
                          >
                            {formatTime(record.check_in)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={isEarly(record)
                              ? "bg-orange-50 text-orange-700 border-orange-200"
                              : "bg-red-50 text-red-700 border-red-200"
                            }
                          >
                            {formatTime(record.check_out)}
                          </Badge>
                        </TableCell>
                        <TableCell>{record.break_duration || 0} წთ</TableCell>
                        <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate">
                          {record.notes || "-"}
                        </TableCell>
                      </TableRow>
                    ))}
                    {filteredRecords.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                          ჩანაწერები არ მოიძებნა
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="lateness">
          <Card>
            <CardHeader>
              <CardTitle>დაგვიანების რეპორტი</CardTitle>
              <CardDescription>
                ნაპოვნია {filteredRecords.length} ჩანაწერი (დაგვიანება ან ადრე გასვლა)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">#</TableHead>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>თარიღი</TableHead>
                      <TableHead>დღე</TableHead>
                      <TableHead>დაგეგმილი</TableHead>
                      <TableHead>ფაქტობრივი</TableHead>
                      <TableHead>დაგვიანება</TableHead>
                      <TableHead>დაგეგმილი</TableHead>
                      <TableHead>ფაქტობრივი</TableHead>
                      <TableHead>ადრე გასვლა</TableHead>
                      <TableHead>მიზეზი</TableHead>
                      <TableHead>სტატუსი</TableHead>
                      {canJustify && <TableHead>მოქმედება</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRecords.map((record, index) => (
                      <TableRow key={record.id}>
                        <TableCell className="text-muted-foreground">{index + 1}</TableCell>
                        <TableCell className="font-medium">{record.employee_name}</TableCell>
                        <TableCell>{format(new Date(record.date), "dd/MM/yyyy", { locale: ka })}</TableCell>
                        <TableCell>{getDayName(record.date)}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {record.scheduled_start || "-"}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={isLate(record) 
                              ? "bg-amber-50 text-amber-700 border-amber-200" 
                              : "bg-green-50 text-green-700 border-green-200"
                            }
                          >
                            {formatTime(record.check_in)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {isLate(record) ? (
                            <Badge variant="destructive" className="bg-amber-500">
                              {calculateLateness(record)}
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {record.scheduled_end || "-"}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={isEarly(record)
                              ? "bg-orange-50 text-orange-700 border-orange-200"
                              : "bg-red-50 text-red-700 border-red-200"
                            }
                          >
                            {formatTime(record.check_out)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {isEarly(record) ? (
                            <Badge variant="destructive" className="bg-orange-500">
                              {calculateEarliness(record)}
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell className="text-sm max-w-[200px]">
                          {record.lateness_comment || "-"}
                        </TableCell>
                        <TableCell>
                          {record.lateness_justified === null ? (
                            <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                              განუხილველი
                            </Badge>
                          ) : record.lateness_justified ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              საპატიო
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                              <XCircle className="h-3 w-3 mr-1" />
                              არასაპატიო
                            </Badge>
                          )}
                          {record.justification_note && (
                            <p className="text-xs text-muted-foreground mt-1 max-w-[150px] truncate">
                              {record.justification_note}
                            </p>
                          )}
                        </TableCell>
                        {canJustify && (
                          <TableCell>
                            <div className="flex gap-2 items-center">
                              {record.lateness_justified === null ? (
                                <>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="h-8 bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
                                    onClick={() => {
                                      setJustificationDialog({ open: true, record, action: 'excuse' });
                                      setJustificationNote("");
                                    }}
                                  >
                                    <CheckCircle className="h-3 w-3 mr-1" />
                                    საპატიო
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="h-8 bg-red-50 hover:bg-red-100 text-red-700 border-red-200"
                                    onClick={() => {
                                      setJustificationDialog({ open: true, record, action: 'unexcuse' });
                                      setJustificationNote("");
                                    }}
                                  >
                                    <XCircle className="h-3 w-3 mr-1" />
                                    არასაპატიო
                                  </Button>
                                </>
                              ) : (
                                <span className="text-muted-foreground text-sm">-</span>
                              )}
                              {isLate(record) && !record.lateness_comment && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-8 bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                                  onClick={() => sendLatenessSms(record.employee_id)}
                                  disabled={sendingSms === record.employee_id}
                                >
                                  {sendingSms === record.employee_id ? (
                                    <span className="animate-spin h-3 w-3 border-2 border-blue-700 border-t-transparent rounded-full mr-1" />
                                  ) : (
                                    <Send className="h-3 w-3 mr-1" />
                                  )}
                                  SMS
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        )}
                      </TableRow>
                    ))}
                    {filteredRecords.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={canJustify ? 14 : 13} className="text-center text-muted-foreground py-8">
                          დაგვიანების ან ადრე გასვლის ჩანაწერები არ მოიძებნა
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Justification Dialog */}
      <Dialog open={justificationDialog.open} onOpenChange={(open) => {
        if (!open) {
          setJustificationDialog({ open: false, record: null, action: null });
          setJustificationNote("");
        }
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {justificationDialog.action === 'excuse' ? 'საპატიო დაგვიანება' : 'არასაპატიო დაგვიანება'}
            </DialogTitle>
            <DialogDescription>
              თანამშრომელი: {justificationDialog.record?.employee_name}
              <br />
              თარიღი: {justificationDialog.record ? format(new Date(justificationDialog.record.date), "dd MMMM yyyy", { locale: ka }) : ""}
              <br />
              მიზეზი: {justificationDialog.record?.lateness_comment || "მითითებული არ არის"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>ხელმძღვანელის კომენტარი (არასავალდებულო)</Label>
            <Textarea
              placeholder="ჩაწერეთ დამატებითი კომენტარი..."
              value={justificationNote}
              onChange={(e) => setJustificationNote(e.target.value)}
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setJustificationDialog({ open: false, record: null, action: null });
              setJustificationNote("");
            }}>
              გაუქმება
            </Button>
            <Button 
              onClick={handleJustify}
              className={justificationDialog.action === 'excuse' 
                ? "bg-green-600 hover:bg-green-700" 
                : "bg-red-600 hover:bg-red-700"
              }
            >
              დადასტურება
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AttendanceAnalytics;
