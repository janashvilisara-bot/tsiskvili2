import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { Settings, Pencil, Plus, Search } from "lucide-react";
import { z } from "zod";

interface UIText {
  id: string;
  key: string;
  key_ka: string | null;
  ka_text: string;
  en_text: string | null;
  category: string;
  description: string | null;
}

export default function AdminPanel() {
  const { userRole } = useAuth();
  const [texts, setTexts] = useState<UIText[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingText, setEditingText] = useState<UIText | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchTexts();
  }, []);

  const fetchTexts = async () => {
    try {
      const { data, error } = await supabase
        .from('ui_texts')
        .select('*')
        .order('category', { ascending: true })
        .order('key', { ascending: true });

      if (error) throw error;
      setTexts(data || []);
    } catch (error: any) {
      toast.error('შეცდომა ტექსტების ჩატვირთვისას');
    }
  };

  const uiTextSchema = z.object({
    key: z.string().min(1, 'გასაღები სავალდებულოა').max(100).regex(/^[a-z_]+$/, 'გასაღები უნდა შეიცავდეს მხოლოდ პატარა ლათინურ ასოებს და ქვედა ხაზს'),
    key_ka: z.string().max(100).optional(),
    ka_text: z.string().min(1, 'ქართული ტექსტი სავალდებულოა').max(1000),
    en_text: z.string().max(1000).optional(),
    category: z.string().min(1, 'კატეგორია სავალდებულოა'),
    description: z.string().max(500).optional(),
  });

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const rawData = {
        key: formData.get('key') as string,
        key_ka: formData.get('key_ka') as string || undefined,
        ka_text: formData.get('ka_text') as string,
        en_text: formData.get('en_text') as string || undefined,
        category: formData.get('category') as string,
        description: formData.get('description') as string || undefined,
      };

      const result = uiTextSchema.safeParse(rawData);
      if (!result.success) {
        const errors = result.error.flatten().fieldErrors;
        toast.error(Object.values(errors).flat()[0] || 'შეცდომა ვალიდაციისას');
        return;
      }

      const payload = {
        ...result.data,
        key_ka: result.data.key_ka || null,
        en_text: result.data.en_text || null,
        description: result.data.description || null,
      };

      if (editingText) {
        const { error } = await supabase
          .from('ui_texts')
          .update(payload)
          .eq('id', editingText.id);

        if (error) throw error;
        toast.success('ტექსტი განახლდა');
      } else {
        const { error } = await supabase
          .from('ui_texts')
          .insert([payload as any]);

        if (error) throw error;
        toast.success('ტექსტი დაემატა');
      }

      setIsDialogOpen(false);
      setEditingText(null);
      fetchTexts();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const categories = Array.from(new Set(texts.map(t => t.category)));
  
  const filteredTexts = texts.filter(text => {
    const matchesSearch = text.key.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         text.ka_text.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || text.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  if (userRole !== 'admin') {
    return (
      <div className="p-8 text-center">
        <p className="text-muted-foreground">თქვენ არ გაქვთ წვდომა ამ გვერდზე</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Settings className="h-8 w-8" />
            ადმინ პანელი
          </h1>
          <p className="mt-2 text-muted-foreground">
            მართეთ ვებგვერდის ტექსტები და თარგმანები
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingText(null)}>
              <Plus className="h-4 w-4 mr-2" />
              ახალი ტექსტი
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingText ? 'ტექსტის რედაქტირება' : 'ახალი ტექსტის დამატება'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="key">გასაღები (ინგლისური) *</Label>
                  <Input
                    id="key"
                    name="key"
                    defaultValue={editingText?.key}
                    placeholder="e.g. employees.title"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="key_ka">გასაღები (ქართული)</Label>
                  <Input
                    id="key_ka"
                    name="key_ka"
                    defaultValue={editingText?.key_ka || ''}
                    placeholder="მაგ. თანამშრომლები.სათაური"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">კატეგორია *</Label>
                  <Select name="category" defaultValue={editingText?.category || 'general'}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">ზოგადი</SelectItem>
                      <SelectItem value="employees">თანამშრომლები</SelectItem>
                      <SelectItem value="payroll">ხელფასები</SelectItem>
                      <SelectItem value="attendance">დასწრება</SelectItem>
                      <SelectItem value="dashboard">მთავარი</SelectItem>
                      <SelectItem value="notifications">შეტყობინებები</SelectItem>
                      <SelectItem value="leave_requests">შვებულების მოთხოვნები</SelectItem>
                      <SelectItem value="documents">დოკუმენტები</SelectItem>
                      <SelectItem value="settings">პარამეტრები</SelectItem>
                      <SelectItem value="reports">ანგარიშები</SelectItem>
                      <SelectItem value="contacts">კონტაქტები</SelectItem>
                      <SelectItem value="deals">გარიგებები</SelectItem>
                      <SelectItem value="candidates">კანდიდატები</SelectItem>
                      <SelectItem value="vacancies">ვაკანსიები</SelectItem>
                      <SelectItem value="evaluations">შეფასებები</SelectItem>
                      <SelectItem value="schedules">განრიგი</SelectItem>
                      <SelectItem value="business_trips">მივლინებები</SelectItem>
                      <SelectItem value="vehicle_requests">ტრანსპორტის მოთხოვნები</SelectItem>
                      <SelectItem value="org_structure">ორგანიზაციული სტრუქტურა</SelectItem>
                      <SelectItem value="system">სისტემა</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="ka_text">ტექსტი (ქართული) *</Label>
                <Input
                  id="ka_text"
                  name="ka_text"
                  defaultValue={editingText?.ka_text}
                  required
                />
              </div>
              <div>
                <Label htmlFor="en_text">ტექსტი (ინგლისური)</Label>
                <Input
                  id="en_text"
                  name="en_text"
                  defaultValue={editingText?.en_text || ''}
                />
              </div>
              <div>
                <Label htmlFor="description">აღწერა</Label>
                <Textarea
                  id="description"
                  name="description"
                  defaultValue={editingText?.description || ''}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  გაუქმება
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? 'შენახვა...' : 'შენახვა'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="ძებნა..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="კატეგორია" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">ყველა კატეგორია</SelectItem>
            {categories.map((cat) => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>ტექსტების სია</CardTitle>
          <CardDescription>
            სულ {filteredTexts.length} ტექსტი
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ქართული გასაღები</TableHead>
                <TableHead>English Key</TableHead>
                <TableHead>კატეგორია</TableHead>
                <TableHead>ქართული ტექსტი</TableHead>
                <TableHead>English Text</TableHead>
                <TableHead className="w-20"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTexts.map((text) => (
                <TableRow key={text.id}>
                  <TableCell className="font-semibold">{text.key_ka || '-'}</TableCell>
                  <TableCell className="font-mono text-sm text-muted-foreground">{text.key}</TableCell>
                  <TableCell>
                    <span className="px-2 py-1 bg-primary/10 text-primary rounded text-xs">
                      {text.category}
                    </span>
                  </TableCell>
                  <TableCell>{text.ka_text}</TableCell>
                  <TableCell className="text-muted-foreground">{text.en_text || '-'}</TableCell>
                  <TableCell>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setEditingText(text);
                        setIsDialogOpen(true);
                      }}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredTexts.length === 0 && (
            <div className="flex h-32 items-center justify-center text-muted-foreground">
              ტექსტები არ მოიძებნა
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
