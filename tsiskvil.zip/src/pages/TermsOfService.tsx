import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Briefcase,
  Shield,
  Lock,
  Server,
  Scale,
} from 'lucide-react';
import { PageTransition } from '@/components/PageTransition';

const TermsOfService = () => {
  return (
    <PageTransition>
      <div className="max-w-4xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <Briefcase className="h-16 w-16 mx-auto text-primary" />
          <h1 className="text-4xl font-bold">მომსახურების პირობები</h1>
          <p className="text-muted-foreground">Terms of Service - B2B / SaaS</p>
          <p className="text-sm text-muted-foreground">ბოლო განახლება: 19 ივნისი, 2026</p>
        </div>

        <Card className="bg-muted/30 border-muted">
          <CardContent className="py-6">
            <p className="text-sm text-muted-foreground leading-relaxed">
              წინამდებარე ხელშეკრულება არეგულირებს წვდომას „Talent OS“ პლატფორმაზე (შემდგომში „პლატფორმა“) და მის გამოყენებას კორპორატიული კლიენტების (შემდგომში „დამსაქმებელი“) მიერ. პლატფორმაზე რეგისტრაციით ან მომსახურების ხელშეკრულების გაფორმებით, დამსაქმებელი ეთანხმება ამ პირობებს.
            </p>
          </CardContent>
        </Card>

        {/* Section 1 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Briefcase className="h-5 w-5 text-primary" />
              1. სერვისის აღწერილობა და მხარეთა როლები
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
              <p>
                <strong>1.1.</strong> Talent OS წარმოადგენს ადამიანური რესურსების მართვის ღრუბლოვან სისტემას (SaaS), რომელიც მოიცავს კადრების აღრიცხვის, დაწინაურების, დისციპლინური სანქციების, სახელფასო უწყისების (Payroll), დასწრებისა და კარიერული განვითარების მოდულებს.
              </p>
              <p>
                <strong>1.2.</strong> მონაცემთა დამამუშავებელი (Data Controller): დამსაქმებელი, რომელიც სისტემაში ატვირთავს თავისი თანამშრომლების პერსონალურ მონაცემებს, მოქმედებს როგორც მონაცემთა დამამუშავებელი და სრულად არის პასუხისმგებელი ამ მონაცემების შეგროვების სამართლებრივ საფუძვლებზე (მაგ. შრომითი ხელშეკრულება).
              </p>
              <p>
                <strong>1.3.</strong> მონაცემთა დამმუშავებელი (Data Processor): პლატფორმა TalentOS მოქმედებს ექსკლუზიურად როგორც მონაცემთა დამმუშავებელი. ჩვენ ვამუშავებთ ინფორმაციას მხოლოდ დამსაქმებლის წერილობითი ინსტრუქციების შესაბამისად და წინამდებარე პირობების ფარგლებში.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Section 2 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Shield className="h-5 w-5 text-primary" />
              2. ანგარიშების მართვა და წვდომის კონტროლი
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
              <p>
                <strong>2.1.</strong> დამსაქმებელი ვალდებულია თავად მართოს თავისი ადმინისტრატორებისა და თანამშრომლების წვდომის უფლებები (Role-Based Access Control).
              </p>
              <p>
                <strong>2.2.</strong> დამსაქმებელი პასუხისმგებელია ყველა იმ ქმედებაზე, რომელიც განხორციელდება მისი კორპორატიული ანგარიშის ქვეშ. უსაფრთხოების მიზნით, ყველა ადმინისტრატორისთვის სავალდებულოა ორფაქტორიანი ავტორიზაციის (2FA) აქტივაცია.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Section 3 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Lock className="h-5 w-5 text-primary" />
              3. სენსიტიური მონაცემების დამუშავება (ხელფასები და სანქციები)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
              <p>
                <strong>3.1.</strong> პლატფორმა უზრუნველყოფს ადამიანური რესურსების მართვისთვის საჭირო ტექნიკურ გარემოს.
              </p>
              <p>
                <strong>3.2.</strong> ეს მონაცემები მკაცრად კონფიდენციალურია. პლატფორმის ტექნიკურ პერსონალს არ აქვს წვდომა ამ შინაარსზე, გარდა იმ შემთხვევებისა, როდესაც დამსაქმებელი თავად ითხოვს ტექნიკურ მხარდაჭერას (Support) და გასცემს დროებით ავტორიზაციას.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Section 4 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Server className="h-5 w-5 text-primary" />
              4. მონაცემთა მდებარეობა და უსაფრთხოება
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
              <p>
                <strong>4.1.</strong> Talent OS-ის ინფრასტრუქტურა განთავსებულია Lovable პლატფორმაზე. ყველა მონაცემი ფიზიკურად ლოკალიზებულია და ინახება ევროკავშირის (EU) ტერიტორიაზე არსებულ მაღალი დაცვის სერვერებზე.
              </p>
              <p>
                <strong>4.2.</strong> პლატფორმა ახორციელებს მონაცემთა დაშიფვრას როგორც გადაცემის პროცესში (In Transit - TLS), ისე შენახვისას (At Rest - AES-256), და აწარმოებს ქმედებების აუდიტის ლოგებს (Audit Trail).
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Section 5 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Scale className="h-5 w-5 text-primary" />
              5. პასუხისმგებლობის შეზღუდვა
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
              <p>
                <strong>5.1.</strong> Talent OS არ არის შრომითი დავების მხარე დამსაქმებელსა და მის თანამშრომლებს შორის. პლატფორმა არ აგებს პასუხს სისტემაში შეყვანილი მონაცემების საფუძველზე არასწორად დათვლილ ხელფასებზე ან შრომითი ურთიერთობის შეწყვეტის სამართლებრივ შედეგებზე.
              </p>
              <p>
                <strong>5.2.</strong> დამსაქმებელი ვალდებულია აანაზღაუროს ნებისმიერი ზიანი ან ჯარიმა, რომელიც შეიძლება დაეკისროს პლატფორმას დამსაქმებლის მიერ პერსონალურ მონაცემთა დაცვის კანონმდებლობის (ან GDPR-ის) დარღვევით მონაცემთა შეყვანის გამო.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageTransition>
  );
};

export default TermsOfService;
