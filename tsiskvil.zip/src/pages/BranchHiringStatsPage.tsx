import { BranchHiringStats } from "@/components/BranchHiringStats";
import { PageTransition } from "@/components/PageTransition";
import { Building2 } from "lucide-react";

export default function BranchHiringStatsPage() {
  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-primary to-primary/80 shadow-lg">
              <Building2 className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">დანიშვნა / გათავისუფლება ფილიალების მიხედვით</h1>
              <p className="text-muted-foreground">კადრების მოძრაობის სტატისტიკა ფილიალების მიხედვით</p>
            </div>
          </div>
          <BranchHiringStats />
        </div>
      </div>
    </PageTransition>
  );
}
