import { useState, useEffect } from 'react';
import { PageTransition } from '@/components/PageTransition';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Download, Search, LogOut } from 'lucide-react';
import { ReportPageShell } from '@/components/reports/ReportPageShell';
import { format } from 'date-fns';
import { ka } from 'date-fns/locale';
import { exportToExcel } from '@/lib/exportToExcel';

interface LogoutLog {
  id: string;
  user_id: string | null;
  action_type: string;
  created_at: string;
  ip_address: string | null;
  user_agent: string | null;
  status: string;
  employee_name?: string;
  employee_email?: string;
  details?: any;
}

export default function AutoLogoutReport() {
  const [logoutLogs, setLogoutLogs] = useState<LogoutLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<LogoutLog[]>([]);
  const [employees, setEmployees] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Filters
  const [selectedEmployee, setSelectedEmployee] = useState<string>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [logoutLogs, selectedEmployee, startDate, endDate, searchTerm]);

  const fetchData = async () => {
    try {
      setIsLoading(true);

      // Fetch employees for the filter dropdown
      const { data: employeesData } = await supabase
        .from('employees')
        .select('id, full_name, email, user_id')
        .eq('status', 'active')
        .order('full_name');

      setEmployees(employeesData || []);

      // Fetch logout logs (session timeout, force logout, etc.)
      const { data: logsData, error } = await supabase
        .from('audit_logs')
        .select('*')
        .in('action_type', ['logout', 'sign_out', 'session_timeout', 'force_logout', 'auto_logout'])
        .order('created_at', { ascending: false })
        .limit(1000);

      if (error) throw error;

      // Enrich logs with employee information
      const enrichedLogs = (logsData || []).map(log => {
        const employee = employeesData?.find(emp => emp.user_id === log.user_id);
        return {
          ...log,
          employee_name: employee?.full_name || 'უცნობი',
          employee_email: employee?.email || ''
        };
      });

      setLogoutLogs(enrichedLogs);
      setFilteredLogs(enrichedLogs);
    } catch (error: any) {
      console.error('Error fetching data:', error);
      toast.error('მონაცემების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...logoutLogs];

    // Filter by employee
    if (selectedEmployee !== 'all') {
      filtered = filtered.filter(log => log.user_id === selectedEmployee);
    }

    // Filter by date range
    if (startDate) {
      filtered = filtered.filter(log => new Date(log.created_at) >= new Date(startDate));
    }
    if (endDate) {
      filtered = filtered.filter(log => new Date(log.created_at) <= new Date(endDate + 'T23:59:59'));
    }

    // Filter by search term
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(log => 
        log.employee_name?.toLowerCase().includes(search) ||
        log.employee_email?.toLowerCase().includes(search) ||
        log.ip_address?.toLowerCase().includes(search)
      );
    }

    setFilteredLogs(filtered);
  };

  const getLogoutReason = (log: LogoutLog): string => {
    if (log.action_type === 'session_timeout' || log.action_type === 'auto_logout') {
      return 'ავტომატური გასვლა (სესიის ვადა)';
    }
    if (log.action_type === 'force_logout') {
      return 'იძულებითი გასვლა';
    }
    if (log.details?.reason) {
      return log.details.reason;
    }
    return 'ავტომატური გასვლა';
  };

  const handleExportToExcel = () => {
    const exportData = filteredLogs.map(log => ({
      'თანამშრომელი': log.employee_name,
      'ელ. ფოსტა': log.employee_email,
      'გასვლის თარიღი': format(new Date(log.created_at), 'dd/MM/yyyy', { locale: ka }),
      'გასვლის დრო': format(new Date(log.created_at), 'HH:mm:ss'),
      'მიზეზი': getLogoutReason(log),
      'IP მისამართი': log.ip_address || '',
      'სტატუსი': log.status === 'success' ? 'წარმატებული' : 'წარუმატებელი'
    }));

    const success = exportToExcel(
      exportData,
      `ავტოლოგაუთების_რეპორტი_${format(new Date(), 'dd-MM-yyyy')}`,
      'ავტოლოგაუთები'
    );

    if (success) {
      toast.success('ექსპორტი წარმატებით განხორციელდა');
    } else {
      toast.error('ექსპორტის შეცდომა');
    }
  };

  const resetFilters = () => {
    setSelectedEmployee('all');
    setStartDate('');
    setEndDate('');
    setSearchTerm('');
  };

  return (
    <ReportPageShell
      title="ავტოლოგაუთების რეპორტი"
      description="თანამშრომლების ავტომატური გასვლების ისტორია"
      icon={LogOut}
      gradient="from-amber-400 via-orange-500 to-red-500"
      shadow="shadow-orange-500/30"
      actions={
        <Button onClick={handleExportToExcel} disabled={filteredLogs.length === 0} size="lg" className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 shadow-lg">
          <Download className="h-4 w-4 mr-2" />
          Excel-ში გადმოწერა
        </Button>
      }
    >

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              ფილტრები
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="employee">თანამშრომელი</Label>
                <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                  <SelectTrigger id="employee">
                    <SelectValue placeholder="აირჩიეთ თანამშრომელი" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">ყველა</SelectItem>
                    {employees
                      .filter(emp => emp.user_id)
                      .map(emp => (
                        <SelectItem key={emp.user_id} value={emp.user_id}>
                          {emp.full_name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="start-date">დაწყების თარიღი</Label>
                <Input
                  id="start-date"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="end-date">დასრულების თარიღი</Label>
                <Input
                  id="end-date"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="search">ძებნა</Label>
                <Input
                  id="search"
                  placeholder="ძიება სახელით, ფოსტით..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" onClick={resetFilters}>
                ფილტრების გასუფთავება
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats Card */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">სულ ავტოლოგაუთები</p>
                <p className="text-2xl font-bold">{filteredLogs.length}</p>
              </div>
              <LogOut className="h-8 w-8 text-destructive" />
            </div>
          </CardContent>
        </Card>

        {/* Table */}
        <Card>
          <CardHeader>
            <CardTitle>ავტოლოგაუთების სია</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">იტვირთება...</div>
            ) : filteredLogs.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                მონაცემები არ მოიძებნა
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თანამშრომელი</TableHead>
                      <TableHead>ელ. ფოსტა</TableHead>
                      <TableHead>თარიღი</TableHead>
                      <TableHead>დრო</TableHead>
                      <TableHead>მიზეზი</TableHead>
                      <TableHead>IP მისამართი</TableHead>
                      <TableHead>სტატუსი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredLogs.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="font-medium">{log.employee_name}</TableCell>
                        <TableCell>{log.employee_email}</TableCell>
                        <TableCell>
                          {format(new Date(log.created_at), 'dd/MM/yyyy', { locale: ka })}
                        </TableCell>
                        <TableCell>
                          {format(new Date(log.created_at), 'HH:mm:ss')}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <LogOut className="h-4 w-4 text-destructive" />
                            {getLogoutReason(log)}
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {log.ip_address || 'N/A'}
                        </TableCell>
                        <TableCell>
                          <Badge variant={log.status === 'success' ? 'default' : 'destructive'}>
                            {log.status === 'success' ? 'წარმატებული' : 'წარუმატებელი'}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
    </ReportPageShell>
  );
}
