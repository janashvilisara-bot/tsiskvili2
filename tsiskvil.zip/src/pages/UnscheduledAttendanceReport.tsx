import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Download, Calendar as CalIcon } from "lucide-react";
import { ReportPageShell } from "@/components/reports/ReportPageShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ResponsiveTable } from "@/components/ResponsiveTable";
import { XLSX } from "@/lib/xlsxCompat";

interface Row {
  attendance_id: string;
  employee_id: string;
  employee_name: string;
  department: string | null;
  date: string;
  check_in: string | null;
  check_out: string | null;
  check_in_method: string | null;
}

const UnscheduledAttendanceReport = () => {
  const now = new Date();
  const [month, setMonth] = useState<number>(now.getMonth() + 1);
  const [year, setYear] = useState<number>(now.getFullYear());
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => { fetchData(); }, [month, year]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const startDate = new Date(year, month - 1, 1);
      const endDate = new Date(year, month, 0);
      const startStr = startDate.toISOString().split("T")[0];
      const endStr = endDate.toISOString().split("T")[0];

      // 1. Pull attendance records with check-in or check-out
      const { data: att, error: attErr } = await supabase
        .from("attendance")
        .select("id, employee_id, date, check_in, check_out, check_in_method")
        .gte("date", startStr)
        .lte("date", endStr)
        .or("check_in.not.is.null,check_out.not.is.null");
      if (attErr) throw attErr;

      const empIds = Array.from(new Set((att || []).map((a: any) => a.employee_id)));
      if (empIds.length === 0) { setRows([]); return; }

      // 2. Pull employees
      const { data: emps } = await supabase
        .from("employees")
        .select("id, full_name, department")
        .in("id", empIds);
      const empMap = new Map((emps || []).map((e: any) => [e.id, e]));

      // 3. Pull schedules for the period
      const [ws, es, ss] = await Promise.all([
        supabase.from("work_schedules")
          .select("employee_id, effective_from, effective_to")
          .in("employee_id", empIds)
          .lte("effective_from", endStr),
        supabase.from("employee_schedules")
          .select("employee_id, start_date, end_date")
          .in("employee_id", empIds)
          .lte("start_date", endStr),
        supabase.from("shift_schedules")
          .select("employee_id, shift_date")
          .in("employee_id", empIds)
          .gte("shift_date", startStr)
          .lte("shift_date", endStr),
      ]);

      const hasSchedule = (empId: string, dateStr: string): boolean => {
        const d = dateStr;
        // work_schedules: effective_from <= d AND (effective_to IS NULL OR effective_to >= d)
        if ((ws.data || []).some((r: any) =>
          r.employee_id === empId &&
          r.effective_from <= d &&
          (!r.effective_to || r.effective_to >= d)
        )) return true;
        // employee_schedules: start_date <= d AND (end_date IS NULL OR end_date >= d)
        if ((es.data || []).some((r: any) =>
          r.employee_id === empId &&
          r.start_date <= d &&
          (!r.end_date || r.end_date >= d)
        )) return true;
        // shift_schedules: shift_date == d
        if ((ss.data || []).some((r: any) =>
          r.employee_id === empId && r.shift_date === d
        )) return true;
        return false;
      };

      const result: Row[] = [];
      for (const a of (att || []) as any[]) {
        if (hasSchedule(a.employee_id, a.date)) continue;
        const emp = empMap.get(a.employee_id) as any;
        result.push({
          attendance_id: a.id,
          employee_id: a.employee_id,
          employee_name: emp?.full_name || "-",
          department: emp?.department || null,
          date: a.date,
          check_in: a.check_in,
          check_out: a.check_out,
          check_in_method: a.check_in_method,
        });
      }
      result.sort((a, b) => b.date.localeCompare(a.date) || a.employee_name.localeCompare(b.employee_name));
      setRows(result);
    } catch (e: any) {
      console.error(e);
      toast.error("მონაცემების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  const exportExcel = () => {
    if (rows.length === 0) { toast.info("მონაცემები არ არის"); return; }
    const data = rows.map(r => ({
      "თარიღი": r.date,
      "თანამშრომელი": r.employee_name,
      "დეპარტამენტი": r.department || "-",
      "შემოსვლა": r.check_in || "-",
      "გასვლა": r.check_out || "-",
      "მეთოდი": r.check_in_method || "-",
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "გრაფიკის გარეშე");
    XLSX.writeFile(wb, `unscheduled_attendance_${year}_${month}.xlsx`);
  };

  const months = ["იანვარი","თებერვალი","მარტი","აპრილი","მაისი","ივნისი","ივლისი","აგვისტო","სექტემბერი","ოქტომბერი","ნოემბერი","დეკემბერი"];
  const years = Array.from({ length: 5 }, (_, i) => now.getFullYear() - i);

  return (
    <ReportPageShell
      title="დასწრება გრაფიკის გარეშე"
      description="დღეები, როცა თანამშრომელს ფიქსირდება შემოსვლა/გასვლა, მაგრამ მინიჭებული გრაფიკი არ აქვს"
      icon={AlertTriangle}
      gradient="from-amber-400 via-orange-500 to-red-500"
    >
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2">
                <CalIcon className="h-5 w-5 text-primary" />
                პერიოდი
              </CardTitle>
              <CardDescription>აირჩიე თვე და წელი</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
                <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {months.map((m, i) => <SelectItem key={i + 1} value={String(i + 1)}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
                <SelectTrigger className="w-[110px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {years.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm" onClick={exportExcel} disabled={rows.length === 0}>
                <Download className="h-4 w-4 mr-2" />Excel
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2 mb-4">
            <Badge variant={rows.length > 0 ? "destructive" : "secondary"}>
              ანომალია: {rows.length}
            </Badge>
            <span className="text-sm text-muted-foreground">
              ჩანაწერი ჩაითვალა ანომალიად, თუ თანამშრომელს მითითებულ თარიღზე არ აქვს არც წესიერი გრაფიკი (work/employee schedule) და არც ცვლის გრაფიკი (shift schedule).
            </span>
          </div>

          {loading ? (
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-12 bg-muted animate-pulse rounded" />
              ))}
            </div>
          ) : rows.length === 0 ? (
            <p className="text-center text-muted-foreground py-12">
              ანომალია არ მოიძებნა - ყველა დასწრება გრაფიკის ფარგლებშია ✅
            </p>
          ) : (
            <ResponsiveTable>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>თარიღი</TableHead>
                    <TableHead>თანამშრომელი</TableHead>
                    <TableHead>დეპარტამენტი</TableHead>
                    <TableHead>შემოსვლა</TableHead>
                    <TableHead>გასვლა</TableHead>
                    <TableHead>მეთოდი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((r) => (
                    <TableRow key={r.attendance_id}>
                      <TableCell className="font-medium">{r.date}</TableCell>
                      <TableCell>{r.employee_name}</TableCell>
                      <TableCell>{r.department || "-"}</TableCell>
                      <TableCell>{r.check_in || "-"}</TableCell>
                      <TableCell>{r.check_out || "-"}</TableCell>
                      <TableCell><Badge variant="outline">{r.check_in_method || "-"}</Badge></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ResponsiveTable>
          )}
        </CardContent>
      </Card>
    </ReportPageShell>
  );
};

export default UnscheduledAttendanceReport;
