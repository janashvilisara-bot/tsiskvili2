import { useState, useMemo } from "react";
import {
  Shield,
  FileDown,
  FileText,
  AlertTriangle,
  CheckCircle,
  Clock,
  Moon,
  Calendar,
  Users,
  Briefcase,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useWorkTimeData } from "@/hooks/useWorkTimeData";
import { supabase } from "@/integrations/supabase/client";
import { useBranchFilter } from "@/hooks/useBranchFilter";

import { useEffect } from "react";
import { toast } from "sonner";
import { exportLaborInspectionReport } from "@/lib/exportLaborInspectionReport";
import { exportLaborInspectionPDF } from "@/lib/exportLaborInspectionPDF";
import { cn } from "@/lib/utils";

export default function LaborInspectionReport() {
  const now = new Date();
  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split("T")[0];
  const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split("T")[0];

  const [startDate, setStartDate] = useState(firstDay);
  const [endDate, setEndDate] = useState(lastDay);
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [departments, setDepartments] = useState<{ id: string; name: string }[]>([]);

  const branchId = useBranchFilter();
  const { records, loading } = useWorkTimeData(startDate, endDate, selectedDepartment, "all", branchId);


  useEffect(() => {
    const fetchDepartments = async () => {
      const { data } = await supabase.from("departments").select("id, name").order("name");
      if (data) setDepartments(data);
    };
    fetchDepartments();
  }, []);

  const compliance = useMemo(() => {
    const weeklyViolations = records.filter((r) => r.regular_hours / 4 > 40);
    const overtimeViolations = records.filter((r) => (r.regular_hours + r.overtime_hours) / 4 > 48);
    const nightWorkers = records.filter((r) => r.night_work_hours > 0);
    const highNightWork = records.filter((r) => r.night_work_hours > 20);
    const totalViolations = weeklyViolations.length + overtimeViolations.length + highNightWork.length;
    const complianceRate = records.length > 0 ? Math.round(((records.length - totalViolations) / records.length) * 100) : 100;

    return {
      weeklyViolations,
      overtimeViolations,
      nightWorkers,
      highNightWork,
      totalViolations,
      complianceRate,
    };
  }, [records]);

  const handleExportExcel = async () => {
    if (records.length === 0) {
      toast.error("მონაცემები არ მოიძებნა");
      return;
    }
    try {
      await exportLaborInspectionReport(records, startDate, endDate);
      toast.success("Excel ანგარიში წარმატებით ჩამოიტვირთა");
    } catch {
      toast.error("Excel ექსპორტის შეცდომა");
    }
  };

  const handleExportPDF = () => {
    if (records.length === 0) {
      toast.error("მონაცემები არ მოიძებნა");
      return;
    }
    try {
      exportLaborInspectionPDF(records, startDate, endDate);
      toast.success("PDF ანგარიში წარმატებით ჩამოიტვირთა");
    } catch {
      toast.error("PDF ექსპორტის შეცდომა");
    }
  };

  const statCards = [
    {
      title: "შესაბამისობის მაჩვენებელი",
      value: `${compliance.complianceRate}%`,
      icon: compliance.complianceRate >= 90 ? CheckCircle : AlertTriangle,
      color: compliance.complianceRate >= 90 ? "from-emerald-500 to-green-600" : "from-red-500 to-rose-600",
      bgColor: compliance.complianceRate >= 90 ? "bg-emerald-500/10" : "bg-red-500/10",
      trend: compliance.complianceRate >= 90 ? "ნორმაში" : "ყურადღება",
      trendUp: compliance.complianceRate >= 90,
    },
    {
      title: "40-სთ კვირის დარღვევა",
      value: compliance.weeklyViolations.length.toString(),
      icon: Clock,
      color: "from-orange-500 to-amber-600",
      bgColor: "bg-orange-500/10",
      trend: compliance.weeklyViolations.length === 0 ? "ნორმაში" : "დარღვევა",
      trendUp: compliance.weeklyViolations.length === 0,
    },
    {
      title: "ღამის სამუშაო",
      value: compliance.nightWorkers.length.toString(),
      icon: Moon,
      color: "from-indigo-500 to-violet-600",
      bgColor: "bg-indigo-500/10",
      trend: `${Math.round(records.reduce((s, r) => s + r.night_work_hours, 0))} სთ`,
      trendUp: compliance.highNightWork.length === 0,
    },
    {
      title: "სულ დარღვევები",
      value: compliance.totalViolations.toString(),
      icon: AlertTriangle,
      color: "from-red-500 to-rose-600",
      bgColor: "bg-red-500/10",
      trend: compliance.totalViolations === 0 ? "სუფთა" : "საჭიროა ყურადღება",
      trendUp: compliance.totalViolations === 0,
    },
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-red-500 via-rose-500 to-orange-500 shadow-xl shadow-red-500/30">
                <Shield className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                  შრომის ინსპექციის ანგარიში
                </h1>
                <p className="text-muted-foreground mt-1">
                  lms.gov.ge - შრომის კოდექსთან შესაბამისობის ანალიზი
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button onClick={handleExportExcel} className="gap-2 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700" size="lg">
                <FileDown className="h-5 w-5" />
                Excel ექსპორტი
              </Button>
              <Button onClick={handleExportPDF} variant="outline" className="gap-2" size="lg">
                <FileText className="h-5 w-5" />
                PDF ექსპორტი
              </Button>
            </div>
          </div>

          {/* Filters */}
          <Card className="border-border/50 bg-card/80 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground mb-2 block">საწყისი თარიღი</label>
                  <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground mb-2 block">საბოლოო თარიღი</label>
                  <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground mb-2 block">დეპარტამენტი</label>
                  <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                    <SelectTrigger>
                      <SelectValue placeholder="ყველა დეპარტამენტი" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                      {departments.map((d) => (
                        <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {statCards.map((stat, index) => (
              <Card
                key={index}
                className={cn(
                  "group relative overflow-hidden border-border/50 bg-card/80 backdrop-blur-xl",
                  "hover:shadow-2xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-2",
                  "animate-fade-in"
                )}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardContent className="p-6 relative">
                  <div className="flex items-start justify-between mb-4">
                    <div className={cn("p-3 rounded-xl", stat.bgColor)}>
                      <stat.icon className="h-6 w-6" style={{ color: `hsl(var(--primary))` }} />
                    </div>
                    <div className={cn(
                      "flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full",
                      stat.trendUp
                        ? "text-emerald-600 bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-400"
                        : "text-red-600 bg-red-100 dark:bg-red-950/50 dark:text-red-400"
                    )}>
                      {stat.trendUp ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                      <span>{stat.trend}</span>
                    </div>
                  </div>
                  <div className="text-2xl md:text-3xl font-bold tracking-tight">{loading ? "..." : stat.value}</div>
                  <div className="text-sm text-muted-foreground font-medium mt-1">{stat.title}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Violations Table */}
          {!loading && compliance.totalViolations > 0 && (
            <Card className="border-red-200 dark:border-red-900/50 animate-fade-in">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600 dark:text-red-400">
                  <AlertTriangle className="h-5 w-5" />
                  აღმოჩენილი დარღვევები ({compliance.totalViolations})
                </CardTitle>
                <CardDescription>საქართველოს შრომის კოდექსის მოთხოვნებთან შეუსაბამობა</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {compliance.weeklyViolations.map((r, i) => (
                    <div key={`weekly-${i}`} className="flex items-center justify-between p-3 rounded-lg bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/30">
                      <div className="flex items-center gap-3">
                        <Clock className="h-4 w-4 text-red-500" />
                        <div>
                          <p className="font-medium text-sm">{r.employee_name}</p>
                          <p className="text-xs text-muted-foreground">40-საათიანი კვირის დარღვევა - საშუალო: {Math.round((r.regular_hours / 4) * 10) / 10} სთ/კვირა</p>
                        </div>
                      </div>
                      <Badge variant="destructive">მაღალი</Badge>
                    </div>
                  ))}
                  {compliance.overtimeViolations.map((r, i) => (
                    <div key={`ot-${i}`} className="flex items-center justify-between p-3 rounded-lg bg-orange-50 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-900/30">
                      <div className="flex items-center gap-3">
                        <AlertTriangle className="h-4 w-4 text-orange-500" />
                        <div>
                          <p className="font-medium text-sm">{r.employee_name}</p>
                          <p className="text-xs text-muted-foreground">48-საათიანი ლიმიტის გადაჭარბება - სულ: {Math.round(((r.regular_hours + r.overtime_hours) / 4) * 10) / 10} სთ/კვირა</p>
                        </div>
                      </div>
                      <Badge variant="destructive">კრიტიკული</Badge>
                    </div>
                  ))}
                  {compliance.highNightWork.map((r, i) => (
                    <div key={`night-${i}`} className="flex items-center justify-between p-3 rounded-lg bg-indigo-50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-900/30">
                      <div className="flex items-center gap-3">
                        <Moon className="h-4 w-4 text-indigo-500" />
                        <div>
                          <p className="font-medium text-sm">{r.employee_name}</p>
                          <p className="text-xs text-muted-foreground">მაღალი ღამის სამუშაო - {Math.round(r.night_work_hours * 10) / 10} სთ</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="border-indigo-300 text-indigo-600">საშუალო</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Compliance OK banner */}
          {!loading && compliance.totalViolations === 0 && records.length > 0 && (
            <Card className="border-emerald-200 dark:border-emerald-900/50 bg-emerald-50/50 dark:bg-emerald-950/20 animate-fade-in">
              <CardContent className="p-8 text-center">
                <CheckCircle className="h-12 w-12 text-emerald-500 mx-auto mb-3" />
                <h3 className="text-xl font-bold text-emerald-700 dark:text-emerald-400">სრული შესაბამისობა</h3>
                <p className="text-muted-foreground mt-1">ყველა თანამშრომელი შრომის კოდექსის მოთხოვნებს აკმაყოფილებს</p>
              </CardContent>
            </Card>
          )}

          {/* Employee Summary Table */}
          {!loading && records.length > 0 && (
            <Card className="border-border/50 bg-card/80 backdrop-blur-xl animate-fade-in">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  თანამშრომლების სამუშაო დროის რეზიუმე
                </CardTitle>
                <CardDescription>{records.length} თანამშრომელი • {startDate} - {endDate}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-2 font-medium text-muted-foreground">თანამშრომელი</th>
                        <th className="text-center py-3 px-2 font-medium text-muted-foreground">დღეები</th>
                        <th className="text-center py-3 px-2 font-medium text-muted-foreground">რეგულარული</th>
                        <th className="text-center py-3 px-2 font-medium text-muted-foreground">ზეგანაკვეთური</th>
                        <th className="text-center py-3 px-2 font-medium text-muted-foreground">ღამის</th>
                        <th className="text-center py-3 px-2 font-medium text-muted-foreground">შვებულება</th>
                        <th className="text-center py-3 px-2 font-medium text-muted-foreground">მივლინება</th>
                        <th className="text-center py-3 px-2 font-medium text-muted-foreground">სტატუსი</th>
                      </tr>
                    </thead>
                    <tbody>
                      {records.slice(0, 20).map((r, i) => {
                        const weeklyAvg = r.regular_hours / 4;
                        const hasViolation = weeklyAvg > 40 || (r.regular_hours + r.overtime_hours) / 4 > 48;
                        return (
                          <tr key={i} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                            <td className="py-3 px-2">
                              <div className="font-medium">{r.employee_name}</div>
                              <div className="text-xs text-muted-foreground">{r.position}</div>
                            </td>
                            <td className="text-center py-3 px-2">{r.worked_days}</td>
                            <td className="text-center py-3 px-2">{Math.round(r.regular_hours * 10) / 10}</td>
                            <td className="text-center py-3 px-2">{Math.round(r.overtime_hours * 10) / 10}</td>
                            <td className="text-center py-3 px-2">{Math.round(r.night_work_hours * 10) / 10}</td>
                            <td className="text-center py-3 px-2">{r.vacation_days}</td>
                            <td className="text-center py-3 px-2">{r.total_business_trip_days}</td>
                            <td className="text-center py-3 px-2">
                              {hasViolation ? (
                                <Badge variant="destructive" className="text-xs">დარღვევა</Badge>
                              ) : (
                                <Badge variant="outline" className="text-xs border-emerald-300 text-emerald-600">ნორმაში</Badge>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  {records.length > 20 && (
                    <p className="text-center text-sm text-muted-foreground mt-4">
                      ნაჩვენებია 20 / {records.length} თანამშრომელი. სრული სია ხელმისაწვდომია Excel/PDF ექსპორტში.
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Footer info */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-primary/5 via-primary/10 to-accent/10 border border-primary/20 backdrop-blur-xl animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-primary/10">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">საქართველოს შრომის კოდექსი</p>
                <p className="text-xs text-muted-foreground">
                  40-საათიანი სამუშაო კვირა • ზეგანაკვეთური ≤ 48 სთ/კვირა • 24 დღე ყოველწლიური შვებულება • ღამის სამუშაო 22:00–06:00
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
