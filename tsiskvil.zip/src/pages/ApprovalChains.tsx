import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, ChevronRight, CheckCircle2, XCircle, Clock, GitBranch, ArrowUp, ArrowDown } from "lucide-react";

interface Chain {
  id: string;
  name: string;
  description: string | null;
  module: string;
  is_active: boolean;
  updated_at: string;
}

interface ChainStep {
  id: string;
  chain_id: string;
  step_order: number;
  approver_type: string;
  approver_role: string | null;
  approver_user_id: string | null;
  min_amount: number | null;
  max_amount: number | null;
}

interface ApprovalRequest {
  id: string;
  chain_id: string;
  module: string;
  requested_by: string;
  amount: number | null;
  current_step: number;
  status: string;
  payload: any;
  created_at: string;
}

const MODULES = [
  { value: "leave", ka: "შვებულება", en: "Leave" },
  { value: "business_trip", ka: "ბიზნეს მივლინება", en: "Business Trip" },
  { value: "overtime", ka: "ზეგანაკვეთური", en: "Overtime" },
  { value: "expense", ka: "ხარჯი", en: "Expense" },
  { value: "generic", ka: "ზოგადი", en: "Generic" },
];

const ROLES = [
  { value: "manager", ka: "მენეჯერი", en: "Manager" },
  { value: "hr_manager", ka: "HR", en: "HR" },
  { value: "cfo", ka: "CFO", en: "CFO" },
  { value: "admin", ka: "Admin", en: "Admin" },
];

export default function ApprovalChains() {
  const { language } = useLanguage();
  const { toast } = useToast();
  const tr = (ka: string, en: string) => (language === "en" ? en : ka);

  const [chains, setChains] = useState<Chain[]>([]);
  const [steps, setSteps] = useState<Record<string, ChainStep[]>>({});
  const [requests, setRequests] = useState<ApprovalRequest[]>([]);
  const [selected, setSelected] = useState<Chain | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newModule, setNewModule] = useState("leave");
  const [tab, setTab] = useState("chains");

  const load = async () => {
    const { data: chainsData } = await supabase.from("approval_chains" as any).select("*").order("created_at", { ascending: false });
    if (chainsData) {
      setChains(chainsData as any);
      const ids = (chainsData as any).map((c: any) => c.id);
      if (ids.length) {
        const { data: stepsData } = await supabase
          .from("approval_chain_steps" as any)
          .select("*")
          .in("chain_id", ids)
          .order("step_order");
        if (stepsData) {
          const grouped: Record<string, ChainStep[]> = {};
          (stepsData as any[]).forEach((s) => {
            grouped[s.chain_id] = grouped[s.chain_id] || [];
            grouped[s.chain_id].push(s);
          });
          setSteps(grouped);
        }
      }
    }
    const { data: reqs } = await supabase
      .from("approval_requests" as any)
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);
    if (reqs) setRequests(reqs as any);
  };

  useEffect(() => {
    load();
  }, []);

  const createChain = async () => {
    if (!newName.trim()) return;
    const { error } = await supabase.from("approval_chains" as any).insert({
      name: newName.trim(),
      description: newDesc.trim() || null,
      module: newModule,
    } as any);
    if (error) toast({ title: tr("შეცდომა", "Error"), variant: "destructive" });
    else {
      toast({ title: tr("შექმნილია", "Created") });
      setCreateOpen(false);
      setNewName("");
      setNewDesc("");
      load();
    }
  };

  const deleteChain = async (id: string) => {
    if (!confirm(tr("წავშალოთ?", "Delete?"))) return;
    const { error } = await supabase.from("approval_chains" as any).delete().eq("id", id);
    if (error) { toast({ title: tr("შეცდომა: ცვლილება ვერ შეინახა", "Error: change not saved"), variant: "destructive" }); return; }
    if (selected?.id === id) setSelected(null);
    load();
  };

  const addStep = async (chain: Chain) => {
    const existing = steps[chain.id] || [];
    const order = (existing[existing.length - 1]?.step_order || 0) + 1;
    const { error } = await supabase.from("approval_chain_steps" as any).insert({
      chain_id: chain.id,
      step_order: order,
      approver_type: "role",
      approver_role: "manager",
    } as any);
    if (error) toast({ title: tr("შეცდომა", "Error"), variant: "destructive" });
    else load();
  };

  const updateStep = async (id: string, patch: Partial<ChainStep>) => {
    const { error } = await supabase.from("approval_chain_steps" as any).update(patch as any).eq("id", id);
    if (error) { toast({ title: tr("შეცდომა: ცვლილება ვერ შეინახა", "Error: change not saved"), variant: "destructive" }); return; }
    load();
  };

  const removeStep = async (id: string) => {
    const { error } = await supabase.from("approval_chain_steps" as any).delete().eq("id", id);
    if (error) { toast({ title: tr("შეცდომა: ცვლილება ვერ შეინახა", "Error: change not saved"), variant: "destructive" }); return; }
    load();
  };

  const moveStep = async (chainId: string, stepId: string, dir: -1 | 1) => {
    const chainSteps = [...(steps[chainId] || [])].sort((a, b) => a.step_order - b.step_order);
    const idx = chainSteps.findIndex((s) => s.id === stepId);
    const swapIdx = idx + dir;
    if (idx < 0 || swapIdx < 0 || swapIdx >= chainSteps.length) return;
    const a = chainSteps[idx];
    const b = chainSteps[swapIdx];
    await Promise.all([
      supabase.from("approval_chain_steps" as any).update({ step_order: b.step_order } as any).eq("id", a.id),
      supabase.from("approval_chain_steps" as any).update({ step_order: a.step_order } as any).eq("id", b.id),
    ]);
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <GitBranch className="h-8 w-8 text-primary" />
            {tr("მრავალდონიანი დამტკიცებები", "Multi-level Approvals")}
          </h1>
          <p className="text-muted-foreground mt-1">
            {tr("აწყვე დამტკიცების ჯაჭვი: მენეჯერი → HR → CFO", "Build approval chains: Manager → HR → CFO")}
          </p>
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="chains">{tr("ჯაჭვები", "Chains")}</TabsTrigger>
          <TabsTrigger value="requests">{tr("მოთხოვნები", "Requests")}</TabsTrigger>
        </TabsList>

        <TabsContent value="chains" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={createOpen} onOpenChange={setCreateOpen}>
              <DialogTrigger asChild>
                <Button variant="gradient">
                  <Plus className="mr-2 h-4 w-4" />
                  {tr("ახალი ჯაჭვი", "New Chain")}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{tr("ახალი ჯაჭვი", "New Chain")}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>{tr("სახელი", "Name")}</Label>
                    <Input value={newName} onChange={(e) => setNewName(e.target.value)} />
                  </div>
                  <div>
                    <Label>{tr("აღწერა", "Description")}</Label>
                    <Textarea value={newDesc} onChange={(e) => setNewDesc(e.target.value)} />
                  </div>
                  <div>
                    <Label>{tr("მოდული", "Module")}</Label>
                    <Select value={newModule} onValueChange={setNewModule}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {MODULES.map((m) => (
                          <SelectItem key={m.value} value={m.value}>{tr(m.ka, m.en)}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={createChain}>{tr("შექმნა", "Create")}</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          {chains.length === 0 && (
            <Card><CardContent className="py-12 text-center text-muted-foreground">
              {tr("ჯერ ჯაჭვები არ არის", "No chains yet")}
            </CardContent></Card>
          )}

          {chains.map((chain) => {
            const chainSteps = (steps[chain.id] || []).sort((a, b) => a.step_order - b.step_order);
            const moduleLabel = MODULES.find((m) => m.value === chain.module);
            return (
              <Card key={chain.id}>
                <CardHeader>
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div>
                      <CardTitle>{chain.name}</CardTitle>
                      <div className="flex gap-2 mt-1">
                        <Badge variant="outline">{moduleLabel ? tr(moduleLabel.ka, moduleLabel.en) : chain.module}</Badge>
                        {chain.description && <span className="text-sm text-muted-foreground">{chain.description}</span>}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button variant="outline" size="sm" onClick={() => addStep(chain)}>
                        <Plus className="h-3 w-3 mr-1" /> {tr("საფეხური", "Step")}
                      </Button>
                      <Button variant="destructive" size="sm" onClick={() => deleteChain(chain.id)}>
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap items-center gap-2">
                    {chainSteps.length === 0 && (
                      <p className="text-sm text-muted-foreground">{tr("საფეხურები არ არის", "No steps")}</p>
                    )}
                    {chainSteps.map((s, idx) => (
                      <div key={s.id} className="flex items-center gap-2">
                        <div className="border-2 border-primary/30 bg-card rounded-lg p-3 min-w-[200px]">
                          <div className="flex items-center justify-between gap-1 mb-2">
                            <Badge variant="default">{tr("საფეხური", "Step")} {s.step_order}</Badge>
                            <div className="flex gap-0.5">
                              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => moveStep(chain.id, s.id, -1)}>
                                <ArrowUp className="h-3 w-3" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => moveStep(chain.id, s.id, 1)}>
                                <ArrowDown className="h-3 w-3" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => removeStep(s.id)}>
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                          <Select
                            value={s.approver_type}
                            onValueChange={(v) => updateStep(s.id, { approver_type: v })}
                          >
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="role">{tr("როლი", "Role")}</SelectItem>
                              <SelectItem value="manager">{tr("პირდაპირი მენეჯერი", "Direct Manager")}</SelectItem>
                            </SelectContent>
                          </Select>
                          {s.approver_type === "role" && (
                            <Select
                              value={s.approver_role || "manager"}
                              onValueChange={(v) => updateStep(s.id, { approver_role: v })}
                            >
                              <SelectTrigger className="h-8 text-xs mt-1"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                {ROLES.map((r) => (
                                  <SelectItem key={r.value} value={r.value}>{tr(r.ka, r.en)}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          )}
                          <Input
                            type="number"
                            placeholder={tr("მინ. თანხა", "Min amount")}
                            className="h-8 text-xs mt-1"
                            value={s.min_amount ?? ""}
                            onChange={(e) => updateStep(s.id, { min_amount: e.target.value ? Number(e.target.value) : null })}
                          />
                        </div>
                        {idx < chainSteps.length - 1 && <ChevronRight className="h-5 w-5 text-muted-foreground shrink-0" />}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </TabsContent>

        <TabsContent value="requests" className="space-y-2">
          {requests.length === 0 && (
            <Card><CardContent className="py-12 text-center text-muted-foreground">
              {tr("მოთხოვნები არ არის", "No requests yet")}
            </CardContent></Card>
          )}
          {requests.map((r) => {
            const chain = chains.find((c) => c.id === r.chain_id);
            const totalSteps = chain ? (steps[chain.id] || []).length : 0;
            const StatusIcon = r.status === "approved" ? CheckCircle2 : r.status === "rejected" ? XCircle : Clock;
            const statusColor =
              r.status === "approved" ? "text-success" : r.status === "rejected" ? "text-destructive" : "text-warning";
            return (
              <Card key={r.id}>
                <CardContent className="py-4 flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-3">
                    <StatusIcon className={`h-5 w-5 ${statusColor}`} />
                    <div>
                      <div className="font-medium">{chain?.name || r.module}</div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(r.created_at).toLocaleString(language === "en" ? "en-US" : "ka-GE")}
                        {r.amount != null && ` • ${r.amount} ₾`}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">
                      {tr("საფეხური", "Step")} {r.current_step}/{totalSteps || "?"}
                    </Badge>
                    <Badge variant={r.status === "approved" ? "default" : r.status === "rejected" ? "destructive" : "secondary"}>
                      {r.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </TabsContent>
      </Tabs>
    </div>
  );
}
