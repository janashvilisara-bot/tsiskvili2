import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Clock, MapPin, CheckCircle, XCircle, Calendar, User, PartyPopper, AlertCircle, TrendingUp, Activity, ArrowLeft, MessageSquare, ShieldAlert } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useSwipe } from "@/hooks/use-swipe";
import { useNavigate } from "react-router-dom";
import { checkLocationValidity, formatDistance, type OfficeLocation } from "@/lib/geofencing";
import { withRetry } from "@/lib/supabaseRetry";

interface AttendanceRecord {
  id: string;
  date: string;
  check_in: string | null;
  check_out: string | null;
  status: string;
  check_in_location: string | null;
  check_out_location: string | null;
  break_duration: number | null;
  notes: string | null;
  lateness_comment: string | null;
}

interface PublicHoliday {
  id: string;
  name: string;
  holiday_date: string;
  is_recurring: boolean;
  is_active: boolean;
}

export default function MobileAttendance() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [location, setLocation] = useState<{ lat: number; lon: number } | null>(null);
  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord | null>(null);
  const [recentAttendance, setRecentAttendance] = useState<AttendanceRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [employee, setEmployee] = useState<any>(null);
  const [publicHolidays, setPublicHolidays] = useState<PublicHoliday[]>([]);
  const [todayHoliday, setTodayHoliday] = useState<PublicHoliday | null>(null);
  const [currentView, setCurrentView] = useState<'today' | 'history'>('today');
  const [showLatenessDialog, setShowLatenessDialog] = useState(false);
  const [latenessComment, setLatenessComment] = useState("");
  const [officeLocations, setOfficeLocations] = useState<OfficeLocation[]>([]);
  const [locationWarning, setLocationWarning] = useState<string | null>(null);

  const swipeHandlers = useSwipe({
    onSwipeLeft: () => setCurrentView('history'),
    onSwipeRight: () => setCurrentView('today'),
  });

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (user) {
      fetchEmployee();
      fetchPublicHolidays();
      fetchOfficeLocations();
    }
  }, [user]);

  useEffect(() => {
    if (employee && publicHolidays.length >= 0) {
      fetchTodayAttendance();
      fetchRecentAttendance();
      checkTodayHoliday();
    }
  }, [employee, publicHolidays]);

  useEffect(() => {
    // Check location validity when location or office locations change
    if (location && officeLocations.length > 0) {
      const result = checkLocationValidity(location, officeLocations);
      if (!result.isValid && result.nearestOffice) {
        setLocationWarning(`თქვენ ხართ ოფისიდან ${formatDistance(result.distance)} მოშორებით`);
      } else {
        setLocationWarning(null);
      }
    }
  }, [location, officeLocations]);

  const fetchOfficeLocations = async () => {
    try {
      const { data, error } = await supabase
        .from("office_locations")
        .select("*")
        .eq("is_active", true);

      if (error) throw error;
      setOfficeLocations(data || []);
    } catch (error: any) {
      console.error("Error fetching office locations:", error);
    }
  };

  const fetchPublicHolidays = async () => {
    try {
      const { data, error } = await supabase
        .from("public_holidays")
        .select("*")
        .eq("is_active", true);

      if (error) throw error;
      setPublicHolidays(data || []);
    } catch (error: any) {
      console.error("Error fetching public holidays:", error);
    }
  };

  const checkTodayHoliday = () => {
    const today = new Date().toISOString().split('T')[0];
    const holiday = publicHolidays.find(h => {
      if (h.is_recurring) {
        const holidayMonthDay = h.holiday_date.substring(5);
        const todayMonthDay = today.substring(5);
        return holidayMonthDay === todayMonthDay;
      }
      return h.holiday_date === today;
    });
    setTodayHoliday(holiday || null);
  };

  useEffect(() => {
    requestLocation();
  }, []);

  const fetchEmployee = async () => {
    if (!user?.id) {
      console.error("User ID not found");
      toast.error("მომხმარებელი არ არის ავტორიზებული");
      return;
    }
    
    
    // First try to find by user_id (preferred method for authenticated users)
    let { data, error } = await supabase
      .from('employees')
      .select('*')
      .eq('user_id', user.id)
      .eq('status', 'active')
      .limit(1);
    
    // If not found by user_id, fall back to email search
    if ((!data || data.length === 0) && user.email) {
      const emailResult = await supabase
        .from('employees')
        .select('*')
        .eq('email', user.email)
        .eq('status', 'active')
        .limit(1);
      
      data = emailResult.data;
      error = emailResult.error;
    }
    
    if (error) {
      console.error("Error fetching employee:", error);
      toast.error("შეცდომა თანამშრომლის მოძიებისას: " + error.message);
      return;
    }
    
    if (!data || data.length === 0) {
      console.error("No active employee found for user:", user.id, user.email);
      toast.error("აქტიური თანამშრომელი არ მოიძებნა. დარწმუნდით, რომ თქვენი თანამშრომლის პროფილი დაკავშირებულია თქვენს ანგარიშთან და სტატუსი აქტიურია.");
      return;
    }
    
    setEmployee(data[0]);
  };

  const requestLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lon: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Location error:", error);
          toast.error("ლოკაციის წვდომა შეზღუდულია");
        }
      );
    }
  };

  const fetchTodayAttendance = async () => {
    if (!employee) return;
    
    const today = new Date().toISOString().split('T')[0];
    const { data } = await supabase
      .from('attendance')
      .select('*')
      .eq('employee_id', employee.id)
      .eq('date', today)
      .limit(1)
      .maybeSingle();
    
    setTodayAttendance(data);
  };

  const fetchRecentAttendance = async () => {
    if (!employee) return;
    
    const { data } = await supabase
      .from('attendance')
      .select('*')
      .eq('employee_id', employee.id)
      .order('date', { ascending: false })
      .limit(7);
    
    setRecentAttendance(data || []);
  };

  const handleCheckIn = async () => {
    if (!employee) {
      toast.error("თანამშრომელი არ მოიძებნა");
      return;
    }

    // Check if employee has mobile attendance method enabled
    if (employee.attendance_method && employee.attendance_method !== 'mobile') {
      toast.error("თქვენ არ გაქვთ მობილურით აღრიცხვის უფლება. თქვენი აღრიცხვის მეთოდია: " + (employee.attendance_method === 'turnstile' ? 'ტურნიკეტი' : employee.attendance_method));
      return;
    }

    setIsLoading(true);
    try {
      const now = new Date();
      const today = now.toISOString().split('T')[0];
      const time = now.toTimeString().split(' ')[0];
      const locationStr = location ? `${location.lat}, ${location.lon}` : null;

      // Check geofencing - is the employee within office radius?
      let isSuspiciousLocation = false;
      let nearestOfficeName = '';
      let distanceFromOffice = 0;

      if (location && officeLocations.length > 0) {
        const geoResult = checkLocationValidity(location, officeLocations);
        isSuspiciousLocation = !geoResult.isValid;
        nearestOfficeName = geoResult.nearestOffice?.name || '';
        distanceFromOffice = geoResult.distance;
      }

      // Fetch employee's work schedule to check if late
      const { data: scheduleData } = await supabase
        .from('work_schedules')
        .select('schedule_type, start_time')
        .eq('employee_id', employee.id)
        .single();

      let isLate = false;
      if (scheduleData?.start_time) {
        const scheduledStartTime = scheduleData.start_time.substring(0, 5);
        const currentTime = time.substring(0, 5);
        isLate = currentTime > scheduledStartTime;
      }

      // Insert attendance record (with retry for peak-load resilience)
      const { data: attendanceData, error } = await withRetry(() =>
        supabase
          .from('attendance')
          .insert([{
            employee_id: employee.id,
            branch_id: employee.branch_id,
            date: today,
            check_in: time,
            check_in_location: locationStr,
            check_in_method: 'mobile',
            status: 'present',
            is_suspicious_location: isSuspiciousLocation,
          }])
          .select()
          .single()
      );

      if (error) throw error;

      // If suspicious location, create an alert for HR
      if (isSuspiciousLocation && attendanceData) {
        await supabase
          .from('location_alerts')
          .insert([{
            attendance_id: attendanceData.id,
            employee_id: employee.id,
            expected_location: nearestOfficeName,
            actual_location: locationStr,
            distance_meters: distanceFromOffice,
            status: 'pending',
          }]);

        toast.warning("შემოსვლა აღირიცხა, მაგრამ თქვენი ლოკაცია ოფისის არეალს გარეთაა. HR-ს ეცნობება.");
      } else {
        toast.success("შემოსვლა აღირიცხა მობილურით!");
      }
      
      await fetchTodayAttendance();
      await fetchRecentAttendance();

      // If late, show dialog to add comment
      if (isLate) {
        setShowLatenessDialog(true);
      }
    } catch (error: any) {
      toast.error(error.message || "შეცდომა მოხდა");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveLatenessComment = async () => {
    if (!todayAttendance) return;

    try {
      const { error } = await supabase
        .from('attendance')
        .update({ lateness_comment: latenessComment.trim() || null })
        .eq('id', todayAttendance.id);

      if (error) throw error;

      toast.success("კომენტარი დამატებულია");
      setShowLatenessDialog(false);
      setLatenessComment("");
      await fetchTodayAttendance();
    } catch (error: any) {
      toast.error(error.message || "შეცდომა მოხდა");
    }
  };

  const handleCheckOut = async () => {
    if (!todayAttendance) return;

    // Check if employee has mobile attendance method enabled
    if (employee?.attendance_method && employee.attendance_method !== 'mobile') {
      toast.error("თქვენ არ გაქვთ მობილურით აღრიცხვის უფლება. თქვენი აღრიცხვის მეთოდია: " + (employee.attendance_method === 'turnstile' ? 'ტურნიკეტი' : employee.attendance_method));
      return;
    }

    setIsLoading(true);
    try {
      const now = new Date();
      const time = now.toTimeString().split(' ')[0];
      const locationStr = location ? `${location.lat}, ${location.lon}` : null;

      const { error } = await supabase
        .from('attendance')
        .update({
          check_out: time,
          check_out_location: locationStr,
          check_out_method: 'mobile',
        })
        .eq('id', todayAttendance.id);

      if (error) throw error;
      
      toast.success("გასვლა აღირიცხა მობილურით!");
      fetchTodayAttendance();
      fetchRecentAttendance();
    } catch (error: any) {
      toast.error(error.message || "შეცდომა მოხდა");
    } finally {
      setIsLoading(false);
    }
  };

  const formatTime = (time: string | null) => {
    if (!time) return '-';
    return time.substring(0, 5);
  };

  const isCheckedIn = todayAttendance && todayAttendance.check_in && !todayAttendance.check_out;
  const isCheckedOut = todayAttendance && todayAttendance.check_out;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring" as const,
        stiffness: 100
      }
    }
  };

  return (
    <motion.div 
      className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5 p-4 pb-20"
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      {...swipeHandlers}
    >
      {/* Header with Gradient */}
      <motion.div 
        className="mb-6 text-center relative"
        variants={itemVariants}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 blur-3xl -z-10" />
        <div className="flex items-center justify-center gap-3 mb-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/employee-portal')}
            className="text-muted-foreground hover:text-foreground hover:bg-accent/20"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-3xl font-bold flex items-center gap-3 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            <Clock className="h-8 w-8 text-primary animate-pulse" />
            დროის აღრიცხვა
          </h1>
        </div>
        {employee && (
          <motion.p 
            className="text-muted-foreground mt-2 flex items-center justify-center gap-2"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <User className="h-4 w-4" />
            {employee.full_name}
          </motion.p>
        )}
      </motion.div>

      {/* View Tabs */}
      <motion.div 
        className="flex gap-2 mb-6 p-1 bg-muted/50 rounded-lg backdrop-blur-sm"
        variants={itemVariants}
      >
        <button
          onClick={() => setCurrentView('today')}
          className={`flex-1 py-3 px-4 rounded-md transition-all duration-300 font-medium ${
            currentView === 'today'
              ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/20'
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          დღევანდელი
        </button>
        <button
          onClick={() => setCurrentView('history')}
          className={`flex-1 py-3 px-4 rounded-md transition-all duration-300 font-medium ${
            currentView === 'history'
              ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/20'
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          ისტორია
        </button>
      </motion.div>

      <AnimatePresence mode="wait">
        {currentView === 'today' ? (
          <motion.div
            key="today"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.3 }}
          >
            {/* Holiday Warning */}
            {todayHoliday && (
              <motion.div variants={itemVariants}>
                <Card className="mb-4 border-orange-500/50 bg-gradient-to-br from-orange-50 to-orange-100/50 dark:from-orange-950/20 dark:to-orange-900/10 shadow-lg">
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-orange-500/20 rounded-full">
                        <PartyPopper className="h-6 w-6 text-orange-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-orange-900 dark:text-orange-100">
                          {todayHoliday.name}
                        </h3>
                        <p className="text-sm text-orange-700 dark:text-orange-300 flex items-center gap-1.5 mt-1">
                          <AlertCircle className="h-3.5 w-3.5" />
                          დღეს ოფიციალური დასვენების დღეა. მუშაობა ჩაითვლება ოვერთაიმად.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Current Time Card with Gradient */}
            <motion.div variants={itemVariants}>
              <Card className="mb-6 bg-gradient-to-br from-primary via-primary to-accent text-white shadow-xl shadow-primary/20 border-0 overflow-hidden">
                <div className="absolute inset-0 bg-grid-white/[0.05] pointer-events-none" />
                <CardContent className="pt-8 pb-8 text-center relative">
                  <motion.div 
                    className="text-6xl font-bold mb-3 tabular-nums"
                    animate={{ scale: [1, 1.02, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    {currentTime.toLocaleTimeString('ka-GE', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </motion.div>
                  <div className="text-lg opacity-90 flex items-center justify-center gap-2 mb-3">
                    <Calendar className="h-5 w-5" />
                    {currentTime.toLocaleDateString('ka-GE', { 
                      weekday: 'long', 
                      day: 'numeric',
                      month: 'long'
                    })}
                  </div>
                  {location && (
                    <motion.div 
                      className="mt-4 flex items-center justify-center gap-2 text-sm opacity-80 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 mx-auto w-fit"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <MapPin className="h-4 w-4" />
                      <span>ლოკაცია დადასტურებულია</span>
                    </motion.div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Check In/Out Buttons with Animation */}
            {employee?.attendance_method === 'turnstile' ? (
              <motion.div variants={itemVariants}>
                <Card className="bg-gradient-to-br from-orange-50 to-orange-100/50 dark:from-orange-950/20 dark:to-orange-900/10 border-orange-500/50">
                  <CardContent className="pt-6 pb-6 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="p-4 bg-orange-500/20 rounded-full">
                        <AlertCircle className="h-10 w-10 text-orange-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-orange-900 dark:text-orange-100 mb-2">
                          ტურნიკეტით აღრიცხვა
                        </h3>
                        <p className="text-sm text-orange-700 dark:text-orange-300">
                          თქვენი აღრიცხვის მეთოდი განსაზღვრულია როგორც ტურნიკეტი. გთხოვთ გამოიყენოთ ტურნიკეტი შემოსვლისა და გასვლის აღსარიცხად.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ) : (
              <motion.div 
                className="grid grid-cols-2 gap-4 mb-6"
                variants={itemVariants}
              >
                <motion.div
                  whileTap={{ scale: 0.95 }}
                  whileHover={{ scale: 1.02 }}
                >
                  <Button
                    size="lg"
                    onClick={handleCheckIn}
                    disabled={isLoading || !!isCheckedIn || !!isCheckedOut}
                    className="h-28 w-full flex flex-col gap-3 bg-gradient-to-br from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 shadow-lg shadow-green-500/20 border-0"
                  >
                    <div className="p-3 bg-white/20 rounded-full">
                      <CheckCircle className="h-8 w-8" />
                    </div>
                    <span className="text-lg font-semibold">შემოსვლა</span>
                  </Button>
                </motion.div>
                <motion.div
                  whileTap={{ scale: 0.95 }}
                  whileHover={{ scale: 1.02 }}
                >
                  <Button
                    size="lg"
                    onClick={handleCheckOut}
                    disabled={isLoading || !isCheckedIn || !!isCheckedOut}
                    className="h-28 w-full flex flex-col gap-3 bg-gradient-to-br from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 shadow-lg shadow-red-500/20 border-0"
                  >
                  <div className="p-3 bg-white/20 rounded-full">
                    <XCircle className="h-8 w-8" />
                  </div>
                  <span className="text-lg font-semibold">გასვლა</span>
                </Button>
              </motion.div>
            </motion.div>
            )}

            {/* Today's Status with Enhanced Design */}
            {todayAttendance && (
              <motion.div variants={itemVariants}>
                <Card className="mb-6 border-2 shadow-lg hover:shadow-xl transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Activity className="h-5 w-5 text-primary" />
                      დღევანდელი სტატუსი
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-green-50 to-green-100/50 dark:from-green-950/20 dark:to-green-900/10">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                        <span className="text-muted-foreground">შემოსვლა</span>
                      </div>
                      <span className="font-bold text-lg">{formatTime(todayAttendance.check_in)}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-red-50 to-red-100/50 dark:from-red-950/20 dark:to-red-900/10">
                      <div className="flex items-center gap-2">
                        <div className={`h-2 w-2 rounded-full ${isCheckedOut ? 'bg-red-500' : 'bg-gray-300'} ${isCheckedOut && 'animate-pulse'}`} />
                        <span className="text-muted-foreground">გასვლა</span>
                      </div>
                      <span className="font-bold text-lg">{formatTime(todayAttendance.check_out)}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <span className="text-muted-foreground">სტატუსი</span>
                      <Badge 
                        variant={isCheckedOut ? "secondary" : "default"}
                        className="px-4 py-1 text-sm font-medium"
                      >
                        {isCheckedOut ? "დასრულებული" : "მიმდინარე"}
                      </Badge>
                    </div>
                    {todayAttendance.lateness_comment && (
                      <div className="p-3 rounded-lg bg-gradient-to-r from-amber-50 to-amber-100/50 dark:from-amber-950/20 dark:to-amber-900/10">
                        <div className="flex items-start gap-2">
                          <MessageSquare className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
                          <div>
                            <span className="text-sm font-medium text-amber-900 dark:text-amber-100">დაგვიანების მიზეზი:</span>
                            <p className="text-sm text-amber-700 dark:text-amber-300 mt-1">{todayAttendance.lateness_comment}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Add Lateness Comment Button */}
            {todayAttendance && !todayAttendance.lateness_comment && (
              <motion.div variants={itemVariants}>
                <Button
                  variant="outline"
                  className="w-full mb-6 h-auto py-4 border-dashed hover:bg-accent/10"
                  onClick={() => setShowLatenessDialog(true)}
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  დაამატე კომენტარი დაგვიანებაზე
                </Button>
              </motion.div>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="history"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="space-y-4"
          >
            <motion.div variants={itemVariants}>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    დასწრების ისტორია
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {recentAttendance.map((record, index) => (
                    <motion.div
                      key={record.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="p-4 rounded-lg border bg-gradient-to-r from-card to-muted/20 hover:shadow-md transition-all"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div className="h-2 w-2 rounded-full bg-primary" />
                          <div>
                            <div className="font-medium">
                              {new Date(record.date).toLocaleDateString('ka-GE', { 
                                day: 'numeric',
                                month: 'long'
                              })}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {new Date(record.date).toLocaleDateString('ka-GE', { 
                                weekday: 'long'
                              })}
                            </div>
                          </div>
                        </div>
                        <Badge variant="outline" className={
                          record.status === 'present' ? 'bg-green-50 text-green-700 border-green-200' :
                          record.status === 'late' ? 'bg-orange-50 text-orange-700 border-orange-200' :
                          'bg-red-50 text-red-700 border-red-200'
                        }>
                          {record.status === 'present' ? 'დამსწრე' : record.status === 'late' ? 'დაგვიანება' : 'არმყოფი'}
                        </Badge>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="grid grid-cols-2 gap-2">
                          <div className="flex items-center gap-1.5 text-muted-foreground">
                            <CheckCircle className="h-3.5 w-3.5 text-green-500" />
                            <span className="text-xs">შემოსვლა:</span>
                            <span className="font-medium">{formatTime(record.check_in)}</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-muted-foreground">
                            <XCircle className="h-3.5 w-3.5 text-red-500" />
                            <span className="text-xs">გასვლა:</span>
                            <span className="font-medium">{formatTime(record.check_out)}</span>
                          </div>
                        </div>
                        {record.break_duration && record.break_duration > 0 && (
                          <div className="flex items-center gap-1.5 text-muted-foreground text-xs pt-1 border-t">
                            <Clock className="h-3 w-3" />
                            <span>შესვენება: {record.break_duration} წთ</span>
                          </div>
                        )}
                        {record.notes && (
                          <div className="text-muted-foreground text-xs pt-1 border-t">
                            <div className="flex items-start gap-1">
                              <span className="font-medium">კომენტარი:</span>
                              <span className="flex-1">{record.notes}</span>
                            </div>
                          </div>
                        )}
                        {record.check_in_location && (
                          <div className="text-muted-foreground text-xs pt-1 border-t">
                            <div className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              <span>ლოკაცია ფიქსირებული</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                  {recentAttendance.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      ისტორია ცარიელია
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Swipe Hint */}
      <motion.div 
        className="fixed bottom-6 left-1/2 -translate-x-1/2 text-xs text-muted-foreground/50 flex items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <motion.div
          animate={{ x: [-5, 5, -5] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          ←
        </motion.div>
        გადაფურცლეთ გვერდებს შორის
        <motion.div
          animate={{ x: [-5, 5, -5] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          →
        </motion.div>
      </motion.div>

      {/* Lateness Comment Dialog */}
      <Dialog open={showLatenessDialog} onOpenChange={setShowLatenessDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-primary" />
              დაგვიანების მიზეზი
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-sm text-muted-foreground">
              გთხოვთ, აღწეროთ დაგვიანების მიზეზი:
            </p>
            <Textarea
              placeholder="მაგ: საცობები, ავტობუსის დაგვიანება და ა.შ."
              value={latenessComment}
              onChange={(e) => setLatenessComment(e.target.value)}
              className="min-h-[100px]"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowLatenessDialog(false);
              setLatenessComment("");
            }}>
              გაუქმება
            </Button>
            <Button onClick={handleSaveLatenessComment}>
              შენახვა
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
