import { useState, useEffect } from "react";
import { useFeatureLock, FeatureLockOverlay } from "@/components/FeatureCardLock";
import { 
  DollarSign,
  Wallet,
  Briefcase,
  Shield,
  Coins,
  FileText,
  ArrowRight,
  Sparkles,
  TrendingUp,
  TrendingDown,
  Users,
  Calendar,
  PiggyBank,
  Receipt,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3
} from "lucide-react";
import { PageTransition } from "@/components/PageTransition";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import HubErrorState from "@/components/HubErrorState";
import { cn } from "@/lib/utils";

interface FinanceStats {
  totalPayroll: number;
  totalBudget: number;
  totalAssets: number;
  pendingCompensations: number;
  activeEmployees: number;
  budgetUsed: number;
}

export default function Finance() {
  const navigate = useNavigate();
  const { isLocked, handleLockedClick } = useFeatureLock();
  const [stats, setStats] = useState<FinanceStats>({
    totalPayroll: 0,
    totalBudget: 0,
    totalAssets: 0,
    pendingCompensations: 0,
    activeEmployees: 0,
    budgetUsed: 0
  });
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState(false);

  useEffect(() => {
    fetchFinanceStats();
  }, []);

  const fetchFinanceStats = async () => {
    try {
      // Fetch active employees count
      const { count: employeeCount } = await supabase
        .from('employees')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Fetch total payroll (sum of salaries)
      const { data: employees } = await supabase
        .from('employees')
        .select('salary')
        .eq('status', 'active');

      const totalPayroll = employees?.reduce((sum, emp) => sum + (emp.salary || 0), 0) || 0;

      // Fetch budget plans for current year
      const currentYear = new Date().getFullYear();
      const { data: budgetPlans } = await supabase
        .from('budget_plans')
        .select('planned_amount, actual_amount')
        .eq('fiscal_year', currentYear);

      const totalBudget = budgetPlans?.reduce((sum, plan) => sum + (plan.planned_amount || 0), 0) || 0;
      const budgetUsed = budgetPlans?.reduce((sum, plan) => sum + (plan.actual_amount || 0), 0) || 0;

      // Fetch assets count
      const { count: assetCount } = await supabase
        .from('assets')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Fetch pending compensations
      const { count: pendingCount } = await supabase
        .from('compensation')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');

      setStats({
        totalPayroll,
        totalBudget,
        totalAssets: assetCount || 0,
        pendingCompensations: pendingCount || 0,
        activeEmployees: employeeCount || 0,
        budgetUsed
      });
    } catch (error) {
      console.error('Error fetching finance stats:', error);
      setFetchError(true);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ka-GE', {
      style: 'currency',
      currency: 'GEL',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const quickStats = [
    {
      title: "მთლიანი ხელფასები",
      value: formatCurrency(stats.totalPayroll),
      icon: DollarSign,
      color: "from-emerald-500 to-green-600",
      bgColor: "bg-emerald-500/10",
      trend: "+12%",
      trendUp: true,
      description: "ყოველთვიური"
    },
    {
      title: "წლიური ბიუჯეტი",
      value: formatCurrency(stats.totalBudget),
      icon: PiggyBank,
      color: "from-blue-500 to-indigo-600",
      bgColor: "bg-blue-500/10",
      trend: stats.totalBudget > 0 ? `${Math.round((stats.budgetUsed / stats.totalBudget) * 100)}%` : "0%",
      trendUp: stats.budgetUsed < stats.totalBudget * 0.8,
      description: "გამოყენებული"
    },
    {
      title: "აქტიური აქტივები",
      value: stats.totalAssets.toString(),
      icon: Briefcase,
      color: "from-purple-500 to-violet-600",
      bgColor: "bg-purple-500/10",
      trend: "+5",
      trendUp: true,
      description: "ერთეული"
    },
    {
      title: "მომლოდინე კომპენსაციები",
      value: stats.pendingCompensations.toString(),
      icon: Receipt,
      color: "from-orange-500 to-amber-600",
      bgColor: "bg-orange-500/10",
      trend: stats.pendingCompensations > 0 ? "საჭიროებს ყურადღებას" : "დასრულებული",
      trendUp: stats.pendingCompensations === 0,
      description: "მოთხოვნა"
    }
  ];

  const categories = [
    {
      title: "ძირითადი ფუნქციები",
      description: "ფინანსური მართვის ცენტრალური სერვისები",
      icon: DollarSign,
      color: "from-emerald-400 via-green-500 to-teal-500",
      shadowColor: "shadow-emerald-500/25",
      functions: [
        { 
          name: "ხელფასები", 
          description: "ხელფასების დარიცხვა და მართვა",
          url: "/payroll",
          icon: DollarSign,
          stats: `${stats.activeEmployees} თანამშრომელი`
        },
        { 
          name: "ბიუჯეტი", 
          description: "ბიუჯეტის დაგეგმვა და კონტროლი",
          url: "/budget-planning",
          icon: Wallet,
          stats: formatCurrency(stats.totalBudget)
        },
        { 
          name: "აქტივები", 
          description: "კომპანიის აქტივების აღრიცხვა",
          url: "/assets",
          icon: Briefcase,
          stats: `${stats.totalAssets} ერთეული`
        },
        { 
          name: "სარგებლები", 
          description: "თანამშრომლების სარგებლების მართვა",
          url: "/benefits-admin",
          icon: Shield,
          stats: "აქტიური"
        },
        { 
          name: "კომპენსაცია", 
          description: "ბონუსები და დამატებითი კომპენსაციები",
          url: "/compensation",
          icon: Receipt,
          stats: `${stats.pendingCompensations} მომლოდინე`
        },
        {
          name: "ფინანსური დაშბორდი",
          description: "Tax დაზოგვა · ხელფასის სკალა · ბიუჯეტი vs ფაქტი",
          url: "/financial-dashboard",
          icon: BarChart3,
          stats: "ანალიტიკა"
        },
        {
          name: "ფინანსური ანალიტიკა",
          description: "ხელფასი vs წინა წელი თვეების მიხედვით",
          url: "/financial-analytics",
          icon: TrendingUp,
          stats: "თვეების trend"
        },
      ]
    },
    {
      title: "დამატებითი სერვისები",
      description: "საპენსიო გადახდები",
      icon: Coins,
      color: "from-amber-400 via-orange-500 to-red-500",
      shadowColor: "shadow-orange-500/25",
      functions: [
        { 
          name: "საპენსიო გადახდები", 
          description: "საპენსიო ანგარიშსწორებების მართვა",
          url: "/pension-payments",
          icon: PiggyBank,
          stats: "2% სავალდებულო"
        },
      ]
    }
  ];

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {fetchError && <HubErrorState onRetry={fetchFinanceStats} />}
          {/* Header */}
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-400 via-green-500 to-teal-500 shadow-xl shadow-emerald-500/30 animate-scale-in">
                <DollarSign className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-foreground via-foreground/90 to-foreground/70 bg-clip-text text-transparent">
                  ფინანსები
                </h1>
                <p className="text-muted-foreground mt-1 text-lg">
                  ფინანსური მართვისა და ბუღალტერიის სისტემა
                </p>
              </div>
            </div>
          </div>

          {/* Quick Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {quickStats.map((stat, index) => (
              <Card 
                key={index}
                className={cn(
                  "group relative overflow-hidden border-border/50 bg-card/80 backdrop-blur-xl",
                  "hover:shadow-2xl hover:border-primary/30 transition-all duration-500 hover:-translate-y-2",
                  "animate-fade-in"
                )}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {/* Background gradient on hover */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <CardContent className="p-6 relative">
                  <div className="flex items-start justify-between mb-4">
                    <div className={cn(
                      "p-3 rounded-xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-3",
                      stat.bgColor
                    )}>
                      <stat.icon className={cn(
                        "h-6 w-6 bg-gradient-to-br bg-clip-text",
                        stat.color
                      )} style={{ color: 'transparent', backgroundImage: `linear-gradient(to bottom right, var(--tw-gradient-stops))` }} />
                    </div>
                    
                    <div className={cn(
                      "flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full transition-all duration-300",
                      stat.trendUp 
                        ? "text-emerald-600 bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-400" 
                        : "text-amber-600 bg-amber-100 dark:bg-amber-950/50 dark:text-amber-400"
                    )}>
                      {stat.trendUp ? (
                        <ArrowUpRight className="h-3 w-3" />
                      ) : (
                        <ArrowDownRight className="h-3 w-3" />
                      )}
                      <span>{stat.trend}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-2xl md:text-3xl font-bold tracking-tight group-hover:scale-105 transition-transform duration-300 origin-left">
                      {loading ? (
                        <div className="h-8 w-24 bg-muted animate-pulse rounded" />
                      ) : (
                        stat.value
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground font-medium">
                      {stat.title}
                    </div>
                    <div className="text-xs text-muted-foreground/70">
                      {stat.description}
                    </div>
                  </div>

                  {/* Decorative blur */}
                  <div className={cn(
                    "absolute -right-8 -bottom-8 w-32 h-32 rounded-full blur-3xl opacity-0 group-hover:opacity-30 transition-opacity duration-500",
                    `bg-gradient-to-br ${stat.color}`
                  )} />
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Categories */}
          <div className="space-y-10">
            {categories.map((category, idx) => (
              <div 
                key={idx} 
                className="space-y-6 animate-fade-in"
                style={{ animationDelay: `${(idx + 4) * 100}ms` }}
              >
                {/* Category Header */}
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "p-3 rounded-xl bg-gradient-to-br shadow-xl",
                    category.color,
                    category.shadowColor
                  )}>
                    <category.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl md:text-3xl font-bold text-foreground">{category.title}</h2>
                    <p className="text-sm text-muted-foreground">{category.description}</p>
                  </div>
                </div>

                {/* Function Cards Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
                  {category.functions.map((func, funcIdx) => (
                    <Card
                      key={funcIdx}
                      className={cn(
                        "group cursor-pointer overflow-hidden",
                        "border-border/50 bg-card/80 backdrop-blur-xl",
                        "hover:border-primary/50 transition-all duration-500",
                        "hover:shadow-2xl hover:-translate-y-2",
                        "animate-fade-in"
                      )}
                      style={{ animationDelay: `${(idx * 4 + funcIdx + 5) * 50}ms` }}
                      onClick={(e) => isLocked(func.url) ? handleLockedClick(e) : navigate(func.url)}
                    >
                      {isLocked(func.url) && <FeatureLockOverlay />}
                      {/* Gradient Header */}
                      <CardHeader className={cn(
                        "bg-gradient-to-br text-white pb-4 relative overflow-hidden",
                        category.color
                      )}>
                        <div className="flex items-center gap-3 relative z-10">
                          <div className="p-2.5 bg-white/20 rounded-xl backdrop-blur-sm group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                            <func.icon className="h-5 w-5" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{func.name}</CardTitle>
                            <span className="text-xs text-white/80">{func.stats}</span>
                          </div>
                        </div>
                        
                        {/* Decorative circles */}
                        <div className="absolute -right-4 -top-4 w-20 h-20 bg-white/10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700" />
                        <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white/5 rounded-full group-hover:scale-125 transition-transform duration-500" />
                      </CardHeader>
                      
                      <CardContent className="pt-6 relative">
                        <CardDescription className="text-muted-foreground mb-4 min-h-[48px] leading-relaxed">
                          {func.description}
                        </CardDescription>
                        
                        <div className="flex items-center gap-2 text-primary font-semibold text-sm group-hover:gap-4 transition-all duration-300">
                          <span>გახსნა</span>
                          <ArrowRight className="h-4 w-4 group-hover:translate-x-2 transition-transform duration-300" />
                        </div>

                        {/* Hover gradient overlay */}
                        <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Enhanced Footer Stats */}
          <div 
            className="mt-12 p-6 md:p-8 rounded-2xl bg-gradient-to-r from-primary/5 via-primary/10 to-accent/10 border border-primary/20 backdrop-blur-xl animate-fade-in"
            style={{ animationDelay: '800ms' }}
          >
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-primary/10 animate-pulse">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-lg font-semibold text-foreground">
                    სულ ხელმისაწვდომია <span className="text-2xl font-bold text-primary">{categories.reduce((sum, cat) => sum + cat.functions.length, 0)}</span> ფინანსური ფუნქცია
                  </p>
                  <p className="text-sm text-muted-foreground">
                    მართეთ თქვენი კომპანიის ფინანსები ეფექტურად
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-sm font-medium">{stats.activeEmployees} აქტიური თანამშრომელი</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
