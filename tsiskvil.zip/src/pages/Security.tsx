import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, AlertTriangle, FileText, Lock, UserCheck, Clock, Activity, Database, FileSearch, Scale, Users, Key, LockKeyhole, Unlock, Eye, EyeOff } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";

interface AuditLog {
  id: string;
  user_id: string;
  action_type: string;
  resource_type: string;
  resource_id: string;
  details: any;
  ip_address: string;
  status: string;
  created_at: string;
}

interface SecurityEvent {
  id: string;
  event_type: string;
  severity: string;
  user_id: string | null;
  description: string;
  metadata: any;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
}

interface AccountLockout {
  id: string;
  email: string;
  failed_attempts: number;
  locked_at: string;
  locked_until: string;
  unlock_token: string | null;
}

interface PasswordPolicy {
  id: string;
  min_length: number;
  require_uppercase: boolean;
  require_lowercase: boolean;
  require_numbers: boolean;
  require_special_chars: boolean;
  password_expiry_days: number;
  password_history_count: number;
  is_active: boolean;
}

interface SecurityIncident {
  id: string;
  incident_type: string;
  severity: string;
  status: string;
  title: string;
  description: string;
  detected_at: string;
  reported_by: string;
  assigned_to: string;
}

interface DataClassification {
  id: string;
  table_name: string;
  column_name: string;
  classification_level: string;
  sensitivity_reason: string;
  encryption_required: boolean;
  access_control_level: string;
}

interface ComplianceReport {
  id: string;
  report_type: string;
  report_period_start: string;
  report_period_end: string;
  status: string;
  created_at: string;
}

interface UserConsent {
  id: string;
  user_id: string;
  consent_type: string;
  consent_given: boolean;
  given_at: string;
  withdrawn_at: string;
}

interface ProcessingActivity {
  id: string;
  activity_name: string;
  activity_name_ka: string;
  purpose: string;
  legal_basis: string;
  data_categories: string[];
  data_subjects: string[];
  retention_period: string;
  is_active: boolean;
}

interface DSRRequest {
  id: string;
  request_type: string;
  request_type_ka: string;
  requester_name: string;
  requester_email: string;
  status: string;
  priority: string;
  deadline: string;
  created_at: string;
}

interface DataBreach {
  id: string;
  breach_type: string;
  severity: string;
  status: string;
  description: string;
  discovery_date: string;
  affected_individuals_notified: boolean;
  supervisory_authority_notified: boolean;
}

interface DPIAAssessment {
  id: string;
  assessment_name: string;
  risk_level: string;
  status: string;
  assessed_by: string;
  approved_at: string;
}

export default function Security() {
  const { toast } = useToast();
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [incidents, setIncidents] = useState<SecurityIncident[]>([]);
  const [classifications, setClassifications] = useState<DataClassification[]>([]);
  const [reports, setReports] = useState<ComplianceReport[]>([]);
  const [consents, setConsents] = useState<UserConsent[]>([]);
  const [processingActivities, setProcessingActivities] = useState<ProcessingActivity[]>([]);
  const [dsrRequests, setDsrRequests] = useState<DSRRequest[]>([]);
  const [dataBreaches, setDataBreaches] = useState<DataBreach[]>([]);
  const [dpiaAssessments, setDpiaAssessments] = useState<DPIAAssessment[]>([]);
  const [securityEvents, setSecurityEvents] = useState<SecurityEvent[]>([]);
  const [accountLockouts, setAccountLockouts] = useState<AccountLockout[]>([]);
  const [passwordPolicy, setPasswordPolicy] = useState<PasswordPolicy | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    setLoading(true);
    await Promise.all([
      fetchAuditLogs(),
      fetchIncidents(),
      fetchClassifications(),
      fetchReports(),
      fetchConsents(),
      fetchProcessingActivities(),
      fetchDSRRequests(),
      fetchDataBreaches(),
      fetchDPIAAssessments(),
      fetchSecurityEvents(),
      fetchAccountLockouts(),
      fetchPasswordPolicy(),
    ]);
    setLoading(false);
  };

  const fetchSecurityEvents = async () => {
    const { data, error } = await supabase
      .from('security_events')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);
    
    if (error) {
      console.error('Error fetching security events:', error);
    } else {
      setSecurityEvents(data || []);
    }
  };

  const fetchAccountLockouts = async () => {
    const { data, error } = await supabase
      .from('account_lockouts')
      .select('*')
      .order('locked_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching account lockouts:', error);
    } else {
      setAccountLockouts(data || []);
    }
  };

  const fetchPasswordPolicy = async () => {
    const { data, error } = await supabase
      .from('password_policies')
      .select('*')
      .eq('is_active', true)
      .single();
    
    if (error && error.code !== 'PGRST116') {
      console.error('Error fetching password policy:', error);
    } else {
      setPasswordPolicy(data);
    }
  };

  const unlockAccount = async (id: string) => {
    const { error } = await supabase
      .from('account_lockouts')
      .delete()
      .eq('id', id);
    
    if (error) {
      toast({
        title: "შეცდომა",
        description: "ანგარიშის განბლოკვა ვერ მოხერხდა",
        variant: "destructive",
      });
    } else {
      toast({
        title: "წარმატება",
        description: "ანგარიში განიბლოკა",
      });
      fetchAccountLockouts();
    }
  };

  const updatePasswordPolicy = async (updates: Partial<PasswordPolicy>) => {
    if (!passwordPolicy) return;
    
    const { error } = await supabase
      .from('password_policies')
      .update(updates)
      .eq('id', passwordPolicy.id);
    
    if (error) {
      toast({
        title: "შეცდომა",
        description: "პოლიტიკის განახლება ვერ მოხერხდა",
        variant: "destructive",
      });
    } else {
      toast({
        title: "წარმატება",
        description: "პოლიტიკა განახლდა",
      });
      fetchPasswordPolicy();
    }
  };

  const fetchAuditLogs = async () => {
    const { data, error } = await supabase
      .from('audit_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);
    
    if (error) {
      console.error('Error fetching audit logs:', error);
    } else {
      setAuditLogs(data || []);
    }
  };

  const fetchIncidents = async () => {
    const { data, error } = await supabase
      .from('security_incidents')
      .select('*')
      .order('detected_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching incidents:', error);
    } else {
      setIncidents(data || []);
    }
  };

  const fetchClassifications = async () => {
    const { data, error } = await supabase
      .from('data_classifications')
      .select('*')
      .order('classification_level', { ascending: false });
    
    if (error) {
      console.error('Error fetching classifications:', error);
    } else {
      setClassifications(data || []);
    }
  };

  const fetchReports = async () => {
    const { data, error } = await supabase
      .from('compliance_reports')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching reports:', error);
    } else {
      setReports(data || []);
    }
  };

  const fetchConsents = async () => {
    const { data, error } = await supabase
      .from('user_consents')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching consents:', error);
    } else {
      setConsents(data || []);
    }
  };

  const fetchProcessingActivities = async () => {
    const { data, error } = await supabase
      .from('processing_activities')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching processing activities:', error);
    } else {
      setProcessingActivities(data || []);
    }
  };

  const fetchDSRRequests = async () => {
    const { data, error } = await supabase
      .from('dsr_requests')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching DSR requests:', error);
    } else {
      setDsrRequests(data || []);
    }
  };

  const fetchDataBreaches = async () => {
    const { data, error } = await supabase
      .from('data_breaches')
      .select('*')
      .order('discovery_date', { ascending: false });
    
    if (error) {
      console.error('Error fetching data breaches:', error);
    } else {
      setDataBreaches(data || []);
    }
  };

  const fetchDPIAAssessments = async () => {
    const { data, error } = await supabase
      .from('dpia_assessments')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching DPIA assessments:', error);
    } else {
      setDpiaAssessments(data || []);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'outline';
    }
  };

  const getClassificationColor = (level: string) => {
    switch (level) {
      case 'restricted': return 'destructive';
      case 'confidential': return 'default';
      case 'internal': return 'secondary';
      case 'public': return 'outline';
      default: return 'outline';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'destructive';
      case 'investigating': return 'default';
      case 'resolved': return 'secondary';
      case 'closed': return 'outline';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent flex items-center gap-3">
          <Shield className="h-10 w-10 text-primary" />
          უსაფრთხოება და შესაბამისობა
        </h1>
        <p className="mt-2 text-muted-foreground">
          საქართველოს კანონი "პერსონალური მონაცემების დაცვის შესახებ" | ISO/IEC 27001, 27017, 27018
        </p>
      </div>

      {/* სტატისტიკა */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">DSR მოთხოვნები</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dsrRequests.filter(r => r.status === 'pending').length}</div>
            <p className="text-xs text-muted-foreground">მიმდინარე მოთხოვნები</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">დარღვევები</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dataBreaches.length}</div>
            <p className="text-xs text-muted-foreground">რეგისტრირებული დარღვევები</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">დაბლოკილი ანგარიშები</CardTitle>
            <LockKeyhole className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{accountLockouts.length}</div>
            <p className="text-xs text-muted-foreground">ჩაკეტილი მომხმარებლები</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">უსაფრთხოების მოვლენები</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{securityEvents.filter(e => e.severity === 'high' || e.severity === 'critical').length}</div>
            <p className="text-xs text-muted-foreground">კრიტიკული მოვლენები</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">DPIA შეფასებები</CardTitle>
            <FileSearch className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dpiaAssessments.length}</div>
            <p className="text-xs text-muted-foreground">დაცვის შეფასებები</p>
          </CardContent>
        </Card>
      </div>

      {/* ტაბები */}
      <Tabs defaultValue="gdpr" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 lg:grid-cols-12">
          <TabsTrigger value="gdpr">GDPR</TabsTrigger>
          <TabsTrigger value="dsr">DSR</TabsTrigger>
          <TabsTrigger value="breaches">დარღვევები</TabsTrigger>
          <TabsTrigger value="dpia">DPIA</TabsTrigger>
          <TabsTrigger value="audit">აუდიტი</TabsTrigger>
          <TabsTrigger value="incidents">ინციდენტები</TabsTrigger>
          <TabsTrigger value="events">მოვლენები</TabsTrigger>
          <TabsTrigger value="lockouts">დაბლოკვა</TabsTrigger>
          <TabsTrigger value="password">პაროლი</TabsTrigger>
          <TabsTrigger value="classifications">კლასიფიკაცია</TabsTrigger>
          <TabsTrigger value="reports">ანგარიშები</TabsTrigger>
          <TabsTrigger value="consents">თანხმობები</TabsTrigger>
        </TabsList>

        {/* პერსონალური მონაცემების დამუშავება (GDPR) */}
        <TabsContent value="gdpr" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                მონაცემთა დამუშავების აქტივობები
              </CardTitle>
              <CardDescription>
                კანონი "პერსონალური მონაცემების დაცვის შესახებ" - მუხლი 30
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>აქტივობა</TableHead>
                    <TableHead>მიზანი</TableHead>
                    <TableHead>სამართლებრივი საფუძველი</TableHead>
                    <TableHead>მონაცემთა კატეგორიები</TableHead>
                    <TableHead>შენახვის ვადა</TableHead>
                    <TableHead>სტატუსი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {processingActivities.map((activity) => (
                    <TableRow key={activity.id}>
                      <TableCell className="font-medium">
                        {activity.activity_name_ka || activity.activity_name}
                      </TableCell>
                      <TableCell className="max-w-xs truncate">{activity.purpose}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{activity.legal_basis}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {activity.data_categories?.slice(0, 2).map((cat, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {cat}
                            </Badge>
                          ))}
                          {activity.data_categories?.length > 2 && (
                            <Badge variant="secondary" className="text-xs">
                              +{activity.data_categories.length - 2}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{activity.retention_period}</TableCell>
                      <TableCell>
                        <Badge variant={activity.is_active ? 'secondary' : 'outline'}>
                          {activity.is_active ? 'აქტიური' : 'არააქტიური'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* მონაცემთა სუბიექტების უფლებები (DSR) */}
        <TabsContent value="dsr" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  სუბიექტების უფლებების მოთხოვნები (DSR)
                </CardTitle>
                <CardDescription>
                  30 დღიანი ვადით პასუხის გაცემა - ISO/IEC 27018 | მუხლი 25-34
                </CardDescription>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button>
                    <UserCheck className="h-4 w-4 mr-2" />
                    ახალი მოთხოვნა
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg">
                  <DialogHeader>
                    <DialogTitle>ახალი DSR მოთხოვნა</DialogTitle>
                    <DialogDescription>
                      მონაცემთა სუბიექტის უფლებების მოთხოვნის რეგისტრაცია
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={async (e) => {
                    e.preventDefault();
                    const formData = new FormData(e.currentTarget);
                    const requestType = formData.get('request_type') as string;
                    const requestTypeKa: Record<string, string> = {
                      'access': 'წვდომის უფლება',
                      'rectification': 'შესწორების უფლება',
                      'erasure': 'წაშლის უფლება',
                      'restriction': 'შეზღუდვის უფლება',
                      'portability': 'გადატანის უფლება',
                      'objection': 'წინააღმდეგობის უფლება'
                    };
                    const deadline = new Date();
                    deadline.setDate(deadline.getDate() + 30);
                    
                    const { error } = await supabase.from('dsr_requests').insert([{
                      request_type: requestType,
                      request_type_ka: requestTypeKa[requestType] || requestType,
                      requester_name: formData.get('requester_name') as string,
                      requester_email: formData.get('requester_email') as string,
                      request_details: formData.get('request_details') as string,
                      priority: (formData.get('priority') as string) || 'medium',
                      deadline: deadline.toISOString(),
                      status: 'pending',
                      verification_status: 'pending'
                    }]);
                    
                    if (error) {
                      toast({ title: "შეცდომა", description: error.message, variant: "destructive" });
                    } else {
                      toast({ title: "წარმატება", description: "მოთხოვნა დარეგისტრირდა" });
                      fetchDSRRequests();
                    }
                  }} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="request_type">მოთხოვნის ტიპი</Label>
                      <Select name="request_type" required>
                        <SelectTrigger>
                          <SelectValue placeholder="აირჩიეთ ტიპი" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="access">წვდომის უფლება</SelectItem>
                          <SelectItem value="rectification">შესწორების უფლება</SelectItem>
                          <SelectItem value="erasure">წაშლის უფლება (დავიწყების)</SelectItem>
                          <SelectItem value="restriction">დამუშავების შეზღუდვა</SelectItem>
                          <SelectItem value="portability">მონაცემთა გადატანა</SelectItem>
                          <SelectItem value="objection">წინააღმდეგობის უფლება</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="requester_name">მომთხოვნის სახელი</Label>
                        <Input name="requester_name" required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="requester_email">ელ.ფოსტა</Label>
                        <Input name="requester_email" type="email" required />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="priority">პრიორიტეტი</Label>
                      <Select name="priority" defaultValue="medium">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">დაბალი</SelectItem>
                          <SelectItem value="medium">საშუალო</SelectItem>
                          <SelectItem value="high">მაღალი</SelectItem>
                          <SelectItem value="urgent">სასწრაფო</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="request_details">დეტალური აღწერა</Label>
                      <Textarea name="request_details" rows={3} required />
                    </div>
                    <Button type="submit" className="w-full">მოთხოვნის რეგისტრაცია</Button>
                  </form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {dsrRequests.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  მოთხოვნები არ არის რეგისტრირებული
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>მოთხოვნის ტიპი</TableHead>
                      <TableHead>მომხმარებელი</TableHead>
                      <TableHead>სტატუსი</TableHead>
                      <TableHead>პრიორიტეტი</TableHead>
                      <TableHead>ვადა</TableHead>
                      <TableHead>მოქმედებები</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dsrRequests.map((request) => (
                      <TableRow key={request.id}>
                        <TableCell>
                          <Badge variant="outline">
                            {request.request_type_ka || request.request_type}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium">
                          {request.requester_name}
                          <div className="text-xs text-muted-foreground">{request.requester_email}</div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={
                            request.status === 'completed' ? 'secondary' :
                            request.status === 'in_progress' ? 'default' :
                            request.status === 'rejected' ? 'destructive' : 'outline'
                          }>
                            {request.status === 'pending' ? 'მოლოდინში' :
                             request.status === 'in_progress' ? 'მიმდინარე' :
                             request.status === 'completed' ? 'დასრულებული' :
                             request.status === 'rejected' ? 'უარყოფილი' : request.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={
                            request.priority === 'urgent' || request.priority === 'high' ? 'destructive' : 'secondary'
                          }>
                            {request.priority === 'low' ? 'დაბალი' :
                             request.priority === 'medium' ? 'საშუალო' :
                             request.priority === 'high' ? 'მაღალი' :
                             request.priority === 'urgent' ? 'სასწრაფო' : request.priority}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(request.deadline).toLocaleDateString('ka-GE')}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-2">
                            {request.status === 'pending' && (
                              <>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={async () => {
                                    const { error } = await supabase.from('dsr_requests').update({ status: 'in_progress' }).eq('id', request.id);
                                    if (error) { toast({ title: "შეცდომა: ცვლილება ვერ შეინახა", variant: "destructive" }); return; }
                                    toast({ title: "სტატუსი განახლდა" });
                                    fetchDSRRequests();
                                  }}
                                >
                                  დაწყება
                                </Button>
                              </>
                            )}
                            {request.status === 'in_progress' && (
                              <Button
                                size="sm"
                                onClick={async () => {
                                  const { error } = await supabase.from('dsr_requests').update({ 
                                    status: 'completed',
                                    response_date: new Date().toISOString()
                                  }).eq('id', request.id);
                                  if (error) { toast({ title: "შეცდომა: ცვლილება ვერ შეინახა", variant: "destructive" }); return; }
                                  toast({ title: "მოთხოვნა დასრულდა" });
                                  fetchDSRRequests();
                                }}
                              >
                                დასრულება
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* მონაცემთა დარღვევები */}
        <TabsContent value="breaches" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                მონაცემთა დარღვევების რეესტრი
              </CardTitle>
              <CardDescription>
                72 საათიანი შეტყობინების ვადა - მუხლი 35
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ტიპი</TableHead>
                    <TableHead>აღწერა</TableHead>
                    <TableHead>სიმწვავე</TableHead>
                    <TableHead>სტატუსი</TableHead>
                    <TableHead>გამოვლენის თარიღი</TableHead>
                    <TableHead>შეტყობინებები</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {dataBreaches.map((breach) => (
                    <TableRow key={breach.id}>
                      <TableCell>
                        <Badge variant="outline">{breach.breach_type}</Badge>
                      </TableCell>
                      <TableCell className="max-w-sm truncate">{breach.description}</TableCell>
                      <TableCell>
                        <Badge variant={getSeverityColor(breach.severity) as any}>
                          {breach.severity}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusColor(breach.status) as any}>
                          {breach.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {new Date(breach.discovery_date).toLocaleString('ka-GE')}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1 flex-col">
                          <Badge variant={breach.affected_individuals_notified ? 'secondary' : 'destructive'} className="text-xs">
                            {breach.affected_individuals_notified ? '✓ ინდივიდები' : '✗ ინდივიდები'}
                          </Badge>
                          <Badge variant={breach.supervisory_authority_notified ? 'secondary' : 'destructive'} className="text-xs">
                            {breach.supervisory_authority_notified ? '✓ ზედამხედველი' : '✗ ზედამხედველი'}
                          </Badge>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* DPIA შეფასებები */}
        <TabsContent value="dpia" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSearch className="h-5 w-5" />
                დაცვის შეფასების აქტები (DPIA)
              </CardTitle>
              <CardDescription>
                მონაცემთა დაცვის გავლენის შეფასება - მუხლი 36
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>შეფასების სახელი</TableHead>
                    <TableHead>რისკის დონე</TableHead>
                    <TableHead>სტატუსი</TableHead>
                    <TableHead>დამტკიცების თარიღი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {dpiaAssessments.map((assessment) => (
                    <TableRow key={assessment.id}>
                      <TableCell className="font-medium">{assessment.assessment_name}</TableCell>
                      <TableCell>
                        <Badge variant={getSeverityColor(assessment.risk_level) as any}>
                          {assessment.risk_level}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={
                          assessment.status === 'approved' ? 'secondary' :
                          assessment.status === 'rejected' ? 'destructive' : 'outline'
                        }>
                          {assessment.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {assessment.approved_at ? new Date(assessment.approved_at).toLocaleDateString('ka-GE') : '-'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* აუდიტის ჟურნალი */}
        <TabsContent value="audit" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                აუდიტის ჟურნალი
              </CardTitle>
              <CardDescription>
                მომხმარებელთა ქმედებების სრული ისტორია (ISO 27001)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>თარიღი</TableHead>
                    <TableHead>მოქმედება</TableHead>
                    <TableHead>რესურსი</TableHead>
                    <TableHead>IP მისამართი</TableHead>
                    <TableHead>სტატუსი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {auditLogs.slice(0, 20).map((log) => (
                    <TableRow key={log.id}>
                      <TableCell>{new Date(log.created_at).toLocaleString('ka-GE')}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{log.action_type}</Badge>
                      </TableCell>
                      <TableCell>{log.resource_type}</TableCell>
                      <TableCell className="font-mono text-sm">{log.ip_address}</TableCell>
                      <TableCell>
                        <Badge variant={log.status === 'success' ? 'secondary' : 'destructive'}>
                          {log.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* უსაფრთხოების ინციდენტები */}
        <TabsContent value="incidents" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                უსაფრთხოების ინციდენტები
              </CardTitle>
              <CardDescription>
                ინციდენტების მართვა და რეაგირება (ISO 27001)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>სათაური</TableHead>
                    <TableHead>ტიპი</TableHead>
                    <TableHead>სიმწვავე</TableHead>
                    <TableHead>სტატუსი</TableHead>
                    <TableHead>გამოვლენის თარიღი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {incidents.map((incident) => (
                    <TableRow key={incident.id}>
                      <TableCell className="font-medium">{incident.title}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{incident.incident_type}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getSeverityColor(incident.severity) as any}>
                          {incident.severity}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusColor(incident.status) as any}>
                          {incident.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{new Date(incident.detected_at).toLocaleString('ka-GE')}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* უსაფრთხოების მოვლენები */}
        <TabsContent value="events" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                უსაფრთხოების მოვლენები
              </CardTitle>
              <CardDescription>
                რეალტაიმ მონიტორინგი და გამაფრთხილებელი სისტემა
              </CardDescription>
            </CardHeader>
            <CardContent>
              {securityEvents.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  უსაფრთხოების მოვლენები არ არის რეგისტრირებული
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>თარიღი</TableHead>
                      <TableHead>ტიპი</TableHead>
                      <TableHead>აღწერა</TableHead>
                      <TableHead>სიმწვავე</TableHead>
                      <TableHead>IP მისამართი</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {securityEvents.map((event) => (
                      <TableRow key={event.id}>
                        <TableCell className="text-sm">
                          {new Date(event.created_at).toLocaleString('ka-GE')}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{event.event_type}</Badge>
                        </TableCell>
                        <TableCell className="max-w-sm truncate">{event.description}</TableCell>
                        <TableCell>
                          <Badge variant={getSeverityColor(event.severity) as any}>
                            {event.severity}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{event.ip_address || '-'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ანგარიშის დაბლოკვა */}
        <TabsContent value="lockouts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LockKeyhole className="h-5 w-5" />
                დაბლოკილი ანგარიშები
              </CardTitle>
              <CardDescription>
                არასწორი პაროლის გამო ჩაკეტილი მომხმარებლები
              </CardDescription>
            </CardHeader>
            <CardContent>
              {accountLockouts.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  დაბლოკილი ანგარიშები არ არის
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ელ-ფოსტა</TableHead>
                      <TableHead>ცდების რაოდენობა</TableHead>
                      <TableHead>დაბლოკვის დრო</TableHead>
                      <TableHead>განბლოკვის დრო</TableHead>
                      <TableHead>მოქმედება</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {accountLockouts.map((lockout) => (
                      <TableRow key={lockout.id}>
                        <TableCell className="font-medium">{lockout.email}</TableCell>
                        <TableCell>
                          <Badge variant="destructive">{lockout.failed_attempts}</Badge>
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(lockout.locked_at).toLocaleString('ka-GE')}
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(lockout.locked_until).toLocaleString('ka-GE')}
                        </TableCell>
                        <TableCell>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => unlockAccount(lockout.id)}
                          >
                            <Unlock className="h-4 w-4 mr-1" />
                            განბლოკვა
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* პაროლის პოლიტიკა */}
        <TabsContent value="password" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="h-5 w-5" />
                პაროლის პოლიტიკა
              </CardTitle>
              <CardDescription>
                საერთაშორისო სტანდარტების შესაბამისი პაროლის მოთხოვნები
              </CardDescription>
            </CardHeader>
            <CardContent>
              {passwordPolicy ? (
                <div className="space-y-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>მინიმალური სიგრძე</Label>
                      <Input 
                        type="number"
                        value={passwordPolicy.min_length}
                        onChange={(e) => updatePasswordPolicy({ min_length: parseInt(e.target.value) })}
                        min={6}
                        max={32}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>პაროლის ვადა (დღე)</Label>
                      <Input 
                        type="number"
                        value={passwordPolicy.password_expiry_days}
                        onChange={(e) => updatePasswordPolicy({ password_expiry_days: parseInt(e.target.value) })}
                        min={0}
                        max={365}
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <Label>დიდი ასო აუცილებელი</Label>
                      <Switch 
                        checked={passwordPolicy.require_uppercase}
                        onCheckedChange={(checked) => updatePasswordPolicy({ require_uppercase: checked })}
                      />
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <Label>პატარა ასო აუცილებელი</Label>
                      <Switch 
                        checked={passwordPolicy.require_lowercase}
                        onCheckedChange={(checked) => updatePasswordPolicy({ require_lowercase: checked })}
                      />
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <Label>ციფრი აუცილებელი</Label>
                      <Switch 
                        checked={passwordPolicy.require_numbers}
                        onCheckedChange={(checked) => updatePasswordPolicy({ require_numbers: checked })}
                      />
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <Label>სპეციალური სიმბოლო</Label>
                      <Switch 
                        checked={passwordPolicy.require_special_chars}
                        onCheckedChange={(checked) => updatePasswordPolicy({ require_special_chars: checked })}
                      />
                    </div>
                  </div>

                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-medium mb-2">მიმდინარე მოთხოვნები:</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>✓ მინიმუმ {passwordPolicy.min_length} სიმბოლო</li>
                      {passwordPolicy.require_uppercase && <li>✓ მინიმუმ 1 დიდი ასო (A-Z)</li>}
                      {passwordPolicy.require_lowercase && <li>✓ მინიმუმ 1 პატარა ასო (a-z)</li>}
                      {passwordPolicy.require_numbers && <li>✓ მინიმუმ 1 ციფრი (0-9)</li>}
                      {passwordPolicy.require_special_chars && <li>✓ მინიმუმ 1 სპეციალური სიმბოლო (!@#$%...)</li>}
                      {passwordPolicy.password_expiry_days > 0 && (
                        <li>✓ პაროლი იცვლება ყოველ {passwordPolicy.password_expiry_days} დღეში</li>
                      )}
                    </ul>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  პაროლის პოლიტიკა არ არის კონფიგურირებული
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* მონაცემთა კლასიფიკაცია */}
        <TabsContent value="classifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                მონაცემთა კლასიფიკაცია
              </CardTitle>
              <CardDescription>
                მონაცემების სენსიტიურობის დონეები (ISO 27017)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ცხრილი</TableHead>
                    <TableHead>სვეტი</TableHead>
                    <TableHead>დონე</TableHead>
                    <TableHead>დაშიფვრა</TableHead>
                    <TableHead>მიზეზი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {classifications.map((classification) => (
                    <TableRow key={classification.id}>
                      <TableCell className="font-mono text-sm">{classification.table_name}</TableCell>
                      <TableCell className="font-mono text-sm">{classification.column_name}</TableCell>
                      <TableCell>
                        <Badge variant={getClassificationColor(classification.classification_level) as any}>
                          {classification.classification_level}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {classification.encryption_required ? (
                          <Badge variant="secondary">აუცილებელია</Badge>
                        ) : (
                          <Badge variant="outline">არ არის</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-sm">{classification.sensitivity_reason}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* შესაბამისობის ანგარიშები */}
        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                შესაბამისობის ანგარიშები
              </CardTitle>
              <CardDescription>
                ISO/IEC სტანდარტების შესაბამისობის დოკუმენტაცია
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ტიპი</TableHead>
                    <TableHead>პერიოდი</TableHead>
                    <TableHead>სტატუსი</TableHead>
                    <TableHead>შექმნის თარიღი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reports.map((report) => (
                    <TableRow key={report.id}>
                      <TableCell>
                        <Badge variant="outline">{report.report_type}</Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(report.report_period_start).toLocaleDateString('ka-GE')} - 
                        {new Date(report.report_period_end).toLocaleDateString('ka-GE')}
                      </TableCell>
                      <TableCell>
                        <Badge variant={report.status === 'approved' ? 'secondary' : 'outline'}>
                          {report.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{new Date(report.created_at).toLocaleDateString('ka-GE')}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* მომხმარებლის თანხმობები */}
        <TabsContent value="consents" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCheck className="h-5 w-5" />
                მომხმარებლის თანხმობები
              </CardTitle>
              <CardDescription>
                GDPR თანხმობების მართვა (ISO 27018)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>თანხმობის ტიპი</TableHead>
                    <TableHead>სტატუსი</TableHead>
                    <TableHead>მიცემის თარიღი</TableHead>
                    <TableHead>გაუქმების თარიღი</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {consents.map((consent) => (
                    <TableRow key={consent.id}>
                      <TableCell>
                        <Badge variant="outline">{consent.consent_type}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={consent.consent_given ? 'secondary' : 'destructive'}>
                          {consent.consent_given ? 'მიცემულია' : 'გაუქმებულია'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {consent.given_at ? new Date(consent.given_at).toLocaleString('ka-GE') : '-'}
                      </TableCell>
                      <TableCell>
                        {consent.withdrawn_at ? new Date(consent.withdrawn_at).toLocaleString('ka-GE') : '-'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* კანონმდებლობა და სტანდარტები */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-2 border-primary/20">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Scale className="h-5 w-5 text-primary" />
              საქართველოს კანონი
            </CardTitle>
            <CardDescription>პერსონალური მონაცემების დაცვა</CardDescription>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <p>✓ დამუშავების რეესტრი (მუხლი 30)</p>
            <p>✓ DSR მოთხოვნები (30 დღე)</p>
            <p>✓ დარღვევების შეტყობინება (72 საათი)</p>
            <p>✓ DPIA შეფასებები</p>
            <p>✓ DPO დანიშვნა</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">ISO/IEC 27001</CardTitle>
            <CardDescription>ინფორმაციული უსაფრთხოების მართვა</CardDescription>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <p>✓ აუდიტის ჟურნალი</p>
            <p>✓ ინციდენტების მართვა</p>
            <p>✓ წვდომის კონტროლი</p>
            <p>✓ შესაბამისობის ანგარიშები</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">ISO/IEC 27017</CardTitle>
            <CardDescription>ღრუბლოვანი უსაფრთხოება</CardDescription>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <p>✓ მონაცემთა კლასიფიკაცია</p>
            <p>✓ ღრუბლოვანი დაცვა</p>
            <p>✓ ქსელური უსაფრთხოება</p>
            <p>✓ მონაცემთა იზოლაცია</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">ISO/IEC 27018</CardTitle>
            <CardDescription>პერსონალური მონაცემების დაცვა</CardDescription>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <p>✓ GDPR შესაბამისობა</p>
            <p>✓ მომხმარებლის თანხმობა</p>
            <p>✓ მონაცემების შენახვა</p>
            <p>✓ წაშლის უფლება</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
