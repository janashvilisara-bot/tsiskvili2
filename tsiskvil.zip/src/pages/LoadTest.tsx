import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Activity, Play, Square, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { percentile, splitBatches, verdictFor, type Verdict , equivalentRealUsers, type LoadMode, overallVerdict } from "@/lib/loadTest";

const USERS = [50, 100, 200, 300, 400];
const DURATIONS = [30, 60, 120, 180];
const ROUND_SEC = 30;

type Run = { id: string; created_at: string; virtual_users: number; duration_sec: number; total_requests: number; failed_requests: number; rps: number; p50_ms: number | null; p95_ms: number | null; p99_ms: number | null; verdict: string; stopped_early: boolean };

export default function LoadTest() {
  const { user } = useAuth();
  const { language } = useLanguage();
  const ka = language !== "en";
  const T = (k: string, e: string) => (ka ? k : e);

  const [users, setUsers] = useState(200);
  const [duration, setDuration] = useState(60);
  const [mode, setMode] = useState<LoadMode>("realistic");
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [series, setSeries] = useState<{ round: number; p95: number; rps: number }[]>([]);
  const [result, setResult] = useState<null | { total: number; failed: number; rps: number; p50: number; p95: number; p99: number; max: number; verdict: Verdict; mode?: LoadMode }>(null);
  const [db, setDb] = useState<{ before?: any; after?: any }>({});
  const [scen, setScen] = useState<{ name: string; count: number; p50: number; p95: number; max: number; failed: number }[]>([]);
  const [history, setHistory] = useState<Run[]>([]);
  const stopRef = useRef(false);

  const loadHistory = async () => {
    const { data } = await supabase.from("load_test_runs").select("*").order("created_at", { ascending: false }).limit(20);
    setHistory((data as Run[]) || []);
  };
  useEffect(() => { loadHistory(); }, []);

  const run = async () => {
    stopRef.current = false;
    setRunning(true); setResult(null); setScen([]); setSeries([]); setProgress(0);
    const before = (await supabase.rpc("load_test_db_stats" as any)).data;
    setDb({ before });
    const all: number[] = [];
    let failed = 0, elapsed = 0, round = 0, callErrors = 0;
    const scenAll: Record<string, { lat: number[]; failed: number }> = {};
    try {
      while (elapsed < duration && !stopRef.current) {
        const secs = Math.min(ROUND_SEC, duration - elapsed);
        const res = await Promise.all(splitBatches(users).map((u) =>
          supabase.functions.invoke("load-test-runner", { body: { users: u, seconds: secs, mode, warmup: round === 0 } })));
        const lat: number[] = []; let f = 0;
        for (const r of res) {
          if (r.error || !r.data?.latencies) { callErrors++; f += 1; continue; }
          lat.push(...r.data.latencies); f += r.data.failed;
          for (const [k, v] of Object.entries((r.data.byScenario || {}) as Record<string, { lat: number[]; failed: number }>)) {
            const b = (scenAll[k] ??= { lat: [], failed: 0 }); b.lat.push(...v.lat); b.failed += v.failed;
          }
        }
        all.push(...lat); failed += f; elapsed += secs; round++;
        const s = [...lat].sort((a, b) => a - b);
        setSeries((p) => [...p, { round: elapsed, p95: percentile(s, 95), rps: Math.round(lat.length / secs) }]);
        setProgress(Math.round((elapsed / duration) * 100));
      }
      const sorted = all.sort((a, b) => a - b);
      const total = sorted.length + callErrors;
      const errRate = total ? failed / total : 1;
      const r = { total, failed, rps: Math.round((sorted.length / Math.max(1, elapsed)) * 10) / 10, p50: percentile(sorted, 50), p95: percentile(sorted, 95), p99: percentile(sorted, 99), max: sorted[sorted.length - 1] || 0, verdict: overallVerdict(mode, percentile(sorted, 95), errRate, Math.round((sorted.length / Math.max(1, elapsed)) * 10) / 10, users), mode };
      setResult(r);
      setScen(Object.entries(scenAll).map(([name, v]) => { const x = [...v.lat].sort((a, b) => a - b); return { name, count: x.length, p50: percentile(x, 50), p95: percentile(x, 95), max: x[x.length - 1] || 0, failed: v.failed }; }).sort((a, b) => b.p95 - a.p95));
      const after = (await supabase.rpc("load_test_db_stats" as any)).data;
      setDb({ before, after });
      await supabase.from("load_test_runs").insert({ created_by: user!.id, virtual_users: users, duration_sec: elapsed, total_requests: r.total, failed_requests: r.failed, rps: r.rps, p50_ms: r.p50, p95_ms: r.p95, p99_ms: r.p99, max_ms: r.max, verdict: r.verdict, db_before: before, db_after: after, stopped_early: stopRef.current } as any);
      loadHistory();
    } catch {
      toast.error(T("ტესტი ვერ შესრულდა", "Test failed"));
    } finally { setRunning(false); }
  };

  const verdictBadge = (v: string) => {
    const map: Record<string, [string, string]> = {
      pass: [T("უძლებს", "Holds"), "bg-primary text-primary-foreground"],
      borderline: [T("ზღვარზე", "Borderline"), "bg-accent text-accent-foreground"],
      fail: [T("ვერ უძლებს", "Fails"), "bg-destructive text-destructive-foreground"],
    };
    const [label, cls] = map[v] || [v, ""];
    return <Badge className={cls}>{label}</Badge>;
  };

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center gap-3">
        <Activity className="h-6 w-6 text-primary" />
        <h1 className="font-display text-2xl font-semibold">{T("დატვირთვის ტესტი", "Load test")}</h1>
      </div>

      <Card>
        <CardContent className="flex flex-col gap-4 pt-6 md:flex-row md:items-end">
          <div className="space-y-1">
            <div className="text-sm text-muted-foreground">{T("მომხმარებლები ერთდროულად", "Concurrent users")}</div>
            <Select value={String(users)} onValueChange={(v) => setUsers(Number(v))} disabled={running}>
              <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
              <SelectContent>{USERS.map((u) => <SelectItem key={u} value={String(u)}>{u}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <div className="text-sm text-muted-foreground">{T("ხანგრძლივობა", "Duration")}</div>
            <Select value={String(duration)} onValueChange={(v) => setDuration(Number(v))} disabled={running}>
              <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
              <SelectContent>{DURATIONS.map((d) => <SelectItem key={d} value={String(d)}>{d < 60 ? `${d} ${T("წმ", "s")}` : `${d / 60} ${T("წთ", "min")}`}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <div className="text-sm text-muted-foreground">{T("რეჟიმი", "Mode")}</div>
            <Select value={mode} onValueChange={(v) => setMode(v as LoadMode)} disabled={running}>
              <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="realistic">{T("რეალისტური", "Realistic")}</SelectItem>
                <SelectItem value="stress">{T("სტრეს", "Stress")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {!running ? (
            <Button onClick={run} className="gap-2"><Play className="h-4 w-4" />{T("ტესტის დაწყება", "Start test")}</Button>
          ) : (
            <Button variant="destructive" onClick={() => { stopRef.current = true; }} className="gap-2"><Square className="h-4 w-4" />{T("შეჩერება", "Stop")}</Button>
          )}
          <div className="flex items-start gap-2 text-xs text-muted-foreground md:ml-auto md:max-w-xs">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            {T("მხოლოდ კითხვის მოთხოვნები, მონაცემები არ იცვლება. გაუშვით სამუშაო საათების გარეთ.", "Read-only requests, no data changes. Run outside working hours.")}
          </div>
        </CardContent>
        {running && <div className="px-6 pb-6"><Progress value={progress} /></div>}
      </Card>

      {result && (
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-3">{T("შედეგი", "Result")} {verdictBadge(result.verdict)}</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {[
              [T("მოთხოვნები", "Requests"), result.total],
              [T("ჩავარდნილი", "Failed"), `${result.failed} (${result.total ? ((result.failed / result.total) * 100).toFixed(2) : 0}%)`],
              [T("მოთხოვნა/წმ", "Req/s"), result.rps],
              ["p50", `${result.p50} ms`], ["p95", `${result.p95} ms`], ["p99", `${result.p99} ms`],
              [T("≈ რეალური მომხმარებლები", "≈ Real users"), equivalentRealUsers(result.rps)],
              [T("ყველაზე ნელი", "Slowest"), `${result.max} ms`],
              [T("ბაზის კავშირები", "DB connections"), `${db.before?.connections ?? "—"} → ${db.after?.connections ?? "—"} / ${db.after?.max_connections ?? "—"}`],
            ].map(([l, v]) => (
              <div key={String(l)} className="rounded-lg border p-3"><div className="text-xs text-muted-foreground">{l}</div><div className="font-display text-lg font-semibold">{v}</div></div>
            ))}
          </CardContent>
          {result.mode === "stress" && (
            <p className="px-6 pb-4 text-sm text-muted-foreground">{T("სტრეს რეჟიმი ~10-ჯერ მეტ დატვირთვას იძლევა, ვიდრე რეალური გამოყენება. აქ შეფასება ხდება შეცდომებით და ≈ რეალური მომხმარებლებით; მაღალი p95 ტესტის ხელსაწყოს ზღვარია. ზუსტი p95-ისთვის გამოიყენეთ გარე k6 სკრიპტი.", "Stress mode generates ~10x more load than real use. It is judged by errors and ≈ real users; high p95 reflects the test tool's limit. For precise p95 use the external k6 script.")}</p>
          )}
        </Card>
      )}

      {scen.length > 0 && (
        <Card>
          <CardHeader><CardTitle>{T("შედეგი გვერდების მიხედვით", "Results by page")}</CardTitle></CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="text-left text-muted-foreground"><th className="p-2">{T("მონაცემი", "Data")}</th><th className="p-2">{T("მოთხოვნა", "Req")}</th><th className="p-2">p50</th><th className="p-2">p95</th><th className="p-2">{T("ნელი", "Max")}</th><th className="p-2">{T("ვერდიქტი", "Verdict")}</th></tr></thead>
              <tbody>{scen.map((s) => (
                <tr key={s.name} className="border-t">
                  <td className="p-2 font-medium">{s.name}</td><td className="p-2">{s.count}</td><td className="p-2">{s.p50} ms</td><td className="p-2">{s.p95} ms</td><td className="p-2">{s.max} ms</td>
                  <td className="p-2">{verdictBadge(verdictFor(s.p95, s.count ? s.failed / (s.count + s.failed) : 0))}</td>
                </tr>))}</tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {series.length > 0 && (
        <Card>
          <CardHeader><CardTitle>{T("პასუხის დრო (p95) და მოთხოვნები წამში", "Response time (p95) and req/s")}</CardTitle></CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer>
              <LineChart data={series}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="round" unit="s" />
                <YAxis yAxisId="l" /><YAxis yAxisId="r" orientation="right" />
                <Tooltip />
                <Line yAxisId="l" dataKey="p95" name="p95 ms" stroke="hsl(var(--primary))" />
                <Line yAxisId="r" dataKey="rps" name="req/s" stroke="hsl(var(--muted-foreground))" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle>{T("ტესტების ისტორია", "Test history")}</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          {history.length === 0 ? <div className="text-sm text-muted-foreground">{T("ჯერ ტესტი არ გაშვებულა", "No tests yet")}</div> : (
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground"><tr><th className="p-2">{T("თარიღი", "Date")}</th><th className="p-2">{T("მომხ.", "Users")}</th><th className="p-2">{T("წმ", "s")}</th><th className="p-2">p95</th><th className="p-2">{T("შეცდომები", "Errors")}</th><th className="p-2">req/s</th><th className="p-2">{T("ვერდიქტი", "Verdict")}</th></tr></thead>
              <tbody>{history.map((h) => (
                <tr key={h.id} className="border-t">
                  <td className="p-2">{new Date(h.created_at).toLocaleString(ka ? "ka-GE" : "en-GB")}</td>
                  <td className="p-2">{h.virtual_users}</td><td className="p-2">{h.duration_sec}</td>
                  <td className="p-2">{h.p95_ms} ms</td>
                  <td className="p-2">{h.total_requests ? ((h.failed_requests / h.total_requests) * 100).toFixed(2) : 0}%</td>
                  <td className="p-2">{h.rps}</td><td className="p-2">{verdictBadge(h.verdict)}</td>
                </tr>))}
              </tbody>
            </table>)}
        </CardContent>
      </Card>
    </div>
  );
}
