import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Building2, ShieldCheck, Loader2, CheckCircle2, Rocket } from 'lucide-react';
import { z } from 'zod';

const schema = z.object({
  companyName: z.string().trim().min(2, 'შეიყვანეთ კომპანიის დასახელება'),
  identificationCode: z.string().trim().min(4, 'შეიყვანეთ საიდენტიფიკაციო კოდი'),
  legalAddress: z.string().trim().min(3, 'შეიყვანეთ იურიდიული მისამართი'),
  physicalAddress: z.string().trim().optional(),
  companyPhone: z.string().trim().optional(),
  adminFullName: z.string().trim().min(2, 'შეიყვანეთ სახელი და გვარი'),
  adminEmail: z.string().trim().email('არასწორი ელ.ფოსტა'),
  adminPassword: z.string().min(8, 'პაროლი მინიმუმ 8 სიმბოლო'),
  confirmPassword: z.string().min(1, 'გაიმეორეთ პაროლი'),
}).refine((d) => d.adminPassword === d.confirmPassword, {
  message: 'პაროლები არ ემთხვევა',
  path: ['confirmPassword'],
});

type FormState = z.infer<typeof schema>;

const EMPTY: FormState = {
  companyName: '',
  identificationCode: '',
  legalAddress: '',
  physicalAddress: '',
  companyPhone: '',
  adminFullName: '',
  adminEmail: '',
  adminPassword: '',
  confirmPassword: '',
};

export default function Setup() {
  const navigate = useNavigate();
  const { signIn } = useAuth();
  const [checking, setChecking] = useState(true);
  const [allowed, setAllowed] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [form, setForm] = useState<FormState>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    let active = true;
    (async () => {
      const { data, error } = await supabase.rpc('has_any_admin');
      if (!active) return;
      if (error) {
        setAllowed(false);
      } else {
        setAllowed(data !== true);
      }
      setChecking(false);
    })();
    return () => { active = false; };
  }, []);

  const set = (key: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((prev) => ({ ...prev, [key]: e.target.value }));

  const steps = useMemo(() => ([
    'მთავარი ოფისი (ფილიალი)',
    'შვებულების ტიპები',
    'საქართველოს დღესასწაულები',
    'სამუშაო გრაფიკის შაბლონები',
    'დეპარტამენტები და პოზიციები',
    'ყველა მოდულის გააქტიურება',
  ]), []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      parsed.error.issues.forEach((i) => { fieldErrors[String(i.path[0])] = i.message; });
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke('provision-tenant', {
        body: {
          companyName: form.companyName,
          identificationCode: form.identificationCode,
          legalAddress: form.legalAddress,
          physicalAddress: form.physicalAddress || form.legalAddress,
          companyPhone: form.companyPhone,
          adminFullName: form.adminFullName,
          adminEmail: form.adminEmail,
          adminPassword: form.adminPassword,
        },
      });

      const result = data as { success?: boolean; error?: string } | null;
      if (error || !result?.success) {
        if (result?.error === 'already_provisioned') {
          toast.error('სისტემა უკვე აწყობილია - გთხოვთ, შედით თქვენი ანგარიშით.');
          navigate('/auth', { replace: true });
          return;
        }
        toast.error('სისტემის აწყობა ვერ მოხერხდა. გთხოვთ, სცადოთ ხელახლა.');
        return;
      }

      setDone(true);
      toast.success('სისტემა წარმატებით აეწყო');
      try {
        await signIn(form.adminEmail, form.adminPassword);
        navigate('/', { replace: true });
      } catch {
        navigate('/auth', { replace: true });
      }
    } catch {
      toast.error('სისტემის აწყობა ვერ მოხერხდა. გთხოვთ, სცადოთ ხელახლა.');
    } finally {
      setSubmitting(false);
    }
  };

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!allowed) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <ShieldCheck className="h-10 w-10 mx-auto text-primary" />
            <CardTitle>სისტემა უკვე აწყობილია</CardTitle>
            <CardDescription>
              პირველადი აწყობის გვერდი ხელმისაწვდომია მხოლოდ ახალ, ცარიელ სისტემაში.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full" onClick={() => navigate('/auth', { replace: true })}>
              შესვლის გვერდზე გადასვლა
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 p-4 py-10">
      <div className="mx-auto w-full max-w-3xl space-y-6">
        <div className="text-center space-y-2">
          <Rocket className="h-10 w-10 mx-auto text-primary" />
          <h1 className="text-2xl font-semibold">სისტემის პირველადი აწყობა</h1>
          <p className="text-sm text-muted-foreground">
            შეავსეთ კომპანიის მონაცემები და შექმენით მთავარი ადმინისტრატორის ანგარიში
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Building2 className="h-5 w-5 text-primary" /> კომპანიის მონაცემები
              </CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="companyName">კომპანიის დასახელება *</Label>
                <Input id="companyName" value={form.companyName} onChange={set('companyName')} autoComplete="organization" />
                {errors.companyName && <p className="text-xs text-destructive">{errors.companyName}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="identificationCode">საიდენტიფიკაციო კოდი *</Label>
                <Input id="identificationCode" value={form.identificationCode} onChange={set('identificationCode')} inputMode="numeric" />
                {errors.identificationCode && <p className="text-xs text-destructive">{errors.identificationCode}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="legalAddress">იურიდიული მისამართი *</Label>
                <Input id="legalAddress" value={form.legalAddress} onChange={set('legalAddress')} />
                {errors.legalAddress && <p className="text-xs text-destructive">{errors.legalAddress}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="physicalAddress">ფაქტობრივი მისამართი</Label>
                <Input id="physicalAddress" value={form.physicalAddress ?? ''} onChange={set('physicalAddress')} placeholder="თუ ცარიელია, გამოიყენება იურიდიული" />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="companyPhone">საკონტაქტო ტელეფონი</Label>
                <Input id="companyPhone" value={form.companyPhone ?? ''} onChange={set('companyPhone')} autoComplete="tel" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <ShieldCheck className="h-5 w-5 text-primary" /> მთავარი ადმინისტრატორი
              </CardTitle>
              <CardDescription>ეს მონაცემები ყოველ ახალ კომპანიაზე უნიკალური უნდა იყოს</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="adminFullName">სახელი და გვარი *</Label>
                <Input id="adminFullName" value={form.adminFullName} onChange={set('adminFullName')} autoComplete="name" />
                {errors.adminFullName && <p className="text-xs text-destructive">{errors.adminFullName}</p>}
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="adminEmail">ელ.ფოსტა *</Label>
                <Input id="adminEmail" type="email" value={form.adminEmail} onChange={set('adminEmail')} autoComplete="email" />
                {errors.adminEmail && <p className="text-xs text-destructive">{errors.adminEmail}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="adminPassword">პაროლი *</Label>
                <Input id="adminPassword" type="password" value={form.adminPassword} onChange={set('adminPassword')} autoComplete="new-password" />
                {errors.adminPassword && <p className="text-xs text-destructive">{errors.adminPassword}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">გაიმეორეთ პაროლი *</Label>
                <Input id="confirmPassword" type="password" value={form.confirmPassword} onChange={set('confirmPassword')} autoComplete="new-password" />
                {errors.confirmPassword && <p className="text-xs text-destructive">{errors.confirmPassword}</p>}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">რა აეწყობა ავტომატურად</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-2 sm:grid-cols-2">
              {steps.map((s) => (
                <div key={s} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                  <span>{s}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Separator />

          <Button type="submit" size="lg" className="w-full" disabled={submitting || done}>
            {submitting ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> მიმდინარეობს აწყობა...</>) : 'სისტემის აწყობა'}
          </Button>
        </form>
      </div>
    </div>
  );
}
