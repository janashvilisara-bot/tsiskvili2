import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { ShieldCheck, Shield, Lock, FileKey, Database, Eye, ClipboardCheck, Server, Bot, Sparkles, Cookie } from "lucide-react";
import { Link } from "react-router-dom";

export default function DataProtection() {
  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <ShieldCheck className="h-8 w-8 text-primary" />
            მონაცემთა დაცვა
          </h1>
          <p className="mt-2 text-muted-foreground">როგორ არის დაცული თქვენი მონაცემები სისტემაში</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <Button asChild variant="outline" className="gap-2">
            <Link to="/privacy-policy">
              <FileKey className="h-4 w-4" />
              კონფიდენციალურობის პოლიტიკა
            </Link>
          </Button>
          <Button asChild variant="outline" className="gap-2">
            <Link to="/terms-of-service">
              <Shield className="h-4 w-4" />
              მომსახურების პირობები
            </Link>
          </Button>
          <Button asChild variant="outline" className="gap-2">
            <Link to="/cookie-policy">
              <Cookie className="h-4 w-4" />
              ქუქი-ფაილების პოლიტიკა
            </Link>
          </Button>
          <Button asChild className="gap-2">
            <Link to="/ai-dpo">
              <Bot className="h-4 w-4" />
              AI DPO ასისტენტი
              <Sparkles className="h-3 w-3" />
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Encryption */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <FileKey className="h-5 w-5 text-primary" />
              დაშიფვრა
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground list-disc ml-4">
              <li><strong>ტრანზიტში:</strong> TLS/HTTPS დაშიფვრა ყველა კომუნიკაციისთვის</li>
              <li><strong>შენახვისას:</strong> AES-256 დისკის დაშიფვრა</li>
              <li><strong>აპლიკაციის დონეზე:</strong> AES-256-GCM დაშიფვრა სენსიტიური ველებისთვის (პირადი ნომერი, ხელფასი, საბანკო ანგარიში, ბონუსი, საპენსიო)</li>
            </ul>
          </CardContent>
        </Card>

        {/* Access Control */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Shield className="h-5 w-5 text-primary" />
              წვდომის კონტროლი (RBAC + RLS)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground list-disc ml-4">
              <li><strong>36+ Row-Level Security პოლიტიკა</strong> - თანამშრომლები ხედავენ მხოლოდ საკუთარ მონაცემებს</li>
              <li>დეპარტამენტის მენეჯერები ხედავენ გუნდის მონაცემებს (საბანკო ინფორმაციის გარეშე)</li>
              <li>მხოლოდ ადმინისტრატორსა და HR-ს აქვთ სრული წვდომა</li>
              <li>ანონიმური წვდომა სრულად დაბლოკილია ყველა სენსიტიურ ცხრილზე</li>
            </ul>
          </CardContent>
        </Card>

        {/* File Storage */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Database className="h-5 w-5 text-primary" />
              ფაილების შენახვა
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground list-disc ml-4">
              <li>ყველა ფაილის საცავი (დოკუმენტები, კონტრაქტები, რეზიუმეები) არის <strong>პრივატული</strong></li>
              <li>წვდომა მხოლოდ <strong>ხელმოწერილი URL-ების</strong> (Signed URLs) მეშვეობით, ვადის შეზღუდვით</li>
            </ul>
          </CardContent>
        </Card>

        {/* Authentication */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Lock className="h-5 w-5 text-primary" />
              ავთენტიფიკაცია და სესიები
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground list-disc ml-4">
              <li>მინიმუმ 12 სიმბოლოიანი პაროლი კომპლექსურობის მოთხოვნებით</li>
              <li>ანგარიშის დაბლოკვა 5 წარუმატებელი მცდელობის შემდეგ (30 წუთი)</li>
              <li>8-საათიანი სესიის ტაიმაუტი ავტომატური გამოსვლით</li>
              <li>ავტორიზაციის ანომალიების აღმოჩენა (ახალი ლოკაცია/მოწყობილობა)</li>
            </ul>
          </CardContent>
        </Card>

        {/* Attack Prevention */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Eye className="h-5 w-5 text-primary" />
              თავდასხმების პრევენცია
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground list-disc ml-4">
              <li>ინტრუზიის აღმოჩენის სისტემა (SQL ინჯექცია, XSS, ბრძანების ინჯექცია)</li>
              <li>Rate limiting კრიტიკულ ფუნქციებზე</li>
              <li>CSP, HSTS და Clickjacking-ის პრევენცია</li>
            </ul>
          </CardContent>
        </Card>

        {/* Audit */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <ClipboardCheck className="h-5 w-5 text-primary" />
              აუდიტი და მონიტორინგი
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground list-disc ml-4">
              <li>12+ ტიპის მოვლენის ლოგირება რისკის დონეებით</li>
              <li>ყოველი დაშიფვრა/გაშიფვრის ოპერაცია აღირიცხება</li>
              <li>ავტორიზაციის ისტორია ინახება 1 წლის განმავლობაში</li>
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Compliance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Server className="h-5 w-5 text-primary" />
            შესაბამისობა (Compliance)
          </CardTitle>
          <CardDescription>სისტემა შეესაბამება შემდეგ სტანდარტებს</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Badge variant="outline" className="text-sm py-1 px-3">ISO/IEC 27001</Badge>
            <Badge variant="outline" className="text-sm py-1 px-3">OWASP Top 10</Badge>
            <Badge variant="outline" className="text-sm py-1 px-3">GDPR</Badge>
            <Badge variant="outline" className="text-sm py-1 px-3">საქართველოს პერსონალურ მონაცემთა დაცვის კანონი</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
