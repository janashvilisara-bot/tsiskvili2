import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { Plus, Trash2, Edit, Shield } from 'lucide-react';
import { Navigate } from 'react-router-dom';
import { Textarea } from '@/components/ui/textarea';

interface CustomRole {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
}

interface Permission {
  key: string;
  label: string;
  category: string;
}

// Define all available permissions based on menu items
const ALL_PERMISSIONS: Permission[] = [
  // მთავარი
  { key: 'dashboard', label: 'მთავარი გვერდი', category: 'მთავარი' },
  { key: 'employee-portal', label: 'თანამშრომლის პორტალი', category: 'მთავარი' },
  { key: 'calendar', label: 'კალენდარი', category: 'მთავარი' },
  { key: 'tasks', label: 'დავალებები', category: 'მთავარი' },
  { key: 'chat', label: 'ჩეთი', category: 'მთავარი' },
  { key: 'help', label: 'დახმარება', category: 'მთავარი' },
  
  // პერსონალი
  { key: 'employees', label: 'თანამშრომლები', category: 'პერსონალი' },
  { key: 'attendance', label: 'დასწრება', category: 'პერსონალი' },
  { key: 'work-schedules', label: 'სამუშაო გრაფიკები', category: 'პერსონალი' },
  { key: 'shift-schedules', label: 'ცვლების გრაფიკები', category: 'პერსონალი' },
  { key: 'schedule-templates', label: 'გრაფიკის თემპლეითები', category: 'პერსონალი' },
  { key: 'leave-requests', label: 'შვებულებები', category: 'პერსონალი' },
  { key: 'leave-statistics', label: 'შვებულების სტატისტიკა', category: 'პერსონალი' },
  { key: 'public-holidays', label: 'სახელმწიფო დღესასწაულები', category: 'პერსონალი' },
  { key: 'overtime-requests', label: 'ზეგანაკვეთური სამუშაო', category: 'პერსონალი' },
  { key: 'overtime-reports', label: 'ზეგანაკვეთური რეპორტები', category: 'პერსონალი' },
  { key: 'business-trip-requests', label: 'მივლინებები', category: 'პერსონალი' },
  { key: 'vehicle-requests', label: 'ტრანსპორტის მოთხოვნები', category: 'პერსონალი' },
  { key: 'lateness-analytics', label: 'დაგვიანების ანალიტიკა', category: 'პერსონალი' },
  { key: 'mobile-attendance', label: 'მობილური დასწრება', category: 'პერსონალი' },
  { key: 'work-time-tracking', label: 'სამუშაო დროის აღრიცხვა', category: 'პერსონალი' },
  { key: 'work-time-form-generator', label: 'N1 ფორმის გენერატორი', category: 'პერსონალი' },
  
  // ფინანსები
  { key: 'payroll', label: 'ხელფასები', category: 'ფინანსები' },
  { key: 'pension-payments', label: 'საპენსიო გადასახადები', category: 'ფინანსები' },
  { key: 'compensation', label: 'ბონუსები და კომპენსაციები', category: 'ფინანსები' },
  { key: 'benefits', label: 'სარგებლები (HR)', category: 'ფინანსები' },
  { key: 'benefits-admin', label: 'სარგებლების მართვა', category: 'ფინანსები' },
  { key: 'budget-planning', label: 'ბიუჯეტის დაგეგმვა', category: 'ფინანსები' },
  { key: 'budget-expenses', label: 'ბიუჯეტის ხარჯები', category: 'ფინანსები' },
  { key: 'financial-reports', label: 'ფინანსური რეპორტები', category: 'ფინანსები' },
  { key: 'financial-documentation', label: 'ფინანსური დოკუმენტაცია', category: 'ფინანსები' },
  { key: 'reports', label: 'რეპორტები', category: 'ფინანსები' },
  
  // დაქირავება
  { key: 'vacancies', label: 'ვაკანსიები', category: 'დაქირავება' },
  { key: 'candidates', label: 'კანდიდატები', category: 'დაქირავება' },
  { key: 'job-descriptions', label: 'პოზიციების აღწერა', category: 'დაქირავება' },
  { key: 'job-applications', label: 'განაცხადები', category: 'დაქირავება' },
  
  // განვითარება და შეფასება
  { key: 'training', label: 'ტრენინგები', category: 'განვითარება და შეფასება' },
  { key: 'video-tutorial-management', label: 'ვიდეო ტუტორიალების მართვა', category: 'განვითარება და შეფასება' },
  { key: 'evaluations', label: 'შეფასებები', category: 'განვითარება და შეფასება' },
  { key: 'feedback', label: 'უკუკავშირი', category: 'განვითარება და შეფასება' },
  { key: 'okr-management', label: 'OKR მართვა', category: 'განვითარება და შეფასება' },
  { key: 'pulse-surveys', label: 'გამოკითხვები', category: 'განვითარება და შეფასება' },
  { key: 'onboarding', label: 'ონბორდინგი', category: 'განვითარება და შეფასება' },
  { key: 'onboarding-templates', label: 'ონბორდინგ თემპლეითები', category: 'განვითარება და შეფასება' },
  { key: 'recognition', label: 'აღიარება', category: 'განვითარება და შეფასება' },
  
  // ორგანიზაცია
  { key: 'organizational-structure', label: 'ორგანიზაციული სტრუქტურა', category: 'ორგანიზაცია' },
  { key: 'disciplinary', label: 'დისციპლინური ღონისძიებები', category: 'ორგანიზაცია' },
  { key: 'announcements', label: 'განცხადებები', category: 'ორგანიზაცია' },
  
  // სისტემა და ადმინისტრირება
  { key: 'documents', label: 'დოკუმენტები', category: 'სისტემა და ადმინისტრირება' },
  { key: 'document-reports', label: 'დოკუმენტების რეპორტები', category: 'სისტემა და ადმინისტრირება' },
  { key: 'contract-templates', label: 'ხელშეკრულების შაბლონები', category: 'სისტემა და ადმინისტრირება' },
  { key: 'role-management', label: 'როლების მართვა', category: 'სისტემა და ადმინისტრირება' },
  { key: 'custom-role-management', label: 'Custom როლების მართვა', category: 'სისტემა და ადმინისტრირება' },
  { key: 'company-settings', label: 'კომპანიის პარამეტრები', category: 'სისტემა და ადმინისტრირება' },
  { key: 'sms-settings', label: 'SMS პარამეტრები', category: 'სისტემა და ადმინისტრირება' },
  { key: 'security', label: 'უსაფრთხოება', category: 'სისტემა და ადმინისტრირება' },
  { key: 'audit-logs', label: 'აუდიტის ლოგები', category: 'სისტემა და ადმინისტრირება' },
  { key: 'asset-management', label: 'აქტივების მართვა', category: 'სისტემა და ადმინისტრირება' },
];

export default function CustomRoleManagement() {
  const { userRole, user } = useAuth();
  const [roles, setRoles] = useState<CustomRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingRole, setEditingRole] = useState<CustomRole | null>(null);
  const [roleName, setRoleName] = useState('');
  const [roleDescription, setRoleDescription] = useState('');
  const [selectedPermissions, setSelectedPermissions] = useState<Set<string>>(new Set());

  if (userRole !== 'admin' && userRole !== 'hr_manager') {
    return <Navigate to="/" replace />;
  }

  useEffect(() => {
    fetchRoles();
  }, []);

  const fetchRoles = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('custom_roles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRoles(data || []);
    } catch (error: any) {
      toast.error('როლების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = async (role?: CustomRole) => {
    if (role) {
      setEditingRole(role);
      setRoleName(role.name);
      setRoleDescription(role.description || '');
      
      // Load permissions for this role
      const { data, error } = await supabase
        .from('role_permissions')
        .select('permission_key')
        .eq('role_id', role.id);

      if (!error && data) {
        setSelectedPermissions(new Set(data.map(p => p.permission_key)));
      }
    } else {
      setEditingRole(null);
      setRoleName('');
      setRoleDescription('');
      setSelectedPermissions(new Set());
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingRole(null);
    setRoleName('');
    setRoleDescription('');
    setSelectedPermissions(new Set());
  };

  const handleSave = async () => {
    if (!roleName.trim()) {
      toast.error('შეიყვანეთ როლის სახელი');
      return;
    }

    try {
      if (editingRole) {
        // Update existing role
        const { error: updateError } = await supabase
          .from('custom_roles')
          .update({ name: roleName, description: roleDescription })
          .eq('id', editingRole.id);

        if (updateError) throw updateError;

        // Delete old permissions
        await supabase
          .from('role_permissions')
          .delete()
          .eq('role_id', editingRole.id);

        // Insert new permissions
        if (selectedPermissions.size > 0) {
          const permissions = Array.from(selectedPermissions).map(key => ({
            role_id: editingRole.id,
            permission_key: key
          }));

          const { error: permError } = await supabase
            .from('role_permissions')
            .insert(permissions);

          if (permError) throw permError;
        }

        toast.success('როლი განახლდა');
      } else {
        // Create new role
        const { data: newRole, error: insertError } = await supabase
          .from('custom_roles')
          .insert({ 
            name: roleName, 
            description: roleDescription,
            created_by: user?.id 
          })
          .select()
          .single();

        if (insertError) throw insertError;

        // Insert permissions
        if (selectedPermissions.size > 0) {
          const permissions = Array.from(selectedPermissions).map(key => ({
            role_id: newRole.id,
            permission_key: key
          }));

          const { error: permError } = await supabase
            .from('role_permissions')
            .insert(permissions);

          if (permError) throw permError;
        }

        toast.success('როლი შეიქმნა');
      }

      fetchRoles();
      handleCloseDialog();
    } catch (error: any) {
      toast.error('შეცდომა: ' + error.message);
    }
  };

  const handleDelete = async (roleId: string) => {
    if (!confirm('დარწმუნებული ხართ რომ გსურთ ამ როლის წაშლა?')) return;

    try {
      const { error } = await supabase
        .from('custom_roles')
        .delete()
        .eq('id', roleId);

      if (error) throw error;
      toast.success('როლი წაიშალა');
      fetchRoles();
    } catch (error: any) {
      toast.error('წაშლა ვერ მოხერხდა: ' + error.message);
    }
  };

  const togglePermission = (key: string) => {
    const newPermissions = new Set(selectedPermissions);
    if (newPermissions.has(key)) {
      newPermissions.delete(key);
    } else {
      newPermissions.add(key);
    }
    setSelectedPermissions(newPermissions);
  };

  const toggleCategory = (category: string) => {
    const categoryPermissions = ALL_PERMISSIONS
      .filter(p => p.category === category)
      .map(p => p.key);
    
    const allSelected = categoryPermissions.every(key => selectedPermissions.has(key));
    const newPermissions = new Set(selectedPermissions);
    
    if (allSelected) {
      categoryPermissions.forEach(key => newPermissions.delete(key));
    } else {
      categoryPermissions.forEach(key => newPermissions.add(key));
    }
    
    setSelectedPermissions(newPermissions);
  };

  const categories = Array.from(new Set(ALL_PERMISSIONS.map(p => p.category)));

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Shield className="h-8 w-8" />
            Custom როლების მართვა
          </h1>
          <p className="text-muted-foreground mt-1">
            შექმენით და მართეთ მორგებული როლები სპეციფიკური უფლებებით
          </p>
        </div>
        <Button onClick={() => handleOpenDialog()}>
          <Plus className="h-4 w-4 mr-2" />
          ახალი როლი
        </Button>
      </div>

      <div className="grid gap-4">
        {loading ? (
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground">იტვირთება...</p>
            </CardContent>
          </Card>
        ) : roles.length === 0 ? (
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground">
                Custom როლები არ მოიძებნა. შექმენით ახალი როლი ზემოთ მოცემული ღილაკით.
              </p>
            </CardContent>
          </Card>
        ) : (
          roles.map((role) => (
            <Card key={role.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{role.name}</CardTitle>
                    <CardDescription>{role.description || 'აღწერა არ არის'}</CardDescription>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleOpenDialog(role)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="icon"
                      onClick={() => handleDelete(role.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
            </Card>
          ))
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={handleCloseDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingRole ? 'როლის რედაქტირება' : 'ახალი როლის შექმნა'}
            </DialogTitle>
            <DialogDescription>
              შეავსეთ როლის ინფორმაცია და აირჩიეთ ფუნქციონალები რომლებიც ხელმისაწვდომი იქნება ამ როლისთვის
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="name">როლის სახელი *</Label>
              <Input
                id="name"
                value={roleName}
                onChange={(e) => setRoleName(e.target.value)}
                placeholder="მაგ: მენეჯერი, ბუღალტერი..."
              />
            </div>

            <div>
              <Label htmlFor="description">აღწერა</Label>
              <Textarea
                id="description"
                value={roleDescription}
                onChange={(e) => setRoleDescription(e.target.value)}
                placeholder="მოკლე აღწერა როლის შესახებ..."
                rows={2}
              />
            </div>

            <div className="space-y-4">
              <Label className="text-lg font-semibold">ფუნქციონალები</Label>
              {categories.map((category) => {
                const categoryPermissions = ALL_PERMISSIONS.filter(p => p.category === category);
                const allSelected = categoryPermissions.every(p => selectedPermissions.has(p.key));
                const someSelected = categoryPermissions.some(p => selectedPermissions.has(p.key));

                return (
                  <div key={category} className="border rounded-lg p-4 space-y-2">
                    <div className="flex items-center space-x-2 mb-3">
                      <Checkbox
                        id={`category-${category}`}
                        checked={allSelected}
                        onCheckedChange={() => toggleCategory(category)}
                        className={someSelected && !allSelected ? "data-[state=checked]:bg-primary/50" : ""}
                      />
                      <Label
                        htmlFor={`category-${category}`}
                        className="text-base font-semibold cursor-pointer"
                      >
                        {category}
                      </Label>
                    </div>
                    <div className="grid grid-cols-2 gap-2 pl-6">
                      {categoryPermissions.map((permission) => (
                        <div key={permission.key} className="flex items-center space-x-2">
                          <Checkbox
                            id={permission.key}
                            checked={selectedPermissions.has(permission.key)}
                            onCheckedChange={() => togglePermission(permission.key)}
                          />
                          <Label
                            htmlFor={permission.key}
                            className="text-sm cursor-pointer"
                          >
                            {permission.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={handleCloseDialog}>
              გაუქმება
            </Button>
            <Button onClick={handleSave}>
              {editingRole ? 'განახლება' : 'შექმნა'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
