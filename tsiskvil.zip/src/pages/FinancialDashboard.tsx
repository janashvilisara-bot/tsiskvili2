import { useEffect, useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageTransition } from "@/components/PageTransition";
import { Skeleton } from "@/components/ui/skeleton";
import { PiggyBank, BarChart3, Wallet, TrendingUp, TrendingDown, Briefcase } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip as RTooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";
import { toast } from "sonner";

type JD = { title: string; salary_range_min: number | null; salary_range_max: number | null };
type EmpRow = { position: string | null; salary: number | null; is_pension_payer: boolean | null };
type BudgetPlan = { category: string; planned_amount: number | null; actual_amount: number | null; fiscal_year: number };

const fmt = (n: number) => `₾${Math.round(n).toLocaleString("ka-GE")}`;

export default function FinancialDashboard() {
  const [loading, setLoading] = useState(true);
  const [year, setYear] = useState<number>(new Date().getFullYear());
  const [employees, setEmployees] = useState<EmpRow[]>([]);
  const [jds, setJds] = useState<JD[]>([]);
  const [budgets, setBudgets] = useState<BudgetPlan[]>([]);

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year]);

  const load = async () => {
    setLoading(true);
    try {
      const [empRes, jdRes, bRes] = await Promise.all([
        supabase.from("employees").select("position, salary, is_pension_payer").eq("status", "active"),
        supabase.from("job_descriptions").select("title, salary_range_min, salary_range_max").eq("is_active", true),
        supabase.from("budget_plans").select("category, planned_amount, actual_amount, fiscal_year").eq("fiscal_year", year),
      ]);
      if (empRes.error) throw empRes.error;
      setEmployees((empRes.data ?? []) as EmpRow[]);
      setJds((jdRes.data ?? []) as JD[]);
      setBudgets((bRes.data ?? []) as BudgetPlan[]);
    } catch (e) {
      console.error(e);
      toast.error("მონაცემების ჩატვირთვა ვერ მოხერხდა");
    } finally {
      setLoading(false);
    }
  };

  // TAX SAVINGS (Georgia: 20% IT + 2%/2% pension; if employee opted out, save 2% employer)
  const taxStats = useMemo(() => {
    const totalGross = employees.reduce((s, e) => s + (e.salary ?? 0), 0);
    const totalIT = totalGross * 0.2;
    const totalPensionEmployer = employees.reduce(
      (s, e) => s + ((e.is_pension_payer !== false) ? (e.salary ?? 0) * 0.02 : 0), 0,
    );
    const optedOut = employees.filter((e) => e.is_pension_payer === false).length;
    const optedOutSavings = employees
      .filter((e) => e.is_pension_payer === false)
      .reduce((s, e) => s + (e.salary ?? 0) * 0.02, 0);
    return { totalGross, totalIT, totalPensionEmployer, optedOut, optedOutSavings };
  }, [employees]);

  // POSITION SALARY RANGE: aggregate active employees vs JD min/max
  const positionRows = useMemo(() => {
    const byPos = new Map<string, { count: number; sum: number; min: number; max: number }>();
    for (const e of employees) {
      const p = (e.position ?? "-").trim();
      const cur = byPos.get(p) ?? { count: 0, sum: 0, min: Infinity, max: 0 };
      const s = e.salary ?? 0;
      cur.count += 1;
      cur.sum += s;
      cur.min = Math.min(cur.min, s);
      cur.max = Math.max(cur.max, s);
      byPos.set(p, cur);
    }
    const jdMap = new Map(jds.map((j) => [j.title.trim().toLowerCase(), j]));
    return Array.from(byPos.entries())
      .map(([position, agg]) => {
        const jd = jdMap.get(position.toLowerCase());
        const avg = agg.count ? agg.sum / agg.count : 0;
        return {
          position,
          count: agg.count,
          avg,
          empMin: agg.min === Infinity ? 0 : agg.min,
          empMax: agg.max,
          jdMin: jd?.salary_range_min ?? null,
          jdMax: jd?.salary_range_max ?? null,
        };
      })
      .sort((a, b) => b.avg - a.avg);
  }, [employees, jds]);

  // BUDGET VS ACTUAL
  const budgetRows = useMemo(() => {
    const byCat = new Map<string, { planned: number; actual: number }>();
    for (const b of budgets) {
      const cur = byCat.get(b.category) ?? { planned: 0, actual: 0 };
      cur.planned += b.planned_amount ?? 0;
      cur.actual += b.actual_amount ?? 0;
      byCat.set(b.category, cur);
    }
    return Array.from(byCat.entries()).map(([category, v]) => ({
      category,
      planned: v.planned,
      actual: v.actual,
      variance: v.planned - v.actual,
      usagePct: v.planned > 0 ? (v.actual / v.planned) * 100 : 0,
    }));
  }, [budgets]);

  const budgetTotal = useMemo(() => {
    const planned = budgetRows.reduce((s, r) => s + r.planned, 0);
    const actual = budgetRows.reduce((s, r) => s + r.actual, 0);
    return { planned, actual, variance: planned - actual };
  }, [budgetRows]);

  const yearOptions = useMemo(() => {
    const y = new Date().getFullYear();
    return [y + 1, y, y - 1, y - 2];
  }, []);

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5 p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg">
                <BarChart3 className="h-7 w-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold">ფინანსური დაშბორდი</h1>
                <p className="text-sm text-muted-foreground">საგადასახადო ოპტიმიზაცია · პოზიციების ხელფასი · ბიუჯეტი vs ფაქტი</p>
              </div>
            </div>
            <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
              <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                {yearOptions.map((y) => <SelectItem key={y} value={String(y)}>{y} წ.</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <Tabs defaultValue="tax" className="space-y-4">
            <TabsList className="grid grid-cols-3 w-full max-w-2xl">
              <TabsTrigger value="tax" className="gap-2"><PiggyBank className="h-4 w-4" /> Tax დაზოგვა</TabsTrigger>
              <TabsTrigger value="positions" className="gap-2"><Briefcase className="h-4 w-4" /> პოზიც. ხელფ.</TabsTrigger>
              <TabsTrigger value="budget" className="gap-2"><Wallet className="h-4 w-4" /> ბიუჯ. vs ფაქტი</TabsTrigger>
            </TabsList>

            {/* TAX */}
            <TabsContent value="tax" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <KpiCard label="სულ Gross ხელფასი" value={fmt(taxStats.totalGross)} icon={TrendingUp} tone="emerald" />
                <KpiCard label="საშემოს. გადასახადი (20%)" value={fmt(taxStats.totalIT)} icon={TrendingDown} tone="rose" />
                <KpiCard label="დამსაქმ. პენსია (2%)" value={fmt(taxStats.totalPensionEmployer)} icon={PiggyBank} tone="indigo" />
                <KpiCard label="დაზოგვა (opt-out)" value={fmt(taxStats.optedOutSavings)} sub={`${taxStats.optedOut} თანამშრომელი`} icon={PiggyBank} tone="amber" />
              </div>
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">საგადასახადო ოპტიმიზაციის რეკომენდაციები</CardTitle>
                  <CardDescription>გათვლები საქართველოს კანონმდებლობის მიხედვით</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <Row label="სულ თანამშრომელი" value={`${employees.length}`} />
                  <Row label="საპენსიო სქემიდან გასულები" value={`${taxStats.optedOut}`} />
                  <Row label="წლიური დაზოგვა (opt-out)" value={fmt(taxStats.optedOutSavings * 12)} highlight />
                  <Row label="წლიური საშემოს. გადასახადი" value={fmt(taxStats.totalIT * 12)} />
                </CardContent>
              </Card>
            </TabsContent>

            {/* POSITIONS */}
            <TabsContent value="positions" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">პოზიციების ხელფასის სკალა</CardTitle>
                  <CardDescription>{positionRows.length} პოზიცია · {employees.length} თანამშრომელი</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {loading ? <Skeleton className="h-40 w-full" /> : positionRows.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-8">მონაცემები არ მოიძებნა</p>
                  ) : positionRows.map((r) => {
                    const min = r.jdMin ?? r.empMin;
                    const max = r.jdMax ?? r.empMax;
                    const range = Math.max(1, max - min);
                    const avgPct = Math.min(100, Math.max(0, ((r.avg - min) / range) * 100));
                    return (
                      <div key={r.position} className="space-y-1.5">
                        <div className="flex items-center justify-between text-sm">
                          <div className="font-medium">{r.position}</div>
                          <div className="text-muted-foreground">{r.count} თანამშრომელი · საშ. <span className="font-semibold text-foreground">{fmt(r.avg)}</span></div>
                        </div>
                        <div className="relative h-2.5 rounded-full bg-muted overflow-hidden">
                          <div className="absolute inset-y-0 left-0 right-0 bg-gradient-to-r from-emerald-500/60 via-amber-500/60 to-rose-500/60" />
                          <div className="absolute top-0 h-2.5 w-1 bg-foreground rounded" style={{ left: `${avgPct}%` }} />
                        </div>
                        <div className="flex justify-between text-[11px] text-muted-foreground">
                          <span>{fmt(min)}</span>
                          {r.jdMin === null && <Badge variant="outline" className="h-4 px-1.5 text-[10px]">JD არ არსებობს</Badge>}
                          <span>{fmt(max)}</span>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </TabsContent>

            {/* BUDGET */}
            <TabsContent value="budget" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <KpiCard label="დაგეგმილი" value={fmt(budgetTotal.planned)} icon={Wallet} tone="indigo" />
                <KpiCard label="ფაქტიური" value={fmt(budgetTotal.actual)} icon={TrendingUp} tone="emerald" />
                <KpiCard
                  label="ვარიაცია"
                  value={fmt(Math.abs(budgetTotal.variance))}
                  sub={budgetTotal.variance >= 0 ? "ეკონომია" : "გადახარჯვა"}
                  icon={budgetTotal.variance >= 0 ? TrendingDown : TrendingUp}
                  tone={budgetTotal.variance >= 0 ? "emerald" : "rose"}
                />
              </div>
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">კატეგორიების მიხედვით - {year}</CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? <Skeleton className="h-64 w-full" /> : budgetRows.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-8">ბიუჯეტი {year} წლისთვის არ არსებობს</p>
                  ) : (
                    <ResponsiveContainer width="100%" height={320}>
                      <BarChart data={budgetRows}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis dataKey="category" tick={{ fontSize: 12 }} />
                        <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `₾${Math.round(Number(v) / 1000)}k`} />
                        <RTooltip formatter={(v: number) => fmt(v)} contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                        <Legend />
                        <Bar dataKey="planned" name="დაგეგმილი" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
                        <Bar dataKey="actual" name="ფაქტიური" fill="hsl(142 71% 45%)" radius={[6, 6, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </PageTransition>
  );
}

function KpiCard({ label, value, sub, icon: Icon, tone }: { label: string; value: string; sub?: string; icon: any; tone: "emerald" | "rose" | "indigo" | "amber" }) {
  const tones: Record<string, string> = {
    emerald: "from-emerald-500/15 to-emerald-500/5 text-emerald-600 dark:text-emerald-400",
    rose: "from-rose-500/15 to-rose-500/5 text-rose-600 dark:text-rose-400",
    indigo: "from-indigo-500/15 to-indigo-500/5 text-indigo-600 dark:text-indigo-400",
    amber: "from-amber-500/15 to-amber-500/5 text-amber-600 dark:text-amber-400",
  };
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`p-2.5 rounded-xl bg-gradient-to-br ${tones[tone]}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <div className="text-xs text-muted-foreground truncate">{label}</div>
          <div className="text-lg font-bold truncate">{value}</div>
          {sub && <div className="text-[11px] text-muted-foreground truncate">{sub}</div>}
        </div>
      </CardContent>
    </Card>
  );
}

function Row({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex items-center justify-between py-2 border-b last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className={highlight ? "font-bold text-emerald-600 dark:text-emerald-400" : "font-medium"}>{value}</span>
    </div>
  );
}
