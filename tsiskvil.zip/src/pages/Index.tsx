import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Users, 
  Clock, 
  FileText, 
  Calendar, 
  DollarSign,
  TrendingUp,
  Shield,
  BarChart3,
  Briefcase,
  MessageSquare,
  Bell,
  Building2,
  GraduationCap,
  Award,
  MapPin,
  Plane,
  Car,
  Gift,
  Target,
  Search,
  BookOpen,
  Activity,
  BriefcaseBusiness,
  FileCheck,
  CalendarCheck,
  AlertCircle,
  ChartBar,
  UserCheck,
  FileSpreadsheet,
  Globe,
  LayoutDashboard
} from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

function getGreeting(hour: number): string {
  if (hour < 6) return "ღამე მშვიდობისა 🌙";
  if (hour < 12) return "დილა მშვიდობისა ☀️";
  if (hour < 18) return "შუადღე მშვიდობისა 🌤️";
  return "საღამო მშვიდობისა 🌅";
}

const Index = () => {
  const navigate = useNavigate();
  const { language, setLanguage } = useLanguage();

  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const timeStr = now.toLocaleTimeString("ka-GE", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const dateStr = now.toLocaleDateString("ka-GE", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const greeting = getGreeting(now.getHours());

  const allPages = [
    // მთავარი
    {
      category: "მთავარი",
      pages: [
        { icon: LayoutDashboard, title: "მთავარი გვერდი", description: "სისტემის მიმოხილვა", link: "/dashboard" },
        { icon: Users, title: "თანამშრომლების პორტალი", description: "პერსონალური ინფორმაცია", link: "/employee-portal" },
        { icon: Bell, title: "შეტყობინებები", description: "ყველა შეტყობინება", link: "/notifications" },
      ]
    },
    // პერსონალი
    {
      category: "პერსონალი",
      pages: [
        { icon: Users, title: "თანამშრომლები", description: "სრული მართვა", link: "/employees" },
        { icon: Clock, title: "დასწრება", description: "რეალურ დროში", link: "/attendance" },
        { icon: Calendar, title: "სამუშაო გრაფიკები", description: "გრაფიკების მართვა", link: "/work-schedules" },
        { icon: CalendarCheck, title: "ცვლების გრაფიკები", description: "ცვლების დაგეგმვა", link: "/shift-schedules" },
        { icon: Activity, title: "სამუშაო დროის აღრიცხვა", description: "დროის მართვა", link: "/work-time-tracking" },
        { icon: FileCheck, title: "შვებულებები", description: "შვებულების მოთხოვნები", link: "/leave-requests" },
        { icon: ChartBar, title: "შვებულების სტატისტიკა", description: "ანალიტიკა", link: "/leave-statistics" },
        { icon: Calendar, title: "კალენდარი", description: "ვიზუალიზაცია", link: "/calendar" },
        { icon: CalendarCheck, title: "საჯარო დასვენების დღეები", description: "დღესასწაულების მართვა", link: "/public-holidays" },
      ]
    },
    // ფინანსები
    {
      category: "ფინანსები",
      pages: [
        { icon: DollarSign, title: "ხელფასები", description: "ავტომატური გაანგარიშება", link: "/payroll" },
        { icon: DollarSign, title: "პენსიის გადახდები", description: "პენსია", link: "/pension-payments" },
        { icon: Gift, title: "კომპენსაციები", description: "ბონუსები და ჯილდოები", link: "/compensation" },
        { icon: TrendingUp, title: "ბიუჯეტის დაგეგმვა", description: "ფინანსური დაგეგმვა", link: "/budget-planning" },
        { icon: DollarSign, title: "ბიუჯეტი და ხარჯები", description: "ხარჯების აღრიცხვა", link: "/budget-expenses" },
        { icon: BarChart3, title: "ფინანსური ანგარიშები", description: "დეტალური ანგარიშგება", link: "/financial-reports" },
        { icon: FileText, title: "ფინანსური დოკუმენტაცია", description: "დოკუმენტები", link: "/financial-documentation" },
      ]
    },
    // რეკრუტმენტი
    {
      category: "რეკრუტმენტი",
      pages: [
        { icon: Briefcase, title: "ვაკანსიები", description: "თავისუფალი პოზიციები", link: "/vacancies" },
        { icon: Users, title: "კანდიდატები", description: "განაცხადების მართვა", link: "/candidates" },
        { icon: FileText, title: "განაცხადები", description: "სამუშაოს განაცხადები", link: "/job-applications" },
        { icon: BookOpen, title: "თანამდებობის აღწერილობები", description: "პოზიციების აღწერა", link: "/job-descriptions" },
      ]
    },
    // განვითარება და შეფასება
    {
      category: "განვითარება",
      pages: [
        { icon: Award, title: "შეფასებები", description: "თანამშრომლების შეფასება", link: "/employee-evaluations" },
        { icon: Target, title: "OKR მართვა", description: "მიზნები და შედეგები", link: "/okr-management" },
        { icon: GraduationCap, title: "ტრენინგები", description: "სასწავლო პროგრამები", link: "/training" },
        { icon: FileText, title: "ტრენინგის შაბლონები", description: "Onboarding", link: "/onboarding-templates" },
        { icon: UserCheck, title: "Onboarding", description: "ახალი თანამშრომლები", link: "/onboarding" },
        { icon: MessageSquare, title: "უკუკავშირი", description: "გამოკითხვები", link: "/feedback" },
        { icon: Search, title: "Pulse გამოკითხვები", description: "სწრაფი გამოკითხვები", link: "/pulse-surveys" },
      ]
    },
    // ორგანიზაცია
    {
      category: "ორგანიზაცია",
      pages: [
        { icon: Building2, title: "ორგანიზაციული სტრუქტურა", description: "სტრუქტურა", link: "/organizational-structure" },
        { icon: AlertCircle, title: "დისციპლინური ღონისძიებები", description: "დარღვევები", link: "/disciplinary" },
        { icon: FileText, title: "დოკუმენტები", description: "ციფრული არქივი", link: "/documents" },
        { icon: FileCheck, title: "დოკუმენტების ანგარიშები", description: "სტატუსები", link: "/document-reports" },
        { icon: FileText, title: "ხელშეკრულების შაბლონები", description: "კონტრაქტები", link: "/contract-templates" },
      ]
    },
    // ანგარიშგება
    {
      category: "ანგარიშგება",
      pages: [
        { icon: BarChart3, title: "ანგარიშები", description: "დეტალური ანალიტიკა", link: "/reports" },
        { icon: Clock, title: "გვიანობის ანალიტიკა", description: "დაგვიანება", link: "/lateness-analytics" },
        { icon: Activity, title: "ზეგანაკვეთური მოთხოვნები", description: "Overtime", link: "/overtime-requests" },
        { icon: ChartBar, title: "ზეგანაკვეთური ანგარიშები", description: "ანალიტიკა", link: "/overtime-reports" },
        { icon: FileSpreadsheet, title: "სამუშაო დროის ფორმა", description: "N1 ფორმა", link: "/work-time-form-generator" },
      ]
    },
    // სერვისები
    {
      category: "სერვისები",
      pages: [
        { icon: Plane, title: "მივლინებები", description: "მივლინების მოთხოვნები", link: "/business-trip-requests" },
        { icon: MapPin, title: "სამსახურებრივი გასვლები", description: "Service trips", link: "/service-trips" },
        { icon: Car, title: "ავტომობილის მოთხოვნები", description: "ტრანსპორტი", link: "/vehicle-requests" },
        { icon: BriefcaseBusiness, title: "აქტივების მართვა", description: "ინვენტარი", link: "/asset-management" },
        { icon: Gift, title: "Benefit Plans", description: "სარგებელი", link: "/benefits" },
        { icon: Award, title: "ამოცნობა", description: "Recognition", link: "/recognition" },
        { icon: Bell, title: "გაცნობები", description: "სიახლეები", link: "/announcements" },
      ]
    },
    // სისტემა
    {
      category: "სისტემა",
      pages: [
        { icon: MessageSquare, title: "ჩატი", description: "შიდა კომუნიკაცია", link: "/chat" },
        { icon: BookOpen, title: "დახმარება", description: "მომხმარებლის სახელმძღვანელო", link: "/help" },
      ]
    },
    // CRM
    {
      category: "CRM",
      pages: [
        { icon: Users, title: "კონტაქტები", description: "კლიენტები და პარტნიორები", link: "/contacts" },
        { icon: TrendingUp, title: "გარიგებები", description: "Deals", link: "/deals" },
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      {/* Header */}
      <div className="sticky top-0 z-50 border-b bg-card/95 backdrop-blur-lg pt-[env(safe-area-inset-top)]">
        <div className="container mx-auto px-3 sm:px-4 py-3 sm:py-4 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
            <div className="h-9 w-9 sm:h-10 sm:w-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center shrink-0">
              <Shield className="h-5 w-5 sm:h-6 sm:w-6 text-primary-foreground" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base sm:text-xl font-bold text-foreground truncate">{greeting}</h1>
              <div className="flex items-center gap-1 sm:gap-2 text-[10px] sm:text-xs text-muted-foreground flex-wrap">
                <Clock className="h-3 w-3 shrink-0" />
                <span className="font-mono">{timeStr}</span>
                <span className="hidden sm:inline">·</span>
                <MapPin className="h-3 w-3 shrink-0 hidden sm:inline" />
                <span className="hidden sm:inline">თბილისი</span>
                <span className="hidden sm:inline">·</span>
                <span className="hidden sm:inline">{dateStr}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setLanguage(language === 'ka' ? 'en' : 'ka')}
              className="gap-1 sm:gap-2 px-2 sm:px-3 h-8 sm:h-9 text-xs sm:text-sm"
            >
              <Globe className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
              {language === 'ka' ? 'EN' : 'ქარ'}
            </Button>
            <Button onClick={() => navigate("/auth")} size="sm" className="h-8 sm:h-9 px-3 sm:px-4 text-xs sm:text-sm">შესვლა</Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-8">
        {allPages.map((section, idx) => (
          <div key={idx} className="mb-6 sm:mb-12">
            <div className="mb-3 sm:mb-6">
              <h2 className="text-lg sm:text-2xl font-bold text-foreground mb-1 sm:mb-2">{section.category}</h2>
              <div className="h-0.5 sm:h-1 w-16 sm:w-20 bg-gradient-to-r from-primary to-accent rounded-full" />
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 sm:gap-4">
              {section.pages.map((page, pageIdx) => {
                const Icon = page.icon;
                return (
                  <Card 
                    key={pageIdx}
                    className="group cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-105 hover:border-primary/50 bg-card/50 backdrop-blur-sm"
                    onClick={() => navigate(page.link)}
                  >
                    <CardHeader className="p-2.5 sm:pb-3 sm:p-6">
                      <div className="flex items-center gap-2 sm:flex-col sm:items-start sm:gap-0">
                        <div className="p-1.5 sm:p-2 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors shrink-0">
                          <Icon className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                        </div>
                        <CardTitle className="text-xs sm:text-base sm:mt-3 group-hover:text-primary transition-colors leading-tight">
                          {page.title}
                        </CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent className="px-2.5 pb-2.5 pt-0 sm:pb-4 sm:px-6">
                      <CardDescription className="text-[10px] sm:text-sm leading-tight">{page.description}</CardDescription>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Index;
