import { useState, useEffect } from "react";
import { FileText, CheckCircle, Clock, XCircle, Download, Filter, Search } from "lucide-react";
import { ReportPageShell } from "@/components/reports/ReportPageShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ResponsiveTable, MobileCard, MobileCardRow } from "@/components/ResponsiveTable";
import { useIsMobile } from "@/hooks/use-mobile";
import { exportToExcel } from "@/lib/exportToExcel";

interface DocumentStatus {
  document_id: string;
  document_title: string;
  employee_id: string;
  employee_name: string;
  department: string;
  status: 'acknowledged' | 'pending' | 'rejected';
  created_at: string;
  signed_at: string | null;
  days_pending: number;
}

interface Stats {
  total: number;
  acknowledged: number;
  pending: number;
  rejected: number;
}

export default function DocumentReports() {
  const [documents, setDocuments] = useState<DocumentStatus[]>([]);
  const [stats, setStats] = useState<Stats>({ total: 0, acknowledged: 0, pending: 0, rejected: 0 });
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [departments, setDepartments] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const isMobile = useIsMobile();

  useEffect(() => {
    fetchDocumentStatuses();
    fetchDepartments();
  }, []);

  const fetchDepartments = async () => {
    try {
      const { data, error } = await supabase
        .from('departments')
        .select('name')
        .eq('is_active', true);

      if (error) throw error;
      setDepartments(data?.map(d => d.name) || []);
    } catch (error: any) {
      console.error('Error fetching departments:', error);
    }
  };

  const fetchDocumentStatuses = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('document_signatures')
        .select(`
          id,
          document_id,
          employee_id,
          is_acknowledged,
          signed_at,
          created_at,
          documents:document_id (
            title
          ),
          employees:employee_id (
            full_name,
            department
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const processedData: DocumentStatus[] = (data || []).map((item: any) => {
        const daysPending = item.signed_at 
          ? 0 
          : Math.floor((new Date().getTime() - new Date(item.created_at).getTime()) / (1000 * 60 * 60 * 24));

        let status: 'acknowledged' | 'pending' | 'rejected' = 'pending';
        if (item.is_acknowledged && item.signed_at) {
          status = 'acknowledged';
        } else if (item.is_acknowledged === false && item.signed_at) {
          status = 'rejected';
        }

        return {
          document_id: item.document_id,
          document_title: item.documents?.title || 'უცნობი დოკუმენტი',
          employee_id: item.employee_id,
          employee_name: item.employees?.full_name || 'უცნობი',
          department: item.employees?.department || 'უცნობი',
          status,
          created_at: item.created_at,
          signed_at: item.signed_at,
          days_pending: daysPending,
        };
      });

      setDocuments(processedData);

      // Calculate stats
      const newStats = {
        total: processedData.length,
        acknowledged: processedData.filter(d => d.status === 'acknowledged').length,
        pending: processedData.filter(d => d.status === 'pending').length,
        rejected: processedData.filter(d => d.status === 'rejected').length,
      };
      setStats(newStats);
    } catch (error: any) {
      console.error('Error fetching document statuses:', error);
      toast.error('დოკუმენტების სტატუსების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const handleExport = () => {
    const exportData = filteredDocuments.map(doc => ({
      'დოკუმენტი': doc.document_title,
      'თანამშრომელი': doc.employee_name,
      'დეპარტამენტი': doc.department,
      'სტატუსი': getStatusLabel(doc.status),
      'გაგზავნის თარიღი': new Date(doc.created_at).toLocaleDateString('ka-GE'),
      'ხელმოწერის თარიღი': doc.signed_at ? new Date(doc.signed_at).toLocaleDateString('ka-GE') : '-',
      'დღეები მოლოდინში': doc.days_pending,
    }));

    exportToExcel(exportData, 'დოკუმენტების_სტატუსი');
    toast.success('რეპორტი ექსპორტირებულია');
  };

  const getStatusBadge = (status: string) => {
    const config = {
      acknowledged: { label: 'გაცნობილი', variant: 'default' as const, icon: CheckCircle },
      pending: { label: 'გასაცნობი', variant: 'secondary' as const, icon: Clock },
      rejected: { label: 'უარყოფილი', variant: 'destructive' as const, icon: XCircle },
    };

    const statusConfig = config[status as keyof typeof config] || config.pending;
    const Icon = statusConfig.icon;

    return (
      <Badge variant={statusConfig.variant}>
        <Icon className="h-3 w-3 mr-1" />
        {statusConfig.label}
      </Badge>
    );
  };

  const getStatusLabel = (status: string) => {
    const labels = {
      acknowledged: 'გაცნობილი',
      pending: 'გასაცნობი',
      rejected: 'უარყოფილი',
    };
    return labels[status as keyof typeof labels] || status;
  };

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = 
      doc.document_title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.employee_name.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDepartment = departmentFilter === 'all' || doc.department === departmentFilter;
    const matchesStatus = statusFilter === 'all' || doc.status === statusFilter;

    return matchesSearch && matchesDepartment && matchesStatus;
  });

  return (
    <ReportPageShell
      title="დოკუმენტების სტატუსის რეპორტი"
      description="გაცნობილი, გასაცნობი და უარყოფილი დოკუმენტების მონიტორინგი"
      icon={FileText}
      gradient="from-blue-400 via-blue-500 to-indigo-500"
      shadow="shadow-blue-500/30"
      actions={
        <Button onClick={handleExport} size="lg" className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 shadow-lg">
          <Download className="mr-2 h-4 w-4" />
          ექსპორტი
        </Button>
      }
    >

      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">სულ დოკუმენტი</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">გაცნობილი</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.acknowledged}</div>
            <Progress 
              value={stats.total > 0 ? (stats.acknowledged / stats.total) * 100 : 0} 
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">გასაცნობი</CardTitle>
            <Clock className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.pending}</div>
            <Progress 
              value={stats.total > 0 ? (stats.pending / stats.total) * 100 : 0} 
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">უარყოფილი</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.rejected}</div>
            <Progress 
              value={stats.total > 0 ? (stats.rejected / stats.total) * 100 : 0} 
              className="mt-2"
            />
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            ფილტრები
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="ძიება დოკუმენტის ან თანამშრომლის მიხედვით..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="დეპარტამენტი" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა დეპარტამენტი</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="სტატუსი" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ყველა სტატუსი</SelectItem>
                  <SelectItem value="acknowledged">გაცნობილი</SelectItem>
                  <SelectItem value="pending">გასაცნობი</SelectItem>
                  <SelectItem value="rejected">უარყოფილი</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Documents Table */}
      <Card>
        <CardHeader>
          <CardTitle>დოკუმენტების დეტალური სია</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveTable
            data={filteredDocuments}
            mobileCards={(doc: DocumentStatus) => (
              <MobileCard key={doc.document_id + doc.employee_id}>
                <MobileCardRow label="დოკუმენტი" value={doc.document_title} />
                <MobileCardRow label="თანამშრომელი" value={doc.employee_name} />
                <MobileCardRow label="დეპარტამენტი" value={doc.department} />
                <MobileCardRow label="სტატუსი" value={getStatusBadge(doc.status)} />
                <MobileCardRow 
                  label="გაგზავნის თარიღი" 
                  value={new Date(doc.created_at).toLocaleDateString('ka-GE')} 
                />
                {doc.signed_at && (
                  <MobileCardRow 
                    label="ხელმოწერის თარიღი" 
                    value={new Date(doc.signed_at).toLocaleDateString('ka-GE')} 
                  />
                )}
                {doc.status === 'pending' && (
                  <MobileCardRow 
                    label="დღეები მოლოდინში" 
                    value={
                      <Badge variant={doc.days_pending > 5 ? 'destructive' : 'secondary'}>
                        {doc.days_pending} დღე
                      </Badge>
                    } 
                  />
                )}
              </MobileCard>
            )}
          >
            <TableHeader>
              <TableRow>
                <TableHead>დოკუმენტი</TableHead>
                <TableHead>თანამშრომელი</TableHead>
                <TableHead>დეპარტამენტი</TableHead>
                <TableHead>სტატუსი</TableHead>
                <TableHead>გაგზავნის თარიღი</TableHead>
                <TableHead>ხელმოწერის თარიღი</TableHead>
                <TableHead>დღეები მოლოდინში</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center">
                    იტვირთება...
                  </TableCell>
                </TableRow>
              ) : filteredDocuments.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground">
                    დოკუმენტები არ მოიძებნა
                  </TableCell>
                </TableRow>
              ) : (
                filteredDocuments.map((doc, index) => (
                  <TableRow key={`${doc.document_id}-${doc.employee_id}-${index}`}>
                    <TableCell className="font-medium">{doc.document_title}</TableCell>
                    <TableCell>{doc.employee_name}</TableCell>
                    <TableCell>{doc.department}</TableCell>
                    <TableCell>{getStatusBadge(doc.status)}</TableCell>
                    <TableCell>
                      {new Date(doc.created_at).toLocaleDateString('ka-GE')}
                    </TableCell>
                    <TableCell>
                      {doc.signed_at 
                        ? new Date(doc.signed_at).toLocaleDateString('ka-GE')
                        : '-'
                      }
                    </TableCell>
                    <TableCell>
                      {doc.status === 'pending' ? (
                        <Badge variant={doc.days_pending > 5 ? 'destructive' : 'secondary'}>
                          {doc.days_pending} დღე
                        </Badge>
                      ) : (
                        '-'
                      )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </ResponsiveTable>
        </CardContent>
      </Card>
    </ReportPageShell>
  );
}
