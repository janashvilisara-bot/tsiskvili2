import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Plus, Star, TrendingUp, MessageSquare, Calendar } from "lucide-react";
import { RiskPredictionButton, PerformanceAIButton } from "@/components/evaluations/AIAnalysisButtons";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";

interface Evaluation {
  id: string;
  employee_id: string;
  evaluator_id: string;
  evaluation_date: string;
  period_start: string;
  period_end: string;
  overall_rating: number;
  performance_rating: number;
  teamwork_rating: number;
  communication_rating: number;
  leadership_rating: number;
  strengths: string;
  areas_for_improvement: string;
  goals: string;
  comments: string;
  status: string;
}

export default function EmployeeEvaluations() {
  const { id } = useParams();
  const { user, userRole } = useAuth();
  const { t } = useLanguage();
  const [evaluations, setEvaluations] = useState<Evaluation[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [employee, setEmployee] = useState<any>(null);
  const [overallRating, setOverallRating] = useState("");
  const [performanceRating, setPerformanceRating] = useState("");
  const [teamworkRating, setTeamworkRating] = useState("");
  const [communicationRating, setCommunicationRating] = useState("");
  const [leadershipRating, setLeadershipRating] = useState("");

  const canCreateEvaluation = userRole === 'admin' || userRole === 'hr_manager';

  useEffect(() => {
    if (id) {
      fetchEmployee();
      fetchEvaluations();
    }
  }, [id]);

  const fetchEmployee = async () => {
    const { data, error } = await supabase
      .from('employees')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) {
      console.error('Error fetching employee:', error);
      toast.error('თანამშრომლის ჩატვირთვა ვერ მოხერხდა');
    } else if (data) {
      setEmployee(data);
    }
  };

  const fetchEvaluations = async () => {
    const { data, error } = await supabase
      .from('employee_evaluations')
      .select('*')
      .eq('employee_id', id)
      .order('evaluation_date', { ascending: false });

    if (error) {
      toast.error('შეფასებების ჩატვირთვა ვერ მოხერხდა');
    } else {
      setEvaluations(data || []);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const formData = new FormData(e.currentTarget);

    try {
      const payload = {
        employee_id: id,
        evaluator_id: user?.id,
        period_start: formData.get('period_start') as string,
        period_end: formData.get('period_end') as string,
        overall_rating: parseInt(overallRating),
        performance_rating: parseInt(performanceRating),
        teamwork_rating: parseInt(teamworkRating),
        communication_rating: parseInt(communicationRating),
        leadership_rating: parseInt(leadershipRating),
        strengths: formData.get('strengths') as string,
        areas_for_improvement: formData.get('areas_for_improvement') as string,
        goals: formData.get('goals') as string,
        comments: formData.get('comments') as string,
        status: 'submitted',
      };

      const { error } = await supabase
        .from('employee_evaluations')
        .insert([payload]);

      if (error) throw error;

      toast.success('შეფასება წარმატებით დაემატა');
      setIsDialogOpen(false);
      setOverallRating("");
      setPerformanceRating("");
      setTeamworkRating("");
      setCommunicationRating("");
      setLeadershipRating("");
      fetchEvaluations();
      (e.target as HTMLFormElement).reset();
    } catch (error: any) {
      toast.error(error.message || 'შეცდომა მოხდა');
    } finally {
      setIsLoading(false);
    }
  };

  const RatingStars = ({ rating }: { rating: number }) => (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          className={`h-4 w-4 ${
            star <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground'
          }`}
        />
      ))}
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">შეფასებები</h1>
          {employee && (
            <p className="mt-2 text-muted-foreground">
              {employee.full_name} - {employee.position}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2">
          {canCreateEvaluation && id && employee && (
            <>
              <RiskPredictionButton employeeId={id} employeeName={employee.full_name} />
              <PerformanceAIButton employeeId={id} employeeName={employee.full_name} />
            </>
          )}
          {canCreateEvaluation && (
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                ახალი შეფასება
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto max-w-2xl">
              <DialogHeader>
                <DialogTitle>ახალი შეფასება</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <Label htmlFor="period_start">პერიოდის დასაწყისი *</Label>
                    <Input id="period_start" name="period_start" type="date" required />
                  </div>
                  <div>
                    <Label htmlFor="period_end">პერიოდის დასასრული *</Label>
                    <Input id="period_end" name="period_end" type="date" required />
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="font-semibold">რეიტინგები (1-5)</h3>
                  
                  <div>
                    <Label htmlFor="overall_rating">მთლიანი რეიტინგი *</Label>
                    <Select value={overallRating} onValueChange={setOverallRating} required>
                      <SelectTrigger>
                        <SelectValue placeholder="აირჩიეთ" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 - ცუდი</SelectItem>
                        <SelectItem value="2">2 - დაბალი</SelectItem>
                        <SelectItem value="3">3 - საშუალო</SelectItem>
                        <SelectItem value="4">4 - კარგი</SelectItem>
                        <SelectItem value="5">5 - შესანიშნავი</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="performance_rating">ეფექტურობა *</Label>
                    <Select value={performanceRating} onValueChange={setPerformanceRating} required>
                      <SelectTrigger>
                        <SelectValue placeholder="აირჩიეთ" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="5">5</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="teamwork_rating">გუნდური მუშაობა *</Label>
                    <Select value={teamworkRating} onValueChange={setTeamworkRating} required>
                      <SelectTrigger>
                        <SelectValue placeholder="აირჩიეთ" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="5">5</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="communication_rating">კომუნიკაცია *</Label>
                    <Select value={communicationRating} onValueChange={setCommunicationRating} required>
                      <SelectTrigger>
                        <SelectValue placeholder="აირჩიეთ" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="5">5</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="leadership_rating">ლიდერობა *</Label>
                    <Select value={leadershipRating} onValueChange={setLeadershipRating} required>
                      <SelectTrigger>
                        <SelectValue placeholder="აირჩიეთ" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="5">5</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="strengths">ძლიერი მხარეები</Label>
                  <Textarea
                    id="strengths"
                    name="strengths"
                    placeholder="აღწერეთ ძლიერი მხარეები..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="areas_for_improvement">გასაუმჯობესებელი მხარეები</Label>
                  <Textarea
                    id="areas_for_improvement"
                    name="areas_for_improvement"
                    placeholder="აღწერეთ გასაუმჯობესებელი მხარეები..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="goals">მიზნები</Label>
                  <Textarea
                    id="goals"
                    name="goals"
                    placeholder="დასახეთ მიზნები..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="comments">კომენტარები</Label>
                  <Textarea
                    id="comments"
                    name="comments"
                    placeholder="დამატებითი კომენტარები..."
                    rows={3}
                  />
                </div>

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'დამატება...' : 'შეფასების დამატება'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
        </div>
      </div>

      <div className="grid gap-4">
        {evaluations.map((evaluation) => (
          <Card key={evaluation.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    შეფასება - {new Date(evaluation.evaluation_date).toLocaleDateString('ka-GE')}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    პერიოდი: {new Date(evaluation.period_start).toLocaleDateString('ka-GE')} -{' '}
                    {new Date(evaluation.period_end).toLocaleDateString('ka-GE')}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <RatingStars rating={evaluation.overall_rating} />
                  <span className="text-sm text-muted-foreground">
                    მთლიანი: {evaluation.overall_rating}/5
                  </span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <TrendingUp className="h-4 w-4" />
                    ეფექტურობა
                  </div>
                  <RatingStars rating={evaluation.performance_rating} />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Star className="h-4 w-4" />
                    გუნდური მუშაობა
                  </div>
                  <RatingStars rating={evaluation.teamwork_rating} />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <MessageSquare className="h-4 w-4" />
                    კომუნიკაცია
                  </div>
                  <RatingStars rating={evaluation.communication_rating} />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Star className="h-4 w-4" />
                    ლიდერობა
                  </div>
                  <RatingStars rating={evaluation.leadership_rating} />
                </div>
              </div>

              {evaluation.strengths && (
                <div>
                  <h4 className="font-semibold text-sm mb-1">ძლიერი მხარეები:</h4>
                  <p className="text-sm text-muted-foreground">{evaluation.strengths}</p>
                </div>
              )}

              {evaluation.areas_for_improvement && (
                <div>
                  <h4 className="font-semibold text-sm mb-1">გასაუმჯობესებელი მხარეები:</h4>
                  <p className="text-sm text-muted-foreground">{evaluation.areas_for_improvement}</p>
                </div>
              )}

              {evaluation.goals && (
                <div>
                  <h4 className="font-semibold text-sm mb-1">მიზნები:</h4>
                  <p className="text-sm text-muted-foreground">{evaluation.goals}</p>
                </div>
              )}

              {evaluation.comments && (
                <div>
                  <h4 className="font-semibold text-sm mb-1">კომენტარები:</h4>
                  <p className="text-sm text-muted-foreground">{evaluation.comments}</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}

        {evaluations.length === 0 && (
          <Card>
            <CardContent className="flex h-32 items-center justify-center text-muted-foreground">
              შეფასებები არ მოიძებნა
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
