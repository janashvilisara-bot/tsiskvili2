import { useEffect, useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  Sparkles, FileText, BookText, ShieldCheck, Lock, Clock, HardHat, FileEdit,
  Loader2, Download, Copy, Save, Trash2, Eye, Plus,
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

const ICONS: Record<string, any> = {
  FileText, BookText, ShieldCheck, Lock, Clock, HardHat, FileEdit,
};

interface Question {
  key: string;
  label: string;
  type: "text" | "textarea" | "number" | "date" | "select";
  required?: boolean;
  default?: any;
  options?: string[];
}

interface Template {
  id: string;
  code: string;
  name_ka: string;
  description_ka: string | null;
  category: string;
  icon: string;
  questions_schema: Question[];
  sort_order: number;
}

interface GeneratedDoc {
  id: string;
  title: string;
  template_code: string;
  content: string;
  status: string;
  created_at: string;
}

export default function AIDocuments() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [templates, setTemplates] = useState<Template[]>([]);
  const [docs, setDocs] = useState<GeneratedDoc[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTpl, setActiveTpl] = useState<Template | null>(null);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [generating, setGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<string>("");
  const [viewDoc, setViewDoc] = useState<GeneratedDoc | null>(null);

  const loadData = async () => {
    setLoading(true);
    const [tplRes, docRes] = await Promise.all([
      supabase.from("ai_document_templates").select("*").eq("is_active", true).order("sort_order"),
      supabase.from("ai_generated_documents").select("id,title,template_code,content,status,created_at").order("created_at", { ascending: false }).limit(50),
    ]);
    if (tplRes.data) setTemplates(tplRes.data as any);
    if (docRes.data) setDocs(docRes.data as any);
    setLoading(false);
  };

  useEffect(() => { loadData(); }, []);

  const openTemplate = (tpl: Template) => {
    setActiveTpl(tpl);
    const init: Record<string, any> = {};
    (tpl.questions_schema || []).forEach((q) => {
      if (q.default !== undefined) init[q.key] = q.default;
    });
    setAnswers(init);
    setGeneratedContent("");
  };

  const handleGenerate = async () => {
    if (!activeTpl) return;
    const missing = (activeTpl.questions_schema || []).find(
      (q) => q.required && (answers[q.key] === undefined || answers[q.key] === "")
    );
    if (missing) {
      toast({ title: "ვალიდაცია", description: `შეავსეთ: ${missing.label}`, variant: "destructive" });
      return;
    }
    setGenerating(true);
    setGeneratedContent("");
    try {
      const { data, error } = await supabase.functions.invoke("ai-generate-hr-document", {
        body: { templateCode: activeTpl.code, answers },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setGeneratedContent(data.content);
      toast({ title: "მზადაა", description: "დოკუმენტი დაგენერირდა. შეგიძლიათ შეინახოთ ან გადმოწეროთ." });
    } catch (e: any) {
      toast({ title: "შეცდომა", description: e.message || "გენერაცია ვერ მოხერხდა", variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  };

  const handleSave = async () => {
    if (!activeTpl || !generatedContent || !user) return;
    const title = `${activeTpl.name_ka} - ${new Date().toLocaleDateString("ka-GE")}`;
    const { error } = await supabase.from("ai_generated_documents").insert({
      template_id: activeTpl.id,
      template_code: activeTpl.code,
      title,
      answers,
      content: generatedContent,
      status: "draft",
      created_by: user.id,
    });
    if (error) {
      toast({ title: "შენახვა ვერ მოხერხდა", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "შენახულია", description: "დოკუმენტი დაემატა არქივში." });
    setActiveTpl(null);
    loadData();
  };

  const downloadMd = (content: string, title: string) => {
    const blob = new Blob([content], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = (content: string) => {
    navigator.clipboard.writeText(content);
    toast({ title: "დაკოპირდა", description: "შინაარსი ბუფერშია." });
  };

  const deleteDoc = async (id: string) => {
    if (!confirm("დარწმუნებული ხართ?")) return;
    const { error } = await supabase.from("ai_generated_documents").delete().eq("id", id);
    if (error) {
      toast({ title: "შეცდომა", description: error.message, variant: "destructive" });
      return;
    }
    loadData();
  };

  const grouped = useMemo(() => {
    const g: Record<string, Template[]> = {};
    templates.forEach((t) => {
      g[t.category] = g[t.category] || [];
      g[t.category].push(t);
    });
    return g;
  }, [templates]);

  const categoryLabels: Record<string, string> = {
    policy: "პოლიტიკები",
    contract: "ხელშეკრულებები",
    appendix: "დანართები",
    general: "ზოგადი",
  };

  return (
    <div className="container mx-auto py-6 space-y-6 max-w-7xl">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Sparkles className="h-7 w-7 text-primary" />
            AI HR დოკუმენტები
          </h1>
          <p className="text-muted-foreground mt-1">
            ავტომატური დოკუმენტების შედგენა საქართველოს შრომის კოდექსის შესაბამისად
          </p>
        </div>
      </div>

      <Tabs defaultValue="generate" className="w-full">
        <TabsList>
          <TabsTrigger value="generate">
            <Plus className="h-4 w-4 mr-2" />
            ახლის შექმნა
          </TabsTrigger>
          <TabsTrigger value="archive">
            <FileText className="h-4 w-4 mr-2" />
            არქივი ({docs.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="generate" className="space-y-6">
          {loading ? (
            <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
          ) : (
            Object.entries(grouped).map(([cat, tpls]) => (
              <div key={cat}>
                <h2 className="text-lg font-semibold mb-3">{categoryLabels[cat] || cat}</h2>
                <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                  {tpls.map((tpl) => {
                    const Icon = ICONS[tpl.icon] || FileText;
                    return (
                      <Card key={tpl.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => openTemplate(tpl)}>
                        <CardHeader>
                          <div className="flex items-start gap-3">
                            <div className="p-2 rounded-lg bg-primary/10 text-primary">
                              <Icon className="h-5 w-5" />
                            </div>
                            <div className="flex-1">
                              <CardTitle className="text-base">{tpl.name_ka}</CardTitle>
                              <CardDescription className="text-xs mt-1 line-clamp-2">{tpl.description_ka}</CardDescription>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <Button size="sm" className="w-full">
                            <Sparkles className="h-3.5 w-3.5 mr-2" />
                            შექმნა
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </TabsContent>

        <TabsContent value="archive">
          {docs.length === 0 ? (
            <Card><CardContent className="py-12 text-center text-muted-foreground">დოკუმენტები ჯერ არ შენახულა</CardContent></Card>
          ) : (
            <div className="space-y-2">
              {docs.map((d) => (
                <Card key={d.id}>
                  <CardContent className="p-4 flex items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{d.title}</div>
                      <div className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
                        <Badge variant="outline">{d.status}</Badge>
                        <span>{new Date(d.created_at).toLocaleString("ka-GE")}</span>
                      </div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Button size="icon" variant="ghost" onClick={() => setViewDoc(d)}><Eye className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => downloadMd(d.content, d.title)}><Download className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => copyToClipboard(d.content)}><Copy className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => deleteDoc(d.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Generation Dialog */}
      <Dialog open={!!activeTpl} onOpenChange={(o) => !o && setActiveTpl(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              {activeTpl?.name_ka}
            </DialogTitle>
            <DialogDescription>{activeTpl?.description_ka}</DialogDescription>
          </DialogHeader>

          {!generatedContent ? (
            <div className="space-y-4">
              {(activeTpl?.questions_schema || []).map((q) => (
                <div key={q.key} className="space-y-2">
                  <Label>
                    {q.label} {q.required && <span className="text-destructive">*</span>}
                  </Label>
                  {q.type === "textarea" ? (
                    <Textarea
                      value={answers[q.key] ?? ""}
                      onChange={(e) => setAnswers({ ...answers, [q.key]: e.target.value })}
                      rows={3}
                    />
                  ) : q.type === "select" ? (
                    <Select value={answers[q.key] ?? ""} onValueChange={(v) => setAnswers({ ...answers, [q.key]: v })}>
                      <SelectTrigger><SelectValue placeholder="აირჩიეთ..." /></SelectTrigger>
                      <SelectContent>
                        {(q.options || []).map((opt) => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  ) : (
                    <Input
                      type={q.type === "number" ? "number" : q.type === "date" ? "date" : "text"}
                      value={answers[q.key] ?? ""}
                      onChange={(e) => setAnswers({ ...answers, [q.key]: q.type === "number" ? Number(e.target.value) : e.target.value })}
                    />
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              <div className="prose prose-sm dark:prose-invert max-w-none border rounded-lg p-4 bg-muted/30 max-h-[60vh] overflow-y-auto">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{generatedContent}</ReactMarkdown>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2 flex-wrap">
            {!generatedContent ? (
              <>
                <Button variant="outline" onClick={() => setActiveTpl(null)}>გაუქმება</Button>
                <Button onClick={handleGenerate} disabled={generating}>
                  {generating ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> გენერაცია...</> : <><Sparkles className="h-4 w-4 mr-2" /> AI გენერაცია</>}
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => setGeneratedContent("")}>
                  ხელახლა
                </Button>
                <Button variant="outline" onClick={() => copyToClipboard(generatedContent)}><Copy className="h-4 w-4 mr-2" /> კოპირება</Button>
                <Button variant="outline" onClick={() => downloadMd(generatedContent, activeTpl?.name_ka || "document")}>
                  <Download className="h-4 w-4 mr-2" /> ჩამოტვირთვა
                </Button>
                <Button onClick={handleSave}><Save className="h-4 w-4 mr-2" /> შენახვა</Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={!!viewDoc} onOpenChange={(o) => !o && setViewDoc(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{viewDoc?.title}</DialogTitle>
          </DialogHeader>
          <div className="prose prose-sm dark:prose-invert max-w-none border rounded-lg p-4 bg-muted/30">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{viewDoc?.content || ""}</ReactMarkdown>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => copyToClipboard(viewDoc?.content || "")}><Copy className="h-4 w-4 mr-2" /> კოპირება</Button>
            <Button onClick={() => downloadMd(viewDoc?.content || "", viewDoc?.title || "doc")}><Download className="h-4 w-4 mr-2" /> ჩამოტვირთვა</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
