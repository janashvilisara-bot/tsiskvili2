import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, Calendar, Users, Award, MapPin, Video, GraduationCap, Stethoscope } from "lucide-react";
import { AddTrainingDialog } from "@/components/training/AddTrainingDialog";
import { SmartAcademyCourses } from "@/components/training/SmartAcademyCourses";
import { FindMeConsultations } from "@/components/training/FindMeConsultations";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Training {
  id: string;
  title: string;
  description: string | null;
  category: string;
  course_status: string;
  instructor_name: string | null;
  start_date: string;
  end_date: string | null;
  duration_weeks: number | null;
  max_participants: number | null;
  location: string | null;
  is_online: boolean;
  meeting_link: string | null;
  participants?: Array<{ id: string }>;
}

interface EmployeeTrainingStats {
  employee_id: string;
  full_name: string;
  training_count: number;
  completed_count: number;
  in_progress_count: number;
}

export default function Training() {
  const [trainings, setTrainings] = useState<Training[]>([]);
  const [employeeStats, setEmployeeStats] = useState<EmployeeTrainingStats[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchEmployeeStats = async () => {
    try {
      // Fetch participants without foreign key joins
      const { data: participants, error: participantsError } = await supabase
        .from('training_participants')
        .select('employee_id, training_id');

      if (participantsError) throw participantsError;

      if (!participants || participants.length === 0) {
        setEmployeeStats([]);
        return;
      }

      // Get unique employee and training IDs
      const employeeIds = [...new Set(participants.map(p => p.employee_id))];
      const trainingIds = [...new Set(participants.map(p => p.training_id))];

      // Fetch employees and trainings separately
      const [employeesResult, trainingsResult] = await Promise.all([
        supabase.from('employees').select('id, full_name').in('id', employeeIds),
        supabase.from('training_courses').select('id, course_status').in('id', trainingIds)
      ]);

      const employeesMap = new Map(employeesResult.data?.map(e => [e.id, e.full_name]) || []);
      const trainingsMap = new Map(trainingsResult.data?.map(t => [t.id, t.course_status]) || []);

      const statsMap = new Map<string, EmployeeTrainingStats>();
      
      participants.forEach((p) => {
        const empId = p.employee_id;
        const empName = employeesMap.get(empId) || 'უცნობი';
        const trainingStatus = trainingsMap.get(p.training_id);
        
        if (!statsMap.has(empId)) {
          statsMap.set(empId, {
            employee_id: empId,
            full_name: empName,
            training_count: 0,
            completed_count: 0,
            in_progress_count: 0
          });
        }
        
        const stats = statsMap.get(empId)!;
        stats.training_count++;
        
        if (trainingStatus === 'completed') {
          stats.completed_count++;
        } else if (trainingStatus === 'active') {
          stats.in_progress_count++;
        }
      });
      
      const statsArray = Array.from(statsMap.values())
        .sort((a, b) => b.training_count - a.training_count);
      
      setEmployeeStats(statsArray);
    } catch (error) {
      console.error('Error fetching employee stats:', error);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      await Promise.all([fetchTrainings(), fetchEmployeeStats()]);
    };
    loadData();
  }, []);

  const fetchTrainings = async () => {
    try {
      const { data, error } = await supabase
        .from("training_courses")
        .select(`
          *,
          participants:training_participants(id)
        `)
        .order("start_date", { ascending: false });

      if (error) throw error;
      setTrainings(data || []);
    } catch (error) {
      console.error("Error fetching trainings:", error);
      toast({
        title: "შეცდომა",
        description: "ტრენინგების ჩატვირთვა ვერ მოხერხდა",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const stats = {
    total: trainings.length,
    active: trainings.filter(t => t.course_status === 'active').length,
    participants: trainings.reduce((sum, t) => sum + (t.participants?.length || 0), 0),
    completionRate: trainings.length > 0 
      ? Math.round((trainings.filter(t => t.course_status === 'completed').length / trainings.length) * 100)
      : 0,
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      active: { variant: "default" as const, label: "აქტიური" },
      upcoming: { variant: "secondary" as const, label: "დაგეგმილი" },
      completed: { variant: "outline" as const, label: "დასრულებული" },
      cancelled: { variant: "destructive" as const, label: "გაუქმებული" },
    };
    return variants[status as keyof typeof variants] || variants.upcoming;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-lg">იტვირთება...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">ტრენინგები</h1>
            <p className="text-muted-foreground mt-2">
              თანამშრომელთა განვითარების პროგრამები
            </p>
          </div>
          <AddTrainingDialog />
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">სულ ტრენინგები</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-xs text-muted-foreground">ყველა პროგრამა</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">აქტიური კურსები</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.active}</div>
              <p className="text-xs text-muted-foreground">მიმდინარე</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">მონაწილეები</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.participants}</div>
              <p className="text-xs text-muted-foreground">თანამშრომელი</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">დასრულების %</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.completionRate}%</div>
              <p className="text-xs text-muted-foreground">წარმატება</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="internal" className="space-y-4">
          <TabsList>
            <TabsTrigger value="internal" className="gap-2">
              <BookOpen className="h-4 w-4" />
              შიდა ტრენინგები
            </TabsTrigger>
            <TabsTrigger value="smart-academy" className="gap-2">
              <GraduationCap className="h-4 w-4" />
              Smart Academy
            </TabsTrigger>
            <TabsTrigger value="findme" className="gap-2">
              <Stethoscope className="h-4 w-4" />
              FindMe
            </TabsTrigger>
          </TabsList>

          <TabsContent value="internal" className="space-y-6">
            {/* Employee Training Statistics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  თანამშრომლების სტატისტიკა
                </CardTitle>
              </CardHeader>
              <CardContent>
                {employeeStats.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">
                    არ არის მონაცემები
                  </p>
                ) : (
                  <div className="space-y-3">
                    {employeeStats.map((stat) => (
                      <div
                        key={stat.employee_id}
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50 transition-colors"
                      >
                        <div className="flex-1">
                          <h4 className="font-medium">{stat.full_name}</h4>
                          <div className="flex gap-4 mt-2 text-sm text-muted-foreground">
                            <span>სულ: {stat.training_count}</span>
                            <span className="text-green-600">დასრულებული: {stat.completed_count}</span>
                            <span className="text-blue-600">მიმდინარე: {stat.in_progress_count}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-primary">
                            {stat.training_count}
                          </div>
                          <div className="text-xs text-muted-foreground">ტრენინგი</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>ტრენინგების სია</CardTitle>
              </CardHeader>
              <CardContent>
                {trainings.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>ტრენინგები ჯერ არ არის დამატებული</p>
                    <p className="text-sm mt-2">დააჭირეთ "ახალი ტრენინგი" ღილაკს დასამატებლად</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {trainings.map((training) => {
                      const statusBadge = getStatusBadge(training.course_status);
                      return (
                        <div
                          key={training.id}
                          className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div className="space-y-1 flex-1">
                            <div className="flex items-center gap-3">
                              <h3 className="font-semibold">{training.title}</h3>
                              <Badge variant={statusBadge.variant}>
                                {statusBadge.label}
                              </Badge>
                            </div>
                            {training.description && (
                              <p className="text-sm text-muted-foreground line-clamp-1">
                                {training.description}
                              </p>
                            )}
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <BookOpen className="h-4 w-4" />
                                {training.category}
                              </span>
                              <span className="flex items-center gap-1">
                                <Users className="h-4 w-4" />
                                {training.participants?.length || 0}
                                {training.max_participants && ` / ${training.max_participants}`} მონაწილე
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                {new Date(training.start_date).toLocaleDateString('ka-GE')}
                              </span>
                              {training.duration_weeks && (
                                <span>{training.duration_weeks} კვირა</span>
                              )}
                              {training.is_online ? (
                                <span className="flex items-center gap-1">
                                  <Video className="h-4 w-4" />
                                  ონლაინ
                                </span>
                              ) : training.location && (
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-4 w-4" />
                                  {training.location}
                                </span>
                              )}
                            </div>
                            {training.instructor_name && (
                              <p className="text-sm text-muted-foreground">
                                ინსტრუქტორი: {training.instructor_name}
                              </p>
                            )}
                          </div>
                          <Button variant="outline" size="sm">
                            დეტალები
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="smart-academy">
            <SmartAcademyCourses />
          </TabsContent>

          <TabsContent value="findme">
            <FindMeConsultations />
          </TabsContent>
        </Tabs>
      </div>
  );
}

