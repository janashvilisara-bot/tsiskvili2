import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useBranchFilter } from "@/hooks/useBranchFilter";
import { loadPerformanceInputs } from "@/hooks/usePerformanceData";
import { performanceScore, potentialScore, toLevel, type Level } from "@/lib/performanceScore";

interface Row { id: string; full_name: string; department: string | null; position: string | null; perf: number | null; pot: number | null }
interface Mobility { employee_id: string; full_name: string; current_fit: number | null; role: string; fit: number }

const LEVELS: Level[] = ["low", "mid", "high"];

export default function TalentMap() {
  const { userRole } = useAuth();
  const { language } = useLanguage();
  const L = (ka: string, en: string) => (language === "en" ? en : ka);
  const navigate = useNavigate();
  const branchId = useBranchFilter();
  const [rows, setRows] = useState<Row[] | null>(null);
  const [mobility, setMobility] = useState<Mobility[]>([]);
  const [dept, setDept] = useState("all");
  const [pos, setPos] = useState("all");
  const allowed = userRole === "admin" || userRole === "hr_manager";

  useEffect(() => {
    if (!allowed) return;
    (async () => {
      setRows(null);
      let q = supabase.from("employees").select("id, user_id, full_name, department, position").eq("status", "active").order("full_name");
      if (branchId) q = q.eq("branch_id", branchId);
      const { data: emps } = await q;
      const list = emps || [];
      const inputs = await loadPerformanceInputs(list);
      setRows(list.map((e: any) => ({ id: e.id, full_name: e.full_name, department: e.department, position: e.position, perf: performanceScore(inputs[e.id]), pot: potentialScore(inputs[e.id]) })));
      const ids = list.map((e: any) => e.id);
      if (ids.length) {
        const { data: fits } = await supabase.from("employee_role_fit").select("employee_id, current_fit, top_matches, created_at").in("employee_id", ids).order("created_at", { ascending: false });
        const seen = new Set<string>();
        const names = new Map(list.map((e: any) => [e.id, e.full_name]));
        const mob: Mobility[] = [];
        (fits || []).forEach((f: any) => {
          if (seen.has(f.employee_id)) return;
          seen.add(f.employee_id);
          const best = (f.top_matches || [])[0];
          if (best && best.fit >= 70 && best.fit > (f.current_fit ?? 0)) mob.push({ employee_id: f.employee_id, full_name: names.get(f.employee_id) || "", current_fit: f.current_fit, role: best.role, fit: best.fit });
        });
        setMobility(mob.sort((a, b) => b.fit - a.fit));
      } else setMobility([]);
    })();
  }, [branchId, allowed]);

  const depts = useMemo(() => [...new Set((rows || []).map((r) => r.department).filter(Boolean))] as string[], [rows]);
  const positions = useMemo(() => [...new Set((rows || []).map((r) => r.position).filter(Boolean))] as string[], [rows]);
  const filtered = (rows || []).filter((r) => (dept === "all" || r.department === dept) && (pos === "all" || r.position === pos));
  const placed = filtered.filter((r) => r.perf !== null && r.pot !== null);
  const unplaced = filtered.length - placed.length;

  if (!allowed) return <p className="p-6 text-muted-foreground">{L("ეს გვერდი მხოლოდ ადმინისა და HR-ისთვისაა.", "This page is for admins and HR only.")}</p>;

  const boxName: Record<string, [string, string]> = {
    "high-high": ["ვარსკვლავები", "Stars"], "mid-high": ["მომავალი ლიდერები", "Future leaders"], "low-high": ["გამოუყენებელი პოტენციალი", "Untapped potential"],
    "high-mid": ["ძლიერი შემსრულებლები", "Strong performers"], "mid-mid": ["სტაბილური ბირთვი", "Core players"], "low-mid": ["განვითარება სჭირდება", "Needs development"],
    "high-low": ["საიმედო ექსპერტები", "Trusted experts"], "mid-low": ["ეფექტური", "Effective"], "low-low": ["ყურადღება სჭირდება", "Needs attention"],
  };

  return (
    <div className="space-y-4 p-4 md:p-6">
      <div>
        <h1 className="text-2xl font-semibold">{L("ტალანტების რუკა", "Talent map")}</h1>
        <p className="text-sm text-muted-foreground">{L("შედეგები და პოტენციალი ერთ ბადეზე. დააჭირეთ თანამშრომელს დეტალებისთვის.", "Performance and potential on one grid. Click a person for details.")}</p>
      </div>
      <div className="flex flex-wrap gap-2">
        <Select value={dept} onValueChange={setDept}>
          <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">{L("ყველა დეპარტამენტი", "All departments")}</SelectItem>{depts.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={pos} onValueChange={setPos}>
          <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">{L("ყველა პოზიცია", "All positions")}</SelectItem>{positions.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
        </Select>
      </div>

      {!rows ? <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div> : (
        <>
          <div className="flex gap-2">
            <div className="hidden sm:flex items-center"><span className="-rotate-90 text-xs text-muted-foreground whitespace-nowrap">{L("პოტენციალი →", "Potential →")}</span></div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 flex-1">
              {[...LEVELS].reverse().map((p) => LEVELS.map((f) => {
                const key = `${f}-${p}`;
                const people = placed.filter((r) => toLevel(r.perf!) === f && toLevel(r.pot!) === p);
                return (
                  <Card key={key} className="min-h-[140px]">
                    <CardHeader className="p-3 pb-1"><CardTitle className="text-sm flex justify-between gap-2"><span>{L(...boxName[key])}</span><Badge variant="outline">{people.length}</Badge></CardTitle></CardHeader>
                    <CardContent className="p-3 pt-1 flex flex-wrap gap-1">
                      {people.map((r) => (
                        <button key={r.id} onClick={() => navigate(`/employees/${r.id}?tab=performance`)} className="text-xs rounded-md border px-2 py-1 hover:bg-accent text-left" title={`${r.position || ""} · ${r.perf}/${r.pot}`}>
                          {r.full_name}
                        </button>
                      ))}
                    </CardContent>
                  </Card>
                );
              }))}
            </div>
          </div>
          <p className="text-xs text-muted-foreground text-center">{L("შედეგები →", "Performance →")}{unplaced > 0 && ` · ${L(`${unplaced} თანამშრომელს ჯერ არ აქვს საკმარისი მონაცემი`, `${unplaced} people don't have enough data yet`)}`}</p>

          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">{L("გადასაყვანად შესაფერისი", "Good candidates for a move")}</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {mobility.length === 0 ? (
                <p className="text-sm text-muted-foreground">{L("ჯერ არავინ. გახსენით თანამშრომლის „პერფორმანსი“ ჩანართი და გაუშვით AI ანალიზი.", "Nobody yet. Open an employee's Performance tab and run the AI analysis.")}</p>
              ) : mobility.map((m) => (
                <button key={m.employee_id} onClick={() => navigate(`/employees/${m.employee_id}?tab=performance`)} className="w-full flex justify-between items-center gap-2 border rounded-lg p-3 hover:bg-accent text-left">
                  <span><span className="font-medium">{m.full_name}</span> <span className="text-muted-foreground text-sm">→ {m.role}</span></span>
                  <span className="text-sm">{m.current_fit ?? "—"}% → <Badge>{m.fit}%</Badge></span>
                </button>
              ))}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
