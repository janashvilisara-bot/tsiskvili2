import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import { UserPlus, Trash2, Search, Shield, Users, Crown } from 'lucide-react';
import { Navigate } from 'react-router-dom';
import { logRoleChange } from '@/lib/securityLogger';

interface UserWithRoles {
  id: string;
  email: string;
  full_name: string;
  roles: string[];
  customRoles: Array<{ id: string; name: string }>;
}

interface CustomRole {
  id: string;
  name: string;
}

type AppRole = 'admin' | 'hr_manager' | 'department_manager' | 'employee';

export default function RoleManagement() {
  const { userRole, user } = useAuth();
  const [users, setUsers] = useState<UserWithRoles[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<UserWithRoles[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRole, setSelectedRole] = useState<AppRole | 'all'>('all');
  const [loading, setLoading] = useState(true);
  const [managedDepartmentName, setManagedDepartmentName] = useState<string | null>(null);
  const [customRoles, setCustomRoles] = useState<CustomRole[]>([]);

  // Only admins and department managers can access this page
  if (userRole !== 'admin' && userRole !== 'department_manager') {
    return <Navigate to="/" replace />;
  }

  useEffect(() => {
    fetchUsers();
    fetchCustomRoles();
  }, []);

  useEffect(() => {
    filterUsers();
  }, [searchQuery, selectedRole, users]);

  const fetchCustomRoles = async () => {
    try {
      const { data, error } = await supabase
        .from('custom_roles')
        .select('id, name')
        .order('name');

      if (error) throw error;
      setCustomRoles(data || []);
    } catch (error: any) {
      console.error('Error fetching custom roles:', error);
    }
  };

  const fetchUsers = async () => {
    try {
      setLoading(true);

      // Get employees with their user_ids and departments
      const { data: employees, error: employeesError } = await supabase
        .from('employees')
        .select('id, user_id, department, full_name');

      if (employeesError) throw employeesError;

      // Get current user's managed department if department manager
      let departmentName: string | null = null;
      if (userRole === 'department_manager' && user) {
        const { data: employee, error: empError } = await supabase
          .from('employees')
          .select('id')
          .eq('user_id', user.id)
          .single();

        if (!empError && employee) {
          const { data: department, error: deptError } = await supabase
            .from('departments')
            .select('name')
            .eq('manager_id', employee.id)
            .single();

          if (!deptError && department) {
            departmentName = department.name;
            setManagedDepartmentName(department.name);
          }
        }
      }

      // Filter employees by department if department manager
      let filteredEmployees = employees || [];
      if (userRole === 'department_manager' && departmentName) {
        filteredEmployees = filteredEmployees.filter(emp => emp.department === departmentName);
      }

      // Get all user roles
      const { data: userRoles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role');

      if (rolesError) throw rolesError;

      // Get emails from auth.users using database function
      const usersWithRoles: UserWithRoles[] = [];
      
      for (const employee of filteredEmployees) {
        if (!employee.user_id) continue;

        // Get user email using the database function
        const { data: userEmail, error: emailError } = await supabase
          .rpc('get_user_email_by_id', { target_user_id: employee.user_id });
        
        if (!emailError && userEmail) {
          const roles = (userRoles || [])
            .filter(ur => ur.user_id === employee.user_id)
            .map(ur => ur.role);

          // Get user's custom roles
          const { data: userCustomRoles } = await supabase
            .from('user_custom_roles')
            .select(`
              role_id,
              custom_roles (
                id,
                name
              )
            `)
            .eq('user_id', employee.user_id);

          const customRolesList = (userCustomRoles || [])
            .map(ucr => ({
              id: (ucr as any).custom_roles?.id || '',
              name: (ucr as any).custom_roles?.name || ''
            }))
            .filter(r => r.id && r.name);

          usersWithRoles.push({
            id: employee.user_id,
            email: userEmail,
            full_name: employee.full_name || userEmail || 'უცნობი',
            roles: roles,
            customRoles: customRolesList
          });
        }
      }

      setUsers(usersWithRoles);
    } catch (error: any) {
      console.error('Error fetching users:', error);
      toast.error('მომხმარებლების ჩატვირთვა ვერ მოხერხდა');
    } finally {
      setLoading(false);
    }
  };

  const filterUsers = () => {
    let filtered = [...users];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        user =>
          user.full_name.toLowerCase().includes(query) ||
          user.email.toLowerCase().includes(query)
      );
    }

    // Role filter
    if (selectedRole !== 'all') {
      filtered = filtered.filter(user => user.roles.includes(selectedRole));
    }

    setFilteredUsers(filtered);
  };

  const handleAddRole = async (userId: string, role: AppRole) => {
    // Department managers can only assign employee role
    if (userRole === 'department_manager' && role !== 'employee') {
      toast.error('დეპარტამენტის მენეჯერს შეუძლია მხოლოდ თანამშრომლის როლის მინიჭება');
      return;
    }

    try {
      const { error } = await supabase
        .from('user_roles')
        .insert([{ user_id: userId, role }]);

      if (error) {
        if (error.code === '23505') {
          toast.error('ეს როლი უკვე მინიჭებული აქვს მომხმარებელს');
        } else {
          throw error;
        }
        return;
      }

      // Log role change
      const foundUser = users.find(u => u.id === userId);
      await logRoleChange(userId, 'none', role);

      toast.success('როლი წარმატებით დაემატა');
      fetchUsers();
    } catch (error: any) {
      console.error('Error adding role:', error);
      toast.error('როლის დამატება ვერ მოხერხდა');
    }
  };

  const handleAddCustomRole = async (userId: string, roleId: string) => {
    try {
      const { error } = await supabase
        .from('user_custom_roles')
        .insert([{ user_id: userId, role_id: roleId }]);

      if (error) {
        if (error.code === '23505') {
          toast.error('ეს custom როლი უკვე მინიჭებული აქვს მომხმარებელს');
        } else {
          throw error;
        }
        return;
      }

      toast.success('Custom როლი წარმატებით დაემატა');
      fetchUsers();
    } catch (error: any) {
      console.error('Error adding custom role:', error);
      toast.error('Custom როლის დამატება ვერ მოხერხდა');
    }
  };

  const handleRemoveCustomRole = async (userId: string, roleId: string) => {
    try {
      const { error } = await supabase
        .from('user_custom_roles')
        .delete()
        .eq('user_id', userId)
        .eq('role_id', roleId);

      if (error) throw error;

      toast.success('Custom როლი წარმატებით წაიშალა');
      fetchUsers();
    } catch (error: any) {
      console.error('Error removing custom role:', error);
      toast.error('Custom როლის წაშლა ვერ მოხერხდა');
    }
  };

  const handleRemoveRole = async (userId: string, role: AppRole) => {
    // Department managers can only remove employee role
    if (userRole === 'department_manager' && role !== 'employee') {
      toast.error('დეპარტამენტის მენეჯერს შეუძლია მხოლოდ თანამშრომლის როლის წაშლა');
      return;
    }

    // Admin cannot remove another admin's role - only super admin can do this via database
    if (userRole === 'admin' && role === 'admin' && userId !== user?.id) {
      toast.error('ადმინისტრატორის როლის წაშლა შესაძლებელია მხოლოდ ბაზიდან პირდაპირ');
      return;
    }

    // Prevent self-demotion from admin
    if (role === 'admin' && userId === user?.id) {
      toast.error('თქვენ ვერ წაშლით საკუთარ ადმინისტრატორის როლს');
      return;
    }

    // Prevent removing the last employee role
    const foundUser = users.find(u => u.id === userId);
    if (foundUser && foundUser.roles.length === 1 && role === 'employee') {
      toast.error('ყველა მომხმარებელს უნდა ჰქონდეს მინიმუმ თანამშრომლის როლი');
      return;
    }

    try {
      const { error } = await supabase
        .from('user_roles')
        .delete()
        .eq('user_id', userId)
        .eq('role', role);

      if (error) throw error;

      // Log role removal
      await logRoleChange(userId, role, 'none');

      toast.success('როლი წარმატებით წაიშალა');
      fetchUsers();
    } catch (error: any) {
      console.error('Error removing role:', error);
      toast.error('როლის წაშლა ვერ მოხერხდა');
    }
  };

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case 'admin':
        return 'destructive';
      case 'hr_manager':
        return 'default';
      case 'department_manager':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin':
        return <Crown className="h-3 w-3" />;
      case 'hr_manager':
        return <Shield className="h-3 w-3" />;
      case 'department_manager':
        return <Users className="h-3 w-3" />;
      default:
        return null;
    }
  };

  const getRoleText = (role: string) => {
    switch (role) {
      case 'admin':
        return 'ადმინისტრატორი';
      case 'hr_manager':
        return 'HR მენეჯერი';
      case 'department_manager':
        return 'დეპარტამენტის მენეჯერი';
      case 'employee':
        return 'თანამშრომელი';
      default:
        return role;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">იტვირთება...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">როლების მართვა</h1>
        <p className="text-muted-foreground">
          მართეთ მომხმარებლების როლები და უფლებები
        </p>
        {userRole === 'department_manager' && managedDepartmentName && (
          <div className="mt-2 inline-flex items-center gap-2 px-3 py-1 rounded-md bg-primary/10 text-primary">
            <Users className="h-4 w-4" />
            <span className="text-sm font-medium">თქვენი დეპარტამენტი: {managedDepartmentName}</span>
          </div>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>ფილტრები</CardTitle>
          <CardDescription>მოძებნეთ და გაფილტრეთ მომხმარებლები</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="ძიება სახელით ან ელ.ფოსტით..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={selectedRole} onValueChange={(value) => setSelectedRole(value as AppRole | 'all')}>
              <SelectTrigger>
                <SelectValue placeholder="როლის არჩევა" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ყველა როლი</SelectItem>
                <SelectItem value="admin">ადმინისტრატორი</SelectItem>
                <SelectItem value="hr_manager">HR მენეჯერი</SelectItem>
                <SelectItem value="department_manager">დეპარტამენტის მენეჯერი</SelectItem>
                <SelectItem value="employee">თანამშრომელი</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="text-sm text-muted-foreground">
            ნაპოვნია: {filteredUsers.length} მომხმარებელი
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>მომხმარებლები</CardTitle>
          <CardDescription>მართეთ მომხმარებლების როლები</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>სახელი</TableHead>
                  <TableHead>ელ.ფოსტა</TableHead>
                  <TableHead>როლები</TableHead>
                  <TableHead className="text-right">მოქმედებები</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                      მომხმარებლები არ მოიძებნა
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.full_name}</TableCell>
                      <TableCell className="text-muted-foreground">{user.email}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-2">
                          {user.roles.map((role) => (
                            <Badge
                              key={role}
                              variant={getRoleBadgeVariant(role)}
                              className="flex items-center gap-1"
                            >
                              {getRoleIcon(role)}
                              {getRoleText(role)}
                              {userRole === 'admin' && (
                                <button
                                  onClick={() => handleRemoveRole(user.id, role as AppRole)}
                                  className="ml-1 hover:text-destructive"
                                >
                                  ×
                                </button>
                              )}
                            </Badge>
                          ))}
                          {user.customRoles?.map((customRole) => (
                            <Badge
                              key={customRole.id}
                              variant="outline"
                              className="flex items-center gap-1 border-purple-500 text-purple-700 dark:text-purple-300"
                            >
                              <Shield className="h-3 w-3" />
                              {customRole.name}
                              {userRole === 'admin' && (
                                <button
                                  onClick={() => handleRemoveCustomRole(user.id, customRole.id)}
                                  className="ml-1 hover:text-destructive"
                                >
                                  ×
                                </button>
                              )}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-2">
                          {userRole === 'admin' && (
                            <>
                              <Select onValueChange={(role) => handleAddRole(user.id, role as AppRole)}>
                                <SelectTrigger className="w-[180px]">
                                  <SelectValue placeholder="სისტემური როლი" />
                                </SelectTrigger>
                                <SelectContent>
                                  {!user.roles.includes('admin') && (
                                    <SelectItem value="admin">ადმინისტრატორი</SelectItem>
                                  )}
                                  {!user.roles.includes('hr_manager') && (
                                    <SelectItem value="hr_manager">HR მენეჯერი</SelectItem>
                                  )}
                                  {!user.roles.includes('department_manager') && (
                                    <SelectItem value="department_manager">დეპარტამენტის მენეჯერი</SelectItem>
                                  )}
                                </SelectContent>
                              </Select>
                              
                              {customRoles.length > 0 && (
                                <Select onValueChange={(value) => handleAddCustomRole(user.id, value)}>
                                  <SelectTrigger className="w-[180px]">
                                    <SelectValue placeholder="Custom როლი" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {customRoles
                                      .filter(cr => !user.customRoles?.some(ucr => ucr.id === cr.id))
                                      .map((customRole) => (
                                        <SelectItem key={customRole.id} value={customRole.id}>
                                          {customRole.name}
                                        </SelectItem>
                                      ))}
                                  </SelectContent>
                                </Select>
                              )}
                            </>
                          )}
                          {userRole === 'department_manager' && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleRemoveRole(user.id, 'employee')}
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              წაშლა
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
