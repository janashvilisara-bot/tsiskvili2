import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { FileSignature, Shield, CheckCircle, AlertCircle, Loader2, Eye, EyeOff, ExternalLink, Settings, Webhook, Copy, Check, Link2, Unlink, User } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { initiateSignifyOAuth } from '@/lib/signifyPKCE';

export default function SignifyIntegration() {
  const { user, userRole } = useAuth();
  const [clientId, setClientId] = useState('');
  const [clientSecret, setClientSecret] = useState('');
  const [webhookSecurityKey, setWebhookSecurityKey] = useState('');
  const [isActive, setIsActive] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'unknown' | 'connected' | 'error'>('unknown');
  const [showSecret, setShowSecret] = useState(false);
  const [showWebhookKey, setShowWebhookKey] = useState(false);
  const [existingId, setExistingId] = useState<string | null>(null);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [signifyLink, setSignifyLink] = useState<{ linked: boolean; email?: string; name?: string } | null>(null);
  const [isLinking, setIsLinking] = useState(false);
  const [isUnlinking, setIsUnlinking] = useState(false);
  const isAdmin = userRole === 'admin';

  useEffect(() => {
    fetchSettings();
    fetchSignifyLinkStatus();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('integration_settings')
        .select('*')
        .eq('provider', 'signify')
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setExistingId(data.id);
        setClientId(data.client_id || '');
        setClientSecret(data.client_secret || '');
        setIsActive(data.is_active);
        const settings = data.settings as Record<string, unknown> | null;
        setWebhookSecurityKey((settings?.webhook_security_key as string) || '');
      }
    } catch (error: any) {
      console.error('Error fetching signify settings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchSignifyLinkStatus = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('signify-oauth', {
        body: { action: 'status' },
      });
      if (!error && data) {
        setSignifyLink({ linked: data.linked, email: data.signify_email, name: data.signify_name });
      }
    } catch (e) {
      console.error('Failed to check signify link status:', e);
    }
  };

  const handleLinkSignify = async () => {
    setIsLinking(true);
    try {
      await initiateSignifyOAuth();
    } catch (e) {
      toast.error('OAuth ინიცირება ვერ მოხერხდა');
      setIsLinking(false);
    }
  };

  const handleUnlinkSignify = async () => {
    setIsUnlinking(true);
    try {
      const { data, error } = await supabase.functions.invoke('signify-oauth', {
        body: { action: 'unlink' },
      });
      if (error) throw error;
      setSignifyLink({ linked: false });
      toast.success('Signify ექაუნთი გათიშულია');
    } catch (e) {
      toast.error('გათიშვა ვერ მოხერხდა');
    } finally {
      setIsUnlinking(false);
    }
  };

  const handleSave = async () => {
    if (!clientId.trim() || !clientSecret.trim()) {
      toast.error('გთხოვთ შეავსოთ Client ID და Client Secret');
      return;
    }

    setIsSaving(true);
    try {
      if (existingId) {
        const { error } = await supabase
          .from('integration_settings')
          .update({
            client_id: clientId.trim(),
            client_secret: clientSecret.trim(),
            is_active: isActive,
            settings: { webhook_security_key: webhookSecurityKey.trim() || null },
            updated_by: user?.id,
            updated_at: new Date().toISOString(),
          })
          .eq('id', existingId);

        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('integration_settings')
          .insert({
            provider: 'signify',
            client_id: clientId.trim(),
            client_secret: clientSecret.trim(),
            is_active: isActive,
            settings: { webhook_security_key: webhookSecurityKey.trim() || null },
            created_by: user?.id,
            updated_by: user?.id,
          })
          .select()
          .single();

        if (error) throw error;
        setExistingId(data.id);
      }

      toast.success('Signify კონფიგურაცია შენახულია');
    } catch (error: any) {
      console.error('Error saving signify settings:', error);
      toast.error('შენახვა ვერ მოხერხდა');
    } finally {
      setIsSaving(false);
    }
  };

  const handleTestConnection = async () => {
    if (!clientId.trim() || !clientSecret.trim()) {
      toast.error('ჯერ შეავსეთ Client ID და Client Secret');
      return;
    }

    setIsTesting(true);
    setConnectionStatus('unknown');
    try {
      const { data, error } = await supabase.functions.invoke('signify-sign', {
        body: { action: 'check-status' },
      });

      if (error) throw error;

      if (data?.connected) {
        setConnectionStatus('connected');
        toast.success('Signify API კავშირი წარმატებულია!');
      } else {
        setConnectionStatus('error');
        toast.error(data?.error || 'კავშირი ვერ მოხერხდა');
      }
    } catch (error: any) {
      setConnectionStatus('error');
      toast.error('კავშირის ტესტი ვერ მოხერხდა');
    } finally {
      setIsTesting(false);
    }
  };

  const handleToggleActive = async (active: boolean) => {
    setIsActive(active);

    if (existingId) {
      try {
        await supabase
          .from('integration_settings')
          .update({ is_active: active, updated_by: user?.id, updated_at: new Date().toISOString() })
          .eq('id', existingId);

        toast.success(active ? 'Signify გააქტიურებულია' : 'Signify გათიშულია');
      } catch {
        toast.error('სტატუსის ცვლილება ვერ მოხერხდა');
        setIsActive(!active);
      }
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center">
              <FileSignature className="h-5 w-5 text-white" />
            </div>
            Signify - ელექტრონული ხელმოწერა
          </h1>
          <p className="mt-2 text-muted-foreground">
            გააქტიურეთ Signify.ge ელექტრონული ხელმოწერის სერვისი თქვენი ორგანიზაციისთვის
          </p>
        </div>
        <a href="https://signify.ge" target="_blank" rel="noopener noreferrer">
          <Button variant="outline" className="gap-2">
            <ExternalLink className="h-4 w-4" />
            signify.ge
          </Button>
        </a>
      </div>

      {/* Status card */}
      <Card>
        <CardContent className="flex items-center justify-between p-6">
          <div className="flex items-center gap-4">
            <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${isActive ? 'bg-green-100 dark:bg-green-900/30' : 'bg-muted'}`}>
              {isActive ? (
                <CheckCircle className="h-6 w-6 text-green-600 dark:text-green-400" />
              ) : (
                <AlertCircle className="h-6 w-6 text-muted-foreground" />
              )}
            </div>
            <div>
              <p className="font-semibold text-lg">
                {isActive ? 'Signify აქტიურია' : 'Signify გათიშულია'}
              </p>
              <p className="text-sm text-muted-foreground">
                {isActive 
                  ? 'ელექტრონული ხელმოწერა ხელმისაწვდომია დოკუმენტების მოდულში' 
                  : 'გააქტიურეთ ელექტრონული ხელმოწერის ფუნქცია'}
              </p>
            </div>
          </div>
          <Switch
            checked={isActive}
            onCheckedChange={handleToggleActive}
            disabled={!isAdmin || (!existingId && !clientId)}
          />
        </CardContent>
      </Card>

      {/* User OAuth Linking */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            თქვენი Signify ექაუნთის დაკავშირება
          </CardTitle>
          <CardDescription>
            დააკავშირეთ თქვენი Signify ექაუნთი Talentos-ს ანგარიშთან, რომ დოკუმენტები თქვენი სახელით გაიგზავნოს ხელმოსაწერად.
            საჭიროა Signify Business Pro ან Enterprise სატარიფო გეგმა.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {signifyLink === null ? (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>მოწმდება...</span>
            </div>
          ) : signifyLink.linked ? (
            <div className="space-y-4">
              <div className="flex items-center gap-4 rounded-lg border border-border/60 bg-muted/30 p-4">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Link2 className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{signifyLink.name || 'Signify მომხმარებელი'}</p>
                  <p className="text-sm text-muted-foreground">{signifyLink.email || 'ელ-ფოსტა არ არის ხელმისაწვდომი'}</p>
                </div>
                <Badge className="bg-primary/10 text-primary border-primary/20">
                  <CheckCircle className="h-3 w-3 mr-1" /> დაკავშირებულია
                </Badge>
              </div>
              <Button
                variant="outline"
                onClick={handleUnlinkSignify}
                disabled={isUnlinking}
                className="gap-2 text-destructive hover:text-destructive"
              >
                {isUnlinking ? <Loader2 className="h-4 w-4 animate-spin" /> : <Unlink className="h-4 w-4" />}
                Signify ექაუნთის გათიშვა
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                ღილაკზე დაჭერისას გადამისამართდებით Signify-ს გვერდზე, სადაც მოგეთხოვებათ წვდომის ნებართვა.
              </p>
              <Button
                onClick={handleLinkSignify}
                disabled={isLinking}
                className="gap-2"
              >
                {isLinking ? <Loader2 className="h-4 w-4 animate-spin" /> : <Link2 className="h-4 w-4" />}
                Signify ექაუნთის დაკავშირება
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Credentials */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            API კონფიგურაცია
          </CardTitle>
          <CardDescription>
            შეიყვანეთ Signify Enterprise ანგარიშის API credentials. 
            მათ შეგიძლიათ იპოვოთ Signify პორტალში → API Credentials სექციაში.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="client-id">Client ID</Label>
            <Input
              id="client-id"
              value={clientId}
              onChange={(e) => setClientId(e.target.value)}
              placeholder="შეიყვანეთ Signify Client ID"
              disabled={!isAdmin}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="client-secret">Client Secret</Label>
            <div className="relative">
              <Input
                id="client-secret"
                type={showSecret ? 'text' : 'password'}
                value={clientSecret}
                onChange={(e) => setClientSecret(e.target.value)}
                placeholder="შეიყვანეთ Signify Client Secret"
                disabled={!isAdmin}
                className="pr-10"
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
                onClick={() => setShowSecret(!showSecret)}
              >
                {showSecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <Separator />

          <div className="flex items-center gap-3">
            <Button onClick={handleSave} disabled={isSaving || !isAdmin} className="gap-2">
              {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Shield className="h-4 w-4" />}
              {isSaving ? 'ინახება...' : 'შენახვა'}
            </Button>

            <Button variant="outline" onClick={handleTestConnection} disabled={isTesting || !clientId || !clientSecret} className="gap-2">
              {isTesting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
              {isTesting ? 'მოწმდება...' : 'კავშირის ტესტი'}
            </Button>

            {connectionStatus === 'connected' && (
              <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 border-green-200">
                <CheckCircle className="h-3 w-3 mr-1" /> დაკავშირებულია
              </Badge>
            )}
            {connectionStatus === 'error' && (
              <Badge variant="destructive">
                <AlertCircle className="h-3 w-3 mr-1" /> კავშირი ვერ მოხერხდა
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Webhook Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Webhook className="h-5 w-5" />
            Webhook კონფიგურაცია
          </CardTitle>
          <CardDescription>
            Signify პორტალში ჩაწერეთ ქვემოთ მოცემული URL და Security Key, რომ დოკუმენტის ხელმოწერის შემდეგ სისტემამ ავტომატურად მიიღოს შეტყობინება.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Webhook URL</Label>
            <div className="flex flex-wrap gap-2">
              <Input
                readOnly
                value={`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/signify-webhook`}
                className="font-mono text-xs bg-muted"
              />
              <Button
                variant="outline"
                size="icon"
                className="shrink-0"
                onClick={() => {
                  navigator.clipboard.writeText(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/signify-webhook`);
                  setCopiedUrl(true);
                  setTimeout(() => setCopiedUrl(false), 2000);
                  toast.success('URL დაკოპირდა');
                }}
              >
                {copiedUrl ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="webhook-key">Webhook Security Key</Label>
            <p className="text-xs text-muted-foreground">Signify-ში დააგენერირეთ Security Key და ჩაწერეთ აქაც - სისტემა შეამოწმებს ყოველ webhook მოთხოვნას.</p>
            <div className="relative">
              <Input
                id="webhook-key"
                type={showWebhookKey ? 'text' : 'password'}
                value={webhookSecurityKey}
                onChange={(e) => setWebhookSecurityKey(e.target.value)}
                placeholder="Signify-ს Webhook Security Key"
                disabled={!isAdmin}
                className="pr-10"
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
                onClick={() => setShowWebhookKey(!showWebhookKey)}
              >
                {showWebhookKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="rounded-lg border border-border/60 bg-muted/30 p-4 text-sm text-muted-foreground space-y-2">
            <p className="font-medium text-foreground">Signify პორტალში შეავსეთ:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Webhook scope</strong> → API დოკუმენტებისთვის</li>
              <li><strong>Webhook type</strong> → დოკუმენტის დასრულებისას</li>
              <li><strong>Webhook URL</strong> → ზემოთ მოცემული URL</li>
              <li><strong>Webhook Security Key</strong> → ზემოთ შეყვანილი გასაღები</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Info card */}
      <Card className="border-blue-200 dark:border-blue-800 bg-blue-50/50 dark:bg-blue-950/20">
        <CardContent className="p-6">
          <h3 className="font-semibold text-lg mb-3">როგორ მუშაობს?</h3>
          <div className="space-y-3 text-sm text-muted-foreground">
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-0.5 shrink-0">1</Badge>
              <p>შექმენით Enterprise ანგარიში <a href="https://signify.ge" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">signify.ge</a>-ზე</p>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-0.5 shrink-0">2</Badge>
              <p>Signify პორტალში გადადით API Credentials სექციაში და დააგენერირეთ Client ID და Client Secret</p>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-0.5 shrink-0">3</Badge>
              <p>შეიყვანეთ credentials ზემოთ და გააქტიურეთ სერვისი</p>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="outline" className="mt-0.5 shrink-0">4</Badge>
              <p>დოკუმენტების მოდულში გამოჩნდება ელექტრონული ხელმოწერის ღილაკი - დოკუმენტები გაიგზავნება Signify-ზე ხელმოსაწერად</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
