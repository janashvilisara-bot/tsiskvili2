export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      account_lockouts: {
        Row: {
          created_at: string
          email: string
          failed_attempts: number
          id: string
          locked_at: string
          locked_until: string
          unlock_token: string | null
        }
        Insert: {
          created_at?: string
          email: string
          failed_attempts: number
          id?: string
          locked_at?: string
          locked_until: string
          unlock_token?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          failed_attempts?: number
          id?: string
          locked_at?: string
          locked_until?: string
          unlock_token?: string | null
        }
        Relationships: []
      }
      advertisements: {
        Row: {
          ad_type: string
          click_count: number | null
          created_at: string
          created_by: string | null
          description: string | null
          end_date: string | null
          id: string
          image_url: string | null
          is_active: boolean | null
          link_url: string | null
          placement: string
          priority: number | null
          start_date: string | null
          target_roles: string[] | null
          title: string
          updated_at: string
          view_count: number | null
        }
        Insert: {
          ad_type?: string
          click_count?: number | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          link_url?: string | null
          placement?: string
          priority?: number | null
          start_date?: string | null
          target_roles?: string[] | null
          title: string
          updated_at?: string
          view_count?: number | null
        }
        Update: {
          ad_type?: string
          click_count?: number | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          link_url?: string | null
          placement?: string
          priority?: number | null
          start_date?: string | null
          target_roles?: string[] | null
          title?: string
          updated_at?: string
          view_count?: number | null
        }
        Relationships: []
      }
      ai_document_templates: {
        Row: {
          category: string
          code: string
          created_at: string
          description_en: string | null
          description_ka: string | null
          icon: string | null
          id: string
          is_active: boolean
          name_en: string
          name_ka: string
          questions_schema: Json
          sort_order: number
          system_prompt: string
          updated_at: string
        }
        Insert: {
          category?: string
          code: string
          created_at?: string
          description_en?: string | null
          description_ka?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name_en: string
          name_ka: string
          questions_schema?: Json
          sort_order?: number
          system_prompt: string
          updated_at?: string
        }
        Update: {
          category?: string
          code?: string
          created_at?: string
          description_en?: string | null
          description_ka?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name_en?: string
          name_ka?: string
          questions_schema?: Json
          sort_order?: number
          system_prompt?: string
          updated_at?: string
        }
        Relationships: []
      }
      ai_generated_documents: {
        Row: {
          answers: Json
          content: string
          created_at: string
          created_by: string
          employee_id: string | null
          id: string
          status: string
          template_code: string
          template_id: string | null
          title: string
          updated_at: string
          updated_by: string | null
          version: number
        }
        Insert: {
          answers?: Json
          content: string
          created_at?: string
          created_by: string
          employee_id?: string | null
          id?: string
          status?: string
          template_code: string
          template_id?: string | null
          title: string
          updated_at?: string
          updated_by?: string | null
          version?: number
        }
        Update: {
          answers?: Json
          content?: string
          created_at?: string
          created_by?: string
          employee_id?: string | null
          id?: string
          status?: string
          template_code?: string
          template_id?: string | null
          title?: string
          updated_at?: string
          updated_by?: string | null
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "ai_generated_documents_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "ai_document_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_response_cache: {
        Row: {
          cache_key: string
          created_at: string
          expires_at: string
          function_name: string
          hit_count: number
          id: string
          last_accessed_at: string
          model: string | null
          prompt_hash: string
          response: Json
        }
        Insert: {
          cache_key: string
          created_at?: string
          expires_at?: string
          function_name: string
          hit_count?: number
          id?: string
          last_accessed_at?: string
          model?: string | null
          prompt_hash: string
          response: Json
        }
        Update: {
          cache_key?: string
          created_at?: string
          expires_at?: string
          function_name?: string
          hit_count?: number
          id?: string
          last_accessed_at?: string
          model?: string | null
          prompt_hash?: string
          response?: Json
        }
        Relationships: []
      }
      announcements: {
        Row: {
          announcement_type: string
          branch_id: string | null
          content: string
          created_at: string | null
          created_by: string | null
          id: string
          is_pinned: boolean | null
          priority: string | null
          published: boolean | null
          target_audience: string | null
          title: string
          updated_at: string | null
        }
        Insert: {
          announcement_type: string
          branch_id?: string | null
          content: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_pinned?: boolean | null
          priority?: string | null
          published?: boolean | null
          target_audience?: string | null
          title: string
          updated_at?: string | null
        }
        Update: {
          announcement_type?: string
          branch_id?: string | null
          content?: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_pinned?: boolean | null
          priority?: string | null
          published?: boolean | null
          target_audience?: string | null
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "announcements_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      app_user_connections: {
        Row: {
          connection_key_ciphertext: string
          connector_id: string
          created_at: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          connection_key_ciphertext: string
          connector_id: string
          created_at?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          connection_key_ciphertext?: string
          connector_id?: string
          created_at?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      approval_chain_steps: {
        Row: {
          approver_role: string | null
          approver_type: string
          approver_user_id: string | null
          chain_id: string
          created_at: string
          id: string
          max_amount: number | null
          min_amount: number | null
          step_order: number
        }
        Insert: {
          approver_role?: string | null
          approver_type: string
          approver_user_id?: string | null
          chain_id: string
          created_at?: string
          id?: string
          max_amount?: number | null
          min_amount?: number | null
          step_order: number
        }
        Update: {
          approver_role?: string | null
          approver_type?: string
          approver_user_id?: string | null
          chain_id?: string
          created_at?: string
          id?: string
          max_amount?: number | null
          min_amount?: number | null
          step_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "approval_chain_steps_chain_id_fkey"
            columns: ["chain_id"]
            isOneToOne: false
            referencedRelation: "approval_chains"
            referencedColumns: ["id"]
          },
        ]
      }
      approval_chains: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          module: string
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          module: string
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          module?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      approval_requests: {
        Row: {
          amount: number | null
          chain_id: string
          created_at: string
          current_step: number
          id: string
          module: string
          payload: Json
          reference_id: string | null
          reference_table: string | null
          requested_by: string
          status: string
          updated_at: string
        }
        Insert: {
          amount?: number | null
          chain_id: string
          created_at?: string
          current_step?: number
          id?: string
          module: string
          payload?: Json
          reference_id?: string | null
          reference_table?: string | null
          requested_by: string
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number | null
          chain_id?: string
          created_at?: string
          current_step?: number
          id?: string
          module?: string
          payload?: Json
          reference_id?: string | null
          reference_table?: string | null
          requested_by?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "approval_requests_chain_id_fkey"
            columns: ["chain_id"]
            isOneToOne: false
            referencedRelation: "approval_chains"
            referencedColumns: ["id"]
          },
        ]
      }
      approval_step_decisions: {
        Row: {
          approver_id: string
          comment: string | null
          decided_at: string
          decision: string
          id: string
          request_id: string
          step_order: number
        }
        Insert: {
          approver_id: string
          comment?: string | null
          decided_at?: string
          decision: string
          id?: string
          request_id: string
          step_order: number
        }
        Update: {
          approver_id?: string
          comment?: string | null
          decided_at?: string
          decision?: string
          id?: string
          request_id?: string
          step_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "approval_step_decisions_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "approval_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      assets: {
        Row: {
          asset_name: string
          asset_type: string
          assigned_to: string | null
          branch_id: string
          created_at: string | null
          created_by: string | null
          id: string
          location: string | null
          notes: string | null
          purchase_date: string | null
          purchase_price: number | null
          serial_number: string | null
          status: string
          updated_at: string | null
        }
        Insert: {
          asset_name: string
          asset_type: string
          assigned_to?: string | null
          branch_id?: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          location?: string | null
          notes?: string | null
          purchase_date?: string | null
          purchase_price?: number | null
          serial_number?: string | null
          status?: string
          updated_at?: string | null
        }
        Update: {
          asset_name?: string
          asset_type?: string
          assigned_to?: string | null
          branch_id?: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          location?: string | null
          notes?: string | null
          purchase_date?: string | null
          purchase_price?: number | null
          serial_number?: string | null
          status?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "assets_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance: {
        Row: {
          branch_id: string
          break_duration: number | null
          break_end: string | null
          break_start: string | null
          check_in: string | null
          check_in_location: string | null
          check_in_method: string | null
          check_out: string | null
          check_out_location: string | null
          check_out_method: string | null
          created_at: string
          created_by: string | null
          date: string
          deleted_at: string | null
          device_id: string | null
          employee_id: string
          id: string
          is_suspicious_location: boolean | null
          justification_note: string | null
          justified_at: string | null
          justified_by: string | null
          lateness_comment: string | null
          lateness_justified: boolean | null
          notes: string | null
          overtime_hours: number | null
          status: string
          updated_at: string
        }
        Insert: {
          branch_id?: string
          break_duration?: number | null
          break_end?: string | null
          break_start?: string | null
          check_in?: string | null
          check_in_location?: string | null
          check_in_method?: string | null
          check_out?: string | null
          check_out_location?: string | null
          check_out_method?: string | null
          created_at?: string
          created_by?: string | null
          date: string
          deleted_at?: string | null
          device_id?: string | null
          employee_id: string
          id?: string
          is_suspicious_location?: boolean | null
          justification_note?: string | null
          justified_at?: string | null
          justified_by?: string | null
          lateness_comment?: string | null
          lateness_justified?: boolean | null
          notes?: string | null
          overtime_hours?: number | null
          status?: string
          updated_at?: string
        }
        Update: {
          branch_id?: string
          break_duration?: number | null
          break_end?: string | null
          break_start?: string | null
          check_in?: string | null
          check_in_location?: string | null
          check_in_method?: string | null
          check_out?: string | null
          check_out_location?: string | null
          check_out_method?: string | null
          created_at?: string
          created_by?: string | null
          date?: string
          deleted_at?: string | null
          device_id?: string | null
          employee_id?: string
          id?: string
          is_suspicious_location?: boolean | null
          justification_note?: string | null
          justified_at?: string | null
          justified_by?: string | null
          lateness_comment?: string | null
          lateness_justified?: boolean | null
          notes?: string | null
          overtime_hours?: number | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "attendance_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "attendance_devices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance_archive: {
        Row: {
          archived_at: string
          break_duration: number | null
          break_end: string | null
          break_start: string | null
          check_in: string | null
          check_in_location: string | null
          check_in_method: string | null
          check_out: string | null
          check_out_location: string | null
          check_out_method: string | null
          created_at: string
          created_by: string | null
          date: string
          deleted_at: string | null
          device_id: string | null
          employee_id: string
          id: string
          is_suspicious_location: boolean | null
          justification_note: string | null
          justified_at: string | null
          justified_by: string | null
          lateness_comment: string | null
          lateness_justified: boolean | null
          notes: string | null
          overtime_hours: number | null
          status: string
          updated_at: string
        }
        Insert: {
          archived_at?: string
          break_duration?: number | null
          break_end?: string | null
          break_start?: string | null
          check_in?: string | null
          check_in_location?: string | null
          check_in_method?: string | null
          check_out?: string | null
          check_out_location?: string | null
          check_out_method?: string | null
          created_at?: string
          created_by?: string | null
          date: string
          deleted_at?: string | null
          device_id?: string | null
          employee_id: string
          id?: string
          is_suspicious_location?: boolean | null
          justification_note?: string | null
          justified_at?: string | null
          justified_by?: string | null
          lateness_comment?: string | null
          lateness_justified?: boolean | null
          notes?: string | null
          overtime_hours?: number | null
          status?: string
          updated_at?: string
        }
        Update: {
          archived_at?: string
          break_duration?: number | null
          break_end?: string | null
          break_start?: string | null
          check_in?: string | null
          check_in_location?: string | null
          check_in_method?: string | null
          check_out?: string | null
          check_out_location?: string | null
          check_out_method?: string | null
          created_at?: string
          created_by?: string | null
          date?: string
          deleted_at?: string | null
          device_id?: string | null
          employee_id?: string
          id?: string
          is_suspicious_location?: boolean | null
          justification_note?: string | null
          justified_at?: string | null
          justified_by?: string | null
          lateness_comment?: string | null
          lateness_justified?: boolean | null
          notes?: string | null
          overtime_hours?: number | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      attendance_confirmations: {
        Row: {
          confirmed_at: string
          confirmed_by: string | null
          created_at: string
          employee_id: string
          id: string
          note: string | null
          period_month: number
          period_year: number
          total_days: number
          total_hours: number
        }
        Insert: {
          confirmed_at?: string
          confirmed_by?: string | null
          created_at?: string
          employee_id: string
          id?: string
          note?: string | null
          period_month: number
          period_year: number
          total_days?: number
          total_hours?: number
        }
        Update: {
          confirmed_at?: string
          confirmed_by?: string | null
          created_at?: string
          employee_id?: string
          id?: string
          note?: string | null
          period_month?: number
          period_year?: number
          total_days?: number
          total_hours?: number
        }
        Relationships: [
          {
            foreignKeyName: "attendance_confirmations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_confirmations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_confirmations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_confirmations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance_devices: {
        Row: {
          api_key: string | null
          created_at: string
          created_by: string | null
          device_model: string | null
          device_name: string
          device_type: string
          id: string
          ip_address: string | null
          is_active: boolean
          last_sync: string | null
          location: string | null
          notes: string | null
          updated_at: string
          webhook_url: string | null
        }
        Insert: {
          api_key?: string | null
          created_at?: string
          created_by?: string | null
          device_model?: string | null
          device_name: string
          device_type: string
          id?: string
          ip_address?: string | null
          is_active?: boolean
          last_sync?: string | null
          location?: string | null
          notes?: string | null
          updated_at?: string
          webhook_url?: string | null
        }
        Update: {
          api_key?: string | null
          created_at?: string
          created_by?: string | null
          device_model?: string | null
          device_name?: string
          device_type?: string
          id?: string
          ip_address?: string | null
          is_active?: boolean
          last_sync?: string | null
          location?: string | null
          notes?: string | null
          updated_at?: string
          webhook_url?: string | null
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          action_type: string
          after_state: Json | null
          before_state: Json | null
          created_at: string
          details: Json | null
          id: string
          ip_address: string | null
          resource_id: string | null
          resource_type: string
          risk_level: string | null
          session_id: string | null
          status: string
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action_type: string
          after_state?: Json | null
          before_state?: Json | null
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          resource_id?: string | null
          resource_type: string
          risk_level?: string | null
          session_id?: string | null
          status?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action_type?: string
          after_state?: Json | null
          before_state?: Json | null
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          resource_id?: string | null
          resource_type?: string
          risk_level?: string | null
          session_id?: string | null
          status?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      audit_logs_archive: {
        Row: {
          action_type: string
          after_state: Json | null
          archived_at: string
          before_state: Json | null
          created_at: string
          details: Json | null
          id: string
          ip_address: string | null
          resource_id: string | null
          resource_type: string
          risk_level: string | null
          session_id: string | null
          status: string
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action_type: string
          after_state?: Json | null
          archived_at?: string
          before_state?: Json | null
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          resource_id?: string | null
          resource_type: string
          risk_level?: string | null
          session_id?: string | null
          status?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action_type?: string
          after_state?: Json | null
          archived_at?: string
          before_state?: Json | null
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          resource_id?: string | null
          resource_type?: string
          risk_level?: string | null
          session_id?: string | null
          status?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      backup_history: {
        Row: {
          backup_type: string
          created_at: string
          created_by: string | null
          error_message: string | null
          file_path: string | null
          file_size_bytes: number | null
          id: string
          schedule_id: string | null
          status: string
          tables_included: string[]
          total_rows: number | null
        }
        Insert: {
          backup_type?: string
          created_at?: string
          created_by?: string | null
          error_message?: string | null
          file_path?: string | null
          file_size_bytes?: number | null
          id?: string
          schedule_id?: string | null
          status?: string
          tables_included?: string[]
          total_rows?: number | null
        }
        Update: {
          backup_type?: string
          created_at?: string
          created_by?: string | null
          error_message?: string | null
          file_path?: string | null
          file_size_bytes?: number | null
          id?: string
          schedule_id?: string | null
          status?: string
          tables_included?: string[]
          total_rows?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "backup_history_schedule_id_fkey"
            columns: ["schedule_id"]
            isOneToOne: false
            referencedRelation: "backup_schedules"
            referencedColumns: ["id"]
          },
        ]
      }
      backup_schedules: {
        Row: {
          created_at: string
          created_by: string | null
          email_recipients: string[] | null
          frequency: string
          id: string
          is_enabled: boolean
          last_backup_at: string | null
          next_backup_at: string | null
          selected_tables: string[]
          send_email: boolean
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          email_recipients?: string[] | null
          frequency?: string
          id?: string
          is_enabled?: boolean
          last_backup_at?: string | null
          next_backup_at?: string | null
          selected_tables?: string[]
          send_email?: boolean
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          email_recipients?: string[] | null
          frequency?: string
          id?: string
          is_enabled?: boolean
          last_backup_at?: string | null
          next_backup_at?: string | null
          selected_tables?: string[]
          send_email?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      badges: {
        Row: {
          color: string
          created_at: string
          criteria_type: string
          criteria_value: number | null
          description: string | null
          description_en: string | null
          icon: string
          id: string
          is_active: boolean
          name: string
          name_en: string | null
          points_required: number | null
        }
        Insert: {
          color?: string
          created_at?: string
          criteria_type: string
          criteria_value?: number | null
          description?: string | null
          description_en?: string | null
          icon?: string
          id?: string
          is_active?: boolean
          name: string
          name_en?: string | null
          points_required?: number | null
        }
        Update: {
          color?: string
          created_at?: string
          criteria_type?: string
          criteria_value?: number | null
          description?: string | null
          description_en?: string | null
          icon?: string
          id?: string
          is_active?: boolean
          name?: string
          name_en?: string | null
          points_required?: number | null
        }
        Relationships: []
      }
      benchmark_opt_in: {
        Row: {
          company_size_band: string
          created_at: string
          enabled_at: string | null
          enabled_by: string | null
          id: string
          industry: string | null
          is_enabled: boolean
          region: string
          updated_at: string
        }
        Insert: {
          company_size_band?: string
          created_at?: string
          enabled_at?: string | null
          enabled_by?: string | null
          id?: string
          industry?: string | null
          is_enabled?: boolean
          region?: string
          updated_at?: string
        }
        Update: {
          company_size_band?: string
          created_at?: string
          enabled_at?: string | null
          enabled_by?: string | null
          id?: string
          industry?: string | null
          is_enabled?: boolean
          region?: string
          updated_at?: string
        }
        Relationships: []
      }
      benefit_plans: {
        Row: {
          coverage_details: string | null
          coverage_end_date: string | null
          coverage_start_date: string | null
          created_at: string | null
          created_by: string | null
          eligibility_criteria: string | null
          employee_contribution: number | null
          employer_contribution: number | null
          enrollment_end_date: string | null
          enrollment_start_date: string | null
          id: string
          is_active: boolean | null
          plan_name: string
          plan_type: string
          provider_contact: string | null
          provider_name: string
          updated_at: string | null
        }
        Insert: {
          coverage_details?: string | null
          coverage_end_date?: string | null
          coverage_start_date?: string | null
          created_at?: string | null
          created_by?: string | null
          eligibility_criteria?: string | null
          employee_contribution?: number | null
          employer_contribution?: number | null
          enrollment_end_date?: string | null
          enrollment_start_date?: string | null
          id?: string
          is_active?: boolean | null
          plan_name: string
          plan_type: string
          provider_contact?: string | null
          provider_name: string
          updated_at?: string | null
        }
        Update: {
          coverage_details?: string | null
          coverage_end_date?: string | null
          coverage_start_date?: string | null
          created_at?: string | null
          created_by?: string | null
          eligibility_criteria?: string | null
          employee_contribution?: number | null
          employer_contribution?: number | null
          enrollment_end_date?: string | null
          enrollment_start_date?: string | null
          id?: string
          is_active?: boolean | null
          plan_name?: string
          plan_type?: string
          provider_contact?: string | null
          provider_name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      benefit_types: {
        Row: {
          calculation_method: string
          created_at: string
          created_by: string | null
          default_amount: number | null
          description: string | null
          id: string
          is_active: boolean
          is_taxable: boolean
          name: string
          name_ka: string | null
          pension_contribution_rate: number | null
          updated_at: string
        }
        Insert: {
          calculation_method: string
          created_at?: string
          created_by?: string | null
          default_amount?: number | null
          description?: string | null
          id?: string
          is_active?: boolean
          is_taxable?: boolean
          name: string
          name_ka?: string | null
          pension_contribution_rate?: number | null
          updated_at?: string
        }
        Update: {
          calculation_method?: string
          created_at?: string
          created_by?: string | null
          default_amount?: number | null
          description?: string | null
          id?: string
          is_active?: boolean
          is_taxable?: boolean
          name?: string
          name_ka?: string | null
          pension_contribution_rate?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      branch_transfers: {
        Row: {
          created_at: string
          created_by: string | null
          employee_id: string
          from_branch_id: string | null
          id: string
          notes: string | null
          reason: string | null
          to_branch_id: string
          transfer_date: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          employee_id: string
          from_branch_id?: string | null
          id?: string
          notes?: string | null
          reason?: string | null
          to_branch_id: string
          transfer_date?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          employee_id?: string
          from_branch_id?: string | null
          id?: string
          notes?: string | null
          reason?: string | null
          to_branch_id?: string
          transfer_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "branch_transfers_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "branch_transfers_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "branch_transfers_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "branch_transfers_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "branch_transfers_from_branch_id_fkey"
            columns: ["from_branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "branch_transfers_to_branch_id_fkey"
            columns: ["to_branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      branches: {
        Row: {
          address: string | null
          city: string | null
          code: string
          created_at: string
          currency: string
          description: string | null
          email: string | null
          id: string
          is_active: boolean
          is_primary: boolean
          logo_url: string | null
          manager_id: string | null
          name: string
          name_en: string | null
          phone: string | null
          timezone: string
          updated_at: string
        }
        Insert: {
          address?: string | null
          city?: string | null
          code: string
          created_at?: string
          currency?: string
          description?: string | null
          email?: string | null
          id?: string
          is_active?: boolean
          is_primary?: boolean
          logo_url?: string | null
          manager_id?: string | null
          name: string
          name_en?: string | null
          phone?: string | null
          timezone?: string
          updated_at?: string
        }
        Update: {
          address?: string | null
          city?: string | null
          code?: string
          created_at?: string
          currency?: string
          description?: string | null
          email?: string | null
          id?: string
          is_active?: boolean
          is_primary?: boolean
          logo_url?: string | null
          manager_id?: string | null
          name?: string
          name_en?: string | null
          phone?: string | null
          timezone?: string
          updated_at?: string
        }
        Relationships: []
      }
      budget_expenses: {
        Row: {
          amount: number
          approval_required: boolean
          approval_threshold: number | null
          approved_at: string | null
          approved_by: string | null
          budget_plan_id: string | null
          category: string
          created_at: string
          created_by: string | null
          department_id: string | null
          description: string | null
          expense_date: string
          fiscal_month: number | null
          fiscal_quarter: number | null
          fiscal_year: number
          id: string
          rejection_reason: string | null
          status: string
          updated_at: string
        }
        Insert: {
          amount: number
          approval_required?: boolean
          approval_threshold?: number | null
          approved_at?: string | null
          approved_by?: string | null
          budget_plan_id?: string | null
          category: string
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          expense_date: string
          fiscal_month?: number | null
          fiscal_quarter?: number | null
          fiscal_year: number
          id?: string
          rejection_reason?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          approval_required?: boolean
          approval_threshold?: number | null
          approved_at?: string | null
          approved_by?: string | null
          budget_plan_id?: string | null
          category?: string
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          expense_date?: string
          fiscal_month?: number | null
          fiscal_quarter?: number | null
          fiscal_year?: number
          id?: string
          rejection_reason?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "budget_expenses_budget_plan_id_fkey"
            columns: ["budget_plan_id"]
            isOneToOne: false
            referencedRelation: "budget_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budget_expenses_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      budget_plans: {
        Row: {
          actual_amount: number | null
          approved_at: string | null
          approved_by: string | null
          category: string
          created_at: string
          created_by: string | null
          department_id: string | null
          fiscal_month: number | null
          fiscal_quarter: number | null
          fiscal_year: number
          id: string
          notes: string | null
          planned_amount: number
          rejection_reason: string | null
          status: string
          submitted_by: string | null
          updated_at: string
          variance: number | null
        }
        Insert: {
          actual_amount?: number | null
          approved_at?: string | null
          approved_by?: string | null
          category: string
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          fiscal_month?: number | null
          fiscal_quarter?: number | null
          fiscal_year: number
          id?: string
          notes?: string | null
          planned_amount: number
          rejection_reason?: string | null
          status?: string
          submitted_by?: string | null
          updated_at?: string
          variance?: number | null
        }
        Update: {
          actual_amount?: number | null
          approved_at?: string | null
          approved_by?: string | null
          category?: string
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          fiscal_month?: number | null
          fiscal_quarter?: number | null
          fiscal_year?: number
          id?: string
          notes?: string | null
          planned_amount?: number
          rejection_reason?: string | null
          status?: string
          submitted_by?: string | null
          updated_at?: string
          variance?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "budget_plans_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      business_trip_requests: {
        Row: {
          accommodation_needed: boolean | null
          approved_at: string | null
          approved_by: string | null
          branch_id: string
          created_at: string | null
          destination: string
          employee_id: string | null
          end_date: string
          esim_needed: boolean | null
          estimated_budget: number | null
          hr_approved_at: string | null
          hr_approved_by: string | null
          id: string
          manager_approved_at: string | null
          manager_approved_by: string | null
          manager_id: string | null
          purpose: string
          rejection_reason: string | null
          start_date: string
          status: string
          transportation_type: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          accommodation_needed?: boolean | null
          approved_at?: string | null
          approved_by?: string | null
          branch_id?: string
          created_at?: string | null
          destination: string
          employee_id?: string | null
          end_date: string
          esim_needed?: boolean | null
          estimated_budget?: number | null
          hr_approved_at?: string | null
          hr_approved_by?: string | null
          id?: string
          manager_approved_at?: string | null
          manager_approved_by?: string | null
          manager_id?: string | null
          purpose: string
          rejection_reason?: string | null
          start_date: string
          status?: string
          transportation_type?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          accommodation_needed?: boolean | null
          approved_at?: string | null
          approved_by?: string | null
          branch_id?: string
          created_at?: string | null
          destination?: string
          employee_id?: string | null
          end_date?: string
          esim_needed?: boolean | null
          estimated_budget?: number | null
          hr_approved_at?: string | null
          hr_approved_by?: string | null
          id?: string
          manager_approved_at?: string | null
          manager_approved_by?: string | null
          manager_id?: string | null
          purpose?: string
          rejection_reason?: string | null
          start_date?: string
          status?: string
          transportation_type?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "business_trip_requests_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_hr_approved_by_fkey"
            columns: ["hr_approved_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_hr_approved_by_fkey"
            columns: ["hr_approved_by"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_hr_approved_by_fkey"
            columns: ["hr_approved_by"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_hr_approved_by_fkey"
            columns: ["hr_approved_by"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_manager_approved_by_fkey"
            columns: ["manager_approved_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_manager_approved_by_fkey"
            columns: ["manager_approved_by"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_manager_approved_by_fkey"
            columns: ["manager_approved_by"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_manager_approved_by_fkey"
            columns: ["manager_approved_by"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_trip_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      call_recordings: {
        Row: {
          call_id: string
          duration: number | null
          ended_at: string | null
          file_size: number | null
          file_url: string | null
          id: string
          started_at: string
          started_by: string
          status: string
        }
        Insert: {
          call_id: string
          duration?: number | null
          ended_at?: string | null
          file_size?: number | null
          file_url?: string | null
          id?: string
          started_at?: string
          started_by: string
          status?: string
        }
        Update: {
          call_id?: string
          duration?: number | null
          ended_at?: string | null
          file_size?: number | null
          file_url?: string | null
          id?: string
          started_at?: string
          started_by?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "call_recordings_call_id_fkey"
            columns: ["call_id"]
            isOneToOne: false
            referencedRelation: "video_calls"
            referencedColumns: ["id"]
          },
        ]
      }
      candidates: {
        Row: {
          ai_analysis: string | null
          applied_date: string | null
          branch_id: string
          cover_letter: string | null
          created_at: string | null
          deleted_at: string | null
          email: string
          external_application_id: string | null
          external_match_score: number | null
          external_source: string | null
          full_name: string
          id: string
          match_score: number | null
          phone: string | null
          photo_url: string | null
          resume_file_path: string | null
          resume_url: string | null
          source: string | null
          status: string | null
          updated_at: string | null
          vacancy_id: string | null
        }
        Insert: {
          ai_analysis?: string | null
          applied_date?: string | null
          branch_id?: string
          cover_letter?: string | null
          created_at?: string | null
          deleted_at?: string | null
          email: string
          external_application_id?: string | null
          external_match_score?: number | null
          external_source?: string | null
          full_name: string
          id?: string
          match_score?: number | null
          phone?: string | null
          photo_url?: string | null
          resume_file_path?: string | null
          resume_url?: string | null
          source?: string | null
          status?: string | null
          updated_at?: string | null
          vacancy_id?: string | null
        }
        Update: {
          ai_analysis?: string | null
          applied_date?: string | null
          branch_id?: string
          cover_letter?: string | null
          created_at?: string | null
          deleted_at?: string | null
          email?: string
          external_application_id?: string | null
          external_match_score?: number | null
          external_source?: string | null
          full_name?: string
          id?: string
          match_score?: number | null
          phone?: string | null
          photo_url?: string | null
          resume_file_path?: string | null
          resume_url?: string | null
          source?: string | null
          status?: string | null
          updated_at?: string | null
          vacancy_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "candidates_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "candidates_vacancy_id_fkey"
            columns: ["vacancy_id"]
            isOneToOne: false
            referencedRelation: "job_vacancies"
            referencedColumns: ["id"]
          },
        ]
      }
      career_events: {
        Row: {
          created_at: string
          created_by: string | null
          department_id: string | null
          department_name: string | null
          employee_id: string
          event_date: string
          event_type: string
          id: string
          notes: string | null
          position_title: string | null
          previous_salary: number | null
          salary: number | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          department_name?: string | null
          employee_id: string
          event_date: string
          event_type: string
          id?: string
          notes?: string | null
          position_title?: string | null
          previous_salary?: number | null
          salary?: number | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          department_name?: string | null
          employee_id?: string
          event_date?: string
          event_type?: string
          id?: string
          notes?: string | null
          position_title?: string | null
          previous_salary?: number | null
          salary?: number | null
          user_id?: string | null
        }
        Relationships: []
      }
      challenge_participants: {
        Row: {
          challenge_id: string
          completed: boolean
          completed_at: string | null
          created_at: string
          current_progress: number
          employee_id: string
          id: string
        }
        Insert: {
          challenge_id: string
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          current_progress?: number
          employee_id: string
          id?: string
        }
        Update: {
          challenge_id?: string
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          current_progress?: number
          employee_id?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "challenge_participants_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "team_challenges"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_participants_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_participants_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_participants_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_participants_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      changelog_items: {
        Row: {
          created_at: string | null
          id: string
          release_id: string
          sort_order: number | null
          text: string
          type: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          release_id: string
          sort_order?: number | null
          text: string
          type?: string
        }
        Update: {
          created_at?: string | null
          id?: string
          release_id?: string
          sort_order?: number | null
          text?: string
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "changelog_items_release_id_fkey"
            columns: ["release_id"]
            isOneToOne: false
            referencedRelation: "changelog_releases"
            referencedColumns: ["id"]
          },
        ]
      }
      changelog_releases: {
        Row: {
          created_at: string | null
          created_by: string | null
          highlights: string | null
          id: string
          release_date: string
          title: string
          version: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          highlights?: string | null
          id?: string
          release_date?: string
          title: string
          version: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          highlights?: string | null
          id?: string
          release_date?: string
          title?: string
          version?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          content: string
          created_at: string
          file_name: string | null
          file_size: number | null
          file_type: string | null
          file_url: string | null
          id: string
          receiver_id: string | null
          room_id: string
          sender_id: string
          type: string
        }
        Insert: {
          content: string
          created_at?: string
          file_name?: string | null
          file_size?: number | null
          file_type?: string | null
          file_url?: string | null
          id?: string
          receiver_id?: string | null
          room_id: string
          sender_id: string
          type?: string
        }
        Update: {
          content?: string
          created_at?: string
          file_name?: string | null
          file_size?: number | null
          file_type?: string | null
          file_url?: string | null
          id?: string
          receiver_id?: string | null
          room_id?: string
          sender_id?: string
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chat_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_participants: {
        Row: {
          id: string
          joined_at: string
          last_read_at: string | null
          room_id: string
          user_id: string
        }
        Insert: {
          id?: string
          joined_at?: string
          last_read_at?: string | null
          room_id: string
          user_id: string
        }
        Update: {
          id?: string
          joined_at?: string
          last_read_at?: string | null
          room_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_participants_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chat_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_rooms: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          name: string | null
          type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          name?: string | null
          type: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          name?: string | null
          type?: string
          updated_at?: string
        }
        Relationships: []
      }
      companies: {
        Row: {
          company_name: string
          contact_person: string | null
          created_at: string
          created_by: string | null
          email: string
          id: string
          identification_code: string
          is_active: boolean
          legal_address: string
          phone: string | null
          physical_address: string
          updated_at: string
        }
        Insert: {
          company_name: string
          contact_person?: string | null
          created_at?: string
          created_by?: string | null
          email: string
          id?: string
          identification_code: string
          is_active?: boolean
          legal_address: string
          phone?: string | null
          physical_address: string
          updated_at?: string
        }
        Update: {
          company_name?: string
          contact_person?: string | null
          created_at?: string
          created_by?: string | null
          email?: string
          id?: string
          identification_code?: string
          is_active?: boolean
          legal_address?: string
          phone?: string | null
          physical_address?: string
          updated_at?: string
        }
        Relationships: []
      }
      company_features: {
        Row: {
          company_id: string | null
          created_at: string | null
          enabled_at: string | null
          enabled_by: string | null
          expires_at: string | null
          feature_key: string
          id: string
          is_enabled: boolean | null
        }
        Insert: {
          company_id?: string | null
          created_at?: string | null
          enabled_at?: string | null
          enabled_by?: string | null
          expires_at?: string | null
          feature_key: string
          id?: string
          is_enabled?: boolean | null
        }
        Update: {
          company_id?: string | null
          created_at?: string | null
          enabled_at?: string | null
          enabled_by?: string | null
          expires_at?: string | null
          feature_key?: string
          id?: string
          is_enabled?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "company_features_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      company_packages: {
        Row: {
          activated_at: string | null
          activated_by: string | null
          company_id: string
          created_at: string | null
          expires_at: string | null
          id: string
          is_active: boolean | null
          package_id: string
        }
        Insert: {
          activated_at?: string | null
          activated_by?: string | null
          company_id: string
          created_at?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          package_id: string
        }
        Update: {
          activated_at?: string | null
          activated_by?: string | null
          company_id?: string
          created_at?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          package_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_packages_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_packages_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "feature_packages"
            referencedColumns: ["id"]
          },
        ]
      }
      compensation: {
        Row: {
          amount: number
          approved_at: string | null
          approved_by: string | null
          bonus_type: string | null
          branch_id: string
          created_at: string
          created_by: string | null
          employee_id: string
          id: string
          payment_date: string | null
          reason: string | null
          status: string
          type: string
          updated_at: string
        }
        Insert: {
          amount: number
          approved_at?: string | null
          approved_by?: string | null
          bonus_type?: string | null
          branch_id?: string
          created_at?: string
          created_by?: string | null
          employee_id: string
          id?: string
          payment_date?: string | null
          reason?: string | null
          status?: string
          type?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          approved_at?: string | null
          approved_by?: string | null
          bonus_type?: string | null
          branch_id?: string
          created_at?: string
          created_by?: string | null
          employee_id?: string
          id?: string
          payment_date?: string | null
          reason?: string | null
          status?: string
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "compensation_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "compensation_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "compensation_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "compensation_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "compensation_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      compliance_monitoring: {
        Row: {
          action_items: Json | null
          completed: boolean
          completion_date: string | null
          compliance_area: string
          compliance_status: string
          created_at: string
          created_by: string | null
          deadline: string | null
          findings: string | null
          id: string
          monitoring_date: string
          recommendations: string | null
          responsible_person: string | null
          updated_at: string
        }
        Insert: {
          action_items?: Json | null
          completed?: boolean
          completion_date?: string | null
          compliance_area: string
          compliance_status: string
          created_at?: string
          created_by?: string | null
          deadline?: string | null
          findings?: string | null
          id?: string
          monitoring_date: string
          recommendations?: string | null
          responsible_person?: string | null
          updated_at?: string
        }
        Update: {
          action_items?: Json | null
          completed?: boolean
          completion_date?: string | null
          compliance_area?: string
          compliance_status?: string
          created_at?: string
          created_by?: string | null
          deadline?: string | null
          findings?: string | null
          id?: string
          monitoring_date?: string
          recommendations?: string | null
          responsible_person?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      compliance_reports: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string
          file_path: string | null
          findings: Json | null
          generated_by: string | null
          id: string
          recommendations: string | null
          report_period_end: string
          report_period_start: string
          report_type: string
          status: string
          updated_at: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          file_path?: string | null
          findings?: Json | null
          generated_by?: string | null
          id?: string
          recommendations?: string | null
          report_period_end: string
          report_period_start: string
          report_type: string
          status?: string
          updated_at?: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          file_path?: string | null
          findings?: Json | null
          generated_by?: string | null
          id?: string
          recommendations?: string | null
          report_period_end?: string
          report_period_start?: string
          report_type?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      compliance_snapshots: {
        Row: {
          created_at: string
          department: string | null
          details: Json | null
          id: string
          leave_compliance_rate: number | null
          night_work_count: number
          overall_score: number
          overtime_violations: number
          pension_compliance_rate: number | null
          rest_period_violations: number
          snapshot_date: string
          total_employees: number
          work_hour_violations: number
        }
        Insert: {
          created_at?: string
          department?: string | null
          details?: Json | null
          id?: string
          leave_compliance_rate?: number | null
          night_work_count?: number
          overall_score?: number
          overtime_violations?: number
          pension_compliance_rate?: number | null
          rest_period_violations?: number
          snapshot_date: string
          total_employees?: number
          work_hour_violations?: number
        }
        Update: {
          created_at?: string
          department?: string | null
          details?: Json | null
          id?: string
          leave_compliance_rate?: number | null
          night_work_count?: number
          overall_score?: number
          overtime_violations?: number
          pension_compliance_rate?: number | null
          rest_period_violations?: number
          snapshot_date?: string
          total_employees?: number
          work_hour_violations?: number
        }
        Relationships: []
      }
      contacts: {
        Row: {
          address: string | null
          company_name: string
          contact_person: string
          created_at: string | null
          created_by: string | null
          email: string
          id: string
          notes: string | null
          phone: string | null
          status: string | null
          updated_at: string | null
        }
        Insert: {
          address?: string | null
          company_name: string
          contact_person: string
          created_at?: string | null
          created_by?: string | null
          email: string
          id?: string
          notes?: string | null
          phone?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          address?: string | null
          company_name?: string
          contact_person?: string
          created_at?: string | null
          created_by?: string | null
          email?: string
          id?: string
          notes?: string | null
          phone?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      contract_templates: {
        Row: {
          contract_type: string
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_active: boolean
          name: string
          template_content: string
          updated_at: string
        }
        Insert: {
          contract_type: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          template_content: string
          updated_at?: string
        }
        Update: {
          contract_type?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          template_content?: string
          updated_at?: string
        }
        Relationships: []
      }
      contracts: {
        Row: {
          branch_id: string
          contract_number: string | null
          contract_type: string
          created_at: string
          created_by: string | null
          deleted_at: string | null
          document_id: string | null
          employee_id: string
          end_date: string | null
          file_url: string | null
          id: string
          notification_sent: boolean
          position: string
          renewal_notes: string | null
          renewal_status: string | null
          renewed_at: string | null
          renewed_by: string | null
          salary: number
          signature_data: string | null
          signed_at: string | null
          start_date: string
          status: string
          terms: string | null
          updated_at: string
        }
        Insert: {
          branch_id?: string
          contract_number?: string | null
          contract_type: string
          created_at?: string
          created_by?: string | null
          deleted_at?: string | null
          document_id?: string | null
          employee_id: string
          end_date?: string | null
          file_url?: string | null
          id?: string
          notification_sent?: boolean
          position: string
          renewal_notes?: string | null
          renewal_status?: string | null
          renewed_at?: string | null
          renewed_by?: string | null
          salary: number
          signature_data?: string | null
          signed_at?: string | null
          start_date: string
          status?: string
          terms?: string | null
          updated_at?: string
        }
        Update: {
          branch_id?: string
          contract_number?: string | null
          contract_type?: string
          created_at?: string
          created_by?: string | null
          deleted_at?: string | null
          document_id?: string | null
          employee_id?: string
          end_date?: string | null
          file_url?: string | null
          id?: string
          notification_sent?: boolean
          position?: string
          renewal_notes?: string | null
          renewal_status?: string | null
          renewed_at?: string | null
          renewed_by?: string | null
          salary?: number
          signature_data?: string | null
          signed_at?: string | null
          start_date?: string
          status?: string
          terms?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "contracts_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contracts_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contracts_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contracts_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contracts_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contracts_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      custom_roles: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      data_breaches: {
        Row: {
          affected_data_categories: string[]
          affected_individuals_notified: boolean
          authority_notification_date: string | null
          breach_type: string
          created_at: string
          description: string
          discovered_by: string | null
          discovery_date: string
          dpo_notified: boolean
          id: string
          investigated_by: string | null
          likely_consequences: string | null
          measures_taken: string | null
          notification_date: string | null
          notification_deadline: string | null
          number_of_affected_individuals: number | null
          occurrence_date: string | null
          preventive_measures: string | null
          root_cause: string | null
          severity: string
          status: string
          supervisory_authority_notified: boolean
          updated_at: string
        }
        Insert: {
          affected_data_categories: string[]
          affected_individuals_notified?: boolean
          authority_notification_date?: string | null
          breach_type: string
          created_at?: string
          description: string
          discovered_by?: string | null
          discovery_date: string
          dpo_notified?: boolean
          id?: string
          investigated_by?: string | null
          likely_consequences?: string | null
          measures_taken?: string | null
          notification_date?: string | null
          notification_deadline?: string | null
          number_of_affected_individuals?: number | null
          occurrence_date?: string | null
          preventive_measures?: string | null
          root_cause?: string | null
          severity: string
          status?: string
          supervisory_authority_notified?: boolean
          updated_at?: string
        }
        Update: {
          affected_data_categories?: string[]
          affected_individuals_notified?: boolean
          authority_notification_date?: string | null
          breach_type?: string
          created_at?: string
          description?: string
          discovered_by?: string | null
          discovery_date?: string
          dpo_notified?: boolean
          id?: string
          investigated_by?: string | null
          likely_consequences?: string | null
          measures_taken?: string | null
          notification_date?: string | null
          notification_deadline?: string | null
          number_of_affected_individuals?: number | null
          occurrence_date?: string | null
          preventive_measures?: string | null
          root_cause?: string | null
          severity?: string
          status?: string
          supervisory_authority_notified?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      data_classifications: {
        Row: {
          access_control_level: string
          classification_level: string
          column_name: string
          created_at: string
          created_by: string | null
          encryption_required: boolean
          id: string
          sensitivity_reason: string | null
          table_name: string
          updated_at: string
        }
        Insert: {
          access_control_level?: string
          classification_level: string
          column_name: string
          created_at?: string
          created_by?: string | null
          encryption_required?: boolean
          id?: string
          sensitivity_reason?: string | null
          table_name: string
          updated_at?: string
        }
        Update: {
          access_control_level?: string
          classification_level?: string
          column_name?: string
          created_at?: string
          created_by?: string | null
          encryption_required?: boolean
          id?: string
          sensitivity_reason?: string | null
          table_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      data_processing_agreements: {
        Row: {
          agreement_date: string
          compliance_status: string
          contract_file_path: string | null
          created_at: string
          created_by: string | null
          data_categories: string[]
          expiry_date: string | null
          id: string
          last_audit_date: string | null
          next_audit_date: string | null
          notes: string | null
          processing_purpose: string
          processor_contact: string
          processor_name: string
          processor_type: string
          security_measures: string
          status: string
          sub_processors: string[] | null
          updated_at: string
        }
        Insert: {
          agreement_date: string
          compliance_status?: string
          contract_file_path?: string | null
          created_at?: string
          created_by?: string | null
          data_categories: string[]
          expiry_date?: string | null
          id?: string
          last_audit_date?: string | null
          next_audit_date?: string | null
          notes?: string | null
          processing_purpose: string
          processor_contact: string
          processor_name: string
          processor_type: string
          security_measures: string
          status?: string
          sub_processors?: string[] | null
          updated_at?: string
        }
        Update: {
          agreement_date?: string
          compliance_status?: string
          contract_file_path?: string | null
          created_at?: string
          created_by?: string | null
          data_categories?: string[]
          expiry_date?: string | null
          id?: string
          last_audit_date?: string | null
          next_audit_date?: string | null
          notes?: string | null
          processing_purpose?: string
          processor_contact?: string
          processor_name?: string
          processor_type?: string
          security_measures?: string
          status?: string
          sub_processors?: string[] | null
          updated_at?: string
        }
        Relationships: []
      }
      data_retention_policies: {
        Row: {
          created_at: string
          created_by: string | null
          data_category: string
          deletion_method: string
          description: string | null
          id: string
          is_active: boolean
          legal_basis: string | null
          policy_name: string
          retention_period_days: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          data_category: string
          deletion_method?: string
          description?: string | null
          id?: string
          is_active?: boolean
          legal_basis?: string | null
          policy_name: string
          retention_period_days: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          data_category?: string
          deletion_method?: string
          description?: string | null
          id?: string
          is_active?: boolean
          legal_basis?: string | null
          policy_name?: string
          retention_period_days?: number
          updated_at?: string
        }
        Relationships: []
      }
      deals: {
        Row: {
          amount: number
          contact_id: string | null
          created_at: string | null
          created_by: string | null
          description: string | null
          expected_close_date: string | null
          id: string
          probability: number | null
          status: string | null
          title: string
          updated_at: string | null
        }
        Insert: {
          amount: number
          contact_id?: string | null
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          expected_close_date?: string | null
          id?: string
          probability?: number | null
          status?: string | null
          title: string
          updated_at?: string | null
        }
        Update: {
          amount?: number
          contact_id?: string | null
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          expected_close_date?: string | null
          id?: string
          probability?: number | null
          status?: string | null
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "deals_contact_id_fkey"
            columns: ["contact_id"]
            isOneToOne: false
            referencedRelation: "contacts"
            referencedColumns: ["id"]
          },
        ]
      }
      deduction_types: {
        Row: {
          calculation_method: string
          created_at: string
          created_by: string | null
          default_amount: number | null
          description: string | null
          id: string
          is_active: boolean
          is_mandatory: boolean
          name: string
          name_ka: string | null
          pension_contribution_rate: number | null
          updated_at: string
        }
        Insert: {
          calculation_method: string
          created_at?: string
          created_by?: string | null
          default_amount?: number | null
          description?: string | null
          id?: string
          is_active?: boolean
          is_mandatory?: boolean
          name: string
          name_ka?: string | null
          pension_contribution_rate?: number | null
          updated_at?: string
        }
        Update: {
          calculation_method?: string
          created_at?: string
          created_by?: string | null
          default_amount?: number | null
          description?: string | null
          id?: string
          is_active?: boolean
          is_mandatory?: boolean
          name?: string
          name_ka?: string | null
          pension_contribution_rate?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      departments: {
        Row: {
          branch_id: string
          budget: number | null
          created_at: string
          created_by: string | null
          description: string | null
          headcount_limit: number | null
          id: string
          is_active: boolean
          manager_id: string | null
          name: string
          name_en: string | null
          parent_department_id: string | null
          updated_at: string
        }
        Insert: {
          branch_id?: string
          budget?: number | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          headcount_limit?: number | null
          id?: string
          is_active?: boolean
          manager_id?: string | null
          name: string
          name_en?: string | null
          parent_department_id?: string | null
          updated_at?: string
        }
        Update: {
          branch_id?: string
          budget?: number | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          headcount_limit?: number | null
          id?: string
          is_active?: boolean
          manager_id?: string | null
          name?: string
          name_en?: string | null
          parent_department_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "departments_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "departments_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "departments_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "departments_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "departments_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "departments_parent_department_id_fkey"
            columns: ["parent_department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      device_tokens: {
        Row: {
          created_at: string
          id: string
          platform: string
          token: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          platform?: string
          token: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          platform?: string
          token?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      disciplinary_actions: {
        Row: {
          action_type: string
          created_at: string
          created_by: string | null
          description: string | null
          employee_id: string
          follow_up_date: string | null
          follow_up_notes: string | null
          id: string
          issued_by: string | null
          issued_date: string
          reason: string
          severity: string
          status: string
          updated_at: string
        }
        Insert: {
          action_type: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          employee_id: string
          follow_up_date?: string | null
          follow_up_notes?: string | null
          id?: string
          issued_by?: string | null
          issued_date?: string
          reason: string
          severity?: string
          status?: string
          updated_at?: string
        }
        Update: {
          action_type?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          employee_id?: string
          follow_up_date?: string | null
          follow_up_notes?: string | null
          id?: string
          issued_by?: string | null
          issued_date?: string
          reason?: string
          severity?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "disciplinary_actions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disciplinary_actions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disciplinary_actions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disciplinary_actions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disciplinary_actions_issued_by_fkey"
            columns: ["issued_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disciplinary_actions_issued_by_fkey"
            columns: ["issued_by"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disciplinary_actions_issued_by_fkey"
            columns: ["issued_by"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disciplinary_actions_issued_by_fkey"
            columns: ["issued_by"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      document_policies: {
        Row: {
          approver_role: Database["public"]["Enums"]["app_role"] | null
          auto_expire: boolean
          created_at: string
          created_by: string | null
          document_category: string
          id: string
          is_active: boolean
          notification_days_before: number | null
          policy_name: string
          requires_approval: boolean
          requires_signature: boolean
          retention_days: number | null
          updated_at: string
        }
        Insert: {
          approver_role?: Database["public"]["Enums"]["app_role"] | null
          auto_expire?: boolean
          created_at?: string
          created_by?: string | null
          document_category: string
          id?: string
          is_active?: boolean
          notification_days_before?: number | null
          policy_name: string
          requires_approval?: boolean
          requires_signature?: boolean
          retention_days?: number | null
          updated_at?: string
        }
        Update: {
          approver_role?: Database["public"]["Enums"]["app_role"] | null
          auto_expire?: boolean
          created_at?: string
          created_by?: string | null
          document_category?: string
          id?: string
          is_active?: boolean
          notification_days_before?: number | null
          policy_name?: string
          requires_approval?: boolean
          requires_signature?: boolean
          retention_days?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      document_signatures: {
        Row: {
          created_at: string
          document_id: string
          document_url: string | null
          employee_id: string
          id: string
          ip_address: string | null
          is_acknowledged: boolean
          signature_data: string | null
          signed_at: string | null
          viewed_at: string | null
        }
        Insert: {
          created_at?: string
          document_id: string
          document_url?: string | null
          employee_id: string
          id?: string
          ip_address?: string | null
          is_acknowledged?: boolean
          signature_data?: string | null
          signed_at?: string | null
          viewed_at?: string | null
        }
        Update: {
          created_at?: string
          document_id?: string
          document_url?: string | null
          employee_id?: string
          id?: string
          ip_address?: string | null
          is_acknowledged?: boolean
          signature_data?: string | null
          signed_at?: string | null
          viewed_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "document_signatures_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_signatures_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_signatures_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_signatures_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_signatures_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      document_templates: {
        Row: {
          content: string
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_active: boolean
          name: string
          requires_signature: boolean
          template_type: string
          updated_at: string
        }
        Insert: {
          content: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          requires_signature?: boolean
          template_type: string
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          requires_signature?: boolean
          template_type?: string
          updated_at?: string
        }
        Relationships: []
      }
      documents: {
        Row: {
          branch_id: string
          category: string | null
          created_at: string
          deleted_at: string | null
          description: string | null
          employee_id: string | null
          file_path: string
          file_size: number | null
          file_type: string | null
          id: string
          title: string
          updated_at: string
          uploaded_by: string
        }
        Insert: {
          branch_id?: string
          category?: string | null
          created_at?: string
          deleted_at?: string | null
          description?: string | null
          employee_id?: string | null
          file_path: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          title: string
          updated_at?: string
          uploaded_by: string
        }
        Update: {
          branch_id?: string
          category?: string | null
          created_at?: string
          deleted_at?: string | null
          description?: string | null
          employee_id?: string | null
          file_path?: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          title?: string
          updated_at?: string
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "documents_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      dpia_assessments: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          assessed_by: string | null
          assessment_name: string
          authority_opinion: string | null
          consultation_required: boolean
          created_at: string
          dpo_consulted: boolean
          dpo_opinion: string | null
          id: string
          identified_risks: Json
          mitigation_measures: Json
          necessity_justification: string
          next_review_date: string | null
          processing_activity_id: string | null
          proportionality_assessment: string
          residual_risk_level: string
          reviewed_by: string | null
          risk_level: string
          status: string
          supervisory_authority_consulted: boolean
          updated_at: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          assessed_by?: string | null
          assessment_name: string
          authority_opinion?: string | null
          consultation_required?: boolean
          created_at?: string
          dpo_consulted?: boolean
          dpo_opinion?: string | null
          id?: string
          identified_risks: Json
          mitigation_measures: Json
          necessity_justification: string
          next_review_date?: string | null
          processing_activity_id?: string | null
          proportionality_assessment: string
          residual_risk_level: string
          reviewed_by?: string | null
          risk_level: string
          status?: string
          supervisory_authority_consulted?: boolean
          updated_at?: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          assessed_by?: string | null
          assessment_name?: string
          authority_opinion?: string | null
          consultation_required?: boolean
          created_at?: string
          dpo_consulted?: boolean
          dpo_opinion?: string | null
          id?: string
          identified_risks?: Json
          mitigation_measures?: Json
          necessity_justification?: string
          next_review_date?: string | null
          processing_activity_id?: string | null
          proportionality_assessment?: string
          residual_risk_level?: string
          reviewed_by?: string | null
          risk_level?: string
          status?: string
          supervisory_authority_consulted?: boolean
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "dpia_assessments_processing_activity_id_fkey"
            columns: ["processing_activity_id"]
            isOneToOne: false
            referencedRelation: "processing_activities"
            referencedColumns: ["id"]
          },
        ]
      }
      dpo_activities: {
        Row: {
          activity_date: string
          activity_type: string
          created_at: string
          created_by: string | null
          description: string
          follow_up_date: string | null
          follow_up_required: boolean
          id: string
          outcomes: string | null
          participants: string[] | null
          recommendations: string | null
          status: string
          updated_at: string
        }
        Insert: {
          activity_date: string
          activity_type: string
          created_at?: string
          created_by?: string | null
          description: string
          follow_up_date?: string | null
          follow_up_required?: boolean
          id?: string
          outcomes?: string | null
          participants?: string[] | null
          recommendations?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          activity_date?: string
          activity_type?: string
          created_at?: string
          created_by?: string | null
          description?: string
          follow_up_date?: string | null
          follow_up_required?: boolean
          id?: string
          outcomes?: string | null
          participants?: string[] | null
          recommendations?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      dsr_requests: {
        Row: {
          actions_taken: Json | null
          assigned_to: string | null
          created_at: string
          deadline: string
          id: string
          priority: string
          request_details: string
          request_type: string
          request_type_ka: string | null
          requester_email: string
          requester_name: string
          response: string | null
          response_date: string | null
          status: string
          subject_details: Json | null
          updated_at: string
          user_id: string | null
          verification_method: string | null
          verification_status: string
        }
        Insert: {
          actions_taken?: Json | null
          assigned_to?: string | null
          created_at?: string
          deadline: string
          id?: string
          priority?: string
          request_details: string
          request_type: string
          request_type_ka?: string | null
          requester_email: string
          requester_name: string
          response?: string | null
          response_date?: string | null
          status?: string
          subject_details?: Json | null
          updated_at?: string
          user_id?: string | null
          verification_method?: string | null
          verification_status?: string
        }
        Update: {
          actions_taken?: Json | null
          assigned_to?: string | null
          created_at?: string
          deadline?: string
          id?: string
          priority?: string
          request_details?: string
          request_type?: string
          request_type_ka?: string | null
          requester_email?: string
          requester_name?: string
          response?: string | null
          response_date?: string | null
          status?: string
          subject_details?: Json | null
          updated_at?: string
          user_id?: string | null
          verification_method?: string | null
          verification_status?: string
        }
        Relationships: []
      }
      email_send_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          message_id: string | null
          metadata: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email?: string
          status?: string
          template_name?: string
        }
        Relationships: []
      }
      email_send_state: {
        Row: {
          auth_email_ttl_minutes: number
          batch_size: number
          id: number
          retry_after_until: string | null
          send_delay_ms: number
          transactional_email_ttl_minutes: number
          updated_at: string
        }
        Insert: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Update: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Relationships: []
      }
      email_unsubscribe_tokens: {
        Row: {
          created_at: string
          email: string
          id: string
          token: string
          used_at: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          token: string
          used_at?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          token?: string
          used_at?: string | null
        }
        Relationships: []
      }
      employee_badges: {
        Row: {
          badge_id: string
          earned_at: string
          employee_id: string
          id: string
        }
        Insert: {
          badge_id: string
          earned_at?: string
          employee_id: string
          id?: string
        }
        Update: {
          badge_id?: string
          earned_at?: string
          employee_id?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_badges_badge_id_fkey"
            columns: ["badge_id"]
            isOneToOne: false
            referencedRelation: "badges"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_badges_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_badges_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_badges_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_badges_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_benefit_enrollments: {
        Row: {
          benefit_plan_id: string
          coverage_level: string | null
          created_at: string | null
          employee_contribution: number | null
          employee_id: string
          employer_contribution: number | null
          end_date: string | null
          enrollment_date: string
          id: string
          notes: string | null
          start_date: string | null
          status: string | null
          updated_at: string | null
        }
        Insert: {
          benefit_plan_id: string
          coverage_level?: string | null
          created_at?: string | null
          employee_contribution?: number | null
          employee_id: string
          employer_contribution?: number | null
          end_date?: string | null
          enrollment_date?: string
          id?: string
          notes?: string | null
          start_date?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          benefit_plan_id?: string
          coverage_level?: string | null
          created_at?: string | null
          employee_contribution?: number | null
          employee_id?: string
          employer_contribution?: number | null
          end_date?: string | null
          enrollment_date?: string
          id?: string
          notes?: string | null
          start_date?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "employee_benefit_enrollments_benefit_plan_id_fkey"
            columns: ["benefit_plan_id"]
            isOneToOne: false
            referencedRelation: "benefit_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_benefit_enrollments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_benefit_enrollments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_benefit_enrollments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_benefit_enrollments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_benefits: {
        Row: {
          amount: number
          attachment_url: string | null
          benefit_type_id: string | null
          created_at: string
          created_by: string | null
          employee_id: string
          end_date: string | null
          granted_at: string | null
          granted_by: string | null
          id: string
          is_active: boolean
          notes: string | null
          reference_url: string | null
          service_category: string
          start_date: string
          updated_at: string
        }
        Insert: {
          amount: number
          attachment_url?: string | null
          benefit_type_id?: string | null
          created_at?: string
          created_by?: string | null
          employee_id: string
          end_date?: string | null
          granted_at?: string | null
          granted_by?: string | null
          id?: string
          is_active?: boolean
          notes?: string | null
          reference_url?: string | null
          service_category?: string
          start_date: string
          updated_at?: string
        }
        Update: {
          amount?: number
          attachment_url?: string | null
          benefit_type_id?: string | null
          created_at?: string
          created_by?: string | null
          employee_id?: string
          end_date?: string | null
          granted_at?: string | null
          granted_by?: string | null
          id?: string
          is_active?: boolean
          notes?: string | null
          reference_url?: string | null
          service_category?: string
          start_date?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_benefits_benefit_type_id_fkey"
            columns: ["benefit_type_id"]
            isOneToOne: false
            referencedRelation: "benefit_types"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_certifications: {
        Row: {
          certification_name: string
          created_at: string | null
          credential_id: string | null
          credential_url: string | null
          employee_id: string | null
          expiry_date: string | null
          id: string
          is_active: boolean | null
          issue_date: string
          issuing_organization: string | null
        }
        Insert: {
          certification_name: string
          created_at?: string | null
          credential_id?: string | null
          credential_url?: string | null
          employee_id?: string | null
          expiry_date?: string | null
          id?: string
          is_active?: boolean | null
          issue_date: string
          issuing_organization?: string | null
        }
        Update: {
          certification_name?: string
          created_at?: string | null
          credential_id?: string | null
          credential_url?: string | null
          employee_id?: string | null
          expiry_date?: string | null
          id?: string
          is_active?: boolean | null
          issue_date?: string
          issuing_organization?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "employee_certifications_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_certifications_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_certifications_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_certifications_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_deductions: {
        Row: {
          amount: number
          branch_id: string
          created_at: string
          created_by: string | null
          deduction_type_id: string | null
          employee_id: string
          end_date: string | null
          id: string
          is_active: boolean
          notes: string | null
          start_date: string
          updated_at: string
        }
        Insert: {
          amount: number
          branch_id?: string
          created_at?: string
          created_by?: string | null
          deduction_type_id?: string | null
          employee_id: string
          end_date?: string | null
          id?: string
          is_active?: boolean
          notes?: string | null
          start_date: string
          updated_at?: string
        }
        Update: {
          amount?: number
          branch_id?: string
          created_at?: string
          created_by?: string | null
          deduction_type_id?: string | null
          employee_id?: string
          end_date?: string | null
          id?: string
          is_active?: boolean
          notes?: string | null
          start_date?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_deductions_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_deductions_deduction_type_id_fkey"
            columns: ["deduction_type_id"]
            isOneToOne: false
            referencedRelation: "deduction_types"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_evaluations: {
        Row: {
          areas_for_improvement: string | null
          branch_id: string
          comments: string | null
          communication_rating: number | null
          created_at: string | null
          employee_id: string
          evaluation_date: string
          evaluator_id: string
          goals: string | null
          id: string
          leadership_rating: number | null
          overall_rating: number | null
          performance_rating: number | null
          period_end: string
          period_start: string
          status: string | null
          strengths: string | null
          teamwork_rating: number | null
          updated_at: string | null
        }
        Insert: {
          areas_for_improvement?: string | null
          branch_id?: string
          comments?: string | null
          communication_rating?: number | null
          created_at?: string | null
          employee_id: string
          evaluation_date?: string
          evaluator_id: string
          goals?: string | null
          id?: string
          leadership_rating?: number | null
          overall_rating?: number | null
          performance_rating?: number | null
          period_end: string
          period_start: string
          status?: string | null
          strengths?: string | null
          teamwork_rating?: number | null
          updated_at?: string | null
        }
        Update: {
          areas_for_improvement?: string | null
          branch_id?: string
          comments?: string | null
          communication_rating?: number | null
          created_at?: string | null
          employee_id?: string
          evaluation_date?: string
          evaluator_id?: string
          goals?: string | null
          id?: string
          leadership_rating?: number | null
          overall_rating?: number | null
          performance_rating?: number | null
          period_end?: string
          period_start?: string
          status?: string | null
          strengths?: string | null
          teamwork_rating?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "employee_evaluations_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_evaluations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_evaluations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_evaluations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_evaluations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_feedback: {
        Row: {
          ai_recommendation: string | null
          created_at: string
          description: string
          employee_id: string | null
          hr_notes: string | null
          id: string
          is_anonymous: boolean
          manager_notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: Database["public"]["Enums"]["feedback_status"]
          subject: string
          type: Database["public"]["Enums"]["feedback_type"]
          updated_at: string
        }
        Insert: {
          ai_recommendation?: string | null
          created_at?: string
          description: string
          employee_id?: string | null
          hr_notes?: string | null
          id?: string
          is_anonymous?: boolean
          manager_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["feedback_status"]
          subject: string
          type: Database["public"]["Enums"]["feedback_type"]
          updated_at?: string
        }
        Update: {
          ai_recommendation?: string | null
          created_at?: string
          description?: string
          employee_id?: string | null
          hr_notes?: string | null
          id?: string
          is_anonymous?: boolean
          manager_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["feedback_status"]
          subject?: string
          type?: Database["public"]["Enums"]["feedback_type"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_feedback_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_feedback_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_feedback_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_feedback_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_goals: {
        Row: {
          actual_result: string | null
          assigned_by: string | null
          branch_id: string
          category: string | null
          created_at: string | null
          description: string | null
          employee_id: string | null
          goal_type: string | null
          id: string
          measurement_criteria: string | null
          progress_percentage: number | null
          start_date: string
          status: string | null
          target_date: string
          title: string
          updated_at: string | null
        }
        Insert: {
          actual_result?: string | null
          assigned_by?: string | null
          branch_id?: string
          category?: string | null
          created_at?: string | null
          description?: string | null
          employee_id?: string | null
          goal_type?: string | null
          id?: string
          measurement_criteria?: string | null
          progress_percentage?: number | null
          start_date: string
          status?: string | null
          target_date: string
          title: string
          updated_at?: string | null
        }
        Update: {
          actual_result?: string | null
          assigned_by?: string | null
          branch_id?: string
          category?: string | null
          created_at?: string | null
          description?: string | null
          employee_id?: string | null
          goal_type?: string | null
          id?: string
          measurement_criteria?: string | null
          progress_percentage?: number | null
          start_date?: string
          status?: string | null
          target_date?: string
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "employee_goals_assigned_by_fkey"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_goals_assigned_by_fkey"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_goals_assigned_by_fkey"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_goals_assigned_by_fkey"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_goals_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_goals_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_goals_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_goals_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_goals_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_history: {
        Row: {
          applied_at: string | null
          change_type: string
          created_at: string
          created_by: string | null
          effective_date: string
          employee_id: string
          id: string
          new_branch_id: string | null
          new_department: string | null
          new_position: string | null
          new_salary: number | null
          notes: string | null
          previous_branch_id: string | null
          previous_department: string | null
          previous_position: string | null
          previous_salary: number | null
          reason: string | null
          status: string
        }
        Insert: {
          applied_at?: string | null
          change_type: string
          created_at?: string
          created_by?: string | null
          effective_date: string
          employee_id: string
          id?: string
          new_branch_id?: string | null
          new_department?: string | null
          new_position?: string | null
          new_salary?: number | null
          notes?: string | null
          previous_branch_id?: string | null
          previous_department?: string | null
          previous_position?: string | null
          previous_salary?: number | null
          reason?: string | null
          status?: string
        }
        Update: {
          applied_at?: string | null
          change_type?: string
          created_at?: string
          created_by?: string | null
          effective_date?: string
          employee_id?: string
          id?: string
          new_branch_id?: string | null
          new_department?: string | null
          new_position?: string | null
          new_salary?: number | null
          notes?: string | null
          previous_branch_id?: string | null
          previous_department?: string | null
          previous_position?: string | null
          previous_salary?: number | null
          reason?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_history_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_history_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_history_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_history_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_history_new_branch_id_fkey"
            columns: ["new_branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_history_previous_branch_id_fkey"
            columns: ["previous_branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_onboarding: {
        Row: {
          actual_completion_date: string | null
          created_at: string | null
          created_by: string | null
          employee_id: string | null
          expected_completion_date: string | null
          id: string
          progress_percentage: number | null
          start_date: string
          status: string | null
          template_id: string | null
          updated_at: string | null
        }
        Insert: {
          actual_completion_date?: string | null
          created_at?: string | null
          created_by?: string | null
          employee_id?: string | null
          expected_completion_date?: string | null
          id?: string
          progress_percentage?: number | null
          start_date: string
          status?: string | null
          template_id?: string | null
          updated_at?: string | null
        }
        Update: {
          actual_completion_date?: string | null
          created_at?: string | null
          created_by?: string | null
          employee_id?: string | null
          expected_completion_date?: string | null
          id?: string
          progress_percentage?: number | null
          start_date?: string
          status?: string | null
          template_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "employee_onboarding_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_onboarding_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_onboarding_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_onboarding_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_onboarding_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "onboarding_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_points: {
        Row: {
          created_at: string
          current_points: number
          employee_id: string
          id: string
          level: number
          total_earned: number
          total_spent: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          current_points?: number
          employee_id: string
          id?: string
          level?: number
          total_earned?: number
          total_spent?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          current_points?: number
          employee_id?: string
          id?: string
          level?: number
          total_earned?: number
          total_spent?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_points_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: true
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_points_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: true
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_points_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: true
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_points_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: true
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_risk_assessments: {
        Row: {
          assessed_at: string | null
          assessed_by: string | null
          created_at: string | null
          employee_id: string
          id: string
          recommendations: Json | null
          risk_factors: Json | null
          risk_level: string
          risk_score: number
        }
        Insert: {
          assessed_at?: string | null
          assessed_by?: string | null
          created_at?: string | null
          employee_id: string
          id?: string
          recommendations?: Json | null
          risk_factors?: Json | null
          risk_level?: string
          risk_score: number
        }
        Update: {
          assessed_at?: string | null
          assessed_by?: string | null
          created_at?: string | null
          employee_id?: string
          id?: string
          recommendations?: Json | null
          risk_factors?: Json | null
          risk_level?: string
          risk_score?: number
        }
        Relationships: [
          {
            foreignKeyName: "employee_risk_assessments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_risk_assessments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_risk_assessments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_risk_assessments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_role_fit: {
        Row: {
          created_at: string
          created_by: string | null
          current_fit: number | null
          data_sufficient: boolean
          employee_id: string
          id: string
          summary: string | null
          top_matches: Json
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          current_fit?: number | null
          data_sufficient?: boolean
          employee_id: string
          id?: string
          summary?: string | null
          top_matches?: Json
        }
        Update: {
          created_at?: string
          created_by?: string | null
          current_fit?: number | null
          data_sufficient?: boolean
          employee_id?: string
          id?: string
          summary?: string | null
          top_matches?: Json
        }
        Relationships: [
          {
            foreignKeyName: "employee_role_fit_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_role_fit_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_role_fit_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_role_fit_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_schedules: {
        Row: {
          branch_id: string
          created_at: string | null
          employee_id: string
          end_date: string | null
          id: string
          start_date: string
          template_id: string
          updated_at: string | null
        }
        Insert: {
          branch_id?: string
          created_at?: string | null
          employee_id: string
          end_date?: string | null
          id?: string
          start_date?: string
          template_id: string
          updated_at?: string | null
        }
        Update: {
          branch_id?: string
          created_at?: string | null
          employee_id?: string
          end_date?: string | null
          id?: string
          start_date?: string
          template_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "employee_schedules_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_schedules_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "schedule_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_skills: {
        Row: {
          created_at: string
          employee_id: string
          id: string
          level: number
          notes: string | null
          skill_id: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          created_at?: string
          employee_id: string
          id?: string
          level: number
          notes?: string | null
          skill_id: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          created_at?: string
          employee_id?: string
          id?: string
          level?: number
          notes?: string | null
          skill_id?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "employee_skills_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_skills_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_skills_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_skills_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_skills_skill_id_fkey"
            columns: ["skill_id"]
            isOneToOne: false
            referencedRelation: "skills"
            referencedColumns: ["id"]
          },
        ]
      }
      employees: {
        Row: {
          actual_address: string | null
          additional_phone: string | null
          attendance_method: string | null
          avatar_url: string | null
          bank_account: string | null
          bank_account_number: string | null
          bank_code: string | null
          bank_name: string | null
          branch_id: string
          card_number: string | null
          citizenship_countries: string[] | null
          comments: string | null
          created_at: string | null
          created_by: string | null
          custom_end_time: string | null
          custom_start_time: string | null
          date_of_birth: string | null
          deleted_at: string | null
          department: string | null
          education: string | null
          education_level: string | null
          email: string
          emergency_contact_name: string | null
          emergency_contact_phone: string | null
          emergency_contact_relation: string | null
          employee_comment: string | null
          employee_number: string | null
          father_name: string | null
          foreign_country: string | null
          full_name: string
          gender: string | null
          has_changed_password: boolean | null
          has_disability: boolean | null
          has_pension: boolean | null
          hire_date: string
          hourly_rate: number | null
          id: string
          is_dual_citizen: boolean | null
          is_intern: boolean | null
          is_minor: boolean | null
          is_pension_payer: boolean | null
          is_pregnant: boolean | null
          is_probation: boolean | null
          last_name: string | null
          lateness_control_enabled: boolean | null
          legal_address: string | null
          minimum_wage_compliant: boolean | null
          office_location_id: string | null
          pension_account_number: string | null
          personal_id: string | null
          personal_id_number: string | null
          phone: string | null
          phone_number: string | null
          position: string
          previous_experience: string | null
          probation_months: number | null
          receive_lateness_sms: boolean | null
          receive_sms_notifications: boolean | null
          receive_subordinate_lateness_sms: boolean | null
          receive_subordinate_sms: boolean | null
          residency_status: string | null
          salary: number | null
          salary_type: string
          savings: number | null
          secondary_manager_id: string | null
          show_door_access_history: boolean | null
          show_email_on_info_page: boolean | null
          show_email_on_list: boolean | null
          show_norm_on_info_page: boolean | null
          show_phone_on_list: boolean | null
          show_resignation_date: boolean | null
          status: string | null
          tax_benefits: string | null
          termination_date: string | null
          termination_reason: string | null
          turnstile_card_number: string | null
          updated_at: string | null
          user_id: string | null
          work_schedule_id: string | null
        }
        Insert: {
          actual_address?: string | null
          additional_phone?: string | null
          attendance_method?: string | null
          avatar_url?: string | null
          bank_account?: string | null
          bank_account_number?: string | null
          bank_code?: string | null
          bank_name?: string | null
          branch_id?: string
          card_number?: string | null
          citizenship_countries?: string[] | null
          comments?: string | null
          created_at?: string | null
          created_by?: string | null
          custom_end_time?: string | null
          custom_start_time?: string | null
          date_of_birth?: string | null
          deleted_at?: string | null
          department?: string | null
          education?: string | null
          education_level?: string | null
          email: string
          emergency_contact_name?: string | null
          emergency_contact_phone?: string | null
          emergency_contact_relation?: string | null
          employee_comment?: string | null
          employee_number?: string | null
          father_name?: string | null
          foreign_country?: string | null
          full_name: string
          gender?: string | null
          has_changed_password?: boolean | null
          has_disability?: boolean | null
          has_pension?: boolean | null
          hire_date?: string
          hourly_rate?: number | null
          id?: string
          is_dual_citizen?: boolean | null
          is_intern?: boolean | null
          is_minor?: boolean | null
          is_pension_payer?: boolean | null
          is_pregnant?: boolean | null
          is_probation?: boolean | null
          last_name?: string | null
          lateness_control_enabled?: boolean | null
          legal_address?: string | null
          minimum_wage_compliant?: boolean | null
          office_location_id?: string | null
          pension_account_number?: string | null
          personal_id?: string | null
          personal_id_number?: string | null
          phone?: string | null
          phone_number?: string | null
          position: string
          previous_experience?: string | null
          probation_months?: number | null
          receive_lateness_sms?: boolean | null
          receive_sms_notifications?: boolean | null
          receive_subordinate_lateness_sms?: boolean | null
          receive_subordinate_sms?: boolean | null
          residency_status?: string | null
          salary?: number | null
          salary_type?: string
          savings?: number | null
          secondary_manager_id?: string | null
          show_door_access_history?: boolean | null
          show_email_on_info_page?: boolean | null
          show_email_on_list?: boolean | null
          show_norm_on_info_page?: boolean | null
          show_phone_on_list?: boolean | null
          show_resignation_date?: boolean | null
          status?: string | null
          tax_benefits?: string | null
          termination_date?: string | null
          termination_reason?: string | null
          turnstile_card_number?: string | null
          updated_at?: string | null
          user_id?: string | null
          work_schedule_id?: string | null
        }
        Update: {
          actual_address?: string | null
          additional_phone?: string | null
          attendance_method?: string | null
          avatar_url?: string | null
          bank_account?: string | null
          bank_account_number?: string | null
          bank_code?: string | null
          bank_name?: string | null
          branch_id?: string
          card_number?: string | null
          citizenship_countries?: string[] | null
          comments?: string | null
          created_at?: string | null
          created_by?: string | null
          custom_end_time?: string | null
          custom_start_time?: string | null
          date_of_birth?: string | null
          deleted_at?: string | null
          department?: string | null
          education?: string | null
          education_level?: string | null
          email?: string
          emergency_contact_name?: string | null
          emergency_contact_phone?: string | null
          emergency_contact_relation?: string | null
          employee_comment?: string | null
          employee_number?: string | null
          father_name?: string | null
          foreign_country?: string | null
          full_name?: string
          gender?: string | null
          has_changed_password?: boolean | null
          has_disability?: boolean | null
          has_pension?: boolean | null
          hire_date?: string
          hourly_rate?: number | null
          id?: string
          is_dual_citizen?: boolean | null
          is_intern?: boolean | null
          is_minor?: boolean | null
          is_pension_payer?: boolean | null
          is_pregnant?: boolean | null
          is_probation?: boolean | null
          last_name?: string | null
          lateness_control_enabled?: boolean | null
          legal_address?: string | null
          minimum_wage_compliant?: boolean | null
          office_location_id?: string | null
          pension_account_number?: string | null
          personal_id?: string | null
          personal_id_number?: string | null
          phone?: string | null
          phone_number?: string | null
          position?: string
          previous_experience?: string | null
          probation_months?: number | null
          receive_lateness_sms?: boolean | null
          receive_sms_notifications?: boolean | null
          receive_subordinate_lateness_sms?: boolean | null
          receive_subordinate_sms?: boolean | null
          residency_status?: string | null
          salary?: number | null
          salary_type?: string
          savings?: number | null
          secondary_manager_id?: string | null
          show_door_access_history?: boolean | null
          show_email_on_info_page?: boolean | null
          show_email_on_list?: boolean | null
          show_norm_on_info_page?: boolean | null
          show_phone_on_list?: boolean | null
          show_resignation_date?: boolean | null
          status?: string | null
          tax_benefits?: string | null
          termination_date?: string | null
          termination_reason?: string | null
          turnstile_card_number?: string | null
          updated_at?: string | null
          user_id?: string | null
          work_schedule_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "employees_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employees_office_location_id_fkey"
            columns: ["office_location_id"]
            isOneToOne: false
            referencedRelation: "office_locations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employees_secondary_manager_id_fkey"
            columns: ["secondary_manager_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employees_secondary_manager_id_fkey"
            columns: ["secondary_manager_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employees_secondary_manager_id_fkey"
            columns: ["secondary_manager_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employees_secondary_manager_id_fkey"
            columns: ["secondary_manager_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employees_work_schedule_id_fkey"
            columns: ["work_schedule_id"]
            isOneToOne: false
            referencedRelation: "schedule_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      encrypted_employee_data: {
        Row: {
          created_at: string | null
          employee_id: string
          encrypted_address: string | null
          encrypted_bank_account: string | null
          encrypted_bonus: string | null
          encrypted_email: string | null
          encrypted_pension_amount: string | null
          encrypted_personal_id: string | null
          encrypted_phone: string | null
          encrypted_salary: string | null
          encryption_version: number | null
          id: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          employee_id: string
          encrypted_address?: string | null
          encrypted_bank_account?: string | null
          encrypted_bonus?: string | null
          encrypted_email?: string | null
          encrypted_pension_amount?: string | null
          encrypted_personal_id?: string | null
          encrypted_phone?: string | null
          encrypted_salary?: string | null
          encryption_version?: number | null
          id?: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          employee_id?: string
          encrypted_address?: string | null
          encrypted_bank_account?: string | null
          encrypted_bonus?: string | null
          encrypted_email?: string | null
          encrypted_pension_amount?: string | null
          encrypted_personal_id?: string | null
          encrypted_phone?: string | null
          encrypted_salary?: string | null
          encryption_version?: number | null
          id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "encrypted_employee_data_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: true
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "encrypted_employee_data_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: true
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "encrypted_employee_data_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: true
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "encrypted_employee_data_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: true
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      encryption_access_log: {
        Row: {
          access_type: string
          accessed_fields: string[] | null
          created_at: string | null
          employee_id: string | null
          id: string
          ip_address: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          access_type: string
          accessed_fields?: string[] | null
          created_at?: string | null
          employee_id?: string | null
          id?: string
          ip_address?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          access_type?: string
          accessed_fields?: string[] | null
          created_at?: string | null
          employee_id?: string | null
          id?: string
          ip_address?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "encryption_access_log_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "encryption_access_log_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "encryption_access_log_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "encryption_access_log_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      enterprise_inquiries: {
        Row: {
          company_name: string
          contact_person: string
          created_at: string
          email: string
          employee_count: string
          id: string
          message: string | null
          phone: string | null
          status: string
          updated_at: string
        }
        Insert: {
          company_name: string
          contact_person: string
          created_at?: string
          email: string
          employee_count: string
          id?: string
          message?: string | null
          phone?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          company_name?: string
          contact_person?: string
          created_at?: string
          email?: string
          employee_count?: string
          id?: string
          message?: string | null
          phone?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      esim_plans: {
        Row: {
          country: string | null
          created_at: string | null
          currency: string
          data_gb: number
          description: string | null
          id: string
          is_active: boolean | null
          price: number
          region: string
          updated_at: string | null
          validity_days: number
        }
        Insert: {
          country?: string | null
          created_at?: string | null
          currency?: string
          data_gb: number
          description?: string | null
          id?: string
          is_active?: boolean | null
          price: number
          region: string
          updated_at?: string | null
          validity_days: number
        }
        Update: {
          country?: string | null
          created_at?: string | null
          currency?: string
          data_gb?: number
          description?: string | null
          id?: string
          is_active?: boolean | null
          price?: number
          region?: string
          updated_at?: string | null
          validity_days?: number
        }
        Relationships: []
      }
      esim_requests: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string | null
          employee_id: string
          id: string
          notes: string | null
          plan_id: string
          rejection_reason: string | null
          status: string
          trip_id: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string | null
          employee_id: string
          id?: string
          notes?: string | null
          plan_id: string
          rejection_reason?: string | null
          status?: string
          trip_id: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string | null
          employee_id?: string
          id?: string
          notes?: string | null
          plan_id?: string
          rejection_reason?: string | null
          status?: string
          trip_id?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "esim_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "esim_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "esim_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "esim_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "esim_requests_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "esim_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "esim_requests_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "business_trip_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          event_date: string
          event_type: string
          id: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          event_date: string
          event_type: string
          id?: string
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          event_date?: string
          event_type?: string
          id?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      expense_categories: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          is_active: boolean | null
          max_amount: number | null
          name: string
          name_ka: string | null
          requires_receipt: boolean | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          max_amount?: number | null
          name: string
          name_ka?: string | null
          requires_receipt?: boolean | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          max_amount?: number | null
          name?: string
          name_ka?: string | null
          requires_receipt?: boolean | null
        }
        Relationships: []
      }
      expense_requests: {
        Row: {
          amount: number
          branch_id: string
          business_purpose: string | null
          category_id: string | null
          created_at: string | null
          currency: string | null
          description: string
          employee_id: string | null
          expense_date: string
          id: string
          paid_at: string | null
          receipt_url: string | null
          review_notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string | null
          submitted_at: string | null
          updated_at: string | null
        }
        Insert: {
          amount: number
          branch_id?: string
          business_purpose?: string | null
          category_id?: string | null
          created_at?: string | null
          currency?: string | null
          description: string
          employee_id?: string | null
          expense_date: string
          id?: string
          paid_at?: string | null
          receipt_url?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
          submitted_at?: string | null
          updated_at?: string | null
        }
        Update: {
          amount?: number
          branch_id?: string
          business_purpose?: string | null
          category_id?: string | null
          created_at?: string | null
          currency?: string | null
          description?: string
          employee_id?: string | null
          expense_date?: string
          id?: string
          paid_at?: string | null
          receipt_url?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
          submitted_at?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "expense_requests_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expense_requests_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "expense_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expense_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expense_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expense_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expense_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expense_requests_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expense_requests_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expense_requests_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expense_requests_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      feature_definitions: {
        Row: {
          category: string
          created_at: string | null
          description: string | null
          feature_key: string
          id: string
          name: string
          name_ka: string
          package_id: string | null
          sort_order: number | null
        }
        Insert: {
          category?: string
          created_at?: string | null
          description?: string | null
          feature_key: string
          id?: string
          name: string
          name_ka: string
          package_id?: string | null
          sort_order?: number | null
        }
        Update: {
          category?: string
          created_at?: string | null
          description?: string | null
          feature_key?: string
          id?: string
          name?: string
          name_ka?: string
          package_id?: string | null
          sort_order?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "feature_definitions_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "feature_packages"
            referencedColumns: ["id"]
          },
        ]
      }
      feature_packages: {
        Row: {
          color: string | null
          created_at: string | null
          description: string | null
          description_ka: string | null
          icon: string | null
          id: string
          is_active: boolean | null
          name: string
          name_ka: string
          price_monthly: number | null
          price_yearly: number | null
          sort_order: number | null
          updated_at: string | null
        }
        Insert: {
          color?: string | null
          created_at?: string | null
          description?: string | null
          description_ka?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          name_ka: string
          price_monthly?: number | null
          price_yearly?: number | null
          sort_order?: number | null
          updated_at?: string | null
        }
        Update: {
          color?: string | null
          created_at?: string | null
          description?: string | null
          description_ka?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          name_ka?: string
          price_monthly?: number | null
          price_yearly?: number | null
          sort_order?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      herio_candidates: {
        Row: {
          applied_at: string | null
          arrived_at: string | null
          confirmed_at: string | null
          created_at: string
          feedback_text: string | null
          full_name: string | null
          herio_candidate_id: string
          herio_job_id: string
          id: string
          last_synced_at: string
          phone: string | null
          photo_url: string | null
          rating: number | null
          raw_data: Json | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          applied_at?: string | null
          arrived_at?: string | null
          confirmed_at?: string | null
          created_at?: string
          feedback_text?: string | null
          full_name?: string | null
          herio_candidate_id: string
          herio_job_id: string
          id?: string
          last_synced_at?: string
          phone?: string | null
          photo_url?: string | null
          rating?: number | null
          raw_data?: Json | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          applied_at?: string | null
          arrived_at?: string | null
          confirmed_at?: string | null
          created_at?: string
          feedback_text?: string | null
          full_name?: string | null
          herio_candidate_id?: string
          herio_job_id?: string
          id?: string
          last_synced_at?: string
          phone?: string | null
          photo_url?: string | null
          rating?: number | null
          raw_data?: Json | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      herio_jobs: {
        Row: {
          created_at: string
          description: string | null
          end_date: string | null
          filled_count: number | null
          herio_job_id: string
          hourly_rate: number | null
          id: string
          job_type: string
          last_synced_at: string
          latitude: number | null
          location_name: string | null
          longitude: number | null
          raw_data: Json | null
          required_count: number | null
          start_date: string | null
          status: string
          title: string | null
          total_payment: number | null
          updated_at: string
          user_id: string
          vacancy_id: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          end_date?: string | null
          filled_count?: number | null
          herio_job_id: string
          hourly_rate?: number | null
          id?: string
          job_type?: string
          last_synced_at?: string
          latitude?: number | null
          location_name?: string | null
          longitude?: number | null
          raw_data?: Json | null
          required_count?: number | null
          start_date?: string | null
          status?: string
          title?: string | null
          total_payment?: number | null
          updated_at?: string
          user_id: string
          vacancy_id?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          end_date?: string | null
          filled_count?: number | null
          herio_job_id?: string
          hourly_rate?: number | null
          id?: string
          job_type?: string
          last_synced_at?: string
          latitude?: number | null
          location_name?: string | null
          longitude?: number | null
          raw_data?: Json | null
          required_count?: number | null
          start_date?: string | null
          status?: string
          title?: string | null
          total_payment?: number | null
          updated_at?: string
          user_id?: string
          vacancy_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "herio_jobs_vacancy_id_fkey"
            columns: ["vacancy_id"]
            isOneToOne: false
            referencedRelation: "job_vacancies"
            referencedColumns: ["id"]
          },
        ]
      }
      herio_sync_log: {
        Row: {
          created_at: string
          duration_ms: number | null
          endpoint: string
          error_message: string | null
          id: string
          method: string
          request_body: Json | null
          response_body: Json | null
          status_code: number | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          duration_ms?: number | null
          endpoint: string
          error_message?: string | null
          id?: string
          method: string
          request_body?: Json | null
          response_body?: Json | null
          status_code?: number | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          duration_ms?: number | null
          endpoint?: string
          error_message?: string | null
          id?: string
          method?: string
          request_body?: Json | null
          response_body?: Json | null
          status_code?: number | null
          user_id?: string | null
        }
        Relationships: []
      }
      herio_user_credentials: {
        Row: {
          created_at: string
          email: string
          herio_user_id: string | null
          id: string
          is_active: boolean
          last_error: string | null
          last_login_at: string | null
          password_encrypted: string
          password_iv: string
          token: string | null
          token_expires_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          email: string
          herio_user_id?: string | null
          id?: string
          is_active?: boolean
          last_error?: string | null
          last_login_at?: string | null
          password_encrypted: string
          password_iv: string
          token?: string | null
          token_expires_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          email?: string
          herio_user_id?: string | null
          id?: string
          is_active?: boolean
          last_error?: string | null
          last_login_at?: string | null
          password_encrypted?: string
          password_iv?: string
          token?: string | null
          token_expires_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      insurance_companies: {
        Row: {
          accident_insurance: boolean | null
          address: string | null
          company_name: string
          company_type: string
          copay_percent: number | null
          created_at: string | null
          created_by: string | null
          dental_coverage: boolean | null
          description: string | null
          email: string | null
          group_discount_percent: number | null
          has_international_coverage: boolean | null
          health_coverage: boolean | null
          id: string
          is_active: boolean | null
          is_recommended: boolean | null
          life_insurance: boolean | null
          logo_url: string | null
          max_coverage_amount: number | null
          max_monthly_premium: number | null
          min_contract_months: number | null
          min_monthly_premium: number | null
          notes: string | null
          partner_clinics_count: number | null
          phone: string | null
          rating: number | null
          travel_insurance: boolean | null
          updated_at: string | null
          vision_coverage: boolean | null
          waiting_period_days: number | null
          website: string | null
        }
        Insert: {
          accident_insurance?: boolean | null
          address?: string | null
          company_name: string
          company_type?: string
          copay_percent?: number | null
          created_at?: string | null
          created_by?: string | null
          dental_coverage?: boolean | null
          description?: string | null
          email?: string | null
          group_discount_percent?: number | null
          has_international_coverage?: boolean | null
          health_coverage?: boolean | null
          id?: string
          is_active?: boolean | null
          is_recommended?: boolean | null
          life_insurance?: boolean | null
          logo_url?: string | null
          max_coverage_amount?: number | null
          max_monthly_premium?: number | null
          min_contract_months?: number | null
          min_monthly_premium?: number | null
          notes?: string | null
          partner_clinics_count?: number | null
          phone?: string | null
          rating?: number | null
          travel_insurance?: boolean | null
          updated_at?: string | null
          vision_coverage?: boolean | null
          waiting_period_days?: number | null
          website?: string | null
        }
        Update: {
          accident_insurance?: boolean | null
          address?: string | null
          company_name?: string
          company_type?: string
          copay_percent?: number | null
          created_at?: string | null
          created_by?: string | null
          dental_coverage?: boolean | null
          description?: string | null
          email?: string | null
          group_discount_percent?: number | null
          has_international_coverage?: boolean | null
          health_coverage?: boolean | null
          id?: string
          is_active?: boolean | null
          is_recommended?: boolean | null
          life_insurance?: boolean | null
          logo_url?: string | null
          max_coverage_amount?: number | null
          max_monthly_premium?: number | null
          min_contract_months?: number | null
          min_monthly_premium?: number | null
          notes?: string | null
          partner_clinics_count?: number | null
          phone?: string | null
          rating?: number | null
          travel_insurance?: boolean | null
          updated_at?: string | null
          vision_coverage?: boolean | null
          waiting_period_days?: number | null
          website?: string | null
        }
        Relationships: []
      }
      integration_settings: {
        Row: {
          client_id: string | null
          client_secret: string | null
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean
          provider: string
          settings: Json | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          client_id?: string | null
          client_secret?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          provider: string
          settings?: Json | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          client_id?: string | null
          client_secret?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          provider?: string
          settings?: Json | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      job_board_postings: {
        Row: {
          board_name: string
          board_url: string | null
          branch_id: string
          created_at: string
          created_by: string | null
          external_url: string | null
          id: string
          notes: string | null
          posted_at: string | null
          status: string
          updated_at: string
          vacancy_id: string
        }
        Insert: {
          board_name: string
          board_url?: string | null
          branch_id?: string
          created_at?: string
          created_by?: string | null
          external_url?: string | null
          id?: string
          notes?: string | null
          posted_at?: string | null
          status?: string
          updated_at?: string
          vacancy_id: string
        }
        Update: {
          board_name?: string
          board_url?: string | null
          branch_id?: string
          created_at?: string
          created_by?: string | null
          external_url?: string | null
          id?: string
          notes?: string | null
          posted_at?: string | null
          status?: string
          updated_at?: string
          vacancy_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_board_postings_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      job_descriptions: {
        Row: {
          branch_id: string
          created_at: string
          education_level: string | null
          employment_type: string
          experience_years: number | null
          id: string
          is_active: boolean
          language_requirements: string | null
          position_id: string | null
          qualifications: string | null
          requirements: string
          responsibilities: string
          salary_range_max: number | null
          salary_range_min: number | null
          skills: string | null
          summary: string | null
          title: string
          updated_at: string
          version: number
          working_conditions: string | null
        }
        Insert: {
          branch_id?: string
          created_at?: string
          education_level?: string | null
          employment_type?: string
          experience_years?: number | null
          id?: string
          is_active?: boolean
          language_requirements?: string | null
          position_id?: string | null
          qualifications?: string | null
          requirements: string
          responsibilities: string
          salary_range_max?: number | null
          salary_range_min?: number | null
          skills?: string | null
          summary?: string | null
          title: string
          updated_at?: string
          version?: number
          working_conditions?: string | null
        }
        Update: {
          branch_id?: string
          created_at?: string
          education_level?: string | null
          employment_type?: string
          experience_years?: number | null
          id?: string
          is_active?: boolean
          language_requirements?: string | null
          position_id?: string | null
          qualifications?: string | null
          requirements?: string
          responsibilities?: string
          salary_range_max?: number | null
          salary_range_min?: number | null
          skills?: string | null
          summary?: string | null
          title?: string
          updated_at?: string
          version?: number
          working_conditions?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "job_descriptions_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_descriptions_position_id_fkey"
            columns: ["position_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      job_vacancies: {
        Row: {
          ad_budget: number | null
          branch_id: string
          closed_date: string | null
          created_at: string | null
          created_by: string | null
          department_id: string | null
          description: string | null
          employment_type: string
          experience_level: string | null
          external_talentos_id: string | null
          filled_date: string | null
          id: string
          location: string | null
          opened_date: string | null
          openings_count: number | null
          position_id: string | null
          remote_option: boolean | null
          requirements: string | null
          salary_max: number | null
          salary_min: number | null
          social_media_budget: number | null
          status: string | null
          talentos_sync_error: string | null
          talentos_sync_status: string | null
          talentos_synced_at: string | null
          title: string
          total_spent: number | null
          updated_at: string | null
        }
        Insert: {
          ad_budget?: number | null
          branch_id?: string
          closed_date?: string | null
          created_at?: string | null
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          employment_type?: string
          experience_level?: string | null
          external_talentos_id?: string | null
          filled_date?: string | null
          id?: string
          location?: string | null
          opened_date?: string | null
          openings_count?: number | null
          position_id?: string | null
          remote_option?: boolean | null
          requirements?: string | null
          salary_max?: number | null
          salary_min?: number | null
          social_media_budget?: number | null
          status?: string | null
          talentos_sync_error?: string | null
          talentos_sync_status?: string | null
          talentos_synced_at?: string | null
          title: string
          total_spent?: number | null
          updated_at?: string | null
        }
        Update: {
          ad_budget?: number | null
          branch_id?: string
          closed_date?: string | null
          created_at?: string | null
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          employment_type?: string
          experience_level?: string | null
          external_talentos_id?: string | null
          filled_date?: string | null
          id?: string
          location?: string | null
          opened_date?: string | null
          openings_count?: number | null
          position_id?: string | null
          remote_option?: boolean | null
          requirements?: string | null
          salary_max?: number | null
          salary_min?: number | null
          social_media_budget?: number | null
          status?: string | null
          talentos_sync_error?: string | null
          talentos_sync_status?: string | null
          talentos_synced_at?: string | null
          title?: string
          total_spent?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "job_vacancies_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_vacancies_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_vacancies_position_id_fkey"
            columns: ["position_id"]
            isOneToOne: false
            referencedRelation: "positions"
            referencedColumns: ["id"]
          },
        ]
      }
      key_results: {
        Row: {
          created_at: string
          created_by: string | null
          current_value: number
          description: string | null
          id: string
          metric_type: string
          objective_id: string
          owner_id: string | null
          status: string
          target_value: number
          title: string
          unit: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          current_value?: number
          description?: string | null
          id?: string
          metric_type?: string
          objective_id: string
          owner_id?: string | null
          status?: string
          target_value: number
          title: string
          unit?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          current_value?: number
          description?: string | null
          id?: string
          metric_type?: string
          objective_id?: string
          owner_id?: string | null
          status?: string
          target_value?: number
          title?: string
          unit?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "key_results_objective_id_fkey"
            columns: ["objective_id"]
            isOneToOne: false
            referencedRelation: "objectives"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_base: {
        Row: {
          category: string
          content: string
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean
          language: string
          search_vector: unknown
          source: string | null
          source_wiki_page_id: string | null
          subcategory: string | null
          tags: string[] | null
          title: string
          updated_at: string
        }
        Insert: {
          category?: string
          content: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          language?: string
          search_vector?: unknown
          source?: string | null
          source_wiki_page_id?: string | null
          subcategory?: string | null
          tags?: string[] | null
          title: string
          updated_at?: string
        }
        Update: {
          category?: string
          content?: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          language?: string
          search_vector?: unknown
          source?: string | null
          source_wiki_page_id?: string | null
          subcategory?: string | null
          tags?: string[] | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_base_source_wiki_page_id_fkey"
            columns: ["source_wiki_page_id"]
            isOneToOne: true
            referencedRelation: "wiki_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      lateness_records: {
        Row: {
          actual_time: string
          approved_by: string | null
          branch_id: string
          created_at: string
          date: string
          employee_id: string
          id: string
          minutes_late: number
          notes: string | null
          reason: string | null
          scheduled_time: string
          updated_at: string
        }
        Insert: {
          actual_time: string
          approved_by?: string | null
          branch_id?: string
          created_at?: string
          date: string
          employee_id: string
          id?: string
          minutes_late: number
          notes?: string | null
          reason?: string | null
          scheduled_time: string
          updated_at?: string
        }
        Update: {
          actual_time?: string
          approved_by?: string | null
          branch_id?: string
          created_at?: string
          date?: string
          employee_id?: string
          id?: string
          minutes_late?: number
          notes?: string | null
          reason?: string | null
          scheduled_time?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lateness_records_approved_by_fkey"
            columns: ["approved_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lateness_records_approved_by_fkey"
            columns: ["approved_by"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lateness_records_approved_by_fkey"
            columns: ["approved_by"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lateness_records_approved_by_fkey"
            columns: ["approved_by"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lateness_records_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lateness_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lateness_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lateness_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lateness_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      leave_requests: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          branch_id: string
          created_at: string
          custom_fields: Json | null
          deleted_at: string | null
          document_file_name: string | null
          document_url: string | null
          employee_id: string
          end_date: string
          id: string
          leave_type: string
          leave_type_id: string | null
          manager_id: string | null
          reason: string | null
          replacement_employee_id: string | null
          sick_leave_certificate_number: string | null
          sick_leave_compensation_percentage: number | null
          sick_leave_end_date: string | null
          sick_leave_issue_date: string | null
          sick_leave_start_date: string | null
          start_date: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          branch_id?: string
          created_at?: string
          custom_fields?: Json | null
          deleted_at?: string | null
          document_file_name?: string | null
          document_url?: string | null
          employee_id: string
          end_date: string
          id?: string
          leave_type: string
          leave_type_id?: string | null
          manager_id?: string | null
          reason?: string | null
          replacement_employee_id?: string | null
          sick_leave_certificate_number?: string | null
          sick_leave_compensation_percentage?: number | null
          sick_leave_end_date?: string | null
          sick_leave_issue_date?: string | null
          sick_leave_start_date?: string | null
          start_date: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          branch_id?: string
          created_at?: string
          custom_fields?: Json | null
          deleted_at?: string | null
          document_file_name?: string | null
          document_url?: string | null
          employee_id?: string
          end_date?: string
          id?: string
          leave_type?: string
          leave_type_id?: string | null
          manager_id?: string | null
          reason?: string | null
          replacement_employee_id?: string | null
          sick_leave_certificate_number?: string | null
          sick_leave_compensation_percentage?: number | null
          sick_leave_end_date?: string | null
          sick_leave_issue_date?: string | null
          sick_leave_start_date?: string | null
          start_date?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "leave_requests_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_leave_type_id_fkey"
            columns: ["leave_type_id"]
            isOneToOne: false
            referencedRelation: "leave_types"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_replacement_employee_id_fkey"
            columns: ["replacement_employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_replacement_employee_id_fkey"
            columns: ["replacement_employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_replacement_employee_id_fkey"
            columns: ["replacement_employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_replacement_employee_id_fkey"
            columns: ["replacement_employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      leave_types: {
        Row: {
          approver_role: Database["public"]["Enums"]["app_role"] | null
          color: string | null
          created_at: string
          created_by: string | null
          days_allowed: number
          description: string | null
          id: string
          is_active: boolean
          is_paid: boolean
          name: string
          name_en: string | null
          requires_approval: boolean
          updated_at: string
        }
        Insert: {
          approver_role?: Database["public"]["Enums"]["app_role"] | null
          color?: string | null
          created_at?: string
          created_by?: string | null
          days_allowed?: number
          description?: string | null
          id?: string
          is_active?: boolean
          is_paid?: boolean
          name: string
          name_en?: string | null
          requires_approval?: boolean
          updated_at?: string
        }
        Update: {
          approver_role?: Database["public"]["Enums"]["app_role"] | null
          color?: string | null
          created_at?: string
          created_by?: string | null
          days_allowed?: number
          description?: string | null
          id?: string
          is_active?: boolean
          is_paid?: boolean
          name?: string
          name_en?: string | null
          requires_approval?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      load_test_runs: {
        Row: {
          created_at: string
          created_by: string
          db_after: Json | null
          db_before: Json | null
          duration_sec: number
          failed_requests: number
          id: string
          max_ms: number | null
          p50_ms: number | null
          p95_ms: number | null
          p99_ms: number | null
          rps: number
          stopped_early: boolean
          total_requests: number
          verdict: string
          virtual_users: number
        }
        Insert: {
          created_at?: string
          created_by: string
          db_after?: Json | null
          db_before?: Json | null
          duration_sec: number
          failed_requests?: number
          id?: string
          max_ms?: number | null
          p50_ms?: number | null
          p95_ms?: number | null
          p99_ms?: number | null
          rps?: number
          stopped_early?: boolean
          total_requests?: number
          verdict: string
          virtual_users: number
        }
        Update: {
          created_at?: string
          created_by?: string
          db_after?: Json | null
          db_before?: Json | null
          duration_sec?: number
          failed_requests?: number
          id?: string
          max_ms?: number | null
          p50_ms?: number | null
          p95_ms?: number | null
          p99_ms?: number | null
          rps?: number
          stopped_early?: boolean
          total_requests?: number
          verdict?: string
          virtual_users?: number
        }
        Relationships: []
      }
      location_alerts: {
        Row: {
          actual_location: string | null
          attendance_id: string | null
          created_at: string
          distance_meters: number | null
          employee_id: string | null
          expected_location: string | null
          id: string
          review_notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string | null
        }
        Insert: {
          actual_location?: string | null
          attendance_id?: string | null
          created_at?: string
          distance_meters?: number | null
          employee_id?: string | null
          expected_location?: string | null
          id?: string
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
        }
        Update: {
          actual_location?: string | null
          attendance_id?: string | null
          created_at?: string
          distance_meters?: number | null
          employee_id?: string | null
          expected_location?: string | null
          id?: string
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "location_alerts_attendance_id_fkey"
            columns: ["attendance_id"]
            isOneToOne: false
            referencedRelation: "attendance"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "location_alerts_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "location_alerts_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "location_alerts_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "location_alerts_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      login_attempts: {
        Row: {
          attempt_time: string
          email: string
          failure_reason: string | null
          id: string
          ip_address: string | null
          success: boolean
          user_agent: string | null
        }
        Insert: {
          attempt_time?: string
          email: string
          failure_reason?: string | null
          id?: string
          ip_address?: string | null
          success: boolean
          user_agent?: string | null
        }
        Update: {
          attempt_time?: string
          email?: string
          failure_reason?: string | null
          id?: string
          ip_address?: string | null
          success?: boolean
          user_agent?: string | null
        }
        Relationships: []
      }
      login_history: {
        Row: {
          anomaly_reason: string | null
          city: string | null
          country: string | null
          created_at: string | null
          email: string
          id: string
          ip_address: string | null
          is_suspicious: boolean | null
          login_at: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          anomaly_reason?: string | null
          city?: string | null
          country?: string | null
          created_at?: string | null
          email: string
          id?: string
          ip_address?: string | null
          is_suspicious?: boolean | null
          login_at?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          anomaly_reason?: string | null
          city?: string | null
          country?: string | null
          created_at?: string | null
          email?: string
          id?: string
          ip_address?: string | null
          is_suspicious?: boolean | null
          login_at?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      medical_checkups: {
        Row: {
          certificate_number: string | null
          checkup_date: string
          checkup_type: string
          created_at: string
          created_by: string | null
          doctor_name: string | null
          employee_id: string
          id: string
          is_valid: boolean | null
          medical_institution: string | null
          next_checkup_date: string | null
          notes: string | null
          restrictions: string | null
          result: string | null
          updated_at: string
        }
        Insert: {
          certificate_number?: string | null
          checkup_date: string
          checkup_type?: string
          created_at?: string
          created_by?: string | null
          doctor_name?: string | null
          employee_id: string
          id?: string
          is_valid?: boolean | null
          medical_institution?: string | null
          next_checkup_date?: string | null
          notes?: string | null
          restrictions?: string | null
          result?: string | null
          updated_at?: string
        }
        Update: {
          certificate_number?: string | null
          checkup_date?: string
          checkup_type?: string
          created_at?: string
          created_by?: string | null
          doctor_name?: string | null
          employee_id?: string
          id?: string
          is_valid?: boolean | null
          medical_institution?: string | null
          next_checkup_date?: string | null
          notes?: string | null
          restrictions?: string | null
          result?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "medical_checkups_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medical_checkups_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medical_checkups_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medical_checkups_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string
          created_by: string | null
          employee_ids: string[] | null
          expires_at: string | null
          id: string
          is_read: boolean
          link: string | null
          message: string
          sms_enabled: boolean | null
          sms_sent: boolean | null
          sms_sent_at: string | null
          target_audience: string
          title: string
          type: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          employee_ids?: string[] | null
          expires_at?: string | null
          id?: string
          is_read?: boolean
          link?: string | null
          message: string
          sms_enabled?: boolean | null
          sms_sent?: boolean | null
          sms_sent_at?: string | null
          target_audience?: string
          title: string
          type?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          employee_ids?: string[] | null
          expires_at?: string | null
          id?: string
          is_read?: boolean
          link?: string | null
          message?: string
          sms_enabled?: boolean | null
          sms_sent?: boolean | null
          sms_sent_at?: string | null
          target_audience?: string
          title?: string
          type?: string
          user_id?: string | null
        }
        Relationships: []
      }
      objectives: {
        Row: {
          branch_id: string
          created_at: string
          created_by: string | null
          department_id: string | null
          description: string | null
          end_date: string
          fiscal_quarter: number | null
          fiscal_year: number
          id: string
          objective_type: string
          owner_id: string | null
          progress: number
          start_date: string
          status: string
          time_period: string
          title: string
          updated_at: string
        }
        Insert: {
          branch_id?: string
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          end_date: string
          fiscal_quarter?: number | null
          fiscal_year: number
          id?: string
          objective_type?: string
          owner_id?: string | null
          progress?: number
          start_date: string
          status?: string
          time_period?: string
          title: string
          updated_at?: string
        }
        Update: {
          branch_id?: string
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          end_date?: string
          fiscal_quarter?: number | null
          fiscal_year?: number
          id?: string
          objective_type?: string
          owner_id?: string | null
          progress?: number
          start_date?: string
          status?: string
          time_period?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "objectives_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "objectives_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      offboarding_processes: {
        Row: {
          completed_at: string | null
          created_at: string
          created_by: string | null
          employee_id: string
          id: string
          last_day: string
          notes: string | null
          reason: string | null
          status: string
          template_id: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          employee_id: string
          id?: string
          last_day: string
          notes?: string | null
          reason?: string | null
          status?: string
          template_id?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          employee_id?: string
          id?: string
          last_day?: string
          notes?: string | null
          reason?: string | null
          status?: string
          template_id?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "offboarding_processes_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "offboarding_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      offboarding_tasks: {
        Row: {
          assignee_id: string | null
          category: string
          completed_at: string | null
          completed_by: string | null
          created_at: string
          description: string | null
          due_date: string | null
          id: string
          notes: string | null
          order_index: number
          process_id: string
          status: string
          title: string
        }
        Insert: {
          assignee_id?: string | null
          category: string
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          notes?: string | null
          order_index?: number
          process_id: string
          status?: string
          title: string
        }
        Update: {
          assignee_id?: string | null
          category?: string
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          notes?: string | null
          order_index?: number
          process_id?: string
          status?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "offboarding_tasks_process_id_fkey"
            columns: ["process_id"]
            isOneToOne: false
            referencedRelation: "offboarding_processes"
            referencedColumns: ["id"]
          },
        ]
      }
      offboarding_templates: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_default: boolean
          name: string
          tasks: Json
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_default?: boolean
          name: string
          tasks?: Json
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_default?: boolean
          name?: string
          tasks?: Json
        }
        Relationships: []
      }
      office_locations: {
        Row: {
          address: string | null
          created_at: string
          id: string
          is_active: boolean | null
          latitude: number
          longitude: number
          name: string
          radius_meters: number
          updated_at: string
        }
        Insert: {
          address?: string | null
          created_at?: string
          id?: string
          is_active?: boolean | null
          latitude: number
          longitude: number
          name: string
          radius_meters?: number
          updated_at?: string
        }
        Update: {
          address?: string | null
          created_at?: string
          id?: string
          is_active?: boolean | null
          latitude?: number
          longitude?: number
          name?: string
          radius_meters?: number
          updated_at?: string
        }
        Relationships: []
      }
      onboarding_task_completion: {
        Row: {
          completed_at: string | null
          completed_by: string | null
          created_at: string | null
          due_date: string | null
          employee_id: string | null
          id: string
          notes: string | null
          onboarding_id: string | null
          status: string | null
          task_id: string | null
        }
        Insert: {
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string | null
          due_date?: string | null
          employee_id?: string | null
          id?: string
          notes?: string | null
          onboarding_id?: string | null
          status?: string | null
          task_id?: string | null
        }
        Update: {
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string | null
          due_date?: string | null
          employee_id?: string | null
          id?: string
          notes?: string | null
          onboarding_id?: string | null
          status?: string | null
          task_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "onboarding_task_completion_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "onboarding_task_completion_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "onboarding_task_completion_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "onboarding_task_completion_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "onboarding_task_completion_onboarding_id_fkey"
            columns: ["onboarding_id"]
            isOneToOne: false
            referencedRelation: "employee_onboarding"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "onboarding_task_completion_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "onboarding_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      onboarding_tasks: {
        Row: {
          assigned_to_role: string | null
          created_at: string | null
          description: string | null
          due_days: number
          id: string
          is_mandatory: boolean | null
          order_index: number | null
          task_type: string
          template_id: string | null
          title: string
        }
        Insert: {
          assigned_to_role?: string | null
          created_at?: string | null
          description?: string | null
          due_days: number
          id?: string
          is_mandatory?: boolean | null
          order_index?: number | null
          task_type: string
          template_id?: string | null
          title: string
        }
        Update: {
          assigned_to_role?: string | null
          created_at?: string | null
          description?: string | null
          due_days?: number
          id?: string
          is_mandatory?: boolean | null
          order_index?: number | null
          task_type?: string
          template_id?: string | null
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "onboarding_tasks_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "onboarding_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      onboarding_templates: {
        Row: {
          created_at: string | null
          created_by: string | null
          description: string | null
          duration_days: number | null
          id: string
          is_active: boolean | null
          name: string
          position_type: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          duration_days?: number | null
          id?: string
          is_active?: boolean | null
          name: string
          position_type?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          duration_days?: number | null
          id?: string
          is_active?: boolean | null
          name?: string
          position_type?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      organization_info: {
        Row: {
          created_at: string | null
          created_by: string | null
          id: string
          identification_code: string | null
          organization_name: string
          structural_unit: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          id?: string
          identification_code?: string | null
          organization_name: string
          structural_unit?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          id?: string
          identification_code?: string | null
          organization_name?: string
          structural_unit?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      overtime_requests: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          branch_id: string
          created_at: string
          employee_id: string
          end_time: string
          hours: number
          id: string
          manager_id: string | null
          overtime_type: string
          reason: string | null
          start_time: string
          status: string
          updated_at: string
          user_id: string
          work_date: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          branch_id?: string
          created_at?: string
          employee_id: string
          end_time: string
          hours: number
          id?: string
          manager_id?: string | null
          overtime_type: string
          reason?: string | null
          start_time: string
          status?: string
          updated_at?: string
          user_id: string
          work_date: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          branch_id?: string
          created_at?: string
          employee_id?: string
          end_time?: string
          hours?: number
          id?: string
          manager_id?: string | null
          overtime_type?: string
          reason?: string | null
          start_time?: string
          status?: string
          updated_at?: string
          user_id?: string
          work_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "overtime_requests_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "overtime_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "overtime_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "overtime_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "overtime_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      password_history: {
        Row: {
          created_at: string | null
          id: string
          password_hash: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          password_hash: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          password_hash?: string
          user_id?: string
        }
        Relationships: []
      }
      password_policies: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          lockout_duration_minutes: number | null
          max_failed_attempts: number | null
          min_length: number
          password_expiry_days: number | null
          password_history_count: number | null
          require_lowercase: boolean
          require_numbers: boolean
          require_special_chars: boolean
          require_uppercase: boolean
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          lockout_duration_minutes?: number | null
          max_failed_attempts?: number | null
          min_length?: number
          password_expiry_days?: number | null
          password_history_count?: number | null
          require_lowercase?: boolean
          require_numbers?: boolean
          require_special_chars?: boolean
          require_uppercase?: boolean
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          lockout_duration_minutes?: number | null
          max_failed_attempts?: number | null
          min_length?: number
          password_expiry_days?: number | null
          password_history_count?: number | null
          require_lowercase?: boolean
          require_numbers?: boolean
          require_special_chars?: boolean
          require_uppercase?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      payroll: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          base_salary: number
          bonuses: number | null
          branch_id: string
          created_at: string
          created_by: string | null
          deductions: number | null
          employee_id: string
          gross_salary: number | null
          holiday_overtime_hours: number | null
          id: string
          is_retroactive: boolean
          month: number
          net_salary: number
          notes: string | null
          overtime_hours: number | null
          paid_at: string | null
          payment_date: string | null
          rejection_reason: string | null
          retroactive_period_end: string | null
          retroactive_period_start: string | null
          retroactive_reason: string | null
          status: string
          updated_at: string
          year: number
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          base_salary: number
          bonuses?: number | null
          branch_id?: string
          created_at?: string
          created_by?: string | null
          deductions?: number | null
          employee_id: string
          gross_salary?: number | null
          holiday_overtime_hours?: number | null
          id?: string
          is_retroactive?: boolean
          month: number
          net_salary: number
          notes?: string | null
          overtime_hours?: number | null
          paid_at?: string | null
          payment_date?: string | null
          rejection_reason?: string | null
          retroactive_period_end?: string | null
          retroactive_period_start?: string | null
          retroactive_reason?: string | null
          status?: string
          updated_at?: string
          year: number
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          base_salary?: number
          bonuses?: number | null
          branch_id?: string
          created_at?: string
          created_by?: string | null
          deductions?: number | null
          employee_id?: string
          gross_salary?: number | null
          holiday_overtime_hours?: number | null
          id?: string
          is_retroactive?: boolean
          month?: number
          net_salary?: number
          notes?: string | null
          overtime_hours?: number | null
          paid_at?: string | null
          payment_date?: string | null
          rejection_reason?: string | null
          retroactive_period_end?: string | null
          retroactive_period_start?: string | null
          retroactive_reason?: string | null
          status?: string
          updated_at?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "payroll_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      payroll_components: {
        Row: {
          applies_to_all: boolean
          calculation_type: string
          component_type: string
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_active: boolean
          is_recurring: boolean
          is_taxable: boolean
          name: string
          name_en: string | null
          updated_at: string
        }
        Insert: {
          applies_to_all?: boolean
          calculation_type: string
          component_type: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          is_recurring?: boolean
          is_taxable?: boolean
          name: string
          name_en?: string | null
          updated_at?: string
        }
        Update: {
          applies_to_all?: boolean
          calculation_type?: string
          component_type?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          is_recurring?: boolean
          is_taxable?: boolean
          name?: string
          name_en?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      payroll_details: {
        Row: {
          amount: number
          branch_id: string
          component_id: string
          created_at: string
          hours: number | null
          id: string
          notes: string | null
          payroll_id: string
        }
        Insert: {
          amount: number
          branch_id?: string
          component_id: string
          created_at?: string
          hours?: number | null
          id?: string
          notes?: string | null
          payroll_id: string
        }
        Update: {
          amount?: number
          branch_id?: string
          component_id?: string
          created_at?: string
          hours?: number | null
          id?: string
          notes?: string | null
          payroll_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payroll_details_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_details_component_id_fkey"
            columns: ["component_id"]
            isOneToOne: false
            referencedRelation: "payroll_components"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payroll_details_payroll_id_fkey"
            columns: ["payroll_id"]
            isOneToOne: false
            referencedRelation: "payroll"
            referencedColumns: ["id"]
          },
        ]
      }
      payroll_runs: {
        Row: {
          branch_id: string
          completed_at: string | null
          created_at: string
          duration_ms: number | null
          error_message: string | null
          id: string
          month: number
          records_processed: number
          started_at: string
          status: string
          total_net_amount: number
          triggered_by: string
          triggered_by_user_id: string | null
          year: number
        }
        Insert: {
          branch_id?: string
          completed_at?: string | null
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          id?: string
          month: number
          records_processed?: number
          started_at?: string
          status?: string
          total_net_amount?: number
          triggered_by?: string
          triggered_by_user_id?: string | null
          year: number
        }
        Update: {
          branch_id?: string
          completed_at?: string | null
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          id?: string
          month?: number
          records_processed?: number
          started_at?: string
          status?: string
          total_net_amount?: number
          triggered_by?: string
          triggered_by_user_id?: string | null
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "payroll_runs_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      pension_payments: {
        Row: {
          base_salary: number
          created_at: string
          created_by: string | null
          employee_contribution: number
          employee_id: string
          employer_contribution: number
          id: string
          notes: string | null
          payment_date: string
          payment_reference: string | null
          period_month: number
          period_year: number
          status: string
          total_amount: number | null
          updated_at: string
        }
        Insert: {
          base_salary: number
          created_at?: string
          created_by?: string | null
          employee_contribution?: number
          employee_id: string
          employer_contribution?: number
          id?: string
          notes?: string | null
          payment_date?: string
          payment_reference?: string | null
          period_month: number
          period_year: number
          status?: string
          total_amount?: number | null
          updated_at?: string
        }
        Update: {
          base_salary?: number
          created_at?: string
          created_by?: string | null
          employee_contribution?: number
          employee_id?: string
          employer_contribution?: number
          id?: string
          notes?: string | null
          payment_date?: string
          payment_reference?: string | null
          period_month?: number
          period_year?: number
          status?: string
          total_amount?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "pension_payments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pension_payments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pension_payments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pension_payments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      per_diem_rates: {
        Row: {
          city: string | null
          country: string
          created_at: string
          currency: string
          daily_rate: number
          id: string
          is_active: boolean
          notes: string | null
          updated_at: string
        }
        Insert: {
          city?: string | null
          country?: string
          created_at?: string
          currency?: string
          daily_rate: number
          id?: string
          is_active?: boolean
          notes?: string | null
          updated_at?: string
        }
        Update: {
          city?: string | null
          country?: string
          created_at?: string
          currency?: string
          daily_rate?: number
          id?: string
          is_active?: boolean
          notes?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      performance_reviews: {
        Row: {
          acknowledged_at: string | null
          areas_for_improvement: string | null
          branch_id: string
          created_at: string | null
          cycle_id: string | null
          employee_comments: string | null
          employee_id: string | null
          goals_achieved: string | null
          id: string
          manager_comments: string | null
          new_goals: string | null
          overall_rating: number | null
          review_date: string
          reviewed_at: string | null
          reviewer_id: string | null
          status: string | null
          strengths: string | null
          submitted_at: string | null
          updated_at: string | null
        }
        Insert: {
          acknowledged_at?: string | null
          areas_for_improvement?: string | null
          branch_id?: string
          created_at?: string | null
          cycle_id?: string | null
          employee_comments?: string | null
          employee_id?: string | null
          goals_achieved?: string | null
          id?: string
          manager_comments?: string | null
          new_goals?: string | null
          overall_rating?: number | null
          review_date: string
          reviewed_at?: string | null
          reviewer_id?: string | null
          status?: string | null
          strengths?: string | null
          submitted_at?: string | null
          updated_at?: string | null
        }
        Update: {
          acknowledged_at?: string | null
          areas_for_improvement?: string | null
          branch_id?: string
          created_at?: string | null
          cycle_id?: string | null
          employee_comments?: string | null
          employee_id?: string | null
          goals_achieved?: string | null
          id?: string
          manager_comments?: string | null
          new_goals?: string | null
          overall_rating?: number | null
          review_date?: string
          reviewed_at?: string | null
          reviewer_id?: string | null
          status?: string | null
          strengths?: string | null
          submitted_at?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "performance_reviews_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "performance_reviews_cycle_id_fkey"
            columns: ["cycle_id"]
            isOneToOne: false
            referencedRelation: "review_cycles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "performance_reviews_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "performance_reviews_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "performance_reviews_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "performance_reviews_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "performance_reviews_reviewer_id_fkey"
            columns: ["reviewer_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "performance_reviews_reviewer_id_fkey"
            columns: ["reviewer_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "performance_reviews_reviewer_id_fkey"
            columns: ["reviewer_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "performance_reviews_reviewer_id_fkey"
            columns: ["reviewer_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      point_transactions: {
        Row: {
          created_at: string
          created_by: string | null
          employee_id: string
          id: string
          points: number
          reason: string
          reason_type: string
          reference_id: string | null
          reference_type: string | null
          transaction_type: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          employee_id: string
          id?: string
          points: number
          reason: string
          reason_type: string
          reference_id?: string | null
          reference_type?: string | null
          transaction_type: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          employee_id?: string
          id?: string
          points?: number
          reason?: string
          reason_type?: string
          reference_id?: string | null
          reference_type?: string | null
          transaction_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "point_transactions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "point_transactions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "point_transactions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "point_transactions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      positions: {
        Row: {
          branch_id: string
          created_at: string
          created_by: string | null
          department_id: string | null
          filled_count: number | null
          headcount: number | null
          id: string
          is_active: boolean
          level: string | null
          max_salary: number | null
          min_salary: number | null
          required_skills: string[] | null
          responsibilities: string | null
          title: string
          updated_at: string
        }
        Insert: {
          branch_id?: string
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          filled_count?: number | null
          headcount?: number | null
          id?: string
          is_active?: boolean
          level?: string | null
          max_salary?: number | null
          min_salary?: number | null
          required_skills?: string[] | null
          responsibilities?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          branch_id?: string
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          filled_count?: number | null
          headcount?: number | null
          id?: string
          is_active?: boolean
          level?: string | null
          max_salary?: number | null
          min_salary?: number | null
          required_skills?: string[] | null
          responsibilities?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "positions_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "positions_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      pricing_inquiries: {
        Row: {
          additional_notes: string | null
          branches_count: number | null
          budget_range: string | null
          company_name: string
          contact_person: string
          contact_position: string | null
          country: string | null
          created_at: string
          current_hr_system: string | null
          email: string
          employee_count: number | null
          expected_users: number | null
          hosting_preference: string | null
          id: string
          industry: string | null
          integrations_needed: string[] | null
          internal_notes: string | null
          modules_needed: string[] | null
          phone: string | null
          special_requirements: string | null
          status: string
          timeline: string | null
          updated_at: string
          website: string | null
        }
        Insert: {
          additional_notes?: string | null
          branches_count?: number | null
          budget_range?: string | null
          company_name: string
          contact_person: string
          contact_position?: string | null
          country?: string | null
          created_at?: string
          current_hr_system?: string | null
          email: string
          employee_count?: number | null
          expected_users?: number | null
          hosting_preference?: string | null
          id?: string
          industry?: string | null
          integrations_needed?: string[] | null
          internal_notes?: string | null
          modules_needed?: string[] | null
          phone?: string | null
          special_requirements?: string | null
          status?: string
          timeline?: string | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          additional_notes?: string | null
          branches_count?: number | null
          budget_range?: string | null
          company_name?: string
          contact_person?: string
          contact_position?: string | null
          country?: string | null
          created_at?: string
          current_hr_system?: string | null
          email?: string
          employee_count?: number | null
          expected_users?: number | null
          hosting_preference?: string | null
          id?: string
          industry?: string | null
          integrations_needed?: string[] | null
          internal_notes?: string | null
          modules_needed?: string[] | null
          phone?: string | null
          special_requirements?: string | null
          status?: string
          timeline?: string | null
          updated_at?: string
          website?: string | null
        }
        Relationships: []
      }
      processing_activities: {
        Row: {
          activity_name: string
          activity_name_ka: string | null
          created_at: string
          created_by: string | null
          data_categories: string[]
          data_subjects: string[]
          dpo_involved: boolean
          id: string
          is_active: boolean
          legal_basis: string
          purpose: string
          recipients: string[] | null
          responsible_person: string | null
          retention_period: string
          safeguards: string | null
          security_measures: string
          third_country_transfers: boolean
          updated_at: string
        }
        Insert: {
          activity_name: string
          activity_name_ka?: string | null
          created_at?: string
          created_by?: string | null
          data_categories: string[]
          data_subjects: string[]
          dpo_involved?: boolean
          id?: string
          is_active?: boolean
          legal_basis: string
          purpose: string
          recipients?: string[] | null
          responsible_person?: string | null
          retention_period: string
          safeguards?: string | null
          security_measures: string
          third_country_transfers?: boolean
          updated_at?: string
        }
        Update: {
          activity_name?: string
          activity_name_ka?: string | null
          created_at?: string
          created_by?: string | null
          data_categories?: string[]
          data_subjects?: string[]
          dpo_involved?: boolean
          id?: string
          is_active?: boolean
          legal_basis?: string
          purpose?: string
          recipients?: string[] | null
          responsible_person?: string | null
          retention_period?: string
          safeguards?: string | null
          security_measures?: string
          third_country_transfers?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          full_name: string
          id: string
          updated_at: string | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          full_name: string
          id: string
          updated_at?: string | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          full_name?: string
          id?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      projects: {
        Row: {
          branch_id: string
          color: string | null
          created_at: string
          created_by: string | null
          department_id: string | null
          description: string | null
          end_date: string | null
          id: string
          name: string
          start_date: string | null
          status: string
          updated_at: string
        }
        Insert: {
          branch_id?: string
          color?: string | null
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          name: string
          start_date?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          branch_id?: string
          color?: string | null
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          name?: string
          start_date?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "projects_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "projects_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      public_holidays: {
        Row: {
          branch_id: string | null
          created_at: string
          created_by: string | null
          holiday_date: string
          id: string
          is_active: boolean
          is_recurring: boolean
          name: string
          overtime_multiplier: number | null
          updated_at: string
          year: number | null
        }
        Insert: {
          branch_id?: string | null
          created_at?: string
          created_by?: string | null
          holiday_date: string
          id?: string
          is_active?: boolean
          is_recurring?: boolean
          name: string
          overtime_multiplier?: number | null
          updated_at?: string
          year?: number | null
        }
        Update: {
          branch_id?: string | null
          created_at?: string
          created_by?: string | null
          holiday_date?: string
          id?: string
          is_active?: boolean
          is_recurring?: boolean
          name?: string
          overtime_multiplier?: number | null
          updated_at?: string
          year?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "public_holidays_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      recognitions: {
        Row: {
          created_at: string
          id: string
          is_public: boolean
          message: string
          points_awarded: number
          recipient_id: string
          recognizer_id: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_public?: boolean
          message: string
          points_awarded?: number
          recipient_id: string
          recognizer_id: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_public?: boolean
          message?: string
          points_awarded?: number
          recipient_id?: string
          recognizer_id?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "recognitions_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "recognitions_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "recognitions_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "recognitions_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "recognitions_recognizer_id_fkey"
            columns: ["recognizer_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "recognitions_recognizer_id_fkey"
            columns: ["recognizer_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "recognitions_recognizer_id_fkey"
            columns: ["recognizer_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "recognitions_recognizer_id_fkey"
            columns: ["recognizer_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      review_cycles: {
        Row: {
          created_at: string | null
          created_by: string | null
          description: string | null
          end_date: string
          id: string
          name: string
          review_type: string
          start_date: string
          status: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_date: string
          id?: string
          name: string
          review_type: string
          start_date: string
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_date?: string
          id?: string
          name?: string
          review_type?: string
          start_date?: string
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      reward_catalog: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          description_en: string | null
          id: string
          image_url: string | null
          is_active: boolean
          name: string
          name_en: string | null
          points_cost: number
          quantity_available: number | null
          reward_type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          description_en?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          name: string
          name_en?: string | null
          points_cost: number
          quantity_available?: number | null
          reward_type: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          description_en?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          name?: string
          name_en?: string | null
          points_cost?: number
          quantity_available?: number | null
          reward_type?: string
          updated_at?: string
        }
        Relationships: []
      }
      reward_redemptions: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string
          delivered_at: string | null
          employee_id: string
          id: string
          notes: string | null
          points_spent: number
          reward_id: string
          status: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          delivered_at?: string | null
          employee_id: string
          id?: string
          notes?: string | null
          points_spent: number
          reward_id: string
          status?: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          delivered_at?: string | null
          employee_id?: string
          id?: string
          notes?: string | null
          points_spent?: number
          reward_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "reward_redemptions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reward_redemptions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reward_redemptions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reward_redemptions_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reward_redemptions_reward_id_fkey"
            columns: ["reward_id"]
            isOneToOne: false
            referencedRelation: "reward_catalog"
            referencedColumns: ["id"]
          },
        ]
      }
      role_permissions: {
        Row: {
          created_at: string
          id: string
          permission_key: string
          role_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          permission_key: string
          role_id: string
        }
        Update: {
          created_at?: string
          id?: string
          permission_key?: string
          role_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "role_permissions_role_id_fkey"
            columns: ["role_id"]
            isOneToOne: false
            referencedRelation: "custom_roles"
            referencedColumns: ["id"]
          },
        ]
      }
      rsge_exports: {
        Row: {
          branch_id: string | null
          created_at: string
          created_by: string
          export_type: string
          file_format: string
          id: string
          period_from: string
          period_to: string
          row_count: number
          uploaded_at: string | null
        }
        Insert: {
          branch_id?: string | null
          created_at?: string
          created_by?: string
          export_type: string
          file_format?: string
          id?: string
          period_from: string
          period_to: string
          row_count?: number
          uploaded_at?: string | null
        }
        Update: {
          branch_id?: string | null
          created_at?: string
          created_by?: string
          export_type?: string
          file_format?: string
          id?: string
          period_from?: string
          period_to?: string
          row_count?: number
          uploaded_at?: string | null
        }
        Relationships: []
      }
      safety_training_records: {
        Row: {
          certificate_number: string | null
          created_at: string
          created_by: string | null
          employee_id: string
          id: string
          instructor_name: string | null
          is_valid: boolean | null
          next_due_date: string | null
          notes: string | null
          training_date: string
          training_type: string
          updated_at: string
        }
        Insert: {
          certificate_number?: string | null
          created_at?: string
          created_by?: string | null
          employee_id: string
          id?: string
          instructor_name?: string | null
          is_valid?: boolean | null
          next_due_date?: string | null
          notes?: string | null
          training_date: string
          training_type?: string
          updated_at?: string
        }
        Update: {
          certificate_number?: string | null
          created_at?: string
          created_by?: string | null
          employee_id?: string
          id?: string
          instructor_name?: string | null
          is_valid?: boolean | null
          next_due_date?: string | null
          notes?: string | null
          training_date?: string
          training_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "safety_training_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "safety_training_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "safety_training_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "safety_training_records_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      salary_benchmarks: {
        Row: {
          calculated_at: string
          company_count: number
          company_size_band: string
          created_at: string
          currency: string
          id: string
          p25: number
          p50: number
          p75: number
          position_category: string
          region: string
          sample_size: number
          source: string
          updated_at: string
        }
        Insert: {
          calculated_at?: string
          company_count?: number
          company_size_band?: string
          created_at?: string
          currency?: string
          id?: string
          p25: number
          p50: number
          p75: number
          position_category: string
          region?: string
          sample_size: number
          source?: string
          updated_at?: string
        }
        Update: {
          calculated_at?: string
          company_count?: number
          company_size_band?: string
          created_at?: string
          currency?: string
          id?: string
          p25?: number
          p50?: number
          p75?: number
          position_category?: string
          region?: string
          sample_size?: number
          source?: string
          updated_at?: string
        }
        Relationships: []
      }
      salary_history: {
        Row: {
          base_salary: number
          branch_id: string
          created_at: string
          employee_id: string
          gross_salary: number
          id: string
          income_tax: number | null
          month: number
          net_salary: number
          pension_tax: number | null
          total_benefits: number | null
          total_deductions: number | null
          year: number
        }
        Insert: {
          base_salary: number
          branch_id?: string
          created_at?: string
          employee_id: string
          gross_salary: number
          id?: string
          income_tax?: number | null
          month: number
          net_salary: number
          pension_tax?: number | null
          total_benefits?: number | null
          total_deductions?: number | null
          year: number
        }
        Update: {
          base_salary?: number
          branch_id?: string
          created_at?: string
          employee_id?: string
          gross_salary?: number
          id?: string
          income_tax?: number | null
          month?: number
          net_salary?: number
          pension_tax?: number | null
          total_benefits?: number | null
          total_deductions?: number | null
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "salary_history_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      schedule_templates: {
        Row: {
          break_duration: number | null
          break_end_time: string | null
          break_start_time: string | null
          conditions: string | null
          created_at: string | null
          created_by: string | null
          description: string | null
          end_time: string | null
          id: string
          is_default: boolean | null
          name: string
          no_break: boolean | null
          schedule_category: string | null
          schedule_type: string | null
          start_time: string | null
          updated_at: string | null
          weekly_hours: number | null
          work_days: string[] | null
          work_days_location: Json | null
        }
        Insert: {
          break_duration?: number | null
          break_end_time?: string | null
          break_start_time?: string | null
          conditions?: string | null
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_time?: string | null
          id?: string
          is_default?: boolean | null
          name: string
          no_break?: boolean | null
          schedule_category?: string | null
          schedule_type?: string | null
          start_time?: string | null
          updated_at?: string | null
          weekly_hours?: number | null
          work_days?: string[] | null
          work_days_location?: Json | null
        }
        Update: {
          break_duration?: number | null
          break_end_time?: string | null
          break_start_time?: string | null
          conditions?: string | null
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_time?: string | null
          id?: string
          is_default?: boolean | null
          name?: string
          no_break?: boolean | null
          schedule_category?: string | null
          schedule_type?: string | null
          start_time?: string | null
          updated_at?: string | null
          weekly_hours?: number | null
          work_days?: string[] | null
          work_days_location?: Json | null
        }
        Relationships: []
      }
      security_events: {
        Row: {
          created_at: string
          description: string
          event_type: string
          id: string
          ip_address: string | null
          metadata: Json | null
          severity: string
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          description: string
          event_type: string
          id?: string
          ip_address?: string | null
          metadata?: Json | null
          severity?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          description?: string
          event_type?: string
          id?: string
          ip_address?: string | null
          metadata?: Json | null
          severity?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      security_incidents: {
        Row: {
          affected_systems: string[] | null
          affected_users: string[] | null
          assigned_to: string | null
          corrective_actions: string | null
          created_at: string
          description: string
          detected_at: string
          id: string
          incident_type: string
          preventive_actions: string | null
          reported_by: string | null
          resolution_notes: string | null
          resolved_at: string | null
          root_cause: string | null
          severity: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          affected_systems?: string[] | null
          affected_users?: string[] | null
          assigned_to?: string | null
          corrective_actions?: string | null
          created_at?: string
          description: string
          detected_at?: string
          id?: string
          incident_type: string
          preventive_actions?: string | null
          reported_by?: string | null
          resolution_notes?: string | null
          resolved_at?: string | null
          root_cause?: string | null
          severity: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          affected_systems?: string[] | null
          affected_users?: string[] | null
          assigned_to?: string | null
          corrective_actions?: string | null
          created_at?: string
          description?: string
          detected_at?: string
          id?: string
          incident_type?: string
          preventive_actions?: string | null
          reported_by?: string | null
          resolution_notes?: string | null
          resolved_at?: string | null
          root_cause?: string | null
          severity?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      sensitive_data_access_log: {
        Row: {
          access_type: string
          accessed_at: string
          accessed_record_id: string | null
          accessed_table: string
          fields_accessed: string[] | null
          id: string
          ip_address: string | null
          user_agent: string | null
          user_id: string
        }
        Insert: {
          access_type: string
          accessed_at?: string
          accessed_record_id?: string | null
          accessed_table: string
          fields_accessed?: string[] | null
          id?: string
          ip_address?: string | null
          user_agent?: string | null
          user_id: string
        }
        Update: {
          access_type?: string
          accessed_at?: string
          accessed_record_id?: string | null
          accessed_table?: string
          fields_accessed?: string[] | null
          id?: string
          ip_address?: string | null
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      service_trips: {
        Row: {
          approved_at: string | null
          created_at: string
          destination: string
          employee_id: string
          end_date: string
          end_time: string | null
          id: string
          manager_id: string | null
          purpose: string | null
          rejection_reason: string | null
          start_date: string
          start_time: string | null
          status: string
          updated_at: string
        }
        Insert: {
          approved_at?: string | null
          created_at?: string
          destination: string
          employee_id: string
          end_date: string
          end_time?: string | null
          id?: string
          manager_id?: string | null
          purpose?: string | null
          rejection_reason?: string | null
          start_date: string
          start_time?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          approved_at?: string | null
          created_at?: string
          destination?: string
          employee_id?: string
          end_date?: string
          end_time?: string | null
          id?: string
          manager_id?: string | null
          purpose?: string | null
          rejection_reason?: string | null
          start_date?: string
          start_time?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_trips_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_trips_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_trips_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_trips_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_trips_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_trips_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_trips_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_trips_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      shift_schedules: {
        Row: {
          break_duration: number | null
          created_at: string | null
          created_by: string | null
          employee_id: string
          end_time: string
          id: string
          notes: string | null
          shift_date: string
          shift_name: string | null
          start_time: string
          updated_at: string | null
        }
        Insert: {
          break_duration?: number | null
          created_at?: string | null
          created_by?: string | null
          employee_id: string
          end_time: string
          id?: string
          notes?: string | null
          shift_date: string
          shift_name?: string | null
          start_time: string
          updated_at?: string | null
        }
        Update: {
          break_duration?: number | null
          created_at?: string | null
          created_by?: string | null
          employee_id?: string
          end_time?: string
          id?: string
          notes?: string | null
          shift_date?: string
          shift_name?: string | null
          start_time?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "shift_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      shift_templates: {
        Row: {
          break_duration: number
          created_at: string
          created_by: string | null
          description: string | null
          end_time: string
          id: string
          is_active: boolean
          name: string
          shift_name: string | null
          start_time: string
          updated_at: string
        }
        Insert: {
          break_duration?: number
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_time: string
          id?: string
          is_active?: boolean
          name: string
          shift_name?: string | null
          start_time: string
          updated_at?: string
        }
        Update: {
          break_duration?: number
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_time?: string
          id?: string
          is_active?: boolean
          name?: string
          shift_name?: string | null
          start_time?: string
          updated_at?: string
        }
        Relationships: []
      }
      signify_signing_requests: {
        Row: {
          created_at: string
          document_id: string
          id: string
          initiated_by: string
          recipient_code: string
          recipient_email: string | null
          recipient_name: string
          signed_at: string | null
          signify_document_id: number
          signify_recipient_id: number | null
          signing_url: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          document_id: string
          id?: string
          initiated_by: string
          recipient_code: string
          recipient_email?: string | null
          recipient_name: string
          signed_at?: string | null
          signify_document_id: number
          signify_recipient_id?: number | null
          signing_url?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          document_id?: string
          id?: string
          initiated_by?: string
          recipient_code?: string
          recipient_email?: string | null
          recipient_name?: string
          signed_at?: string | null
          signify_document_id?: number
          signify_recipient_id?: number | null
          signing_url?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "signify_signing_requests_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
        ]
      }
      signify_user_tokens: {
        Row: {
          access_token: string
          created_at: string
          id: string
          refresh_token: string
          signify_email: string | null
          signify_name: string | null
          signify_user_id: string | null
          token_expires_at: string
          updated_at: string
          user_id: string
        }
        Insert: {
          access_token: string
          created_at?: string
          id?: string
          refresh_token: string
          signify_email?: string | null
          signify_name?: string | null
          signify_user_id?: string | null
          token_expires_at: string
          updated_at?: string
          user_id: string
        }
        Update: {
          access_token?: string
          created_at?: string
          id?: string
          refresh_token?: string
          signify_email?: string | null
          signify_name?: string | null
          signify_user_id?: string | null
          token_expires_at?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      skills: {
        Row: {
          category: string
          created_at: string
          id: string
          name_en: string
          name_ka: string
          target_level: number
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          name_en: string
          name_ka: string
          target_level?: number
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          name_en?: string
          name_ka?: string
          target_level?: number
          updated_at?: string
        }
        Relationships: []
      }
      smart_academy_enrollments: {
        Row: {
          card_type: string | null
          course_duration: string | null
          course_link: string | null
          course_price: number | null
          course_title: string
          created_at: string
          email: string | null
          employee_id: string | null
          external_course_id: number
          full_name: string | null
          gift_recipient_name: string | null
          hr_comment: string | null
          id: string
          is_gift: boolean | null
          is_online: boolean | null
          notes: string | null
          payment_type: string | null
          personal_id: string | null
          phone: string | null
          preferred_schedule: string | null
          processed_at: string | null
          processed_by: string | null
          promo_code: string | null
          quantity: number
          status: string
          terms_accepted: boolean | null
          updated_at: string
          user_id: string
          wants_consultation: boolean | null
        }
        Insert: {
          card_type?: string | null
          course_duration?: string | null
          course_link?: string | null
          course_price?: number | null
          course_title: string
          created_at?: string
          email?: string | null
          employee_id?: string | null
          external_course_id: number
          full_name?: string | null
          gift_recipient_name?: string | null
          hr_comment?: string | null
          id?: string
          is_gift?: boolean | null
          is_online?: boolean | null
          notes?: string | null
          payment_type?: string | null
          personal_id?: string | null
          phone?: string | null
          preferred_schedule?: string | null
          processed_at?: string | null
          processed_by?: string | null
          promo_code?: string | null
          quantity?: number
          status?: string
          terms_accepted?: boolean | null
          updated_at?: string
          user_id: string
          wants_consultation?: boolean | null
        }
        Update: {
          card_type?: string | null
          course_duration?: string | null
          course_link?: string | null
          course_price?: number | null
          course_title?: string
          created_at?: string
          email?: string | null
          employee_id?: string | null
          external_course_id?: number
          full_name?: string | null
          gift_recipient_name?: string | null
          hr_comment?: string | null
          id?: string
          is_gift?: boolean | null
          is_online?: boolean | null
          notes?: string | null
          payment_type?: string | null
          personal_id?: string | null
          phone?: string | null
          preferred_schedule?: string | null
          processed_at?: string | null
          processed_by?: string | null
          promo_code?: string | null
          quantity?: number
          status?: string
          terms_accepted?: boolean | null
          updated_at?: string
          user_id?: string
          wants_consultation?: boolean | null
        }
        Relationships: []
      }
      sms_logs: {
        Row: {
          created_at: string | null
          employee_id: string | null
          employee_name: string | null
          id: string
          message: string
          organization: string | null
          recipient: string
          sent_at: string | null
          sent_by_user_id: string | null
          status: string
          twilio_sid: string | null
        }
        Insert: {
          created_at?: string | null
          employee_id?: string | null
          employee_name?: string | null
          id?: string
          message: string
          organization?: string | null
          recipient: string
          sent_at?: string | null
          sent_by_user_id?: string | null
          status?: string
          twilio_sid?: string | null
        }
        Update: {
          created_at?: string | null
          employee_id?: string | null
          employee_name?: string | null
          id?: string
          message?: string
          organization?: string | null
          recipient?: string
          sent_at?: string | null
          sent_by_user_id?: string | null
          status?: string
          twilio_sid?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sms_logs_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sms_logs_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sms_logs_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sms_logs_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      sms_notification_settings: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          notification_type: string
          sms_enabled: boolean
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          notification_type: string
          sms_enabled?: boolean
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          notification_type?: string
          sms_enabled?: boolean
          updated_at?: string | null
        }
        Relationships: []
      }
      support_tickets: {
        Row: {
          ai_actions_taken: Json | null
          ai_diagnosis: string | null
          ai_resolved: boolean | null
          assigned_to: string | null
          category: string
          created_at: string
          created_by: string
          description: string
          id: string
          priority: string
          resolution_notes: string | null
          resolved_at: string | null
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          ai_actions_taken?: Json | null
          ai_diagnosis?: string | null
          ai_resolved?: boolean | null
          assigned_to?: string | null
          category?: string
          created_at?: string
          created_by: string
          description: string
          id?: string
          priority?: string
          resolution_notes?: string | null
          resolved_at?: string | null
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          ai_actions_taken?: Json | null
          ai_diagnosis?: string | null
          ai_resolved?: boolean | null
          assigned_to?: string | null
          category?: string
          created_at?: string
          created_by?: string
          description?: string
          id?: string
          priority?: string
          resolution_notes?: string | null
          resolved_at?: string | null
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      suppressed_emails: {
        Row: {
          created_at: string
          email: string
          id: string
          metadata: Json | null
          reason: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          metadata?: Json | null
          reason: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          metadata?: Json | null
          reason?: string
        }
        Relationships: []
      }
      talentos_webhook_events: {
        Row: {
          candidate_id: string | null
          created_at: string
          error_message: string | null
          event_type: string
          external_application_id: string | null
          external_job_id: string | null
          id: string
          payload: Json
          processed: boolean | null
          signature_valid: boolean | null
          vacancy_id: string | null
        }
        Insert: {
          candidate_id?: string | null
          created_at?: string
          error_message?: string | null
          event_type: string
          external_application_id?: string | null
          external_job_id?: string | null
          id?: string
          payload: Json
          processed?: boolean | null
          signature_valid?: boolean | null
          vacancy_id?: string | null
        }
        Update: {
          candidate_id?: string | null
          created_at?: string
          error_message?: string | null
          event_type?: string
          external_application_id?: string | null
          external_job_id?: string | null
          id?: string
          payload?: Json
          processed?: boolean | null
          signature_valid?: boolean | null
          vacancy_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "talentos_webhook_events_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "talentos_webhook_events_vacancy_id_fkey"
            columns: ["vacancy_id"]
            isOneToOne: false
            referencedRelation: "job_vacancies"
            referencedColumns: ["id"]
          },
        ]
      }
      task_attachments: {
        Row: {
          created_at: string
          file_name: string
          file_path: string
          file_size: number | null
          file_type: string | null
          id: string
          task_id: string
          uploaded_by: string
        }
        Insert: {
          created_at?: string
          file_name: string
          file_path: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          task_id: string
          uploaded_by: string
        }
        Update: {
          created_at?: string
          file_name?: string
          file_path?: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          task_id?: string
          uploaded_by?: string
        }
        Relationships: []
      }
      task_comments: {
        Row: {
          comment: string
          created_at: string
          id: string
          task_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          comment: string
          created_at?: string
          id?: string
          task_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          comment?: string
          created_at?: string
          id?: string
          task_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      tasks: {
        Row: {
          approval_notes: string | null
          assigned_by: string | null
          assigned_to: string | null
          branch_id: string
          completed_at: string | null
          created_at: string
          department_id: string | null
          description: string | null
          due_date: string | null
          id: string
          notes: string | null
          parent_task_id: string | null
          priority: string
          progress: number | null
          project_id: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          submitted_at: string | null
          task_type: string
          title: string
          updated_at: string
        }
        Insert: {
          approval_notes?: string | null
          assigned_by?: string | null
          assigned_to?: string | null
          branch_id?: string
          completed_at?: string | null
          created_at?: string
          department_id?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          notes?: string | null
          parent_task_id?: string | null
          priority?: string
          progress?: number | null
          project_id?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          submitted_at?: string | null
          task_type: string
          title: string
          updated_at?: string
        }
        Update: {
          approval_notes?: string | null
          assigned_by?: string | null
          assigned_to?: string | null
          branch_id?: string
          completed_at?: string | null
          created_at?: string
          department_id?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          notes?: string | null
          parent_task_id?: string | null
          priority?: string
          progress?: number | null
          project_id?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          submitted_at?: string | null
          task_type?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tasks_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_parent_task_id_fkey"
            columns: ["parent_task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      team_challenges: {
        Row: {
          challenge_type: string
          created_at: string
          created_by: string | null
          department_id: string | null
          description: string | null
          end_date: string
          id: string
          name: string
          points_reward: number
          start_date: string
          status: string
          target_value: number
          updated_at: string
        }
        Insert: {
          challenge_type: string
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          end_date: string
          id?: string
          name: string
          points_reward?: number
          start_date: string
          status?: string
          target_value?: number
          updated_at?: string
        }
        Update: {
          challenge_type?: string
          created_at?: string
          created_by?: string | null
          department_id?: string | null
          description?: string | null
          end_date?: string
          id?: string
          name?: string
          points_reward?: number
          start_date?: string
          status?: string
          target_value?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_challenges_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      tn_application_sync: {
        Row: {
          candidate_email: string | null
          candidate_full_name: string | null
          candidate_id: string | null
          candidate_phone: string | null
          cover_note: string | null
          created_at: string
          cv_file_path: string | null
          external_application_id: string
          external_candidate_user_id: string | null
          external_job_id: string
          id: string
          last_pulled_at: string
          match_breakdown: Json | null
          match_score: number | null
          raw_payload: Json | null
          status: string
          updated_at: string
          vacancy_id: string | null
        }
        Insert: {
          candidate_email?: string | null
          candidate_full_name?: string | null
          candidate_id?: string | null
          candidate_phone?: string | null
          cover_note?: string | null
          created_at?: string
          cv_file_path?: string | null
          external_application_id: string
          external_candidate_user_id?: string | null
          external_job_id: string
          id?: string
          last_pulled_at?: string
          match_breakdown?: Json | null
          match_score?: number | null
          raw_payload?: Json | null
          status?: string
          updated_at?: string
          vacancy_id?: string | null
        }
        Update: {
          candidate_email?: string | null
          candidate_full_name?: string | null
          candidate_id?: string | null
          candidate_phone?: string | null
          cover_note?: string | null
          created_at?: string
          cv_file_path?: string | null
          external_application_id?: string
          external_candidate_user_id?: string | null
          external_job_id?: string
          id?: string
          last_pulled_at?: string
          match_breakdown?: Json | null
          match_score?: number | null
          raw_payload?: Json | null
          status?: string
          updated_at?: string
          vacancy_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tn_application_sync_candidate_id_fkey"
            columns: ["candidate_id"]
            isOneToOne: false
            referencedRelation: "candidates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tn_application_sync_vacancy_id_fkey"
            columns: ["vacancy_id"]
            isOneToOne: false
            referencedRelation: "job_vacancies"
            referencedColumns: ["id"]
          },
        ]
      }
      tn_job_sync: {
        Row: {
          created_at: string
          external_company_id: string | null
          external_job_id: string
          id: string
          last_error: string | null
          last_pushed_at: string
          status: string
          updated_at: string
          vacancy_id: string
        }
        Insert: {
          created_at?: string
          external_company_id?: string | null
          external_job_id: string
          id?: string
          last_error?: string | null
          last_pushed_at?: string
          status?: string
          updated_at?: string
          vacancy_id: string
        }
        Update: {
          created_at?: string
          external_company_id?: string | null
          external_job_id?: string
          id?: string
          last_error?: string | null
          last_pushed_at?: string
          status?: string
          updated_at?: string
          vacancy_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tn_job_sync_vacancy_id_fkey"
            columns: ["vacancy_id"]
            isOneToOne: true
            referencedRelation: "job_vacancies"
            referencedColumns: ["id"]
          },
        ]
      }
      training_courses: {
        Row: {
          budget: number | null
          category: string
          course_status: string
          created_at: string | null
          created_by: string | null
          description: string | null
          duration_weeks: number | null
          end_date: string | null
          id: string
          instructor_email: string | null
          instructor_name: string | null
          is_online: boolean | null
          location: string | null
          max_participants: number | null
          meeting_link: string | null
          start_date: string
          title: string
          updated_at: string | null
        }
        Insert: {
          budget?: number | null
          category: string
          course_status?: string
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          duration_weeks?: number | null
          end_date?: string | null
          id?: string
          instructor_email?: string | null
          instructor_name?: string | null
          is_online?: boolean | null
          location?: string | null
          max_participants?: number | null
          meeting_link?: string | null
          start_date: string
          title: string
          updated_at?: string | null
        }
        Update: {
          budget?: number | null
          category?: string
          course_status?: string
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          duration_weeks?: number | null
          end_date?: string | null
          id?: string
          instructor_email?: string | null
          instructor_name?: string | null
          is_online?: boolean | null
          location?: string | null
          max_participants?: number | null
          meeting_link?: string | null
          start_date?: string
          title?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      training_enrollments: {
        Row: {
          attendance_status: string | null
          certificate_issued: boolean | null
          certificate_url: string | null
          completion_date: string | null
          employee_id: string | null
          enrollment_date: string | null
          feedback: string | null
          id: string
          score: number | null
          session_id: string | null
          status: string | null
        }
        Insert: {
          attendance_status?: string | null
          certificate_issued?: boolean | null
          certificate_url?: string | null
          completion_date?: string | null
          employee_id?: string | null
          enrollment_date?: string | null
          feedback?: string | null
          id?: string
          score?: number | null
          session_id?: string | null
          status?: string | null
        }
        Update: {
          attendance_status?: string | null
          certificate_issued?: boolean | null
          certificate_url?: string | null
          completion_date?: string | null
          employee_id?: string | null
          enrollment_date?: string | null
          feedback?: string | null
          id?: string
          score?: number | null
          session_id?: string | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "training_enrollments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "training_enrollments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "training_enrollments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "training_enrollments_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "training_enrollments_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "training_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      training_participants: {
        Row: {
          attendance_percentage: number | null
          certificate_issued: boolean | null
          completion_date: string | null
          created_at: string | null
          employee_id: string
          enrollment_date: string | null
          final_score: number | null
          id: string
          notes: string | null
          participant_status: string
          training_id: string
          updated_at: string | null
        }
        Insert: {
          attendance_percentage?: number | null
          certificate_issued?: boolean | null
          completion_date?: string | null
          created_at?: string | null
          employee_id: string
          enrollment_date?: string | null
          final_score?: number | null
          id?: string
          notes?: string | null
          participant_status?: string
          training_id: string
          updated_at?: string | null
        }
        Update: {
          attendance_percentage?: number | null
          certificate_issued?: boolean | null
          completion_date?: string | null
          created_at?: string | null
          employee_id?: string
          enrollment_date?: string | null
          final_score?: number | null
          id?: string
          notes?: string | null
          participant_status?: string
          training_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "training_participants_training_id_fkey"
            columns: ["training_id"]
            isOneToOne: false
            referencedRelation: "training_courses"
            referencedColumns: ["id"]
          },
        ]
      }
      training_sessions: {
        Row: {
          course_id: string | null
          created_at: string | null
          end_time: string | null
          id: string
          instructor: string | null
          location: string | null
          max_participants: number | null
          session_date: string
          start_time: string | null
          status: string | null
        }
        Insert: {
          course_id?: string | null
          created_at?: string | null
          end_time?: string | null
          id?: string
          instructor?: string | null
          location?: string | null
          max_participants?: number | null
          session_date: string
          start_time?: string | null
          status?: string | null
        }
        Update: {
          course_id?: string | null
          created_at?: string | null
          end_time?: string | null
          id?: string
          instructor?: string | null
          location?: string | null
          max_participants?: number | null
          session_date?: string
          start_time?: string | null
          status?: string | null
        }
        Relationships: []
      }
      travel_bookings: {
        Row: {
          booking_type: string
          branch_id: string | null
          check_in_date: string
          check_out_date: string
          city: string
          confirmation_number: string | null
          country: string
          created_at: string
          created_by: string | null
          currency: string
          employee_id: string | null
          exceeds_limit: boolean
          expense_request_id: string | null
          guests: number
          id: string
          limit_amount: number | null
          limit_approved_at: string | null
          limit_approved_by: string | null
          nightly_rate: number
          nights: number
          notes: string | null
          per_diem_days: number
          per_diem_rate: number
          per_diem_total: number
          room_type: string | null
          status: string
          total_amount: number
          trip_id: string | null
          updated_at: string
          vendor_id: string | null
          vendor_name_manual: string | null
          voucher_url: string | null
        }
        Insert: {
          booking_type?: string
          branch_id?: string | null
          check_in_date: string
          check_out_date: string
          city: string
          confirmation_number?: string | null
          country?: string
          created_at?: string
          created_by?: string | null
          currency?: string
          employee_id?: string | null
          exceeds_limit?: boolean
          expense_request_id?: string | null
          guests?: number
          id?: string
          limit_amount?: number | null
          limit_approved_at?: string | null
          limit_approved_by?: string | null
          nightly_rate?: number
          nights?: number
          notes?: string | null
          per_diem_days?: number
          per_diem_rate?: number
          per_diem_total?: number
          room_type?: string | null
          status?: string
          total_amount?: number
          trip_id?: string | null
          updated_at?: string
          vendor_id?: string | null
          vendor_name_manual?: string | null
          voucher_url?: string | null
        }
        Update: {
          booking_type?: string
          branch_id?: string | null
          check_in_date?: string
          check_out_date?: string
          city?: string
          confirmation_number?: string | null
          country?: string
          created_at?: string
          created_by?: string | null
          currency?: string
          employee_id?: string | null
          exceeds_limit?: boolean
          expense_request_id?: string | null
          guests?: number
          id?: string
          limit_amount?: number | null
          limit_approved_at?: string | null
          limit_approved_by?: string | null
          nightly_rate?: number
          nights?: number
          notes?: string | null
          per_diem_days?: number
          per_diem_rate?: number
          per_diem_total?: number
          room_type?: string | null
          status?: string
          total_amount?: number
          trip_id?: string | null
          updated_at?: string
          vendor_id?: string | null
          vendor_name_manual?: string | null
          voucher_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "travel_bookings_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "travel_bookings_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "travel_bookings_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "travel_bookings_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "travel_bookings_expense_request_id_fkey"
            columns: ["expense_request_id"]
            isOneToOne: false
            referencedRelation: "expense_requests"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "travel_bookings_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "business_trip_requests"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "travel_bookings_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "travel_vendors"
            referencedColumns: ["id"]
          },
        ]
      }
      travel_policy_limits: {
        Row: {
          city: string | null
          country: string
          created_at: string
          currency: string
          id: string
          is_active: boolean
          max_nightly_rate: number
          role_level: string | null
          updated_at: string
        }
        Insert: {
          city?: string | null
          country?: string
          created_at?: string
          currency?: string
          id?: string
          is_active?: boolean
          max_nightly_rate: number
          role_level?: string | null
          updated_at?: string
        }
        Update: {
          city?: string | null
          country?: string
          created_at?: string
          currency?: string
          id?: string
          is_active?: boolean
          max_nightly_rate?: number
          role_level?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      travel_vendors: {
        Row: {
          address: string | null
          city: string
          contact_email: string | null
          contact_person: string | null
          contact_phone: string | null
          contract_end_date: string | null
          contract_file_url: string | null
          contract_start_date: string | null
          corporate_rate: number | null
          country: string
          created_at: string
          created_by: string | null
          currency: string
          id: string
          is_active: boolean
          name: string
          notes: string | null
          rating: number | null
          room_types: Json
          source: string
          updated_at: string
          vendor_type: string
          website: string | null
        }
        Insert: {
          address?: string | null
          city: string
          contact_email?: string | null
          contact_person?: string | null
          contact_phone?: string | null
          contract_end_date?: string | null
          contract_file_url?: string | null
          contract_start_date?: string | null
          corporate_rate?: number | null
          country?: string
          created_at?: string
          created_by?: string | null
          currency?: string
          id?: string
          is_active?: boolean
          name: string
          notes?: string | null
          rating?: number | null
          room_types?: Json
          source?: string
          updated_at?: string
          vendor_type?: string
          website?: string | null
        }
        Update: {
          address?: string | null
          city?: string
          contact_email?: string | null
          contact_person?: string | null
          contact_phone?: string | null
          contract_end_date?: string | null
          contract_file_url?: string | null
          contract_start_date?: string | null
          corporate_rate?: number | null
          country?: string
          created_at?: string
          created_by?: string | null
          currency?: string
          id?: string
          is_active?: boolean
          name?: string
          notes?: string | null
          rating?: number | null
          room_types?: Json
          source?: string
          updated_at?: string
          vendor_type?: string
          website?: string | null
        }
        Relationships: []
      }
      ui_texts: {
        Row: {
          category: string
          created_at: string
          created_by: string | null
          description: string | null
          en_text: string | null
          id: string
          ka_text: string
          key: string
          key_ka: string | null
          updated_at: string
        }
        Insert: {
          category?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          en_text?: string | null
          id?: string
          ka_text: string
          key: string
          key_ka?: string | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          en_text?: string | null
          id?: string
          ka_text?: string
          key?: string
          key_ka?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      user_branch_access: {
        Row: {
          access_level: string
          branch_id: string
          created_at: string
          id: string
          is_primary: boolean
          user_id: string
        }
        Insert: {
          access_level?: string
          branch_id: string
          created_at?: string
          id?: string
          is_primary?: boolean
          user_id: string
        }
        Update: {
          access_level?: string
          branch_id?: string
          created_at?: string
          id?: string
          is_primary?: boolean
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_branch_access_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      user_consents: {
        Row: {
          consent_given: boolean
          consent_language: string | null
          consent_method: string | null
          consent_text: string
          consent_type: string
          consent_version: string
          created_at: string
          data_categories: string[] | null
          given_at: string | null
          id: string
          ip_address: string | null
          updated_at: string
          user_agent: string | null
          user_id: string
          withdrawal_method: string | null
          withdrawn_at: string | null
        }
        Insert: {
          consent_given?: boolean
          consent_language?: string | null
          consent_method?: string | null
          consent_text: string
          consent_type: string
          consent_version: string
          created_at?: string
          data_categories?: string[] | null
          given_at?: string | null
          id?: string
          ip_address?: string | null
          updated_at?: string
          user_agent?: string | null
          user_id: string
          withdrawal_method?: string | null
          withdrawn_at?: string | null
        }
        Update: {
          consent_given?: boolean
          consent_language?: string | null
          consent_method?: string | null
          consent_text?: string
          consent_type?: string
          consent_version?: string
          created_at?: string
          data_categories?: string[] | null
          given_at?: string | null
          id?: string
          ip_address?: string | null
          updated_at?: string
          user_agent?: string | null
          user_id?: string
          withdrawal_method?: string | null
          withdrawn_at?: string | null
        }
        Relationships: []
      }
      user_custom_roles: {
        Row: {
          created_at: string
          id: string
          role_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_custom_roles_role_id_fkey"
            columns: ["role_id"]
            isOneToOne: false
            referencedRelation: "custom_roles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_favorites: {
        Row: {
          created_at: string
          icon: string | null
          id: string
          page_path: string
          page_title: string
          user_id: string
        }
        Insert: {
          created_at?: string
          icon?: string | null
          id?: string
          page_path: string
          page_title: string
          user_id: string
        }
        Update: {
          created_at?: string
          icon?: string | null
          id?: string
          page_path?: string
          page_title?: string
          user_id?: string
        }
        Relationships: []
      }
      user_presence: {
        Row: {
          last_seen: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          last_seen?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          last_seen?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vehicle_requests: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          branch_id: string
          created_at: string | null
          destination: string
          employee_id: string | null
          end_date: string
          end_time: string | null
          id: string
          manager_id: string | null
          passengers_count: number | null
          purpose: string | null
          start_date: string
          start_time: string | null
          status: string
          updated_at: string | null
          user_id: string
          vehicle_type: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          branch_id?: string
          created_at?: string | null
          destination: string
          employee_id?: string | null
          end_date: string
          end_time?: string | null
          id?: string
          manager_id?: string | null
          passengers_count?: number | null
          purpose?: string | null
          start_date: string
          start_time?: string | null
          status?: string
          updated_at?: string | null
          user_id: string
          vehicle_type: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          branch_id?: string
          created_at?: string | null
          destination?: string
          employee_id?: string | null
          end_date?: string
          end_time?: string | null
          id?: string
          manager_id?: string | null
          passengers_count?: number | null
          purpose?: string | null
          start_date?: string
          start_time?: string | null
          status?: string
          updated_at?: string | null
          user_id?: string
          vehicle_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_requests_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      video_call_participants: {
        Row: {
          call_id: string
          id: string
          is_host: boolean
          is_recording: boolean
          joined_at: string
          left_at: string | null
          user_id: string
        }
        Insert: {
          call_id: string
          id?: string
          is_host?: boolean
          is_recording?: boolean
          joined_at?: string
          left_at?: string | null
          user_id: string
        }
        Update: {
          call_id?: string
          id?: string
          is_host?: boolean
          is_recording?: boolean
          joined_at?: string
          left_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "video_call_participants_call_id_fkey"
            columns: ["call_id"]
            isOneToOne: false
            referencedRelation: "video_calls"
            referencedColumns: ["id"]
          },
        ]
      }
      video_calls: {
        Row: {
          ended_at: string | null
          id: string
          room_id: string
          started_at: string
          started_by: string
          status: string
        }
        Insert: {
          ended_at?: string | null
          id?: string
          room_id: string
          started_at?: string
          started_by: string
          status?: string
        }
        Update: {
          ended_at?: string | null
          id?: string
          room_id?: string
          started_at?: string
          started_by?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "video_calls_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chat_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      video_tutorials: {
        Row: {
          category: string
          created_at: string | null
          created_by: string | null
          description: string
          duration: string
          id: string
          thumbnail: string | null
          title: string
          updated_at: string | null
          video_url: string
        }
        Insert: {
          category: string
          created_at?: string | null
          created_by?: string | null
          description: string
          duration: string
          id?: string
          thumbnail?: string | null
          title: string
          updated_at?: string | null
          video_url: string
        }
        Update: {
          category?: string
          created_at?: string | null
          created_by?: string | null
          description?: string
          duration?: string
          id?: string
          thumbnail?: string | null
          title?: string
          updated_at?: string | null
          video_url?: string
        }
        Relationships: []
      }
      webrtc_signals: {
        Row: {
          created_at: string
          id: string
          receiver_id: string
          room_id: string
          sender_id: string
          signal_data: Json
          signal_type: string
        }
        Insert: {
          created_at?: string
          id?: string
          receiver_id: string
          room_id: string
          sender_id: string
          signal_data: Json
          signal_type: string
        }
        Update: {
          created_at?: string
          id?: string
          receiver_id?: string
          room_id?: string
          sender_id?: string
          signal_data?: Json
          signal_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "webrtc_signals_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chat_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      wellness_checkins: {
        Row: {
          checkin_date: string
          created_at: string | null
          employee_id: string | null
          id: string
          is_anonymous: boolean | null
          mood_rating: number | null
          notes: string | null
          stress_level: number | null
          work_life_balance: number | null
        }
        Insert: {
          checkin_date: string
          created_at?: string | null
          employee_id?: string | null
          id?: string
          is_anonymous?: boolean | null
          mood_rating?: number | null
          notes?: string | null
          stress_level?: number | null
          work_life_balance?: number | null
        }
        Update: {
          checkin_date?: string
          created_at?: string | null
          employee_id?: string | null
          id?: string
          is_anonymous?: boolean | null
          mood_rating?: number | null
          notes?: string | null
          stress_level?: number | null
          work_life_balance?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "wellness_checkins_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wellness_checkins_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wellness_checkins_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wellness_checkins_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      wellness_survey_responses: {
        Row: {
          employee_id: string | null
          id: string
          responses: Json
          sentiment_score: number | null
          submitted_at: string | null
          survey_id: string | null
        }
        Insert: {
          employee_id?: string | null
          id?: string
          responses: Json
          sentiment_score?: number | null
          submitted_at?: string | null
          survey_id?: string | null
        }
        Update: {
          employee_id?: string | null
          id?: string
          responses?: Json
          sentiment_score?: number | null
          submitted_at?: string | null
          survey_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wellness_survey_responses_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wellness_survey_responses_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wellness_survey_responses_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wellness_survey_responses_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wellness_survey_responses_survey_id_fkey"
            columns: ["survey_id"]
            isOneToOne: false
            referencedRelation: "wellness_surveys"
            referencedColumns: ["id"]
          },
        ]
      }
      wellness_surveys: {
        Row: {
          created_at: string | null
          created_by: string | null
          description: string | null
          end_date: string | null
          id: string
          is_active: boolean | null
          is_anonymous: boolean | null
          questions: Json
          start_date: string | null
          survey_type: string
          title: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          is_active?: boolean | null
          is_anonymous?: boolean | null
          questions: Json
          start_date?: string | null
          survey_type: string
          title: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          is_active?: boolean | null
          is_anonymous?: boolean | null
          questions?: Json
          start_date?: string | null
          survey_type?: string
          title?: string
        }
        Relationships: []
      }
      wiki_page_comments: {
        Row: {
          content: string
          created_at: string
          id: string
          page_id: string
          parent_comment_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          page_id: string
          parent_comment_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          page_id?: string
          parent_comment_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wiki_page_comments_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "wiki_pages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wiki_page_comments_parent_comment_id_fkey"
            columns: ["parent_comment_id"]
            isOneToOne: false
            referencedRelation: "wiki_page_comments"
            referencedColumns: ["id"]
          },
        ]
      }
      wiki_page_versions: {
        Row: {
          change_summary: string | null
          content: string
          created_at: string
          created_by: string | null
          id: string
          page_id: string
          title: string
          version_number: number
        }
        Insert: {
          change_summary?: string | null
          content: string
          created_at?: string
          created_by?: string | null
          id?: string
          page_id: string
          title: string
          version_number: number
        }
        Update: {
          change_summary?: string | null
          content?: string
          created_at?: string
          created_by?: string | null
          id?: string
          page_id?: string
          title?: string
          version_number?: number
        }
        Relationships: [
          {
            foreignKeyName: "wiki_page_versions_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "wiki_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      wiki_pages: {
        Row: {
          content: string
          created_at: string
          created_by: string | null
          excerpt: string | null
          id: string
          is_pinned: boolean
          parent_id: string | null
          published_at: string | null
          slug: string
          sort_order: number
          space_id: string
          status: string
          tags: string[]
          title: string
          updated_at: string
          updated_by: string | null
          view_count: number
        }
        Insert: {
          content?: string
          created_at?: string
          created_by?: string | null
          excerpt?: string | null
          id?: string
          is_pinned?: boolean
          parent_id?: string | null
          published_at?: string | null
          slug: string
          sort_order?: number
          space_id: string
          status?: string
          tags?: string[]
          title: string
          updated_at?: string
          updated_by?: string | null
          view_count?: number
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string | null
          excerpt?: string | null
          id?: string
          is_pinned?: boolean
          parent_id?: string | null
          published_at?: string | null
          slug?: string
          sort_order?: number
          space_id?: string
          status?: string
          tags?: string[]
          title?: string
          updated_at?: string
          updated_by?: string | null
          view_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "wiki_pages_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "wiki_pages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wiki_pages_space_id_fkey"
            columns: ["space_id"]
            isOneToOne: false
            referencedRelation: "wiki_spaces"
            referencedColumns: ["id"]
          },
        ]
      }
      wiki_spaces: {
        Row: {
          color: string | null
          created_at: string
          created_by: string | null
          description: string | null
          icon: string | null
          id: string
          key: string
          name: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          icon?: string | null
          id?: string
          key: string
          name: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          color?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          icon?: string | null
          id?: string
          key?: string
          name?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      work_schedules: {
        Row: {
          break_duration: number | null
          created_at: string
          created_by: string | null
          effective_from: string
          effective_to: string | null
          employee_id: string
          end_time: string | null
          id: string
          no_break: boolean | null
          schedule_type: string
          start_time: string | null
          template_id: string | null
          updated_at: string
          working_hours_per_week: number | null
        }
        Insert: {
          break_duration?: number | null
          created_at?: string
          created_by?: string | null
          effective_from: string
          effective_to?: string | null
          employee_id: string
          end_time?: string | null
          id?: string
          no_break?: boolean | null
          schedule_type?: string
          start_time?: string | null
          template_id?: string | null
          updated_at?: string
          working_hours_per_week?: number | null
        }
        Update: {
          break_duration?: number | null
          created_at?: string
          created_by?: string | null
          effective_from?: string
          effective_to?: string | null
          employee_id?: string
          end_time?: string | null
          id?: string
          no_break?: boolean | null
          schedule_type?: string
          start_time?: string | null
          template_id?: string | null
          updated_at?: string
          working_hours_per_week?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "work_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_schedules_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_schedules_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "schedule_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      work_time_form_generations: {
        Row: {
          created_at: string
          employee_id: string
          file_url: string | null
          form_type: string
          generated_at: string
          id: string
          month: number
          sent_at: string | null
          sent_via: string | null
          status: string
          updated_at: string
          year: number
        }
        Insert: {
          created_at?: string
          employee_id: string
          file_url?: string | null
          form_type?: string
          generated_at?: string
          id?: string
          month: number
          sent_at?: string | null
          sent_via?: string | null
          status?: string
          updated_at?: string
          year: number
        }
        Update: {
          created_at?: string
          employee_id?: string
          file_url?: string | null
          form_type?: string
          generated_at?: string
          id?: string
          month?: number
          sent_at?: string | null
          sent_via?: string | null
          status?: string
          updated_at?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "work_time_form_generations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_time_form_generations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_time_form_generations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "work_time_form_generations_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
      workflow_runs: {
        Row: {
          context: Json
          error: string | null
          finished_at: string | null
          id: string
          logs: Json
          started_at: string
          status: string
          triggered_by: string | null
          workflow_id: string
        }
        Insert: {
          context?: Json
          error?: string | null
          finished_at?: string | null
          id?: string
          logs?: Json
          started_at?: string
          status?: string
          triggered_by?: string | null
          workflow_id: string
        }
        Update: {
          context?: Json
          error?: string | null
          finished_at?: string | null
          id?: string
          logs?: Json
          started_at?: string
          status?: string
          triggered_by?: string | null
          workflow_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workflow_runs_workflow_id_fkey"
            columns: ["workflow_id"]
            isOneToOne: false
            referencedRelation: "workflows"
            referencedColumns: ["id"]
          },
        ]
      }
      workflows: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          graph: Json
          id: string
          is_active: boolean
          name: string
          schedule_cron: string | null
          trigger_config: Json
          trigger_type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          graph?: Json
          id?: string
          is_active?: boolean
          name: string
          schedule_cron?: string | null
          trigger_config?: Json
          trigger_type?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          graph?: Json
          id?: string
          is_active?: boolean
          name?: string
          schedule_cron?: string | null
          trigger_config?: Json
          trigger_type?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      department_hierarchy: {
        Row: {
          budget: number | null
          id: string | null
          level: number | null
          manager_id: string | null
          name: string | null
          parent_department_id: string | null
          path: string[] | null
        }
        Relationships: []
      }
      employee_feedback_safe_view: {
        Row: {
          ai_recommendation: string | null
          created_at: string | null
          description: string | null
          employee_id: string | null
          hr_notes: string | null
          id: string | null
          is_anonymous: boolean | null
          manager_notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: Database["public"]["Enums"]["feedback_status"] | null
          subject: string | null
          type: Database["public"]["Enums"]["feedback_type"] | null
          updated_at: string | null
        }
        Insert: {
          ai_recommendation?: string | null
          created_at?: string | null
          description?: string | null
          employee_id?: never
          hr_notes?: string | null
          id?: string | null
          is_anonymous?: boolean | null
          manager_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["feedback_status"] | null
          subject?: string | null
          type?: Database["public"]["Enums"]["feedback_type"] | null
          updated_at?: string | null
        }
        Update: {
          ai_recommendation?: string | null
          created_at?: string | null
          description?: string | null
          employee_id?: never
          hr_notes?: string | null
          id?: string | null
          is_anonymous?: boolean | null
          manager_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["feedback_status"] | null
          subject?: string | null
          type?: Database["public"]["Enums"]["feedback_type"] | null
          updated_at?: string | null
        }
        Relationships: []
      }
      employees_directory: {
        Row: {
          avatar_url: string | null
          department: string | null
          email: string | null
          full_name: string | null
          hire_date: string | null
          id: string | null
          last_name: string | null
          position: string | null
          status: string | null
        }
        Insert: {
          avatar_url?: string | null
          department?: string | null
          email?: string | null
          full_name?: string | null
          hire_date?: string | null
          id?: string | null
          last_name?: string | null
          position?: string | null
          status?: string | null
        }
        Update: {
          avatar_url?: string | null
          department?: string | null
          email?: string | null
          full_name?: string | null
          hire_date?: string | null
          id?: string | null
          last_name?: string | null
          position?: string | null
          status?: string | null
        }
        Relationships: []
      }
      employees_manager_view: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          date_of_birth: string | null
          department: string | null
          email: string | null
          full_name: string | null
          gender: string | null
          hire_date: string | null
          id: string | null
          last_name: string | null
          phone_number: string | null
          position: string | null
          salary: number | null
          status: string | null
          termination_date: string | null
          updated_at: string | null
          user_id: string | null
          work_schedule_id: string | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          date_of_birth?: string | null
          department?: string | null
          email?: string | null
          full_name?: string | null
          gender?: string | null
          hire_date?: string | null
          id?: string | null
          last_name?: string | null
          phone_number?: string | null
          position?: string | null
          salary?: number | null
          status?: string | null
          termination_date?: string | null
          updated_at?: string | null
          user_id?: string | null
          work_schedule_id?: string | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          date_of_birth?: string | null
          department?: string | null
          email?: string | null
          full_name?: string | null
          gender?: string | null
          hire_date?: string | null
          id?: string | null
          last_name?: string | null
          phone_number?: string | null
          position?: string | null
          salary?: number | null
          status?: string | null
          termination_date?: string | null
          updated_at?: string | null
          user_id?: string | null
          work_schedule_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "employees_work_schedule_id_fkey"
            columns: ["work_schedule_id"]
            isOneToOne: false
            referencedRelation: "schedule_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      employees_public_directory: {
        Row: {
          avatar_url: string | null
          department: string | null
          employee_number: string | null
          full_name: string | null
          gender: string | null
          hire_date: string | null
          id: string | null
          last_name: string | null
          position: string | null
          status: string | null
        }
        Insert: {
          avatar_url?: string | null
          department?: string | null
          employee_number?: string | null
          full_name?: string | null
          gender?: string | null
          hire_date?: string | null
          id?: string | null
          last_name?: string | null
          position?: string | null
          status?: string | null
        }
        Update: {
          avatar_url?: string | null
          department?: string | null
          employee_number?: string | null
          full_name?: string | null
          gender?: string | null
          hire_date?: string | null
          id?: string | null
          last_name?: string | null
          position?: string | null
          status?: string | null
        }
        Relationships: []
      }
      hr_metrics: {
        Row: {
          absent_today: number | null
          active_employees: number | null
          applications_last_30_days: number | null
          avg_time_to_fill: number | null
          employees_on_leave: number | null
          employees_on_leave_now: number | null
          filled_vacancies_last_30_days: number | null
          hired_last_30_days: number | null
          late_today: number | null
          new_hires_last_30_days: number | null
          open_vacancies: number | null
          pending_leave_requests: number | null
          present_today: number | null
          terminations_last_30_days: number | null
        }
        Relationships: []
      }
      integration_settings_safe: {
        Row: {
          client_id: string | null
          client_secret_masked: string | null
          created_at: string | null
          created_by: string | null
          id: string | null
          is_active: boolean | null
          provider: string | null
          settings: Json | null
          updated_at: string | null
        }
        Insert: {
          client_id?: string | null
          client_secret_masked?: never
          created_at?: string | null
          created_by?: string | null
          id?: string | null
          is_active?: boolean | null
          provider?: string | null
          settings?: Json | null
          updated_at?: string | null
        }
        Update: {
          client_id?: string | null
          client_secret_masked?: never
          created_at?: string | null
          created_by?: string | null
          id?: string | null
          is_active?: boolean | null
          provider?: string | null
          settings?: Json | null
          updated_at?: string | null
        }
        Relationships: []
      }
      leave_requests_manager_view: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string | null
          custom_fields: Json | null
          deleted_at: string | null
          document_file_name: string | null
          document_url: string | null
          employee_id: string | null
          end_date: string | null
          id: string | null
          leave_type: string | null
          leave_type_id: string | null
          manager_id: string | null
          reason: string | null
          replacement_employee_id: string | null
          sick_leave_certificate_number: string | null
          sick_leave_compensation_percentage: number | null
          sick_leave_end_date: string | null
          sick_leave_issue_date: string | null
          sick_leave_start_date: string | null
          start_date: string | null
          status: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string | null
          custom_fields?: never
          deleted_at?: string | null
          document_file_name?: never
          document_url?: never
          employee_id?: string | null
          end_date?: string | null
          id?: string | null
          leave_type?: string | null
          leave_type_id?: string | null
          manager_id?: string | null
          reason?: never
          replacement_employee_id?: string | null
          sick_leave_certificate_number?: never
          sick_leave_compensation_percentage?: never
          sick_leave_end_date?: never
          sick_leave_issue_date?: never
          sick_leave_start_date?: never
          start_date?: string | null
          status?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string | null
          custom_fields?: never
          deleted_at?: string | null
          document_file_name?: never
          document_url?: never
          employee_id?: string | null
          end_date?: string | null
          id?: string | null
          leave_type?: string | null
          leave_type_id?: string | null
          manager_id?: string | null
          reason?: never
          replacement_employee_id?: string | null
          sick_leave_certificate_number?: never
          sick_leave_compensation_percentage?: never
          sick_leave_end_date?: never
          sick_leave_issue_date?: never
          sick_leave_start_date?: never
          start_date?: string | null
          status?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "leave_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_leave_type_id_fkey"
            columns: ["leave_type_id"]
            isOneToOne: false
            referencedRelation: "leave_types"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_replacement_employee_id_fkey"
            columns: ["replacement_employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_replacement_employee_id_fkey"
            columns: ["replacement_employee_id"]
            isOneToOne: false
            referencedRelation: "employees_directory"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_replacement_employee_id_fkey"
            columns: ["replacement_employee_id"]
            isOneToOne: false
            referencedRelation: "employees_manager_view"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leave_requests_replacement_employee_id_fkey"
            columns: ["replacement_employee_id"]
            isOneToOne: false
            referencedRelation: "employees_public_directory"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      analytics_query: { Args: { query: string }; Returns: Json }
      apply_scheduled_employee_changes: { Args: never; Returns: Json }
      archive_old_attendance: { Args: never; Returns: Json }
      archive_old_audit_logs: { Args: never; Returns: Json }
      award_points: {
        Args: {
          _amount: number
          _employee_id: string
          _reason?: string
          _reason_type: string
          _reference_id?: string
        }
        Returns: undefined
      }
      bootstrap_admin_role: { Args: { p_user_id: string }; Returns: boolean }
      can_view_employee: {
        Args: { target_employee_id: string }
        Returns: boolean
      }
      can_view_employee_sensitive: {
        Args: { emp_id: string }
        Returns: boolean
      }
      can_view_leave_request_details: {
        Args: { _employee_id: string; _user_id: string }
        Returns: boolean
      }
      can_view_sensitive_employee_data: {
        Args: { target_employee_id: string }
        Returns: boolean
      }
      can_view_task: {
        Args: {
          _task: Database["public"]["Tables"]["tasks"]["Row"]
          _user_id: string
        }
        Returns: boolean
      }
      check_and_award_badges: {
        Args: { _employee_id: string }
        Returns: undefined
      }
      check_annual_leave_balance: {
        Args: { emp_id: string; year_to_check?: number }
        Returns: {
          employee_id: string
          remaining: number
          total_allocated: number
          total_used: number
        }[]
      }
      check_login_anomaly: {
        Args: { p_email: string; p_ip_address: string; p_user_id: string }
        Returns: Json
      }
      check_password_strength: { Args: { password: string }; Returns: Json }
      check_unsigned_documents: { Args: never; Returns: undefined }
      cleanup_old_audit_logs: { Args: never; Returns: Json }
      clear_demo_data: { Args: never; Returns: Json }
      create_audit_log: {
        Args: {
          _action_type: string
          _details?: Json
          _resource_id?: string
          _resource_type: string
          _status?: string
        }
        Returns: string
      }
      default_branch_id: { Args: never; Returns: string }
      delete_employees_permanently: {
        Args: { p_ids: string[] }
        Returns: {
          user_id: string
        }[]
      }
      generate_employee_number: { Args: never; Returns: string }
      get_ai_cache: { Args: { p_cache_key: string }; Returns: Json }
      get_current_employee_id: { Args: never; Returns: string }
      get_current_user_email: { Args: never; Returns: string }
      get_default_branch_id: { Args: never; Returns: string }
      get_employee_department_manager: {
        Args: { emp_id: string }
        Returns: string
      }
      get_employee_directory: {
        Args: never
        Returns: {
          emp_department: string
          emp_full_name: string
          emp_id: string
          emp_position: string
        }[]
      }
      get_employee_payroll_admin: {
        Args: { p_employee_id: string; p_year?: number }
        Returns: {
          base_salary: number
          bonuses: number
          created_at: string
          deductions: number
          employee_id: string
          id: string
          month: number
          net_salary: number
          payment_date: string
          payment_status: string
          tax_amount: number
          year: number
        }[]
      }
      get_employee_protected_fields: {
        Args: { p_employee_id: string }
        Returns: {
          bank_account_number: string
          department: string
          employee_number: string
          hire_date: string
          hourly_rate: number
          personal_id: string
          position: string
          salary: number
          status: string
        }[]
      }
      get_integration_secret: { Args: { p_provider: string }; Returns: string }
      get_my_payroll_records: {
        Args: { p_month?: number; p_year?: number }
        Returns: {
          base_salary: number
          bonuses: number
          created_at: string
          deductions: number
          employee_id: string
          id: string
          month: number
          net_salary: number
          payment_date: string
          payment_status: string
          tax_amount: number
          year: number
        }[]
      }
      get_public_table_names: { Args: never; Returns: Json }
      get_user_branches: { Args: { _user_id: string }; Returns: string[] }
      get_user_email_by_id: {
        Args: { target_user_id: string }
        Returns: string
      }
      get_user_primary_branch: { Args: { _user_id: string }; Returns: string }
      get_users_by_role: {
        Args: { role_name: string }
        Returns: {
          id: string
        }[]
      }
      has_any_admin: { Args: never; Returns: boolean }
      has_custom_permission: {
        Args: { _permission_key: string; _user_id: string }
        Returns: boolean
      }
      has_feature: {
        Args: { _company_id: string; _feature_key: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_department_manager_of: {
        Args: { _employee_id: string }
        Returns: boolean
      }
      is_manager_of_employee: {
        Args: { _employee_id: string; _user_id: string }
        Returns: boolean
      }
      is_user_in_room: {
        Args: { _room_id: string; _user_id: string }
        Returns: boolean
      }
      load_test_db_stats: { Args: never; Returns: Json }
      log_disciplinary_record_view: {
        Args: { p_employee_id: string; p_record_id: string }
        Returns: undefined
      }
      log_login_with_anomaly_check: {
        Args: {
          p_city?: string
          p_country?: string
          p_email: string
          p_ip_address: string
          p_user_agent: string
          p_user_id: string
        }
        Returns: Json
      }
      log_security_event: {
        Args: {
          p_description: string
          p_event_type: string
          p_metadata?: Json
          p_severity: string
          p_user_id?: string
        }
        Returns: string
      }
      log_sensitive_data_access: {
        Args: {
          p_access_type?: string
          p_fields?: string[]
          p_record_id?: string
          p_table: string
        }
        Returns: undefined
      }
      mark_password_changed: { Args: never; Returns: undefined }
      redeem_reward: { Args: { _reward_id: string }; Returns: Json }
      refresh_salary_benchmarks: {
        Args: never
        Returns: {
          categories_skipped: number
          categories_updated: number
        }[]
      }
      restore_deleted_record: {
        Args: { p_record_id: string; p_table_name: string }
        Returns: boolean
      }
      run_workflow: { Args: { p_workflow_id: string }; Returns: Json }
      run_workflow_impl: { Args: { p_workflow_id: string }; Returns: Json }
      run_workflows: { Args: never; Returns: Json }
      run_workflows_impl: { Args: never; Returns: Json }
      search_knowledge_base: {
        Args: {
          max_results?: number
          search_category?: string
          search_language?: string
          search_query: string
        }
        Returns: {
          category: string
          content: string
          id: string
          relevance: number
          tags: string[]
          title: string
        }[]
      }
      seed_demo_data: { Args: never; Returns: Json }
      seed_tenant_defaults: {
        Args: { p_company_id: string; p_user_id: string }
        Returns: Json
      }
      set_ai_cache: {
        Args: {
          p_cache_key: string
          p_function_name: string
          p_model?: string
          p_prompt_hash: string
          p_response: Json
          p_ttl_hours?: number
        }
        Returns: undefined
      }
      soft_delete_record: {
        Args: { p_record_id: string; p_table_name: string }
        Returns: boolean
      }
      user_has_branch_access: {
        Args: { _branch_id: string; _user_id: string }
        Returns: boolean
      }
      validate_password_strength: {
        Args: { password: string }
        Returns: boolean
      }
      verify_push_secret: { Args: { _secret: string }; Returns: boolean }
      workflow_tpl: { Args: { _data: Json; _tpl: string }; Returns: string }
    }
    Enums: {
      app_role: "admin" | "hr_manager" | "employee" | "department_manager"
      feedback_status: "pending" | "in_review" | "resolved" | "dismissed"
      feedback_type: "complaint" | "concern" | "idea"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "hr_manager", "employee", "department_manager"],
      feedback_status: ["pending", "in_review", "resolved", "dismissed"],
      feedback_type: ["complaint", "concern", "idea"],
    },
  },
} as const
