import { describe, it, expect } from "vitest";
import { selectRows, buildCsv, RSGE_COLUMNS } from "./rsgeRegistry";

const ok = { id: "1", full_name: "ნინო ბერიძე", last_name: "ბერიძე", personal_id: "01001012345", position: "მენეჯერი", hire_date: "2026-10-05", termination_date: null, salary: 1500 };
const gone = { ...ok, id: "2", hire_date: "2020-01-01", termination_date: "2026-10-20" };

describe("rsgeRegistry", () => {
  it("selects hires and terminations only inside the period", () => {
    const rows = selectRows([ok, gone], "both", "2026-10-01", "2026-10-31");
    expect(rows.map((r) => r.event)).toEqual(["hire", "termination"]);
    expect(selectRows([ok, gone], "hire", "2026-10-01", "2026-10-31")).toHaveLength(1);
    expect(selectRows([ok], "both", "2026-11-01", "2026-11-30")).toHaveLength(0);
  });

  it("flags personal ID that is not 11 digits and missing position", () => {
    const [r] = selectRows([{ ...ok, personal_id: "123", position: "" }], "hire", "2026-10-01", "2026-10-31");
    expect(r.errors).toEqual(["personal_id", "position"]);
  });

  it("excludes invalid rows from CSV and keeps column order", () => {
    const csv = buildCsv(selectRows([ok, { ...ok, id: "3", personal_id: null }], "hire", "2026-10-01", "2026-10-31"));
    const lines = csv.replace("\uFEFF", "").split("\r\n");
    expect(lines[0]).toBe(RSGE_COLUMNS.join(","));
    expect(lines).toHaveLength(2);
    expect(lines[1]).toBe("01001012345,ნინო,ბერიძე,დანიშვნა,2026-10-05,მენეჯერი,1500");
  });
});
