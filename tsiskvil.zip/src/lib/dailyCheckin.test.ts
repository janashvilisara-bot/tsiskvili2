import { describe, it, expect } from "vitest";
import { shouldAskCheckin, localDateKey } from "./dailyCheckin";

describe("daily anonymous check-in rule", () => {
  const now = new Date(2026, 9, 14, 22, 0);

  it("asks when never filled", () => {
    expect(shouldAskCheckin(null, now)).toBe(true);
  });

  it("does not ask again on the same day", () => {
    expect(shouldAskCheckin(localDateKey(now), now)).toBe(false);
  });

  it("asks again the next day", () => {
    expect(shouldAskCheckin("2026-10-13", now)).toBe(true);
  });
});
