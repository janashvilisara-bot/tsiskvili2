/**
 * ცენტრალური ფინანსური გამოთვლების ბიბლიოთეკა
 * ყველა ფინანსური გამოთვლა ერთ ადგილას - დუბლირების გარეშე
 */

// ==================== კონსტანტები ====================

export const FINANCIAL_CONSTANTS = {
  // საპენსიო გადასახადები (ქართული კანონმდებლობა 2025)
  PENSION_EMPLOYEE_RATE: 0.02, // 2% თანამშრომელი
  PENSION_EMPLOYER_RATE: 0.02, // 2% დამსაქმებელი

  // სახელმწიფოს თანამონაწილეობის წლიური შემოსავლის ზღვრები
  // "დაგროვებითი პენსიის შესახებ" კანონის მუხლი 22
  PENSION_STATE_TIER1_LIMIT: 24000, // <24,000 ₾ წლიური → 2%
  PENSION_STATE_TIER2_LIMIT: 60000, // 24,000–60,000 ₾ → 1%
  PENSION_STATE_TIER1_RATE: 0.02,
  PENSION_STATE_TIER2_RATE: 0.01,
  PENSION_STATE_TIER3_RATE: 0,
  PENSION_ANNUAL_BASE_CAP: 60000, // საპენსიო შენატანის ბაზის ზღვარი
  
  // საშემოსავლო გადასახადი
  INCOME_TAX_RATE: 0.20, // 20% ფლეტ რეიტი
  
  // ზეგანაკვეთური კოეფიციენტები (ქართული შრომის კოდექსი)
  OVERTIME_MULTIPLIER: 1.25, // სტანდარტული ზეგანაკვეთური (მუხ. 27 - 125%)
  HOLIDAY_OVERTIME_MULTIPLIER: 1.5, // დღესასწაულის ზეგანაკვეთური (მუხ. 30 - 150%)
  
  // საპენსიო ასაკის ლიმიტები
  PENSION_MAX_AGE_MALE: 65,
  PENSION_MAX_AGE_FEMALE: 60,
  
  // სამუშაო საათები
  STANDARD_MONTHLY_HOURS: 160, // სტანდარტული 40 საათიანი კვირის თვე
  STANDARD_DAILY_HOURS: 8, // სტანდარტული სამუშაო დღე
  WORKING_DAYS_PER_MONTH: 20, // საშუალო სამუშაო დღეები თვეში
} as const;

// ==================== ინტერფეისები ====================

export interface PensionContribution {
  employeeContribution: number;
  employerContribution: number;
  stateContribution: number;
  stateRate: number;
  totalAmount: number;
}

export interface HolidayOvertimeCalculation {
  hours: number;
  multiplier: number;
  bonus: number;
}

export interface PayrollCalculation {
  baseSalary: number;
  totalBonuses: number;
  totalDeductions: number;
  grossSalary: number;
  netSalary: number;
  pensionEmployee: number;
  pensionEmployer: number;
  incomeTax: number;
  hourlyRate: number;
  benefitsDeduction: number;
}

export interface Attendance {
  date: string;
  check_in: string | null;
  check_out: string | null;
  overtime_hours?: number | null;
}

export interface PublicHoliday {
  holiday_date: string;
  overtime_multiplier?: number | null;
  is_recurring?: boolean;
}

// ==================== ძირითადი გამოთვლები ====================

/**
 * საათობრივი განაკვეთის გამოთვლა
 */
export function calculateHourlyRate(
  baseSalary: number,
  monthlyHours: number = FINANCIAL_CONSTANTS.STANDARD_MONTHLY_HOURS
): number {
  if (monthlyHours <= 0) return 0;
  return baseSalary / monthlyHours;
}

/**
 * საპენსიო გადასახადის გამოთვლა
 * @param grossIncome - მთლიანი შემოსავალი (ბაზა + ბონუსები)
 * @param options - ასაკი და სქესი საპენსიო ასაკის შემოწმებისთვის
 */
export function calculatePensionContribution(
  grossIncome: number,
  options?: { age?: number; gender?: 'male' | 'female'; annualIncome?: number }
): PensionContribution {
  // საპენსიო ასაკს გადაცილებული თანამშრომლები თავისუფლდებიან
  if (options?.age && options?.gender) {
    const maxAge = options.gender === 'male'
      ? FINANCIAL_CONSTANTS.PENSION_MAX_AGE_MALE
      : FINANCIAL_CONSTANTS.PENSION_MAX_AGE_FEMALE;
    if (options.age > maxAge) {
      return {
        employeeContribution: 0,
        employerContribution: 0,
        stateContribution: 0,
        stateRate: 0,
        totalAmount: 0,
      };
    }
  }

  // საფუძველი არ აღემატება წლიურ 60,000 ₾ ლიმიტს (პროპორციულად თვიური 5,000 ₾)
  const monthlyCap = FINANCIAL_CONSTANTS.PENSION_ANNUAL_BASE_CAP / 12;
  const cappedBase = Math.min(grossIncome, monthlyCap);

  const employeeContribution = cappedBase * FINANCIAL_CONSTANTS.PENSION_EMPLOYEE_RATE;
  const employerContribution = cappedBase * FINANCIAL_CONSTANTS.PENSION_EMPLOYER_RATE;

  // სახელმწიფოს თანამონაწილეობის % წლიური შემოსავლის მიხედვით
  const annualIncome = options?.annualIncome ?? grossIncome * 12;
  let stateRate: number;
  if (annualIncome < FINANCIAL_CONSTANTS.PENSION_STATE_TIER1_LIMIT) {
    stateRate = FINANCIAL_CONSTANTS.PENSION_STATE_TIER1_RATE;
  } else if (annualIncome <= FINANCIAL_CONSTANTS.PENSION_STATE_TIER2_LIMIT) {
    stateRate = FINANCIAL_CONSTANTS.PENSION_STATE_TIER2_RATE;
  } else {
    stateRate = FINANCIAL_CONSTANTS.PENSION_STATE_TIER3_RATE;
  }
  const stateContribution = cappedBase * stateRate;

  return {
    employeeContribution,
    employerContribution,
    stateContribution,
    stateRate,
    totalAmount: employeeContribution + employerContribution + stateContribution,
  };
}

/**
 * სახელმწიფოს თანამონაწილეობის წილის გამოთვლა წლიური შემოსავლის მიხედვით
 */
export function getPensionStateRate(annualIncome: number): number {
  if (annualIncome < FINANCIAL_CONSTANTS.PENSION_STATE_TIER1_LIMIT) {
    return FINANCIAL_CONSTANTS.PENSION_STATE_TIER1_RATE;
  }
  if (annualIncome <= FINANCIAL_CONSTANTS.PENSION_STATE_TIER2_LIMIT) {
    return FINANCIAL_CONSTANTS.PENSION_STATE_TIER2_RATE;
  }
  return FINANCIAL_CONSTANTS.PENSION_STATE_TIER3_RATE;
}

/**
 * საშემოსავლო გადასახადის გამოთვლა (20% ნებისმიერ თანხაზე)
 */
export function calculateIncomeTax(grossIncome: number): number {
  if (grossIncome <= 0) return 0;
  
  return grossIncome * FINANCIAL_CONSTANTS.INCOME_TAX_RATE;
}

/**
 * ზეგანაკვეთური ბონუსის გამოთვლა
 */
export function calculateOvertimeBonus(
  hours: number,
  hourlyRate: number,
  multiplier: number = FINANCIAL_CONSTANTS.OVERTIME_MULTIPLIER
): number {
  return hours * hourlyRate * multiplier;
}

/**
 * წმინდა ხელფასის გამოთვლა
 */
export function calculateNetSalary(
  baseSalary: number,
  bonuses: number,
  deductions: number
): number {
  return baseSalary + bonuses - deductions;
}

/**
 * დღესასწაულის ზეგანაკვეთური საათების გამოთვლა
 */
export function calculateHolidayOvertimeHours(
  attendance: Attendance[],
  holidays: PublicHoliday[]
): HolidayOvertimeCalculation[] {
  const holidayDates = new Set(holidays.map(h => h.holiday_date));
  const results: HolidayOvertimeCalculation[] = [];

  attendance.forEach((att) => {
    const matchingHoliday = holidays.find(holiday => {
      if (holiday.is_recurring) {
        const holidayMonthDay = holiday.holiday_date.substring(5);
        const attendanceMonthDay = att.date.substring(5);
        return holidayMonthDay === attendanceMonthDay;
      }
      return holiday.holiday_date === att.date;
    });

    if (matchingHoliday && att.check_in && att.check_out) {
      const hours = calculateWorkedHours(att.check_in, att.check_out);
      const multiplier = matchingHoliday.overtime_multiplier || FINANCIAL_CONSTANTS.HOLIDAY_OVERTIME_MULTIPLIER;
      
      results.push({
        hours: hours * multiplier,
        multiplier,
        bonus: 0, // will be calculated with hourly rate
      });
    }
  });

  return results;
}

/**
 * დამუშავებული საათების გამოთვლა check-in/check-out-დან
 */
export function calculateWorkedHours(checkIn: string, checkOut: string): number {
  if (!checkIn || !checkOut) return 0;
  
  const [inHours, inMinutes] = checkIn.split(':').map(Number);
  const [outHours, outMinutes] = checkOut.split(':').map(Number);
  
  const totalMinutes = (outHours * 60 + outMinutes) - (inHours * 60 + inMinutes);
  return totalMinutes / 60;
}

/**
 * სრული ხელფასის გამოთვლა (ყველა კომპონენტით)
 */
export function calculateFullPayroll(params: {
  baseSalary: number;
  manualBonuses?: number;
  manualDeductions?: number;
  /** ჩვეულებრივი ზეგანაკვეთური საათები (raw) - ფუნქცია თვითონ გაამრავლებს 1.25-ზე */
  overtimeHours?: number;
  /**
   * დღესასწაულის ზეგანაკვეთური საათები - უკვე *შეწონილი* (multiplier უკვე გათვალისწინებული).
   * caller-ი თვითონ ამრავლებს raw საათებს holiday.overtime_multiplier-ზე (default 1.5)
   * და გადასცემს შედეგს. ეს ფუნქცია მხოლოდ hourlyRate-ზე ამრავლებს (multiplier=1),
   * რომ თავიდან ავიცილოთ ორმაგი გამრავლება (double-multiplication bug fix).
   */
  holidayOvertimeHours?: number;
  hasPension?: boolean;
  benefitsDeduction?: number;
  employeeAge?: number;
  employeeGender?: 'male' | 'female';
}): PayrollCalculation {
  const {
    baseSalary,
    manualBonuses = 0,
    manualDeductions = 0,
    overtimeHours = 0,
    holidayOvertimeHours = 0,
    hasPension = true,
    benefitsDeduction = 0,
    employeeAge,
    employeeGender,
  } = params;

  // საათობრივი განაკვეთი - ფიქსირებული salary/160
  const hourlyRate = calculateHourlyRate(baseSalary);

  // ჩვეულებრივი ზეგანაკვეთური (მუხ. 27 - 125%)
  const overtimeBonus = calculateOvertimeBonus(overtimeHours, hourlyRate);
  // დღესასწაულის ზეგანაკვეთური - საათები უკვე შეწონილია caller-ში (მუხ. 30),
  // ამიტომ აქ multiplier=1 (თავიდან ვაცილებთ double-multiplication bug-ს).
  const holidayOvertimeBonus = holidayOvertimeHours * hourlyRate;

  // ჯამური ბონუსები
  const totalBonuses = manualBonuses + overtimeBonus + holidayOvertimeBonus;

  // მთლიანი შემოსავალი (გადასახადამდე)
  const grossSalary = baseSalary + totalBonuses;

  // პენსია - ითვლება მთლიან შემოსავალზე, ასაკის შემოწმებით
  const pension = hasPension ? calculatePensionContribution(grossSalary, {
    age: employeeAge,
    gender: employeeGender,
  }) : {
    employeeContribution: 0,
    employerContribution: 0,
    stateContribution: 0,
    stateRate: 0,
    totalAmount: 0,
  };

  // დასაბეგრი შემოსავალი (მთლიანი შემოსავალი - პენსია)
  const taxableIncome = grossSalary - pension.employeeContribution;

  // საშემოსავლო გადასახადი - 20% ფლეტ რეიტი პენსიის შემდეგ
  const incomeTax = calculateIncomeTax(taxableIncome);

  // ჯამური დაქვითვები
  const totalDeductions = manualDeductions + pension.employeeContribution + incomeTax + benefitsDeduction;

  // წმინდა ხელფასი
  const netSalary = calculateNetSalary(baseSalary, totalBonuses, totalDeductions);

  return {
    baseSalary,
    totalBonuses,
    totalDeductions,
    grossSalary,
    netSalary,
    pensionEmployee: pension.employeeContribution,
    pensionEmployer: pension.employerContribution,
    incomeTax,
    hourlyRate,
    benefitsDeduction,
  };
}

/**
 * დღესასწაულის ზეგანაკვეთური ბონუსის გამოთვლა
 */
export function calculateHolidayOvertimeBonus(
  attendance: Attendance[],
  holidays: PublicHoliday[],
  hourlyRate: number
): { hours: number; bonus: number } {
  let totalHours = 0;

  attendance.forEach((att) => {
    const matchingHoliday = holidays.find(holiday => {
      if (holiday.is_recurring) {
        const holidayMonthDay = holiday.holiday_date.substring(5);
        const attendanceMonthDay = att.date.substring(5);
        return holidayMonthDay === attendanceMonthDay;
      }
      return holiday.holiday_date === att.date;
    });

    if (matchingHoliday && att.check_in && att.check_out) {
      const hours = calculateWorkedHours(att.check_in, att.check_out);
      const multiplier = matchingHoliday.overtime_multiplier || FINANCIAL_CONSTANTS.HOLIDAY_OVERTIME_MULTIPLIER;
      totalHours += hours * multiplier;
    }
  });

  return {
    hours: totalHours,
    bonus: totalHours * hourlyRate,
  };
}

/**
 * დეკრეტული/ავადმყოფობის გადახდის გამოთვლა
 * საათობრივ ანაზღაურებაზე მყოფი თანამშრომლებისთვის გამოიყენება
 * წინა 3 თვის საშუალო ანაზღაურება (საქართველოს შრომის კოდექსი)
 */
export function calculateLeavePayment(
  baseSalary: number,
  days: number,
  leaveType: 'maternity' | 'paternity' | 'sick' | 'annual',
  options?: {
    isHourly?: boolean;
    lastThreeMonthsEarnings?: number[]; // ბოლო 3 თვის შემოსავლები
  }
): number {
  let effectiveMonthlySalary = baseSalary;

  // საათობრივი თანამშრომლისთვის - ბოლო 3 თვის საშუალო
  if (options?.isHourly && options?.lastThreeMonthsEarnings?.length) {
    const earnings = options.lastThreeMonthsEarnings;
    const totalEarnings = earnings.reduce((sum, e) => sum + e, 0);
    effectiveMonthlySalary = totalEarnings / earnings.length;
  }

  const dailyRate = effectiveMonthlySalary / 30;
  
  switch (leaveType) {
    case 'sick':
      return dailyRate * days * 0.7; // 70% ავადმყოფობისთვის
    case 'maternity':
    case 'paternity':
    case 'annual':
      return dailyRate * days; // 100% დეკრეტული/შვებულებისთვის
    default:
      return dailyRate * days;
  }
}

/**
 * საათობრივი თანამშრომლის ბოლო 3 თვის შემოსავლების გამოთვლა
 * payroll ჩანაწერებიდან
 */
export function calculateLastThreeMonthsEarnings(
  payrollRecords: Array<{ month: number; year: number; gross_salary: number }>
): number[] {
  // დალაგება თარიღით კლებადობით და ბოლო 3 თვის აღება
  const sorted = [...payrollRecords]
    .sort((a, b) => {
      if (a.year !== b.year) return b.year - a.year;
      return b.month - a.month;
    })
    .slice(0, 3);

  return sorted.map(r => r.gross_salary);
}

/**
 * შვებულების დღეების გამოთვლა
 */
export function calculateLeaveDays(startDate: string, endDate: string): number {
  if (!startDate || !endDate) return 0;
  
  const start = new Date(startDate);
  const end = new Date(endDate);
  const diffTime = end.getTime() - start.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return diffDays + 1; // ჩათვლით ორივე დღე
}
