// Employee performance score (0-100), trend and potential used by the
// performance tab and the talent map. Missing data sources are skipped and
// the remaining weights are renormalised; no data at all => null.

export interface EvalInput {
  evaluation_date: string;
  overall_rating: number | null;
  leadership_rating?: number | null;
  communication_rating?: number | null;
}

export interface PerformanceInput {
  evaluations: EvalInput[];
  lateCount90d: number | null; // null = attendance not tracked
  tasksCompleted: number;
  tasksOverdue: number;
  goalProgress: number[]; // 0-100 each
  trainingsTotal: number;
  trainingsCompleted: number;
  skillLevels: number[]; // 1-5 each
}

export const WEIGHTS = { evaluations: 40, attendance: 20, tasks: 20, goals: 10, training: 10 };

export type Trend = "improving" | "stable" | "declining" | "unknown";
export type Level = "low" | "mid" | "high";

const clamp = (n: number) => Math.max(0, Math.min(100, n));
const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);

function sortedEvals(e: EvalInput[]) {
  return [...e]
    .filter((x) => typeof x.overall_rating === "number")
    .sort((a, b) => a.evaluation_date.localeCompare(b.evaluation_date));
}

export function componentScores(i: PerformanceInput) {
  const evs = sortedEvals(i.evaluations);
  const lastEvs = evs.slice(-3);
  return {
    evaluations: lastEvs.length ? clamp((avg(lastEvs.map((e) => e.overall_rating as number)) / 5) * 100) : null,
    attendance: i.lateCount90d === null ? null : clamp(100 - i.lateCount90d * 5),
    tasks: i.tasksCompleted + i.tasksOverdue > 0 ? clamp((i.tasksCompleted / (i.tasksCompleted + i.tasksOverdue)) * 100) : null,
    goals: i.goalProgress.length ? clamp(avg(i.goalProgress)) : null,
    training: i.trainingsTotal > 0 ? clamp((i.trainingsCompleted / i.trainingsTotal) * 100) : null,
  };
}

export function performanceScore(i: PerformanceInput): number | null {
  const c = componentScores(i);
  let sum = 0;
  let w = 0;
  (Object.keys(WEIGHTS) as (keyof typeof WEIGHTS)[]).forEach((k) => {
    const v = c[k];
    if (v !== null) {
      sum += v * WEIGHTS[k];
      w += WEIGHTS[k];
    }
  });
  return w === 0 ? null : Math.round(sum / w);
}

export function performanceTrend(evals: EvalInput[]): Trend {
  const evs = sortedEvals(evals);
  if (evs.length < 2) return "unknown";
  const diff = (evs[evs.length - 1].overall_rating as number) - (evs[evs.length - 2].overall_rating as number);
  if (diff >= 0.5) return "improving";
  if (diff <= -0.5) return "declining";
  return "stable";
}

// Potential: leadership + communication of latest evaluation, skill levels, learning activity.
export function potentialScore(i: PerformanceInput): number | null {
  const parts: number[] = [];
  const last = sortedEvals(i.evaluations).slice(-1)[0];
  if (last) {
    const lc = [last.leadership_rating, last.communication_rating].filter((x): x is number => typeof x === "number");
    if (lc.length) parts.push((avg(lc) / 5) * 100);
  }
  if (i.skillLevels.length) parts.push((avg(i.skillLevels) / 5) * 100);
  if (i.trainingsTotal > 0) parts.push((i.trainingsCompleted / i.trainingsTotal) * 100);
  return parts.length ? Math.round(clamp(avg(parts))) : null;
}

export function toLevel(score: number): Level {
  if (score >= 75) return "high";
  if (score >= 50) return "mid";
  return "low";
}
