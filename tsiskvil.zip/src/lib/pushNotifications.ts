import { Capacitor } from '@capacitor/core';
import { PushNotifications } from '@capacitor/push-notifications';
import { supabase } from '@/integrations/supabase/client';

let initialized = false;

async function saveToken(userId: string, token: string) {
  const platform = Capacitor.getPlatform();
  await supabase
    .from('device_tokens')
    .upsert(
      { user_id: userId, token, platform, updated_at: new Date().toISOString() },
      { onConflict: 'token' }
    );
}

/**
 * Registers the device for push notifications (native Android/iOS only).
 * Safe to call on web - it no-ops there. Call after the user signs in.
 */
export async function initPushNotifications(userId: string): Promise<void> {
  if (!Capacitor.isNativePlatform() || initialized) return;
  initialized = true;

  try {
    const perm = await PushNotifications.requestPermissions();
    if (perm.receive !== 'granted') return;

    await PushNotifications.register();

    await PushNotifications.addListener('registration', (token) => {
      void saveToken(userId, token.value);
    });

    await PushNotifications.addListener('registrationError', (err) => {
      console.error('Push registration error:', err);
    });

    await PushNotifications.addListener('pushNotificationReceived', (notification) => {
    });

    await PushNotifications.addListener('pushNotificationActionPerformed', (action) => {
      const path = (action.notification.data as { path?: string })?.path;
      if (path && typeof path === 'string' && path.startsWith('/')) {
        window.location.href = path;
      }
    });
  } catch (err) {
    console.error('Push init failed:', err);
  }
}
