// Geofencing utility functions

export interface Location {
  lat: number;
  lon: number;
}

export interface OfficeLocation {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  radius_meters: number;
}

/**
 * Calculate the distance between two points using Haversine formula
 * Returns distance in meters
 */
export function calculateDistance(point1: Location, point2: Location): number {
  const R = 6371000; // Earth's radius in meters
  const lat1 = point1.lat * Math.PI / 180;
  const lat2 = point2.lat * Math.PI / 180;
  const deltaLat = (point2.lat - point1.lat) * Math.PI / 180;
  const deltaLon = (point2.lon - point1.lon) * Math.PI / 180;

  const a = Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) *
    Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

/**
 * Check if a location is within any of the office geofences
 * Returns the nearest office and whether the location is valid
 */
export function checkLocationValidity(
  userLocation: Location,
  offices: OfficeLocation[]
): { isValid: boolean; nearestOffice: OfficeLocation | null; distance: number } {
  if (offices.length === 0) {
    // No offices configured - allow check-in anywhere
    return { isValid: true, nearestOffice: null, distance: 0 };
  }

  let nearestOffice: OfficeLocation | null = null;
  let minDistance = Infinity;

  for (const office of offices) {
    const distance = calculateDistance(userLocation, {
      lat: Number(office.latitude),
      lon: Number(office.longitude)
    });

    if (distance < minDistance) {
      minDistance = distance;
      nearestOffice = office;
    }
  }

  const isValid = nearestOffice ? minDistance <= nearestOffice.radius_meters : false;

  return { isValid, nearestOffice, distance: Math.round(minDistance) };
}

/**
 * Format distance for display
 */
export function formatDistance(meters: number): string {
  if (meters < 1000) {
    return `${meters} მ`;
  }
  return `${(meters / 1000).toFixed(1)} კმ`;
}
