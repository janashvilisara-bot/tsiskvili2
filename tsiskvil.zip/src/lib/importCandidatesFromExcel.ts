import ExcelJS from 'exceljs';

export interface ImportedCandidate {
  full_name: string;
  email: string;
  phone?: string;
  cover_letter?: string;
  source?: string;
}

export const importCandidatesFromExcel = async (file: File): Promise<ImportedCandidate[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      try {
        const buffer = e.target?.result as ArrayBuffer;
        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.load(buffer);
        
        const worksheet = workbook.worksheets[0];
        if (!worksheet) {
          reject(new Error('No worksheet found'));
          return;
        }
        
        const candidates: ImportedCandidate[] = [];
        const headerRow = worksheet.getRow(1);
        const headers: { [key: number]: string } = {};
        
        // Map headers
        headerRow.eachCell((cell, colNumber) => {
          headers[colNumber] = String(cell.value || '').trim();
        });
        
        // Process data rows
        worksheet.eachRow((row, rowNumber) => {
          if (rowNumber === 1) return; // Skip header
          
          const rowData: { [key: string]: any } = {};
          row.eachCell((cell, colNumber) => {
            const header = headers[colNumber];
            if (header) {
              rowData[header] = cell.value;
            }
          });
          
          const candidate: ImportedCandidate = {
            full_name: rowData['სახელი და გვარი'] || rowData['სახელი'] || rowData['Full Name'] || rowData['Name'] || '',
            email: rowData['ელ. ფოსტა'] || rowData['Email'] || rowData['მეილი'] || '',
            phone: rowData['ტელეფონი'] || rowData['Phone'] || rowData['მობილური'] || '',
            cover_letter: rowData['შენიშვნა'] || rowData['კომენტარი'] || rowData['Notes'] || rowData['Cover Letter'] || '',
            source: rowData['წყარო'] || rowData['Source'] || 'excel_import',
          };
          
          if (candidate.full_name && candidate.email) {
            candidates.push(candidate);
          }
        });
        
        resolve(candidates);
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = (error) => reject(error);
    reader.readAsArrayBuffer(file);
  });
};

export const downloadCandidatesTemplate = async () => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('კანდიდატები');
  
  worksheet.columns = [
    { header: 'სახელი და გვარი', key: 'full_name', width: 25 },
    { header: 'ელ. ფოსტა', key: 'email', width: 25 },
    { header: 'ტელეფონი', key: 'phone', width: 18 },
    { header: 'შენიშვნა', key: 'notes', width: 30 },
    { header: 'წყარო', key: 'source', width: 15 },
  ];
  
  // Style header row
  worksheet.getRow(1).font = { bold: true };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };
  
  // Add sample data
  worksheet.addRow({
    full_name: 'გიორგი ბერიძე',
    email: 'giorgi@example.com',
    phone: '+995 555 123456',
    notes: 'გამოცდილი დეველოპერი',
    source: 'LinkedIn'
  });
  
  worksheet.addRow({
    full_name: 'ანა ქარჩავა',
    email: 'ana@example.com',
    phone: '+995 555 654321',
    notes: 'დიზაინერი',
    source: 'რეკომენდაცია'
  });
  
  // Download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'კანდიდატების_შაბლონი.xlsx';
  link.click();
  window.URL.revokeObjectURL(url);
};
