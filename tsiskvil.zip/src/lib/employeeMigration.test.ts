import { describe, expect, it } from 'vitest';
import { buildMigrationRows, parseMigrationCSV, suggestMapping } from './employeeMigration';
import { industryPresets } from './industryPresets';

describe('employee migration', () => {
  it('reads CSV quoted commas, multiline values and zero salary', () => {
    const sheet = parseMigrationCSV('Full Name,Email,Position,Salary\r\n"Test, Person",test@example.com,"Office\nManager",0');
    const rows = buildMigrationRows(sheet, suggestMapping(sheet.headers));
    expect(rows[0].employee.full_name).toBe('Test, Person');
    expect(rows[0].employee.position).toBe('Office\nManager');
    expect(rows[0].employee.salary).toBe(0);
    expect(rows[0].errors).toEqual([]);
  });
  it('reads semicolon CSV exports and comma decimals', () => {
    const sheet = parseMigrationCSV('Full Name;Email;Position;Salary\nTest Person;test@example.com;Manager;1234,50');
    expect(buildMigrationRows(sheet, suggestMapping(sheet.headers))[0].employee.salary).toBe(1234.5);
  });
  it('skips duplicate emails from the export and existing staff without overwriting', () => {
    const sheet = parseMigrationCSV('Full Name,Email,Position\nTest One,EXISTING@example.com,Manager\nTest Two,new@example.com,Manager\nTest Three,new@example.com,Manager');
    expect(buildMigrationRows(sheet, suggestMapping(sheet.headers), ['existing@example.com']).map(r => r.errors)).toEqual([['duplicate'], [], ['duplicate']]);
  });
  it('rejects missing required values, negative salaries and impossible dates', () => {
    const sheet = parseMigrationCSV('Full Name,Email,Position,Salary,Hire Date\n,,,-1,2026-02-30');
    expect(buildMigrationRows(sheet, suggestMapping(sheet.headers))[0].errors).toEqual(['full_name', 'email', 'position', 'salary', 'hire_date']);
  });
  it('supports manual mapping for unfamiliar competitor columns', () => {
    const sheet = parseMigrationCSV('A,B,C\nTest Person,test@example.com,Manager');
    expect(buildMigrationRows(sheet, { full_name: 0, email: 1, position: 2 })[0].errors).toEqual([]);
  });
});
describe('industry presets', () => {
  for (const id of ['hotel', 'clinic', 'retail']) {
    it(`provides ${id} departments, positions and shifts in both languages`, () => {
      const preset = industryPresets.find(p => p.id === id);
      expect(preset?.departments.length).toBe(4);
      expect(preset?.departments.every(d => d.positions.length > 0 && !!d.name.ka && !!d.name.en)).toBe(true);
      expect(preset?.schedules.length).toBe(id === 'retail' ? 2 : 3);
      expect(preset?.schedules.every(s => /^\d{2}:\d{2}$/.test(s.start) && /^\d{2}:\d{2}$/.test(s.end))).toBe(true);
    });
  }
});