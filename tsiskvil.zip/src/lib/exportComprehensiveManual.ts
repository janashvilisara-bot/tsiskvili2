import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from 'docx';
import { saveAs } from 'file-saver';

export const exportComprehensiveManual = async () => {
  const doc = new Document({
    sections: [{
      properties: {},
      children: [
        // Title
        new Paragraph({
          text: "HR სისტემის სრული სახელმძღვანელო",
          heading: HeadingLevel.TITLE,
          alignment: AlignmentType.CENTER,
          spacing: { after: 400 }
        }),

        new Paragraph({
          text: "ვერსია 2.0 - ყველა ფუნქციონალის დეტალური აღწერა (განახლებული)",
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: new Date().toLocaleDateString('ka-GE'),
          alignment: AlignmentType.CENTER,
          spacing: { after: 800 }
        }),

        // Table of Contents
        new Paragraph({
          text: "სარჩევი",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),

        ...generateTableOfContents(),

        // Introduction
        ...generateIntroduction(),

        // Chapter 1: Employee Management
        ...generateEmployeeManagement(),

        // Chapter 2: Work Schedules
        ...generateWorkSchedules(),

        // Chapter 3: Attendance
        ...generateAttendance(),

        // Chapter 4: Leave Management
        ...generateLeaveManagement(),

        // Chapter 5: Overtime
        ...generateOvertime(),

        // Chapter 6: Payroll
        ...generatePayroll(),

        // Chapter 7: Pension
        ...generatePension(),

        // Chapter 8: Compensation & Bonuses
        ...generateCompensation(),

        // Chapter 9: Budget Planning
        ...generateBudget(),

        // Chapter 10: Financial Reports
        ...generateFinancialReports(),

        // Chapter 11: Documents
        ...generateDocuments(),

        // Chapter 12: Organizational Structure
        ...generateOrgStructure(),

        // Chapter 13: Recruitment
        ...generateRecruitment(),

        // Chapter 14: Tasks
        ...generateTasks(),

        // Chapter 15: Notifications
        ...generateNotifications(),

        // Chapter 16: Security & Roles
        ...generateSecurity(),

        // Chapter 17: Advertisements
        ...generateAdvertisements(),

        // Chapter 18: Additional Features
        ...generateAdditionalFeatures(),

        // Chapter 19: Payroll Run History
        ...generatePayrollRunHistory(),

        // Chapter 20: HR Analytics & Metrics
        ...generateHRAnalytics(),

        // Chapter 21: AI Features
        ...generateAIFeatures(),

        // Chapter 22: Password & Security Updates
        ...generatePasswordSecurity(),
      ]
    }]
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `HR_სისტემის_სრული_სახელმძღვანელო_${new Date().toISOString().split('T')[0]}.docx`);
};

function generateTableOfContents(): Paragraph[] {
  return [
    new Paragraph({ text: "1. შესავალი", spacing: { after: 100 } }),
    new Paragraph({ text: "2. თანამშრომლების მართვა", spacing: { after: 100 } }),
    new Paragraph({ text: "3. სამუშაო გრაფიკები", spacing: { after: 100 } }),
    new Paragraph({ text: "4. დასწრების აღრიცხვა", spacing: { after: 100 } }),
    new Paragraph({ text: "5. შვებულებების მართვა", spacing: { after: 100 } }),
    new Paragraph({ text: "6. ზეგანაკვეთური სამუშაო", spacing: { after: 100 } }),
    new Paragraph({ text: "7. ხელფასის სისტემა", spacing: { after: 100 } }),
    new Paragraph({ text: "8. პენსიის გადასახადები", spacing: { after: 100 } }),
    new Paragraph({ text: "9. კომპენსაციები და ბონუსები", spacing: { after: 100 } }),
    new Paragraph({ text: "10. ბიუჯეტის დაგეგმვა", spacing: { after: 100 } }),
    new Paragraph({ text: "11. ფინანსური ანგარიშები", spacing: { after: 100 } }),
    new Paragraph({ text: "12. დოკუმენტების მართვა", spacing: { after: 100 } }),
    new Paragraph({ text: "13. ორგანიზაციული სტრუქტურა", spacing: { after: 100 } }),
    new Paragraph({ text: "14. რეკრუტინგი", spacing: { after: 100 } }),
    new Paragraph({ text: "15. ამოცანების მართვა", spacing: { after: 100 } }),
    new Paragraph({ text: "16. შეტყობინებები", spacing: { after: 100 } }),
    new Paragraph({ text: "17. უსაფრთხოება და როლები", spacing: { after: 100 } }),
    new Paragraph({ text: "18. რეკლამების მართვა", spacing: { after: 100 } }),
    new Paragraph({ text: "19. დამატებითი ფუნქციები", spacing: { after: 100 } }),
    new Paragraph({ text: "20. ხელფასის გაშვების ისტორია", spacing: { after: 100 } }),
    new Paragraph({ text: "21. HR ანალიტიკა და მეტრიკები", spacing: { after: 100 } }),
    new Paragraph({ text: "22. AI ფუნქციები და ავტომატიზაცია", spacing: { after: 100 } }),
    new Paragraph({ text: "23. პაროლი და უსაფრთხოების განახლებები", spacing: { after: 600 } }),
  ];
}

function generateIntroduction(): Paragraph[] {
  return [
    new Paragraph({
      text: "1. შესავალი",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "ეს სახელმძღვანელო მოიცავს HR სისტემის ყველა ფუნქციონალს დეტალური ინსტრუქციებით. სისტემა შექმნილია თანამშრომლების მართვის, დასწრების აღრიცხვის, ხელფასების გაანგარიშების და ყველა HR პროცესის ავტომატიზაციისთვის.",
      spacing: { after: 200 }
    }),
    new Paragraph({
      text: "სისტემის ძირითადი უპირატესობები:",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 200, after: 100 }
    }),
    new Paragraph({ text: "• სრული თანამშრომლების ბაზის მართვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ავტომატური დასწრების აღრიცხვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შვებულებების და ზეგანაკვეთური სამუშაოს კონტროლი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ავტომატური ხელფასის გაანგარიშება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ფინანსური ანგარიშგება და ბიუჯეტის დაგეგმვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დოკუმენტების ელექტრონული ხელმოწერა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• SMS/Email შეტყობინებები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ორგანიზაციული სტრუქტურის ვიზუალიზაცია", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• რეკრუტინგისა და კანდიდატების მართვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• AI ასისტენტი დახმარებისთვის", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateEmployeeManagement(): Paragraph[] {
  return [
    new Paragraph({
      text: "2. თანამშრომლების მართვა",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "2.1 თანამშრომლის რეგისტრაცია",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "მხოლოდ ადმინისტრატორს შეუძლია ახალი თანამშრომლის რეგისტრაცია:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'თანამშრომლები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი თანამშრომელი' ღილაკს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. შეავსეთ სავალდებულო ველები:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "სახელი და გვარი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "პირადი ნომერი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ტელეფონის ნომერი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ელექტრონული ფოსტა", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "პოზიცია", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "დეპარტამენტი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "სამუშაო გრაფიკი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ხელფასი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "როლი (ადმინი/HR/მენეჯერი/თანამშრომელი)", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "პაროლი (მინიმუმ 8 სიმბოლო)", bullet: { level: 1 }, spacing: { after: 100 } }),
    new Paragraph({ text: "4. შეინახეთ ინფორმაცია", bullet: { level: 0 }, spacing: { after: 200 } }),
    new Paragraph({
      text: "ავტომატური პროცესები რეგისტრაციის შემდეგ:",
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 200, after: 100 }
    }),
    new Paragraph({ text: "• ავტომატურად იქმნება ავტორიზაციის ანგარიში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• თუ არჩეულია ფიქსირებული გრაფიკი, ავტომატურად ემატება სამუშაო გრაფიკში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• თანამშრომელს SMS-ით ეგზავნება პაროლი და ლოგინის ბმული", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• პირველ შესვლაზე გამოდის შეტყობინება პაროლის შესაცვლელად", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "2.2 თანამშრომლის პროფილის რედაქტირება",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "თანამშრომლის ინფორმაციის განახლება:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'თანამშრომლები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. აირჩიეთ თანამშრომელი სიიდან", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. დააჭირეთ 'რედაქტირება' ღილაკს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. შეცვალეთ საჭირო ველები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. შეინახეთ ცვლილებები", bullet: { level: 0 }, spacing: { after: 200 } }),
    new Paragraph({
      text: "რედაქტირებადი ველები:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• პირადი ინფორმაცია (სახელი, ტელეფონი, ელ-ფოსტა)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სამსახურებრივი ინფორმაცია (პოზიცია, დეპარტამენტი)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სამუშაო გრაფიკი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ხელფასი და ბენეფიტები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• პროფილის სურათი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• როლი და უფლებები", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "2.3 თანამშრომლის პორტალი",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "თითოეულ თანამშრომელს აქვს პირადი პორტალი სადაც ხედავს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• დასწრების ისტორიას და სტატისტიკას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შვებულების ბალანსს (წლიური, სამედიცინო, პირადი, გადაუხდელი)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შვებულებების ისტორიის ქრონოლოგიას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• აქტიურ ამოცანებს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მიმდინარე განაცხადებს (შვებულება, ზეგანაკვეთური)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შეტყობინებებს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ხელმოწერილი დოკუმენტების ისტორიას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ფავორიტების სექციას სწრაფი წვდომისთვის", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• კალენდარს დასვენების დღეებით", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "2.4 პაროლის აღდგენა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "პაროლის აღდგენა შესაძლებელია SMS ან Email-ის მეშვეობით:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. შესვლის გვერდზე დააჭირეთ 'პაროლის აღდგენა'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. აირჩიეთ SMS ან Email", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. შეიყვანეთ თქვენი ელ-ფოსტა ან ტელეფონი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. მიიღებთ აღდგენის ბმულს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. შექმენით ახალი პაროლი", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateWorkSchedules(): Paragraph[] {
  return [
    new Paragraph({
      text: "3. სამუშაო გრაფიკები",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "3.1 გრაფიკების ტიპები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სისტემა მხარს უჭერს 4 ტიპის გრაფიკს:",
      spacing: { after: 100 }
    }),
    new Paragraph({
      text: "სრული გრაფიკი 1 (Fixed 1):",
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 200, after: 100 }
    }),
    new Paragraph({ text: "• სტანდარტული 8 საათიანი სამუშაო დღე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ჩვეულებრივ 09:00-18:00", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• 40 საათიანი სამუშაო კვირა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• 1 საათიანი შესვენება", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "სრული გრაფიკი 2 (Fixed 2):",
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 200, after: 100 }
    }),
    new Paragraph({ text: "• ალტერნატიული 8 საათიანი სამუშაო დღე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ჩვეულებრივ 10:00-19:00", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• 40 საათიანი სამუშაო კვირა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• 1 საათიანი შესვენება", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "საათობრივი (Hourly):",
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 200, after: 100 }
    }),
    new Paragraph({ text: "• ცვლადი საათობრივი გრაფიკი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• თითოეული დღისთვის ინდივიდუალურად განისაზღვრება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მოქნილი სამუშაო დრო", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "ცვლები (Shifts):",
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 200, after: 100 }
    }),
    new Paragraph({ text: "• ღამის/დღის ცვლების სისტემა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ღამის ცვლა: 22:00-06:00", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დღის ცვლა: 06:00-22:00", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ავტომატური რეკურენტული ცვლები", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "3.2 გრაფიკის შაბლონების მართვა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ახალი შაბლონის შექმნა:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'გრაფიკის შაბლონები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი შაბლონი'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. შეავსეთ შაბლონის დეტალები (დასახელება, აღწერა)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. მიუთითეთ სამუშაო საათები და პირობები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. შეინახეთ შაბლონი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "6. გააქტიურება/გამორთე შაბლონი საჭიროების მიხედვით", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "3.3 ცვლების კალენდარი",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ცვლების დამატება:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'სამუშაო გრაფიკები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. აირჩიეთ თანამშრომელი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. დააჭირეთ კალენდარზე სასურველ თარიღს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. მიუთითეთ ცვლის დრო (დაწყება-დასრულება)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. შეინახეთ ცვლა", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "რეკურენტული ცვლების შექმნა:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• შეგიძლიათ შექმნათ ავტომატური ცვლები კვირის ან თვის განმავლობაში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სისტემა ავტომატურად გაიმეორებს გრაფიკს მითითებულ პერიოდში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შესაძლებელია მთელი კვირის ან თვის კოპირება სხვა პერიოდში", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "3.4 Excel ექსპორტი და იმპორტი",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({ text: "• გადმოწერეთ Excel შაბლონი გრაფიკების მასობრივად დასამატებლად", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შეავსეთ შაბლონი გრაფიკების ინფორმაციით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ატვირთეთ შევსებული ფაილი სისტემაში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ექსპორტი ხელმისაწვდომია არსებული გრაფიკების გადმოსაწერად", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateAttendance(): Paragraph[] {
  return [
    new Paragraph({
      text: "4. დასწრების აღრიცხვა",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "4.1 მობილური დასწრება",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "თანამშრომლებს შეუძლიათ აღრიცხონ დასწრება მობილური მოწყობილობიდან:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გახსენით 'მობილური დასწრება' გვერდი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'შემოსვლა' ღილაკს სამუშაოზე მისვლისას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. დააჭირეთ 'გასვლა' ღილაკს სამუშაოდან წასვლისას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. სისტემა ავტომატურად ითვლის სამუშაო საათებს", bullet: { level: 0 }, spacing: { after: 200 } }),
    new Paragraph({
      text: "დამატებითი ფუნქციები:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• გეოლოკაციის აღრიცხვა (თუ გააქტიურებულია)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გვიანობის ავტომატური აღრიცხვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გვიანობის კომენტარის დამატების შესაძლებლობა", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "4.2 რეალურ დროში მონიტორინგი",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ადმინისტრატორებს და მენეჯერებს შეუძლიათ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ნახონ ყველა აქტიური თანამშრომელი რეალურ დროში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ნახონ ვინ არის სამუშაოზე და ვინ არა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ნახონ შემოსვლის და გასვლის დრო", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ნახონ გვიან მისულები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მონაცემები ავტომატურად განახლდება Realtime-ის საშუალებით", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "4.3 დასწრების ისტორია",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "დასწრების ისტორია ტაბი გვიჩვენებს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ყველა თანამშრომლის დასწრების ჩანაწერებს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• თარიღის მიხედვით ფილტრაციას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• თანამშრომლის მიხედვით ძიებას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გვიანობის ანალიტიკას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Excel ექსპორტს ანგარიშებისთვის", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "4.4 გვიანობის ანალიტიკა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სპეციალური გვერდი გვიანობების დეტალური ანალიზისთვის:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• გვიანობის სტატისტიკა თანამშრომლების მიხედვით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გვიანობის ტრენდები დროის განმავლობაში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ფილტრაცია თარიღის, დეპარტამენტის, თანამშრომლის მიხედვით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გვიანობის მიზეზების კომენტარები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Excel ექსპორტი დეტალური ანგარიშებისთვის", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateLeaveManagement(): Paragraph[] {
  return [
    new Paragraph({
      text: "5. შვებულებების მართვა",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "5.1 შვებულების ტიპები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სისტემა მხარს უჭერს შემდეგ შვებულებების ტიპებს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• წლიური შვებულება (24 სამუშაო დღე წელიწადში)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სამედიცინო შვებულება (დოკუმენტის ატვირთვით)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• პირადი შვებულება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გადაუხდელი შვებულება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დეკრეტული შვებულება (სპეციალური პირობებით)", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "5.2 შვებულების განაცხადის შექმნა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "თანამშრომელს შეუძლია შექმნას შვებულების განაცხადი:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'შვებულებები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი განაცხადი'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. აირჩიეთ შვებულების ტიპი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. მიუთითეთ დაწყების და დასრულების თარიღები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. დაამატეთ კომენტარი (არასავალდებულო)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "6. სამედიცინოს შემთხვევაში ატვირთეთ დოკუმენტი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "7. გაგზავნეთ განაცხადი", bullet: { level: 0 }, spacing: { after: 200 } }),
    new Paragraph({
      text: "განაცხადის შემდეგ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• მენეჯერი/HR იღებს შეტყობინებას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• განაცხადის სტატუსი არის 'განხილვაში'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• თანამშრომელს შეუძლია თვალყურის დევნება პორტალიდან", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "5.3 შვებულების დამტკიცება",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "HR/მენეჯერმა უნდა განიხილოს და დაამტკიცოს განაცხადი:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'შვებულებები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. ნახეთ მომლოდინე განაცხადები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. შეამოწმეთ შვებულების ბალანსი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. დაამტკიცეთ ან უარყავით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. დაამატეთ კომენტარი საჭიროების შემთხვევაში", bullet: { level: 0 }, spacing: { after: 200 } }),
    new Paragraph({
      text: "დამტკიცების შემდეგ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• თანამშრომელს ეგზავნება SMS/Email შეტყობინება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ბალანსი ავტომატურად განახლდება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შვებულება აისახება კალენდარში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ცვლილებები ასახულია ანგარიშებში", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "5.4 შვებულების სტატისტიკა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "დეტალური სტატისტიკა შვებულებების შესახებ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• შვებულებაზე მყოფი თანამშრომლების რაოდენობა დეპარტამენტების მიხედვით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შვებულების ბალანსების მიმოხილვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ყველაზე მეტად გამოყენებული შვებულების ტიპები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• კვარტალური და წლიური ანალიზი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Excel ექსპორტი დეტალური ანგარიშებისთვის", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateOvertime(): Paragraph[] {
  return [
    new Paragraph({
      text: "6. ზეგანაკვეთური სამუშაო",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "6.1 ზეგანაკვეთურის განაცხადის შექმნა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "თანამშრომელს შეუძლია შექმნას ზეგანაკვეთურის განაცხადი:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'ზეგანაკვეთური' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი განაცხადი'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. მიუთითეთ თარიღი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. მიუთითეთ საათების რაოდენობა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. დაამატეთ მიზეზი/კომენტარი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "6. გაგზავნეთ განაცხადი დასამტკიცებლად", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "6.2 დამტკიცება და გადახდა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "HR/მენეჯერმა უნდა დაამტკიცოს განაცხადი:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. შეამოწმეთ განაცხადის დეტალები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დაადასტურეთ ფაქტობრივი მუშაობა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. დაამტკიცეთ ან უარყავით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. დამტკიცების შემდეგ ავტომატურად გაანგარიშდება გადახდა", bullet: { level: 0 }, spacing: { after: 200 } }),
    new Paragraph({
      text: "ზეგანაკვეთურის გაანგარიშება:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ზეგანაკვეთური ანაზღაურდება 1.5x კოეფიციენტით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გადახდა = საათობრივი განაკვეთი × 1.5 × საათების რაოდენობა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ავტომატურად ემატება ხელფასის სისტემაში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• აისახება ფინანსურ ანგარიშებში", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "6.3 სახელმწიფო უქმე დღეების ზეგანაკვეთური",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სისტემა ავტომატურად აღრიცხავს სახელმწიფო უქმე დღეებს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ყველა ოფიციალური დღესასწაული ინახება სისტემაში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• უქმე დღეებში მუშაობა ავტომატურად ითვლება ზეგანაკვეთურად", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ადმინისტრატორებს შეუძლიათ დაამატონ/შეცვალონ უქმე დღეები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დეტალური ანგარიში უქმე დღეებში მუშაობაზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Excel ექსპორტი სტატისტიკით", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generatePayroll(): Paragraph[] {
  return [
    new Paragraph({
      text: "7. ხელფასის სისტემა",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "7.1 ხელფასის დარიცხვა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ხელფასის დარიცხვა ხდება თვის ბოლოს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'ხელფასები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. აირჩიეთ თვე და წელი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. დააჭირეთ 'ხელფასის გაანგარიშება'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. სისტემა ავტომატურად გაანგარიშებს:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "საბაზო ხელფასი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ბონუსები და კომპენსაციები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ზეგანაკვეთური", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "დამატებითი სარგებლები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "გადასახადები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. შეამოწმეთ გაანგარიშება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "6. დაამტკიცეთ ხელფასები", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "7.2 ხელფასის კომპონენტები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ხელფასი შედგება შემდეგი კომპონენტებისგან:",
      spacing: { after: 100 }
    }),
    new Paragraph({
      text: "საბაზო ხელფასი:",
      spacing: { after: 50 }
    }),
    new Paragraph({ text: "• ფიქსირებული თანხა თვეში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• განისაზღვრება თანამშრომლის რეგისტრაციისას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შეიძლება შეიცვალოს პროფილის რედაქტირებით", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "ბონუსები:",
      spacing: { after: 50 }
    }),
    new Paragraph({ text: "• წარმადობის ბონუსი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• კვარტალური პრემიები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ერთჯერადი გადახდები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სპეციალური წახალისება", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "ზეგანაკვეთური:",
      spacing: { after: 50 }
    }),
    new Paragraph({ text: "• ავტომატურად ემატება დამტკიცებული განაცხადებიდან", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• 1.5x კოეფიციენტით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• საათების აღრიცხვა და გაანგარიშება", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "გამოქვითვები:",
      spacing: { after: 50 }
    }),
    new Paragraph({ text: "• საშემოსავლო გადასახადი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• პენსიის შენატანები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სხვა გამოქვითვები", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "7.3 ხელფასების Excel ექსპორტი",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ხელფასების ექსპორტი საბუღალტრო მიზნებისთვის:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• გაანგარიშებული ხელფასების სრული ჩამონათვალი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ყველა კომპონენტი დეტალურად", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Excel ფორმატში გადმოწერა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• საბუღალტრო პროგრამებში იმპორტისთვის მზადაა", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generatePension(): Paragraph[] {
  return [
    new Paragraph({
      text: "8. პენსიის გადასახადები",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "8.1 პენსიის გაანგარიშება",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "პენსიის შენატანები გაანგარიშდება ავტომატურად:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• თანამშრომლის შენატანი - 2% ხელფასიდან", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დამსაქმებლის შენატანი - 4% ხელფასიდან", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ავტომატური გაანგარიშება ხელფასის დარიცხვისას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მონაცემები ინახება pension_payments ცხრილში", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "8.2 პენსიის ანგარიშები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "დეტალური ანგარიშები პენსიის გადახდებზე:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'პენსია' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. აირჩიეთ პერიოდი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. ნახეთ დეტალური სია:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "თანამშრომლები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "თანამშრომლის შენატანი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "დამსაქმებლის შენატანი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "სულ გადასახდელი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. Excel ექსპორტი საგადასახადო ანგარიშებისთვის", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateCompensation(): Paragraph[] {
  return [
    new Paragraph({
      text: "9. კომპენსაციები და ბონუსები",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "9.1 კომპენსაციის ტიპები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სისტემა მხარს უჭერს სხვადასხვა ტიპის კომპენსაციებს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• წარმადობის ბონუსი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ერთჯერადი კომპენსაცია", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სპეციალური დანამატი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• პრემია", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "9.2 კომპენსაციის დამატება",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "კომპენსაციის მინიჭება თანამშრომელს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'კომპენსაციები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი კომპენსაცია'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. აირჩიეთ თანამშრომელი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. აირჩიეთ კომპენსაციის ტიპი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. მიუთითეთ თანხა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "6. დაამატეთ მიზეზი/აღწერა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "7. მიუთითეთ გადახდის თარიღი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "8. შეინახეთ", bullet: { level: 0 }, spacing: { after: 200 } }),
    new Paragraph({
      text: "დამატების შემდეგ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• კომპენსაცია ავტომატურად ჩაითვლება შესაბამის თვის ხელფასში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• აისახება ფინანსურ ანგარიშებში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• თანამშრომელი დაინახავს პორტალში", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateBudget(): Paragraph[] {
  return [
    new Paragraph({
      text: "10. ბიუჯეტის დაგეგმვა",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "10.1 ბიუჯეტის შექმნა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ბიუჯეტის დაგეგმვის პროცესი:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'ბიუჯეტის დაგეგმვა' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი ბიუჯეტი'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. აირჩიეთ პერიოდი (თვე/კვარტალი/წელი)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. მიუთითეთ კატეგორიები:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ხელფასები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ოფისის ხარჯები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "მარკეტინგი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "IT ინფრასტრუქტურა", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ტრენინგები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "სხვა", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. შეინახეთ ბიუჯეტი", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "10.2 ხარჯების აღრიცხვა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ხარჯის დამატება:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'ხარჯები' ტაბზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი ხარჯი'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. აირჩიეთ კატეგორია", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. მიუთითეთ თანხა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. დაამატეთ აღწერა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "6. ატვირთეთ ინვოისი/ქვითარი (არასავალდებულო)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "7. შეინახეთ", bullet: { level: 0 }, spacing: { after: 200 } }),
    new Paragraph({
      text: "ხარჯები ავტომატურად:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ემატება შესაბამის ბიუჯეტს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• აისახება ფინანსურ ანგარიშებში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• განახლდება დაშვება/გადახარჯვის მონაცემები", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateFinancialReports(): Paragraph[] {
  return [
    new Paragraph({
      text: "11. ფინანსური ანგარიშები",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "11.1 სრული ფინანსური ანგარიში",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სრული ფინანსური ანგარიში მოიცავს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ხელფასების სრული დეტალი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ბონუსები და კომპენსაციები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ზეგანაკვეთური გადახდები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შვებულებების დაანგარიშება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• პენსიის შენატანები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ბიუჯეტის ხარჯები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• უქმე დღეებში მუშაობა", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "11.2 ანგარიშის გენერაცია",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ანგარიშის შექმნა:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'ფინანსური ანგარიშები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. აირჩიეთ პერიოდი (თვე/კვარტალი/წელი)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. აირჩიეთ ანგარიშის ტიპი:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "სრული ანგარიში", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ხელფასები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "პენსია", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ბიუჯეტი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "კომპენსაციები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. გადმოწერეთ Excel ფაილი", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "11.3 სამუშაო დროის ფორმა N1",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სახელმწიფო ფორმის ავტომატური გენერაცია:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ყოველთვიური N1 ფორმის გენერაცია", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ყველა თანამშრომლისთვის ცალ-ცალკე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სრული დასწრების დეტალი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ზეგანაკვეთურის აღრიცხვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შვებულებების მონიშვნა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• PDF/Excel ექსპორტი", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateDocuments(): Paragraph[] {
  return [
    new Paragraph({
      text: "12. დოკუმენტების მართვა",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "12.1 დოკუმენტის შექმნა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "დოკუმენტის დამატება და გაგზავნა:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'დოკუმენტები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი დოკუმენტი'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. აირჩიეთ დოკუმენტის ტიპი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. ატვირთეთ ფაილი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. აირჩიეთ მიმღები თანამშრომლები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "6. გაგზავნეთ დოკუმენტი", bullet: { level: 0 }, spacing: { after: 200 } }),
    new Paragraph({
      text: "გაგზავნის შემდეგ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• თანამშრომლებს ეგზავნებათ SMS შეტყობინება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დოკუმენტი ჩანს პორტალში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სტატუსი: 'განხილვაში'", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "12.2 დოკუმენტის ხელმოწერა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "თანამშრომელმა უნდა ხელი მოაწეროს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით პორტალზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. ნახეთ მოსახელმისებელი დოკუმენტები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. გახსენით დოკუმენტი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. წაიკითხეთ შინაარსი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. დააჭირეთ 'ვეთანხმები' ან 'არ ვეთანხმები'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "6. სტატუსი შეიცვლება 'დადასტურებული'/'უარყოფილი'", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "12.3 დოკუმენტების ანგარიში",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "დოკუმენტაციის სტატუსის ანგარიში:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• დადასტურებული დოკუმენტების რაოდენობა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მოსახელმისებელი დოკუმენტები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• უარყოფილი დოკუმენტები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ფილტრაცია დეპარტამენტისა და თანამშრომლის მიხედვით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Excel ექსპორტი", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "12.4 ავტომატური შეხსენებები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სისტემა ავტომატურად გზავნის შეხსენებებს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• დაუხელმოწერელი დოკუმენტების შესახებ (3 დღის შემდეგ)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• SMS/Email შეტყობინებები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შეხსენების სიხშირე კონფიგურირებადია", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateOrgStructure(): Paragraph[] {
  return [
    new Paragraph({
      text: "13. ორგანიზაციული სტრუქტურა",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "13.1 დეპარტამენტების მართვა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ახალი დეპარტამენტის დამატება:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'ორგანიზაციული სტრუქტურა' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი დეპარტამენტი'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. შეავსეთ ინფორმაცია:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "დასახელება", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "აღწერა", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "მენეჯერი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ბიუჯეტი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "მშობელი დეპარტამენტი (სუბდეპარტამენტისთვის)", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. შეინახეთ", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "13.2 პოზიციების მართვა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ახალი პოზიციის დამატება:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით პოზიციების ტაბზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი პოზიცია'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. შეავსეთ:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "დასახელება", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "დეპარტამენტი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "დონე", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ხელფასის დიაპაზონი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. შეინახეთ", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "13.3 თანამდებობის აღწერა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "პოზიციისთვის დეტალური აღწერის დამატება:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'თანამდებობის აღწერები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. აირჩიეთ პოზიცია", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. დაამატეთ:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ძირითადი ფუნქციები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "პასუხისმგებლობები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "კვალიფიკაციის მოთხოვნები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "გამოცდილება", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. შეინახეთ", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "13.4 დეპარტამენტის ანალიტიკა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "დეპარტამენტების შედარებითი ანალიზი:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• თანამშრომლების რაოდენობა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• საშუალო ხელფასი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ბიუჯეტის განაწილება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• თვიური/კვარტალური შედარება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ტრენდების ვიზუალიზაცია", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Excel ექსპორტი", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateRecruitment(): Paragraph[] {
  return [
    new Paragraph({
      text: "14. რეკრუტინგი",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "14.1 ვაკანსიის გამოცხადება",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ახალი ვაკანსიის შექმნა:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'ვაკანსიები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი ვაკანსია'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. შეავსეთ ინფორმაცია:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "პოზიცია", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "დეპარტამენტი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "სრული აღწერა", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "მოთხოვნები", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ხელფასის დიაპაზონი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. შეინახეთ და გამოაქვეყნეთ", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "14.2 ვაკანსიის გაზიარება",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სისტემა საშუალებას გაძლევთ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• შექმნათ საჯარო ბმული ვაკანსიაზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გააზიაროთ სოციალურ ქსელებში:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "Facebook", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "LinkedIn", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "Twitter/X", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გაუგზავნოთ შიდა შეტყობინება თანამშრომლებს", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "14.3 კანდიდატების მართვა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "კანდიდატის დამატება:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'კანდიდატები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი კანდიდატი'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. შეავსეთ პირადი მონაცემები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. ატვირთეთ CV", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. მიუკერძოეთ ვაკანსიას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "6. დაამატეთ კომენტარი/შენიშვნა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "7. შეინახეთ", bullet: { level: 0 }, spacing: { after: 200 } }),
    new Paragraph({
      text: "კანდიდატის სტატუსები:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ახალი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• განხილვაში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გასაუბრება დაინიშნა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მიღებული", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• უარყოფილი", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "14.4 CV ანალიზი AI-ით",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "AI ასისტენტი დაგეხმარებათ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• CV-ის ავტომატურ ანალიზში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ვაკანსიასთან შესაბამისობის შეფასებაში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• კანდიდატის უნარ-ჩვევების იდენტიფიცირებაში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• რეკომენდაციების მიღებაში", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateTasks(): Paragraph[] {
  return [
    new Paragraph({
      text: "15. ამოცანების მართვა",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "15.1 ამოცანის შექმნა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ახალი ამოცანის დამატება:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით 'ამოცანები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი ამოცანა'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. შეავსეთ:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "სათაური", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "აღწერა", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "პასუხისმგებელი პირი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "ვადა", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "პრიორიტეტი", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. შეინახეთ და გააგზავნეთ", bullet: { level: 0 }, spacing: { after: 200 } }),
    new Paragraph({
      text: "გაგზავნის შემდეგ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• თანამშრომელი იღებს შეტყობინებას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ამოცანა ჩანს პორტალში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სტატუსი: 'ახალი'", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "15.2 ამოცანაზე მუშაობა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "თანამშრომელს შეუძლია:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გახსნას ამოცანა დეტალურად", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. შეცვალოს სტატუსი:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "მიმდინარე", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "დასრულებული", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "გადადებული", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. დაამატოს კომენტარები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. ატვირთოს ფაილები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. აღნიშნოს როგორც დასრულებული", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "15.3 ამოცანების მონიტორინგი",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "მენეჯერებს შეუძლიათ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ნახონ ყველა აქტიური ამოცანა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ფილტრაცია სტატუსის, პირის, ვადის მიხედვით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მიიღონ შეტყობინებები ვადაგადაცილებულ ამოცანებზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გადმოწერონ ამოცანების ანგარიში Excel-ში", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateNotifications(): Paragraph[] {
  return [
    new Paragraph({
      text: "16. შეტყობინებები",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "16.1 შეტყობინებების ტიპები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სისტემა აგზავნის შეტყობინებებს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ახალი თანამშრომელი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შვებულების განაცხადი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ზეგანაკვეთურის განაცხადი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ამოცანის მინიჭება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ამოცანის სტატუსის ცვლილება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დოკუმენტი ხელმოწერისთვის", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დაბადების დღე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ხელფასის დარიცხვა", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "16.2 შეტყობინების არხები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "შეტყობინებები იგზავნება:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• სისტემაში (შიდა შეტყობინებები)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• SMS (გადაუდებელ შემთხვევებში)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Email", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "16.3 SMS კონფიგურაცია",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ადმინისტრატორს შეუძლია დააყენოს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• რომელ მოვლენებზე გაიგზავნოს SMS", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• SMS შაბლონების რედაქტირება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Twilio ინტეგრაცია", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "16.4 შეტყობინებების ფილტრაცია",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "შეტყობინებების გვერდზე შესაძლებელია:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ფილტრაცია კატეგორიების მიხედვით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ძიება თარიღის მიხედვით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• წაკითხული/წაუკითხავი ფილტრი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მასობრივი წაშლა", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateSecurity(): Paragraph[] {
  return [
    new Paragraph({
      text: "17. უსაფრთხოება და როლები",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "17.1 მომხმარებლის როლები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სისტემა მხარს უჭერს 4 ძირითად სისტემურ როლს და Custom როლების ფუნქციონალს:",
      spacing: { after: 100 }
    }),
    new Paragraph({
      text: "ადმინისტრატორი:",
      spacing: { after: 50 }
    }),
    new Paragraph({ text: "• სრული წვდომა ყველა ფუნქციაზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მომხმარებლების და როლების მართვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Custom როლების შექმნა და მართვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სისტემის პარამეტრების კონფიგურაცია", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ყველა ანგარიშის ნახვა", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "HR მენეჯერი:",
      spacing: { after: 50 }
    }),
    new Paragraph({ text: "• თანამშრომლების მართვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შვებულებების და განაცხადების დამტკიცება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ხელფასების მართვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ანგარიშების გენერაცია", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დოკუმენტების მართვა", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "დეპარტამენტის მენეჯერი:",
      spacing: { after: 50 }
    }),
    new Paragraph({ text: "• საკუთარი დეპარტამენტის თანამშრომლების ნახვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დეპარტამენტის დასწრების მონიტორინგი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დეპარტამენტის შვებულებების დამტკიცება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დეპარტამენტის ანგარიშები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ამოცანების მინიჭება", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "თანამშრომელი:",
      spacing: { after: 50 }
    }),
    new Paragraph({ text: "• პირადი პროფილის ნახვა და რედაქტირება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დასწრების აღრიცხვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შვებულებების განაცხადი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ამოცანების ნახვა და შესრულება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დოკუმენტების ხელმოწერა", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "Custom როლები:",
      spacing: { after: 50 }
    }),
    new Paragraph({ text: "• ადმინისტრატორს შეუძლია შექმნას მორგებული როლები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• თითოეული Custom როლისთვის ინდივიდუალურად აირჩევა ხელმისაწვდომი ფუნქციონალები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ფუნქციონალები დაჯგუფებულია კატეგორიებად (მთავარი, პერსონალი, ფინანსები, რეკრუტირება, განვითარება, ორგანიზაცია, სისტემა)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Custom როლები იმართება როლების მართვის გვერდიდან", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მომხმარებელს შეიძლება ჰქონდეს როგორც სისტემური, ისე Custom როლები", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "17.2 უსაფრთხოების პარამეტრები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "პაროლის პოლიტიკა:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• მინიმუმ 8 სიმბოლო", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• პირველ შესვლაზე აუცილებელია შეცვლა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• პაროლის აღდგენა SMS/Email-ით", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "17.3 აუდიტის ლოგები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სისტემა ინახავს ისტორიას:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ყველა მნიშვნელოვანი ქმედება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• თანამშრომლების ცვლილებები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ხელფასების კორექტირება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დოკუმენტების ხელმოწერა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ფილტრაცია თარიღის, მომხმარებლის, ქმედების მიხედვით", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateAdditionalFeatures(): Paragraph[] {
  return [
    new Paragraph({
      text: "19. დამატებითი ფუნქციები",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "19.1 AI ასისტენტი",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ხელოვნური ინტელექტის ასისტენტი დაგეხმარებათ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• სისტემის გამოყენების სწავლაში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• კითხვებზე პასუხის მიღებაში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ფუნქციონალის ძიებაში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სწრაფი ნავიგაციის გაადვილებაში", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "19.2 კალენდარი",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ინტერაქტიული კალენდარი გვიჩვენებს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• სახელმწიფო უქმე დღეები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შვებულებაზე მყოფი თანამშრომლები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მნიშვნელოვანი მოვლენები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სამუშაო დღეები/დასვენების დღეები", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "19.3 განცხადებები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "HR მენეჯერს შეუძლია:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• შექმნას კომპანიის განცხადებები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გამოაქვეყნოს/გამორთოს განცხადებები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მიამაგროს მნიშვნელოვანი განცხადებები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შეცვალოს არსებული განცხადებები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• წაშალოს განცხადებები", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "19.4 Excel იმპორტი/ექსპორტი",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "თითქმის ყველა გვერდზე შესაძლებელია:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• მონაცემების ექსპორტი Excel ფაილში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შაბლონის გადმოწერა მასობრივი იმპორტისთვის", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შევსებული ფაილის ატვირთვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ავტომატური ვალიდაცია", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "19.5 ZIP გადმოწერა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "დოკუმენტების მასობრივი გადმოწერა:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• აირჩიეთ რამდენიმე დოკუმენტი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დააჭირეთ 'ZIP გადმოწერა'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ყველა დოკუმენტი ერთ არქივში", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "19.6 რეალურ დროში განახლებები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "Realtime ტექნოლოგია უზრუნველყოფს:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• დასწრების ავტომატურ განახლებას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შეტყობინებების მყისიერ ჩვენებას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ამოცანების სტატუსის სინქრონიზაციას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• განაცხადების განახლებას", bullet: { level: 0 }, spacing: { after: 400 } }),

    new Paragraph({
      text: "დამატებითი ინფორმაციისთვის დაგვიკავშირდით:",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 400, after: 100 }
    }),
    new Paragraph({
      text: "ტექნიკური მხარდაჭერა: support@company.ge",
      spacing: { after: 50 }
    }),
    new Paragraph({
      text: "ტელეფონი: +995 XXX XX XX XX",
      spacing: { after: 50 }
    }),
  ];
}

function generateAdvertisements(): Paragraph[] {
  return [
    new Paragraph({
      text: "18. რეკლამების მართვა",
      heading: HeadingLevel.HEADING_1,
      spacing: { before: 400, after: 200 }
    }),
    new Paragraph({
      text: "18.1 რეკლამის ტიპები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "სისტემა მხარს უჭერს ორი ტიპის რეკლამას:",
      spacing: { after: 100 }
    }),
    new Paragraph({
      text: "შიდა პრომოები (Internal):",
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 200, after: 100 }
    }),
    new Paragraph({ text: "• კომპანიის სიახლეები და ღონისძიებები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• თანამშრომლებისთვის აქციები და შეთავაზებები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შიდა ტრენინგები და პროგრამები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• კორპორატიული განცხადებები", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "გარე რეკლამები (External):",
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 200, after: 100 }
    }),
    new Paragraph({ text: "• პარტნიორი კომპანიების რეკლამები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სპონსორების მასალები", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გარე სერვისების შეთავაზებები", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "18.2 განთავსების ადგილები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "რეკლამის განთავსება შესაძლებელია სამ ადგილას:",
      spacing: { after: 100 }
    }),
    new Paragraph({
      text: "Dashboard (მთავარი გვერდი):",
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 200, after: 100 }
    }),
    new Paragraph({ text: "• დიდი ჰორიზონტალური ბანერი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ყველა მომხმარებელს ეჩვენება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მაღალი ხილვადობა", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "Sidebar (გვერდითა პანელი):",
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 200, after: 100 }
    }),
    new Paragraph({ text: "• კომპაქტური ვერტიკალური ბანერი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მუდმივად ხილული ნავიგაციის დროს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დისკრეტული ფორმატი", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({
      text: "Popup (ამომხტარი ფანჯარა):",
      heading: HeadingLevel.HEADING_3,
      spacing: { before: 200, after: 100 }
    }),
    new Paragraph({ text: "• მოდალური ფანჯარა შესვლისას", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• 24 საათში ერთხელ ჩვენება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მაქსიმალური ყურადღება", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "18.3 რეკლამის შექმნა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "ახალი რეკლამის დამატება:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "1. გადადით სისტემა → რეკლამების მართვა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. დააჭირეთ 'ახალი რეკლამა' ღილაკს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. შეავსეთ სავალდებულო ველები:", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "   • სათაური", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "   • აღწერა", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "   • რეკლამის ტიპი (შიდა/გარე)", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "   • განთავსება (dashboard/sidebar/popup)", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "   • პრიორიტეტი (1-10)", bullet: { level: 1 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. ატვირთეთ სურათი (არასავალდებულო)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "5. მიუთითეთ გადასვლის ბმული", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "6. დააყენეთ დაწყება/დასრულების თარიღი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "7. აირჩიეთ სამიზნე როლები (არასავალდებულო)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "8. შეინახეთ რეკლამა", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "18.4 სტატისტიკა და ანალიტიკა",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "თითოეული რეკლამისთვის ხელმისაწვდომია:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• ნახვების რაოდენობა - რამდენჯერ გამოჩნდა რეკლამა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• კლიკების რაოდენობა - რამდენჯერ დააკლიკეს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• CTR (Click-Through Rate) - კლიკების პროცენტი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• აქტიურობის სტატუსი", bullet: { level: 0 }, spacing: { after: 300 } }),

    new Paragraph({
      text: "18.5 უფლებები",
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 300, after: 100 }
    }),
    new Paragraph({
      text: "რეკლამების მართვის უფლება აქვთ:",
      spacing: { after: 100 }
    }),
    new Paragraph({ text: "• Admin - სრული წვდომა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• HR Manager - სრული წვდომა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• სხვა მომხმარებლები - მხოლოდ რეკლამების ნახვა", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generatePayrollRunHistory(): Paragraph[] {
  return [
    new Paragraph({ text: "20. ხელფასის გაშვების ისტორია", heading: HeadingLevel.HEADING_1, spacing: { before: 400, after: 200 } }),
    new Paragraph({ text: "სისტემა ინახავს ხელფასის ყოველი ყოველთვიური გაშვების სრულ ისტორიას, რაც უზრუნველყოფს გამჭვირვალობას და აუდიტს.", spacing: { after: 200 } }),

    new Paragraph({ text: "20.1 გაშვების ისტორიის ნახვა", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "1. გადადით 'ხელფასი' → 'გაშვების ისტორია'", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "2. ნახეთ ყველა ადრე გაშვებული პერიოდი (თვე/წელი)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "3. გაშვების სტატუსები: მიმდინარე, წარმატებული, შეცდომით დასრულებული", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "4. დააჭირეთ ჩანაწერს დეტალური ინფორმაციისთვის", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({ text: "20.2 თითოეული გაშვების დეტალები", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• გაშვების თარიღი და დროის შტამპი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ვინ გაუშვა (ადმინი/HR მენეჯერი)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დამუშავებული თანამშრომლების რაოდენობა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• მთლიანი დარიცხული თანხა (gross)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დაუკავებელი გადასახადები (საშემოსავლო, საპენსიო)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გადასახდელი თანხა (net)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• შეცდომების ჟურნალი (თუ მოხდა)", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({ text: "20.3 გადათვლა და განმეორებითი გაშვება", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• ერთი და იგივე პერიოდის ხელახალი გაშვება უსაფრთხოა - სისტემა ცვლის წინა მნიშვნელობებს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ყველა ცვლილება იწერება აუდიტის ჟურნალში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გადასახადების ცვლილების შემთხვევაში სასურველია გადათვლა", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateHRAnalytics(): Paragraph[] {
  return [
    new Paragraph({ text: "21. HR ანალიტიკა და მეტრიკები", heading: HeadingLevel.HEADING_1, spacing: { before: 400, after: 200 } }),
    new Paragraph({ text: "სისტემა იყენებს საერთაშორისო HR სტანდარტებს (ISO 30414, SHRM, Gallup Q12, Bersin, Mercer) მეტრიკების გასაანგარიშებლად.", spacing: { after: 200 } }),

    new Paragraph({ text: "21.1 თანამშრომელთა მეტრიკები", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• Headcount = აქტიური თანამშრომლების რაოდენობა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Turnover Rate = (წასული თანამშრომლები / საშუალო headcount) × 100 (ISO 30414)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Retention Rate = 100 - Turnover Rate", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• New Hire Rate = (ბოლო 30 დღის ახალდანიშნულები / სულ) × 100", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Average Tenure = ყველა აქტიური თანამშრომლის სტაჟის საშუალო", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({ text: "21.2 დასწრების მეტრიკები", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• Attendance Rate = (გამოცხადებული დღეები / აქტიური თანამშრომლები) × 100", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Absenteeism Rate = (გაუმართლებელი არყოფნა / სამუშაო დღეები) × 100 (Bersin)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Punctuality = (დროულად მოსულები / სულ check-in) × 100", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Overtime % = (ზეგანაკვეთური / რეგულარული საათები) × 100 - საქართველოს შრომის კოდექსით 48 სთ/კვირა ლიმიტი", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({ text: "21.3 ჩართულობის მეტრიკები (Engagement)", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• eNPS = % პრომოუტერი (9-10) − % დეტრაქტორი (0-6) (Reichheld სტანდარტი)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Engagement Index = 6 კატეგორიის საშუალო (ლიდერობა, კარიერა, ანაზღაურება, კომუნიკაცია, გარემო, აღიარება) - Gallup Q12 მოდელი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Participation Rate = (ხმის მიმცემები / სულ) × 100", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({ text: "21.4 შესრულების მეტრიკები (Performance)", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• OKR Achievement = (მიღწეული key results / სულ) × 100 - 70% ჩაითვლება წარმატებად", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• 9-Box Grid - შესრულება vs. პოტენციალი (McKinsey მოდელი)", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({ text: "21.5 ანაზღაურების მეტრიკები", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• Compa-Ratio = (რეალური ხელფასი / midpoint) × 100 - Mercer სტანდარტი, ნორმა 80-120%", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Salary Range Penetration - სად ეფინება ხელფასი დიაპაზონში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Cost per Hire - SHRM სტანდარტი", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({ text: "21.6 დასწავლა და კეთილდღეობა", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• Training Completion Rate, Skills Coverage", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Burnout Risk Score - AI-ით (ზეგანაკვეთური + შვებულების გამოყენება + გამოკითხვები)", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generateAIFeatures(): Paragraph[] {
  return [
    new Paragraph({ text: "22. AI ფუნქციები და ავტომატიზაცია", heading: HeadingLevel.HEADING_1, spacing: { before: 400, after: 200 } }),
    new Paragraph({ text: "სისტემა იყენებს Lovable AI Gateway-ს (Gemini, GPT) HR პროცესების გასაუმჯობესებლად.", spacing: { after: 200 } }),

    new Paragraph({ text: "22.1 AI ასისტენტი", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• ბუნებრივ ენაზე კითხვები HR მონაცემებზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• RAG-ით პასუხები კომპანიის რეალური მონაცემებიდან", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ტიკეტების ავტო-რეზოლუცია უსაფრთხო SQL-ით", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({ text: "22.2 AI შეტყობინებები", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• ჭკვიანი HR შეტყობინებები (pg_cron)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• კონტრაქტის ვადის შემოწმება", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• დასწრების ანომალიების გამოვლენა", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({ text: "22.3 AI პროგნოზები", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• Employee Risk Prediction - წასვლის რისკი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Budget Forecast - ბიუჯეტის პროგნოზი", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• CV Match Analysis - კანდიდატის შესაბამისობა ვაკანსიასთან", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• AI Performance Review - შესრულების შეფასების დახმარება", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}

function generatePasswordSecurity(): Paragraph[] {
  return [
    new Paragraph({ text: "23. პაროლი და უსაფრთხოების განახლებები", heading: HeadingLevel.HEADING_1, spacing: { before: 400, after: 200 } }),

    new Paragraph({ text: "23.1 პაროლის გადაცემა ახალი თანამშრომლისთვის", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "თანამშრომლის რეგისტრაციისას ან პაროლის განახლებისას:", spacing: { after: 100 } }),
    new Paragraph({ text: "• პაროლი ავტომატურად იგზავნება Email-ით (პერსონალიზებული შაბლონი)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Email შეიცავს: სახელს, ელ-ფოსტას, ახალ პაროლს და შესვლის ბმულს", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• პარალელურად შესაძლებელია SMS-ით გადაცემა (CloudSMS)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• გაგზავნა ხდება უსაფრთხო email რიგით (queue-ით)", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({ text: "23.2 პაროლის აღდგენა", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• თვითმომსახურება შესვლის გვერდიდან (Email ბმული)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• ადმინ/HR-ის მიერ ხელით ცვლილება - ახალი პაროლი ავტომატურად მიდის თანამშრომელთან Email-ით", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• პაროლის სიძლიერის ვალიდაცია (8+ სიმბოლო, ციფრი, ასო)", bullet: { level: 0 }, spacing: { after: 200 } }),

    new Paragraph({ text: "23.3 უსაფრთხოების სტანდარტები", heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 100 } }),
    new Paragraph({ text: "• ISO 27001, GDPR და საქართველოს კანონმდებლობასთან შესაბამისობა", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• End-to-End დაშიფვრა (AES-256-GCM) მგრძნობიარე ველებისთვის", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• RLS პოლიტიკები ყველა ცხრილზე", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Intrusion Detection System (SQLi, XSS, AI prompt injection)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Rate limiting და JWT ვალიდაცია edge function-ებში", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• Audit Log ყველა მნიშვნელოვანი ქმედებისთვის (რისკის დონეებით)", bullet: { level: 0 }, spacing: { after: 50 } }),
    new Paragraph({ text: "• IP ანომალიის გამოვლენა და ავტომატური ალერტი", bullet: { level: 0 }, spacing: { after: 400 } }),
  ];
}
