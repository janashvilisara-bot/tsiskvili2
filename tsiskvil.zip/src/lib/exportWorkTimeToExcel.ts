import ExcelJS from 'exceljs';

interface DailyAttendance {
  date: string;
  check_in: string | null;
  check_out: string | null;
  hours: number;
  status: string;
}

interface WorkTimeRecord {
  employee_id: string;
  employee_name: string;
  employee_number: string;
  position: string;
  total_hours: number;
  regular_hours: number;
  overtime_hours: number;
  night_overtime_hours: number;
  rest_holiday_hours: number;
  vacation_days: number;
  absence_days: number;
  worked_days: number;
  other: number;
  daily_records: { [key: string]: DailyAttendance };
  planned_hours: number;
}

interface OrganizationInfo {
  name: string;
  address: string;
  phone: string;
  email: string;
}

export const exportWorkTimeToExcel = async (
  records: WorkTimeRecord[],
  orgInfo: OrganizationInfo | null,
  startDate: string,
  endDate: string,
  filename: string
) => {
  try {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('სამუშაო დრო');

    // Header - Organization Info
    worksheet.addRow(['სამუშაო დროის აღრიცხვის ფორმა']);
    worksheet.addRow([]);
    worksheet.addRow(['კომპანიის დასახელება', orgInfo?.name || '']);
    worksheet.addRow(['მისამართი', orgInfo?.address || '']);
    worksheet.addRow(['ტელეფონი', orgInfo?.phone || '']);
    worksheet.addRow(['შედგენის თარიღი', new Date().toLocaleDateString('ka-GE')]);
    worksheet.addRow(['საანგარიშო პერიოდი', `${startDate} - ${endDate}`]);
    worksheet.addRow([]);
    worksheet.addRow([]);

    // Header above days columns
    const daysHeaderRow = worksheet.addRow([
      '',
      '',
      '',
      'აღნიშვნები სამუშაოზე გამოცხადების/არგამოცხადების შესახებ თარიღების მიხედვით თვის განმავლობაში'
    ]);

    // Table Headers
    const headers = [
      'გვარი, სახელი',
      'პირადი ნომერი/ტაბელის ნომერი',
      'თანამდებობა (სახელმწიფო, კრედიტით)',
      '1', '2', '3', '4', '5', '6', '7', '8', '9', '10',
      '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
      '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31',
      'ჯამი დღე',
      'ჯამი საათი',
      'ზეგანაკვეთური დღე',
      'ზეგანაკვეთური საათი',
      'დასვენება',
      'ზეგანაკვეთური ღამე',
      'უქმე დღეები',
      'შვებულება',
      'გაცდენა',
      'სხვა'
    ];
    const headerRow = worksheet.addRow(headers);
    headerRow.font = { bold: true };
    headerRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    // Data rows
    records.forEach(record => {
      const startMonth = new Date(startDate).getMonth();
      const startYear = new Date(startDate).getFullYear();
      const daysInMonth = new Date(startYear, startMonth + 1, 0).getDate();
      
      const dailyCells: (string | number)[] = [];
      for (let day = 1; day <= 31; day++) {
        if (day <= daysInMonth) {
          const dateKey = `${startYear}-${String(startMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const dailyRecord = record.daily_records[dateKey];
          
          if (dailyRecord) {
            if (dailyRecord.status === 'present') {
              dailyCells.push(dailyRecord.hours.toFixed(1));
            } else if (dailyRecord.status === 'absent') {
              dailyCells.push('ა');
            } else {
              dailyCells.push('');
            }
          } else {
            dailyCells.push('');
          }
        } else {
          dailyCells.push('');
        }
      }

      worksheet.addRow([
        record.employee_name,
        record.employee_number,
        record.position,
        ...dailyCells,
        record.worked_days,
        record.total_hours.toFixed(1),
        Math.floor(record.overtime_hours / 8),
        record.overtime_hours.toFixed(1),
        record.rest_holiday_hours.toFixed(1),
        record.night_overtime_hours.toFixed(1),
        record.rest_holiday_hours.toFixed(1),
        record.vacation_days,
        record.absence_days,
        record.other
      ]);
    });

    // Add totals row
    if (records.length > 0) {
      const totalWorkedDays = records.reduce((sum, r) => sum + r.worked_days, 0);
      const totalHours = records.reduce((sum, r) => sum + r.total_hours, 0);
      const totalOvertime = records.reduce((sum, r) => sum + r.overtime_hours, 0);
      const totalNightOvertime = records.reduce((sum, r) => sum + r.night_overtime_hours, 0);
      const totalRestHoliday = records.reduce((sum, r) => sum + r.rest_holiday_hours, 0);
      const totalVacation = records.reduce((sum, r) => sum + r.vacation_days, 0);
      const totalAbsence = records.reduce((sum, r) => sum + r.absence_days, 0);
      const totalOther = records.reduce((sum, r) => sum + r.other, 0);

      const totalsRow = worksheet.addRow([
        'სულ:',
        '',
        '',
        ...Array(31).fill(''),
        totalWorkedDays,
        totalHours.toFixed(1),
        Math.floor(totalOvertime / 8),
        totalOvertime.toFixed(1),
        totalRestHoliday.toFixed(1),
        totalNightOvertime.toFixed(1),
        totalRestHoliday.toFixed(1),
        totalVacation,
        totalAbsence,
        totalOther
      ]);
      totalsRow.font = { bold: true };
    }

    // Add legend section
    worksheet.addRow([]);
    worksheet.addRow([]);
    worksheet.addRow(['პირობითი აღნიშვნები']);
    worksheet.addRow(['დ', '', 'დასვენება, უქმე დღე']);
    worksheet.addRow(['ა/შ', '', 'შეუძლებელია ანაზღაურებადი ანაზღაურების გარეშე შვებულება']);
    worksheet.addRow(['უ/შ', '', 'საავადმყოფო ფურცელი']);
    worksheet.addRow(['ს/დ', '', 'სავალდებულო ფორმელი']);
    worksheet.addRow(['დ/შ-ა', '', 'დაცვილის შვებულება (ანაზღაურებადი)']);
    worksheet.addRow(['დ/შ-უ', '', 'დაცვილის შვებულება - ანაზღაურების გარეშე']);
    worksheet.addRow(['ბ', '', 'გაცდენა']);

    // Set column widths
    worksheet.getColumn(1).width = 25;
    worksheet.getColumn(2).width = 20;
    worksheet.getColumn(3).width = 30;
    for (let i = 4; i <= 34; i++) {
      worksheet.getColumn(i).width = 4;
    }
    for (let i = 35; i <= 44; i++) {
      worksheet.getColumn(i).width = 12;
    }

    // Merge cells for header
    worksheet.mergeCells('A1:K1');
    worksheet.mergeCells('D10:AH10');

    // Create comparison sheet
    const comparisonSheet = workbook.addWorksheet('შედარება');
    comparisonSheet.addRow(['შედარებითი რეპორტი - დაგეგმილი vs ფაქტობრივი საათები']);
    comparisonSheet.addRow([]);
    comparisonSheet.addRow(['კომპანიის დასახელება', orgInfo?.name || '']);
    comparisonSheet.addRow(['საანგარიშო პერიოდი', `${startDate} - ${endDate}`]);
    comparisonSheet.addRow([]);
    
    const compHeaders = comparisonSheet.addRow([
      'თანამშრომელი',
      'პოზიცია',
      'დაგეგმილი საათები',
      'ფაქტობრივი საათები',
      'სხვაობა',
      'შესრულების %',
      'ზეგანაკვეთური',
      'ღამის საათები',
      'დასვენების დღეები'
    ]);
    compHeaders.font = { bold: true };
    compHeaders.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };
    
    records.forEach(record => {
      const difference = record.total_hours - record.planned_hours;
      const percentage = record.planned_hours > 0 
        ? ((record.total_hours / record.planned_hours) * 100).toFixed(1)
        : '0';
      
      comparisonSheet.addRow([
        record.employee_name,
        record.position,
        record.planned_hours.toFixed(1),
        record.total_hours.toFixed(1),
        difference.toFixed(1),
        `${percentage}%`,
        record.overtime_hours.toFixed(1),
        record.night_overtime_hours.toFixed(1),
        record.rest_holiday_hours.toFixed(1)
      ]);
    });
    
    if (records.length > 0) {
      const totalPlanned = records.reduce((sum, r) => sum + r.planned_hours, 0);
      const totalActual = records.reduce((sum, r) => sum + r.total_hours, 0);
      const totalDiff = totalActual - totalPlanned;
      const totalPercentage = totalPlanned > 0 
        ? ((totalActual / totalPlanned) * 100).toFixed(1)
        : '0';
      
      const totalsRow = comparisonSheet.addRow([
        'სულ:',
        '',
        totalPlanned.toFixed(1),
        totalActual.toFixed(1),
        totalDiff.toFixed(1),
        `${totalPercentage}%`,
        records.reduce((sum, r) => sum + r.overtime_hours, 0).toFixed(1),
        records.reduce((sum, r) => sum + r.night_overtime_hours, 0).toFixed(1),
        records.reduce((sum, r) => sum + r.rest_holiday_hours, 0).toFixed(1)
      ]);
      totalsRow.font = { bold: true };
    }
    
    // Set comparison sheet column widths
    comparisonSheet.columns = [
      { width: 25 },
      { width: 30 },
      { width: 15 },
      { width: 15 },
      { width: 12 },
      { width: 12 },
      { width: 15 },
      { width: 15 },
      { width: 15 }
    ];
    
    comparisonSheet.mergeCells('A1:I1');

    // Export file
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.xlsx`;
    link.click();
    window.URL.revokeObjectURL(url);

    return true;
  } catch (error) {
    console.error('Excel export error:', error);
    return false;
  }
};
