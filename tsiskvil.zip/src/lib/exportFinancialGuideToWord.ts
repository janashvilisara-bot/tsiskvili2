import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell, WidthType, BorderStyle } from 'docx';
import { saveAs } from 'file-saver';

export const exportFinancialGuideToWord = async () => {
  const today = new Date().toLocaleDateString('ka-GE');

  const sections = [
    {
      title: 'ზოგადი მიმოხილვა',
      content: 'ფინანსური სისტემა მოიცავს ხელფასების დარიცხვას, ბიუჯეტის დაგეგმვას, ხარჯების აღრიცხვას, ზეგანაკვეთური სამუშაოს აღრიცხვას და კომპენსაციების მართვას. სისტემა ინტეგრირებულია დასწრების აღრიცხვასთან, შვებულებებთან და სამუშაო გრაფიკებთან.'
    },
    {
      title: 'მთავარი კომპონენტები',
      items: [
        'Payroll (ხელფასები) - ყოველთვიური ხელფასების დარიცხვა და გადახდა',
        'Budget Planning (ბიუჯეტის დაგეგმვა) - დეპარტამენტების ბიუჯეტის დაგეგმვა',
        'Budget Expenses (ხარჯები) - ხარჯების აღრიცხვა და ანალიზი',
        'Overtime (ზეგანაკვეთური) - ზეგანაკვეთური საათების აღრიცხვა და გადახდა',
        'Compensation (კომპენსაცია) - ბონუსები და დამატებითი კომპენსაციები',
        'Reports (ანგარიშები) - ფინანსური ანგარიშგება და ანალიტიკა'
      ]
    },
    {
      title: 'ხელფასების გამოთვლა',
      content: 'წმინდა ხელფასი = საბაზო ხელფასი + ბონუსები + დღესასწაულების ზეგანაკვეთური - დაკავებები - პენსია',
      items: [
        'საბაზო ხელფასი - თანამშრომლის ხელშეკრულებით განსაზღვრული თანხა',
        'ბონუსები - ხელით შეყვანილი ბონუსები და წახალისება',
        'დღესასწაულების ზეგანაკვეთური - საჯარო დღესასწაულებზე მუშაობის ანაზღაურება (x2)',
        'დაკავებები - ჯარიმები, სესხის დაფარვა და სხვა დაკავებები',
        'პენსიის შენატანი - 2% საბაზო ხელფასიდან'
      ]
    },
    {
      title: 'ზეგანაკვეთური მულტიპლიკატორები',
      items: [
        'სამუშაო დღეები - x1.5 (საათობრივი განაკვეთის 150%)',
        'შაბათ-კვირა - x2.0 (საათობრივი განაკვეთის 200%)',
        'საჯარო დღესასწაულები - x2.0 (საათობრივი განაკვეთის 200%)',
        'ღამის ცვლები (22:00-06:00) - დამატებითი კომპენსაცია'
      ]
    },
    {
      title: 'ბიუჯეტის კატეგორიები',
      items: [
        'Salaries - ხელფასები და დაკავშირებული ხარჯები',
        'Benefits - თანამშრომელთა შეღავათები და სოციალური პაკეტი',
        'Training - ტრენინგები და პროფესიული განვითარება',
        'Equipment - აღჭურვილობა და ტექნიკა',
        'Marketing - მარკეტინგული აქტივობები',
        'Operations - ოპერაციული ხარჯები',
        'Other - სხვა დანარჩენი კატეგორიები'
      ]
    },
    {
      title: 'მონაცემთა წყაროები',
      items: [
        'employees - თანამშრომლების ინფორმაცია და ხელფასები',
        'payroll - ხელფასის დარიცხვები და გადახდები',
        'budget_plans - ბიუჯეტის გეგმები და პროგნოზები',
        'budget_expenses - ფაქტობრივი ხარჯები',
        'overtime_requests - ზეგანაკვეთური სამუშაოს მოთხოვნები',
        'compensation - კომპენსაციები და ბონუსები',
        'public_holidays - საჯარო დღესასწაულები',
        'attendance - დასწრების აღრიცხვა'
      ]
    },
    {
      title: 'ფინანსური ანგარიშები',
      items: [
        'ხელფასების ანგარიში - ყოველთვიური ხელფასების დეტალური ანალიზი',
        'ზეგანაკვეთურის ანგარიში - ზეგანაკვეთური საათების სტატისტიკა',
        'ბიუჯეტის ანგარიში - დაგეგმილი vs ფაქტობრივი ხარჯები',
        'დეპარტამენტული ანალიზი - ხარჯების განაწილება დეპარტამენტების მიხედვით',
        'დღესასწაულების ზეგანაკვეთური - საჯარო დღესასწაულებზე მუშაობის ანგარიში',
        'სრული ფინანსური რეპორტი - ყოველთვიური კონსოლიდირებული ანგარიში'
      ]
    },
    {
      title: 'ავტომატიზაცია',
      items: [
        'დღესასწაულების ავტომატური ამოცნობა - public_holidays ცხრილიდან',
        'ზეგანაკვეთურის ავტომატური დარიცხვა - overtime_requests-ის საფუძველზე',
        'პენსიის ავტომატური გამოთვლა - 2% საბაზო ხელფასიდან',
        'ბიუჯეტის ვარიანსის ავტომატური გამოთვლა - დაგეგმილი vs ფაქტობრივი',
        'Real-time სტატისტიკა - Dashboard-ზე ცოცხალი მონაცემები'
      ]
    }
  ];

  const children: Paragraph[] = [];

  // Title
  children.push(
    new Paragraph({
      children: [
        new TextRun({
          text: 'ფინანსური სისტემის დოკუმენტაცია',
          bold: true,
          size: 48,
          color: '14B8A6',
        }),
      ],
      heading: HeadingLevel.TITLE,
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
    })
  );

  // Subtitle
  children.push(
    new Paragraph({
      children: [
        new TextRun({
          text: 'HR & CRM Pro System',
          size: 28,
          color: '666666',
        }),
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: 100 },
    })
  );

  // Date
  children.push(
    new Paragraph({
      children: [
        new TextRun({
          text: `გენერირების თარიღი: ${today}`,
          size: 20,
          color: '999999',
        }),
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
    })
  );

  // Sections
  sections.forEach((section, index) => {
    // Section title
    children.push(
      new Paragraph({
        children: [
          new TextRun({
            text: `${index + 1}. ${section.title}`,
            bold: true,
            size: 28,
            color: '14B8A6',
          }),
        ],
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 400, after: 200 },
      })
    );

    // Section content
    if (section.content) {
      children.push(
        new Paragraph({
          children: [
            new TextRun({
              text: section.content,
              size: 22,
            }),
          ],
          spacing: { after: 200 },
        })
      );
    }

    // Section items
    if (section.items) {
      section.items.forEach((item) => {
        children.push(
          new Paragraph({
            children: [
              new TextRun({
                text: '• ',
                size: 22,
                color: '06B6D4',
              }),
              new TextRun({
                text: item,
                size: 22,
              }),
            ],
            spacing: { after: 100 },
            indent: { left: 360 },
          })
        );
      });
    }
  });

  // Footer
  children.push(
    new Paragraph({
      children: [
        new TextRun({
          text: '─'.repeat(50),
          color: '14B8A6',
        }),
      ],
      spacing: { before: 600, after: 200 },
      alignment: AlignmentType.CENTER,
    })
  );

  children.push(
    new Paragraph({
      children: [
        new TextRun({
          text: 'HR & CRM Pro - ფინანსური სისტემა',
          italics: true,
          size: 20,
          color: '666666',
        }),
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: 100 },
    })
  );

  children.push(
    new Paragraph({
      children: [
        new TextRun({
          text: '© 2024-2025 All Rights Reserved',
          size: 16,
          color: '999999',
        }),
      ],
      alignment: AlignmentType.CENTER,
    })
  );

  const doc = new Document({
    sections: [
      {
        properties: {},
        children: children,
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `ფინანსური-გზამკვლევი-${today}.docx`);
};
