import ExcelJS from 'exceljs';
import { WorkTimeRecord } from '@/hooks/useWorkTimeData';
import { downloadWorkbook } from '@/lib/excelHelpers';

interface ComplianceViolation {
  employeeName: string;
  personalId: string;
  violationType: string;
  details: string;
  severity: 'high' | 'medium' | 'low';
}

export const exportLaborInspectionReport = async (
  records: WorkTimeRecord[],
  startDate: string,
  endDate: string,
  companyName: string = 'ორგანიზაცია'
) => {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'TalentOS HR System';
  workbook.created = new Date();

  // Sheet 1: Organization Info & Summary
  const summarySheet = workbook.addWorksheet('საერთო ინფორმაცია');
  
  summarySheet.mergeCells('A1:F1');
  const titleCell = summarySheet.getCell('A1');
  titleCell.value = 'შრომის ინსპექციის ანგარიში - lms.gov.ge';
  titleCell.font = { bold: true, size: 16 };
  titleCell.alignment = { horizontal: 'center' };

  summarySheet.mergeCells('A2:F2');
  summarySheet.getCell('A2').value = `პერიოდი: ${startDate} - ${endDate}`;
  summarySheet.getCell('A2').font = { size: 12 };
  summarySheet.getCell('A2').alignment = { horizontal: 'center' };

  summarySheet.mergeCells('A3:F3');
  summarySheet.getCell('A3').value = `ორგანიზაცია: ${companyName}`;
  summarySheet.getCell('A3').font = { size: 12 };
  summarySheet.getCell('A3').alignment = { horizontal: 'center' };

  summarySheet.mergeCells('A4:F4');
  summarySheet.getCell('A4').value = `გენერირებულია: ${new Date().toLocaleDateString('ka-GE')}`;
  summarySheet.getCell('A4').font = { size: 10, italic: true };
  summarySheet.getCell('A4').alignment = { horizontal: 'center' };

  // Summary stats
  const totalEmployees = records.length;
  const totalRegularHours = records.reduce((sum, r) => sum + r.regular_hours, 0);
  const totalOvertimeHours = records.reduce((sum, r) => sum + r.overtime_hours, 0);
  const totalNightHours = records.reduce((sum, r) => sum + r.night_work_hours, 0);
  const totalVacationDays = records.reduce((sum, r) => sum + r.vacation_days, 0);
  const totalBusinessTripDays = records.reduce((sum, r) => sum + r.total_business_trip_days, 0);

  const violations = analyzeViolations(records);
  const weeklyViolations = violations.filter(v => v.violationType === '40-საათიანი კვირის დარღვევა');
  const overtimeViolations = violations.filter(v => v.violationType === 'ზეგანაკვეთური ლიმიტის გადაჭარბება');

  summarySheet.addRow([]);
  summarySheet.addRow(['საერთო სტატისტიკა']);
  summarySheet.getRow(6).font = { bold: true, size: 13 };

  const statsData = [
    ['თანამშრომელთა რაოდენობა', totalEmployees],
    ['სულ რეგულარული საათები', Math.round(totalRegularHours * 100) / 100],
    ['სულ ზეგანაკვეთური საათები', Math.round(totalOvertimeHours * 100) / 100],
    ['სულ ღამის სამუშაო საათები', Math.round(totalNightHours * 100) / 100],
    ['სულ შვებულების დღეები', totalVacationDays],
    ['სულ მივლინების დღეები', totalBusinessTripDays],
    ['40-საათიანი კვირის დარღვევები', weeklyViolations.length],
    ['ზეგანაკვეთური ლიმიტის დარღვევები', overtimeViolations.length],
    ['სულ დარღვევები', violations.length],
  ];

  statsData.forEach(row => summarySheet.addRow(row));

  summarySheet.getColumn(1).width = 35;
  summarySheet.getColumn(2).width = 20;

  // Sheet 2: Employee Work Hours Detail
  const detailSheet = workbook.addWorksheet('თანამშრომლების საათები');

  detailSheet.columns = [
    { header: '№', key: 'index', width: 5 },
    { header: 'სახელი, გვარი', key: 'name', width: 25 },
    { header: 'პირადი ნომერი', key: 'personalId', width: 15 },
    { header: 'პოზიცია', key: 'position', width: 20 },
    { header: 'დეპარტამენტი', key: 'department', width: 18 },
    { header: 'ნამუშევარი დღეები', key: 'workedDays', width: 16 },
    { header: 'რეგულარული (სთ)', key: 'regularHours', width: 16 },
    { header: 'ზეგანაკვეთური (სთ)', key: 'overtimeHours', width: 18 },
    { header: 'ღამის სამუშაო (სთ)', key: 'nightHours', width: 18 },
    { header: 'უქმე/დასვენება (სთ)', key: 'restHolidayHours', width: 18 },
    { header: 'შვებულება (დღე)', key: 'vacationDays', width: 16 },
    { header: 'მივლინება (დღე)', key: 'businessTripDays', width: 16 },
    { header: 'გაცდენა (დღე)', key: 'absenceDays', width: 14 },
  ];

  // Style header
  const headerRow = detailSheet.getRow(1);
  headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4338CA' } };
  headerRow.alignment = { horizontal: 'center', wrapText: true };

  records.forEach((record, idx) => {
    detailSheet.addRow({
      index: idx + 1,
      name: record.employee_name,
      personalId: record.personal_id,
      position: record.position,
      department: record.department,
      workedDays: record.worked_days,
      regularHours: Math.round(record.regular_hours * 100) / 100,
      overtimeHours: Math.round(record.overtime_hours * 100) / 100,
      nightHours: Math.round(record.night_work_hours * 100) / 100,
      restHolidayHours: Math.round(record.rest_holiday_hours * 100) / 100,
      vacationDays: record.vacation_days,
      businessTripDays: record.total_business_trip_days,
      absenceDays: record.absence_days,
    });
  });

  // Sheet 3: Compliance Analysis
  const complianceSheet = workbook.addWorksheet('შესაბამისობის ანალიზი');

  complianceSheet.columns = [
    { header: '№', key: 'index', width: 5 },
    { header: 'თანამშრომელი', key: 'employeeName', width: 25 },
    { header: 'პირადი ნომერი', key: 'personalId', width: 15 },
    { header: 'დარღვევის ტიპი', key: 'violationType', width: 30 },
    { header: 'დეტალები', key: 'details', width: 45 },
    { header: 'სიმძიმე', key: 'severity', width: 12 },
  ];

  const compHeaderRow = complianceSheet.getRow(1);
  compHeaderRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  compHeaderRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFDC2626' } };
  compHeaderRow.alignment = { horizontal: 'center', wrapText: true };

  if (violations.length === 0) {
    complianceSheet.addRow({ index: '', employeeName: 'დარღვევები არ მოიძებნა', personalId: '', violationType: '', details: '✅ ყველა მეტრიკა შესაბამისობაშია', severity: '' });
  } else {
    violations.forEach((v, idx) => {
      const row = complianceSheet.addRow({
        index: idx + 1,
        employeeName: v.employeeName,
        personalId: v.personalId,
        violationType: v.violationType,
        details: v.details,
        severity: v.severity === 'high' ? '🔴 მაღალი' : v.severity === 'medium' ? '🟡 საშუალო' : '🟢 დაბალი',
      });

      if (v.severity === 'high') {
        row.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } };
      } else if (v.severity === 'medium') {
        row.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFBEB' } };
      }
    });
  }

  // Sheet 4: Overtime Details
  const overtimeSheet = workbook.addWorksheet('ზეგანაკვეთური დეტალები');

  overtimeSheet.columns = [
    { header: '№', key: 'index', width: 5 },
    { header: 'თანამშრომელი', key: 'name', width: 25 },
    { header: 'პირადი ნომერი', key: 'personalId', width: 15 },
    { header: 'ზეგანაკვეთური (სთ)', key: 'overtimeHours', width: 18 },
    { header: 'ანაზღაურებული (სთ)', key: 'paidOvertime', width: 18 },
    { header: 'არაანაზღაურებული (სთ)', key: 'unpaidOvertime', width: 20 },
    { header: 'ღამის ზეგანაკვეთური (სთ)', key: 'nightOvertime', width: 22 },
    { header: '48-სთ ლიმიტი', key: 'limitStatus', width: 15 },
  ];

  const otHeaderRow = overtimeSheet.getRow(1);
  otHeaderRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  otHeaderRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF59E0B' } };
  otHeaderRow.alignment = { horizontal: 'center', wrapText: true };

  const overtimeRecords = records.filter(r => r.overtime_hours > 0 || r.paid_overtime_hours > 0 || r.unpaid_overtime_hours > 0);

  overtimeRecords.forEach((record, idx) => {
    const weeklyAvgHours = (record.regular_hours + record.overtime_hours) / 4; // approximate weekly
    const withinLimit = weeklyAvgHours <= 48;

    overtimeSheet.addRow({
      index: idx + 1,
      name: record.employee_name,
      personalId: record.personal_id,
      overtimeHours: Math.round(record.overtime_hours * 100) / 100,
      paidOvertime: Math.round(record.paid_overtime_hours * 100) / 100,
      unpaidOvertime: Math.round(record.unpaid_overtime_hours * 100) / 100,
      nightOvertime: Math.round(record.night_overtime_hours * 100) / 100,
      limitStatus: withinLimit ? '✅ ნორმაში' : '⚠️ გადაჭარბ.',
    });
  });

  // Sheet 5: lms.gov.ge Compliance Summary (Georgian format)
  const lmsSheet = workbook.addWorksheet('lms.gov.ge ფორმატი');

  lmsSheet.mergeCells('A1:H1');
  const lmsTitle = lmsSheet.getCell('A1');
  lmsTitle.value = 'შრომის პირობების შესახებ ინფორმაცია - lms.gov.ge';
  lmsTitle.font = { bold: true, size: 14 };
  lmsTitle.alignment = { horizontal: 'center' };

  lmsSheet.mergeCells('A2:H2');
  lmsSheet.getCell('A2').value = `საანგარიშო პერიოდი: ${startDate} - ${endDate}`;
  lmsSheet.getCell('A2').font = { size: 11 };
  lmsSheet.getCell('A2').alignment = { horizontal: 'center' };

  lmsSheet.mergeCells('A3:H3');
  lmsSheet.getCell('A3').value = `დამსაქმებელი: ${companyName}`;
  lmsSheet.getCell('A3').font = { size: 11 };
  lmsSheet.getCell('A3').alignment = { horizontal: 'center' };

  // Section 1: General data
  lmsSheet.addRow([]);
  lmsSheet.addRow(['I. ზოგადი ინფორმაცია']);
  lmsSheet.getRow(5).font = { bold: true, size: 12 };

  const generalData = [
    ['დასაქმებულთა რაოდენობა', totalEmployees],
    ['ქალი', records.filter(r => r.department).length], // approximate
    ['კაცი', records.filter(r => r.department).length], // approximate
    ['საშუალო ხელფასი (₾)', records.length > 0 ? Math.round(records.reduce((s, r) => s + r.salary, 0) / records.length) : 0],
  ];
  generalData.forEach(row => lmsSheet.addRow(row));

  // Section 2: Working hours
  lmsSheet.addRow([]);
  lmsSheet.addRow(['II. სამუშაო დროის აღრიცხვა']);
  lmsSheet.getRow(lmsSheet.rowCount).font = { bold: true, size: 12 };

  const hoursData = [
    ['სულ ნამუშევარი საათები', Math.round(totalRegularHours + totalOvertimeHours)],
    ['რეგულარული საათები', Math.round(totalRegularHours)],
    ['ზეგანაკვეთური საათები', Math.round(totalOvertimeHours)],
    ['ღამის სამუშაო საათები (22:00-06:00)', Math.round(totalNightHours)],
    ['უქმე/დასვენების დღეებში ნამუშევარი საათები', Math.round(records.reduce((s, r) => s + r.rest_holiday_hours, 0))],
    ['40-საათიანი კვირის დარღვევები', weeklyViolations.length],
    ['48-საათიანი ლიმიტის დარღვევები', overtimeViolations.length],
  ];
  hoursData.forEach(row => lmsSheet.addRow(row));

  // Section 3: Leave and absence
  lmsSheet.addRow([]);
  lmsSheet.addRow(['III. შვებულება და გაცდენები']);
  lmsSheet.getRow(lmsSheet.rowCount).font = { bold: true, size: 12 };

  const leaveData = [
    ['ყოველწლიური შვებულების დღეები', totalVacationDays],
    ['მივლინების დღეები', totalBusinessTripDays],
    ['გაცდენის დღეები', records.reduce((s, r) => s + r.absence_days, 0)],
    ['დეკრეტული შვებულება (ანაზღაურებადი)', records.reduce((s, r) => s + r.paid_maternity_leave_days, 0)],
    ['დეკრეტული შვებულება (არაანაზღაურებადი)', records.reduce((s, r) => s + r.unpaid_maternity_leave_days, 0)],
  ];
  leaveData.forEach(row => lmsSheet.addRow(row));

  // Section 4: Compliance status
  lmsSheet.addRow([]);
  lmsSheet.addRow(['IV. შესაბამისობის სტატუსი']);
  lmsSheet.getRow(lmsSheet.rowCount).font = { bold: true, size: 12 };

  const complianceStatus = [
    ['სულ დარღვევები', violations.length],
    ['მაღალი რისკი', violations.filter(v => v.severity === 'high').length],
    ['საშუალო რისკი', violations.filter(v => v.severity === 'medium').length],
    ['დაბალი რისკი', violations.filter(v => v.severity === 'low').length],
  ];
  complianceStatus.forEach(row => {
    const addedRow = lmsSheet.addRow(row);
    if (row[0] === 'მაღალი რისკი' && (row[1] as number) > 0) {
      addedRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } };
    }
  });

  lmsSheet.getColumn(1).width = 45;
  lmsSheet.getColumn(2).width = 20;

  // Signature block
  lmsSheet.addRow([]);
  lmsSheet.addRow([]);
  lmsSheet.addRow(['პასუხისმგებელი პირი: _________________________']);
  lmsSheet.addRow(['თარიღი: ' + new Date().toLocaleDateString('ka-GE')]);
  lmsSheet.addRow(['ხელმოწერა: _________________________']);
  lmsSheet.addRow([]);
  lmsSheet.addRow(['ბეჭედი']);

  const filename = `შრომის_ინსპექციის_ანგარიში_${startDate}_${endDate}.xlsx`;
  await downloadWorkbook(workbook, filename);
};

function analyzeViolations(records: WorkTimeRecord[]): ComplianceViolation[] {
  const violations: ComplianceViolation[] = [];

  records.forEach(record => {
    // Check 40-hour work week (approximate: monthly hours / 4 weeks)
    const weeklyAvgHours = record.regular_hours / 4;
    if (weeklyAvgHours > 40) {
      violations.push({
        employeeName: record.employee_name,
        personalId: record.personal_id,
        violationType: '40-საათიანი კვირის დარღვევა',
        details: `საშუალო კვირეული: ${Math.round(weeklyAvgHours * 10) / 10} სთ (ნორმა: 40 სთ)`,
        severity: weeklyAvgHours > 48 ? 'high' : 'medium',
      });
    }

    // Check overtime limit (48 hours/week total including regular)
    const totalWeeklyAvg = (record.regular_hours + record.overtime_hours) / 4;
    if (totalWeeklyAvg > 48) {
      violations.push({
        employeeName: record.employee_name,
        personalId: record.personal_id,
        violationType: 'ზეგანაკვეთური ლიმიტის გადაჭარბება',
        details: `სულ კვირეული: ${Math.round(totalWeeklyAvg * 10) / 10} სთ (ლიმიტი: 48 სთ)`,
        severity: 'high',
      });
    }

    // Night work without proper tracking
    if (record.night_work_hours > 20) {
      violations.push({
        employeeName: record.employee_name,
        personalId: record.personal_id,
        violationType: 'ღამის სამუშაოს მაღალი მაჩვენებელი',
        details: `ღამის საათები: ${Math.round(record.night_work_hours * 10) / 10} სთ - საჭიროებს სპეციალურ კომპენსაციას`,
        severity: 'medium',
      });
    }

    // Leave balance check (24 days annual minimum)
    if (record.vacation_days > 24) {
      violations.push({
        employeeName: record.employee_name,
        personalId: record.personal_id,
        violationType: 'შვებულების ლიმიტის გადაჭარბება',
        details: `გამოყენებული: ${record.vacation_days} დღე (წლიური ნორმა: 24 დღე)`,
        severity: 'low',
      });
    }
  });

  return violations.sort((a, b) => {
    const severityOrder = { high: 0, medium: 1, low: 2 };
    return severityOrder[a.severity] - severityOrder[b.severity];
  });
}
