// Notification sound using Web Audio API - no external files needed
let audioContext: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioContext) {
    audioContext = new AudioContext();
  }
  return audioContext;
}

/**
 * Play a ringtone-like notification sound using Web Audio API
 * Plays a pleasant multi-tone chime sequence
 */
export function playNotificationSound() {
  try {
    const ctx = getAudioContext();
    
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const now = ctx.currentTime;
    
    // Create a pleasant 3-tone chime sequence
    const frequencies = [830, 1050, 1250]; // Pleasant ascending tones
    const durations = [0.15, 0.15, 0.3];
    let offset = 0;

    frequencies.forEach((freq, i) => {
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(freq, now + offset);
      
      // Envelope: quick attack, sustain, fade out
      gainNode.gain.setValueAtTime(0, now + offset);
      gainNode.gain.linearRampToValueAtTime(0.3, now + offset + 0.02);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + offset + durations[i]);
      
      oscillator.start(now + offset);
      oscillator.stop(now + offset + durations[i] + 0.05);
      
      offset += durations[i] + 0.05;
    });

    // Second ring after short pause
    setTimeout(() => {
      try {
        const now2 = ctx.currentTime;
        frequencies.forEach((freq, i) => {
          const oscillator = ctx.createOscillator();
          const gainNode = ctx.createGain();
          
          oscillator.connect(gainNode);
          gainNode.connect(ctx.destination);
          
          oscillator.type = 'sine';
          oscillator.frequency.setValueAtTime(freq, now2 + i * 0.2);
          
          gainNode.gain.setValueAtTime(0, now2 + i * 0.2);
          gainNode.gain.linearRampToValueAtTime(0.25, now2 + i * 0.2 + 0.02);
          gainNode.gain.exponentialRampToValueAtTime(0.01, now2 + i * 0.2 + durations[i]);
          
          oscillator.start(now2 + i * 0.2);
          oscillator.stop(now2 + i * 0.2 + durations[i] + 0.05);
        });
      } catch (e) {
        // Ignore errors on repeat
      }
    }, 600);
  } catch (error) {
    console.warn('Could not play notification sound:', error);
  }
}
