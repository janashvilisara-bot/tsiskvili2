/**
 * Retry helper for Supabase operations during peak load.
 * Retries on transient errors (network, timeout, connection pool exhaustion)
 * with exponential backoff. Does NOT retry on permission/validation errors.
 */

type SupabaseResult<T> = { data: T | null; error: any };

const TRANSIENT_ERROR_CODES = new Set([
  '08000', '08003', '08006', '08001', '08004', // connection exceptions
  '53300', // too_many_connections
  '57P03', // cannot_connect_now
  'XX000', // internal error (often transient under load)
]);

const isTransientError = (error: any): boolean => {
  if (!error) return false;
  // Network errors (fetch failures)
  if (error.message?.includes('Failed to fetch')) return true;
  if (error.message?.includes('NetworkError')) return true;
  if (error.message?.includes('timeout')) return true;
  if (error.message?.toLowerCase().includes('connection')) return true;
  // Postgres transient codes
  if (error.code && TRANSIENT_ERROR_CODES.has(error.code)) return true;
  // 503/504 from edge
  if (error.status === 503 || error.status === 504) return true;
  return false;
};

/**
 * Retry a Supabase operation up to `maxAttempts` times with exponential backoff.
 * @example
 *   const { data, error } = await withRetry(() =>
 *     supabase.from('attendance').insert([payload]).select().single()
 *   );
 */
export async function withRetry<T>(
  op: () => PromiseLike<SupabaseResult<T>>,
  opts: { maxAttempts?: number; baseDelayMs?: number } = {}
): Promise<SupabaseResult<T>> {
  const maxAttempts = opts.maxAttempts ?? 3;
  const baseDelay = opts.baseDelayMs ?? 400;

  let lastResult: SupabaseResult<T> = { data: null, error: null };

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      lastResult = await op();
      if (!lastResult.error) return lastResult;
      if (!isTransientError(lastResult.error)) return lastResult;
    } catch (err: any) {
      lastResult = { data: null, error: err };
      if (!isTransientError(err)) return lastResult;
    }

    if (attempt < maxAttempts) {
      // Exponential backoff with jitter: 400ms, 800ms, 1600ms (+ up to 200ms jitter)
      const delay = baseDelay * Math.pow(2, attempt - 1) + Math.random() * 200;
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }

  return lastResult;
}
