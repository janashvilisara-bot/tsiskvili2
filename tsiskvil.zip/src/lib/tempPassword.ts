const LOWER = "abcdefghijkmnpqrstuvwxyz";
const UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ";
const DIGITS = "23456789";
const SYMBOLS = "!@#$%*";

function pick(set: string): string {
  const buf = new Uint32Array(1);
  crypto.getRandomValues(buf);
  return set[buf[0] % set.length];
}

/** Strong temporary password: 12 chars with lower, upper, digit and symbol. */
export function generateTempPassword(length = 12): string {
  const all = LOWER + UPPER + DIGITS + SYMBOLS;
  const chars = [pick(LOWER), pick(UPPER), pick(DIGITS), pick(SYMBOLS)];
  while (chars.length < length) chars.push(pick(all));
  for (let i = chars.length - 1; i > 0; i--) {
    const buf = new Uint32Array(1);
    crypto.getRandomValues(buf);
    const j = buf[0] % (i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

/** Returns a Georgian error message, or null when the custom password is acceptable. */
export function validateCustomPassword(pw: string): string | null {
  if (pw.length < 8) return "პაროლი მინიმუმ 8 სიმბოლო უნდა იყოს";
  if (/^(.)\1+$/.test(pw) || /^(0123|1234|2345|3456|4567|5678|6789|password|qwerty)/i.test(pw))
    return "პაროლი ძალიან მარტივია";
  if (!/[a-zA-Z]/.test(pw) || !/\d/.test(pw)) return "პაროლი უნდა შეიცავდეს ასოებს და ციფრებს";
  return null;
}

/** Password to send on registration: custom if valid, otherwise generated. */
export function resolveRegistrationPassword(custom?: string): { password?: string; error?: string } {
  const c = custom?.trim();
  if (!c) return { password: generateTempPassword() };
  const err = validateCustomPassword(c);
  return err ? { error: err } : { password: c };
}
