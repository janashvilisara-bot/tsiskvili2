import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { WorkTimeRecord } from '@/hooks/useWorkTimeData';

export const exportLaborInspectionPDF = (
  records: WorkTimeRecord[],
  startDate: string,
  endDate: string,
  companyName: string = 'ორგანიზაცია'
) => {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });

  // Title
  doc.setFontSize(16);
  doc.text('Labor Inspection Report / შრომის ინსპექციის ანგარიში', 148, 15, { align: 'center' });
  
  doc.setFontSize(10);
  doc.text(`Period: ${startDate} - ${endDate}`, 148, 22, { align: 'center' });
  doc.text(`Organization: ${companyName}`, 148, 28, { align: 'center' });
  doc.text(`Generated: ${new Date().toLocaleDateString()}`, 148, 34, { align: 'center' });

  // Summary stats
  const totalEmployees = records.length;
  const totalRegularHours = Math.round(records.reduce((s, r) => s + r.regular_hours, 0) * 100) / 100;
  const totalOvertimeHours = Math.round(records.reduce((s, r) => s + r.overtime_hours, 0) * 100) / 100;
  const totalNightHours = Math.round(records.reduce((s, r) => s + r.night_work_hours, 0) * 100) / 100;

  const weeklyViolations = records.filter(r => r.regular_hours / 4 > 40).length;
  const overtimeLimitViolations = records.filter(r => (r.regular_hours + r.overtime_hours) / 4 > 48).length;

  autoTable(doc, {
    startY: 40,
    head: [['Metric', 'Value']],
    body: [
      ['Total Employees', totalEmployees.toString()],
      ['Regular Hours', totalRegularHours.toString()],
      ['Overtime Hours', totalOvertimeHours.toString()],
      ['Night Work Hours', totalNightHours.toString()],
      ['40h/week Violations', weeklyViolations.toString()],
      ['48h/week Limit Violations', overtimeLimitViolations.toString()],
    ],
    theme: 'grid',
    headStyles: { fillColor: [67, 56, 202] },
    margin: { left: 15 },
    tableWidth: 120,
  });

  // Employee details table
  doc.addPage();
  doc.setFontSize(14);
  doc.text('Employee Work Hours Detail', 148, 15, { align: 'center' });

  autoTable(doc, {
    startY: 22,
    head: [['#', 'Name', 'Personal ID', 'Position', 'Days', 'Regular (h)', 'Overtime (h)', 'Night (h)', 'Leave (d)', 'Trip (d)']],
    body: records.map((r, i) => [
      (i + 1).toString(),
      r.employee_name,
      r.personal_id || '-',
      r.position || '-',
      r.worked_days.toString(),
      (Math.round(r.regular_hours * 100) / 100).toString(),
      (Math.round(r.overtime_hours * 100) / 100).toString(),
      (Math.round(r.night_work_hours * 100) / 100).toString(),
      r.vacation_days.toString(),
      r.total_business_trip_days.toString(),
    ]),
    theme: 'grid',
    headStyles: { fillColor: [67, 56, 202], fontSize: 8 },
    bodyStyles: { fontSize: 7 },
    margin: { left: 10, right: 10 },
  });

  // Violations page
  const violations = records.filter(r => r.regular_hours / 4 > 40 || (r.regular_hours + r.overtime_hours) / 4 > 48 || r.night_work_hours > 20);
  
  if (violations.length > 0) {
    doc.addPage();
    doc.setFontSize(14);
    doc.text('Compliance Violations', 148, 15, { align: 'center' });

    const violationRows: string[][] = [];
    violations.forEach((r, i) => {
      const weeklyAvg = r.regular_hours / 4;
      const totalWeekly = (r.regular_hours + r.overtime_hours) / 4;
      
      if (weeklyAvg > 40) {
        violationRows.push([(violationRows.length + 1).toString(), r.employee_name, r.personal_id || '-', '40h/week violation', `Avg: ${Math.round(weeklyAvg * 10) / 10}h/week`, weeklyAvg > 48 ? 'HIGH' : 'MEDIUM']);
      }
      if (totalWeekly > 48) {
        violationRows.push([(violationRows.length + 1).toString(), r.employee_name, r.personal_id || '-', '48h/week limit exceeded', `Total: ${Math.round(totalWeekly * 10) / 10}h/week`, 'HIGH']);
      }
      if (r.night_work_hours > 20) {
        violationRows.push([(violationRows.length + 1).toString(), r.employee_name, r.personal_id || '-', 'High night work', `${Math.round(r.night_work_hours * 10) / 10}h night work`, 'MEDIUM']);
      }
    });

    autoTable(doc, {
      startY: 22,
      head: [['#', 'Employee', 'Personal ID', 'Violation Type', 'Details', 'Severity']],
      body: violationRows,
      theme: 'grid',
      headStyles: { fillColor: [220, 38, 38], fontSize: 8 },
      bodyStyles: { fontSize: 7 },
      didParseCell: (data) => {
        if (data.column.index === 5 && data.section === 'body') {
          const val = data.cell.raw as string;
          if (val === 'HIGH') {
            data.cell.styles.textColor = [220, 38, 38];
            data.cell.styles.fontStyle = 'bold';
          }
        }
      },
    });
  }

  doc.save(`Labor_Inspection_Report_${startDate}_${endDate}.pdf`);
};
