// Cleans Nina's replies: no markdown stars/headings, no list dashes or bullets.
export function cleanNinaText(input: string): string {
  if (!input) return input;
  return input
    .replace(/```[a-z]*\n?/gi, "")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/__([^_]+)__/g, "$1")
    .replace(/\*+/g, "")
    .replace(/^[ \t]*#{1,6}[ \t]+/gm, "")
    .replace(/^[ \t]*[-–—•▪◦][ \t]+/gm, (m) => (/[-–—]/.test(m.trim()) ? "- " : ""))
    .replace(/^[ \t]*(-{3,}|_{3,})[ \t]*$/gm, "")
    .replace(/[ \t]+[-–—][ \t]+/g, " - ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}
