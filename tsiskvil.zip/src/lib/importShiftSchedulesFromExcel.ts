import ExcelJS from 'exceljs';

export interface ImportedShiftSchedule {
  employee_name: string;
  shift_date: string;
  shift_name?: string;
  start_time: string;
  end_time: string;
  break_duration?: number;
  notes?: string;
}

export const importShiftSchedulesFromExcel = async (file: File): Promise<ImportedShiftSchedule[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      try {
        const buffer = e.target?.result as ArrayBuffer;
        if (!buffer) {
          reject(new Error('ფაილი ცარიელია'));
          return;
        }

        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.load(buffer);
        
        if (!workbook.worksheets || workbook.worksheets.length === 0) {
          reject(new Error('Excel ფაილი არ შეიცავს ფურცლებს'));
          return;
        }

        // Try to find the template sheet or use the first sheet
        let worksheet = workbook.worksheets.find(ws => 
          ws.name.includes('შაბლონი') || ws.name.includes('მაგალითები')
        ) || workbook.worksheets[0];

        if (!worksheet) {
          reject(new Error('ფურცელი ვერ მოიძებნა'));
          return;
        }

        const schedules: ImportedShiftSchedule[] = [];
        const headerRow = worksheet.getRow(1);
        const headers: { [key: number]: string } = {};
        
        // Map headers
        headerRow.eachCell((cell, colNumber) => {
          headers[colNumber] = String(cell.value || '').trim();
        });

        
        // Process data rows
        worksheet.eachRow((row, rowNumber) => {
          if (rowNumber === 1) return; // Skip header
          
          const rowData: { [key: string]: any } = {};
          let hasData = false;
          
          row.eachCell((cell, colNumber) => {
            const header = headers[colNumber];
            if (header) {
              let value = cell.value;
              // Handle date values
              if (value instanceof Date) {
                value = value.toISOString().split('T')[0];
              }
              rowData[header] = value;
              if (value && String(value).trim()) {
                hasData = true;
              }
            }
          });
          
          if (!hasData) return;

          const schedule: ImportedShiftSchedule = {
            employee_name: String(rowData['სახელი გვარი'] || rowData['Full Name'] || '').trim(),
            shift_date: String(rowData['თარიღი'] || rowData['Date'] || '').trim(),
            shift_name: String(rowData['ცვლის სახელი'] || rowData['Shift Name'] || '').trim(),
            start_time: String(rowData['დაწყება'] || rowData['Start Time'] || '').trim(),
            end_time: String(rowData['დასრულება'] || rowData['End Time'] || '').trim(),
            break_duration: parseFloat(String(rowData['შესვენება (წუთი)'] || rowData['Break (min)'] || '0')) || 0,
            notes: String(rowData['შენიშვნა'] || rowData['Notes'] || '').trim(),
          };
          
          if (schedule.employee_name) {
            schedules.push(schedule);
          }
        });
        
        resolve(schedules);
      } catch (error: any) {
        console.error('Import error:', error);
        reject(new Error('ფაილის წაკითხვა ვერ მოხერხდა: ' + error.message));
      }
    };
    
    reader.onerror = () => reject(new Error('ფაილის წაკითხვა ვერ მოხერხდა'));
    reader.readAsArrayBuffer(file);
  });
};
