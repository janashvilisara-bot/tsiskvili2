import ExcelJS from 'exceljs';

export const exportToExcel = async (data: any[], filename: string, sheetName: string = 'Sheet1'): Promise<boolean> => {
  try {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(sheetName);
    
    if (data.length === 0) {
      console.warn('No data to export');
      return false;
    }
    
    // Get headers from first object keys
    const headers = Object.keys(data[0]);
    worksheet.columns = headers.map(header => ({
      header: header,
      key: header,
      width: 15
    }));
    
    // Add rows
    data.forEach(item => {
      worksheet.addRow(item);
    });
    
    // Style header row
    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };
    
    // Generate buffer and download
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.xlsx`;
    link.click();
    window.URL.revokeObjectURL(url);
    
    return true;
  } catch (error) {
    console.error('Excel export error:', error);
    return false;
  }
};

export const exportMultipleSheets = async (sheets: { data: any[], name: string }[], filename: string): Promise<boolean> => {
  try {
    const workbook = new ExcelJS.Workbook();
    
    sheets.forEach(sheet => {
      if (sheet.data.length === 0) return;
      
      const worksheet = workbook.addWorksheet(sheet.name);
      const headers = Object.keys(sheet.data[0]);
      
      worksheet.columns = headers.map(header => ({
        header: header,
        key: header,
        width: 15
      }));
      
      sheet.data.forEach(item => {
        worksheet.addRow(item);
      });
      
      // Style header row
      worksheet.getRow(1).font = { bold: true };
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFE0E0E0' }
      };
    });
    
    // Generate buffer and download
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.xlsx`;
    link.click();
    window.URL.revokeObjectURL(url);
    
    return true;
  } catch (error) {
    console.error('Excel export error:', error);
    return false;
  }
};

// Legacy compatibility - synchronous wrapper (logs warning)
export const exportToExcelSync = (data: any[], filename: string, sheetName: string = 'Sheet1'): void => {
  console.warn('exportToExcelSync is deprecated. Use exportToExcel (async) instead.');
  exportToExcel(data, filename, sheetName);
};
