import { auth, defineMcp } from "@lovable.dev/mcp-js";
import getMyProfile from "./tools/get-my-profile";
import listMyLeaveRequests from "./tools/list-my-leave-requests";
import createLeaveRequest from "./tools/create-leave-request";

const projectRef = import.meta.env.VITE_SUPABASE_PROJECT_ID ?? "project-ref-unset";

export default defineMcp({
  name: "tsiskvili",
  title: "Tsiskvili",
  version: "0.1.0",
  instructions:
    "HR tools for the signed-in employee. Use `get_my_profile` to see the employee card, `list_my_leave_requests` to review leave, and `create_leave_request` to submit new leave.",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [getMyProfile, listMyLeaveRequests, createLeaveRequest],
});
