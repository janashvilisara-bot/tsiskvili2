import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "create_leave_request",
  title: "Request leave",
  description: "Submit a new leave request for the signed-in employee; it starts as pending approval.",
  inputSchema: {
    leave_type: z.enum(["annual", "sick", "personal", "unpaid"]).describe("Type of leave."),
    start_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).describe("Start date YYYY-MM-DD."),
    end_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).describe("End date YYYY-MM-DD."),
    reason: z.string().max(1000).optional().describe("Optional reason."),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  handler: async ({ leave_type, start_date, end_date, reason }, ctx) => {
    if (!ctx.isAuthenticated()) return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    if (end_date < start_date) return { content: [{ type: "text", text: "end_date must be on or after start_date" }], isError: true };
    const supabase = supabaseForUser(ctx);
    const userId = ctx.getUserId();
    const { data: emp, error: empErr } = await supabase
      .from("employees").select("id, branch_id").eq("user_id", userId).maybeSingle();
    if (empErr) return { content: [{ type: "text", text: empErr.message }], isError: true };
    if (!emp) return { content: [{ type: "text", text: "No employee record found for this user." }], isError: true };
    const { data, error } = await supabase
      .from("leave_requests")
      .insert({ employee_id: emp.id, user_id: userId, branch_id: emp.branch_id, leave_type, start_date, end_date, reason: reason ?? null })
      .select("id, leave_type, start_date, end_date, status")
      .single();
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    const request = { id: data.id, leave_type: data.leave_type, start_date: data.start_date, end_date: data.end_date, status: data.status };
    return { content: [{ type: "text", text: JSON.stringify(request) }], structuredContent: { request } };
  },
});
