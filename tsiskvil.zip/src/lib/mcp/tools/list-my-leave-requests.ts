import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_my_leave_requests",
  title: "List my leave requests",
  description: "List the signed-in user's leave requests, newest first, optionally filtered by status.",
  inputSchema: {
    status: z.enum(["pending", "approved", "rejected"]).optional().describe("Filter by status."),
    limit: z.number().int().min(1).max(100).optional().describe("Max rows (default 20)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ status, limit }, ctx) => {
    if (!ctx.isAuthenticated()) return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    let q = supabaseForUser(ctx)
      .from("leave_requests")
      .select("id, leave_type, start_date, end_date, reason, status, created_at")
      .eq("user_id", ctx.getUserId())
      .order("created_at", { ascending: false })
      .limit(limit ?? 20);
    if (status) q = q.eq("status", status);
    const { data, error } = await q;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    const requests = (data ?? []).map((r) => ({
      id: r.id, leave_type: r.leave_type, start_date: r.start_date, end_date: r.end_date,
      reason: r.reason ?? null, status: r.status, created_at: r.created_at,
    }));
    return { content: [{ type: "text", text: JSON.stringify(requests) }], structuredContent: { requests } };
  },
});
