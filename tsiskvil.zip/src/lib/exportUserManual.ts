import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableCell, TableRow, WidthType, BorderStyle } from 'docx';
import { saveAs } from 'file-saver';

export const exportUserManual = async () => {
  const doc = new Document({
    sections: [{
      properties: {},
      children: [
        // Title
        new Paragraph({
          text: "HR სისტემის სრული სახელმძღვანელო",
          heading: HeadingLevel.TITLE,
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "ვერსია 2.0 - ყველა ფუნქციონალის დეტალური აღწერა",
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: `${new Date().toLocaleDateString('ka-GE')}`,
          alignment: AlignmentType.CENTER,
          spacing: { after: 800 }
        }),

        // Table of Contents
        new Paragraph({
          text: "სარჩევი",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),

        new Paragraph({
          text: "1. თანამშრომლის რეგისტრაცია",
          spacing: { after: 100 }
        }),
        new Paragraph({
          text: "2. სამუშაო გრაფიკის მინიჭება",
          spacing: { after: 100 }
        }),
        new Paragraph({
          text: "3. დასწრების აღრიცხვა",
          spacing: { after: 100 }
        }),
        new Paragraph({
          text: "4. შვებულებების მართვა",
          spacing: { after: 100 }
        }),
        new Paragraph({
          text: "5. ზეგანაკვეთური სამუშაო",
          spacing: { after: 100 }
        }),
        new Paragraph({
          text: "6. ხელფასის დარიცხვა",
          spacing: { after: 100 }
        }),
        new Paragraph({ text: "7. პენსიის გადახდები", spacing: { after: 100 } }),
        new Paragraph({ text: "8. ფინანსური რეპორტები", spacing: { after: 100 } }),
        new Paragraph({ text: "9. კომპენსაციები და ბონუსები", spacing: { after: 100 } }),
        new Paragraph({ text: "10. ბიუჯეტის დაგეგმვა", spacing: { after: 100 } }),
        new Paragraph({ text: "11. დოკუმენტების მართვა და ელექტრონული ხელმოწერა", spacing: { after: 100 } }),
        new Paragraph({ text: "12. ორგანიზაციული სტრუქტურა", spacing: { after: 100 } }),
        new Paragraph({ text: "13. რეკრუტინგი", spacing: { after: 100 } }),
        new Paragraph({ text: "14. ამოცანების მართვა", spacing: { after: 100 } }),
        new Paragraph({ text: "15. კომუნიკაცია", spacing: { after: 100 } }),
        new Paragraph({ text: "16. უსაფრთხოება და როლები", spacing: { after: 100 } }),
        new Paragraph({ text: "17. AI ფუნქციები", spacing: { after: 100 } }),
        new Paragraph({ text: "18. ინტეგრაციები", spacing: { after: 100 } }),
        new Paragraph({ text: "19. შესაბამისობა საქართველოს კანონმდებლობასთან", spacing: { after: 100 } }),
        new Paragraph({ text: "20. სისტემის ადმინისტრირება", spacing: { after: 600 } }),

        // Section 1: Employee Registration
        new Paragraph({
          text: "1. თანამშრომლის რეგისტრაცია",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),

        new Paragraph({
          text: "თანამშრომლის დამატება არის პირველი ნაბიჯი სისტემაში. ეს პროცესი მოიცავს ძირითადი ინფორმაციის შეყვანას და ავტომატურ ავტორიზაციის ანგარიშის შექმნას.",
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "ნაბიჯები:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "1. გადადით Employees (თანამშრომლები) გვერდზე",
          bullet: { level: 0 },
          spacing: { after: 100 }
        }),
        new Paragraph({
          text: "2. დააჭირეთ ღილაკს 'ახალი თანამშრომელი'",
          bullet: { level: 0 },
          spacing: { after: 100 }
        }),
        new Paragraph({
          text: "3. შეავსეთ სავალდებულო ველები:",
          bullet: { level: 0 },
          spacing: { after: 100 }
        }),

        new Paragraph({
          text: "სახელი და გვარი - თანამშრომლის სრული სახელი",
          bullet: { level: 1 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ელ-ფოსტა - უნიკალური ელ-ფოსტის მისამართი (ავტორიზაციისთვის)",
          bullet: { level: 1 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "პირადი ნომერი - 11-ნიშნა პირადი ნომერი",
          bullet: { level: 1 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "პოზიცია - არჩევა პოზიციების ჩამონათვალიდან",
          bullet: { level: 1 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "დეპარტამენტი - თანამშრომლის დეპარტამენტი",
          bullet: { level: 1 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ტელეფონი - საკონტაქტო ნომერი",
          bullet: { level: 1 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "დაქირავების თარიღი - სამსახურის დაწყების თარიღი",
          bullet: { level: 1 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "სამუშაო გრაფიკი - აირჩიეთ: სრული 1, სრული 2, საათობრივი, ან ცვლები",
          bullet: { level: 1 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "პაროლი - დააყენეთ საწყისი პაროლი თანამშრომლისთვის",
          bullet: { level: 1 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "მომხმარებლის როლი - employee, hr_manager, ან admin",
          bullet: { level: 1 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "4. დააჭირეთ 'შენახვა'",
          bullet: { level: 0 },
          spacing: { after: 100 }
        }),

        new Paragraph({
          text: "📌 შენიშვნა: სისტემა ავტომატურად:",
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "ქმნის ავტორიზაციის ანგარიშს",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "უგზავნის SMS შეტყობინებას თანამშრომლის ტელეფონზე პაროლით და ლინკით",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ანიჭებს სამუშაო გრაფიკს თუ არის 'სრული 1' ან 'სრული 2'",
          bullet: { level: 0 },
          spacing: { after: 400 }
        }),

        // Section 2: Work Schedule Assignment
        new Paragraph({
          text: "2. სამუშაო გრაფიკის მინიჭება",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),

        new Paragraph({
          text: "სამუშაო გრაფიკი განსაზღვრავს თანამშრომლის სამუშაო საათებს და წესებს.",
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "გრაფიკის ტიპები:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "სრული გრაფიკი 1 - სტანდარტული 8 საათიანი სამუშაო დღე (09:00-18:00)",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "სრული გრაფიკი 2 - ალტერნატიული 8 საათიანი დღე (10:00-19:00)",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "საათობრივი - მოქნილი გრაფიკი, დროის აღრიცხვა საათობრივად",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ცვლები - ცვლების მიხედვით მუშაობა (დღის, საღამოს, ღამის ცვლები)",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "ცვლების გრაფიკის შექმნა:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "1. გადადით Shift Schedules (ცვლების გრაფიკები) გვერდზე",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "2. დააჭირეთ 'ახალი ცვლა'",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "3. აირჩიეთ თანამშრომელი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "4. მიუთითეთ თარიღი, დაწყების და დასრულების დრო",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "5. აირჩიეთ ცვლის ტიპი (დღის, საღამოს, ღამის)",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "6. შეინახეთ",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "📌 რეკომენდაცია: გამოიყენეთ 'ცვლის ტემპლეიტები' ხშირად გამეორებული გრაფიკებისთვის",
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 200, after: 400 }
        }),

        // Section 3: Attendance Tracking
        new Paragraph({
          text: "3. დასწრების აღრიცხვა",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),

        new Paragraph({
          text: "დასწრების სისტემა აღრიცხავს თანამშრომლების შესვლა-გასვლის დროს და ავტომატურად ითვლის სამუშაო საათებს.",
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "დასწრების მეთოდები:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "ხელით შეყვანა - ადმინისტრატორი ან HR მენეჯერი ამატებს ჩანაწერს",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "მობილური აპლიკაცია - თანამშრომელი თავად აფიქსირებს დროს",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "დასწრების მოწყობილობა - ბარათით ან ბიომეტრიით",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "ხელით დასწრების დამატება:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "1. გადადით Attendance (დასწრება) გვერდზე",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "2. დააჭირეთ 'დასწრების დამატება'",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "3. აირჩიეთ თანამშრომელი და თარიღი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "4. შეიყვანეთ შესვლის დრო (მაგ: 09:15)",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "5. შეიყვანეთ გასვლის დრო (მაგ: 18:30)",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "6. მიუთითეთ შესვენების ხანგრძლივობა (წუთებში)",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "7. შეინახეთ",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "⚠️ მნიშვნელოვანი: სისტემა ავტომატურად ითვლის:",
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "მუშაობის საათებს",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "დაგვიანებას (თუ გრაფიკის დაწყების დროზე გვიან მოვიდა)",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ზეგანაკვეთურ საათებს (თუ გრაფიკზე მეტი იმუშავა)",
          bullet: { level: 0 },
          spacing: { after: 400 }
        }),

        // Section 4: Leave Management
        new Paragraph({
          text: "4. შვებულებების მართვა",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),

        new Paragraph({
          text: "შვებულებების სისტემა მართავს თანამშრომლების ყოველწლიურ, სამედიცინო და სხვა ტიპის შვებულებებს.",
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "შვებულების ტიპები:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "ყოველწლიური (annual) - 24 სამუშაო დღე წელიწადში",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "სამედიცინო (sick) - ავადმყოფობის შემთხვევაში",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "პირადი (personal) - პირადი საჭიროებისთვის",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ანაზღაურების გარეშე (unpaid) - უხელფასო შვებულება",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "შვებულების მოთხოვნის პროცესი:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "1. თანამშრომელი შედის Employee Portal-ზე",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "2. დააჭირებს 'შვებულების მოთხოვნა'",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "3. ავსებს ფორმას: ტიპი, თარიღები, მიზეზი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "4. აგზავნის მოთხოვნას",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "5. HR მენეჯერი ხედავს შეტყობინებას",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "6. HR ამოწმებს შვებულების ბალანსს",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "7. ამტკიცებს ან უარყოფს მოთხოვნას",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "8. თანამშრომელი იღებს შეტყობინებას გადაწყვეტილების შესახებ",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "📊 ანალიტიკა: Leave Statistics გვერდზე შეგიძლიათ ნახოთ:",
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "შვებულებაზე მყოფი თანამშრომლების რაოდენობა დეპარტამენტების მიხედვით",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "გამოყენებული და დარჩენილი შვებულების დღეები",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "შვებულებების ტენდენციები თვეების მიხედვით",
          bullet: { level: 0 },
          spacing: { after: 400 }
        }),

        // Section 5: Overtime
        new Paragraph({
          text: "5. ზეგანაკვეთური სამუშაო",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),

        new Paragraph({
          text: "ზეგანაკვეთური სამუშაო არის დრო რომელიც თანამშრომელმა იმუშავა თავისი გრაფიკის ფარგლებს გარეთ.",
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "ზეგანაკვეთურის ტიპები:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "სამუშაო დღე (weekday) - ჩვეულებრივ სამუშაო დღეს დამატებით გაწეული საათები",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "დასვენების დღე (weekend) - შაბათ-კვირას მუშაობა",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "სადღესასწაულო (holiday) - ოფიციალურ დღესასწაულზე მუშაობა",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ღამის ცვლა (night_shift) - 22:00-დან 06:00-მდე მუშაობა",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "ზეგანაკვეთურის მოთხოვნის პროცესი:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "1. გადადით Overtime Requests გვერდზე",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "2. დააჭირეთ 'ახალი მოთხოვნა'",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "3. აირჩიეთ თანამშრომელი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "4. მიუთითეთ სამუშაო თარიღი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "5. შეიყვანეთ დაწყებისა და დასრულების დრო",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "6. მიუთითეთ ზეგანაკვეთურის ტიპი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "7. დაწერეთ მიზეზი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "8. გაგზავნეთ დასამტკიცებლად",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "💰 ანაზღაურება: ზეგანაკვეთური ავტომატურად ითვლება ხელფასის დარიცხვისას საათობრივი განაკვეთით",
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 200, after: 400 }
        }),

        // Section 6: Payroll Processing
        new Paragraph({
          text: "6. ხელფასის დარიცხვა",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),

        new Paragraph({
          text: "ხელფასის დარიცხვა არის ყველაზე მნიშვნელოვანი პროცესი, რომელიც აერთიანებს ყველა ფინანსურ მონაცემს.",
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "ხელფასის კომპონენტები:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "ძირითადი ხელფასი (Base Salary) - ხელშეკრულებით განსაზღვრული თანხა",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ბონუსები (Bonuses) - payroll ცხრილში ან compensation ცხრილში",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ზეგანაკვეთური - დამტკიცებული overtime requests-დან",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "დასვენების დღეებზე მუშაობა - 200% განაკვეთით",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "დღესასწაულებზე მუშაობა - 200% განაკვეთით",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "დაქვითვები (Deductions) - პენსია, გადასახადები, სესხები",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "წმინდა ხელფასი (Net Salary) - საბოლოო გადასახდელი თანხა",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "ხელფასის დარიცხვის პროცესი:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "1. გადადით Payroll გვერდზე",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "2. აირჩიეთ თვე და წელი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "3. დააჭირეთ 'თვიური ხელფასის დამუშავება' (ავტომატური)",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "   ან შექმენით ხელით თითოეული თანამშრომლისთვის",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "4. სისტემა ავტომატურად:",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),

        new Paragraph({
          text: "იღებს ძირითად ხელფასს თანამშრომლის პროფილიდან",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "ამატებს დამტკიცებულ ბონუსებს",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "ითვლის ზეგანაკვეთურ საათებს და ანაზღაურებას",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "ითვლის დღესასწაულებზე მუშაობის ანაზღაურებას",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "აკლებს პენსიის 2% (თანამშრომლის წილი)",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "აკლებს საშემოსავლო გადასახადს",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "ითვლის წმინდა ხელფასს",
          bullet: { level: 1 },
          spacing: { after: 100 }
        }),

        new Paragraph({
          text: "5. გადაამოწმეთ გაანგარიშებები",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "6. დაამტკიცეთ ხელფასები",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "7. მონიშნეთ როგორც 'გადახდილი'",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "📋 მაგალითი:",
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "თანამშრომელი: კუკური",
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ძირითადი ხელფასი: 3,000₾",
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ბონუსი (payroll): 600₾",
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "კომპენსაცია: 500₾",
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ზეგანაკვეთური 5 საათი: 85₾",
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ჯამი (Gross): 4,185₾",
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "დაქვითვები (პენსია 2%): 60₾",
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "სხვა დაქვითვები: 240₾",
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "წმინდა ხელფასი (Net): 3,885₾",
          spacing: { after: 400 }
        }),

        // Section 7: Pension Payments
        new Paragraph({
          text: "7. პენსიის გადახდები",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),

        new Paragraph({
          text: "პენსიის სისტემა ავტომატურად ითვლის თანამშრომლის და დამსაქმებლის წილებს.",
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "პენსიის წილები:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "თანამშრომლის წილი - 2% ძირითადი ხელფასიდან",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "დამსაქმებლის წილი - 4% ძირითადი ხელფასიდან",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "სულ პენსიაში - 6% ძირითადი ხელფასიდან",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "პენსიის გადახდების პროცესი:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "1. გადადით Pension Payments გვერდზე",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "2. პენსიის ჩანაწერები ავტომატურად იქმნება ხელფასის დარიცხვისას",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "3. გადაამოწმეთ თანხები",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "4. მონიშნეთ როგორც 'გადახდილი' როცა რეალურად გადაიხდება",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "5. მიუთითეთ გადახდის თარიღი და საფინანსო კოდი",
          bullet: { level: 0 },
          spacing: { after: 400 }
        }),

        // Section 8: Financial Reports
        new Paragraph({
          text: "8. ფინანსური რეპორტები",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),

        new Paragraph({
          text: "ფინანსური რეპორტები აერთიანებს ყველა ფინანსურ მონაცემს ერთ ადგილზე.",
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "რეპორტის გვერდზე:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "1. გადადით Financial Reports გვერდზე",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "2. აირჩიეთ თვე და წელი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "3. ნახეთ შემაჯამებელი სტატისტიკა:",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),

        new Paragraph({
          text: "სულ ხელფასები",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "სულ ბონუსები და კომპენსაციები",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "სულ ზეგანაკვეთური",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "სულ პენსია",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "სულ ბიუჯეტის ხარჯები",
          bullet: { level: 1 },
          spacing: { after: 100 }
        }),

        new Paragraph({
          text: "4. გადართეთ ტაბებს შორის დეტალური ინფორმაციისთვის:",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),

        new Paragraph({
          text: "ხელფასები - ყველა თანამშრომლის ხელფასის დეტალები",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "ზეგანაკვეთური - დამტკიცებული ზეგანაკვეთური მოთხოვნები",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "პენსია - პენსიის გადახდები",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "დასწრება - დასწრების ჩანაწერები",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "ბიუჯეტი - ბიუჯეტის ხარჯები",
          bullet: { level: 1 },
          spacing: { after: 100 }
        }),

        new Paragraph({
          text: "5. ექსპორტი Excel-ში:",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),

        new Paragraph({
          text: "თითოეული ტაბის ექსპორტი ცალ-ცალკე",
          bullet: { level: 1 },
          spacing: { after: 30 }
        }),
        new Paragraph({
          text: "კონსოლიდირებული რეპორტი - ყველა მონაცემი ერთ Excel ფაილში",
          bullet: { level: 1 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "📊 კონსოლიდირებული რეპორტი შეიცავს:",
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "შეჯამება - ფინანსური მაჩვენებლების მიმოხილვა",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ხელფასები - დეტალური ხელფასის ცხრილი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ზეგანაკვეთური - ზეგანაკვეთურის ცხრილი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "პენსია - პენსიის გადახდების ცხრილი",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "შვებულებები - დამტკიცებული შვებულებები",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "კომპენსაციები - ბონუსები და კომპენსაციები",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ბიუჯეტი - ბიუჯეტის ხარჯები",
          bullet: { level: 0 },
          spacing: { after: 400 }
        }),

        // Section 9: Compensation & Benefits
        new Paragraph({
          text: "9. კომპენსაციები და ბონუსები",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({
          text: "სისტემა მხარს უჭერს სხვადასხვა ტიპის კომპენსაციებს: წარმადობის ბონუსი, ერთჯერადი კომპენსაცია, სპეციალური დანამატი, პრემია.",
          spacing: { after: 200 }
        }),
        new Paragraph({
          text: "კომპენსაციის დამატება:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),
        new Paragraph({ text: "1. გადადით 'კომპენსაციები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "2. დააჭირეთ 'ახალი კომპენსაცია'", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "3. აირჩიეთ თანამშრომელი და კომპენსაციის ტიპი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "4. მიუთითეთ თანხა, მიზეზი და გადახდის თარიღი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "5. შეინახეთ - კომპენსაცია ავტომატურად ჩაითვლება ხელფასში", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Section 10: Budget Planning
        new Paragraph({
          text: "10. ბიუჯეტის დაგეგმვა",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({
          text: "ბიუჯეტის დაგეგმვა საშუალებას გაძლევთ მართოთ კომპანიის ხარჯები კატეგორიებით.",
          spacing: { after: 200 }
        }),
        new Paragraph({ text: "1. გადადით 'ბიუჯეტის დაგეგმვა' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "2. შექმენით ახალი ბიუჯეტი პერიოდის მითითებით (თვე/კვარტალი/წელი)", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "3. დაამატეთ კატეგორიები: ხელფასები, ოფისი, მარკეტინგი, IT, ტრენინგი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "4. ხარჯების ტაბში დაამატეთ რეალური ხარჯები", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "5. სისტემა ავტომატურად ითვლის ბიუჯეტის გადახარჯვას/ეკონომიას", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Section 11: Documents
        new Paragraph({
          text: "11. დოკუმენტების მართვა და ელექტრონული ხელმოწერა",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({
          text: "დოკუმენტების მოდული საშუალებას იძლევა შექმნათ, გაგზავნოთ და ხელი მოაწეროთ დოკუმენტებს.",
          spacing: { after: 200 }
        }),
        new Paragraph({
          text: "დოკუმენტის შექმნა და გაგზავნა:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),
        new Paragraph({ text: "1. გადადით 'დოკუმენტები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "2. დააჭირეთ 'ახალი დოკუმენტი' და ატვირთეთ ფაილი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "3. აირჩიეთ მიმღები თანამშრომლები", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "4. გაგზავნეთ - თანამშრომლებს ეგზავნებათ SMS შეტყობინება", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "5. თანამშრომელი ხელს აწერს პორტალიდან ან Signify.ge-ით", bullet: { level: 0 }, spacing: { after: 200 } }),
        new Paragraph({
          text: "Signify.ge ინტეგრაცია:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),
        new Paragraph({ text: "სისტემა ინტეგრირებულია Signify.ge-სთან OAuth 2.0 (PKCE) პროტოკოლით", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "ელექტრონული ხელმოწერა იურიდიულად ვალიდურია საქართველოს კანონმდებლობით", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "კონფიგურაცია: სისტემა → პარამეტრები → Signify ინტეგრაცია", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Section 12: Organization
        new Paragraph({
          text: "12. ორგანიზაციული სტრუქტურა",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({ text: "1. გადადით 'ორგანიზაციული სტრუქტურა' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "2. დაამატეთ დეპარტამენტები იერარქიული სტრუქტურით", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "3. თითოეულ დეპარტამენტს მიუთითეთ მენეჯერი და ბიუჯეტი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "4. დაამატეთ პოზიციები ხელფასის დიაპაზონით", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "5. ორგანიზაციული ჩარტი ავტომატურად გენერირდება", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "6. დეპარტამენტის ანალიტიკა: თანამშრომლების რაოდენობა, ტრენდები, ხარჯები", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Section 13: Recruitment
        new Paragraph({
          text: "13. რეკრუტინგი",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({ text: "1. შექმენით ვაკანსია 'ვაკანსიები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "2. გამოაქვეყნეთ Job Board-ებზე ან გააზიარეთ ბმული", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "3. კანდიდატების ბაზაში დაამატეთ აპლიკანტები (ხელით ან Excel იმპორტით)", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "4. AI CV ანალიზი ავტომატურად შეაფასებს შესაბამისობას", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "5. მართეთ შერჩევის ეტაპები: ახალი → განხილვაში → გასაუბრება → მიღებული/უარყოფილი", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Section 14: Tasks
        new Paragraph({
          text: "14. ამოცანების მართვა",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({
          text: "Kanban სტილის დაფა პროექტების და ამოცანების მართვისთვის.",
          spacing: { after: 200 }
        }),
        new Paragraph({ text: "1. შექმენით პროექტი 'ამოცანები' გვერდზე", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "2. დაამატეთ ამოცანები სათაურით, აღწერით, პასუხისმგებელი პირით და ვადით", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "3. გადაიტანეთ ამოცანები სტატუსებს შორის: ახალი → მიმდინარე → დასრულებული", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "4. დაამატეთ კომენტარები და ატვირთეთ ფაილები", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "5. მენეჯერები მიიღებენ შეტყობინებებს ვადაგადაცილებულ ამოცანებზე", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Section 15: Communication
        new Paragraph({
          text: "15. კომუნიკაცია",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({
          text: "ჩატი და შეტყობინებები:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),
        new Paragraph({ text: "პირადი და ჯგუფური ჩატი ფაილების გაგზავნით", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "ვიდეო ზარები ჩაწერის ფუნქციით", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "კომპანიის განცხადებები პრიორიტეტული შეტყობინებებით", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "რეალურ დროში push-შეტყობინებები", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "SMS გაგზავნა CloudSMS/Twilio ინტეგრაციით", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "ავტომატური Email შეტყობინებები (Resend)", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Section 16: Security
        new Paragraph({
          text: "16. უსაფრთხოება და როლები",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({
          text: "მომხმარებლის როლები:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),
        new Paragraph({ text: "ადმინისტრატორი - სრული წვდომა, სისტემის კონფიგურაცია, Custom როლების შექმნა", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "HR მენეჯერი - თანამშრომლების მართვა, ხელფასები, დოკუმენტები, ანგარიშები", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "დეპარტამენტის მენეჯერი - საკუთარი გუნდის მართვა, შვებულებების დამტკიცება", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "თანამშრომელი - პირადი პროფილი, მოთხოვნები, დოკუმენტების ხელმოწერა", bullet: { level: 0 }, spacing: { after: 200 } }),
        new Paragraph({
          text: "უსაფრთხოების ფუნქციები:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),
        new Paragraph({ text: "AES-256-GCM ენკრიფცია მგრძნობიარე მონაცემებისთვის", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "RLS პოლიტიკები - მწკრივის დონის უსაფრთხოება", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "აუდიტის ჟურნალი - ყველა მოქმედების ლოგირება", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "IP/გეოლოკაციის ტრეკინგი შესვლის ისტორიაში", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "ავტომატური სესიის ტაიმაუტი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "Intrusion Detection - არაავტორიზებული წვდომის აღმოჩენა", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "GDPR/ISO 27001 შესაბამისობა", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Section 17: AI Features
        new Paragraph({
          text: "17. AI ფუნქციები",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({
          text: "სისტემაში ინტეგრირებულია ხელოვნური ინტელექტის მოწინავე შესაძლებლობები:",
          spacing: { after: 200 }
        }),
        new Paragraph({ text: "ნინა - AI ასისტენტი: ბუნებრივ ენაზე კითხვა-პასუხი სისტემის შესახებ", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "AI CV ანალიზი: რეზიუმეს ავტომატური შეფასება ვაკანსიასთან შესაბამისობით", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "AI შეფასებების ანალიზი: თანამშრომლის შეფასებების ტრენდები და რეკომენდაციები", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "AI რისკის პროგნოზი: თანამშრომლის წასვლის ალბათობის პროგნოზირება", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "AI ბიუჯეტის პროგნოზი: ფინანსური ტრენდების ანალიზი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "AI შესაბამისობის შემოწმება: კანონმდებლობასთან ავტომატური ვერიფიკაცია", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "ჭკვიანი შეტყობინებები: AI-ზე დაფუძნებული პრიორიტიზაცია", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Section 18: Integrations
        new Paragraph({
          text: "18. ინტეგრაციები",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({ text: "Signify.ge - ელექტრონული ხელმოწერა OAuth 2.0 (PKCE) პროტოკოლით", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "GlobalCell - eSIM მართვა მივლინებებისთვის", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "CloudSMS - SMS შეტყობინებების გაგზავნა", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "Twilio - ალტერნატიული SMS პროვაიდერი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "Resend - ელფოსტის შეტყობინებები", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "ტურნიკეტი (Turnstile) - ფიზიკური დასწრების მოწყობილობები", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "PWA მობილური - პროგრესული ვებ აპლიკაცია ყველა პლატფორმაზე", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Section 19: Compliance
        new Paragraph({
          text: "19. შესაბამისობა საქართველოს კანონმდებლობასთან",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({
          text: "სისტემა სრულად შეესაბამება საქართველოს შრომის კოდექსს:",
          spacing: { after: 200 }
        }),
        new Paragraph({ text: "40/48 საათიანი სამუშაო კვირის ლიმიტების მონიტორინგი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "11 საათიანი დასვენება ცვლებს შორის (მუხლი 24)", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "24 საათიანი ყოველკვირეული დასვენება", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "ღამის სამუშაო (22:00-06:00) ტრეკინგი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "24 დღიანი ყოველწლიური შვებულება", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "დედობის/მამობის შვებულება (730 დღე, 183 ანაზღაურებადი)", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "არასრულწლოვანთა შეზღუდვები (36 საათი/კვირა)", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "საპენსიო შენატანები (2%/2%/2% სქემა)", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "შრომის ინსპექციის რეპორტის ავტომატური გენერირება", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Section 20: System Admin
        new Paragraph({
          text: "20. სისტემის ადმინისტრირება",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),
        new Paragraph({ text: "კომპანიის პარამეტრები - ლოგო, სახელი, საკონტაქტო ინფორმაცია", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "როლების მართვა - Custom როლების შექმნა, უფლებების მინიჭება", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "ლიცენზიების მართვა - Professional/Enterprise პაკეტები", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "სერვერის პანელი - CPU, RAM, DB მონიტორინგი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "Health Check - 10+ მეტრიკის ავტომატური მონიტორინგი და Auto-Fix", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "მონაცემთა ბაზის სარეზერვო კოპირება - ავტომატური და ხელით ბექაპი", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "ტესტ მონაცემების გენერატორი - დემო რეჟიმისთვის", bullet: { level: 0 }, spacing: { after: 50 } }),
        new Paragraph({ text: "სისტემის განახლებების ისტორია (Changelog)", bullet: { level: 0 }, spacing: { after: 400 } }),

        // Best Practices
        new Paragraph({
          text: "საუკეთესო პრაქტიკა და რჩევები",
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 }
        }),

        new Paragraph({
          text: "✅ რეგულარული მონიტორინგი:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "ყოველდღე შეამოწმეთ დასწრების ჩანაწერები",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ყოველკვირეულად განიხილეთ შვებულებისა და ზეგანაკვეთურის მოთხოვნები",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "თვის ბოლოს დაამუშავეთ ხელფასები",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "კვარტალში ერთხელ გადაამოწმეთ პენსიის გადახდები",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "⚠️ რისი თავიდან აცილება:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "არ დაგვიანდეთ ხელფასების დამუშავებაში",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ყოველთვის გადაამოწმეთ გაანგარიშებები დამტკიცებამდე",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "არ დაივიწყოთ დღესასწაულებზე მუშაობის დაფიქსირება",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "აწარმოოთ რეგულარული ბექაპები",
          bullet: { level: 0 },
          spacing: { after: 200 }
        }),

        new Paragraph({
          text: "🎯 პროდუქტიულობის რჩევები:",
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 100 }
        }),

        new Paragraph({
          text: "გამოიყენეთ შაბლონები ხშირად გამეორებადი გრაფიკებისთვის",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "დააყენეთ ავტომატური შეტყობინებები მნიშვნელოვანი მოვლენებისთვის",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "გამოიყენეთ ფილტრები დიდი მონაცემების დასამუშავებლად",
          bullet: { level: 0 },
          spacing: { after: 50 }
        }),
        new Paragraph({
          text: "ექსპორტირეთ რეპორტები არქივაციისთვის",
          bullet: { level: 0 },
          spacing: { after: 400 }
        }),

        // Footer
        new Paragraph({
          text: "დამატებითი დახმარებისთვის დაუკავშირდით ადმინისტრატორს",
          alignment: AlignmentType.CENTER,
          spacing: { before: 600, after: 200 }
        }),

        new Paragraph({
          text: `დოკუმენტის შექმნის თარიღი: ${new Date().toLocaleDateString('ka-GE')}`,
          alignment: AlignmentType.CENTER
        })
      ]
    }]
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `ინსტრუქცია_${new Date().toISOString().split('T')[0]}.docx`);
};
