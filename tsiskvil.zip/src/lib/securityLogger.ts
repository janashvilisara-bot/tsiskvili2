import { supabase } from '@/integrations/supabase/client';

export type SecurityEventType = 
  | 'login_success'
  | 'login_failed'
  | 'login_blocked'
  | 'logout'
  | 'password_change'
  | 'password_reset_request'
  | 'session_timeout'
  | 'unauthorized_access'
  | 'role_change'
  | 'sensitive_data_access'
  | 'export_data'
  | 'bulk_operation'
  | 'api_rate_limit'
  | 'suspicious_activity';

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';

interface SecurityLogPayload {
  eventType: SecurityEventType;
  resourceType: string;
  resourceId?: string;
  details?: Record<string, unknown>;
  riskLevel?: RiskLevel;
  userId?: string;
}

/**
 * Log a security event to the audit_logs table
 */
export async function logSecurityEvent(payload: SecurityLogPayload): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    const logEntry = {
      action_type: payload.eventType,
      resource_type: payload.resourceType,
      resource_id: payload.resourceId || null,
      user_id: payload.userId || user?.id || null,
      details: {
        ...payload.details,
        timestamp: new Date().toISOString(),
        user_agent: typeof navigator !== 'undefined' ? navigator.userAgent : null,
      },
      risk_level: payload.riskLevel || determineRiskLevel(payload.eventType),
      status: 'completed',
      ip_address: null, // Will be populated by server if needed
      session_id: null,
    };

    const { error } = await supabase
      .from('audit_logs')
      .insert(logEntry);

    if (error) {
      console.error('Failed to log security event:', error);
    }
  } catch (error) {
    console.error('Error logging security event:', error);
  }
}

/**
 * Determine risk level based on event type
 */
function determineRiskLevel(eventType: SecurityEventType): RiskLevel {
  const riskMap: Record<SecurityEventType, RiskLevel> = {
    login_success: 'low',
    login_failed: 'medium',
    login_blocked: 'high',
    logout: 'low',
    password_change: 'medium',
    password_reset_request: 'medium',
    session_timeout: 'low',
    unauthorized_access: 'high',
    role_change: 'high',
    sensitive_data_access: 'medium',
    export_data: 'medium',
    bulk_operation: 'medium',
    api_rate_limit: 'high',
    suspicious_activity: 'critical',
  };

  return riskMap[eventType] || 'low';
}

/**
 * Log login attempt
 */
export async function logLoginAttempt(email: string, success: boolean, reason?: string): Promise<void> {
  await logSecurityEvent({
    eventType: success ? 'login_success' : 'login_failed',
    resourceType: 'authentication',
    details: {
      email,
      success,
      reason: reason || null,
    },
    riskLevel: success ? 'low' : 'medium',
  });
}

/**
 * Log password change
 */
export async function logPasswordChange(userId: string): Promise<void> {
  await logSecurityEvent({
    eventType: 'password_change',
    resourceType: 'user_security',
    resourceId: userId,
    userId,
    riskLevel: 'medium',
  });
}

/**
 * Log data export
 */
export async function logDataExport(resourceType: string, recordCount: number): Promise<void> {
  await logSecurityEvent({
    eventType: 'export_data',
    resourceType,
    details: {
      record_count: recordCount,
      export_format: 'excel',
    },
    riskLevel: recordCount > 100 ? 'medium' : 'low',
  });
}

/**
 * Log sensitive data access
 */
export async function logSensitiveDataAccess(resourceType: string, resourceId: string): Promise<void> {
  await logSecurityEvent({
    eventType: 'sensitive_data_access',
    resourceType,
    resourceId,
    riskLevel: 'medium',
  });
}

/**
 * Log role change
 */
export async function logRoleChange(
  targetUserId: string,
  oldRole: string,
  newRole: string
): Promise<void> {
  await logSecurityEvent({
    eventType: 'role_change',
    resourceType: 'user_roles',
    resourceId: targetUserId,
    details: {
      old_role: oldRole,
      new_role: newRole,
    },
    riskLevel: 'high',
  });
}

/**
 * Log unauthorized access attempt
 */
export async function logUnauthorizedAccess(resourceType: string, resourceId?: string): Promise<void> {
  await logSecurityEvent({
    eventType: 'unauthorized_access',
    resourceType,
    resourceId,
    riskLevel: 'high',
  });
}
