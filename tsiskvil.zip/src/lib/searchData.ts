import {
  Users,
  CalendarCheck,
  Calendar,
  Plane,
  Clock,
  FileText,
  Cog,
  CalendarDays,
  PartyPopper,
  Smartphone,
  Activity,
  DollarSign,
  Wallet,
  Briefcase,
  Shield,
  Coins,
  UserPlus,
  GraduationCap,
  CreditCard,
  Star,
  BarChart3,
  Lightbulb,
  Award,
  Building2,
  Network,
  ClipboardList,
  Phone,
  FileCheck,
  AlertTriangle,
  Car,
  Settings,
  HelpCircle,
  UserCog,
  MessageSquare,
  Megaphone,
  Lock,
  Database,
  LogOut,
  TrendingUp,
  User,
  Bell,
  LayoutDashboard,
  LucideIcon,
} from "lucide-react";

export interface SearchItem {
  name: string;
  description: string;
  url: string;
  icon: LucideIcon;
  category: string;
  keywords?: string[];
}

export const allSearchItems: SearchItem[] = [
  // მთავარი
  { name: "თანამშრომლის პორტალი", description: "პერსონალური პორტალი", url: "/", icon: User, category: "მთავარი", keywords: ["portal", "პორტალი"] },
  { name: "ყველა ფუნქცია", description: "სისტემის მთავარი დაფა", url: "/dashboard", icon: LayoutDashboard, category: "მთავარი", keywords: ["dashboard", "მთავარი"] },
  { name: "შეტყობინებები", description: "შეტყობინებების სია", url: "/notifications", icon: Bell, category: "მთავარი", keywords: ["notifications", "შეტყობინებები"] },
  
  // პერსონალი - ძირითადი ფუნქციები
  { name: "თანამშრომლები", description: "თანამშრომლების მონაცემების მართვა", url: "/employees", icon: Users, category: "პერსონალი", keywords: ["employees", "თანამშრომლები", "კადრები"] },
  { name: "დასწრება", description: "დასწრების აღრიცხვა და მონიტორინგი", url: "/attendance", icon: CalendarCheck, category: "პერსონალი", keywords: ["attendance", "დასწრება"] },
  { name: "შვებულებები", description: "შვებულებების მოთხოვნები და მართვა", url: "/leave-requests", icon: Calendar, category: "პერსონალი", keywords: ["leave", "შვებულება", "vacation"] },
  { name: "მივლინებები", description: "სამსახურეობრივი მივლინებების მართვა", url: "/business-trip-requests", icon: Plane, category: "პერსონალი", keywords: ["business trip", "მივლინება"] },
  { name: "ზეგანაკვეთური", description: "ზეგანაკვეთური სამუშაოს მოთხოვნები", url: "/overtime-requests", icon: Clock, category: "პერსონალი", keywords: ["overtime", "ზეგანაკვეთური"] },
  { name: "დოკუმენტები", description: "დოკუმენტების მართვა და ხელმოწერა", url: "/documents", icon: FileText, category: "პერსონალი", keywords: ["documents", "დოკუმენტები"] },
  
  // პერსონალი - გრაფიკები
  { name: "სამუშაო გრაფიკები", description: "თანამშრომლების სამუშაო გრაფიკების მართვა", url: "/work-schedules", icon: Calendar, category: "პერსონალი", keywords: ["schedule", "გრაფიკი"] },
  { name: "გრაფიკების შაბლონები", description: "გრაფიკების შაბლონების შექმნა და რედაქტირება", url: "/schedule-templates", icon: Cog, category: "პერსონალი", keywords: ["template", "შაბლონი"] },
  { name: "ცვლების გრაფიკი", description: "ცვლების დაგეგმვა და მართვა", url: "/shift-schedules", icon: CalendarDays, category: "პერსონალი", keywords: ["shift", "ცვლა"] },
  { name: "დასვენების დღეები", description: "საჯარო დასვენების დღეების კალენდარი", url: "/public-holidays", icon: PartyPopper, category: "პერსონალი", keywords: ["holiday", "დასვენება"] },
  
  // პერსონალი - აღრიცხვა
  { name: "სამუშაო დროის აღრიცხვა", description: "სამუშაო დროის დეტალური აღრიცხვა", url: "/work-time-tracking", icon: Clock, category: "პერსონალი", keywords: ["time tracking", "აღრიცხვა"] },
  { name: "მობილური აღრიცხვა", description: "მობილურიდან დასწრების აღრიცხვა", url: "/mobile-attendance", icon: Smartphone, category: "პერსონალი", keywords: ["mobile", "მობილური"] },
  { name: "დასწრების ანალიტიკა", description: "დასწრების ანალიზი და სტატისტიკა", url: "/attendance-analytics", icon: Activity, category: "პერსონალი", keywords: ["analytics", "ანალიტიკა"] },
  
  // ფინანსები
  { name: "ხელფასები", description: "ხელფასების დარიცხვა და მართვა", url: "/payroll", icon: DollarSign, category: "ფინანსები", keywords: ["payroll", "ხელფასი", "salary"] },
  { name: "ბიუჯეტი", description: "ბიუჯეტის დაგეგმვა და კონტროლი", url: "/budget-planning", icon: Wallet, category: "ფინანსები", keywords: ["budget", "ბიუჯეტი"] },
  { name: "აქტივები", description: "კომპანიის აქტივების აღრიცხვა", url: "/assets", icon: Briefcase, category: "ფინანსები", keywords: ["assets", "აქტივები"] },
  { name: "სარგებლები", description: "თანამშრომლების სარგებლების მართვა", url: "/benefits-admin", icon: Shield, category: "ფინანსები", keywords: ["benefits", "სარგებლები"] },
  { name: "კომპენსაცია", description: "ბონუსები და დამატებითი კომპენსაციები", url: "/compensation", icon: DollarSign, category: "ფინანსები", keywords: ["compensation", "კომპენსაცია", "ბონუსი"] },
  { name: "საპენსიო გადახდები", description: "საპენსიო ანგარიშსწორებების მართვა", url: "/pension-payments", icon: Coins, category: "ფინანსები", keywords: ["pension", "პენსია"] },
  { name: "სამუშაო დროის ფორმები", description: "სამუშაო დროის დოკუმენტაციის გენერაცია", url: "/work-time-form-generator", icon: FileText, category: "ფინანსები", keywords: ["form", "ფორმა"] },
  
  // ანგარიშები - პერსონალი
  { name: "ავტორიზაციების ანგარიში", description: "სისტემაში შესვლის ანგარიში და უსაფრთხოება", url: "/authorization-report", icon: Shield, category: "ანგარიშები", keywords: ["authorization", "ავტორიზაცია"] },
  { name: "ავტო გასვლების ანგარიში", description: "ავტომატური გასვლების ჩანაწერები", url: "/auto-logout-report", icon: LogOut, category: "ანგარიშები", keywords: ["logout", "გასვლა"] },
  
  // ანგარიშები - დოკუმენტაცია & დასვენება
  { name: "შვებულებების სტატისტიკა", description: "შვებულებების ბალანსი და ხარჯვა დეპარტამენტების მიხედვით", url: "/leave-statistics", icon: BarChart3, category: "ანგარიშები", keywords: ["leave statistics", "შვებულებების სტატისტიკა"] },
  { name: "დოკუმენტების ანგარიში", description: "დოკუმენტების სტატუსი და ხელმოწერები", url: "/document-reports", icon: FileText, category: "ანგარიშები", keywords: ["documents", "დოკუმენტები"] },
  { name: "SMS ანგარიში", description: "გაგზავნილი SMS შეტყობინებების ისტორია", url: "/sms-reports", icon: MessageSquare, category: "ანგარიშები", keywords: ["sms", "შეტყობინება"] },
  
  // ანგარიშები - ფინანსური
  { name: "ფინანსური ანგარიშები", description: "სრული ფინანსური ანგარიშების სისტემა", url: "/financial-reports", icon: BarChart3, category: "ანგარიშები", keywords: ["financial", "ფინანსური"] },
  { name: "სამუშაო დროის ანგარიში", description: "სრული სამუშაო დროის ანალიზი, რეგულარული და ღამის საათები", url: "/work-time-report", icon: Clock, category: "ანგარიშები", keywords: ["work time", "სამუშაო დრო"] },
  { name: "დაგეგმილი vs რეალური", description: "დაგეგმილი და რეალური დასწრების შედარება", url: "/ideal-attendance-report", icon: Calendar, category: "ანგარიშები", keywords: ["ideal", "დაგეგმილი"] },
  { name: "ზეგანაკვეთურის ანგარიში", description: "ზეგანაკვეთური საათების დეტალური ანგარიში და ხარჯები", url: "/overtime-reports", icon: TrendingUp, category: "ანგარიშები", keywords: ["overtime report", "ზეგანაკვეთურის ანგარიში"] },
  { name: "Chill Out ანგარიში", description: "დასვენების დროის მონიტორინგი", url: "/chill-out-report", icon: Award, category: "ანგარიშები", keywords: ["chill out", "დასვენება"] },
  
  // რეკრუტმენტი
  { name: "ვაკანსიები", description: "ვაკანსიების მართვა და პუბლიკაცია", url: "/vacancies", icon: Briefcase, category: "რეკრუტმენტი", keywords: ["vacancy", "ვაკანსია"] },
  { name: "კანდიდატები", description: "კანდიდატების მართვა და შეფასება", url: "/candidates", icon: UserPlus, category: "რეკრუტმენტი", keywords: ["candidate", "კანდიდატი"] },
  { name: "ონბორდინგი", description: "ახალი თანამშრომლების ადაპტაცია", url: "/onboarding", icon: GraduationCap, category: "რეკრუტმენტი", keywords: ["onboarding", "ონბორდინგი"] },
  { name: "ონბორდინგ შაბლონები", description: "ონბორდინგის პროცესის შაბლონები", url: "/onboarding-templates", icon: FileText, category: "რეკრუტმენტი", keywords: ["template", "შაბლონი"] },
  { name: "გარიგებები", description: "რეკრუტმენტის გარიგებების მართვა", url: "/deals", icon: DollarSign, category: "რეკრუტმენტი", keywords: ["deals", "გარიგება"] },
  
  // განვითარება
  { name: "ტრენინგები", description: "სასწავლო პროგრამები და ტრენინგების მართვა", url: "/training", icon: GraduationCap, category: "განვითარება", keywords: ["training", "ტრენინგი", "სწავლება"] },
  { name: "შეფასებები", description: "თანამშრომლების შეფასების სისტემა", url: "/employee-evaluations", icon: CreditCard, category: "განვითარება", keywords: ["evaluation", "შეფასება"] },
  { name: "აღიარება", description: "წახალისება და მიღწევების აღიარება", url: "/recognition", icon: Star, category: "განვითარება", keywords: ["recognition", "აღიარება"] },
  { name: "კვლევები", description: "პულსური გამოკითხვები და ანალიტიკა", url: "/pulse-surveys", icon: BarChart3, category: "განვითარება", keywords: ["survey", "კვლევა", "გამოკითხვა"] },
  { name: "OKR / KPI", description: "მიზნების დასახვა და შესრულების მონიტორინგი", url: "/okr", icon: Award, category: "განვითარება", keywords: ["okr", "kpi", "მიზანი"] },
  { name: "წუწუნის დაფა", description: "იდეები და უკუკავშირის მართვა", url: "/feedback", icon: Lightbulb, category: "განვითარება", keywords: ["feedback", "უკუკავშირი", "წუწუნი"] },
  
  // ორგანიზაცია
  { name: "ორგ. სტრუქტურა", description: "ორგანიზაციული სტრუქტურის ვიზუალიზაცია და მართვა", url: "/organizational-structure", icon: Network, category: "ორგანიზაცია", keywords: ["structure", "სტრუქტურა"] },
  { name: "დავალებები", description: "დავალებების შექმნა და მონიტორინგი", url: "/tasks", icon: ClipboardList, category: "ორგანიზაცია", keywords: ["task", "დავალება"] },
  { name: "კონტაქტები", description: "საკონტაქტო პირებისა და პარტნიორების მართვა", url: "/contacts", icon: Phone, category: "ორგანიზაცია", keywords: ["contact", "კონტაქტი"] },
  { name: "სამუშაო აღწერილობები", description: "პოზიციების აღწერილობები და მოვალეობები", url: "/job-descriptions", icon: FileCheck, category: "ორგანიზაცია", keywords: ["job description", "აღწერილობა"] },
  { name: "დისციპლინური საყვედურები", description: "დისციპლინური ქმედებების აღრიცხვა", url: "/disciplinary", icon: AlertTriangle, category: "ორგანიზაცია", keywords: ["disciplinary", "დისციპლინა", "საყვედური"] },
  { name: "სამსახურეობრივი გასვლები", description: "სამსახურეობრივი გასვლების მართვა", url: "/service-trips", icon: Briefcase, category: "ორგანიზაცია", keywords: ["service trip", "გასვლა"] },
  { name: "სატრანსპორტო მოთხოვნები", description: "ტრანსპორტის მოთხოვნები და ავტომობილების მართვა", url: "/vehicle-requests", icon: Car, category: "ორგანიზაცია", keywords: ["vehicle", "ტრანსპორტი", "მანქანა"] },
  
  // სისტემა - ძირითადი პარამეტრები
  { name: "პარამეტრები", description: "პერსონალური და სისტემის პარამეტრები", url: "/settings", icon: Settings, category: "სისტემა", keywords: ["settings", "პარამეტრები"] },
  { name: "კომპანია", description: "კომპანიის ინფორმაციის მართვა", url: "/company-settings", icon: Building2, category: "სისტემა", keywords: ["company", "კომპანია"] },
  { name: "როლები", description: "როლებისა და უფლებების მართვა", url: "/role-management", icon: Shield, category: "სისტემა", keywords: ["role", "როლი", "უფლება"] },
  { name: "Custom როლები", description: "მორგებული როლების შექმნა", url: "/custom-role-management", icon: Shield, category: "სისტემა", keywords: ["custom role", "მორგებული როლი"] },
  { name: "დახმარება", description: "სისტემის გამოყენების ინსტრუქციები", url: "/help", icon: HelpCircle, category: "სისტემა", keywords: ["help", "დახმარება"] },
  
  // სისტემა - ადმინისტრირება
  { name: "ადმინ პანელი", description: "ადმინისტრატორის კონტროლის პანელი", url: "/admin-panel", icon: UserCog, category: "სისტემა", keywords: ["admin", "ადმინი"] },
  { name: "ცვლილებების მონიტორინგი", description: "სისტემის ცვლილებების აუდიტი", url: "/audit-logs", icon: Activity, category: "სისტემა", keywords: ["audit", "აუდიტი", "ცვლილება"] },
  { name: "უსაფრთხოება", description: "უსაფრთხოების პარამეტრები და მონიტორინგი", url: "/security", icon: Shield, category: "სისტემა", keywords: ["security", "უსაფრთხოება"] },
  { name: "SMS პარამეტრები", description: "SMS შეტყობინებების კონფიგურაცია", url: "/sms-settings", icon: MessageSquare, category: "სისტემა", keywords: ["sms settings", "sms პარამეტრები"] },
  { name: "ინტეგრაციები", description: "Telegram, Slack, Teams, WhatsApp და კალენდრები", url: "/integrations", icon: MessageSquare, category: "სისტემა", keywords: ["integrations", "ინტეგრაცია", "telegram", "slack", "teams", "whatsapp", "calendar"] },
  { name: "ტესტ-მონაცემები", description: "სატესტო მონაცემების გენერატორი", url: "/test-data-generator", icon: Database, category: "სისტემა", keywords: ["test", "ტესტი", "გენერატორი"] },
  
  // სისტემა - დამატებითი სერვისები
  { name: "ვიდეო ტუტორიალები", description: "ვიდეო ინსტრუქციების მართვა", url: "/video-tutorial-management", icon: GraduationCap, category: "სისტემა", keywords: ["video", "ვიდეო", "ტუტორიალი"] },
  { name: "გამოცხადებები", description: "გამოცხადებების და ახალი ამბების მართვა", url: "/announcements", icon: Megaphone, category: "სისტემა", keywords: ["announcement", "გამოცხადება"] },
  { name: "ჩატი", description: "შიდა კომუნიკაციის სისტემა", url: "/chat", icon: MessageSquare, category: "სისტემა", keywords: ["chat", "ჩატი", "კომუნიკაცია"] },
  { name: "სიმულატორი", description: "სასწავლო სიმულატორი და ტესტირება", url: "/simulator", icon: GraduationCap, category: "სისტემა", keywords: ["simulator", "სიმულატორი"] },
  
  // კონტრაქტები
  { name: "კონტრაქტების შაბლონები", description: "შრომითი კონტრაქტების შაბლონები", url: "/contract-templates", icon: FileText, category: "სისტემა", keywords: ["contract", "კონტრაქტი", "შაბლონი"] },
];

export const searchItems = (query: string): SearchItem[] => {
  if (!query.trim()) return [];
  
  const lowerQuery = query.toLowerCase();
  
  return allSearchItems.filter(item => {
    const matchesName = item.name.toLowerCase().includes(lowerQuery);
    const matchesDescription = item.description.toLowerCase().includes(lowerQuery);
    const matchesCategory = item.category.toLowerCase().includes(lowerQuery);
    const matchesKeywords = item.keywords?.some(k => k.toLowerCase().includes(lowerQuery));
    
    return matchesName || matchesDescription || matchesCategory || matchesKeywords;
  });
};

export const getCategories = (): string[] => {
  return [...new Set(allSearchItems.map(item => item.category))];
};
