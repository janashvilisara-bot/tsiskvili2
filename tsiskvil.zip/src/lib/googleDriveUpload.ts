import { supabase } from "@/integrations/supabase/client";

const toBase64 = (blob: Blob) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });

/**
 * Uploads a generated document to the company Google Drive,
 * inside a folder named after the employee.
 */
export async function uploadToGoogleDrive(params: {
  employeeName: string;
  fileName: string;
  blob: Blob;
  subFolder?: string;
}): Promise<{ success: boolean; webViewLink?: string; error?: string }> {
  try {
    const contentBase64 = await toBase64(params.blob);
    const { data, error } = await supabase.functions.invoke("google-drive", {
      body: {
        action: "upload",
        employeeName: params.employeeName,
        fileName: params.fileName,
        mimeType: params.blob.type || "application/octet-stream",
        subFolder: params.subFolder,
        contentBase64,
      },
    });
    if (error) return { success: false, error: error.message };
    if (data?.error) return { success: false, error: data.error };
    return { success: true, webViewLink: data?.file?.webViewLink };
  } catch (e: any) {
    return { success: false, error: e?.message || "ატვირთვა ვერ მოხერხდა" };
  }
}
