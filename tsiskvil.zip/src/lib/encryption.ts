/**
 * Client-side encryption utilities for sensitive employee data
 * Uses Web Crypto API for AES-256-GCM encryption
 */

// Sensitive fields that should be encrypted
export const SENSITIVE_FIELDS = [
  'personal_id',
  'phone',
  'email', 
  'address',
  'salary',
  'bank_account',
  'bonus',
  'pension_amount'
] as const;

export type SensitiveField = typeof SENSITIVE_FIELDS[number];

export interface EncryptedData {
  ciphertext: string; // Base64 encoded
  iv: string; // Base64 encoded initialization vector
  version: number;
}

export interface DecryptedEmployeeData {
  personal_id?: string;
  phone?: string;
  email?: string;
  address?: string;
  salary?: number;
  bank_account?: string;
  bonus?: number;
  pension_amount?: number;
}

/**
 * Mask sensitive data for non-admin users
 */
export function maskSensitiveData(value: string | number | undefined, type: SensitiveField): string {
  if (value === undefined || value === null) return '***';
  
  const strValue = String(value);
  
  switch (type) {
    case 'personal_id':
      // Show first 3 and last 2 characters: 012***89
      if (strValue.length > 5) {
        return strValue.slice(0, 3) + '***' + strValue.slice(-2);
      }
      return '***';
      
    case 'phone':
      // Show first 3 and last 3: 599***123
      if (strValue.length > 6) {
        return strValue.slice(0, 3) + '***' + strValue.slice(-3);
      }
      return '***';
      
    case 'email':
      // Show first 2 chars and domain: te***@gmail.com
      const atIndex = strValue.indexOf('@');
      if (atIndex > 2) {
        return strValue.slice(0, 2) + '***' + strValue.slice(atIndex);
      }
      return '***@***.***';
      
    case 'address':
      // Show only city/first word
      const firstWord = strValue.split(/[,\s]/)[0];
      return firstWord + ', ***';
      
    case 'salary':
    case 'bonus':
    case 'pension_amount':
      // Show magnitude only: ****₾ (4-digit salary)
      const numValue = Number(value);
      if (numValue > 0) {
        const magnitude = Math.floor(Math.log10(numValue)) + 1;
        return '*'.repeat(magnitude) + ' ₾';
      }
      return '*** ₾';
      
    case 'bank_account':
      // Show last 4 digits: ************1234
      if (strValue.length > 4) {
        return '*'.repeat(strValue.length - 4) + strValue.slice(-4);
      }
      return '****';
      
    default:
      return '***';
  }
}

/**
 * Check if user has admin role to view decrypted data
 */
export function canViewDecryptedData(userRole: string | null): boolean {
  return userRole === 'admin';
}

/**
 * Format decrypted value for display
 */
export function formatDecryptedValue(value: string | number | undefined, type: SensitiveField): string {
  if (value === undefined || value === null) return '-';
  
  switch (type) {
    case 'salary':
    case 'bonus':
    case 'pension_amount':
      return `${Number(value).toLocaleString('ka-GE')} ₾`;
    case 'phone':
      return String(value).replace(/(\d{3})(\d{2})(\d{2})(\d{2})/, '$1 $2 $3 $4');
    default:
      return String(value);
  }
}
