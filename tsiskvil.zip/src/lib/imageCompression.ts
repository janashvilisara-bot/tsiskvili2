/**
 * Browser-side image compression to WebP.
 * Used for avatars and other images to drastically reduce storage/egress costs.
 *
 * Falls back to the original file if:
 * - The browser doesn't support WebP encoding via canvas
 * - The file is already small enough
 * - Anything fails during compression (we never break the upload)
 */

export interface CompressOptions {
  /** Max width/height in pixels (keeps aspect ratio). Default: 512 */
  maxDimension?: number;
  /** WebP quality 0..1. Default: 0.82 */
  quality?: number;
  /** Skip compression if original file is smaller than this (bytes). Default: 30KB */
  minSizeToCompress?: number;
  /** Output filename base (without extension). Default: original name */
  fileNameBase?: string;
}

export async function compressImageToWebP(
  file: File,
  options: CompressOptions = {}
): Promise<File> {
  const {
    maxDimension = 512,
    quality = 0.82,
    minSizeToCompress = 30 * 1024,
    fileNameBase,
  } = options;

  // Skip non-images and tiny files
  if (!file.type.startsWith('image/')) return file;
  if (file.size < minSizeToCompress) return file;
  // SVGs and animated GIFs: don't touch
  if (file.type === 'image/svg+xml' || file.type === 'image/gif') return file;

  try {
    const bitmap = await createBitmap(file);
    const { width, height } = scaleDimensions(bitmap.width, bitmap.height, maxDimension);

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return file;
    ctx.drawImage(bitmap, 0, 0, width, height);
    if ('close' in bitmap && typeof (bitmap as ImageBitmap).close === 'function') {
      (bitmap as ImageBitmap).close();
    }

    const blob: Blob | null = await new Promise((resolve) =>
      canvas.toBlob(resolve, 'image/webp', quality)
    );
    if (!blob || blob.size === 0) return file;

    // If somehow WebP got bigger, keep original
    if (blob.size >= file.size) return file;

    const baseName = (fileNameBase || file.name.replace(/\.[^.]+$/, '')) || 'image';
    return new File([blob], `${baseName}.webp`, { type: 'image/webp' });
  } catch {
    return file;
  }
}

async function createBitmap(file: File): Promise<ImageBitmap | HTMLImageElement> {
  if (typeof createImageBitmap === 'function') {
    try {
      return await createImageBitmap(file);
    } catch {
      // fall through to <img> fallback
    }
  }
  return await new Promise<HTMLImageElement>((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = (e) => {
      URL.revokeObjectURL(url);
      reject(e);
    };
    img.src = url;
  });
}

function scaleDimensions(w: number, h: number, max: number) {
  if (w <= max && h <= max) return { width: w, height: h };
  const ratio = Math.min(max / w, max / h);
  return { width: Math.round(w * ratio), height: Math.round(h * ratio) };
}
