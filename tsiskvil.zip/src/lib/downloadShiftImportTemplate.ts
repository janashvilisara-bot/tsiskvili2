import ExcelJS from 'exceljs';
import { format, addDays } from 'date-fns';

export const downloadShiftImportTemplate = async () => {
  const workbook = new ExcelJS.Workbook();

  // Add instructions sheet
  const instructionsSheet = workbook.addWorksheet('ინსტრუქცია');
  const instructions = [
    ['ინსტრუქცია: როგორ გამოვიყენოთ ეს შაბლონი'],
    [''],
    ['1. შეავსეთ შემდეგი სვეტები:'],
    ['   - სახელი გვარი: თანამშრომლის სრული სახელი (უნდა ემთხვეოდეს სისტემაში არსებულ სახელს)'],
    ['   - თარიღი: YYYY-MM-DD ფორმატით (მაგ: 2024-01-15)'],
    ['   - ცვლის სახელი: ცვლის დასახელება (არააუცილებელი)'],
    ['   - დაწყება: HH:MM ფორმატით (მაგ: 09:00)'],
    ['   - დასრულება: HH:MM ფორმატით (მაგ: 18:00)'],
    ['   - შესვენება (წუთი): წუთებში (მაგ: 60)'],
    ['   - შენიშვნა: დამატებითი ინფორმაცია (არააუცილებელი)'],
    [''],
    ['2. მაგალითები მოცემულია "მაგალითები" ფურცელზე'],
    [''],
    ['3. წაშალეთ მაგალითი მონაცემები და დაამატეთ თქვენი'],
    [''],
    ['4. შეინახეთ ფაილი და ატვირთეთ სისტემაში'],
    [''],
    ['⚠️ მნიშვნელოვანი:'],
    ['   - თანამშრომლის სახელი უნდა ემთხვეოდეს სისტემაში არსებულ სახელს'],
    ['   - თარიღის ფორმატი: YYYY-MM-DD (მაგ: 2024-01-15)'],
    ['   - დროის ფორმატი: HH:MM (მაგ: 09:00)'],
    ['   - 24-საათიანი ფორმატი (00:00 - 23:59)'],
  ];
  
  instructions.forEach(row => {
    instructionsSheet.addRow(row);
  });
  instructionsSheet.getColumn(1).width = 80;

  // Add sample data sheet
  const dataSheet = workbook.addWorksheet('მაგალითები');
  dataSheet.columns = [
    { header: 'სახელი გვარი', key: 'name', width: 20 },
    { header: 'თარიღი', key: 'date', width: 12 },
    { header: 'ცვლის სახელი', key: 'shift', width: 18 },
    { header: 'დაწყება', key: 'start', width: 10 },
    { header: 'დასრულება', key: 'end', width: 10 },
    { header: 'შესვენება (წუთი)', key: 'break', width: 18 },
    { header: 'შენიშვნა', key: 'notes', width: 25 },
  ];

  const today = new Date();
  dataSheet.addRow({
    name: 'გიორგი მელაძე',
    date: format(today, 'yyyy-MM-dd'),
    shift: 'დილის ცვლა',
    start: '09:00',
    end: '18:00',
    break: 60,
    notes: 'რეგულარული გრაფიკი'
  });
  dataSheet.addRow({
    name: 'ნინო ბერიძე',
    date: format(addDays(today, 1), 'yyyy-MM-dd'),
    shift: 'ღამის ცვლა',
    start: '22:00',
    end: '06:00',
    break: 60,
    notes: ''
  });
  dataSheet.addRow({
    name: 'დავით კაპანაძე',
    date: format(addDays(today, 2), 'yyyy-MM-dd'),
    shift: '12-საათიანი დღის',
    start: '08:00',
    end: '20:00',
    break: 60,
    notes: 'შაბათ-კვირის ცვლა'
  });

  // Style header row
  dataSheet.getRow(1).font = { bold: true };
  dataSheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };

  // Add empty template sheet
  const templateSheet = workbook.addWorksheet('შაბლონი');
  templateSheet.columns = [
    { header: 'სახელი გვარი', key: 'name', width: 20 },
    { header: 'თარიღი', key: 'date', width: 12 },
    { header: 'ცვლის სახელი', key: 'shift', width: 18 },
    { header: 'დაწყება', key: 'start', width: 10 },
    { header: 'დასრულება', key: 'end', width: 10 },
    { header: 'შესვენება (წუთი)', key: 'break', width: 18 },
    { header: 'შენიშვნა', key: 'notes', width: 25 },
  ];
  templateSheet.addRow({ name: '', date: '', shift: '', start: '', end: '', break: '', notes: '' });
  
  templateSheet.getRow(1).font = { bold: true };
  templateSheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };

  // Generate file name and download
  const fileName = `cvelis-importis-shabloni-${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
  
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  link.click();
  window.URL.revokeObjectURL(url);
};
