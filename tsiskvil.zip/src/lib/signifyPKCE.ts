// PKCE helpers for Signify OAuth flow

function generateRandomString(length: number): string {
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return Array.from(array, (b) => b.toString(36).padStart(2, '0')).join('').slice(0, length);
}

async function sha256(plain: string): Promise<ArrayBuffer> {
  const encoder = new TextEncoder();
  const data = encoder.encode(plain);
  return crypto.subtle.digest('SHA-256', data);
}

function base64UrlEncode(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (const b of bytes) {
    binary += String.fromCharCode(b);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export async function generatePKCE() {
  const codeVerifier = generateRandomString(43);
  const hash = await sha256(codeVerifier);
  const codeChallenge = base64UrlEncode(hash);
  return { codeVerifier, codeChallenge };
}

export function generateState(): string {
  return generateRandomString(10);
}

const SIGNIFY_CLIENT_ID = 'talentos_9amtat5vfrn62me6s7dx';
const SIGNIFY_AUTHORIZE_URL = 'https://portal.signifyapp.com/oauth/authorize';

export function buildAuthorizeUrl(redirectUri: string, codeChallenge: string, state: string): string {
  const params = new URLSearchParams({
    client_id: SIGNIFY_CLIENT_ID,
    redirect_uri: redirectUri,
    scope: 'ALL openid email',
    response_type: 'code',
    code_challenge_method: 'S256',
    code_challenge: codeChallenge,
    state,
  });

  return `${SIGNIFY_AUTHORIZE_URL}?${params.toString()}`;
}

export async function initiateSignifyOAuth() {
  const { codeVerifier, codeChallenge } = await generatePKCE();
  const state = generateState();
  const redirectUri = 'https://talentos.space/signify-callback';

  // Store in sessionStorage for the callback
  sessionStorage.setItem('signify_pkce_verifier', codeVerifier);
  sessionStorage.setItem('signify_oauth_state', state);
  sessionStorage.setItem('signify_redirect_uri', redirectUri);

  const url = buildAuthorizeUrl(redirectUri, codeChallenge, state);
  window.location.href = url;
}
