import ExcelJS from 'exceljs';
import { format, eachDayOfInterval, startOfMonth, endOfMonth } from 'date-fns';
import { ka } from 'date-fns/locale';

interface ShiftSchedule {
  id: string;
  employee_id: string;
  shift_date: string;
  shift_name: string | null;
  start_time: string;
  end_time: string;
  break_duration: number;
  notes: string | null;
  employees: {
    full_name: string;
    position: string;
    personal_id?: string;
  };
}

export const exportShiftSchedulesToExcel = async (
  shifts: ShiftSchedule[],
  month: Date,
  organizationName: string = 'ორგანიზაცია'
) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('ცვლების გრაფიკი');

  // Get all days in the month
  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(month),
    end: endOfMonth(month),
  });

  // Group shifts by employee
  const employeeShifts = shifts.reduce((acc, shift) => {
    if (!acc[shift.employee_id]) {
      acc[shift.employee_id] = {
        employee: shift.employees,
        shifts: [],
      };
    }
    acc[shift.employee_id].shifts.push(shift);
    return acc;
  }, {} as Record<string, { employee: any; shifts: ShiftSchedule[] }>);

  // Header rows
  worksheet.addRow(['ორგანიზაცია:', organizationName]);
  worksheet.addRow(['პერიოდი:', format(month, 'MMMM yyyy', { locale: ka })]);
  worksheet.addRow([]);

  // Column headers
  const columnHeaders = [
    '№',
    'სახელი გვარი',
    'პირადი ნომერი',
    'თანამდებობა',
    ...daysInMonth.map((day) => format(day, 'd', { locale: ka })),
    'სულ საათები',
    'სამუშაო დრო',
  ];

  const headerRow = worksheet.addRow(columnHeaders);
  headerRow.font = { bold: true };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };

  // Process each employee
  let rowNumber = 1;
  let grandTotalHours = 0;

  Object.values(employeeShifts).forEach(({ employee, shifts: empShifts }) => {
    const rowData: any[] = [
      rowNumber++,
      employee.full_name,
      employee.personal_id || '-',
      employee.position,
    ];

    let employeeTotalHours = 0;
    const employeeWorkTimes = new Set<string>();

    // For each day in the month
    daysInMonth.forEach((day) => {
      const dayShifts = empShifts.filter(
        (shift) => shift.shift_date === format(day, 'yyyy-MM-dd')
      );

      if (dayShifts.length > 0) {
        let dayHours = 0;
        dayShifts.forEach((shift) => {
          const [startHour, startMin] = shift.start_time.split(':').map(Number);
          const [endHour, endMin] = shift.end_time.split(':').map(Number);

          let hours = endHour - startHour;
          let minutes = endMin - startMin;

          if (hours < 0) {
            hours += 24;
          }

          const totalMinutes = hours * 60 + minutes - shift.break_duration;
          const totalHours = totalMinutes / 60;
          dayHours += totalHours;

          employeeWorkTimes.add(`${shift.start_time}-${shift.end_time}`);
        });

        rowData.push(dayHours.toFixed(1));
        employeeTotalHours += dayHours;
      } else {
        rowData.push('-');
      }
    });

    rowData.push(employeeTotalHours.toFixed(1));
    rowData.push(Array.from(employeeWorkTimes).join(', '));
    grandTotalHours += employeeTotalHours;
    worksheet.addRow(rowData);
  });

  // Add totals row
  const totalsRow = worksheet.addRow([
    '', 
    'სულ:', 
    '', 
    '', 
    ...Array(daysInMonth.length).fill(''), 
    grandTotalHours.toFixed(1), 
    ''
  ]);
  totalsRow.font = { bold: true };

  // Set column widths
  worksheet.getColumn(1).width = 5;
  worksheet.getColumn(2).width = 25;
  worksheet.getColumn(3).width = 15;
  worksheet.getColumn(4).width = 20;
  for (let i = 5; i <= 4 + daysInMonth.length; i++) {
    worksheet.getColumn(i).width = 8;
  }
  worksheet.getColumn(5 + daysInMonth.length).width = 12;
  worksheet.getColumn(6 + daysInMonth.length).width = 25;

  // Merge header cells
  worksheet.mergeCells('A1:D1');
  worksheet.mergeCells('A2:D2');

  // Generate file name and download
  const fileName = `cvelis-grafiki-${format(month, 'yyyy-MM')}.xlsx`;
  
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  link.click();
  window.URL.revokeObjectURL(url);
};
