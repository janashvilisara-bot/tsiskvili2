import { supabase } from '@/integrations/supabase/client';

interface AnomalyCheckResult {
  login_id: string;
  is_suspicious: boolean;
  anomaly_reason: string | null;
}

interface GeoLocation {
  country?: string;
  city?: string;
  ip?: string;
}

/**
 * Get approximate location from IP using free API
 */
async function getGeoLocation(): Promise<GeoLocation> {
  try {
    // Use ipapi.co for free IP geolocation (no API key required for basic usage)
    const response = await fetch('https://ipapi.co/json/', {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });
    
    if (!response.ok) {
      return {};
    }
    
    const data = await response.json();
    return {
      country: data.country_name || data.country,
      city: data.city,
      ip: data.ip
    };
  } catch (err) {
    console.error('Failed to get geolocation:', err);
    return {};
  }
}

/**
 * Log login attempt and check for anomalies
 * Call this after successful authentication
 */
export async function trackLoginWithAnomalyCheck(
  userId: string,
  email: string
): Promise<AnomalyCheckResult | null> {
  try {
    // Get geo location
    const geo = await getGeoLocation();
    const userAgent = typeof navigator !== 'undefined' ? navigator.userAgent : null;

    // Call the database function to log and check anomaly
    const { data, error } = await supabase.rpc('log_login_with_anomaly_check', {
      p_user_id: userId,
      p_email: email,
      p_ip_address: geo.ip || null,
      p_user_agent: userAgent,
      p_country: geo.country || null,
      p_city: geo.city || null
    });

    if (error) {
      console.error('Login anomaly check error:', error);
      return null;
    }

    return data as unknown as AnomalyCheckResult;
  } catch (err) {
    console.error('Login tracking failed:', err);
    return null;
  }
}

/**
 * Get login history for current user
 */
export async function getMyLoginHistory(limit: number = 20) {
  try {
    const { data, error } = await supabase
      .from('login_history')
      .select('*')
      .order('login_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Get login history error:', error);
      return [];
    }

    return data || [];
  } catch (err) {
    console.error('Get login history failed:', err);
    return [];
  }
}

/**
 * Get all suspicious logins (for admin/HR)
 */
export async function getSuspiciousLogins(limit: number = 50) {
  try {
    const { data, error } = await supabase
      .from('login_history')
      .select('*')
      .eq('is_suspicious', true)
      .order('login_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Get suspicious logins error:', error);
      return [];
    }

    return data || [];
  } catch (err) {
    console.error('Get suspicious logins failed:', err);
    return [];
  }
}
