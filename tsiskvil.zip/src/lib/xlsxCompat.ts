import ExcelJS from 'exceljs';

/**
 * Compatibility layer to replace vulnerable xlsx package with ExcelJS
 * Provides similar API for easy migration
 */

export const XLSX = {
  utils: {
    book_new: () => new ExcelJS.Workbook(),
    
    json_to_sheet: (data: any[]) => {
      // Returns the data - actual conversion happens in book_append_sheet
      return { _data: data, _type: 'json' };
    },
    
    aoa_to_sheet: (data: any[][]) => {
      // Returns the data - actual conversion happens in book_append_sheet
      return { _data: data, _type: 'aoa' };
    },
    
    book_append_sheet: (workbook: ExcelJS.Workbook, sheetData: any, name: string) => {
      const worksheet = workbook.addWorksheet(name);
      
      if (sheetData._type === 'json' && sheetData._data.length > 0) {
        const data = sheetData._data;
        const headers = Object.keys(data[0]);
        worksheet.columns = headers.map(h => ({ header: h, key: h, width: 18 }));
        data.forEach((row: any) => worksheet.addRow(row));
        worksheet.getRow(1).font = { bold: true };
        worksheet.getRow(1).fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFE0E0E0' }
        };
      } else if (sheetData._type === 'aoa') {
        sheetData._data.forEach((row: any[]) => worksheet.addRow(row));
      }
      
      return worksheet;
    },
    
    sheet_to_json: (worksheet: ExcelJS.Worksheet) => {
      const rows: any[] = [];
      const headers: string[] = [];
      
      worksheet.eachRow((row, rowNumber) => {
        if (rowNumber === 1) {
          row.eachCell((cell) => headers.push(String(cell.value || '')));
        } else {
          const rowData: any = {};
          row.eachCell((cell, colNumber) => {
            if (headers[colNumber - 1]) {
              rowData[headers[colNumber - 1]] = cell.value;
            }
          });
          rows.push(rowData);
        }
      });
      
      return rows;
    }
  },
  
  read: async (buffer: ArrayBuffer) => {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);
    return {
      SheetNames: workbook.worksheets.map(ws => ws.name),
      Sheets: workbook.worksheets.reduce((acc, ws) => {
        acc[ws.name] = ws;
        return acc;
      }, {} as Record<string, ExcelJS.Worksheet>)
    };
  },
  
  writeFile: async (workbook: ExcelJS.Workbook, filename: string) => {
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { 
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    window.URL.revokeObjectURL(url);
  }
};

export default XLSX;
