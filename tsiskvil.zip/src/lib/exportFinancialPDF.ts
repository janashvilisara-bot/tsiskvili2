import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface FinancialData {
  payrollSheet: any[];
  budgetSheet: any[];
  expensesSheet: any[];
  overtimeSheet: any[];
  weekendSheet: any[];
  holidaySheet: any[];
  leaveSheet: any[];
}

export const exportFinancialPDF = async (
  data: FinancialData,
  startDate: string,
  endDate: string
) => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  let yPosition = 20;

  // Add Georgian font support (using default for now, Georgian text may need custom font)
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);

  // Title
  doc.text('სრული ფინანსური ანგარიში', 105, yPosition, { align: 'center' });
  yPosition += 10;

  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text(`პერიოდი: ${new Date(startDate).toLocaleDateString('ka-GE')} - ${new Date(endDate).toLocaleDateString('ka-GE')}`, 105, yPosition, { align: 'center' });
  yPosition += 15;

  // Calculate summaries
  const totalPayroll = data.payrollSheet.reduce((sum, row) => sum + (row['საბაზო ხელფასი'] || 0), 0);
  const totalExpenses = data.expensesSheet.reduce((sum, row) => sum + (row['თანხა'] || 0), 0);
  const totalOvertime = data.overtimeSheet.reduce((sum, row) => sum + (row['ღირებულება'] || 0), 0);
  const totalWeekend = data.weekendSheet.reduce((sum, row) => sum + (row['ღირებულება'] || 0), 0);
  const totalHoliday = data.holidaySheet.reduce((sum, row) => sum + (row['ღირებულება'] || 0), 0);
  const totalLeave = data.leaveSheet.reduce((sum, row) => sum + (row['ღირებულება'] || 0), 0);

  const totalCosts = totalPayroll + totalExpenses + totalOvertime + totalWeekend + totalHoliday + totalLeave;

  // Summary section
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('ფინანსური მიმოხილვა', 14, yPosition);
  yPosition += 10;

  const summaryData = [
    ['ხელფასების ფონდი', `${totalPayroll.toFixed(2)} ₾`],
    ['ბიუჯეტის ხარჯები', `${totalExpenses.toFixed(2)} ₾`],
    ['ზეგანაკვეთური', `${totalOvertime.toFixed(2)} ₾`],
    ['უქმე დღეები', `${totalWeekend.toFixed(2)} ₾`],
    ['დასვენების დღეები', `${totalHoliday.toFixed(2)} ₾`],
    ['შვებულებები', `${totalLeave.toFixed(2)} ₾`],
    ['სულ', `${totalCosts.toFixed(2)} ₾`],
  ];

  autoTable(doc, {
    startY: yPosition,
    head: [['კატეგორია', 'თანხა']],
    body: summaryData,
    theme: 'grid',
    headStyles: { fillColor: [59, 130, 246], textColor: 255, fontStyle: 'bold' },
    styles: { font: 'helvetica', fontSize: 10, cellPadding: 3 },
    columnStyles: {
      0: { cellWidth: 120 },
      1: { cellWidth: 60, halign: 'right', fontStyle: 'bold' },
    },
  });

  yPosition = (doc as any).lastAutoTable.finalY + 15;

  // Add pie chart representation (text-based for simplicity)
  if (yPosition > 250) {
    doc.addPage();
    yPosition = 20;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('ხარჯების განაწილება (%)', 14, yPosition);
  yPosition += 10;

  const distributionData = [
    ['ხელფასები', `${((totalPayroll / totalCosts) * 100).toFixed(1)}%`],
    ['ბიუჯეტის ხარჯები', `${((totalExpenses / totalCosts) * 100).toFixed(1)}%`],
    ['ზეგანაკვეთური', `${((totalOvertime / totalCosts) * 100).toFixed(1)}%`],
    ['უქმე დღეები', `${((totalWeekend / totalCosts) * 100).toFixed(1)}%`],
    ['დასვენების დღეები', `${((totalHoliday / totalCosts) * 100).toFixed(1)}%`],
    ['შვებულებები', `${((totalLeave / totalCosts) * 100).toFixed(1)}%`],
  ];

  autoTable(doc, {
    startY: yPosition,
    head: [['კატეგორია', 'პროცენტი']],
    body: distributionData,
    theme: 'striped',
    headStyles: { fillColor: [16, 185, 129], textColor: 255, fontStyle: 'bold' },
    styles: { font: 'helvetica', fontSize: 10, cellPadding: 3 },
    columnStyles: {
      0: { cellWidth: 120 },
      1: { cellWidth: 60, halign: 'right', fontStyle: 'bold' },
    },
  });

  yPosition = (doc as any).lastAutoTable.finalY + 15;

  // Detailed sections
  const sections = [
    { title: 'ხელფასები', data: data.payrollSheet },
    { title: 'ბიუჯეტი', data: data.budgetSheet },
    { title: 'ხარჯები', data: data.expensesSheet },
    { title: 'ზეგანაკვეთური', data: data.overtimeSheet },
    { title: 'უქმე დღეები', data: data.weekendSheet },
    { title: 'დასვენების დღეები', data: data.holidaySheet },
    { title: 'შვებულებები და ბიულეტენი', data: data.leaveSheet },
  ];

  for (const section of sections) {
    if (section.data && section.data.length > 0) {
      doc.addPage();
      yPosition = 20;

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text(section.title, 14, yPosition);
      yPosition += 10;

      const headers = Object.keys(section.data[0]);
      const rows = section.data.map(row => headers.map(header => row[header] || ''));

      autoTable(doc, {
        startY: yPosition,
        head: [headers],
        body: rows,
        theme: 'grid',
        headStyles: { fillColor: [59, 130, 246], textColor: 255, fontStyle: 'bold', fontSize: 8 },
        styles: { font: 'helvetica', fontSize: 7, cellPadding: 2 },
        columnStyles: headers.reduce((acc, header, index) => {
          acc[index] = { cellWidth: 'auto' };
          return acc;
        }, {} as any),
        margin: { top: 20, right: 10, bottom: 10, left: 10 },
      });
    }
  }

  // Save PDF
  const fileName = `financial_report_${startDate}_${endDate}.pdf`;
  doc.save(fileName);
};
