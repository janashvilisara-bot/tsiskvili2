import ExcelJS from 'exceljs';

interface HolidayWorkRecord {
  employee_id: string;
  employee_name: string;
  employee_number: string;
  position: string;
  department: string;
  holiday_name: string;
  holiday_date: string;
  check_in: string;
  check_out: string;
  total_hours: number;
  overtime_hours: number;
  overtime_multiplier: number;
  calculated_overtime: number;
}

export const exportHolidayWorkToExcel = async (
  records: HolidayWorkRecord[],
  year: number
) => {
  // Calculate totals
  const totalHours = records.reduce((sum, r) => sum + r.total_hours, 0);
  const totalOvertime = records.reduce((sum, r) => sum + r.overtime_hours, 0);
  const totalCalculated = records.reduce((sum, r) => sum + r.calculated_overtime, 0);
  const uniqueEmployees = new Set(records.map(r => r.employee_id)).size;

  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('დღესასწაულებში მუშაობა');

  // Summary section
  worksheet.addRow(['დასვენების დღეებში მუშაობის ანგარიში']);
  worksheet.addRow([`წელი: ${year}`]);
  worksheet.addRow([]);
  worksheet.addRow(['სტატისტიკა:']);
  worksheet.addRow(['სულ ჩანაწერი:', records.length]);
  worksheet.addRow(['უნიკალური თანამშრომლები:', uniqueEmployees]);
  worksheet.addRow(['სულ საათები:', totalHours]);
  worksheet.addRow(['ოვერთაიმის საათები:', totalOvertime]);
  worksheet.addRow(['გაანგარიშებული საათები (კოეფიციენტით):', totalCalculated]);
  worksheet.addRow([]);
  worksheet.addRow([]);

  // Detail headers
  const headerRow = worksheet.addRow([
    'თანამშრომელი',
    'პირადი ნომერი',
    'თანამდებობა',
    'დეპარტამენტი',
    'დღესასწაული',
    'თარიღი',
    'შემოსვლა',
    'გასვლა',
    'საათები',
    'ოვერთაიმი (საათები)',
    'კოეფიციენტი',
    'გაანგარიშებული საათები',
  ]);

  // Style header row
  headerRow.font = { bold: true };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };
  headerRow.alignment = { horizontal: 'center' };

  // Add data rows
  records.forEach(record => {
    worksheet.addRow([
      record.employee_name,
      record.employee_number,
      record.position,
      record.department,
      record.holiday_name,
      record.holiday_date,
      record.check_in,
      record.check_out,
      record.total_hours,
      record.overtime_hours,
      record.overtime_multiplier,
      record.calculated_overtime,
    ]);
  });

  // Add totals row
  const totalsRow = worksheet.addRow([
    'სულ:',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    totalHours,
    totalOvertime,
    '',
    totalCalculated,
  ]);
  totalsRow.font = { bold: true };
  totalsRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFFFD700' }
  };

  // Set column widths
  worksheet.columns = [
    { width: 25 },
    { width: 15 },
    { width: 20 },
    { width: 20 },
    { width: 25 },
    { width: 12 },
    { width: 10 },
    { width: 10 },
    { width: 10 },
    { width: 15 },
    { width: 12 },
    { width: 20 },
  ];

  // Generate filename and download
  const filename = `დასვენების_დღეებში_მუშაობა_${year}.xlsx`;
  
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  window.URL.revokeObjectURL(url);
};
