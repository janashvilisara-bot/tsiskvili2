export type RsgeType = "hire" | "termination" | "both";

export interface RsgeEmployee {
  id: string;
  full_name: string;
  last_name?: string | null;
  personal_id?: string | null;
  position?: string | null;
  hire_date?: string | null;
  termination_date?: string | null;
  salary?: number | null;
}

export interface RsgeRow {
  employee: RsgeEmployee;
  event: "hire" | "termination";
  date: string;
  errors: string[];
}

export const RSGE_COLUMNS = [
  "პირადი ნომერი",
  "სახელი",
  "გვარი",
  "მოვლენა",
  "თარიღი",
  "პოზიცია",
  "ხელფასი",
] as const;

const inRange = (d: string | null | undefined, from: string, to: string) =>
  !!d && d.slice(0, 10) >= from && d.slice(0, 10) <= to;

const validDate = (d: string) => /^\d{4}-\d{2}-\d{2}$/.test(d) && !isNaN(Date.parse(d));

export function validateRow(e: RsgeEmployee, date: string): string[] {
  const errs: string[] = [];
  if (!e.personal_id || !/^\d{11}$/.test(e.personal_id.trim())) errs.push("personal_id");
  if (!e.position || !e.position.trim()) errs.push("position");
  if (!validDate(date)) errs.push("date");
  return errs;
}

export function selectRows(list: RsgeEmployee[], type: RsgeType, from: string, to: string): RsgeRow[] {
  const rows: RsgeRow[] = [];
  for (const e of list) {
    if (type !== "termination" && inRange(e.hire_date, from, to)) {
      const date = e.hire_date!.slice(0, 10);
      rows.push({ employee: e, event: "hire", date, errors: validateRow(e, date) });
    }
    if (type !== "hire" && inRange(e.termination_date, from, to)) {
      const date = e.termination_date!.slice(0, 10);
      rows.push({ employee: e, event: "termination", date, errors: validateRow(e, date) });
    }
  }
  return rows.sort((a, b) => a.date.localeCompare(b.date));
}

export function splitName(e: RsgeEmployee): [string, string] {
  const full = (e.full_name || "").trim();
  if (e.last_name && full.endsWith(e.last_name)) {
    return [full.slice(0, full.length - e.last_name.length).trim(), e.last_name];
  }
  const parts = full.split(/\s+/);
  return [parts[0] || "", parts.slice(1).join(" ")];
}

export function toRecord(r: RsgeRow): (string | number)[] {
  const [first, last] = splitName(r.employee);
  return [
    r.employee.personal_id!.trim(),
    first,
    last,
    r.event === "hire" ? "დანიშვნა" : "გათავისუფლება",
    r.date,
    r.employee.position!.trim(),
    r.employee.salary ?? "",
  ];
}

const esc = (v: string | number) => {
  const s = String(v);
  return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export function buildCsv(rows: RsgeRow[]): string {
  const lines = [RSGE_COLUMNS.join(","), ...rows.filter((r) => !r.errors.length).map((r) => toRecord(r).map(esc).join(","))];
  return "\uFEFF" + lines.join("\r\n");
}

export async function buildXlsx(rows: RsgeRow[]): Promise<Blob> {
  const ExcelJS = (await import("exceljs")).default;
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet("RS.ge");
  ws.addRow([...RSGE_COLUMNS]).font = { bold: true };
  rows.filter((r) => !r.errors.length).forEach((r) => ws.addRow(toRecord(r)));
  ws.getColumn(1).numFmt = "@";
  ws.columns.forEach((c) => (c.width = 20));
  const buf = await wb.xlsx.writeBuffer();
  return new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
}
