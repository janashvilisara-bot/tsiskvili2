// Once-per-day rule for the anonymous logout check-in.
// The "done today" marker lives only in this browser (localStorage) so the database
// never links a check-in to a person.
const KEY = "talentos-anon-checkin-date";

export function localDateKey(d: Date = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function shouldAskCheckin(lastDone: string | null, now: Date = new Date()): boolean {
  return lastDone !== localDateKey(now);
}

export function hasCheckedInToday(): boolean {
  try {
    return !shouldAskCheckin(localStorage.getItem(KEY));
  } catch {
    return false;
  }
}

export function markCheckedInToday(): void {
  try {
    localStorage.setItem(KEY, localDateKey());
  } catch {
    // storage unavailable
  }
}
