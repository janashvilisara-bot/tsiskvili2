import { Document, Packer, Paragraph, Table, TableRow, TableCell, TextRun, WidthType, AlignmentType, BorderStyle } from "docx";
import { saveAs } from "file-saver";

const borders = {
  top: { style: BorderStyle.SINGLE, size: 1, color: "000000" },
  bottom: { style: BorderStyle.SINGLE, size: 1, color: "000000" },
  left: { style: BorderStyle.SINGLE, size: 1, color: "000000" },
  right: { style: BorderStyle.SINGLE, size: 1, color: "000000" },
};

function hCell(text: string, w: number): TableCell {
  return new TableCell({ borders, width: { size: w, type: WidthType.DXA }, shading: { fill: "F0F0F0" }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text, bold: true, size: 20 })] })] });
}
function tCell(text: string, w: number, bold = false): TableCell {
  return new TableCell({ borders, width: { size: w, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text, bold, size: 20 })] })] });
}

export const exportAppendixSLA = (contractNumber: string = "____-__", date: string = new Date().toLocaleDateString('ka-GE')) => {
  const doc = new Document({
    sections: [{
      children: [
        new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "კონფიდენციალური", color: "CC0000", size: 20, italics: true })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 300, after: 100 }, children: [new TextRun({ text: `გენერალური ხელშეკრულება No${contractNumber}`, bold: true, size: 28 })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "დანართი #3 - SLA (მომსახურების დონის შეთანხმება)", bold: true, size: 28 })] }),
        new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: "ქ. თბილისი", size: 22 }), new TextRun({ text: `\t\t\t\t\t\t\t\t${date}`, size: 22 })] }),

        // 1. Availability
        h("1. სისტემის ხელმისაწვდომობა"),
        n("1.1", "შემსრულებელი იღებს ვალდებულებას უზრუნველყოს სისტემის ხელმისაწვდომობა შემდეგი სტანდარტებით:"),
        new Table({
          rows: [
            new TableRow({ children: [hCell("პაკეტი", 3000), hCell("ხელმისაწვდომობა", 3500), hCell("მაქსიმალური downtime/თვე", 3500)] }),
            new TableRow({ children: [tCell("Starter", 3000, true), tCell("99.5%", 3500), tCell("3.6 საათი", 3500)] }),
            new TableRow({ children: [tCell("Professional", 3000, true), tCell("99.7%", 3500), tCell("2.2 საათი", 3500)] }),
            new TableRow({ children: [tCell("Enterprise", 3000, true), tCell("99.9%", 3500), tCell("43.8 წუთი", 3500)] }),
          ],
          width: { size: 10000, type: WidthType.DXA },
        }),
        n("1.2", "ხელმისაწვდომობის გაანგარიშებისას არ ითვლება: დაგეგმილი ტექნიკური სამუშაოები, ფორსმაჟორი, დამკვეთის მხრიდან გამოწვეული შეფერხებები."),

        // 2. Response times
        h("2. რეაგირების დრო"),
        new Table({
          rows: [
            new TableRow({ children: [hCell("პრიორიტეტი", 2000), hCell("აღწერა", 3500), hCell("რეაგირება", 2000), hCell("გადაწყვეტა", 2500)] }),
            new TableRow({ children: [tCell("კრიტიკული (P1)", 2000, true), tCell("სისტემა მთლიანად მიუწვდომელია", 3500), tCell("30 წუთი", 2000), tCell("4 საათი", 2500)] }),
            new TableRow({ children: [tCell("მაღალი (P2)", 2000, true), tCell("ძირითადი ფუნქცია არ მუშაობს", 3500), tCell("1 საათი", 2000), tCell("8 საათი", 2500)] }),
            new TableRow({ children: [tCell("საშუალო (P3)", 2000, true), tCell("ფუნქცია მუშაობს შეზღუდვით", 3500), tCell("4 საათი", 2000), tCell("24 საათი", 2500)] }),
            new TableRow({ children: [tCell("დაბალი (P4)", 2000, true), tCell("კოსმეტიკური ხარვეზი / წინადადება", 3500), tCell("8 საათი", 2000), tCell("5 სამუშაო დღე", 2500)] }),
          ],
          width: { size: 10000, type: WidthType.DXA },
        }),

        // 3. Support
        h("3. ტექნიკური მხარდაჭერა"),
        n("3.1", "ტექნიკური მხარდაჭერა ხელმისაწვდომია სამუშაო დღეებში 09:00-დან 18:00-მდე (თბილისის დროით)."),
        n("3.2", "Enterprise პაკეტის მომხმარებლებისთვის მხარდაჭერა ხელმისაწვდომია 24/7 რეჟიმში კრიტიკული (P1) ინციდენტებისთვის."),
        n("3.3", "მხარდაჭერის არხები: ელ.ფოსტა, ჩატი სისტემაში, ტელეფონი (Enterprise)."),

        // 4. Backups
        h("4. მონაცემთა სარეზერვო ასლები"),
        n("4.1", "მონაცემთა ავტომატური backup ხორციელდება ყოველდღიურად."),
        n("4.2", "სარეზერვო ასლები ინახება მინიმუმ 30 კალენდარული დღის განმავლობაში."),
        n("4.3", "მონაცემთა აღდგენის მოთხოვნა მუშავდება არაუგვიანეს 4 საათისა."),

        // 5. Compensation
        h("5. კომპენსაცია SLA დარღვევისას"),
        n("5.1", "SLA-ით განსაზღვრული ხელმისაწვდომობის დარღვევისას, დამკვეთს ეძლევა კომპენსაცია:"),
        new Table({
          rows: [
            new TableRow({ children: [hCell("Downtime", 5000), hCell("კომპენსაცია", 5000)] }),
            new TableRow({ children: [tCell("SLA-ს დარღვევა ≤ 2x", 5000), tCell("მომსახურების საფასურის 10% კრედიტი", 5000)] }),
            new TableRow({ children: [tCell("SLA-ს დარღვევა 2x - 5x", 5000), tCell("მომსახურების საფასურის 25% კრედიტი", 5000)] }),
            new TableRow({ children: [tCell("SLA-ს დარღვევა > 5x", 5000), tCell("მომსახურების საფასურის 50% კრედიტი", 5000)] }),
          ],
          width: { size: 10000, type: WidthType.DXA },
        }),

        // 6. Maintenance
        h("6. დაგეგმილი ტექნიკური სამუშაოები"),
        n("6.1", "დაგეგმილი ტექნიკური სამუშაოები ხორციელდება არასამუშაო საათებში (22:00 - 06:00)."),
        n("6.2", "შემსრულებელი ვალდებულია წინასწარ შეატყობინოს დამკვეთს დაგეგმილი სამუშაოების შესახებ მინიმუმ 24 საათით ადრე."),
        n("6.3", "გადაუდებელი ტექნიკური სამუშაოების შემთხვევაში შეტყობინება ხორციელდება დაუყოვნებლივ."),

        // Signatures
        new Paragraph({ spacing: { before: 600 }, children: [] }),
        new Paragraph({ children: [new TextRun({ text: "დამკვეთი: ___________________", size: 20 }), new TextRun({ text: "\t\t\t\t" }), new TextRun({ text: "შემსრულებელი: ___________________", size: 20 })] }),
      ],
    }],
  });

  Packer.toBlob(doc).then((blob) => {
    saveAs(blob, `TalentOS_Appendix3_SLA_${contractNumber}.docx`);
  });
};

function h(text: string): Paragraph {
  return new Paragraph({ spacing: { before: 400, after: 200 }, children: [new TextRun({ text, bold: true, size: 24 })] });
}
function n(num: string, text: string): Paragraph {
  return new Paragraph({ spacing: { after: 100 }, children: [new TextRun({ text: `${num}. `, bold: true, size: 22 }), new TextRun({ text, size: 22 })] });
}
