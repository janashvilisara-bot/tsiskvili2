import { Document, Packer, Paragraph, Table, TableRow, TableCell, TextRun, WidthType, AlignmentType, BorderStyle } from "docx";
import { saveAs } from "file-saver";

const borders = {
  top: { style: BorderStyle.SINGLE, size: 1, color: "000000" },
  bottom: { style: BorderStyle.SINGLE, size: 1, color: "000000" },
  left: { style: BorderStyle.SINGLE, size: 1, color: "000000" },
  right: { style: BorderStyle.SINGLE, size: 1, color: "000000" },
};

function headerCell(text: string, width: number): TableCell {
  return new TableCell({
    borders,
    width: { size: width, type: WidthType.DXA },
    shading: { fill: "F0F0F0" },
    children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text, bold: true, size: 20 })] })],
  });
}

function cell(text: string, width: number, bold = false): TableCell {
  return new TableCell({
    borders,
    width: { size: width, type: WidthType.DXA },
    children: [new Paragraph({ children: [new TextRun({ text, bold, size: 20 })] })],
  });
}

export const exportAppendixTariffs = (contractNumber: string = "____-__", date: string = new Date().toLocaleDateString('ka-GE')) => {
  const packages = [
    { name: "Starter", employees: "50-მდე", monthly: "₾350", yearly: "₾280", features: "ძირითადი HR ფუნქციები, დასწრება, შვებულებები, ხელფასები, დოკუმენტაცია, ჩატი" },
    { name: "Professional", employees: "51-200", monthly: "₾450", yearly: "₾360", features: "Starter + SMS შეტყობინებები, GPS/Geofencing, რეკრუტინგი, OKR-ები, ვიდეო ზარები, ანალიტიკა" },
    { name: "Enterprise", employees: "201+", monthly: "ინდივიდუალური", yearly: "ინდივიდუალური", features: "Professional + AI ასისტენტი (ნინა), ულიმიტო SMS, SLA 99.9%, გამოყოფილი მენეჯერი, On-premise ინსტალაცია" },
  ];

  const pricingRows = packages.map(pkg =>
    new TableRow({
      children: [
        cell(pkg.name, 1500, true),
        cell(pkg.employees, 1500),
        cell(pkg.monthly, 1500),
        cell(pkg.yearly, 1500),
        cell(pkg.features, 4000),
      ],
    })
  );

  const doc = new Document({
    sections: [{
      children: [
        new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "კონფიდენციალური", color: "CC0000", size: 20, italics: true })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 300, after: 100 }, children: [new TextRun({ text: `გენერალური ხელშეკრულება No${contractNumber}`, bold: true, size: 28 })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "დანართი #2 - ტარიფები და გადახდის პირობები", bold: true, size: 28 })] }),
        new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: "ქ. თბილისი", size: 22 }), new TextRun({ text: `\t\t\t\t\t\t\t\t${date}`, size: 22 })] }),

        // Section 1
        new Paragraph({ spacing: { before: 300, after: 200 }, children: [new TextRun({ text: "1. სატარიფო პაკეტები", bold: true, size: 24 })] }),
        new Table({
          rows: [
            new TableRow({ children: [headerCell("პაკეტი", 1500), headerCell("თანამშრომლები", 1500), headerCell("თვიური", 1500), headerCell("წლიური (თვეში)", 1500), headerCell("მოიცავს", 4000)] }),
            ...pricingRows,
          ],
          width: { size: 10000, type: WidthType.DXA },
        }),

        // Section 2
        new Paragraph({ spacing: { before: 400, after: 200 }, children: [new TextRun({ text: "2. ფასდაკლების პირობები", bold: true, size: 24 })] }),
        numbered("2.1", "წლიური გადახდის შემთხვევაში მოქმედებს 20%-იანი ფასდაკლება."),
        numbered("2.2", "პირველი თვე უფასოა (საცდელი პერიოდი)."),
        numbered("2.3", "50-ზე მეტი თანამშრომლის დამატების შემთხვევაში, ყოველ დამატებით 10 თანამშრომელზე ემატება ₾30/თვე (Starter/Professional)."),

        // Section 3
        new Paragraph({ spacing: { before: 400, after: 200 }, children: [new TextRun({ text: "3. გადახდის პირობები", bold: true, size: 24 })] }),
        numbered("3.1", "გადახდა ხორციელდება ყოველთვიურად, არაუგვიანეს მიმდინარე თვის 10 რიცხვისა."),
        numbered("3.2", "ანგარიშფაქტურა გაიცემა ყოველი თვის 1 რიცხვში."),
        numbered("3.3", "გადახდა ხორციელდება საბანკო გადარიცხვით ლარში (GEL)."),
        numbered("3.4", "წლიური გადახდის შემთხვევაში, გადახდა ხორციელდება ერთჯერადად ხელშეკრულების გაფორმებიდან 5 სამუშაო დღეში."),

        // Section 4
        new Paragraph({ spacing: { before: 400, after: 200 }, children: [new TextRun({ text: "4. დამატებითი მომსახურება", bold: true, size: 24 })] }),
        new Table({
          rows: [
            new TableRow({ children: [headerCell("მომსახურება", 5000), headerCell("ღირებულება", 5000)] }),
            new TableRow({ children: [cell("სისტემის ინდივიდუალური მორგება (Customization)", 5000), cell("შეთანხმებით", 5000)] }),
            new TableRow({ children: [cell("ტრენინგი (ონლაინ, 2 საათი)", 5000), cell("₾200 / სესია", 5000)] }),
            new TableRow({ children: [cell("ტრენინგი (ადგილზე, 4 საათი)", 5000), cell("₾500 / სესია", 5000)] }),
            new TableRow({ children: [cell("On-premise ინსტალაცია (Docker)", 5000), cell("₾2,000 (ერთჯერადი)", 5000)] }),
            new TableRow({ children: [cell("დამატებითი SMS პაკეტი (1000 SMS)", 5000), cell("₾150", 5000)] }),
            new TableRow({ children: [cell("API ინტეგრაცია (კლიენტის სისტემასთან)", 5000), cell("შეთანხმებით", 5000)] }),
          ],
          width: { size: 10000, type: WidthType.DXA },
        }),

        // Signatures
        new Paragraph({ spacing: { before: 600 }, children: [] }),
        new Paragraph({ children: [new TextRun({ text: "დამკვეთი: ___________________", size: 20 }), new TextRun({ text: "\t\t\t\t" }), new TextRun({ text: "შემსრულებელი: ___________________", size: 20 })] }),
      ],
    }],
  });

  Packer.toBlob(doc).then((blob) => {
    saveAs(blob, `TalentOS_Appendix2_Tariffs_${contractNumber}.docx`);
  });
};

function numbered(num: string, text: string): Paragraph {
  return new Paragraph({ spacing: { after: 100 }, children: [new TextRun({ text: `${num}. `, bold: true, size: 22 }), new TextRun({ text, size: 22 })] });
}
