import { Document, Packer, Paragraph, TextRun, AlignmentType, HeadingLevel, BorderStyle, TabStopPosition, TabStopType } from "docx";
import { saveAs } from "file-saver";

export const exportMasterAgreement = (contractNumber: string = "____-__", date: string = new Date().toLocaleDateString('ka-GE')) => {
  const doc = new Document({
    sections: [
      {
        children: [
          new Paragraph({
            alignment: AlignmentType.RIGHT,
            children: [new TextRun({ text: "კონფიდენციალური", color: "CC0000", size: 20, italics: true })],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 400, after: 200 },
            children: [new TextRun({ text: "გენერალური ხელშეკრულება", bold: true, size: 32 })],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 200 },
            children: [new TextRun({ text: `No ${contractNumber}`, bold: true, size: 28 })],
          }),
          new Paragraph({
            spacing: { after: 200 },
            children: [
              new TextRun({ text: "ქ. თბილისი", size: 22 }),
              new TextRun({ text: `\t\t\t\t\t\t\t\t${date}`, size: 22 }),
            ],
          }),
          new Paragraph({ spacing: { after: 100 }, children: [] }),

          // Preamble
          new Paragraph({
            spacing: { after: 200 },
            children: [
              new TextRun({ text: "ერთი მხრივ, ", size: 22 }),
              new TextRun({ text: "შ.პ.ს. \"________________________\"", bold: true, size: 22 }),
              new TextRun({ text: " (ს/კ: _______________), წარმოდგენილი დირექტორის __________________ სახით, შემდგომში მოხსენიებული, როგორც ", size: 22 }),
              new TextRun({ text: "\"შემსრულებელი\"", bold: true, size: 22 }),
              new TextRun({ text: ", და მეორე მხრივ, ", size: 22 }),
              new TextRun({ text: "შ.პ.ს. \"________________________\"", bold: true, size: 22 }),
              new TextRun({ text: " (ს/კ: _______________), წარმოდგენილი დირექტორის __________________ სახით, შემდგომში მოხსენიებული, როგორც ", size: 22 }),
              new TextRun({ text: "\"დამკვეთი\"", bold: true, size: 22 }),
              new TextRun({ text: ", ერთობლივად მოხსენიებულნი, როგორც \"მხარეები\", დადეს წინამდებარე ხელშეკრულება შემდეგზე:", size: 22 }),
            ],
          }),

          // Article 1
          heading("მუხლი 1. ხელშეკრულების საგანი"),
          numberedParagraph("1.1", "შემსრულებელი იღებს ვალდებულებას, დამკვეთს მიაწოდოს ადამიანური რესურსების მართვის ციფრული პლატფორმა \"TalentOS\" (შემდგომში - \"სისტემა\") და უზრუნველყოს მისი ფუნქციონირება წინამდებარე ხელშეკრულებით განსაზღვრული პირობებით."),
          numberedParagraph("1.2", "სისტემის ფუნქციონალური მახასიათებლები დეტალურად განსაზღვრულია დანართი #1-ში, რომელიც წარმოადგენს წინამდებარე ხელშეკრულების განუყოფელ ნაწილს."),
          numberedParagraph("1.3", "მომსახურების ტარიფები და გადახდის პირობები განსაზღვრულია დანართი #2-ში."),
          numberedParagraph("1.4", "მომსახურების ხარისხის სტანდარტები (SLA) განსაზღვრულია დანართი #3-ში."),

          // Article 2
          heading("მუხლი 2. ხელშეკრულების ვადა"),
          numberedParagraph("2.1", "წინამდებარე ხელშეკრულება ძალაშია ხელმოწერის მომენტიდან და მოქმედებს 12 (თორმეტი) კალენდარული თვის განმავლობაში."),
          numberedParagraph("2.2", "ხელშეკრულება ავტომატურად გრძელდება მომდევნო 12 (თორმეტი) თვის ვადით, თუ არცერთი მხარე არ გამოხატავს ხელშეკრულების შეწყვეტის სურვილს ვადის ამოწურვამდე არანაკლებ 30 (ოცდაათი) კალენდარული დღით ადრე."),
          numberedParagraph("2.3", "ხელშეკრულების ვადის ამოწურვისას ან შეწყვეტისას, დამკვეთს ეძლევა 30 (ოცდაათი) კალენდარული დღე სისტემაში არსებული მონაცემების ექსპორტისთვის."),

          // Article 3
          heading("მუხლი 3. შემსრულებლის ვალდებულებები"),
          numberedParagraph("3.1", "უზრუნველყოს სისტემის უწყვეტი ფუნქციონირება SLA-ში განსაზღვრული სტანდარტების შესაბამისად."),
          numberedParagraph("3.2", "უზრუნველყოს დამკვეთის მონაცემთა უსაფრთხოება და კონფიდენციალურობა AES-256-GCM ენკრიპციის სტანდარტის გამოყენებით."),
          numberedParagraph("3.3", "უზრუნველყოს ტექნიკური მხარდაჭერა სამუშაო დღეებში 09:00-დან 18:00-მდე."),
          numberedParagraph("3.4", "განახორციელოს სისტემის რეგულარული განახლებები და ფუნქციონალური გაუმჯობესებები."),
          numberedParagraph("3.5", "უზრუნველყოს მონაცემთა სარეზერვო ასლების შექმნა დღეში მინიმუმ 1-ჯერ."),
          numberedParagraph("3.6", "შეატყობინოს დამკვეთს დაგეგმილი ტექნიკური სამუშაოების შესახებ მინიმუმ 24 საათით ადრე."),

          // Article 4
          heading("მუხლი 4. დამკვეთის ვალდებულებები"),
          numberedParagraph("4.1", "დროულად განახორციელოს მომსახურების საფასურის გადახდა დანართი #2-ით განსაზღვრული პირობებით."),
          numberedParagraph("4.2", "უზრუნველყოს სისტემის მომხმარებლების ავტორიზაციის მონაცემების კონფიდენციალურობა."),
          numberedParagraph("4.3", "არ გადასცეს მესამე პირებს სისტემაზე წვდომის უფლება შემსრულებლის წინასწარი წერილობითი თანხმობის გარეშე."),
          numberedParagraph("4.4", "დროულად შეატყობინოს შემსრულებელს სისტემაში აღმოჩენილი შეფერხებების შესახებ."),

          // Article 5
          heading("მუხლი 5. ანგარიშსწორება"),
          numberedParagraph("5.1", "მომსახურების საფასური განისაზღვრება დანართი #2-ის შესაბამისად და გადახდა ხორციელდება ყოველთვიურად, არაუგვიანეს მიმდინარე თვის 10 რიცხვისა."),
          numberedParagraph("5.2", "გადახდის დაგვიანების შემთხვევაში, შემსრულებელი უფლებამოსილია დამკვეთს დაარიცხოს პირგასამტეხლო ვადაგადაცილებული თანხის 0.05% ყოველი ვადაგადაცილებული დღისთვის."),
          numberedParagraph("5.3", "30 კალენდარული დღეზე მეტი ვადაგადაცილების შემთხვევაში, შემსრულებელი უფლებამოსილია შეაჩეროს მომსახურების გაწევა."),

          // Article 6
          heading("მუხლი 6. კონფიდენციალურობა"),
          numberedParagraph("6.1", "მხარეები იღებენ ვალდებულებას, არ გაამჟღავნონ ხელშეკრულების პირობები და მის ფარგლებში მიღებული ინფორმაცია მესამე პირებისთვის."),
          numberedParagraph("6.2", "კონფიდენციალურობის ვალდებულება ძალაშია ხელშეკრულების მოქმედების ვადის განმავლობაში და მისი შეწყვეტიდან 3 (სამი) წლის განმავლობაში."),

          // Article 7
          heading("მუხლი 7. პასუხისმგებლობა"),
          numberedParagraph("7.1", "შემსრულებელი პასუხისმგებელია სისტემის გაუმართაობით გამოწვეულ პირდაპირ ზიანზე, რომლის ოდენობა არ აღემატება დამკვეთის მიერ ბოლო 3 თვის განმავლობაში გადახდილ მომსახურების საფასურს."),
          numberedParagraph("7.2", "შემსრულებელი არ არის პასუხისმგებელი არაპირდაპირ ზიანზე, მიუღებელ შემოსავალზე ან მონაცემთა დაკარგვაზე, რომელიც გამოწვეულია დამკვეთის ბრალით."),
          numberedParagraph("7.3", "ფორსმაჟორის შემთხვევაში, მხარეები თავისუფლდებიან ვალდებულებების შეუსრულებლობის პასუხისმგებლობისგან."),

          // Article 8
          heading("მუხლი 8. ხელშეკრულების შეწყვეტა"),
          numberedParagraph("8.1", "ხელშეკრულება შეიძლება შეწყდეს მხარეთა ურთიერთშეთანხმებით."),
          numberedParagraph("8.2", "ნებისმიერ მხარეს უფლება აქვს ცალმხრივად შეწყვიტოს ხელშეკრულება 30 (ოცდაათი) კალენდარული დღით ადრე წერილობითი შეტყობინებით."),
          numberedParagraph("8.3", "შემსრულებელი უფლებამოსილია შეწყვიტოს ხელშეკრულება დაუყოვნებლივ, თუ დამკვეთი არღვევს გადახდის ვალდებულებას 60 (სამოცი) კალენდარული დღეზე მეტი ვადით."),

          // Article 9
          heading("მუხლი 9. დავების გადაწყვეტა"),
          numberedParagraph("9.1", "მხარეთა შორის წარმოქმნილი დავები გადაწყდება მოლაპარაკების გზით."),
          numberedParagraph("9.2", "მოლაპარაკებით დავის გადაუწყვეტელობის შემთხვევაში, დავა განიხილება საქართველოს კანონმდებლობით განსაზღვრული წესით, საქართველოს სასამართლოში."),

          // Article 10
          heading("მუხლი 10. დანართები"),
          numberedParagraph("10.1", "დანართი #1 - სისტემის მახასიათებლები"),
          numberedParagraph("10.2", "დანართი #2 - ტარიფები და გადახდის პირობები"),
          numberedParagraph("10.3", "დანართი #3 - SLA (მომსახურების დონის შეთანხმება)"),

          // Article 11
          heading("მუხლი 11. დასკვნითი დებულებები"),
          numberedParagraph("11.1", "წინამდებარე ხელშეკრულება შედგენილია ქართულ ენაზე, ორ თანაბარი იურიდიული ძალის მქონე ეგზემპლარად, თითო ეგზემპლარი თითოეული მხარისთვის."),
          numberedParagraph("11.2", "ხელშეკრულებაში ცვლილებების შეტანა დასაშვებია მხოლოდ მხარეთა წერილობითი შეთანხმებით."),
          numberedParagraph("11.3", "ხელშეკრულებით გაუთვალისწინებელ შემთხვევებში მხარეები იხელმძღვანელებენ საქართველოს მოქმედი კანონმდებლობით."),

          // Signatures
          new Paragraph({ spacing: { before: 800 }, children: [] }),
          heading("მხარეთა რეკვიზიტები და ხელმოწერები"),
          new Paragraph({ spacing: { before: 300 }, children: [] }),

          new Paragraph({
            children: [
              new TextRun({ text: "შემსრულებელი:", bold: true, size: 22 }),
            ],
          }),
          new Paragraph({ children: [new TextRun({ text: "შ.პ.ს. \"________________________\"", size: 20 })] }),
          new Paragraph({ children: [new TextRun({ text: "ს/კ: _______________", size: 20 })] }),
          new Paragraph({ children: [new TextRun({ text: "იურიდიული მისამართი: ________________________", size: 20 })] }),
          new Paragraph({ children: [new TextRun({ text: "საბანკო რეკვიზიტები: ________________________", size: 20 })] }),
          new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "ხელმოწერა: ___________________", size: 20 })] }),

          new Paragraph({ spacing: { before: 400 }, children: [] }),

          new Paragraph({
            children: [
              new TextRun({ text: "დამკვეთი:", bold: true, size: 22 }),
            ],
          }),
          new Paragraph({ children: [new TextRun({ text: "შ.პ.ს. \"________________________\"", size: 20 })] }),
          new Paragraph({ children: [new TextRun({ text: "ს/კ: _______________", size: 20 })] }),
          new Paragraph({ children: [new TextRun({ text: "იურიდიული მისამართი: ________________________", size: 20 })] }),
          new Paragraph({ children: [new TextRun({ text: "საბანკო რეკვიზიტები: ________________________", size: 20 })] }),
          new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "ხელმოწერა: ___________________", size: 20 })] }),
        ],
      },
    ],
  });

  Packer.toBlob(doc).then((blob) => {
    saveAs(blob, `TalentOS_Master_Agreement_${contractNumber}.docx`);
  });
};

function heading(text: string): Paragraph {
  return new Paragraph({
    spacing: { before: 400, after: 200 },
    children: [new TextRun({ text, bold: true, size: 24 })],
  });
}

function numberedParagraph(num: string, text: string): Paragraph {
  return new Paragraph({
    spacing: { after: 100 },
    children: [
      new TextRun({ text: `${num}. `, bold: true, size: 22 }),
      new TextRun({ text, size: 22 }),
    ],
  });
}
