import { Document, Packer, Paragraph, Table, TableRow, TableCell, TextRun, ImageRun, WidthType, AlignmentType, BorderStyle } from "docx";
import { saveAs } from "file-saver";
import signatureImg from "@/assets/certificate-signature.png";
import stampImg from "@/assets/certificate-stamp.png";

const borders = {
  top: { style: BorderStyle.SINGLE, size: 1, color: "1a7a6d" },
  bottom: { style: BorderStyle.SINGLE, size: 1, color: "1a7a6d" },
  left: { style: BorderStyle.SINGLE, size: 1, color: "1a7a6d" },
  right: { style: BorderStyle.SINGLE, size: 1, color: "1a7a6d" },
};

const noBorders = {
  top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
  bottom: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
  left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
  right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
};

function hCell(text: string, w: number): TableCell {
  return new TableCell({ borders, width: { size: w, type: WidthType.DXA }, shading: { fill: "1a7a6d" }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text, bold: true, size: 20, color: "FFFFFF" })] })] });
}
function tCell(text: string, w: number, bold = false): TableCell {
  return new TableCell({ borders, width: { size: w, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text, bold, size: 20 })] })] });
}
function checkCell(text: string, w: number): TableCell {
  return new TableCell({ borders, width: { size: w, type: WidthType.DXA }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "✓ " + text, size: 20, color: "1a7a6d", bold: true })] })] });
}

export const exportSecurityCertificate = async (
  companyName: string = "________________________",
  certificateNumber: string = `SC-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000)}`,
  issueDate: string = new Date().toLocaleDateString('ka-GE'),
  validUntil: string = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toLocaleDateString('ka-GE')
) => {
  // Fetch images as ArrayBuffer
  const [sigResponse, stampResponse] = await Promise.all([
    fetch(signatureImg).then(r => r.arrayBuffer()),
    fetch(stampImg).then(r => r.arrayBuffer()),
  ]);

  const doc = new Document({
    sections: [{
      children: [
        // Header - Issued by Lovable
        center("Lovable", 36, true, "1a7a6d"),
        center("Cloud Platform Security", 20, false, "666666"),
        new Paragraph({ spacing: { before: 200 }, children: [] }),

        // Certificate Title
        separator(),
        new Paragraph({ spacing: { before: 300 }, children: [] }),
        center("უსაფრთხოების შესაბამისობის სერტიფიკატი", 32, true),
        center("SECURITY COMPLIANCE CERTIFICATE", 22, false, "666666"),
        new Paragraph({ spacing: { before: 100 }, children: [] }),
        center(`No: ${certificateNumber}`, 22, true, "1a7a6d"),
        new Paragraph({ spacing: { before: 100 }, children: [] }),
        center("გაცემულია Lovable, Inc.-ის მიერ", 20, false, "666666"),
        new Paragraph({ spacing: { before: 100 }, children: [] }),
        separator(),

        // Certificate Details
        new Paragraph({ spacing: { before: 300 }, children: [] }),
        new Table({
          rows: [
            infoRow("გაცემის თარიღი:", issueDate),
            infoRow("მოქმედების ვადა:", validUntil),
            infoRow("კლიენტი:", companyName),
            infoRow("პლატფორმა:", "TalentOS v2.0"),
            infoRow("გამცემი:", "Lovable, Inc."),
            infoRow("ჰოსტინგი:", "Lovable Cloud (EU Region)"),
          ],
          width: { size: 10000, type: WidthType.DXA },
        }),

        // Main body
        new Paragraph({ spacing: { before: 400 }, children: [] }),
        p("წინამდებარე სერტიფიკატი ადასტურებს, რომ TalentOS პლატფორმა აკმაყოფილებს ინფორმაციული უსაფრთხოების საერთაშორისო და ადგილობრივ სტანდარტებს და უზრუნველყოფს კლიენტის მონაცემების დაცვას შემდეგი ტექნიკური და ორგანიზაციული ზომებით:"),

        // Section 1 - Encryption
        h("1. მონაცემთა დაშიფვრა (Encryption)"),
        new Table({
          rows: [
            new TableRow({ children: [hCell("კომპონენტი", 4000), hCell("სტანდარტი", 3000), hCell("სტატუსი", 3000)] }),
            new TableRow({ children: [tCell("მონაცემთა დაშიფვრა მოსვენებისას (At Rest)", 4000), tCell("AES-256-GCM", 3000), checkCell("აქტიური", 3000)] }),
            new TableRow({ children: [tCell("მონაცემთა დაშიფვრა ტრანზიტში (In Transit)", 4000), tCell("TLS 1.3", 3000), checkCell("აქტიური", 3000)] }),
            new TableRow({ children: [tCell("სენსიტიური ველების E2E ენკრიპცია", 4000), tCell("AES-256-GCM", 3000), checkCell("აქტიური", 3000)] }),
            new TableRow({ children: [tCell("Backup ენკრიპცია", 4000), tCell("AES-256", 3000), checkCell("აქტიური", 3000)] }),
          ],
          width: { size: 10000, type: WidthType.DXA },
        }),

        // Section 2 - Access Control
        h("2. წვდომის კონტროლი (Access Control)"),
        new Table({
          rows: [
            new TableRow({ children: [hCell("მექანიზმი", 5000), hCell("სტატუსი", 5000)] }),
            new TableRow({ children: [tCell("Row Level Security (RLS) - 36+ პოლიტიკა", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("RBAC (Role-Based Access Control)", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("Custom Roles & Permissions", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("სესიის Timeout და ავტომატური გამოსვლა", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("ანგარიშის დაბლოკვა (Account Lockout)", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("პაროლის სიმტკიცის ვალიდაცია", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("Signed URLs პრივატული ფაილებისთვის", 5000), checkCell("აქტიური", 5000)] }),
          ],
          width: { size: 10000, type: WidthType.DXA },
        }),

        // Section 3 - Monitoring
        h("3. მონიტორინგი და აუდიტი (Monitoring & Audit)"),
        new Table({
          rows: [
            new TableRow({ children: [hCell("სისტემა", 5000), hCell("სტატუსი", 5000)] }),
            new TableRow({ children: [tCell("IDS - შეღწევის აღმოჩენის სისტემა (SQLi, XSS, Prompt Injection)", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("ლოგინის ანომალიების დეტექცია (IP/Geo)", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("Audit Log - ყველა მოქმედების ჩანაწერი (12+ ტიპი)", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("სენსიტიურ მონაცემებზე წვდომის ლოგირება", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("Rate Limiting (Edge Functions)", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("User Activity Monitoring", 5000), checkCell("აქტიური", 5000)] }),
          ],
          width: { size: 10000, type: WidthType.DXA },
        }),

        // Section 4 - Infrastructure
        h("4. ინფრასტრუქტურის უსაფრთხოება"),
        new Table({
          rows: [
            new TableRow({ children: [hCell("კომპონენტი", 5000), hCell("სტატუსი", 5000)] }),
            new TableRow({ children: [tCell("HSTS (HTTP Strict Transport Security)", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("CSP (Content Security Policy)", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("Server Fingerprint Removal", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("SameSite=Strict Cookies", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("Production Console/Debug Strip", 5000), checkCell("აქტიური", 5000)] }),
            new TableRow({ children: [tCell("Vulnerability Disclosure Policy (RFC 9116)", 5000), checkCell("აქტიური", 5000)] }),
          ],
          width: { size: 10000, type: WidthType.DXA },
        }),

        // Section 5 - Compliance
        h("5. შესაბამისობა (Compliance)"),
        new Table({
          rows: [
            new TableRow({ children: [hCell("სტანდარტი / რეგულაცია", 5000), hCell("სტატუსი", 5000)] }),
            new TableRow({ children: [tCell("GDPR (General Data Protection Regulation)", 5000), checkCell("შესაბამისი", 5000)] }),
            new TableRow({ children: [tCell("ISO/IEC 27001 - ინფორმაციული უსაფრთხოება", 5000), checkCell("შესაბამისი", 5000)] }),
            new TableRow({ children: [tCell("ISO/IEC 27018 - ღრუბლოვანი PII დაცვა", 5000), checkCell("შესაბამისი", 5000)] }),
            new TableRow({ children: [tCell("საქართველოს კანონი \"პერსონალურ მონაცემთა დაცვის შესახებ\"", 5000), checkCell("შესაბამისი", 5000)] }),
          ],
          width: { size: 10000, type: WidthType.DXA },
        }),

        // Section 6 - Data Protection
        h("6. მონაცემთა დაცვის ზომები"),
        bullet("სენსიტიური მონაცემების (პირადი ნომერი, ხელფასი, საბანკო რეკვიზიტები) End-to-End ენკრიპცია"),
        bullet("მონაცემთა ავტომატური სარეზერვო ასლები (ყოველდღიური)"),
        bullet("Soft Delete მექანიზმი - 30 დღიანი აღდგენის პერიოდი"),
        bullet("მონაცემთა დამუშავების რეესტრი (Data Processing Register)"),
        bullet("მონაცემთა სუბიექტის მოთხოვნების (DSR) მართვის სისტემა"),
        bullet("მონაცემთა შენახვის პოლიტიკა (Data Retention Policy)"),
        bullet("ინციდენტების შეტყობინების სისტემა (24 საათი)"),
        bullet("დაშიფვრის წვდომის აუდიტის ლოგი"),

        // Section 7 - Privacy Features
        h("7. კონფიდენციალურობის ფუნქციები"),
        bullet("Masked Views - სენსიტიური ველების ნიღბვა როლის მიხედვით"),
        bullet("ანონიმური უკუკავშირის სისტემა (ანონიმურობის გარანტია HR-ისთვისაც)"),
        bullet("სამედიცინო მონაცემების დაფარვა მენეჯერებისთვის"),
        bullet("პრივატული ფაილების Signed URL წვდომა (დროში შეზღუდული)"),
        bullet("მომხმარებლის მონაცემები არ გამოიყენება AI მოდელების ტრენინგისთვის"),

        // Disclaimer
        new Paragraph({ spacing: { before: 400 }, children: [] }),
        separator(),
        new Paragraph({ spacing: { before: 200 }, children: [] }),
        p("წინამდებარე სერტიფიკატი გაცემულია Lovable, Inc.-ის მიერ TalentOS პლატფორმის უსაფრთხოების აუდიტის შედეგების საფუძველზე. სერტიფიკატი მოქმედებს გაცემის თარიღიდან 12 თვის განმავლობაში."),
        
        new Paragraph({ spacing: { before: 100 }, children: [
          new TextRun({ text: "უსაფრთხოების საკონტაქტო: ", bold: true, size: 20 }),
          new TextRun({ text: "security@lovable.dev", size: 20, color: "1a7a6d" }),
        ]}),

        new Paragraph({ spacing: { before: 400 }, children: [] }),
        new Paragraph({ children: [new TextRun({ text: "გამცემი:", bold: true, size: 22 })] }),
        new Paragraph({ spacing: { before: 100 }, children: [new TextRun({ text: "Lovable, Inc. - Security & Compliance Team", size: 20 })] }),
        new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "ხელმოწერა:", bold: true, size: 20 })] }),
        new Paragraph({ spacing: { before: 100 }, children: [
          new ImageRun({ type: "png", data: sigResponse, transformation: { width: 200, height: 80 } }),
        ]}),
        new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "ბეჭედი:", bold: true, size: 20 })] }),
        new Paragraph({ spacing: { before: 100 }, children: [
          new ImageRun({ type: "png", data: stampResponse, transformation: { width: 150, height: 150 } }),
        ]}),
      ],
    }],
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `TalentOS_Security_Certificate_${certificateNumber}.docx`);
};

function center(text: string, size: number, bold = false, color = "000000"): Paragraph {
  return new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text, bold, size, color })] });
}
function h(text: string): Paragraph {
  return new Paragraph({ spacing: { before: 400, after: 200 }, children: [new TextRun({ text, bold: true, size: 24, color: "1a7a6d" })] });
}
function p(text: string): Paragraph {
  return new Paragraph({ spacing: { after: 150 }, children: [new TextRun({ text, size: 20 })] });
}
function bullet(text: string): Paragraph {
  return new Paragraph({ spacing: { after: 60 }, indent: { left: 360 }, children: [new TextRun({ text: `✓  ${text}`, size: 20 })] });
}
function separator(): Paragraph {
  return new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", color: "1a7a6d", size: 16 })] });
}
function infoRow(label: string, value: string): TableRow {
  return new TableRow({
    children: [
      new TableCell({ borders: noBorders, width: { size: 3000, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: label, bold: true, size: 22 })] })] }),
      new TableCell({ borders: noBorders, width: { size: 7000, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: value, size: 22 })] })] }),
    ],
  });
}
