import { Document, Packer, Paragraph, TextRun, AlignmentType } from "docx";
import { saveAs } from "file-saver";

export const exportNDA = (contractNumber: string = "____-__", date: string = new Date().toLocaleDateString('ka-GE')) => {
  const doc = new Document({
    sections: [{
      children: [
        new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "კონფიდენციალური", color: "CC0000", size: 20, italics: true })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 300, after: 100 }, children: [new TextRun({ text: "კონფიდენციალურობის ხელშეკრულება", bold: true, size: 32 })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 100 }, children: [new TextRun({ text: "(Non-Disclosure Agreement - NDA)", size: 24, italics: true })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: `გენერალური ხელშეკრულება No${contractNumber}-თან დაკავშირებით`, size: 22 })] }),
        new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: "ქ. თბილისი", size: 22 }), new TextRun({ text: `\t\t\t\t\t\t\t\t${date}`, size: 22 })] }),

        p("წინამდებარე კონფიდენციალურობის ხელშეკრულება (შემდგომში - \"NDA\") იდება გენერალური ხელშეკრულების No" + contractNumber + " მხარეებს შორის და არეგულირებს კონფიდენციალური ინფორმაციის დაცვის წესს."),

        h("მუხლი 1. კონფიდენციალური ინფორმაციის განსაზღვრება"),
        n("1.1", "კონფიდენციალურ ინფორმაციას მიეკუთვნება ნებისმიერი ინფორმაცია, რომელიც ერთი მხარის მიერ გადაეცემა მეორე მხარეს ხელშეკრულების ფარგლებში, მათ შორის, მაგრამ არამარტო:"),
        bullet("სისტემის ტექნიკური დოკუმენტაცია და არქიტექტურა"),
        bullet("კომერციული პირობები, ფასები და ფასდაკლებები"),
        bullet("თანამშრომელთა პერსონალური მონაცემები"),
        bullet("ბიზნეს-პროცესები და ორგანიზაციული სტრუქტურა"),
        bullet("ფინანსური ინფორმაცია და ანგარიშგება"),
        bullet("API კლავიშები, პაროლები და წვდომის მონაცემები"),
        bullet("სისტემის საწყისი კოდი და ალგორითმები"),
        n("1.2", "კონფიდენციალურ ინფორმაციას არ მიეკუთვნება ინფორმაცია, რომელიც:"),
        bullet("საჯაროდ ხელმისაწვდომია მიმღები მხარის ბრალის გარეშე"),
        bullet("მიმღებ მხარეს ცნობილი იყო ხელშეკრულების დადებამდე"),
        bullet("მიმღებმა მხარემ მიიღო მესამე პირისგან კანონიერად"),

        h("მუხლი 2. ვალდებულებები"),
        n("2.1", "მხარეები იღებენ ვალდებულებას:"),
        bullet("არ გაამჟღავნონ კონფიდენციალური ინფორმაცია მესამე პირებისთვის"),
        bullet("გამოიყენონ კონფიდენციალური ინფორმაცია მხოლოდ ხელშეკრულების მიზნებისთვის"),
        bullet("დაიცვან კონფიდენციალური ინფორმაცია იმავე ხარისხით, როგორც საკუთარ კონფიდენციალურ ინფორმაციას"),
        bullet("შეზღუდონ წვდომა მხოლოდ იმ პირებზე, რომლებსაც ეს ინფორმაცია ესაჭიროებათ სამუშაო მოვალეობების შესასრულებლად"),
        n("2.2", "მხარეები ვალდებულნი არიან უზრუნველყონ, რომ მათმა თანამშრომლებმაც დაიცვან კონფიდენციალურობის ვალდებულება."),

        h("მუხლი 3. კონფიდენციალურობის ვადა"),
        n("3.1", "კონფიდენციალურობის ვალდებულება ძალაშია ხელშეკრულების მოქმედების მთელ პერიოდში."),
        n("3.2", "ხელშეკრულების შეწყვეტის შემდეგ, კონფიდენციალურობის ვალდებულება გრძელდება 3 (სამი) წლის განმავლობაში."),
        n("3.3", "სავაჭრო საიდუმლოებისა და პერსონალური მონაცემების მიმართ კონფიდენციალურობის ვალდებულება უვადოა."),

        h("მუხლი 4. გამონაკლისები"),
        n("4.1", "კონფიდენციალური ინფორმაციის გამჟღავნება დასაშვებია:"),
        bullet("სასამართლოს ან კანონით უფლებამოსილი ორგანოს მოთხოვნით"),
        bullet("მეორე მხარის წინასწარი წერილობითი თანხმობით"),
        n("4.2", "იძულებითი გამჟღავნების შემთხვევაში, მხარე ვალდებულია დაუყოვნებლივ შეატყობინოს მეორე მხარეს და გაამჟღავნოს მხოლოდ მინიმალურად საჭირო ინფორმაცია."),

        h("მუხლი 5. ინფორმაციის დაბრუნება"),
        n("5.1", "ხელშეკრულების შეწყვეტისას, თითოეული მხარე ვალდებულია:"),
        bullet("დაუბრუნოს მეორე მხარეს ყველა კონფიდენციალური მასალა"),
        bullet("წაშალოს ელექტრონული ასლები"),
        bullet("წერილობით დაადასტუროს ინფორმაციის წაშლა/დაბრუნება"),

        h("მუხლი 6. პასუხისმგებლობა"),
        n("6.1", "კონფიდენციალურობის დარღვევისას, დამრღვევი მხარე ვალდებულია აანაზღაუროს მეორე მხარისთვის მიყენებული ზიანი სრული მოცულობით."),
        n("6.2", "კონფიდენციალურობის განზრახ დარღვევის შემთხვევაში, დამრღვევი მხარე ასევე იხდის პირგასამტეხლოს ₾10,000 (ათი ათასი ლარი) ოდენობით."),

        h("მუხლი 7. მოქმედი კანონმდებლობა"),
        n("7.1", "წინამდებარე NDA რეგულირდება საქართველოს კანონმდებლობით."),
        n("7.2", "დავები წყდება საქართველოს სასამართლოში."),

        // Signatures
        new Paragraph({ spacing: { before: 600 }, children: [] }),
        new Paragraph({ children: [new TextRun({ text: "მხარე 1 (შემსრულებელი):", bold: true, size: 20 })] }),
        new Paragraph({ children: [new TextRun({ text: "კომპანია: ________________________", size: 20 })] }),
        new Paragraph({ children: [new TextRun({ text: "წარმომადგენელი: ________________________", size: 20 })] }),
        new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "ხელმოწერა: ___________________", size: 20 })] }),
        new Paragraph({ spacing: { before: 400 }, children: [new TextRun({ text: "მხარე 2 (დამკვეთი):", bold: true, size: 20 })] }),
        new Paragraph({ children: [new TextRun({ text: "კომპანია: ________________________", size: 20 })] }),
        new Paragraph({ children: [new TextRun({ text: "წარმომადგენელი: ________________________", size: 20 })] }),
        new Paragraph({ spacing: { before: 200 }, children: [new TextRun({ text: "ხელმოწერა: ___________________", size: 20 })] }),
      ],
    }],
  });

  Packer.toBlob(doc).then((blob) => {
    saveAs(blob, `TalentOS_NDA_${contractNumber}.docx`);
  });
};

function h(text: string): Paragraph {
  return new Paragraph({ spacing: { before: 400, after: 200 }, children: [new TextRun({ text, bold: true, size: 24 })] });
}
function n(num: string, text: string): Paragraph {
  return new Paragraph({ spacing: { after: 100 }, children: [new TextRun({ text: `${num}. `, bold: true, size: 22 }), new TextRun({ text, size: 22 })] });
}
function p(text: string): Paragraph {
  return new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text, size: 22 })] });
}
function bullet(text: string): Paragraph {
  return new Paragraph({ spacing: { after: 60 }, indent: { left: 720 }, children: [new TextRun({ text: `• ${text}`, size: 20 })] });
}
