import jsPDF from 'jspdf';
import 'jspdf-autotable';

export const exportFinancialDocToPDF = async () => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  const contentWidth = pageWidth - (margin * 2);
  let yPosition = margin;

  // Colors - Teal/Cyan theme
  const primaryColor = [20, 184, 166]; // teal-500
  const secondaryColor = [6, 182, 212]; // cyan-500
  const textColor = [31, 41, 55]; // gray-800
  const lightGray = [243, 244, 246]; // gray-100

  // Helper function to add new page if needed
  const checkAddPage = (requiredSpace: number) => {
    if (yPosition + requiredSpace > pageHeight - margin) {
      doc.addPage();
      yPosition = margin;
      return true;
    }
    return false;
  };

  // Helper function to add text with word wrap
  const addWrappedText = (text: string, fontSize: number, fontStyle: 'normal' | 'bold' = 'normal', color = textColor) => {
    doc.setFontSize(fontSize);
    doc.setFont('helvetica', fontStyle);
    doc.setTextColor(color[0], color[1], color[2]);
    
    const lines = doc.splitTextToSize(text, contentWidth);
    const lineHeight = fontSize * 0.5;
    
    checkAddPage(lines.length * lineHeight);
    
    lines.forEach((line: string) => {
      doc.text(line, margin, yPosition);
      yPosition += lineHeight;
    });
  };

  // Cover Page
  doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.rect(0, 0, pageWidth, 80, 'F');
  
  // Title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(28);
  doc.setFont('helvetica', 'bold');
  doc.text('ფინანსური სისტემის', pageWidth / 2, 35, { align: 'center' });
  doc.text('დოკუმენტაცია', pageWidth / 2, 50, { align: 'center' });
  
  // Subtitle
  doc.setFontSize(14);
  doc.setFont('helvetica', 'normal');
  doc.text('HR & CRM Pro System', pageWidth / 2, 65, { align: 'center' });

  // Date
  doc.setFontSize(10);
  const today = new Date().toLocaleDateString('ka-GE');
  doc.text(`გენერირების თარიღი: ${today}`, pageWidth / 2, 75, { align: 'center' });

  yPosition = 100;

  // Add decorative line
  doc.setDrawColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.setLineWidth(0.5);
  doc.line(margin, yPosition, pageWidth - margin, yPosition);
  yPosition += 15;

  // Content sections
  const sections = [
    {
      title: 'ზოგადი მიმოხილვა',
      content: 'ფინანსური სისტემა მოიცავს ხელფასების დარიცხვას, ბიუჯეტის დაგეგმვას, ხარჯების აღრიცხვას, ზეგანაკვეთური სამუშაოს აღრიცხვას და კომპენსაციების მართვას. სისტემა ინტეგრირებულია დასწრების აღრიცხვასთან, შვებულებებთან და სამუშაო გრაფიკებთან.'
    },
    {
      title: 'მთავარი კომპონენტები',
      items: [
        'Payroll (ხელფასები) - ყოველთვიური ხელფასების დარიცხვა და გადახდა',
        'Budget Planning (ბიუჯეტის დაგეგმვა) - დეპარტამენტების ბიუჯეტის დაგეგმვა',
        'Budget Expenses (ხარჯები) - ხარჯების აღრიცხვა და ანალიზი',
        'Overtime (ზეგანაკვეთური) - ზეგანაკვეთური საათების აღრიცხვა და გადახდა',
        'Compensation (კომპენსაცია) - ბონუსები და დამატებითი კომპენსაციები',
        'Reports (ანგარიშები) - ფინანსური ანგარიშგება და ანალიტიკა'
      ]
    },
    {
      title: 'ხელფასების გამოთვლა',
      content: 'წმინდა ხელფასი = საბაზო ხელფასი + ბონუსები + დღესასწაულების ზეგანაკვეთური - დაკავებები - პენსია',
      items: [
        'საბაზო ხელფასი - თანამშრომლის ხელშეკრულებით განსაზღვრული თანხა',
        'ბონუსები - ხელით შეყვანილი ბონუსები და წახალისება',
        'დღესასწაულების ზეგანაკვეთური - საჯარო დღესასწაულებზე მუშაობის ანაზღაურება (x2)',
        'დაკავებები - ჯარიმები, სესხის დაფარვა და სხვა დაკავებები',
        'პენსიის შენატანი - 2% საბაზო ხელფასიდან'
      ]
    },
    {
      title: 'ზეგანაკვეთური მულტიპლიკატორები',
      items: [
        'სამუშაო დღეები - x1.5 (საათობრივი განაკვეთის 150%)',
        'შაბათ-კვირა - x2.0 (საათობრივი განაკვეთის 200%)',
        'საჯარო დღესასწაულები - x2.0 (საათობრივი განაკვეთის 200%)',
        'ღამის ცვლები (22:00-06:00) - დამატებითი კომპენსაცია'
      ]
    },
    {
      title: 'ბიუჯეტის კატეგორიები',
      items: [
        'Salaries - ხელფასები და დაკავშირებული ხარჯები',
        'Benefits - თანამშრომელთა შეღავათები და სოციალური პაკეტი',
        'Training - ტრენინგები და პროფესიული განვითარება',
        'Equipment - აღჭურვილობა და ტექნიკა',
        'Marketing - მარკეტინგული აქტივობები',
        'Operations - ოპერაციული ხარჯები',
        'Other - სხვა დანარჩენი კატეგორიები'
      ]
    },
    {
      title: 'მონაცემთა წყაროები',
      items: [
        'employees - თანამშრომლების ინფორმაცია და ხელფასები',
        'payroll - ხელფასის დარიცხვები და გადახდები',
        'budget_plans - ბიუჯეტის გეგმები და პროგნოზები',
        'budget_expenses - ფაქტობრივი ხარჯები',
        'overtime_requests - ზეგანაკვეთური სამუშაოს მოთხოვნები',
        'compensation - კომპენსაციები და ბონუსები',
        'public_holidays - საჯარო დღესასწაულები',
        'attendance - დასწრების აღრიცხვა'
      ]
    },
    {
      title: 'ფინანსური ანგარიშები',
      items: [
        'ხელფასების ანგარიში - ყოველთვიური ხელფასების დეტალური ანალიზი',
        'ზეგანაკვეთურის ანგარიში - ზეგანაკვეთური საათების სტატისტიკა',
        'ბიუჯეტის ანგარიში - დაგეგმილი vs ფაქტობრივი ხარჯები',
        'დეპარტამენტული ანალიზი - ხარჯების განაწილება დეპარტამენტების მიხედვით',
        'დღესასწაულების ზეგანაკვეთური - საჯარო დღესასწაულებზე მუშაობის ანგარიში',
        'სრული ფინანსური რეპორტი - ყოველთვიური კონსოლიდირებული ანგარიში'
      ]
    },
    {
      title: 'ავტომატიზაცია',
      items: [
        'დღესასწაულების ავტომატური ამოცნობა - public_holidays ცხრილიდან',
        'ზეგანაკვეთურის ავტომატური დარიცხვა - overtime_requests-ის საფუძველზე',
        'პენსიის ავტომატური გამოთვლა - 2% საბაზო ხელფასიდან',
        'ბიუჯეტის ვარიანსის ავტომატური გამოთვლა - დაგეგმილი vs ფაქტობრივი',
        'Real-time სტატისტიკა - Dashboard-ზე ცოცხალი მონაცემები'
      ]
    }
  ];

  // Render sections
  sections.forEach((section, index) => {
    checkAddPage(30);

    // Section title with background
    doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
    doc.roundedRect(margin, yPosition - 5, contentWidth, 12, 2, 2, 'F');
    
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text(`${index + 1}. ${section.title}`, margin + 3, yPosition + 3);
    yPosition += 15;

    // Section content
    if (section.content) {
      addWrappedText(section.content, 10, 'normal');
      yPosition += 5;
    }

    // Section items
    if (section.items) {
      section.items.forEach((item) => {
        checkAddPage(10);
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(textColor[0], textColor[1], textColor[2]);
        
        // Bullet point
        doc.setFillColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
        doc.circle(margin + 2, yPosition - 1, 1, 'F');
        
        const lines = doc.splitTextToSize(item, contentWidth - 10);
        lines.forEach((line: string) => {
          doc.text(line, margin + 6, yPosition);
          yPosition += 5;
        });
      });
    }

    yPosition += 5;
  });

  // Footer on last page
  checkAddPage(30);
  yPosition = pageHeight - 30;
  
  doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.setLineWidth(0.5);
  doc.line(margin, yPosition, pageWidth - margin, yPosition);
  yPosition += 8;

  doc.setFontSize(10);
  doc.setFont('helvetica', 'italic');
  doc.setTextColor(textColor[0], textColor[1], textColor[2]);
  doc.text('HR & CRM Pro - ფინანსური სისტემა', pageWidth / 2, yPosition, { align: 'center' });
  yPosition += 6;
  doc.setFontSize(8);
  doc.text('© 2024-2025 All Rights Reserved', pageWidth / 2, yPosition, { align: 'center' });

  // Add page numbers
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text(
      `გვერდი ${i} / ${pageCount}`,
      pageWidth - margin,
      pageHeight - 10,
      { align: 'right' }
    );
  }

  // Save PDF
  doc.save(`ფინანსური-დოკუმენტაცია-${new Date().toLocaleDateString('ka-GE')}.pdf`);
};
