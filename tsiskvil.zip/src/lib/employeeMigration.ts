import Papa from 'papaparse';
import type { ImportedEmployee } from './importFromExcel';

export const migrationFields = {
  full_name: ['სახელი და გვარი', 'სახელი გვარი', 'Full Name', 'Employee Name', 'თანამშრომელი'],
  email: ['ელ. ფოსტა', 'ელ.ფოსტა', 'Email', 'E-mail', 'Work Email'],
  position: ['პოზიცია', 'თანამდებობა', 'Position', 'Job Title'],
  department: ['დეპარტამენტი', 'განყოფილება', 'Department'],
  phone: ['ტელეფონი', 'მობილური', 'Phone', 'Mobile'],
  salary: ['ხელფასი', 'Salary', 'Gross Salary', 'დარიცხული ხელფასი'],
  hire_date: ['მოსვლის თარიღი', 'დაქირავების თარიღი', 'Hire Date', 'Start Date'],
  gender: ['სქესი', 'Gender', 'Sex'],
  date_of_birth: ['დაბადების თარიღი', 'Date of Birth', 'Birth Date'],
  status: ['სტატუსი', 'Status'],
} as const;
export type MigrationField = keyof typeof migrationFields;
export type MigrationMapping = Partial<Record<MigrationField, number>>;
export interface MigrationSheet { name: string; headers: string[]; rows: string[][] }
export interface MigrationRow { row: number; employee: ImportedEmployee; errors: string[] }
const normalize = (s: string) => s.toLowerCase().replace(/[\s._-]+/g, '');
export function suggestMapping(headers: string[]): MigrationMapping {
  const mapping: MigrationMapping = {};
  for (const [field, aliases] of Object.entries(migrationFields)) {
    const index = headers.findIndex(h => aliases.some(a => normalize(a) === normalize(h)));
    if (index >= 0) mapping[field as MigrationField] = index;
  }
  return mapping;
}
export function parseMigrationCSV(text: string): MigrationSheet {
  const parsed = Papa.parse<string[]>(text.replace(/^\uFEFF/, ''), { skipEmptyLines: 'greedy' });
  if (parsed.errors.length) throw new Error('invalid_file');
  const [headers, ...rows] = parsed.data;
  if (!headers?.length || !rows.length) throw new Error('empty_file');
  if (rows.some(row => row.length !== headers.length)) throw new Error('invalid_file');
  return { name: 'CSV', headers: headers.map(h => h.trim()), rows };
}
export async function readMigrationFile(file: File): Promise<MigrationSheet[]> {
  if (file.size > 10 * 1024 * 1024) throw new Error('file_too_large');
  if (/\.csv$/i.test(file.name)) return [parseMigrationCSV(await file.text())];
  if (!/\.xlsx$/i.test(file.name)) throw new Error('unsupported_file');
  const { default: ExcelJS } = await import('exceljs');
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(await file.arrayBuffer());
  return workbook.worksheets.filter(ws => ws.rowCount > 1).map(ws => {
    const width = ws.getRow(1).cellCount;
    const cellText = (row: number, col: number) => {
      const cell = ws.getCell(row, col);
      if (cell.value instanceof Date) return cell.value.toISOString().slice(0, 10);
      return cell.text.trim();
    };
    const headers = Array.from({ length: width }, (_, c) => cellText(1, c + 1));
    const rows: string[][] = [];
    for (let r = 2; r <= ws.rowCount; r++) {
      const row = Array.from({ length: width }, (_, c) => cellText(r, c + 1));
      if (row.some(Boolean)) rows.push(row);
    }
    return { name: ws.name, headers, rows };
  });
}
function dateValue(value: string): string | undefined {
  if (!value) return undefined;
  let result = value;
  const local = /^(\d{2})[./](\d{2})[./](\d{4})$/.exec(value);
  if (local) result = `${local[3]}-${local[2]}-${local[1]}`;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(result)) return 'invalid';
  const date = new Date(`${result}T00:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === result ? result : 'invalid';
}
export function buildMigrationRows(sheet: MigrationSheet, mapping: MigrationMapping, existingEmails: string[] = []): MigrationRow[] {
  const emails = new Set(existingEmails.map(e => e.trim().toLowerCase()));
  return sheet.rows.map((row, i) => {
    const value = (key: MigrationField) => {
      const col = mapping[key];
      return col === undefined ? '' : (row[col] || '').trim();
    };
    const errors: string[] = [];
    const email = value('email').toLowerCase();
    const full_name = value('full_name');
    const position = value('position');
    if (full_name.length < 2) errors.push('full_name');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('email');
    if (emails.has(email)) errors.push('duplicate');
    if (email) emails.add(email);
    if (position.length < 2) errors.push('position');
    const rawSalary = value('salary').replace(/\s/g, '').replace(',', '.');
    const salary = rawSalary ? Number(rawSalary) : undefined;
    if (salary !== undefined && (!Number.isFinite(salary) || salary < 0)) errors.push('salary');
    const phone = value('phone');
    if (phone && !/^[+\d\s()-]{9,20}$/.test(phone)) errors.push('phone');
    const hire_date = dateValue(value('hire_date'));
    const date_of_birth = dateValue(value('date_of_birth'));
    if (hire_date === 'invalid') errors.push('hire_date');
    if (date_of_birth === 'invalid') errors.push('date_of_birth');
    const rawGender = value('gender').toLowerCase();
    const gender = ['male', 'მამრობითი', 'კაცი'].includes(rawGender) ? 'male' : ['female', 'მდედრობითი', 'ქალი'].includes(rawGender) ? 'female' : undefined;
    if (rawGender && !gender) errors.push('gender');
    const rawStatus = value('status').toLowerCase();
    const status = !rawStatus || ['active', 'აქტიური'].includes(rawStatus) ? 'active' : ['inactive', 'არააქტიური', 'terminated', 'დათხოვნილი'].includes(rawStatus) ? 'inactive' : undefined;
    if (!status) errors.push('status');
    return { row: i + 2, errors, employee: { full_name, email, position, department: value('department') || undefined, phone: phone || undefined, salary, hire_date, date_of_birth, gender, status } };
  });
}