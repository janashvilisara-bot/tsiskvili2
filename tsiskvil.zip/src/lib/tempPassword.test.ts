import { describe, it, expect } from "vitest";
import { resolveRegistrationPassword, generateTempPassword } from "./tempPassword";

describe("registration password", () => {
  it("empty field generates a strong 12-char password", () => {
    const { password } = resolveRegistrationPassword("");
    expect(password).toHaveLength(12);
    expect(password).toMatch(/[a-z]/);
    expect(password).toMatch(/[A-Z]/);
    expect(password).toMatch(/\d/);
  });
  it("rejects 1111", () => {
    expect(resolveRegistrationPassword("1111").error).toBeTruthy();
  });
  it("accepts a valid custom password", () => {
    expect(resolveRegistrationPassword("Tbilisi2026")).toEqual({ password: "Tbilisi2026" });
  });
  it("generated passwords differ", () => {
    expect(generateTempPassword()).not.toBe(generateTempPassword());
  });
});
