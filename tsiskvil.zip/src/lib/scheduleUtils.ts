/**
 * Get the Georgian label for a schedule type
 */
export const getScheduleTypeLabel = (type: string): string => {
  switch (type) {
    case 'fixed_1':
      return 'ფიქსირებული გრაფიკი I';
    case 'fixed_2':
      return 'ფიქსირებული გრაფიკი II';
    case 'timesheet':
      return 'საათობრივი გრაფიკი';
    case 'shifts':
      return 'ცვლების გრაფიკი';
    default:
      return type;
  }
};

/**
 * Valid schedule types in the system
 */
export const VALID_SCHEDULE_TYPES = ['fixed_1', 'fixed_2', 'timesheet', 'shifts'] as const;

export type ScheduleType = typeof VALID_SCHEDULE_TYPES[number];

/**
 * Check if a schedule type is valid
 */
export const isValidScheduleType = (type: string): type is ScheduleType => {
  return VALID_SCHEDULE_TYPES.includes(type as ScheduleType);
};
