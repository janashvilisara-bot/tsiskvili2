// Single source of feature names used by the top bar, search and catalog (UX-05/UX-06).
export type Lang = "ka" | "en";

export const routeLabels: Record<string, { ka: string; en: string }> = {
  "/": { ka: "მთავარი", en: "Home" },
  "/dashboard": { ka: "ყველა ფუნქცია", en: "All features" },
  "/index": { ka: "ყველა ფუნქცია", en: "All features" },
  "/employees": { ka: "თანამშრომლები", en: "Employees" },
  "/employee-portal": { ka: "თანამშრომლის პორტალი", en: "Employee portal" },
  "/employee-profile": { ka: "პროფილი", en: "Profile" },
  "/leave-requests": { ka: "შვებულებები", en: "Leave" },
  "/attendance": { ka: "დასწრება", en: "Attendance" },
  "/calendar": { ka: "კალენდარი", en: "Calendar" },
  "/payroll": { ka: "ხელფასები", en: "Payroll" },
  "/pension-payments": { ka: "საპენსიო გადახდები", en: "Pension payments" },
  "/rsge-registry": { ka: "RS.ge რეესტრი", en: "RS.ge registry" },
  "/work-time-tracking": { ka: "სამუშაო დროის აღრიცხვა", en: "Time tracking" },
  "/documents": { ka: "დოკუმენტები", en: "Documents" },
  "/notifications": { ka: "შეტყობინებები", en: "Notifications" },
  "/work-schedules": { ka: "სამუშაო გრაფიკები", en: "Work schedules" },
  "/shift-schedules": { ka: "ცვლების გრაფიკი", en: "Shift schedule" },
  "/public-holidays": { ka: "დასვენების დღეები", en: "Public holidays" },
  "/reports": { ka: "ანგარიშები", en: "Reports" },
  "/leave-statistics": { ka: "შვებულებების სტატისტიკა", en: "Leave statistics" },
  "/vacancies": { ka: "ვაკანსიები", en: "Vacancies" },
  "/candidates": { ka: "კანდიდატები", en: "Candidates" },
  "/chat": { ka: "ჩატი", en: "Chat" },
  "/vehicle-requests": { ka: "ავტომობილის მოთხოვნები", en: "Vehicle requests" },
  "/business-trip-requests": { ka: "მივლინებები", en: "Business trips" },
  "/overtime-requests": { ka: "ზეგანაკვეთური", en: "Overtime" },
  "/organizational-structure": { ka: "ორგანიზაციული სტრუქტურა", en: "Org structure" },
  "/organization": { ka: "ორგანიზაცია", en: "Organization" },
  "/personnel": { ka: "პერსონალი", en: "Personnel" },
  "/finance": { ka: "ფინანსები", en: "Finance" },
  "/recruitment": { ka: "რეკრუტინგი", en: "Recruitment" },
  "/development": { ka: "განვითარება", en: "Development" },
  "/talent-map": { ka: "ტალანტების რუკა", en: "Talent map" },
  "/load-test": { ka: "დატვირთვის ტესტი", en: "Load test" },
  "/system": { ka: "სისტემა", en: "System" },
  "/hr-tools": { ka: "HR ინსტრუმენტები", en: "HR tools" },
  "/disciplinary": { ka: "დისციპლინური", en: "Disciplinary" },
  "/feedback": { ka: "უკუკავშირი", en: "Feedback" },
  "/admin-panel": { ka: "ადმინისტრატორის პანელი", en: "Admin panel" },
  "/security": { ka: "უსაფრთხოება", en: "Security" },
  "/tasks": { ka: "დავალებები", en: "Tasks" },
  "/settings": { ka: "პარამეტრები", en: "Settings" },
  "/help": { ka: "დახმარება", en: "Help" },
  "/training": { ka: "ტრენინგები", en: "Training" },
  "/onboarding": { ka: "ადაპტაცია", en: "Onboarding" },
  "/onboarding-templates": { ka: "ადაპტაციის შაბლონები", en: "Onboarding templates" },
  "/benefits": { ka: "სარგებლები", en: "Benefits" },
  "/benefits-admin": { ka: "სარგებლები", en: "Benefits" },
  "/compensation": { ka: "კომპენსაცია", en: "Compensation" },
  "/okr": { ka: "OKR მართვა", en: "OKR" },
  "/recognition": { ka: "აღიარება", en: "Recognition" },
  "/pulse-surveys": { ka: "გამოკითხვები", en: "Surveys" },
  "/assets": { ka: "აქტივები", en: "Assets" },
  "/budget-planning": { ka: "ბიუჯეტი", en: "Budget" },
  "/budget-expenses": { ka: "ბიუჯეტის ხარჯები", en: "Budget expenses" },
  "/role-management": { ka: "როლების მართვა", en: "Role management" },
  "/sms-settings": { ka: "SMS პარამეტრები", en: "SMS settings" },
  "/integrations": { ka: "ინტეგრაციები", en: "Integrations" },
  "/schedule-templates": { ka: "გრაფიკების შაბლონები", en: "Schedule templates" },
};

export function routeLabel(url: string, lang: Lang): string | undefined {
  return routeLabels[url]?.[lang];
}

const BASE = ["/", "/dashboard", "/employee-portal", "/calendar", "/chat", "/help", "/notifications"];
const EMPLOYEE = ["/leave-requests", "/business-trip-requests", "/vehicle-requests", "/tasks", "/pulse-surveys", "/attendance", "/employee-profile", "/documents", "/overtime-requests", "/training", "/public-holidays"];
const MANAGER = ["/manager-dashboard", "/manager-headcount", "/work-schedules", "/employees", "/personnel", "/organization", "/reports"];

/** Search visibility mirrors the menu's role access (UX-09). */
export function canRoleSeeUrl(role: string | null, url: string): boolean {
  if (role === "admin" || role === "hr_manager") return true;
  if (BASE.includes(url)) return true;
  if (EMPLOYEE.includes(url)) return !!role;
  if (role === "department_manager" && MANAGER.includes(url)) return true;
  return false;
}
