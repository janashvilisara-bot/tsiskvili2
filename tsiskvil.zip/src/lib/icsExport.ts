/**
 * ICS Calendar Export Utility
 * Generates .ics files for Google Calendar / Apple Calendar / Outlook import
 */

interface IcsEvent {
  uid: string;
  title: string;
  description?: string;
  startDate: Date;
  endDate?: Date;
  allDay?: boolean;
  location?: string;
  category?: string;
}

const formatIcsDate = (date: Date, allDay: boolean): string => {
  if (allDay) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}${m}${d}`;
  }
  return date.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
};

const escapeIcsText = (text: string): string => {
  return text.replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
};

const buildIcsEvent = (event: IcsEvent): string => {
  const isAllDay = event.allDay !== false;
  const dtStart = isAllDay
    ? `DTSTART;VALUE=DATE:${formatIcsDate(event.startDate, true)}`
    : `DTSTART:${formatIcsDate(event.startDate, false)}`;

  const endDate = event.endDate || new Date(event.startDate.getTime() + 86400000);
  const dtEnd = isAllDay
    ? `DTEND;VALUE=DATE:${formatIcsDate(endDate, true)}`
    : `DTEND:${formatIcsDate(endDate, false)}`;

  const lines = [
    'BEGIN:VEVENT',
    `UID:${event.uid}@talentos.hr`,
    `DTSTAMP:${formatIcsDate(new Date(), false)}`,
    dtStart,
    dtEnd,
    `SUMMARY:${escapeIcsText(event.title)}`,
  ];

  if (event.description) {
    lines.push(`DESCRIPTION:${escapeIcsText(event.description)}`);
  }
  if (event.location) {
    lines.push(`LOCATION:${escapeIcsText(event.location)}`);
  }
  if (event.category) {
    lines.push(`CATEGORIES:${escapeIcsText(event.category)}`);
  }

  lines.push('END:VEVENT');
  return lines.join('\r\n');
};

export const generateIcsCalendar = (events: IcsEvent[], calendarName: string = 'TalentOS HR'): string => {
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//TalentOS HR//Calendar Export//KA',
    `X-WR-CALNAME:${escapeIcsText(calendarName)}`,
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
  ];

  for (const event of events) {
    lines.push(buildIcsEvent(event));
  }

  lines.push('END:VCALENDAR');
  return lines.join('\r\n');
};

export const downloadIcsFile = (icsContent: string, filename: string = 'calendar-export.ics') => {
  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export type { IcsEvent };
