import { supabase } from '@/integrations/supabase/client';

export type ThreatLevel = 'low' | 'medium' | 'high' | 'critical';

export interface SecurityThreat {
  id: string;
  threatType: string;
  description: string;
  level: ThreatLevel;
  sourceIp?: string;
  userId?: string;
  userAgent?: string;
  timestamp: Date;
  mitigated: boolean;
}

interface RequestPattern {
  count: number;
  firstRequest: number;
  lastRequest: number;
  endpoints: Set<string>;
}

// In-memory tracking for suspicious patterns (reset on page reload)
const requestPatterns = new Map<string, RequestPattern>();
const blockedIps = new Set<string>();

// WAF rule thresholds
const WAF_RULES = {
  // Rate-based rules
  MAX_REQUESTS_PER_MINUTE: 100,
  MAX_FAILED_LOGINS: 5,
  MAX_ENDPOINTS_PER_MINUTE: 20,
  
  // Pattern-based detection
  SQL_INJECTION_PATTERNS: [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|ALTER|CREATE|TRUNCATE)\b)/i,
    /(--|#|\/\*|\*\/)/,
    /(\bOR\b|\bAND\b)\s*\d+\s*=\s*\d+/i,
    /'\s*(OR|AND)\s*'?\d+/i,
  ],
  
  XSS_PATTERNS: [
    /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
    /javascript:/gi,
    /on\w+\s*=/gi,
    /<iframe/gi,
    /eval\s*\(/gi,
  ],
  
  PATH_TRAVERSAL_PATTERNS: [
    /\.\.\//g,
    /\.\.\\/, 
    /%2e%2e%2f/gi,
    /%2e%2e\//gi,
  ],
  
  COMMAND_INJECTION_PATTERNS: [
    /[;&|`$]/,
    /\$\(/,
    /`.*`/,
  ],
};

/**
 * Detect SQL injection attempts in input
 */
export function detectSqlInjection(input: string): boolean {
  return WAF_RULES.SQL_INJECTION_PATTERNS.some(pattern => pattern.test(input));
}

/**
 * Detect XSS attempts in input
 */
export function detectXss(input: string): boolean {
  return WAF_RULES.XSS_PATTERNS.some(pattern => pattern.test(input));
}

/**
 * Detect path traversal attempts
 */
export function detectPathTraversal(input: string): boolean {
  return WAF_RULES.PATH_TRAVERSAL_PATTERNS.some(pattern => pattern.test(input));
}

/**
 * Detect command injection attempts
 */
export function detectCommandInjection(input: string): boolean {
  return WAF_RULES.COMMAND_INJECTION_PATTERNS.some(pattern => pattern.test(input));
}

/**
 * Comprehensive input validation with threat detection
 */
export function validateInput(input: string, fieldName: string): {
  isValid: boolean;
  threats: string[];
} {
  const threats: string[] = [];
  
  if (detectSqlInjection(input)) {
    threats.push(`SQL injection attempt detected in ${fieldName}`);
  }
  
  if (detectXss(input)) {
    threats.push(`XSS attempt detected in ${fieldName}`);
  }
  
  if (detectPathTraversal(input)) {
    threats.push(`Path traversal attempt detected in ${fieldName}`);
  }
  
  if (detectCommandInjection(input)) {
    threats.push(`Command injection attempt detected in ${fieldName}`);
  }
  
  return {
    isValid: threats.length === 0,
    threats,
  };
}

/**
 * Track request patterns for anomaly detection
 */
export function trackRequest(identifier: string, endpoint: string): void {
  const now = Date.now();
  const pattern = requestPatterns.get(identifier);
  
  if (!pattern) {
    requestPatterns.set(identifier, {
      count: 1,
      firstRequest: now,
      lastRequest: now,
      endpoints: new Set([endpoint]),
    });
    return;
  }
  
  // Reset if more than 1 minute has passed
  if (now - pattern.firstRequest > 60000) {
    requestPatterns.set(identifier, {
      count: 1,
      firstRequest: now,
      lastRequest: now,
      endpoints: new Set([endpoint]),
    });
    return;
  }
  
  pattern.count++;
  pattern.lastRequest = now;
  pattern.endpoints.add(endpoint);
}

/**
 * Check if a request pattern is suspicious
 */
export function isPatternSuspicious(identifier: string): {
  suspicious: boolean;
  reasons: string[];
} {
  const pattern = requestPatterns.get(identifier);
  const reasons: string[] = [];
  
  if (!pattern) {
    return { suspicious: false, reasons: [] };
  }
  
  // Check request rate
  if (pattern.count > WAF_RULES.MAX_REQUESTS_PER_MINUTE) {
    reasons.push(`High request rate: ${pattern.count} requests/minute`);
  }
  
  // Check endpoint scanning
  if (pattern.endpoints.size > WAF_RULES.MAX_ENDPOINTS_PER_MINUTE) {
    reasons.push(`Endpoint scanning: ${pattern.endpoints.size} unique endpoints accessed`);
  }
  
  return {
    suspicious: reasons.length > 0,
    reasons,
  };
}

/**
 * Log security threat to database
 */
export async function logSecurityThreat(
  threatType: string,
  description: string,
  level: ThreatLevel,
  details?: Record<string, unknown>
): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    await supabase.from('audit_logs').insert({
      action_type: 'security_threat',
      resource_type: 'intrusion_detection',
      user_id: user?.id || null,
      details: {
        threat_type: threatType,
        description,
        level,
        ...details,
        timestamp: new Date().toISOString(),
        user_agent: typeof navigator !== 'undefined' ? navigator.userAgent : null,
      },
      risk_level: level === 'critical' ? 'critical' : level === 'high' ? 'high' : 'medium',
      status: 'detected',
    });
  } catch (error) {
    console.error('Failed to log security threat:', error);
  }
}

/**
 * Block an IP address (in-memory, resets on page reload)
 */
export function blockIp(ip: string): void {
  blockedIps.add(ip);
}

/**
 * Check if an IP is blocked
 */
export function isIpBlocked(ip: string): boolean {
  return blockedIps.has(ip);
}

/**
 * Get blocked IPs count
 */
export function getBlockedIpsCount(): number {
  return blockedIps.size;
}

/**
 * Sanitize user input to prevent common attacks
 */
export function sanitizeInput(input: string): string {
  return input
    // Remove script tags
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    // Remove event handlers
    .replace(/on\w+\s*=\s*["'][^"']*["']/gi, '')
    // Escape HTML entities
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;')
    // Remove null bytes
    .replace(/\0/g, '');
}

/**
 * Validate and sanitize URL to prevent open redirect attacks
 */
export function validateRedirectUrl(url: string, allowedDomains: string[]): boolean {
  try {
    const parsed = new URL(url, window.location.origin);
    
    // Only allow same-origin or whitelisted domains
    if (parsed.origin === window.location.origin) {
      return true;
    }
    
    return allowedDomains.some(domain => parsed.hostname.endsWith(domain));
  } catch {
    return false;
  }
}

/**
 * Monitor for brute force attacks
 */
const loginAttempts = new Map<string, { count: number; firstAttempt: number }>();

export function trackLoginAttempt(identifier: string, success: boolean): {
  blocked: boolean;
  remainingAttempts: number;
} {
  const now = Date.now();
  const attempts = loginAttempts.get(identifier);
  
  if (success) {
    loginAttempts.delete(identifier);
    return { blocked: false, remainingAttempts: WAF_RULES.MAX_FAILED_LOGINS };
  }
  
  if (!attempts || now - attempts.firstAttempt > 900000) { // 15 minutes
    loginAttempts.set(identifier, { count: 1, firstAttempt: now });
    return { blocked: false, remainingAttempts: WAF_RULES.MAX_FAILED_LOGINS - 1 };
  }
  
  attempts.count++;
  const blocked = attempts.count >= WAF_RULES.MAX_FAILED_LOGINS;
  const remaining = Math.max(0, WAF_RULES.MAX_FAILED_LOGINS - attempts.count);
  
  return { blocked, remainingAttempts: remaining };
}

/**
 * Clear expired tracking data (call periodically)
 */
export function cleanupTrackingData(): void {
  const now = Date.now();
  
  // Clean request patterns older than 5 minutes
  for (const [key, pattern] of requestPatterns.entries()) {
    if (now - pattern.lastRequest > 300000) {
      requestPatterns.delete(key);
    }
  }
  
  // Clean login attempts older than 15 minutes
  for (const [key, attempts] of loginAttempts.entries()) {
    if (now - attempts.firstAttempt > 900000) {
      loginAttempts.delete(key);
    }
  }
}
