import ExcelJS from 'exceljs';
import { supabase } from '@/integrations/supabase/client';

const MONTHS = ['იანვარი', 'თებერვალი', 'მარტი', 'აპრილი', 'მაისი', 'ივნისი', 'ივლისი', 'აგვისტო', 'სექტემბერი', 'ოქტომბერი', 'ნოემბერი', 'დეკემბერი'];

export const exportAnnualFinancialReport = async (year: number) => {
  try {
    const workbook = new ExcelJS.Workbook();
    
    // Array to store monthly totals for summary
    const monthlyTotals: any[] = [];

    // Fetch data for each month
    for (let month = 1; month <= 12; month++) {
      const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
      const endDate = new Date(year, month, 0).toISOString().split('T')[0];

      // Fetch all data for the month
      const { data: payrollData } = await supabase.from('payroll').select(`
        *,
        employees:employee_id(full_name, position, department)
      `).eq('month', month).eq('year', year);

      const { data: leavesData } = await supabase.from('leave_requests').select(`
        *,
        employee:employees!leave_requests_employee_id_fkey(full_name)
      `).gte('start_date', startDate).lte('end_date', endDate).eq('status', 'approved');

      const { data: overtimeData } = await supabase.from('overtime_requests' as any).select(`
        *,
        employee:employees(full_name)
      `).gte('work_date', startDate).lte('work_date', endDate).eq('status', 'approved');

      const { data: pensionData } = await supabase.from('pension_payments').select('*')
        .eq('period_month', month).eq('period_year', year);

      const { data: budgetData } = await supabase.from('budget_expenses')
        .select('*')
        .gte('expense_date', startDate)
        .lte('expense_date', endDate)
        .eq('status', 'approved');

      // Calculate monthly totals
      const totalPayroll = (payrollData || []).reduce((sum, p) => sum + (p.net_salary || 0), 0);
      const totalBaseSalary = (payrollData || []).reduce((sum, p) => sum + (p.base_salary || 0), 0);
      const totalBonuses = (payrollData || []).reduce((sum, p) => sum + (p.bonuses || 0), 0);
      const totalDeductions = (payrollData || []).reduce((sum, p) => sum + (p.deductions || 0), 0);
      
      const maternityLeaves = (leavesData || []).filter((l: any) => l.leave_type === 'maternity' || l.leave_type === 'paternity');
      const totalMaternity = maternityLeaves.reduce((sum: number, l: any) => {
        const days = l.end_date && l.start_date 
          ? Math.ceil((new Date(l.end_date).getTime() - new Date(l.start_date).getTime()) / (1000 * 60 * 60 * 24)) + 1
          : 0;
        const payroll = payrollData?.find(p => p.employee_id === l.employee_id);
        const dailyRate = payroll ? (payroll.base_salary || 0) / 30 : 0;
        return sum + (dailyRate * days);
      }, 0);

      const sickLeaves = (leavesData || []).filter((l: any) => l.leave_type === 'sick');
      const totalSick = sickLeaves.reduce((sum: number, l: any) => {
        const days = l.end_date && l.start_date 
          ? Math.ceil((new Date(l.end_date).getTime() - new Date(l.start_date).getTime()) / (1000 * 60 * 60 * 24)) + 1
          : 0;
        const payroll = payrollData?.find(p => p.employee_id === l.employee_id);
        const dailyRate = payroll ? (payroll.base_salary || 0) / 30 : 0;
        return sum + (dailyRate * days * 0.7);
      }, 0);

      const totalOvertime = (overtimeData || []).reduce((sum, o: any) => sum + ((o.hours || 0) * (o.hourly_rate || 0)), 0);
      const totalOvertimeHours = (overtimeData || []).reduce((sum, o: any) => sum + (o.hours || 0), 0);
      const totalPension = (pensionData || []).reduce((sum, p) => sum + (p.total_amount || 0), 0);
      const totalBudget = (budgetData || []).reduce((sum, b) => sum + (b.amount || 0), 0);

      const employeeCount = payrollData?.length || 0;
      const monthlyTotal = totalPayroll + totalMaternity + totalSick + totalOvertime + totalPension + totalBudget;

      // Store monthly data
      monthlyTotals.push({
        'თვე': MONTHS[month - 1],
        'თანამშრომელთა რაოდენობა': employeeCount,
        'საბაზო ხელფასები': totalBaseSalary.toFixed(2),
        'ბონუსები': totalBonuses.toFixed(2),
        'დაქვითვები': totalDeductions.toFixed(2),
        'წმინდა ხელფასები': totalPayroll.toFixed(2),
        'დეკრეტული გადახდები': totalMaternity.toFixed(2),
        'ავადმყოფობა': totalSick.toFixed(2),
        'ზეგანაკვეთური (საათები)': totalOvertimeHours.toFixed(1),
        'ზეგანაკვეთური (₾)': totalOvertime.toFixed(2),
        'პენსია': totalPension.toFixed(2),
        'ბიუჯეტის ხარჯები': totalBudget.toFixed(2),
        'სულ ხარჯები': monthlyTotal.toFixed(2)
      });

      // Create detailed monthly sheet
      const monthlyPayrollSheet = (payrollData || []).map(p => ({
        'თანამშრომელი': p.employees?.full_name || '',
        'პოზიცია': p.employees?.position || '',
        'დეპარტამენტი': p.employees?.department || '',
        'საბაზო ხელფასი': p.base_salary || 0,
        'ბონუსები': p.bonuses || 0,
        'დაქვითვები': p.deductions || 0,
        'წმინდა ხელფასი': p.net_salary || 0,
        'სტატუსი': p.status || 'pending'
      }));

      if (monthlyPayrollSheet.length > 0) {
        const ws = workbook.addWorksheet(`${MONTHS[month - 1]} (ხელფასები)`);
        ws.columns = Object.keys(monthlyPayrollSheet[0]).map(key => ({
          header: key,
          key,
          width: 18
        }));
        monthlyPayrollSheet.forEach(row => ws.addRow(row));
        ws.getRow(1).font = { bold: true };
        ws.getRow(1).fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFE0E0E0' }
        };
      }
    }

    // Create annual summary sheet (at beginning)
    const summarySheet = workbook.addWorksheet('წლიური შეჯამება');
    if (monthlyTotals.length > 0) {
      summarySheet.columns = Object.keys(monthlyTotals[0]).map(key => ({
        header: key,
        key,
        width: 18
      }));
      monthlyTotals.forEach(row => summarySheet.addRow(row));
      summarySheet.getRow(1).font = { bold: true };
      summarySheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFE0E0E0' }
      };
    }

    // Create yearly totals sheet
    const yearlyTotals = monthlyTotals.reduce((acc, month) => {
      return {
        employees: Math.max(acc.employees, parseFloat(month['თანამშრომელთა რაოდენობა']) || 0),
        baseSalary: acc.baseSalary + (parseFloat(month['საბაზო ხელფასები']) || 0),
        bonuses: acc.bonuses + (parseFloat(month['ბონუსები']) || 0),
        deductions: acc.deductions + (parseFloat(month['დაქვითვები']) || 0),
        netSalary: acc.netSalary + (parseFloat(month['წმინდა ხელფასები']) || 0),
        maternity: acc.maternity + (parseFloat(month['დეკრეტული გადახდები']) || 0),
        sick: acc.sick + (parseFloat(month['ავადმყოფობა']) || 0),
        overtimeHours: acc.overtimeHours + (parseFloat(month['ზეგანაკვეთური (საათები)']) || 0),
        overtime: acc.overtime + (parseFloat(month['ზეგანაკვეთური (₾)']) || 0),
        pension: acc.pension + (parseFloat(month['პენსია']) || 0),
        budget: acc.budget + (parseFloat(month['ბიუჯეტის ხარჯები']) || 0),
        total: acc.total + (parseFloat(month['სულ ხარჯები']) || 0)
      };
    }, {
      employees: 0, baseSalary: 0, bonuses: 0, deductions: 0, netSalary: 0,
      maternity: 0, sick: 0, overtimeHours: 0, overtime: 0, pension: 0, budget: 0, total: 0
    });

    const yearlySheet = workbook.addWorksheet('წლიური ჯამები');
    yearlySheet.columns = [
      { header: 'კატეგორია', key: 'category', width: 35 },
      { header: 'თანხა/რაოდენობა', key: 'amount', width: 20 }
    ];

    const yearlyData = [
      { category: 'მაქსიმალური თანამშრომელთა რაოდენობა', amount: yearlyTotals.employees.toString() },
      { category: '═══════════════════════════', amount: '═══════════' },
      { category: 'საბაზო ხელფასები (წლიური)', amount: `${yearlyTotals.baseSalary.toFixed(2)} ₾` },
      { category: 'ბონუსები (წლიური)', amount: `${yearlyTotals.bonuses.toFixed(2)} ₾` },
      { category: 'დაქვითვები (წლიური)', amount: `${yearlyTotals.deductions.toFixed(2)} ₾` },
      { category: 'წმინდა ხელფასები (წლიური)', amount: `${yearlyTotals.netSalary.toFixed(2)} ₾` },
      { category: '═══════════════════════════', amount: '═══════════' },
      { category: 'დეკრეტული გადახდები (წლიური)', amount: `${yearlyTotals.maternity.toFixed(2)} ₾` },
      { category: 'ავადმყოფობის კომპენსაცია (წლიური)', amount: `${yearlyTotals.sick.toFixed(2)} ₾` },
      { category: 'ზეგანაკვეთური საათები (წლიური)', amount: `${yearlyTotals.overtimeHours.toFixed(1)} სთ` },
      { category: 'ზეგანაკვეთური გადახდები (წლიური)', amount: `${yearlyTotals.overtime.toFixed(2)} ₾` },
      { category: 'პენსიის გადახდები (წლიური)', amount: `${yearlyTotals.pension.toFixed(2)} ₾` },
      { category: 'ბიუჯეტის ხარჯები (წლიური)', amount: `${yearlyTotals.budget.toFixed(2)} ₾` },
      { category: '═══════════════════════════', amount: '═══════════' },
      { category: 'სულ ხარჯები (წლიური)', amount: `${yearlyTotals.total.toFixed(2)} ₾` },
      { category: '', amount: '' },
      { category: 'საშუალო თვიური ხარჯი', amount: `${(yearlyTotals.total / 12).toFixed(2)} ₾` }
    ];

    yearlyData.forEach(row => yearlySheet.addRow(row));
    yearlySheet.getRow(1).font = { bold: true };
    yearlySheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    // Create quarterly breakdown
    const quarterlySheet = workbook.addWorksheet('კვარტალური ანალიზი');
    quarterlySheet.columns = [
      { header: 'კვარტალი', key: 'quarter', width: 20 },
      { header: 'თვეები', key: 'months', width: 35 },
      { header: 'სულ ხარჯები', key: 'total', width: 20 },
      { header: 'საშუალო თვიური', key: 'avg', width: 20 }
    ];

    for (let q = 1; q <= 4; q++) {
      const startMonth = (q - 1) * 3;
      const endMonth = q * 3;
      const quarterMonths = monthlyTotals.slice(startMonth, endMonth);
      
      const quarterTotal = quarterMonths.reduce((acc, month) => {
        return acc + (parseFloat(month['სულ ხარჯები']) || 0);
      }, 0);

      quarterlySheet.addRow({
        quarter: `${q}-ე კვარტალი`,
        months: quarterMonths.map(m => m['თვე']).join(', '),
        total: quarterTotal.toFixed(2) + ' ₾',
        avg: (quarterTotal / 3).toFixed(2) + ' ₾'
      });
    }

    quarterlySheet.getRow(1).font = { bold: true };
    quarterlySheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    // Write file
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `წლიური_ფინანსური_ანგარიში_${year}.xlsx`;
    link.click();
    window.URL.revokeObjectURL(url);

    return { success: true };
  } catch (error) {
    console.error('Error exporting annual financial report:', error);
    throw error;
  }
};
