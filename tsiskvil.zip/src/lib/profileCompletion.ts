// Utility to calculate employee profile completion percentage
export const calculateProfileCompletion = (employee: any): number => {
  if (!employee) return 0;
  
  const fields = [
    'full_name',
    'email',
    'phone',
    'personal_id_number',
    'date_of_birth',
    'gender',
    'actual_address',
    'education',
    'education_level',
    'previous_experience',
    'emergency_contact_name',
    'emergency_contact_phone',
    'emergency_contact_relation',
    'bank_account_number',
    'bank_name',
    'tax_benefits',
    'department',
    'position',
    'hire_date',
    'salary',
  ];
  
  const filledFields = fields.filter(field => {
    const value = employee[field];
    return value !== null && value !== undefined && value !== '';
  });
  
  return Math.round((filledFields.length / fields.length) * 100);
};
