export type LocalizedName = { ka: string; en: string };
export interface IndustryPreset {
  id: string;
  name: LocalizedName;
  departments: { name: LocalizedName; positions: LocalizedName[] }[];
  schedules: { name: LocalizedName; start: string; end: string; category: string; breakMinutes: number }[];
}
const n = (ka: string, en: string): LocalizedName => ({ ka, en });
export const industryPresets: IndustryPreset[] = [
  { id: 'hotel', name: n('სასტუმრო', 'Hotel'), departments: [
    { name: n('მიღება და ჯავშნები', 'Reception & Reservations'), positions: [n('რეცეფციონისტი', 'Receptionist'), n('ჯავშნების სპეციალისტი', 'Reservations Specialist')] },
    { name: n('ჰაუსქიფინგი', 'Housekeeping'), positions: [n('ჰაუსქიფინგის მენეჯერი', 'Housekeeping Manager'), n('ოთახების დამლაგებელი', 'Room Attendant')] },
    { name: n('კვება და სასმელები', 'Food & Beverage'), positions: [n('შეფ-მზარეული', 'Head Chef'), n('მიმტანი', 'Waiter')] },
    { name: n('ტექნიკური სამსახური', 'Maintenance'), positions: [n('ტექნიკოსი', 'Maintenance Technician')] },
  ], schedules: [
    { name: n('სასტუმრო - დილის ცვლა', 'Hotel - Morning shift'), start: '07:00', end: '15:00', category: 'shifts', breakMinutes: 30 },
    { name: n('სასტუმრო - საღამოს ცვლა', 'Hotel - Evening shift'), start: '15:00', end: '23:00', category: 'shifts', breakMinutes: 30 },
    { name: n('სასტუმრო - ღამის ცვლა', 'Hotel - Night shift'), start: '23:00', end: '07:00', category: 'shifts', breakMinutes: 30 },
  ] },
  { id: 'clinic', name: n('კლინიკა', 'Clinic'), departments: [
    { name: n('სამედიცინო სამსახური', 'Medical Services'), positions: [n('ექიმი', 'Physician'), n('სამედიცინო დირექტორი', 'Medical Director')] },
    { name: n('საექთნო სამსახური', 'Nursing'), positions: [n('ექთანი', 'Nurse'), n('უფროსი ექთანი', 'Head Nurse')] },
    { name: n('დიაგნოსტიკა', 'Diagnostics'), positions: [n('ლაბორანტი', 'Laboratory Technician')] },
    { name: n('პაციენტთა მომსახურება', 'Patient Services'), positions: [n('რეგისტრატორი', 'Patient Registrar')] },
  ], schedules: [
    { name: n('კლინიკა - დღის ცვლა', 'Clinic - Day shift'), start: '08:00', end: '20:00', category: 'shifts', breakMinutes: 60 },
    { name: n('კლინიკა - ღამის ცვლა', 'Clinic - Night shift'), start: '20:00', end: '08:00', category: 'shifts', breakMinutes: 60 },
    { name: n('კლინიკა - ამბულატორია', 'Clinic - Outpatient'), start: '09:00', end: '17:00', category: 'full', breakMinutes: 30 },
  ] },
  { id: 'retail', name: n('რითეილი', 'Retail'), departments: [
    { name: n('მაღაზიის ოპერაციები', 'Store Operations'), positions: [n('მაღაზიის მენეჯერი', 'Store Manager'), n('გაყიდვების კონსულტანტი', 'Sales Consultant')] },
    { name: n('სალარო', 'Checkout'), positions: [n('მოლარე', 'Cashier')] },
    { name: n('საწყობი და მიწოდება', 'Warehouse & Delivery'), positions: [n('საწყობის თანამშრომელი', 'Warehouse Associate'), n('მარაგების მენეჯერი', 'Inventory Manager')] },
    { name: n('მერჩენდაიზინგი', 'Merchandising'), positions: [n('მერჩენდაიზერი', 'Merchandiser')] },
  ], schedules: [
    { name: n('რითეილი - პირველი ცვლა', 'Retail - First shift'), start: '09:00', end: '17:00', category: 'shifts', breakMinutes: 30 },
    { name: n('რითეილი - მეორე ცვლა', 'Retail - Second shift'), start: '14:00', end: '22:00', category: 'shifts', breakMinutes: 30 },
  ] },
  { id: 'restaurant', name: n('რესტორანი', 'Restaurant'), departments: [
    { name: n('სამზარეულო', 'Kitchen'), positions: [n('შეფ-მზარეული', 'Head Chef'), n('მზარეული', 'Cook'), n('სამზარეულოს დამხმარე', 'Kitchen Assistant')] },
    { name: n('დარბაზი', 'Service Floor'), positions: [n('მიმტანი', 'Waiter'), n('ჰოსტესი', 'Host')] },
    { name: n('ბარი', 'Bar'), positions: [n('ბარმენი', 'Bartender'), n('ბარისტა', 'Barista')] },
    { name: n('ადმინისტრაცია', 'Administration'), positions: [n('რესტორნის მენეჯერი', 'Restaurant Manager')] },
  ], schedules: [
    { name: n('რესტორანი - დღის ცვლა', 'Restaurant - Day shift'), start: '10:00', end: '18:00', category: 'shifts', breakMinutes: 30 },
    { name: n('რესტორანი - საღამოს ცვლა', 'Restaurant - Evening shift'), start: '16:00', end: '00:00', category: 'shifts', breakMinutes: 30 },
  ] },
  { id: 'construction', name: n('მშენებლობა', 'Construction'), departments: [
    { name: n('სამშენებლო სამუშაოები', 'Construction Works'), positions: [n('ობიექტის ხელმძღვანელი', 'Site Manager'), n('ოსტატი', 'Foreman'), n('მუშა', 'Construction Worker')] },
    { name: n('საპროექტო სამსახური', 'Design & Engineering'), positions: [n('ინჟინერი', 'Engineer'), n('არქიტექტორი', 'Architect')] },
    { name: n('უსაფრთხოება და ხარისხი', 'Safety & Quality'), positions: [n('შრომის უსაფრთხოების სპეციალისტი', 'Safety Specialist')] },
    { name: n('მარაგები და ლოჯისტიკა', 'Supply & Logistics'), positions: [n('მომარაგების მენეჯერი', 'Procurement Manager')] },
  ], schedules: [
    { name: n('მშენებლობა - სტანდარტული', 'Construction - Standard'), start: '09:00', end: '18:00', category: 'full', breakMinutes: 60 },
    { name: n('მშენებლობა - ადრეული ცვლა', 'Construction - Early shift'), start: '07:00', end: '16:00', category: 'shifts', breakMinutes: 60 },
  ] },
  { id: 'manufacturing', name: n('წარმოება', 'Manufacturing'), departments: [
    { name: n('საწარმოო ხაზი', 'Production Line'), positions: [n('ოპერატორი', 'Machine Operator'), n('ცვლის უფროსი', 'Shift Supervisor')] },
    { name: n('ხარისხის კონტროლი', 'Quality Control'), positions: [n('ხარისხის ინსპექტორი', 'Quality Inspector')] },
    { name: n('ტექნიკური მომსახურება', 'Maintenance'), positions: [n('მექანიკოსი', 'Mechanic'), n('ელექტრიკოსი', 'Electrician')] },
    { name: n('საწყობი', 'Warehouse'), positions: [n('საწყობის თანამშრომელი', 'Warehouse Associate')] },
  ], schedules: [
    { name: n('წარმოება - პირველი ცვლა', 'Manufacturing - First shift'), start: '08:00', end: '16:00', category: 'shifts', breakMinutes: 45 },
    { name: n('წარმოება - მეორე ცვლა', 'Manufacturing - Second shift'), start: '16:00', end: '00:00', category: 'shifts', breakMinutes: 45 },
    { name: n('წარმოება - ღამის ცვლა', 'Manufacturing - Night shift'), start: '00:00', end: '08:00', category: 'shifts', breakMinutes: 45 },
  ] },
  { id: 'logistics', name: n('ლოჯისტიკა და ტრანსპორტი', 'Logistics & Transport'), departments: [
    { name: n('ტრანსპორტი', 'Transport'), positions: [n('მძღოლი', 'Driver'), n('ავტოპარკის მენეჯერი', 'Fleet Manager')] },
    { name: n('საწყობი', 'Warehouse'), positions: [n('საწყობის უფროსი', 'Warehouse Supervisor'), n('დამტვირთავი', 'Loader')] },
    { name: n('ოპერაციები', 'Operations'), positions: [n('ლოჯისტიკის სპეციალისტი', 'Logistics Specialist'), n('დისპეტჩერი', 'Dispatcher')] },
    { name: n('მომხმარებელთა მომსახურება', 'Customer Service'), positions: [n('მომხმარებელთა მენეჯერი', 'Customer Service Manager')] },
  ], schedules: [
    { name: n('ლოჯისტიკა - დღის ცვლა', 'Logistics - Day shift'), start: '08:00', end: '20:00', category: 'shifts', breakMinutes: 60 },
    { name: n('ლოჯისტიკა - ღამის ცვლა', 'Logistics - Night shift'), start: '20:00', end: '08:00', category: 'shifts', breakMinutes: 60 },
  ] },
  { id: 'it', name: n('IT და ტექნოლოგიები', 'IT & Technology'), departments: [
    { name: n('დეველოპმენტი', 'Development'), positions: [n('პროგრამისტი', 'Software Engineer'), n('გუნდის ლიდერი', 'Team Lead')] },
    { name: n('ხარისხის უზრუნველყოფა', 'Quality Assurance'), positions: [n('QA ინჟინერი', 'QA Engineer')] },
    { name: n('პროდუქტი და დიზაინი', 'Product & Design'), positions: [n('პროდუქტის მენეჯერი', 'Product Manager'), n('UX დიზაინერი', 'UX Designer')] },
    { name: n('ინფრასტრუქტურა', 'Infrastructure'), positions: [n('DevOps ინჟინერი', 'DevOps Engineer'), n('სისტემური ადმინისტრატორი', 'System Administrator')] },
  ], schedules: [
    { name: n('IT - სტანდარტული', 'IT - Standard'), start: '10:00', end: '19:00', category: 'full', breakMinutes: 60 },
    { name: n('IT - მოქნილი', 'IT - Flexible'), start: '11:00', end: '20:00', category: 'flexible', breakMinutes: 60 },
  ] },
  { id: 'bank', name: n('ბანკი და ფინანსები', 'Bank & Finance'), departments: [
    { name: n('ფილიალის მომსახურება', 'Branch Services'), positions: [n('ოპერატორი', 'Teller'), n('ფილიალის მენეჯერი', 'Branch Manager')] },
    { name: n('საკრედიტო სამსახური', 'Lending'), positions: [n('საკრედიტო ოფიცერი', 'Loan Officer'), n('საკრედიტო ანალიტიკოსი', 'Credit Analyst')] },
    { name: n('რისკები და კომპლაენსი', 'Risk & Compliance'), positions: [n('კომპლაენს ოფიცერი', 'Compliance Officer'), n('რისკების ანალიტიკოსი', 'Risk Analyst')] },
    { name: n('ბუღალტერია', 'Accounting'), positions: [n('ბუღალტერი', 'Accountant')] },
  ], schedules: [
    { name: n('ბანკი - სტანდარტული', 'Bank - Standard'), start: '09:30', end: '18:30', category: 'full', breakMinutes: 60 },
    { name: n('ბანკი - შაბათის ცვლა', 'Bank - Saturday shift'), start: '10:00', end: '16:00', category: 'shifts', breakMinutes: 30 },
  ] },
  { id: 'education', name: n('განათლება', 'Education'), departments: [
    { name: n('სასწავლო პროცესი', 'Academic'), positions: [n('მასწავლებელი', 'Teacher'), n('ლექტორი', 'Lecturer')] },
    { name: n('ადმინისტრაცია', 'Administration'), positions: [n('დირექტორი', 'Director'), n('ადმინისტრატორი', 'Administrator')] },
    { name: n('სტუდენტებთან ურთიერთობა', 'Student Affairs'), positions: [n('სტუდენტური სერვისების სპეციალისტი', 'Student Services Specialist')] },
    { name: n('დამხმარე სამსახური', 'Support Services'), positions: [n('ბიბლიოთეკარი', 'Librarian'), n('ფსიქოლოგი', 'Psychologist')] },
  ], schedules: [
    { name: n('განათლება - სასწავლო დღე', 'Education - School day'), start: '09:00', end: '16:00', category: 'full', breakMinutes: 45 },
    { name: n('განათლება - საღამოს ჯგუფები', 'Education - Evening groups'), start: '15:00', end: '21:00', category: 'shifts', breakMinutes: 30 },
  ] },
  { id: 'pharmacy', name: n('აფთიაქი', 'Pharmacy'), departments: [
    { name: n('აფთიაქის ოპერაციები', 'Pharmacy Operations'), positions: [n('ფარმაცევტი', 'Pharmacist'), n('აფთიაქის მენეჯერი', 'Pharmacy Manager')] },
    { name: n('მომხმარებელთა მომსახურება', 'Customer Service'), positions: [n('კონსულტანტი', 'Consultant'), n('მოლარე', 'Cashier')] },
    { name: n('მარაგები', 'Inventory'), positions: [n('მარაგების სპეციალისტი', 'Inventory Specialist')] },
  ], schedules: [
    { name: n('აფთიაქი - დილის ცვლა', 'Pharmacy - Morning shift'), start: '08:00', end: '20:00', category: 'shifts', breakMinutes: 60 },
    { name: n('აფთიაქი - ღამის ცვლა', 'Pharmacy - Night shift'), start: '20:00', end: '08:00', category: 'shifts', breakMinutes: 60 },
  ] },
  { id: 'beauty', name: n('სილამაზის სალონი', 'Beauty Salon'), departments: [
    { name: n('თმის მომსახურება', 'Hair Services'), positions: [n('სტილისტი', 'Hair Stylist'), n('კოლორისტი', 'Colorist')] },
    { name: n('კოსმეტოლოგია', 'Cosmetology'), positions: [n('კოსმეტოლოგი', 'Cosmetologist'), n('მასაჟისტი', 'Massage Therapist')] },
    { name: n('მანიკური და პედიკური', 'Nails'), positions: [n('მანიკიურისტი', 'Nail Technician')] },
    { name: n('მიღება', 'Reception'), positions: [n('ადმინისტრატორი', 'Salon Administrator')] },
  ], schedules: [
    { name: n('სალონი - დილის ცვლა', 'Salon - Morning shift'), start: '10:00', end: '16:00', category: 'shifts', breakMinutes: 30 },
    { name: n('სალონი - საღამოს ცვლა', 'Salon - Evening shift'), start: '14:00', end: '21:00', category: 'shifts', breakMinutes: 30 },
  ] },
  { id: 'security', name: n('დაცვის სამსახური', 'Security Services'), departments: [
    { name: n('ობიექტების დაცვა', 'Site Security'), positions: [n('მეთვალყურე', 'Security Guard'), n('ცვლის უფროსი', 'Shift Supervisor')] },
    { name: n('მონიტორინგი', 'Monitoring'), positions: [n('ვიდეომონიტორინგის ოპერატორი', 'CCTV Operator')] },
    { name: n('ოპერატიული მართვა', 'Operations'), positions: [n('ოპერაციების მენეჯერი', 'Operations Manager')] },
  ], schedules: [
    { name: n('დაცვა - დღის ცვლა 12სთ', 'Security - Day shift 12h'), start: '08:00', end: '20:00', category: 'shifts', breakMinutes: 60 },
    { name: n('დაცვა - ღამის ცვლა 12სთ', 'Security - Night shift 12h'), start: '20:00', end: '08:00', category: 'shifts', breakMinutes: 60 },
  ] },
];