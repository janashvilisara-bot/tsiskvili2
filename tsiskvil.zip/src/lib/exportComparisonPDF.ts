import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

interface ComparisonRow {
  category: string;
  feature: string;
  talentos: string;
  selfhr: string;
  ilaria: string;
}

const comparisonData: ComparisonRow[] = [
  // HR Administration
  { category: "HR Administration", feature: "Employee Profiles", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "HR Administration", feature: "Organizational Structure (Visual Chart)", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "HR Administration", feature: "Departments / Positions", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "HR Administration", feature: "Multi-Company Support", talentos: "✓", selfhr: "-", ilaria: "✗" },

  // Documents
  { category: "Documents", feature: "Document Management", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Documents", feature: "AI Contract Generation", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "Documents", feature: "Contract Templates", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Documents", feature: "Electronic Signature", talentos: "✓", selfhr: "-", ilaria: "✗" },

  // Time Tracking
  { category: "Time Tracking", feature: "Attendance Tracking", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Time Tracking", feature: "Shift Schedules", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Time Tracking", feature: "Work-Time Reports", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Time Tracking", feature: "GPS / Geofencing", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Time Tracking", feature: "Mobile Check-in/out", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Time Tracking", feature: "Suspicious Location Alerts", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Time Tracking", feature: "Auto-Checkout", talentos: "✓", selfhr: "✗", ilaria: "✗" },

  // Payroll & Finance
  { category: "Payroll & Finance", feature: "Salary Calculation", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Payroll & Finance", feature: "Benefits Administration", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Payroll & Finance", feature: "Pension Payments", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "Payroll & Finance", feature: "Budget Planning", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Payroll & Finance", feature: "Expense Management", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Payroll & Finance", feature: "Compensation & Bonuses", talentos: "✓", selfhr: "-", ilaria: "-" },
  { category: "Payroll & Finance", feature: "Financial Reports", talentos: "✓", selfhr: "✓", ilaria: "✓" },

  // Leave Management
  { category: "Leave Management", feature: "Leave Requests", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Leave Management", feature: "Leave Types", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Leave Management", feature: "Leave Statistics", talentos: "✓", selfhr: "-", ilaria: "-" },
  { category: "Leave Management", feature: "Public Holidays", talentos: "✓", selfhr: "✓", ilaria: "✓" },

  // Recruitment
  { category: "Recruitment", feature: "Vacancy Management", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Recruitment", feature: "Candidate Database", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Recruitment", feature: "AI CV Analysis & Matching", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Recruitment", feature: "Onboarding", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Recruitment", feature: "Job Descriptions", talentos: "✓", selfhr: "-", ilaria: "✓" },

  // Training & Development
  { category: "Training & Development", feature: "Training Courses", talentos: "✓", selfhr: "✗", ilaria: "✓" },
  { category: "Training & Development", feature: "Video Tutorials", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Training & Development", feature: "OKR Management", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Training & Development", feature: "Performance Reviews", talentos: "✓", selfhr: "✗", ilaria: "-" },
  { category: "Training & Development", feature: "Employee Evaluations", talentos: "✓", selfhr: "✗", ilaria: "-" },

  // Task Management
  { category: "Task Management", feature: "Kanban Board", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Task Management", feature: "Projects & Subtasks", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Task Management", feature: "Task Comments", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Task Management", feature: "Priority & Deadlines", talentos: "✓", selfhr: "✗", ilaria: "✗" },

  // Communication
  { category: "Communication", feature: "Real-time Chat", talentos: "✓", selfhr: "✓", ilaria: "✗" },
  { category: "Communication", feature: "SMS Notifications", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Communication", feature: "Announcements", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Communication", feature: "Video Calls", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Communication", feature: "Email Notifications", talentos: "✓", selfhr: "-", ilaria: "-" },

  // Gamification
  { category: "Gamification", feature: "Points System", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Gamification", feature: "Badges & Achievements", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Gamification", feature: "Team Challenges", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Gamification", feature: "Rewards Catalog", talentos: "✓", selfhr: "✗", ilaria: "✗" },

  // AI Features
  { category: "AI Features", feature: "AI Assistant (Nina)", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "AI Features", feature: "AI CV Analysis", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "AI Features", feature: "Smart Notifications", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "AI Features", feature: "AI Feedback Recommendations", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "AI Features", feature: "Budget Forecast (AI)", talentos: "✓", selfhr: "✗", ilaria: "✗" },

  // Security
  { category: "Security", feature: "AES-256-GCM Encryption", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "Security", feature: "36+ RLS Policies", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "Security", feature: "Intrusion Detection (IDS)", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Security", feature: "Masked Views (PII Protection)", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Security", feature: "Audit Logs", talentos: "✓", selfhr: "-", ilaria: "-" },
  { category: "Security", feature: "IP/Geo Anomaly Detection", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Security", feature: "Rate Limiting", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "Security", feature: "Soft Delete & Recovery", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Security", feature: "GDPR / Georgian Law Compliance", talentos: "✓", selfhr: "✓", ilaria: "✓" },

  // System
  { category: "System", feature: "Self-Hosting (Docker)", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "System", feature: "Database Backup / Restore", talentos: "✓", selfhr: "-", ilaria: "-" },
  { category: "System", feature: "Mobile App (PWA / Native)", talentos: "PWA", selfhr: "Native", ilaria: "Native" },
  { category: "System", feature: "Role Management (RBAC)", talentos: "✓ Custom", selfhr: "✓", ilaria: "-" },
  { category: "System", feature: "Calendar View", talentos: "✓", selfhr: "-", ilaria: "-" },
  { category: "System", feature: "Support Tickets", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "System", feature: "Business Trips", talentos: "✓", selfhr: "✓", ilaria: "✗" },
  { category: "System", feature: "Vehicle Requests", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "System", feature: "Asset Management", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "System", feature: "CRM (Contacts & Deals)", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "System", feature: "Disciplinary Actions", talentos: "✓", selfhr: "✗", ilaria: "-" },
  { category: "System", feature: "Wellness Surveys", talentos: "✓", selfhr: "✓", ilaria: "✗" },
];

function getFeatureCount(key: "talentos" | "selfhr" | "ilaria") {
  return comparisonData.filter(r => r[key] === "✓" || r[key].includes("✓")).length;
}

export function exportComparisonPDF() {
  const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });

  // Title
  doc.setFontSize(20);
  doc.setTextColor(41, 98, 255);
  doc.text("TalentOS vs Self.hr vs Ilaria", 14, 18);
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text("Feature Comparison | " + new Date().toLocaleDateString("ka-GE"), 14, 25);

  // Legend
  doc.setFontSize(8);
  doc.setTextColor(60, 60, 60);
  doc.text("Legend:  ✓ = Available   ✗ = Not Available   - = Unknown/Unconfirmed", 14, 30);

  // Score summary bar
  const talentosCount = getFeatureCount("talentos");
  const selfhrCount = getFeatureCount("selfhr");
  const ilariaCount = getFeatureCount("ilaria");
  const total = comparisonData.length;

  doc.setFontSize(9);
  doc.setTextColor(0, 140, 60);
  doc.text(`TalentOS: ${talentosCount}/${total}`, 14, 35);
  doc.setTextColor(100, 100, 100);
  doc.text(`Self.hr: ${selfhrCount}/${total}`, 70, 35);
  doc.text(`Ilaria: ${ilariaCount}/${total}`, 126, 35);

  // Group rows by category
  const tableBody: (string | { content: string; styles?: any })[][] = [];
  let lastCategory = "";

  for (const row of comparisonData) {
    const isNewCategory = row.category !== lastCategory;
    if (isNewCategory) {
      tableBody.push([
        { content: row.category, styles: { fontStyle: "bold", fillColor: [235, 240, 255], textColor: [30, 60, 150] } },
        { content: "", styles: { fillColor: [235, 240, 255] } },
        { content: "", styles: { fillColor: [235, 240, 255] } },
        { content: "", styles: { fillColor: [235, 240, 255] } },
        { content: "", styles: { fillColor: [235, 240, 255] } },
      ]);
      lastCategory = row.category;
    }

    const colorize = (val: string) => {
      if (val === "✓" || val.includes("✓")) return { textColor: [0, 140, 60] };
      if (val === "✗") return { textColor: [200, 50, 50] };
      return { textColor: [150, 150, 150] };
    };

    tableBody.push([
      "",
      row.feature,
      { content: row.talentos, styles: { halign: "center", ...colorize(row.talentos) } },
      { content: row.selfhr, styles: { halign: "center", ...colorize(row.selfhr) } },
      { content: row.ilaria, styles: { halign: "center", ...colorize(row.ilaria) } },
    ]);
  }

  autoTable(doc, {
    startY: 39,
    head: [["Category", "Feature", "TalentOS", "Self.hr", "Ilaria"]],
    body: tableBody as any,
    theme: "grid",
    headStyles: {
      fillColor: [41, 98, 255],
      textColor: 255,
      fontSize: 9,
      fontStyle: "bold",
      halign: "center",
    },
    columnStyles: {
      0: { cellWidth: 0.1, overflow: "hidden", textColor: [255, 255, 255], fillColor: [255, 255, 255] },
      1: { cellWidth: 80 },
      2: { cellWidth: 40, halign: "center" },
      3: { cellWidth: 40, halign: "center" },
      4: { cellWidth: 40, halign: "center" },
    },
    styles: {
      fontSize: 8,
      cellPadding: 2,
      lineWidth: 0.1,
      lineColor: [200, 200, 200],
    },
    alternateRowStyles: {
      fillColor: [248, 249, 252],
    },
    margin: { left: 14, right: 14 },
  });

  // Summary page
  doc.addPage();
  doc.setFontSize(16);
  doc.setTextColor(41, 98, 255);
  doc.text("Summary", 14, 20);

  const summaryData = [
    ["Total Features Available", `${talentosCount}/${total}`, `${selfhrCount}/${total}`, `${ilariaCount}/${total}`],
    ["Total Pages/Modules", "80+", "6 modules", "~10 modules"],
    ["Edge Functions", "30+", "N/A", "N/A"],
    ["AI Features", "5+", "None", "None"],
    ["Security Policies (RLS)", "36+", "Unknown", "Unknown"],
    ["Encryption", "AES-256-GCM E2E", "Unknown", "Unknown"],
    ["Team Size", "Growing", "Unknown", "8 employees"],
    ["Clients", "New product", "1,200+", "New product"],
    ["Mobile App", "PWA + Capacitor", "Native iOS/Android", "Native App"],
    ["Self-Hosting", "Docker + On-premise", "SaaS only", "SaaS only"],
    ["Source Code Control", "Full ownership", "Proprietary", "Proprietary"],
    ["Georgian Labor Law", "Full compliance", "Full compliance", "Full compliance"],
    ["HR Outsourcing Service", "Software only", "Unknown", "₾1,500/mo"],
    ["Pricing (Software)", "From ₾350/month", "Unknown", "From ₾500/month"],
  ];

  autoTable(doc, {
    startY: 26,
    head: [["Metric", "TalentOS", "Self.hr", "Ilaria"]],
    body: summaryData,
    theme: "grid",
    headStyles: {
      fillColor: [41, 98, 255],
      textColor: 255,
      fontSize: 10,
      fontStyle: "bold",
    },
    styles: {
      fontSize: 9,
      cellPadding: 4,
    },
    columnStyles: {
      0: { fontStyle: "bold", cellWidth: 70 },
      1: { cellWidth: 55, halign: "center" },
      2: { cellWidth: 55, halign: "center" },
      3: { cellWidth: 55, halign: "center" },
    },
    margin: { left: 14, right: 14 },
  });

  // Advantages page
  doc.addPage();
  doc.setFontSize(16);
  doc.setTextColor(41, 98, 255);
  doc.text("TalentOS Unique Advantages", 14, 20);

  const advantages = [
    ["AI-Powered HR", "AI Assistant (Nina), CV Analysis, Smart Notifications, Budget Forecast - no competitor offers AI"],
    ["Enterprise Security", "AES-256-GCM encryption, IDS, IP anomaly detection, masked PII views, 36+ RLS policies"],
    ["Task Management", "Kanban boards, projects, subtasks, comments - built-in project management"],
    ["Gamification", "Points, badges, team challenges, rewards - unique employee engagement system"],
    ["Self-Hosting", "Full Docker deployment, on-premise option, source code ownership"],
    ["Communication Suite", "Real-time chat, video calls, SMS - complete internal communication"],
    ["Advanced Time Tracking", "GPS geofencing, suspicious location alerts, auto-checkout"],
    ["Financial Management", "Budget planning, expense management, pension payments, comprehensive reporting"],
    ["Lower Price Point", "Starting from ₾350/mo vs Ilaria ₾500/mo - more features for less"],
    ["CRM & Assets", "Built-in contacts/deals CRM and asset management - no competitor has this"],
  ];

  autoTable(doc, {
    startY: 26,
    head: [["Advantage", "Description"]],
    body: advantages,
    theme: "grid",
    headStyles: {
      fillColor: [0, 140, 60],
      textColor: 255,
      fontSize: 10,
      fontStyle: "bold",
    },
    styles: {
      fontSize: 9,
      cellPadding: 4,
    },
    columnStyles: {
      0: { fontStyle: "bold", cellWidth: 60 },
      1: { cellWidth: 180 },
    },
    margin: { left: 14, right: 14 },
  });

  // Footer on all pages
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(7);
    doc.setTextColor(150, 150, 150);
    doc.text(
      `TalentOS vs Self.hr vs Ilaria | Page ${i} of ${pageCount} | Generated: ${new Date().toLocaleString("ka-GE")}`,
      14,
      doc.internal.pageSize.height - 8
    );
  }

  doc.save(`TalentOS-Comparison-${new Date().toISOString().split("T")[0]}.pdf`);
}
