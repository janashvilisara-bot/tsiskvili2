export type Verdict = "pass" | "borderline" | "fail";

export const P95_LIMIT_MS = 1000;
export const ERROR_LIMIT = 0.01;

export function percentile(sorted: number[], p: number): number {
  if (!sorted.length) return 0;
  const idx = Math.min(sorted.length - 1, Math.ceil((p / 100) * sorted.length) - 1);
  return sorted[Math.max(0, idx)];
}

/** pass: p95 < 1s and errors < 1%; fail: p95 >= 2s or errors >= 5%; otherwise borderline. */
export function verdictFor(p95: number, errorRate: number): Verdict {
  if (p95 < P95_LIMIT_MS && errorRate < ERROR_LIMIT) return "pass";
  if (p95 >= P95_LIMIT_MS * 2 || errorRate >= ERROR_LIMIT * 5) return "fail";
  return "borderline";
}

/** Split N virtual users into batches of at most 50 per server call. */
export function splitBatches(users: number, size = 50): number[] {
  const out: number[] = [];
  for (let left = users; left > 0; left -= size) out.push(Math.min(size, left));
  return out;
}

export type LoadMode = "realistic" | "stress";
/** A real employee makes about one request every 15 seconds. */
export const REAL_USER_INTERVAL_SEC = 15;
export function equivalentRealUsers(rps: number): number {
  return Math.round(rps * REAL_USER_INTERVAL_SEC);
}

/** Random delay before a virtual user's first request, so users don't all fire at once. */
export function initialDelayMs(mode: LoadMode, rand: number): number {
  const windowMs = mode === "stress" ? 1000 : 15000;
  return Math.floor(Math.min(Math.max(rand, 0), 0.999999) * windowMs);
}
export const WARMUP_MS = 5000;

/** Stress mode: judged by capacity — errors < 1% and equivalent real users >= selected users means pass. */
export function overallVerdict(mode: LoadMode, p95: number, errorRate: number, rps: number, users: number): Verdict {
  if (mode === "stress" && errorRate < ERROR_LIMIT && equivalentRealUsers(rps) >= users) return "pass";
  return verdictFor(p95, errorRate);
}
