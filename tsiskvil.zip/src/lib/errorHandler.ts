/**
 * ცენტრალიზებული ერორ-ჰენდლერი
 * ტექნიკური დეტალები იფარება მომხმარებლისგან, მხოლოდ ლოგებში ჩაიწერება
 */

// ერორის ტიპები
export type ErrorSeverity = 'low' | 'medium' | 'high' | 'critical';

export interface SanitizedError {
  userMessage: string;
  userMessageEn: string;
  severity: ErrorSeverity;
  errorCode: string;
  canRetry: boolean;
}

// ერორის პატერნები რომლებიც უნდა დაიფაროს
const SENSITIVE_PATTERNS = [
  /password/i,
  /secret/i,
  /api[_-]?key/i,
  /token/i,
  /auth/i,
  /credential/i,
  /private/i,
  /salt/i,
  /hash/i,
];

// DB-სპეციფიკური ერორები
const DB_ERROR_PATTERNS = [
  { pattern: /duplicate key/i, code: 'DB_DUPLICATE', severity: 'low' as ErrorSeverity },
  { pattern: /foreign key/i, code: 'DB_REFERENCE', severity: 'medium' as ErrorSeverity },
  { pattern: /not null/i, code: 'DB_REQUIRED', severity: 'low' as ErrorSeverity },
  { pattern: /permission denied/i, code: 'DB_PERMISSION', severity: 'high' as ErrorSeverity },
  { pattern: /does not exist/i, code: 'DB_NOT_FOUND', severity: 'medium' as ErrorSeverity },
  { pattern: /violates check constraint/i, code: 'DB_VALIDATION', severity: 'low' as ErrorSeverity },
  { pattern: /row-level security/i, code: 'DB_RLS', severity: 'high' as ErrorSeverity },
  { pattern: /timeout/i, code: 'DB_TIMEOUT', severity: 'medium' as ErrorSeverity },
  { pattern: /connection/i, code: 'DB_CONNECTION', severity: 'critical' as ErrorSeverity },
];

// API-სპეციფიკური ერორები
const API_ERROR_PATTERNS = [
  { pattern: /401|unauthorized/i, code: 'AUTH_UNAUTHORIZED', severity: 'medium' as ErrorSeverity },
  { pattern: /403|forbidden/i, code: 'AUTH_FORBIDDEN', severity: 'high' as ErrorSeverity },
  { pattern: /404|not found/i, code: 'NOT_FOUND', severity: 'low' as ErrorSeverity },
  { pattern: /429|too many/i, code: 'RATE_LIMIT', severity: 'medium' as ErrorSeverity },
  { pattern: /500|internal server/i, code: 'SERVER_ERROR', severity: 'high' as ErrorSeverity },
  { pattern: /502|bad gateway/i, code: 'GATEWAY_ERROR', severity: 'high' as ErrorSeverity },
  { pattern: /503|unavailable/i, code: 'SERVICE_DOWN', severity: 'critical' as ErrorSeverity },
  { pattern: /network|fetch|cors/i, code: 'NETWORK_ERROR', severity: 'medium' as ErrorSeverity },
];

// მომხმარებლისთვის გასაგები მესიჯები
const USER_MESSAGES: Record<string, { ka: string; en: string; canRetry: boolean }> = {
  DB_DUPLICATE: { ka: 'ასეთი ჩანაწერი უკვე არსებობს', en: 'This record already exists', canRetry: false },
  DB_REFERENCE: { ka: 'დაკავშირებული ჩანაწერი ვერ მოიძებნა', en: 'Related record not found', canRetry: false },
  DB_REQUIRED: { ka: 'გთხოვთ შეავსოთ ყველა სავალდებულო ველი', en: 'Please fill in all required fields', canRetry: false },
  DB_PERMISSION: { ka: 'თქვენ არ გაქვთ ამ მოქმედების უფლება', en: 'You do not have permission for this action', canRetry: false },
  DB_NOT_FOUND: { ka: 'მოთხოვნილი ინფორმაცია ვერ მოიძებნა', en: 'Requested information not found', canRetry: false },
  DB_VALIDATION: { ka: 'შეყვანილი მონაცემები არასწორია', en: 'The entered data is invalid', canRetry: false },
  DB_RLS: { ka: 'წვდომა შეზღუდულია', en: 'Access is restricted', canRetry: false },
  DB_TIMEOUT: { ka: 'მოთხოვნას დრო გაუვიდა. სცადეთ ხელახლა', en: 'Request timed out. Please try again', canRetry: true },
  DB_CONNECTION: { ka: 'სერვერთან კავშირი ვერ დამყარდა', en: 'Could not connect to server', canRetry: true },
  AUTH_UNAUTHORIZED: { ka: 'გთხოვთ გაიაროთ ავტორიზაცია', en: 'Please log in to continue', canRetry: false },
  AUTH_FORBIDDEN: { ka: 'თქვენ არ გაქვთ ამ რესურსზე წვდომა', en: 'You do not have access to this resource', canRetry: false },
  NOT_FOUND: { ka: 'მოთხოვნილი გვერდი ვერ მოიძებნა', en: 'Requested page not found', canRetry: false },
  RATE_LIMIT: { ka: 'ძალიან ბევრი მოთხოვნა. დაელოდეთ რამდენიმე წამს', en: 'Too many requests. Please wait a moment', canRetry: true },
  SERVER_ERROR: { ka: 'სერვერზე დაფიქსირდა შეცდომა', en: 'A server error occurred', canRetry: true },
  GATEWAY_ERROR: { ka: 'სერვისი დროებით მიუწვდომელია', en: 'Service temporarily unavailable', canRetry: true },
  SERVICE_DOWN: { ka: 'სერვისი დროებით მიუწვდომელია', en: 'Service temporarily unavailable', canRetry: true },
  NETWORK_ERROR: { ka: 'ქსელური კავშირის პრობლემა', en: 'Network connection issue', canRetry: true },
  UNKNOWN: { ka: 'დაფიქსირდა შეცდომა. სცადეთ მოგვიანებით', en: 'An error occurred. Please try again later', canRetry: true },
};

/**
 * შეამოწმებს შეიცავს თუ არა ერორი სენსიტიურ ინფორმაციას
 */
function containsSensitiveInfo(message: string): boolean {
  return SENSITIVE_PATTERNS.some(pattern => pattern.test(message));
}

/**
 * ერორის კატეგორიზაცია
 */
function categorizeError(error: unknown): { code: string; severity: ErrorSeverity } {
  const errorMessage = error instanceof Error ? error.message : String(error);
  
  // DB ერორების შემოწმება
  for (const { pattern, code, severity } of DB_ERROR_PATTERNS) {
    if (pattern.test(errorMessage)) {
      return { code, severity };
    }
  }
  
  // API ერორების შემოწმება
  for (const { pattern, code, severity } of API_ERROR_PATTERNS) {
    if (pattern.test(errorMessage)) {
      return { code, severity };
    }
  }
  
  return { code: 'UNKNOWN', severity: 'medium' };
}

/**
 * ერორის დალოგვა (მხოლოდ development-ში console-ზე, production-ში სერვერზე)
 */
function logError(error: unknown, context?: string): void {
  const timestamp = new Date().toISOString();
  const errorMessage = error instanceof Error ? error.message : String(error);
  const stack = error instanceof Error ? error.stack : undefined;
  
  const logData = {
    timestamp,
    context,
    message: errorMessage,
    stack,
    userAgent: typeof window !== 'undefined' ? window.navigator.userAgent : undefined,
    url: typeof window !== 'undefined' ? window.location.href : undefined,
  };
  
  // Development-ში ვაჩვენებთ console-ზე
  if (process.env.NODE_ENV === 'development') {
    console.error('[ErrorHandler]', logData);
  }
  
  // Production-ში შეგვიძლია გავაგზავნოთ logging სერვისზე
  // TODO: Implement server-side logging if needed
}

/**
 * ერორის სანიტიზაცია მომხმარებლისთვის
 */
export function sanitizeError(error: unknown, context?: string): SanitizedError {
  // დავლოგოთ ორიგინალი ერორი
  logError(error, context);
  
  const { code, severity } = categorizeError(error);
  const messages = USER_MESSAGES[code] || USER_MESSAGES.UNKNOWN;
  
  return {
    userMessage: messages.ka,
    userMessageEn: messages.en,
    severity,
    errorCode: code,
    canRetry: messages.canRetry,
  };
}

/**
 * Toast-ისთვის მზა ერორ-მესიჯის მიღება
 */
export function getErrorMessage(error: unknown, context?: string): string {
  const sanitized = sanitizeError(error, context);
  return sanitized.userMessage;
}

/**
 * Supabase ერორის სანიტიზაცია
 */
export function sanitizeSupabaseError(error: { message?: string; code?: string } | null): string {
  if (!error) return USER_MESSAGES.UNKNOWN.ka;
  
  const fullError = `${error.code || ''} ${error.message || ''}`;
  return getErrorMessage(fullError, 'supabase');
}

/**
 * API Response ერორის სანიტიზაცია
 */
export function sanitizeApiError(response: Response): string {
  const statusErrors: Record<number, string> = {
    400: USER_MESSAGES.DB_VALIDATION.ka,
    401: USER_MESSAGES.AUTH_UNAUTHORIZED.ka,
    403: USER_MESSAGES.AUTH_FORBIDDEN.ka,
    404: USER_MESSAGES.NOT_FOUND.ka,
    429: USER_MESSAGES.RATE_LIMIT.ka,
    500: USER_MESSAGES.SERVER_ERROR.ka,
    502: USER_MESSAGES.GATEWAY_ERROR.ka,
    503: USER_MESSAGES.SERVICE_DOWN.ka,
  };
  
  return statusErrors[response.status] || USER_MESSAGES.UNKNOWN.ka;
}

/**
 * ერორ-ბაუნდარისთვის სანიტიზებული ინფორმაცია
 */
export function getErrorBoundaryMessage(error: Error): {
  title: string;
  description: string;
  showDetails: boolean;
} {
  const isDev = process.env.NODE_ENV === 'development';
  
  return {
    title: 'რაღაც შეცდომა მოხდა',
    description: 'ბოდიშს გიხდით, აპლიკაციაში შეცდომა დაფიქსირდა. გთხოვთ განაახლოთ გვერდი.',
    showDetails: isDev,
  };
}
