import { z } from 'zod';

/**
 * Strong password validation schema
 * Requirements:
 * - Minimum 12 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one number
 * - At least one special character
 */
export const strongPasswordSchema = z
  .string()
  .min(12, { message: 'პაროლი უნდა შეიცავდეს მინიმუმ 12 სიმბოლოს' })
  .regex(/[A-Z]/, { message: 'პაროლი უნდა შეიცავდეს მინიმუმ ერთ დიდ ასოს (A-Z)' })
  .regex(/[a-z]/, { message: 'პაროლი უნდა შეიცავდეს მინიმუმ ერთ პატარა ასოს (a-z)' })
  .regex(/[0-9]/, { message: 'პაროლი უნდა შეიცავდეს მინიმუმ ერთ ციფრს (0-9)' })
  .regex(/[!@#$%^&*(),.?":{}|<>]/, { message: 'პაროლი უნდა შეიცავდეს მინიმუმ ერთ სპეციალურ სიმბოლოს (!@#$%^&*...)' });

/**
 * Password strength checker
 */
export function getPasswordStrength(password: string): {
  score: number;
  label: string;
  color: string;
} {
  let score = 0;

  if (password.length >= 12) score += 1;
  if (password.length >= 16) score += 1;
  if (/[A-Z]/.test(password)) score += 1;
  if (/[a-z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) score += 1;

  if (score <= 2) {
    return { score, label: 'სუსტი', color: 'text-destructive' };
  } else if (score <= 4) {
    return { score, label: 'საშუალო', color: 'text-yellow-500' };
  } else {
    return { score, label: 'ძლიერი', color: 'text-green-500' };
  }
}

/**
 * Generate a secure random password
 */
export function generateSecurePassword(length: number = 14): string {
  const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lowercase = 'abcdefghijklmnopqrstuvwxyz';
  const numbers = '0123456789';
  const special = '!@#$%^&*';
  const allChars = uppercase + lowercase + numbers + special;

  // Ensure at least one of each required type
  let password = '';
  password += uppercase[Math.floor(Math.random() * uppercase.length)];
  password += lowercase[Math.floor(Math.random() * lowercase.length)];
  password += numbers[Math.floor(Math.random() * numbers.length)];
  password += special[Math.floor(Math.random() * special.length)];

  // Fill the rest with random characters
  for (let i = password.length; i < length; i++) {
    password += allChars[Math.floor(Math.random() * allChars.length)];
  }

  // Shuffle the password
  return password
    .split('')
    .sort(() => Math.random() - 0.5)
    .join('');
}

/**
 * Check common weak passwords
 */
const COMMON_WEAK_PASSWORDS = [
  'password', 'password1', '123456', '12345678', 'qwerty', 'abc123',
  'letmein', 'welcome', 'admin', 'login', 'pass1234', 'test1234'
];

export function isCommonPassword(password: string): boolean {
  return COMMON_WEAK_PASSWORDS.includes(password.toLowerCase());
}
