import ExcelJS from 'exceljs';

interface DailyAttendance {
  date: string;
  check_in: string | null;
  check_out: string | null;
  hours: number;
  status: string;
}

interface WorkTimeRecord {
  employee_id: string;
  employee_name: string;
  employee_number: string;
  personal_id: string;
  position: string;
  department: string;
  salary: number;
  total_hours: number;
  regular_hours: number;
  overtime_hours: number;
  night_overtime_hours: number;
  rest_holiday_hours: number;
  vacation_days: number;
  absence_days: number;
  worked_days: number;
  other: number;
  daily_records: { [key: string]: DailyAttendance };
  planned_hours: number;
  paid_maternity_leave_days: number;
  unpaid_maternity_leave_days: number;
  business_trip_days: number;
  weekend_business_trip_days: number;
  total_business_trip_days: number;
  night_work_hours: number;
  rest_day_work_hours: number;
  paid_overtime_hours: number;
  unpaid_overtime_hours: number;
}

interface OrganizationInfo {
  name: string;
  address: string;
  phone: string;
  email: string;
}

export const exportDetailedWorkTimeToExcel = async (
  records: WorkTimeRecord[],
  orgInfo: OrganizationInfo | null,
  startDate: string,
  endDate: string,
  filename: string
) => {
  try {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('დეტალური ანგარიში');

    // Get month details
    const startMonth = new Date(startDate).getMonth();
    const startYear = new Date(startDate).getFullYear();
    const daysInMonth = new Date(startYear, startMonth + 1, 0).getDate();

    // Table Headers
    const headerRow = [
      'თანამშრომელი',
      'ორგანიზაცია',
      'საშტატო',
      'ტაბელის ნომერი',
      'პირადი ნომერი',
      'თანამდებობა',
      'სტრუქტურული ერთეული',
      'ძირითადი სტრუქტურული ერთეული',
      'ხელფასი',
      'გრაფიკით ნამუშევარი დღეები',
      'რეალურად ნამუშევარი დღე',
      'გაცდენილი დღე',
      'გრაფ. სამუშაო დრო',
      'სრული ნამუშევარი საათები',
      'სტანდარტული ნამუშევარი საათები',
      'დაგვიანებული საათები',
      'ზეგანაკვეთური',
      'ხელფასიანი შვებულება',
      'უხელფასო შვებულება',
      'ბიულეტინი',
      'ღამე ნამუშევარი საათები',
      'ხელფასიანი დეკრეტული',
      'უხელფასო დეკრეტული',
      'მივლინება',
      'უქმე დღის მივლინება',
      'მივლინების ჯამი',
      'დასვენების დღეებში ნამუშევარი დრო',
      'ანაზღაურებადი მოცდენილი საათები',
      'არაანაზღაურებადი მოცდენილი საათები'
    ];

    // Add day columns
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(startYear, startMonth, day);
      const dayName = date.toLocaleDateString('ka-GE', { weekday: 'short' });
      headerRow.push(`${String(day).padStart(2, '0')} ${getGeorgianMonth(startMonth)}, ${dayName}`);
    }

    // Set up columns
    worksheet.columns = headerRow.map((header, idx) => ({
      header,
      key: `col${idx}`,
      width: idx < 29 ? getColumnWidth(idx) : 12
    }));

    // Data rows
    records.forEach(record => {
      const plannedDays = Math.ceil(record.planned_hours / 8);
      
      const rowData: any = {
        col0: record.employee_name,
        col1: orgInfo?.name || 'კომპანია',
        col2: '',
        col3: record.employee_number,
        col4: record.personal_id,
        col5: record.position,
        col6: record.department,
        col7: '',
        col8: record.salary || 0,
        col9: plannedDays,
        col10: record.worked_days,
        col11: record.absence_days,
        col12: record.planned_hours.toFixed(2),
        col13: record.total_hours.toFixed(2),
        col14: record.regular_hours.toFixed(2),
        col15: 0,
        col16: record.overtime_hours.toFixed(2),
        col17: record.vacation_days,
        col18: 0,
        col19: 0,
        col20: record.night_overtime_hours.toFixed(2),
        col21: record.paid_maternity_leave_days,
        col22: record.unpaid_maternity_leave_days,
        col23: record.business_trip_days,
        col24: record.weekend_business_trip_days,
        col25: record.total_business_trip_days,
        col26: record.rest_day_work_hours.toFixed(2),
        col27: record.paid_overtime_hours.toFixed(2),
        col28: record.unpaid_overtime_hours.toFixed(2)
      };

      // Add daily hours
      for (let day = 1; day <= daysInMonth; day++) {
        const dateKey = `${startYear}-${String(startMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const dailyRecord = record.daily_records[dateKey];
        
        if (dailyRecord && dailyRecord.hours > 0) {
          rowData[`col${28 + day}`] = dailyRecord.hours.toFixed(2);
        } else {
          rowData[`col${28 + day}`] = '';
        }
      }

      worksheet.addRow(rowData);
    });

    // Style header row
    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    // Download
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}.xlsx`;
    link.click();
    window.URL.revokeObjectURL(url);

    return true;
  } catch (error) {
    console.error('Excel export error:', error);
    return false;
  }
};

function getColumnWidth(idx: number): number {
  const widths = [25, 20, 10, 15, 15, 25, 25, 25, 12, 20, 20, 15, 15, 20, 25, 20, 15, 20, 20, 12, 20, 20, 20, 15, 20, 18, 25, 25, 28];
  return widths[idx] || 15;
}

function getGeorgianMonth(monthIndex: number): string {
  const months = [
    'იან', 'თებ', 'მარ', 'აპრ', 'მაი', 'ივნ',
    'ივლ', 'აგვ', 'სექ', 'ოქტ', 'ნოე', 'დეკ'
  ];
  return months[monthIndex];
}
