import ExcelJS from 'exceljs';

// Helper function to create and download workbook
export const downloadWorkbook = async (workbook: ExcelJS.Workbook, filename: string) => {
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`;
  link.click();
  window.URL.revokeObjectURL(url);
};

// Helper to add styled header row
export const addStyledHeaderRow = (worksheet: ExcelJS.Worksheet, rowNumber: number = 1) => {
  const row = worksheet.getRow(rowNumber);
  row.font = { bold: true };
  row.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };
  row.alignment = { horizontal: 'center' };
};

// Helper to set column widths from array of objects
export const autoSizeColumns = (worksheet: ExcelJS.Worksheet, data: any[], minWidth: number = 10, maxWidth: number = 50) => {
  if (data.length === 0) return;
  
  const headers = Object.keys(data[0]);
  worksheet.columns = headers.map(header => ({
    header,
    key: header,
    width: Math.min(
      Math.max(
        header.length,
        ...data.map(row => String(row[header] || '').length),
        minWidth
      ),
      maxWidth
    )
  }));
};

// Convert array of arrays to ExcelJS rows
export const addArrayData = (worksheet: ExcelJS.Worksheet, data: any[][]) => {
  data.forEach(row => {
    worksheet.addRow(row);
  });
};

// Style a range of cells
export const styleRange = (
  worksheet: ExcelJS.Worksheet, 
  startRow: number, 
  startCol: number, 
  endRow: number, 
  endCol: number,
  style: Partial<ExcelJS.Style>
) => {
  for (let row = startRow; row <= endRow; row++) {
    for (let col = startCol; col <= endCol; col++) {
      const cell = worksheet.getCell(row, col);
      Object.assign(cell, style);
    }
  }
};
