import {
  Document,
  Paragraph,
  Table,
  TableRow,
  TableCell,
  TextRun,
  HeadingLevel,
  AlignmentType,
  WidthType,
  BorderStyle,
  Packer,
  ShadingType,
} from "docx";
import { saveAs } from "file-saver";

interface ComparisonRow {
  category: string;
  feature: string;
  talentos: string;
  selfhr: string;
  ilaria: string;
}

const comparisonData: ComparisonRow[] = [
  // HR Administration
  { category: "HR Administration", feature: "Employee Profiles", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "HR Administration", feature: "Organizational Structure (Visual Chart)", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "HR Administration", feature: "Departments / Positions", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "HR Administration", feature: "Multi-Company Support", talentos: "✓", selfhr: "-", ilaria: "✗" },

  { category: "Documents", feature: "Document Management", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Documents", feature: "AI Contract Generation", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "Documents", feature: "Contract Templates", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Documents", feature: "Electronic Signature", talentos: "✓", selfhr: "-", ilaria: "✗" },

  { category: "Time Tracking", feature: "Attendance Tracking", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Time Tracking", feature: "Shift Schedules", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Time Tracking", feature: "Work-Time Reports", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Time Tracking", feature: "GPS / Geofencing", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Time Tracking", feature: "Mobile Check-in/out", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Time Tracking", feature: "Suspicious Location Alerts", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Time Tracking", feature: "Auto-Checkout", talentos: "✓", selfhr: "✗", ilaria: "✗" },

  { category: "Payroll & Finance", feature: "Salary Calculation", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Payroll & Finance", feature: "Benefits Administration", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Payroll & Finance", feature: "Pension Payments", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "Payroll & Finance", feature: "Budget Planning", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Payroll & Finance", feature: "Expense Management", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Payroll & Finance", feature: "Compensation & Bonuses", talentos: "✓", selfhr: "-", ilaria: "-" },
  { category: "Payroll & Finance", feature: "Financial Reports", talentos: "✓", selfhr: "✓", ilaria: "✓" },

  { category: "Leave Management", feature: "Leave Requests", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Leave Management", feature: "Leave Types", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Leave Management", feature: "Leave Statistics", talentos: "✓", selfhr: "-", ilaria: "-" },
  { category: "Leave Management", feature: "Public Holidays", talentos: "✓", selfhr: "✓", ilaria: "✓" },

  { category: "Recruitment", feature: "Vacancy Management", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Recruitment", feature: "Candidate Database", talentos: "✓", selfhr: "✓", ilaria: "✓" },
  { category: "Recruitment", feature: "AI CV Analysis & Matching", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Recruitment", feature: "Onboarding", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Recruitment", feature: "Job Descriptions", talentos: "✓", selfhr: "-", ilaria: "✓" },

  { category: "Training & Development", feature: "Training Courses", talentos: "✓", selfhr: "✗", ilaria: "✓" },
  { category: "Training & Development", feature: "Video Tutorials", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Training & Development", feature: "OKR Management", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Training & Development", feature: "Performance Reviews", talentos: "✓", selfhr: "✗", ilaria: "-" },
  { category: "Training & Development", feature: "Employee Evaluations", talentos: "✓", selfhr: "✗", ilaria: "-" },

  { category: "Task Management", feature: "Kanban Board", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Task Management", feature: "Projects & Subtasks", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Task Management", feature: "Task Comments", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Task Management", feature: "Priority & Deadlines", talentos: "✓", selfhr: "✗", ilaria: "✗" },

  { category: "Communication", feature: "Real-time Chat", talentos: "✓", selfhr: "✓", ilaria: "✗" },
  { category: "Communication", feature: "SMS Notifications", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Communication", feature: "Announcements", talentos: "✓", selfhr: "✓", ilaria: "-" },
  { category: "Communication", feature: "Video Calls", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Communication", feature: "Email Notifications", talentos: "✓", selfhr: "-", ilaria: "-" },

  { category: "Gamification", feature: "Points System", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Gamification", feature: "Badges & Achievements", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Gamification", feature: "Team Challenges", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Gamification", feature: "Rewards Catalog", talentos: "✓", selfhr: "✗", ilaria: "✗" },

  { category: "AI Features", feature: "AI Assistant (Nina)", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "AI Features", feature: "AI CV Analysis", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "AI Features", feature: "Smart Notifications", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "AI Features", feature: "AI Feedback Recommendations", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "AI Features", feature: "Budget Forecast (AI)", talentos: "✓", selfhr: "✗", ilaria: "✗" },

  { category: "Security", feature: "AES-256-GCM Encryption", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "Security", feature: "36+ RLS Policies", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "Security", feature: "Intrusion Detection (IDS)", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Security", feature: "Masked Views (PII Protection)", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Security", feature: "Audit Logs", talentos: "✓", selfhr: "-", ilaria: "-" },
  { category: "Security", feature: "IP/Geo Anomaly Detection", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Security", feature: "Rate Limiting", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "Security", feature: "Soft Delete & Recovery", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "Security", feature: "GDPR / Georgian Law Compliance", talentos: "✓", selfhr: "✓", ilaria: "✓" },

  { category: "System", feature: "Self-Hosting (Docker)", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "System", feature: "Database Backup / Restore", talentos: "✓", selfhr: "-", ilaria: "-" },
  { category: "System", feature: "Mobile App (PWA / Native)", talentos: "PWA", selfhr: "Native", ilaria: "Native" },
  { category: "System", feature: "Role Management (RBAC)", talentos: "✓ Custom", selfhr: "✓", ilaria: "-" },
  { category: "System", feature: "Calendar View", talentos: "✓", selfhr: "-", ilaria: "-" },
  { category: "System", feature: "Support Tickets", talentos: "✓", selfhr: "-", ilaria: "✗" },
  { category: "System", feature: "Business Trips", talentos: "✓", selfhr: "✓", ilaria: "✗" },
  { category: "System", feature: "Vehicle Requests", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "System", feature: "Asset Management", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "System", feature: "CRM (Contacts & Deals)", talentos: "✓", selfhr: "✗", ilaria: "✗" },
  { category: "System", feature: "Disciplinary Actions", talentos: "✓", selfhr: "✗", ilaria: "-" },
  { category: "System", feature: "Wellness Surveys", talentos: "✓", selfhr: "✓", ilaria: "✗" },
];

const BLUE = "2962FF";
const GREEN = "008C3C";
const RED = "C83232";
const GRAY = "969696";
const LIGHT_BLUE_BG = "EBF0FF";
const ALT_ROW_BG = "F8F9FC";

function getColor(val: string): string {
  if (val === "✓" || val.includes("✓")) return GREEN;
  if (val === "✗") return RED;
  return GRAY;
}

function createHeaderCell(text: string): TableCell {
  return new TableCell({
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text, bold: true, color: "FFFFFF", size: 20, font: "Calibri" })],
      }),
    ],
    shading: { type: ShadingType.SOLID, color: BLUE },
    verticalAlign: "center" as any,
  });
}

function createCell(text: string, options?: { bold?: boolean; color?: string; align?: typeof AlignmentType.CENTER; bg?: string }): TableCell {
  return new TableCell({
    children: [
      new Paragraph({
        alignment: options?.align || AlignmentType.LEFT,
        children: [
          new TextRun({
            text,
            bold: options?.bold || false,
            color: options?.color || "333333",
            size: 18,
            font: "Calibri",
          }),
        ],
      }),
    ],
    ...(options?.bg ? { shading: { type: ShadingType.SOLID, color: options.bg } } : {}),
  });
}

export async function exportComparisonWord() {
  const rows: TableRow[] = [];

  // Header row
  rows.push(
    new TableRow({
      children: [
        createHeaderCell("Category"),
        createHeaderCell("Feature"),
        createHeaderCell("TalentOS"),
        createHeaderCell("Self.hr"),
        createHeaderCell("Ilaria"),
      ],
      tableHeader: true,
    })
  );

  let lastCategory = "";
  let rowIndex = 0;

  for (const item of comparisonData) {
    if (item.category !== lastCategory) {
      // Category header row
      rows.push(
        new TableRow({
          children: [
            createCell(item.category, { bold: true, color: "1E3C96", bg: LIGHT_BLUE_BG }),
            createCell("", { bg: LIGHT_BLUE_BG }),
            createCell("", { bg: LIGHT_BLUE_BG }),
            createCell("", { bg: LIGHT_BLUE_BG }),
            createCell("", { bg: LIGHT_BLUE_BG }),
          ],
        })
      );
      lastCategory = item.category;
    }

    const bg = rowIndex % 2 === 0 ? undefined : ALT_ROW_BG;
    rows.push(
      new TableRow({
        children: [
          createCell("", { bg }),
          createCell(item.feature, { bg }),
          createCell(item.talentos, { color: getColor(item.talentos), align: AlignmentType.CENTER, bold: true, bg }),
          createCell(item.selfhr, { color: getColor(item.selfhr), align: AlignmentType.CENTER, bold: true, bg }),
          createCell(item.ilaria, { color: getColor(item.ilaria), align: AlignmentType.CENTER, bold: true, bg }),
        ],
      })
    );
    rowIndex++;
  }

  // Summary data
  const talentosCount = comparisonData.filter(r => r.talentos === "✓" || r.talentos.includes("✓")).length;
  const selfhrCount = comparisonData.filter(r => r.selfhr === "✓").length;
  const ilariaCount = comparisonData.filter(r => r.ilaria === "✓").length;
  const total = comparisonData.length;

  const summaryRows = [
    ["Total Features Available", `${talentosCount}/${total}`, `${selfhrCount}/${total}`, `${ilariaCount}/${total}`],
    ["Total Pages/Modules", "80+", "~6 modules", "~10 modules"],
    ["Edge Functions", "30+", "N/A", "N/A"],
    ["AI Features", "5+", "None", "None"],
    ["Security Policies (RLS)", "36+", "Unknown", "Unknown"],
    ["Encryption", "AES-256-GCM E2E", "Unknown", "Unknown"],
    ["Clients", "New product", "1,200+", "New product"],
    ["Mobile App", "PWA + Capacitor", "Native iOS/Android", "Native App"],
    ["Self-Hosting", "Docker + On-premise", "SaaS only", "SaaS only"],
    ["Source Code Control", "Full ownership", "Proprietary", "Proprietary"],
    ["Georgian Labor Law", "Full compliance", "Full compliance", "Full compliance"],
    ["Pricing (Software)", "From ₾350/month", "Unknown", "From ₾500/month"],
  ];

  const summaryTableRows: TableRow[] = [
    new TableRow({
      children: [
        createHeaderCell("Metric"),
        createHeaderCell("TalentOS"),
        createHeaderCell("Self.hr"),
        createHeaderCell("Ilaria"),
      ],
      tableHeader: true,
    }),
  ];

  summaryRows.forEach((row, i) => {
    const bg = i % 2 === 0 ? undefined : ALT_ROW_BG;
    summaryTableRows.push(
      new TableRow({
        children: [
          createCell(row[0], { bold: true, bg }),
          createCell(row[1], { align: AlignmentType.CENTER, bg }),
          createCell(row[2], { align: AlignmentType.CENTER, bg }),
          createCell(row[3], { align: AlignmentType.CENTER, bg }),
        ],
      })
    );
  });

  // Advantages
  const advantages = [
    ["AI-Powered HR", "AI Assistant (Nina), CV Analysis, Smart Notifications, Budget Forecast - no competitor offers AI"],
    ["Enterprise Security", "AES-256-GCM encryption, IDS, IP anomaly detection, masked PII views, 36+ RLS policies"],
    ["Task Management", "Kanban boards, projects, subtasks, comments - built-in project management"],
    ["Gamification", "Points, badges, team challenges, rewards - unique employee engagement system"],
    ["Self-Hosting", "Full Docker deployment, on-premise option, source code ownership"],
    ["Communication Suite", "Real-time chat, video calls, SMS - complete internal communication"],
    ["Advanced Time Tracking", "GPS geofencing, suspicious location alerts, auto-checkout"],
    ["Financial Management", "Budget planning, expense management, pension payments, comprehensive reporting"],
    ["Lower Price Point", "Starting from ₾350/mo vs Ilaria ₾500/mo - more features for less"],
    ["CRM & Assets", "Built-in contacts/deals CRM and asset management - no competitor has this"],
  ];

  const advantageRows: TableRow[] = [
    new TableRow({
      children: [
        createHeaderCell("Advantage"),
        createHeaderCell("Description"),
      ],
      tableHeader: true,
    }),
  ];

  advantages.forEach((row, i) => {
    const bg = i % 2 === 0 ? undefined : ALT_ROW_BG;
    advantageRows.push(
      new TableRow({
        children: [
          createCell(row[0], { bold: true, bg }),
          createCell(row[1], { bg }),
        ],
      })
    );
  });

  const borderStyle = {
    top: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
    bottom: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
    left: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
    right: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
  };

  const doc = new Document({
    sections: [
      {
        properties: { page: { size: { orientation: "landscape" as any } } },
        children: [
          new Paragraph({
            children: [new TextRun({ text: "TalentOS vs Self.hr vs Ilaria", bold: true, size: 36, color: BLUE, font: "Calibri" })],
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            children: [new TextRun({ text: `Feature Comparison | ${new Date().toLocaleDateString("ka-GE")}`, size: 20, color: "666666", font: "Calibri" })],
            spacing: { after: 100 },
          }),
          new Paragraph({
            children: [new TextRun({ text: "Legend:  ✓ = Available   ✗ = Not Available   - = Unknown/Unconfirmed", size: 16, color: "888888", font: "Calibri" })],
            spacing: { after: 200 },
          }),
          new Paragraph({
            children: [
              new TextRun({ text: `TalentOS: ${talentosCount}/${total}  |  `, bold: true, color: GREEN, size: 20, font: "Calibri" }),
              new TextRun({ text: `Self.hr: ${selfhrCount}/${total}  |  `, color: GRAY, size: 20, font: "Calibri" }),
              new TextRun({ text: `Ilaria: ${ilariaCount}/${total}`, color: GRAY, size: 20, font: "Calibri" }),
            ],
            spacing: { after: 300 },
          }),
          new Table({
            rows,
            width: { size: 100, type: WidthType.PERCENTAGE },
            borders: borderStyle as any,
          }),
        ],
      },
      {
        properties: { page: { size: { orientation: "landscape" as any } } },
        children: [
          new Paragraph({
            children: [new TextRun({ text: "Summary", bold: true, size: 32, color: BLUE, font: "Calibri" })],
            heading: HeadingLevel.HEADING_1,
            spacing: { after: 300 },
          }),
          new Table({
            rows: summaryTableRows,
            width: { size: 100, type: WidthType.PERCENTAGE },
            borders: borderStyle as any,
          }),
        ],
      },
      {
        properties: { page: { size: { orientation: "landscape" as any } } },
        children: [
          new Paragraph({
            children: [new TextRun({ text: "TalentOS Unique Advantages", bold: true, size: 32, color: BLUE, font: "Calibri" })],
            heading: HeadingLevel.HEADING_1,
            spacing: { after: 300 },
          }),
          new Table({
            rows: advantageRows,
            width: { size: 100, type: WidthType.PERCENTAGE },
            borders: borderStyle as any,
          }),
          new Paragraph({ spacing: { before: 400 }, children: [] }),
          new Paragraph({
            children: [
              new TextRun({
                text: `Generated: ${new Date().toLocaleString("ka-GE")}`,
                size: 14,
                color: "999999",
                font: "Calibri",
              }),
            ],
          }),
        ],
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `TalentOS-Comparison-${new Date().toISOString().split("T")[0]}.docx`);
}
