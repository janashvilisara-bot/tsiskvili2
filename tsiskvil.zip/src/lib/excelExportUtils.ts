import ExcelJS from 'exceljs';

/**
 * Utility helper to export data to Excel using ExcelJS
 * This replaces the vulnerable xlsx package
 */
export const createExcelExport = async (
  data: Record<string, any>[],
  filename: string,
  sheetName: string = 'Sheet1'
): Promise<void> => {
  if (data.length === 0) {
    console.warn('No data to export');
    return;
  }

  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet(sheetName);

  // Get headers from first object
  const headers = Object.keys(data[0]);
  worksheet.columns = headers.map(header => ({
    header,
    key: header,
    width: Math.min(Math.max(header.length + 2, 12), 40)
  }));

  // Add data rows
  data.forEach(row => {
    worksheet.addRow(row);
  });

  // Style header row
  worksheet.getRow(1).font = { bold: true };
  worksheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' }
  };
  worksheet.getRow(1).alignment = { horizontal: 'center' };

  // Download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { 
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
  });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`;
  link.click();
  window.URL.revokeObjectURL(url);
};

/**
 * Export array of arrays to Excel (for when data is already formatted)
 */
export const createExcelExportFromArray = async (
  data: any[][],
  filename: string,
  sheetName: string = 'Sheet1',
  headerRowIndex: number = 0
): Promise<void> => {
  if (data.length === 0) {
    console.warn('No data to export');
    return;
  }

  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet(sheetName);

  // Add all rows
  data.forEach((row, index) => {
    const excelRow = worksheet.addRow(row);
    
    // Style header row
    if (index === headerRowIndex) {
      excelRow.font = { bold: true };
      excelRow.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFE0E0E0' }
      };
    }
  });

  // Download
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { 
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
  });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`;
  link.click();
  window.URL.revokeObjectURL(url);
};
