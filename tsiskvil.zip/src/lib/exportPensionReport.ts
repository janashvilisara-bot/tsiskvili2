import ExcelJS from 'exceljs';
import { FINANCIAL_CONSTANTS, getPensionStateRate } from './financialCalculations';

interface PensionReportRow {
  employeeName: string;
  personalId: string;
  pensionAccount: string;
  baseSalary: number;
  employeeContribution: number;
  employerContribution: number;
  stateContribution: number;
  totalContribution: number;
}

interface PensionPaymentData {
  employee_id: string;
  base_salary: number;
  employee_contribution: number;
  employer_contribution: number;
  employee?: {
    full_name: string;
    personal_id_number: string | null;
    pension_account_number: string | null;
  };
}

const MONTHS_KA = [
  '', 'იანვარი', 'თებერვალი', 'მარტი', 'აპრილი', 'მაისი', 'ივნისი',
  'ივლისი', 'აგვისტო', 'სექტემბერი', 'ოქტომბერი', 'ნოემბერი', 'დეკემბერი'
];

export async function exportPensionReport(
  payments: PensionPaymentData[],
  month: number,
  year: number,
  companyName: string = 'კომპანია'
): Promise<boolean> {
  try {
    if (payments.length === 0) return false;

    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'TalentSOS HR';
    workbook.created = new Date();

    const ws = workbook.addWorksheet('საპენსიო რეპორტი', {
      properties: { defaultColWidth: 18 }
    });

    // Title rows
    ws.mergeCells('A1:H1');
    const titleCell = ws.getCell('A1');
    titleCell.value = 'საპენსიო შენატანების ყოველთვიური რეპორტი';
    titleCell.font = { bold: true, size: 14, color: { argb: 'FF1A1A2E' } };
    titleCell.alignment = { horizontal: 'center', vertical: 'middle' };
    ws.getRow(1).height = 30;

    ws.mergeCells('A2:H2');
    const subtitleCell = ws.getCell('A2');
    subtitleCell.value = `${companyName} - ${MONTHS_KA[month]} ${year}`;
    subtitleCell.font = { size: 11, color: { argb: 'FF555555' } };
    subtitleCell.alignment = { horizontal: 'center' };

    ws.mergeCells('A3:H3');
    ws.getCell('A3').value = `გენერირების თარიღი: ${new Date().toLocaleDateString('ka-GE')}`;
    ws.getCell('A3').font = { size: 9, color: { argb: 'FF999999' } };
    ws.getCell('A3').alignment = { horizontal: 'center' };

    // Headers
    const headers = [
      '№', 'თანამშრომელი', 'პირადი ნომერი', 'საპენსიო ანგარიში',
      'ხელფასი (₾)', 'თანამშრომლის შენატანი (2%)',
      'დამსაქმებლის შენატანი (2%)', 'სახელმწიფო (2%/1%/0%)'
    ];

    const headerRow = ws.addRow(headers);
    headerRow.number; // row 5
    ws.getRow(5).height = 28;

    const headerFill: ExcelJS.FillPattern = {
      type: 'pattern', pattern: 'solid',
      fgColor: { argb: 'FF1A1A2E' }
    };
    const headerFont: Partial<ExcelJS.Font> = {
      bold: true, size: 10, color: { argb: 'FFFFFFFF' }
    };

    headerRow.eachCell((cell) => {
      cell.fill = headerFill;
      cell.font = headerFont;
      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      cell.border = {
        top: { style: 'thin' }, bottom: { style: 'thin' },
        left: { style: 'thin' }, right: { style: 'thin' }
      };
    });

    // Data rows
    const monthlyCap = FINANCIAL_CONSTANTS.PENSION_ANNUAL_BASE_CAP / 12;
    const rows: PensionReportRow[] = payments.map(p => {
      const base = Number(p.base_salary) || 0;
      const cappedBase = Math.min(base, monthlyCap);
      const empContrib = Number(p.employee_contribution) || cappedBase * FINANCIAL_CONSTANTS.PENSION_EMPLOYEE_RATE;
      const emplerContrib = Number(p.employer_contribution) || cappedBase * FINANCIAL_CONSTANTS.PENSION_EMPLOYER_RATE;
      const stateRate = getPensionStateRate(base * 12);
      const stateContrib = cappedBase * stateRate;

      return {
        employeeName: p.employee?.full_name || 'უცნობი',
        personalId: p.employee?.personal_id_number || '',
        pensionAccount: p.employee?.pension_account_number || '',
        baseSalary: base,
        employeeContribution: empContrib,
        employerContribution: emplerContrib,
        stateContribution: stateContrib,
        totalContribution: empContrib + emplerContrib + stateContrib,
      };
    });

    const currencyFmt = '#,##0.00" ₾"';
    const borderStyle: Partial<ExcelJS.Borders> = {
      top: { style: 'thin', color: { argb: 'FFE0E0E0' } },
      bottom: { style: 'thin', color: { argb: 'FFE0E0E0' } },
      left: { style: 'thin', color: { argb: 'FFE0E0E0' } },
      right: { style: 'thin', color: { argb: 'FFE0E0E0' } },
    };

    rows.forEach((row, idx) => {
      const dataRow = ws.addRow([
        idx + 1,
        row.employeeName,
        row.personalId,
        row.pensionAccount,
        row.baseSalary,
        row.employeeContribution,
        row.employerContribution,
        row.stateContribution,
      ]);

      const isEven = idx % 2 === 0;
      dataRow.eachCell((cell, colNumber) => {
        cell.border = borderStyle;
        cell.alignment = { vertical: 'middle', horizontal: colNumber <= 4 ? 'left' : 'right' };
        if (isEven) {
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF8F9FA' } };
        }
        if (colNumber >= 5) {
          cell.numFmt = currencyFmt;
        }
        if (colNumber === 1) {
          cell.alignment = { horizontal: 'center', vertical: 'middle' };
        }
      });
    });

    // Totals row
    const lastDataRow = 5 + rows.length;
    const totalsRow = ws.addRow([
      '', 'ჯამი', '', '',
      rows.reduce((s, r) => s + r.baseSalary, 0),
      rows.reduce((s, r) => s + r.employeeContribution, 0),
      rows.reduce((s, r) => s + r.employerContribution, 0),
      rows.reduce((s, r) => s + r.stateContribution, 0),
    ]);

    totalsRow.eachCell((cell, colNumber) => {
      cell.font = { bold: true, size: 11 };
      cell.border = {
        top: { style: 'medium' }, bottom: { style: 'medium' },
        left: { style: 'thin' }, right: { style: 'thin' }
      };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE8F5E9' } };
      if (colNumber >= 5) cell.numFmt = currencyFmt;
      cell.alignment = { horizontal: colNumber >= 5 ? 'right' : 'left', vertical: 'middle' };
    });

    // Summary section
    const summaryStartRow = lastDataRow + 3;
    ws.mergeCells(`A${summaryStartRow}:C${summaryStartRow}`);
    ws.getCell(`A${summaryStartRow}`).value = 'შეჯამება';
    ws.getCell(`A${summaryStartRow}`).font = { bold: true, size: 12 };

    const totalEmpContrib = rows.reduce((s, r) => s + r.employeeContribution, 0);
    const totalEmplContrib = rows.reduce((s, r) => s + r.employerContribution, 0);
    const totalStateContrib = rows.reduce((s, r) => s + r.stateContribution, 0);
    const grandTotal = totalEmpContrib + totalEmplContrib + totalStateContrib;

    const summaryData = [
      ['თანამშრომლების რაოდენობა:', rows.length],
      ['თანამშრომლის შენატანი (2%):', totalEmpContrib],
      ['დამსაქმებლის შენატანი (2%):', totalEmplContrib],
      ['სახელმწიფოს შენატანი (2%):', totalStateContrib],
      ['მთლიანი საპენსიო შენატანი:', grandTotal],
    ];

    summaryData.forEach((item, idx) => {
      const row = ws.getRow(summaryStartRow + 1 + idx);
      row.getCell(1).value = item[0] as string;
      row.getCell(1).font = { size: 10 };
      row.getCell(2).value = item[1] as number;
      row.getCell(2).font = { bold: true, size: 10 };
      if (idx > 0) row.getCell(2).numFmt = currencyFmt;
    });

    // Column widths
    ws.getColumn(1).width = 6;
    ws.getColumn(2).width = 28;
    ws.getColumn(3).width = 18;
    ws.getColumn(4).width = 22;
    ws.getColumn(5).width = 16;
    ws.getColumn(6).width = 24;
    ws.getColumn(7).width = 24;
    ws.getColumn(8).width = 24;

    // Export
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `საპენსიო_რეპორტი_${MONTHS_KA[month]}_${year}.xlsx`;
    link.click();
    URL.revokeObjectURL(url);

    return true;
  } catch (error) {
    console.error('Pension report export failed:', error);
    return false;
  }
}

/**
 * pensions.ge ოფიციალური ფორმატის CSV ექსპორტი (BOM + UTF-8)
 * სვეტები: პირადი ნომერი | სახელი გვარი | საპენსიო ანგ. | ხელფასი | თანამშრომელი 2% | დამსაქმებელი 2% | სახელმწიფო %
 */
export function exportPensionsGeCSV(
  payments: PensionPaymentData[],
  month: number,
  year: number
): boolean {
  try {
    if (payments.length === 0) return false;

    const monthlyCap = FINANCIAL_CONSTANTS.PENSION_ANNUAL_BASE_CAP / 12;
    const header = [
      'personal_id',
      'full_name',
      'pension_account',
      'base_salary',
      'employee_contribution',
      'employer_contribution',
      'state_contribution',
      'period_month',
      'period_year',
    ].join(',');

    const lines = payments.map(p => {
      const base = Number(p.base_salary) || 0;
      const cappedBase = Math.min(base, monthlyCap);
      const emp = Number(p.employee_contribution) || cappedBase * FINANCIAL_CONSTANTS.PENSION_EMPLOYEE_RATE;
      const empl = Number(p.employer_contribution) || cappedBase * FINANCIAL_CONSTANTS.PENSION_EMPLOYER_RATE;
      const stateRate = getPensionStateRate(base * 12);
      const state = cappedBase * stateRate;

      const esc = (v: string) => `"${(v || '').replace(/"/g, '""')}"`;
      return [
        esc(p.employee?.personal_id_number || ''),
        esc(p.employee?.full_name || ''),
        esc(p.employee?.pension_account_number || ''),
        base.toFixed(2),
        emp.toFixed(2),
        empl.toFixed(2),
        state.toFixed(2),
        String(month),
        String(year),
      ].join(',');
    });

    // BOM იმისთვის რომ Excel-მ ქართული სიმბოლოები სწორად აღიქვას
    const csv = '\uFEFF' + header + '\n' + lines.join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `pensions_ge_${year}_${String(month).padStart(2, '0')}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    return true;
  } catch (e) {
    console.error('pensions.ge CSV export failed:', e);
    return false;
  }
}
