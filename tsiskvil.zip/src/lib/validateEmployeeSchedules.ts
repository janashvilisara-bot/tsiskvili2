import { supabase } from "@/integrations/supabase/client";

/**
 * Validates that all active employees have an active work schedule
 * Returns array of employees without schedules
 */
export const validateEmployeeSchedules = async () => {
  try {
    // Get all active employees
    const { data: employees, error: empError } = await supabase
      .from('employees')
      .select('id, full_name, email, position')
      .eq('status', 'active');

    if (empError) throw empError;

    if (!employees || employees.length === 0) {
      return { valid: true, employeesWithoutSchedules: [] };
    }

    const employeeIds = employees.map(e => e.id);

    // Get current date
    const today = new Date().toISOString().split('T')[0];

    // Get all active work schedules
    const { data: schedules, error: schedError } = await supabase
      .from('work_schedules')
      .select('employee_id, effective_from, effective_to')
      .in('employee_id', employeeIds)
      .lte('effective_from', today)
      .or(`effective_to.is.null,effective_to.gte.${today}`);

    if (schedError) throw schedError;

    // Find employees without active schedules
    const employeesWithSchedules = new Set(schedules?.map(s => s.employee_id) || []);
    const employeesWithoutSchedules = employees.filter(
      emp => !employeesWithSchedules.has(emp.id)
    );

    return {
      valid: employeesWithoutSchedules.length === 0,
      employeesWithoutSchedules,
      totalEmployees: employees.length,
      employeesWithSchedules: employeesWithSchedules.size
    };
  } catch (error) {
    console.error('Error validating employee schedules:', error);
    throw error;
  }
};

/**
 * Get employees without active schedules (for display)
 */
export const getEmployeesWithoutSchedules = async () => {
  const result = await validateEmployeeSchedules();
  return result.employeesWithoutSchedules;
};
