import { format as dateFnsFormat, parseISO, type Locale } from "date-fns";
import { ka } from "date-fns/locale";
import { enUS } from "date-fns/locale";

/**
 * Supported locales for date formatting
 */
export const SUPPORTED_LOCALES = {
  ka: ka,
  en: enUS,
} as const;

export type SupportedLocale = keyof typeof SUPPORTED_LOCALES;

/**
 * Get the current locale from localStorage or default to Georgian
 */
export function getCurrentLocale(): Locale {
  const savedLocale = localStorage.getItem('app_locale') as SupportedLocale | null;
  return savedLocale && SUPPORTED_LOCALES[savedLocale] 
    ? SUPPORTED_LOCALES[savedLocale] 
    : SUPPORTED_LOCALES.ka;
}

/**
 * Set the application locale
 */
export function setCurrentLocale(locale: SupportedLocale) {
  localStorage.setItem('app_locale', locale);
}

/**
 * Safely formats a date string or Date object with validation
 * @param date - Date string, Date object, or null/undefined
 * @param formatString - Format pattern (e.g., "dd/MM/yyyy", "HH:mm")
 * @param options - Optional formatting options including locale
 * @returns Formatted date string or fallback value
 */
export function safeFormatDate(
  date: string | Date | null | undefined,
  formatString: string,
  options?: {
    locale?: Locale;
    fallback?: string;
  }
): string {
  const fallback = options?.fallback ?? "-";
  
  if (!date) {
    return fallback;
  }

  try {
    const dateObj = typeof date === "string" ? new Date(date) : date;
    
    // Check if date is valid
    if (isNaN(dateObj.getTime())) {
      console.warn(`Invalid date value: ${date}`);
      return fallback;
    }

    // Use provided locale or get current locale
    const locale = options?.locale ?? getCurrentLocale();

    return dateFnsFormat(dateObj, formatString, { locale });
  } catch (error) {
    console.error(`Error formatting date: ${date}`, error);
    return fallback;
  }
}

/**
 * Checks if a date value is valid
 * @param date - Date string, Date object, or null/undefined
 * @returns true if date is valid, false otherwise
 */
export function isValidDate(date: string | Date | null | undefined): boolean {
  if (!date) return false;
  
  try {
    const dateObj = typeof date === "string" ? new Date(date) : date;
    return !isNaN(dateObj.getTime());
  } catch {
    return false;
  }
}

/**
 * Parse a date string safely
 * @param dateString - ISO date string
 * @returns Date object or null if invalid
 */
export function safeParseDateISO(dateString: string | null | undefined): Date | null {
  if (!dateString) return null;
  
  try {
    const date = parseISO(dateString);
    return isValidDate(date) ? date : null;
  } catch {
    return null;
  }
}

/**
 * Common date format helpers with built-in validation and locale support
 */
export const formatters = {
  // Date only formats
  shortDate: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "dd/MM/yyyy", { locale }),
  
  longDate: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "d MMMM yyyy", { locale }),
  
  shortDateWithMonth: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "d MMM yyyy", { locale }),
  
  dateWithDayName: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "EEEE, d MMMM yyyy", { locale }),
  
  // Time only formats
  time24: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "HH:mm", { locale }),
  
  timeWithSeconds: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "HH:mm:ss", { locale }),
  
  // Combined date and time formats
  dateTime: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "dd/MM/yyyy HH:mm", { locale }),
  
  longDateTime: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "d MMMM yyyy, HH:mm", { locale }),
  
  shortDateTime: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "d MMM yyyy, HH:mm", { locale }),
  
  // ISO formats
  isoDate: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "yyyy-MM-dd", { locale }),
  
  // For charts and compact displays
  chartDate: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "dd/MM", { locale }),
  
  monthYear: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "MMMM yyyy", { locale }),
  
  // Relative formats
  dayMonthShort: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "d MMM", { locale }),
  
  fullDateTime: (date: string | Date | null | undefined, locale?: Locale) => 
    safeFormatDate(date, "EEEE, d MMMM yyyy წ, HH:mm:ss", { locale }),
};

/**
 * Format date with custom pattern and automatic locale detection
 */
export function formatDate(
  date: string | Date | null | undefined,
  pattern: string,
  options?: {
    locale?: Locale;
    fallback?: string;
  }
): string {
  return safeFormatDate(date, pattern, {
    locale: options?.locale ?? getCurrentLocale(),
    fallback: options?.fallback,
  });
}
