import { PageTransition } from "@/components/PageTransition";

/**
 * Higher-order component to wrap pages with PageTransition
 */
export function wrapPageWithTransition<P extends object>(
  Component: React.ComponentType<P>
): React.ComponentType<P> {
  return function WrappedPage(props: P) {
    return (
      <PageTransition>
        <Component {...props} />
      </PageTransition>
    );
  };
}
