import { describe, it, expect } from "vitest";
import { canRoleSeeUrl, routeLabel } from "./routeLabels";

describe("search visibility by role", () => {
  it("employee cannot see payroll", () => expect(canRoleSeeUrl("employee", "/payroll")).toBe(false));
  it("employee can see leave", () => expect(canRoleSeeUrl("employee", "/leave-requests")).toBe(true));
  it("admin sees payroll", () => expect(canRoleSeeUrl("admin", "/payroll")).toBe(true));
});

describe("labels", () => {
  it("leave has one name", () => expect(routeLabel("/leave-requests", "ka")).toBe("შვებულებები"));
  it("organization in English", () => expect(routeLabel("/organization", "en")).toBe("Organization"));
});
