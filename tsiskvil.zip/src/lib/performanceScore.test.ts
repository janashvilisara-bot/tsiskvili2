import { describe, expect, test } from "vitest";
import { performanceScore, performanceTrend, potentialScore, toLevel, type PerformanceInput } from "./performanceScore";

const empty: PerformanceInput = {
  evaluations: [], lateCount90d: null, tasksCompleted: 0, tasksOverdue: 0,
  goalProgress: [], trainingsTotal: 0, trainingsCompleted: 0, skillLevels: [],
};

describe("performanceScore", () => {
  test("no data gives null", () => {
    expect(performanceScore(empty)).toBeNull();
    expect(potentialScore(empty)).toBeNull();
  });
  test("weights renormalise over available sources", () => {
    // evaluations 4/5 = 80 (w40), attendance 2 late = 90 (w20) => (3200+1800)/60 = 83
    expect(performanceScore({ ...empty, evaluations: [{ evaluation_date: "2026-01-01", overall_rating: 4 }], lateCount90d: 2 })).toBe(83);
  });
  test("trend uses last two evaluations", () => {
    expect(performanceTrend([
      { evaluation_date: "2026-01-01", overall_rating: 3 },
      { evaluation_date: "2026-06-01", overall_rating: 4 },
    ])).toBe("improving");
    expect(performanceTrend([{ evaluation_date: "2026-01-01", overall_rating: 3 }])).toBe("unknown");
  });
  test("level thresholds 50 / 75", () => {
    expect(toLevel(49)).toBe("low");
    expect(toLevel(50)).toBe("mid");
    expect(toLevel(75)).toBe("high");
  });
});
