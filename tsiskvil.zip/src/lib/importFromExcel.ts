import ExcelJS from 'exceljs';

export interface ImportedEmployee {
  full_name: string;
  email: string;
  phone?: string;
  position: string;
  department?: string;
  salary?: number;
  hire_date?: string;
  gender?: string;
  date_of_birth?: string;
  status?: string;
}

export const importFromExcel = async (file: File): Promise<ImportedEmployee[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      try {
        const buffer = e.target?.result as ArrayBuffer;
        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.load(buffer);
        
        const worksheet = workbook.worksheets[0];
        if (!worksheet) {
          reject(new Error('No worksheet found'));
          return;
        }
        
        const employees: ImportedEmployee[] = [];
        const headerRow = worksheet.getRow(1);
        const headers: { [key: number]: string } = {};
        
        // Map headers
        headerRow.eachCell((cell, colNumber) => {
          headers[colNumber] = String(cell.value || '').trim();
        });
        
        // Process data rows
        worksheet.eachRow((row, rowNumber) => {
          if (rowNumber === 1) return; // Skip header
          
          const rowData: { [key: string]: any } = {};
          row.eachCell((cell, colNumber) => {
            const header = headers[colNumber];
            if (header) {
              rowData[header] = cell.value;
            }
          });
          
          const employee: ImportedEmployee = {
            full_name: rowData['სახელი და გვარი'] || rowData['სახელი'] || rowData['Full Name'] || '',
            email: rowData['ელ. ფოსტა'] || rowData['Email'] || '',
            phone: rowData['ტელეფონი'] || rowData['Phone'] || '',
            position: rowData['პოზიცია'] || rowData['Position'] || '',
            department: rowData['დეპარტამენტი'] || rowData['Department'] || undefined,
            salary: parseFloat(rowData['ხელფასი'] || rowData['Salary'] || 0) || undefined,
            hire_date: rowData['მოსვლის თარიღი'] || rowData['Hire Date'] || undefined,
            gender: rowData['სქესი'] || rowData['Gender'] || undefined,
            date_of_birth: rowData['დაბადების თარიღი'] || rowData['Date of Birth'] || undefined,
            status: rowData['სტატუსი'] || rowData['Status'] || 'active',
          };
          
          if (employee.full_name || employee.email) {
            employees.push(employee);
          }
        });
        
        resolve(employees);
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = (error) => reject(error);
    reader.readAsArrayBuffer(file);
  });
};
