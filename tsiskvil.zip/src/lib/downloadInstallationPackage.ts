import JSZip from 'jszip';
import { saveAs } from 'file-saver';

const dockerComposeContent = `version: '3.8'

services:
  # PostgreSQL Database
  postgres:
    image: postgres:15-alpine
    container_name: talentos-db
    restart: unless-stopped
    environment:
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: \${POSTGRES_PASSWORD:-your-super-secret-password}
      POSTGRES_DB: postgres
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./supabase/migrations:/docker-entrypoint-initdb.d
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres"]
      interval: 10s
      timeout: 5s
      retries: 5

  # Supabase Kong API Gateway
  kong:
    image: kong:2.8
    container_name: talentos-kong
    restart: unless-stopped
    environment:
      KONG_DATABASE: "off"
      KONG_DECLARATIVE_CONFIG: /var/lib/kong/kong.yml
      KONG_DNS_ORDER: LAST,A,CNAME
      KONG_PLUGINS: request-transformer,cors,key-auth,acl
    volumes:
      - ./docker/kong.yml:/var/lib/kong/kong.yml
    ports:
      - "8000:8000"
    depends_on:
      - rest
      - auth

  # Supabase REST API (PostgREST)
  rest:
    image: postgrest/postgrest:v11.2.2
    container_name: talentos-rest
    restart: unless-stopped
    environment:
      PGRST_DB_URI: postgres://postgres:\${POSTGRES_PASSWORD:-your-super-secret-password}@postgres:5432/postgres
      PGRST_DB_SCHEMAS: public,storage
      PGRST_DB_ANON_ROLE: anon
      PGRST_JWT_SECRET: \${JWT_SECRET:-your-super-secret-jwt-token-with-at-least-32-characters}
      PGRST_DB_USE_LEGACY_GUCS: "false"
    depends_on:
      postgres:
        condition: service_healthy

  # Supabase Auth (GoTrue)
  auth:
    image: supabase/gotrue:v2.99.0
    container_name: talentos-auth
    restart: unless-stopped
    environment:
      GOTRUE_API_HOST: 0.0.0.0
      GOTRUE_API_PORT: 9999
      API_EXTERNAL_URL: \${API_EXTERNAL_URL:-http://localhost:8000}
      GOTRUE_DB_DRIVER: postgres
      GOTRUE_DB_DATABASE_URL: postgres://postgres:\${POSTGRES_PASSWORD:-your-super-secret-password}@postgres:5432/postgres?search_path=auth
      GOTRUE_SITE_URL: \${SITE_URL:-http://localhost:3000}
      GOTRUE_URI_ALLOW_LIST: "*"
      GOTRUE_JWT_SECRET: \${JWT_SECRET:-your-super-secret-jwt-token-with-at-least-32-characters}
      GOTRUE_JWT_EXP: 3600
      GOTRUE_JWT_DEFAULT_GROUP_NAME: authenticated
      GOTRUE_DISABLE_SIGNUP: "false"
      GOTRUE_EXTERNAL_EMAIL_ENABLED: "true"
      GOTRUE_MAILER_AUTOCONFIRM: "true"
      GOTRUE_SMS_AUTOCONFIRM: "true"
    depends_on:
      postgres:
        condition: service_healthy

  # Supabase Storage API
  storage:
    image: supabase/storage-api:v0.40.4
    container_name: talentos-storage
    restart: unless-stopped
    environment:
      ANON_KEY: \${ANON_KEY:-your-anon-key}
      SERVICE_KEY: \${SERVICE_ROLE_KEY:-your-service-role-key}
      POSTGREST_URL: http://rest:3000
      PGRST_JWT_SECRET: \${JWT_SECRET:-your-super-secret-jwt-token-with-at-least-32-characters}
      DATABASE_URL: postgres://postgres:\${POSTGRES_PASSWORD:-your-super-secret-password}@postgres:5432/postgres
      FILE_SIZE_LIMIT: 52428800
      STORAGE_BACKEND: file
      FILE_STORAGE_BACKEND_PATH: /var/lib/storage
      TENANT_ID: stub
      REGION: stub
      GLOBAL_S3_BUCKET: stub
    volumes:
      - storage_data:/var/lib/storage
    depends_on:
      postgres:
        condition: service_healthy
      rest:
        condition: service_started

  # Frontend Application
  app:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: talentos-app
    restart: unless-stopped
    ports:
      - "3000:80"
    environment:
      VITE_SUPABASE_URL: \${SUPABASE_URL:-http://localhost:8000}
      VITE_SUPABASE_PUBLISHABLE_KEY: \${ANON_KEY:-your-anon-key}
    depends_on:
      - kong

volumes:
  postgres_data:
  storage_data:

networks:
  default:
    name: talentos-network
`;

const dockerfileContent = `# Build stage
FROM node:20-alpine as builder

WORKDIR /app

# Copy package files
COPY package*.json ./
COPY bun.lockb ./

# Install dependencies
RUN npm install

# Copy source code
COPY . .

# Build the application
RUN npm run build

# Production stage
FROM nginx:alpine

# Copy built assets
COPY --from=builder /app/dist /usr/share/nginx/html

# Copy nginx configuration
COPY docker/nginx.conf /etc/nginx/conf.d/default.conf

# Expose port
EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
`;

const nginxConfContent = `server {
    listen 80;
    server_name localhost;
    root /usr/share/nginx/html;
    index index.html;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml application/javascript;

    # ============================================
    # SECURITY HEADERS - Enterprise Grade
    # ============================================
    
    # Prevent clickjacking attacks
    add_header X-Frame-Options "SAMEORIGIN" always;
    
    # Prevent MIME type sniffing
    add_header X-Content-Type-Options "nosniff" always;
    
    # XSS Protection (legacy browsers)
    add_header X-XSS-Protection "1; mode=block" always;
    
    # Control referrer information
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    
    # HTTP Strict Transport Security (HSTS)
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    
    # Content Security Policy (Enforced)
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob:; connect-src 'self' http://kong:8000 ws://kong:8000; frame-ancestors 'self'; form-action 'self'; base-uri 'self'; object-src 'none';" always;
    
    # Permissions Policy - Restrict browser features
    add_header Permissions-Policy "accelerometer=(), camera=(), geolocation=(self), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()" always;

    # Handle React Router
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Cache static assets
    location ~* \\.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # API proxy
    location /api/ {
        proxy_pass http://kong:8000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
    
    # Auth API proxy
    location /auth/ {
        proxy_pass http://kong:8000/auth/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # REST API proxy
    location /rest/ {
        proxy_pass http://kong:8000/rest/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Storage API proxy
    location /storage/ {
        proxy_pass http://kong:8000/storage/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        client_max_body_size 50M;
    }
}
`;

const kongYmlContent = `_format_version: "2.1"

services:
  - name: rest
    url: http://rest:3000
    routes:
      - name: rest-route
        paths:
          - /rest
        strip_path: true

  - name: auth
    url: http://auth:9999
    routes:
      - name: auth-route
        paths:
          - /auth
        strip_path: true

  - name: storage
    url: http://storage:5000
    routes:
      - name: storage-route
        paths:
          - /storage
        strip_path: true

plugins:
  - name: cors
    config:
      origins:
        - "*"
      methods:
        - GET
        - POST
        - PUT
        - PATCH
        - DELETE
        - OPTIONS
      headers:
        - Accept
        - Authorization
        - Content-Type
        - apikey
        - x-client-info
      exposed_headers:
        - Content-Length
        - Content-Range
      credentials: true
      max_age: 3600
`;

const envExampleContent = `# ========================================
# TalentOS HR System - კონფიგურაცია
# ========================================

# ========================================
# სავალდებულო პარამეტრები
# ========================================

# მონაცემთა ბაზის პაროლი
POSTGRES_PASSWORD=TalentOS2024SecureDB!@#

# JWT საიდუმლო გასაღები (მინიმუმ 32 სიმბოლო)
JWT_SECRET=super-secret-jwt-token-for-talentos-hr-system-2024-production-key

# Supabase გასაღებები
# პროდაქშენისთვის შეცვალეთ: https://supabase.com/docs/guides/self-hosting/docker#generate-api-keys
ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0
SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImV4cCI6MTk4MzgxMjk5Nn0.EGIM96RAZx35lJzdJsyH-qQwv8Hdp7fsn3W0YpN81IU

# ========================================
# URL-ები (ლოკალური ინსტალაცია)
# ========================================
API_EXTERNAL_URL=http://localhost:8000
SITE_URL=http://localhost:3000
SUPABASE_URL=http://localhost:8000

# ========================================
# არასავალდებულო - SMS (Twilio)
# ========================================
# დარეგისტრირდით: https://www.twilio.com/
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_PHONE_NUMBER=

# ========================================
# არასავალდებულო - Email (Resend)
# ========================================
# დარეგისტრირდით: https://resend.com/
RESEND_API_KEY=

# ========================================
# არასავალდებულო - AI ფუნქციონალი (OpenAI)
# ========================================
# გასაღების მისაღებად: https://platform.openai.com/api-keys
OPENAI_API_KEY=
`;

const installShContent = `#!/bin/bash

# TalentOS Installation Script
# Supports Linux and macOS

set -e

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║                  TalentOS Installer                        ║"
echo "║              HR Management System v1.0                     ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed!"
    echo "Please install Docker: https://docs.docker.com/get-docker/"
    exit 1
fi

echo "✅ Docker is installed"

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    echo "❌ Docker Compose is not installed!"
    echo "Please install Docker Compose: https://docs.docker.com/compose/install/"
    exit 1
fi

echo "✅ Docker Compose is installed"

# Check if Docker is running
if ! docker info &> /dev/null; then
    echo "❌ Docker is not running!"
    echo "Please start Docker and try again."
    exit 1
fi

echo "✅ Docker is running"

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "📝 Creating configuration file..."
    if [ -f "docker/.env.example" ]; then
        cp docker/.env.example .env
    else
        cat > .env << 'EOF'
# TalentOS Configuration
POSTGRES_PASSWORD=TalentOS2024SecurePassword
JWT_SECRET=your-super-secret-jwt-token-with-at-least-32-characters-long
ANON_KEY=your-anon-key
SERVICE_ROLE_KEY=your-service-role-key
API_EXTERNAL_URL=http://localhost:8000
SITE_URL=http://localhost:3000
SUPABASE_URL=http://localhost:8000
EOF
    fi
    echo "✅ Configuration file created: .env"
    echo "⚠️  Please update .env file with your settings before continuing!"
    read -p "Press Enter to continue after updating .env..."
fi

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p docker

# Pull Docker images
echo "📥 Pulling Docker images..."
docker-compose pull

# Build the application
echo "🔨 Building application..."
docker-compose build

# Start services
echo "🚀 Starting services..."
docker-compose up -d

# Wait for services to start
echo "⏳ Waiting for services to start..."
sleep 10

# Check if services are running
if docker-compose ps | grep -q "Up"; then
    echo ""
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║              Installation completed successfully!          ║"
    echo "╠════════════════════════════════════════════════════════════╣"
    echo "║                                                            ║"
    echo "║  🌐 Application:   http://localhost:3000                   ║"
    echo "║  🔌 API:           http://localhost:8000                   ║"
    echo "║  🗄️  Database:      localhost:5432                         ║"
    echo "║                                                            ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo ""
    echo "📋 Useful commands:"
    echo "   docker-compose logs -f    - View logs"
    echo "   docker-compose stop       - Stop services"
    echo "   docker-compose start      - Start services"
    echo "   docker-compose down       - Remove services"
    echo ""
    echo "👤 To create first admin, go to: http://localhost:3000/auth"
else
    echo "❌ Some services failed to start"
    echo "Run 'docker-compose logs' for details"
    exit 1
fi
`;

const installBatContent = `@echo off
setlocal

echo.
echo ========================================
echo       TalentOS HR System Installer
echo ========================================
echo.

REM Check if Docker is installed
docker --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Docker is not installed!
    echo Please install Docker Desktop: https://docs.docker.com/desktop/install/windows-install/
    pause
    exit /b 1
)

echo [OK] Docker is installed

REM Check if Docker is running
docker ps >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Docker is not running!
    echo Please start Docker Desktop and try again.
    pause
    exit /b 1
)

echo [OK] Docker is running

REM Check if .env file exists
if not exist ".env" (
    echo [INFO] Creating configuration file...
    if exist "docker\\.env.example" (
        copy "docker\\.env.example" ".env" >nul
    ) else (
        echo POSTGRES_PASSWORD=TalentOS2024SecurePassword>.env
        echo JWT_SECRET=your-super-secret-jwt-token-with-at-least-32-characters-long>>.env
        echo ANON_KEY=your-anon-key>>.env
        echo SERVICE_ROLE_KEY=your-service-role-key>>.env
        echo API_EXTERNAL_URL=http://localhost:8000>>.env
        echo SITE_URL=http://localhost:3000>>.env
        echo SUPABASE_URL=http://localhost:8000>>.env
    )
    echo [OK] Configuration file created: .env
    echo [WARNING] Please update .env file with your settings!
    pause
)

REM Create directories
echo [INFO] Creating directories...
if not exist "docker" mkdir docker

REM Pull images
echo [INFO] Pulling Docker images...
docker-compose pull

REM Build application
echo [INFO] Building application...
docker-compose build

REM Start services
echo [INFO] Starting services...
docker-compose up -d

REM Wait for services
echo [INFO] Waiting for services to start...
timeout /t 10 /nobreak >nul

echo.
echo ========================================
echo   Installation Complete!
echo ========================================
echo.
echo   Application:   http://localhost:3000
echo   API:           http://localhost:8000
echo   Database:      localhost:5432
echo.
echo Useful commands:
echo   docker-compose logs -f    - View logs
echo   docker-compose stop       - Stop services
echo   docker-compose start      - Start services
echo   docker-compose down       - Remove services
echo.
echo To create first admin, go to: http://localhost:3000/auth
echo.
pause
`;

const installationGuideContent = `# TalentOS Installation Guide

## System Requirements

- **OS**: Windows 10/11, Ubuntu 20.04+, macOS 12+
- **RAM**: Minimum 4GB (8GB recommended)
- **Disk**: Minimum 10GB free space
- **Docker**: Docker Desktop 4.0+ or Docker Engine 20.10+
- **Docker Compose**: v2.0+

## Quick Start

### Windows
1. Install Docker Desktop from https://docs.docker.com/desktop/install/windows-install/
2. Extract the installation package
3. Double-click \`install.bat\`
4. Wait for installation to complete
5. Open http://localhost:3000 in your browser

### Linux/macOS
1. Install Docker and Docker Compose
2. Extract the installation package
3. Open terminal in the extracted folder
4. Run: \`chmod +x install.sh && ./install.sh\`
5. Open http://localhost:3000 in your browser

## Configuration

Edit the \`.env\` file to customize your installation:

\`\`\`env
# Database password (change this!)
POSTGRES_PASSWORD=your-secure-password

# JWT secret for authentication (minimum 32 characters)
JWT_SECRET=your-super-secret-jwt-token-minimum-32-chars

# API keys (generate your own for production)
ANON_KEY=your-anon-key
SERVICE_ROLE_KEY=your-service-role-key

# URLs
API_EXTERNAL_URL=http://your-server:8000
SITE_URL=http://your-server:3000
SUPABASE_URL=http://your-server:8000
\`\`\`

## Services

| Service | Port | Description |
|---------|------|-------------|
| Application | 3000 | Web interface |
| API Gateway | 8000 | REST API |
| Database | 5432 | PostgreSQL |

## Commands

\`\`\`bash
# View logs
docker-compose logs -f

# Stop services
docker-compose stop

# Start services
docker-compose start

# Remove services (keeps data)
docker-compose down

# Remove services and data
docker-compose down -v

# Rebuild application
docker-compose build app
docker-compose up -d app
\`\`\`

## First Login

1. Open http://localhost:3000/auth
2. Register the first user (will be admin)
3. Login and start configuring the system

## Troubleshooting

### Docker not starting
- Ensure Docker Desktop is running
- Check system requirements

### Services not accessible
- Wait 30 seconds after installation
- Check logs: \`docker-compose logs\`

### Database connection issues
- Check POSTGRES_PASSWORD in .env
- Restart services: \`docker-compose restart\`

## Support

For issues and questions, contact your system administrator.
`;

const readmeContent = `# TalentOS Installation Package

HR Management System - სრული საინსტალაციო პაკეტი

## ინსტალაციის ნაბიჯები

### 1. პროექტის კლონირება GitHub-დან
\`\`\`bash
git clone https://github.com/your-org/talentos-hr.git
cd talentos-hr
\`\`\`

### 2. კონფიგურაციის ფაილების კოპირება
დააკოპირეთ ამ პაკეტიდან შემდეგი ფაილები:
- \`docker-compose.yml\` → პროექტის root-ში
- \`Dockerfile\` → პროექტის root-ში
- \`install.sh\` → პროექტის root-ში
- \`install.bat\` → პროექტის root-ში
- \`docker/\` საქაღალდე → პროექტის root-ში

### 3. ინსტალაციის გაშვება

**Windows:**
\`\`\`bash
install.bat
\`\`\`

**Linux/macOS:**
\`\`\`bash
chmod +x install.sh
./install.sh
\`\`\`

### 4. აპლიკაციის გახსნა
გახსენით ბრაუზერში: http://localhost:3000

## ფაილები

- \`docker-compose.yml\` - Docker სერვისების კონფიგურაცია
- \`Dockerfile\` - აპლიკაციის build ინსტრუქციები
- \`install.sh\` - Linux/macOS ინსტალერი
- \`install.bat\` - Windows ინსტალერი
- \`docker/\` - დამატებითი კონფიგურაციები
  - \`nginx.conf\` - Nginx კონფიგურაცია
  - \`kong.yml\` - API Gateway კონფიგურაცია
  - \`.env.example\` - გარემოს ცვლადების მაგალითი
- \`INSTALLATION_GUIDE.md\` - დეტალური ინსტრუქციები

## AI ფუნქციონალი

ლოკალური ინსტალაციისთვის AI ფუნქციონალი მუშაობს OpenAI API-ით.
გასაღების მისაღებად გადადით: https://platform.openai.com/api-keys

\`.env\` ფაილში დაამატეთ:
\`\`\`
OPENAI_API_KEY=your-openai-api-key
\`\`\`

## მოთხოვნები

- Docker Desktop 4.0+
- 4GB RAM (რეკომენდებული 8GB)
- 10GB თავისუფალი ადგილი
- Git (პროექტის კლონირებისთვის)
`;

export const downloadInstallationPackage = async () => {
  const zip = new JSZip();

  // Root configuration files
  zip.file('docker-compose.yml', dockerComposeContent);
  zip.file('Dockerfile', dockerfileContent);
  zip.file('install.sh', installShContent);
  zip.file('install.bat', installBatContent);
  zip.file('INSTALLATION_GUIDE.md', installationGuideContent);
  zip.file('README.md', readmeContent);

  // package.json
  zip.file('package.json', `{
  "name": "talentos-hr",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "@hookform/resolvers": "^3.10.0",
    "@radix-ui/react-accordion": "^1.2.11",
    "@radix-ui/react-alert-dialog": "^1.1.14",
    "@radix-ui/react-avatar": "^1.1.10",
    "@radix-ui/react-checkbox": "^1.3.2",
    "@radix-ui/react-collapsible": "^1.1.11",
    "@radix-ui/react-dialog": "^1.1.14",
    "@radix-ui/react-dropdown-menu": "^2.1.15",
    "@radix-ui/react-label": "^2.1.7",
    "@radix-ui/react-popover": "^1.1.14",
    "@radix-ui/react-progress": "^1.1.7",
    "@radix-ui/react-scroll-area": "^1.2.9",
    "@radix-ui/react-select": "^2.2.5",
    "@radix-ui/react-separator": "^1.1.7",
    "@radix-ui/react-slot": "^1.2.3",
    "@radix-ui/react-switch": "^1.2.5",
    "@radix-ui/react-tabs": "^1.1.12",
    "@radix-ui/react-toast": "^1.2.14",
    "@radix-ui/react-tooltip": "^1.2.7",
    "@supabase/supabase-js": "^2.76.1",
    "@tanstack/react-query": "^5.83.0",
    "class-variance-authority": "^0.7.1",
    "clsx": "^2.1.1",
    "cmdk": "^1.1.1",
    "date-fns": "^3.6.0",
    "docx": "^9.5.1",
    "embla-carousel-react": "^8.6.0",
    "file-saver": "^2.0.5",
    "framer-motion": "^12.23.24",
    "jspdf": "^3.0.3",
    "jspdf-autotable": "^5.0.2",
    "jszip": "^3.10.1",
    "lucide-react": "^0.462.0",
    "react": "^18.3.1",
    "react-day-picker": "^8.10.1",
    "react-dom": "^18.3.1",
    "react-hook-form": "^7.61.1",
    "react-router-dom": "^6.30.1",
    "recharts": "^3.4.1",
    "sonner": "^1.7.4",
    "tailwind-merge": "^2.6.0",
    "tailwindcss-animate": "^1.0.7",
    "xlsx": "^0.18.5",
    "zod": "^3.25.76"
  },
  "devDependencies": {
    "@types/file-saver": "^2.0.7",
    "@types/react": "^18.3.18",
    "@types/react-dom": "^18.3.5",
    "@vitejs/plugin-react-swc": "^3.5.0",
    "autoprefixer": "^10.4.19",
    "postcss": "^8.4.38",
    "tailwindcss": "^3.4.3",
    "typescript": "^5.4.5",
    "vite": "^5.2.0"
  }
}
`);

  // vite.config.ts
  zip.file('vite.config.ts', `import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 5173,
    host: true,
  },
})
`);

  // tsconfig.json
  zip.file('tsconfig.json', `{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": ["src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
`);

  // tsconfig.node.json
  zip.file('tsconfig.node.json', `{
  "compilerOptions": {
    "composite": true,
    "skipLibCheck": true,
    "module": "ESNext",
    "moduleResolution": "bundler",
    "allowSyntheticDefaultImports": true
  },
  "include": ["vite.config.ts"]
}
`);

  // postcss.config.js
  zip.file('postcss.config.js', `export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
`);

  // tailwind.config.ts
  zip.file('tailwind.config.ts', `import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: ["class"],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}

export default config
`);

  // index.html
  zip.file('index.html', `<!doctype html>
<html lang="ka">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/png" href="/favicon.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TalentOS - HR Management System</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`);

  // .gitignore
  zip.file('.gitignore', `# Dependencies
node_modules
.pnp
.pnp.js

# Build
dist
dist-ssr
*.local

# Environment
.env
.env.local
.env.*.local

# IDE
.vscode/*
!.vscode/extensions.json
.idea
*.suo
*.ntvs*
*.njsproj
*.sln
*.sw?

# Logs
logs
*.log
npm-debug.log*

# OS
.DS_Store
Thumbs.db
`);

  // components.json (for shadcn)
  zip.file('components.json', `{
  "$schema": "https://ui.shadcn.com/schema.json",
  "style": "default",
  "rsc": false,
  "tsx": true,
  "tailwind": {
    "config": "tailwind.config.ts",
    "css": "src/index.css",
    "baseColor": "slate",
    "cssVariables": true,
    "prefix": ""
  },
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils",
    "ui": "@/components/ui",
    "lib": "@/lib",
    "hooks": "@/hooks"
  }
}
`);

  // Docker folder
  const dockerFolder = zip.folder('docker');
  if (dockerFolder) {
    dockerFolder.file('nginx.conf', nginxConfContent);
    dockerFolder.file('kong.yml', kongYmlContent);
    dockerFolder.file('.env.example', envExampleContent);
  }

  // Root .env file (ready to use)
  zip.file('.env', envExampleContent);

  // Public folder
  const publicFolder = zip.folder('public');
  if (publicFolder) {
    publicFolder.file('robots.txt', `User-agent: *
Allow: /
`);
    publicFolder.file('_README.txt', `Place your favicon.png and other public assets here.

Required files:
- favicon.png - Application icon
- apple-touch-icon.png - iOS icon
- pwa-192x192.png - PWA icon (192x192)
- pwa-512x512.png - PWA icon (512x512)
`);
  }

  // Source folder structure
  const srcFolder = zip.folder('src');
  if (srcFolder) {
    // src/main.tsx
    srcFolder.file('main.tsx', `import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
`);

    // Placeholder files for source code
    srcFolder.file('_README.txt', `# Source Code Folder Structure

Copy all source files from the original project here.

Required subfolders:
- components/     - React components
- components/ui/  - Shadcn UI components  
- pages/          - Page components
- hooks/          - Custom React hooks
- lib/            - Utility functions
- contexts/       - React contexts
- integrations/   - Supabase client and types
- assets/         - Images and static assets

Key files to copy:
- App.tsx
- App.css
- index.css
- main.tsx (already included)
`);

    // Create subfolders with placeholders
    const componentsFolder = srcFolder.folder('components');
    componentsFolder?.file('.gitkeep', '');
    
    const uiFolder = componentsFolder?.folder('ui');
    uiFolder?.file('.gitkeep', '');

    const pagesFolder = srcFolder.folder('pages');
    pagesFolder?.file('.gitkeep', '');

    const hooksFolder = srcFolder.folder('hooks');
    hooksFolder?.file('.gitkeep', '');

    const libFolder = srcFolder.folder('lib');
    libFolder?.file('utils.ts', `import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
`);

    const contextsFolder = srcFolder.folder('contexts');
    contextsFolder?.file('.gitkeep', '');

    const integrationsFolder = srcFolder.folder('integrations');
    const supabaseIntegration = integrationsFolder?.folder('supabase');
    supabaseIntegration?.file('client.ts', `import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'http://localhost:8000'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || ''

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
`);
    supabaseIntegration?.file('types.ts', `// Database types will be generated from your Supabase schema
// Run: npx supabase gen types typescript --local > src/integrations/supabase/types.ts

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export type Database = {
  public: {
    Tables: {}
    Views: {}
    Functions: {}
    Enums: {}
    CompositeTypes: {}
  }
}
`);

    const assetsFolder = srcFolder.folder('assets');
    assetsFolder?.file('.gitkeep', '');
  }

  // Supabase folder structure
  const supabaseFolder = zip.folder('supabase');
  if (supabaseFolder) {
    supabaseFolder.file('config.toml', `[api]
enabled = true
port = 54321
schemas = ["public", "storage"]
extra_search_path = ["public", "extensions"]
max_rows = 1000

[db]
port = 54322

[studio]
enabled = true
port = 54323

[auth]
enabled = true
site_url = "http://localhost:3000"
additional_redirect_urls = ["http://localhost:3000"]
jwt_expiry = 3600
enable_signup = true

[auth.email]
enable_signup = true
double_confirm_changes = false
enable_confirmations = false
`);

    const migrationsFolder = supabaseFolder.folder('migrations');
    migrationsFolder?.file('_README.txt', `# Database Migrations

Place your SQL migration files here.

Migration files should be named with timestamp prefix:
- 20240101000000_initial_schema.sql
- 20240101000001_add_users_table.sql
- etc.

These files will be executed in order when the database starts.
`);

    const functionsFolder = supabaseFolder.folder('functions');
    functionsFolder?.file('_README.txt', `# Edge Functions

Place your Supabase Edge Functions here.

Each function should be in its own folder:
- send-email/index.ts
- send-sms/index.ts
- etc.
`);
  }

  // Generate and download
  const content = await zip.generateAsync({ type: 'blob' });
  saveAs(content, 'TalentOS-Installation-Package.zip');
};
