import { supabase } from '@/integrations/supabase/client';

export type SoftDeletableTable = 'employees' | 'documents' | 'leave_requests' | 'contracts' | 'attendance' | 'candidates';

/**
 * Soft delete a record by setting deleted_at timestamp
 */
export async function softDelete(table: SoftDeletableTable, recordId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase.rpc('soft_delete_record', {
      p_table_name: table,
      p_record_id: recordId
    });

    if (error) {
      console.error('Soft delete error:', error);
      return false;
    }

    return data === true;
  } catch (err) {
    console.error('Soft delete failed:', err);
    return false;
  }
}

/**
 * Restore a soft-deleted record
 */
export async function restoreRecord(table: SoftDeletableTable, recordId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase.rpc('restore_deleted_record', {
      p_table_name: table,
      p_record_id: recordId
    });

    if (error) {
      console.error('Restore error:', error);
      return false;
    }

    return data === true;
  } catch (err) {
    console.error('Restore failed:', err);
    return false;
  }
}

/**
 * Get soft-deleted records from a table
 */
export async function getDeletedRecords<T>(table: SoftDeletableTable): Promise<T[]> {
  try {
    const { data, error } = await supabase
      .from(table)
      .select('*')
      .not('deleted_at', 'is', null)
      .order('deleted_at', { ascending: false });

    if (error) {
      console.error('Get deleted records error:', error);
      return [];
    }

    return (data || []) as T[];
  } catch (err) {
    console.error('Get deleted records failed:', err);
    return [];
  }
}

/**
 * Permanently delete a soft-deleted record (GDPR compliant after retention period)
 */
export async function permanentDelete(table: SoftDeletableTable, recordId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from(table)
      .delete()
      .eq('id', recordId)
      .not('deleted_at', 'is', null); // Only allow permanent delete of already soft-deleted records

    if (error) {
      console.error('Permanent delete error:', error);
      return false;
    }

    return true;
  } catch (err) {
    console.error('Permanent delete failed:', err);
    return false;
  }
}
