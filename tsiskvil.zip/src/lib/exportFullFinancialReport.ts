import ExcelJS from 'exceljs';
import { supabase } from '@/integrations/supabase/client';

export const exportFullFinancialReport = async (month: number, year: number) => {
  try {
    const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
    const endDate = new Date(year, month, 0).toISOString().split('T')[0];

    // Fetch payroll data
    const { data: payrollData } = await supabase.from('payroll').select(`
      *,
      employees:employee_id(full_name, position, department, personal_id_number, phone, email)
    `).eq('month', month).eq('year', year);

    // Fetch leave requests
    const { data: leavesData } = await supabase.from('leave_requests').select(`
      *,
      employee:employees!leave_requests_employee_id_fkey(full_name, position, department)
    `).gte('start_date', startDate).lte('end_date', endDate).eq('status', 'approved');

    // Fetch overtime
    const { data: overtimeData } = await supabase.from('overtime_requests' as any).select(`
      *,
      employees:employee_id(full_name, position, department)
    `).gte('work_date', startDate).lte('work_date', endDate).eq('status', 'approved');

    // Fetch pension
    const { data: pensionData } = await supabase.from('pension_payments').select(`
      *,
      employee:employees(full_name, position, department, personal_id_number)
    `).eq('period_month', month).eq('period_year', year);

    // Fetch budget expenses
    const { data: budgetData } = await supabase.from('budget_expenses')
      .select('*')
      .gte('expense_date', startDate)
      .lte('expense_date', endDate)
      .eq('status', 'approved');

    // Fetch compensations
    const { data: compensationData } = await supabase.from('compensation')
      .select(`
        *,
        employee:employees(full_name, position, department)
      `)
      .gte('created_at', startDate)
      .lte('created_at', endDate)
      .eq('status', 'approved');

    // Fetch attendance
    const { data: attendanceData } = await supabase.from('attendance')
      .select(`
        *,
        employee:employees!attendance_employee_id_fkey(full_name, position, department)
      `)
      .gte('date', startDate)
      .lte('date', endDate);

    // Fetch budget plans
    const { data: budgetPlansData } = await supabase.from('budget_plans')
      .select('*')
      .eq('fiscal_year', year)
      .or(`fiscal_month.eq.${month},fiscal_month.is.null`);

    const workbook = new ExcelJS.Workbook();

    // Helper function to add styled sheet
    const addSheet = (name: string, data: any[], emptyMessage: string) => {
      const ws = workbook.addWorksheet(name);
      if (data.length === 0) {
        ws.addRow([emptyMessage]);
        return ws;
      }
      
      const headers = Object.keys(data[0]);
      ws.columns = headers.map(h => ({ header: h, key: h, width: 18 }));
      data.forEach(row => ws.addRow(row));
      ws.getRow(1).font = { bold: true };
      ws.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFE0E0E0' }
      };
      return ws;
    };

    // 1. Payroll Sheet
    const payrollSheet = (payrollData || []).map(p => ({
      'თანამშრომელი': p.employees?.full_name || '',
      'პოზიცია': p.employees?.position || '',
      'დეპარტამენტი': p.employees?.department || '',
      'საბაზო ხელფასი': p.base_salary || 0,
      'საშემოსავლო გადასახადი (20%)': ((p.base_salary || 0) * 0.20).toFixed(2),
      'პენსიის გადასახადი (2%)': ((p.base_salary || 0) * 0.02).toFixed(2),
      'ჯამური გადასახადი': ((p.base_salary || 0) * 0.22).toFixed(2),
      'წმინდა ხელფასი': p.net_salary || ((p.base_salary || 0) * 0.78).toFixed(2),
      'ბონუსები': p.bonuses || 0,
      'დაქვითვები': p.deductions || 0,
      'სტატუსი': p.status || 'pending'
    }));
    addSheet('ხელფასები', payrollSheet, 'არ არის ხელფასის მონაცემები');

    // 2. Payslips
    const payslipsSheet = (payrollData || []).map(p => {
      const baseSalary = p.base_salary || 0;
      const bonuses = p.bonuses || 0;
      const gross = baseSalary + bonuses;
      const incomeTax = gross * 0.20;
      const pension = baseSalary * 0.02;
      const totalDeductions = incomeTax + pension + (p.deductions || 0);
      const netSalary = gross - totalDeductions;

      return {
        'თანამშრომელი': p.employees?.full_name || '',
        'პირადი ნომერი': p.employees?.personal_id_number || '',
        'პოზიცია': p.employees?.position || '',
        'დეპარტამენტი': p.employees?.department || '',
        'პერიოდი': `${month}/${year}`,
        'საბაზო ხელფასი': baseSalary.toFixed(2),
        'ბონუსები': bonuses.toFixed(2),
        'მთლიანი შემოსავალი': gross.toFixed(2),
        'საშემოსავლო გადასახადი (20%)': incomeTax.toFixed(2),
        'პენსიის გადასახადი (2%)': pension.toFixed(2),
        'სხვა დაქვითვები': (p.deductions || 0).toFixed(2),
        'ჯამური დაქვითვები': totalDeductions.toFixed(2),
        'გადასახდელი თანხა': netSalary.toFixed(2),
        'გადახდის თარიღი': p.paid_at || '-',
        'სტატუსი': p.status || 'pending'
      };
    });
    addSheet('ბიულეტინები', payslipsSheet, 'არ არის ბიულეტინები');

    // 3. Maternity Leave
    const maternityLeaves = (leavesData || []).filter(l => 
      l.leave_type === 'maternity' || l.leave_type === 'paternity'
    );
    const maternitySheet = maternityLeaves.map((leave: any) => {
      const days = leave.end_date && leave.start_date 
        ? Math.ceil((new Date(leave.end_date).getTime() - new Date(leave.start_date).getTime()) / (1000 * 60 * 60 * 24)) + 1
        : 0;
      const payroll = payrollData?.find(p => p.employee_id === leave.employee_id);
      const dailyRate = payroll ? (payroll.base_salary || 0) / 30 : 0;
      const amount = dailyRate * days;

      return {
        'თანამშრომელი': leave.employee?.full_name || '',
        'პოზიცია': leave.employee?.position || '',
        'დეპარტამენტი': leave.employee?.department || '',
        'შვებულების ტიპი': leave.leave_type === 'maternity' ? 'დეკრეტული (დედა)' : 'დეკრეტული (მამა)',
        'დაწყების თარიღი': leave.start_date,
        'დასრულების თარიღი': leave.end_date,
        'დღეების რაოდენობა': days,
        'დღიური განაკვეთი': dailyRate.toFixed(2),
        'გადასახდელი თანხა': amount.toFixed(2),
        'სტატუსი': leave.status
      };
    });
    addSheet('დეკრეტული', maternitySheet, 'არ არის დეკრეტული შვებულება ამ პერიოდში');

    // 4. Sick Leave
    const sickLeaves = (leavesData || []).filter((l: any) => l.leave_type === 'sick');
    const sickLeaveSheet = sickLeaves.map((leave: any) => {
      const days = leave.end_date && leave.start_date 
        ? Math.ceil((new Date(leave.end_date).getTime() - new Date(leave.start_date).getTime()) / (1000 * 60 * 60 * 24)) + 1
        : 0;
      const payroll = payrollData?.find(p => p.employee_id === leave.employee_id);
      const dailyRate = payroll ? (payroll.base_salary || 0) / 30 : 0;
      const amount = dailyRate * days * 0.7;

      return {
        'თანამშრომელი': leave.employee?.full_name || '',
        'პოზიცია': leave.employee?.position || '',
        'დღეების რაოდენობა': days,
        'დღიური განაკვეთი': dailyRate.toFixed(2),
        'კომპენსაცია (70%)': amount.toFixed(2),
        'დაწყება': leave.start_date,
        'დასრულება': leave.end_date,
        'სტატუსი': leave.status
      };
    });
    addSheet('ავადმყოფობა', sickLeaveSheet, 'არ არის ავადმყოფობის შვებულება');

    // 5. Overtime
    const overtimeSheet = (overtimeData || []).map((ot: any) => {
      const hours = ot.hours || 0;
      const employeePayroll = payrollData?.find(p => p.employee_id === ot.employee_id);
      const baseSalary = employeePayroll?.base_salary || 0;
      const hourlyRate = baseSalary / 160;
      const cost = hours * hourlyRate;
      
      return {
        'თანამშრომელი': ot.employees?.full_name || '',
        'დეპარტამენტი': ot.employees?.department || '',
        'თარიღი': ot.work_date || '-',
        'საათები': hours,
        'საათობრივი განაკვეთი': hourlyRate.toFixed(2),
        'ღირებულება': cost.toFixed(2),
        'მიზეზი': ot.reason || '-',
        'სტატუსი': ot.status || '-'
      };
    });
    addSheet('ზეგანაკვეთური', overtimeSheet, 'არ არის ზეგანაკვეთური');

    // 6. Pension
    const pensionSheet = (pensionData || []).map(p => ({
      'თანამშრომელი': p.employee?.full_name || '',
      'პირადი ნომერი': p.employee?.personal_id_number || '',
      'პოზიცია': p.employee?.position || '',
      'საბაზო ხელფასი': p.base_salary || 0,
      'თანამშრომლის წილი (2%)': p.employee_contribution || 0,
      'დამსაქმებლის წილი (2%)': p.employer_contribution || 0,
      'ჯამური თანხა': p.total_amount || 0,
      'გადახდის თარიღი': p.payment_date,
      'სტატუსი': p.status
    }));
    addSheet('პენსია', pensionSheet, 'არ არის პენსია');

    // 7. Compensations
    const compensationSheet = (compensationData || []).map(c => ({
      'თანამშრომელი': c.employee?.full_name || '',
      'პოზიცია': c.employee?.position || '',
      'დეპარტამენტი': c.employee?.department || '',
      'ტიპი': c.type === 'bonus' ? 'ბონუსი' : 'დაჯარიმება',
      'თანხა': c.amount || 0,
      'მიზეზი': c.reason || '-',
      'ბონუსის ტიპი': c.bonus_type || '-',
      'გადახდის თარიღი': c.payment_date || '-',
      'სტატუსი': c.status || '-'
    }));
    addSheet('კომპენსაციები', compensationSheet, 'არ არის კომპენსაცია/ბონუსები');

    // 8. Attendance
    const attendanceSheet = (attendanceData || []).map(a => {
      const checkIn = a.check_in || '';
      const checkOut = a.check_out || '';
      let hoursWorked = 0;
      
      if (checkIn && checkOut) {
        const [inH, inM] = checkIn.split(':').map(Number);
        const [outH, outM] = checkOut.split(':').map(Number);
        hoursWorked = ((outH * 60 + outM) - (inH * 60 + inM)) / 60;
      }

      return {
        'თარიღი': a.date,
        'თანამშრომელი': a.employee?.full_name || '',
        'პოზიცია': a.employee?.position || '',
        'შესვლა': checkIn,
        'გასვლა': checkOut,
        'სამუშაო საათები': hoursWorked.toFixed(2),
        'შესვენება (წთ)': a.break_duration || 0,
        'ზეგანაკვეთური': a.overtime_hours || 0,
        'სტატუსი': a.status || 'present'
      };
    });
    addSheet('დასწრება', attendanceSheet, 'არ არის დასწრება');

    // 9. Budget Plans
    const budgetPlansSheet = (budgetPlansData || []).map(b => ({
      'კატეგორია': b.category,
      'დაგეგმილი თანხა': b.planned_amount || 0,
      'ფაქტობრივი თანხა': b.actual_amount || 0,
      'ვარიაცია': b.variance || 0,
      'სტატუსი': b.status || '-',
      'ფისკალური წელი': b.fiscal_year,
      'კვარტალი': b.fiscal_quarter || '-',
      'თვე': b.fiscal_month || '-'
    }));
    addSheet('ბიუჯეტის გეგმები', budgetPlansSheet, 'არ არის ბიუჯეტის გეგმები');

    // 10. Budget Expenses
    const budgetSheet = (budgetData || []).map(b => ({
      'კატეგორია': b.category,
      'თანხა': b.amount,
      'აღწერა': b.description || '-',
      'თარიღი': b.expense_date,
      'სტატუსი': b.status
    }));
    addSheet('ბიუჯეტის ხარჯები', budgetSheet, 'არ არის ბიუჯეტის ხარჯები');

    // 11. Summary Sheet
    const totalPayroll = (payrollData || []).reduce((sum, p) => sum + (p.net_salary || 0), 0);
    const totalMaternity = maternityLeaves.reduce((sum: number, l: any) => {
      const days = l.end_date && l.start_date 
        ? Math.ceil((new Date(l.end_date).getTime() - new Date(l.start_date).getTime()) / (1000 * 60 * 60 * 24)) + 1
        : 0;
      const payroll = payrollData?.find(p => p.employee_id === l.employee_id);
      const dailyRate = payroll ? (payroll.base_salary || 0) / 30 : 0;
      return sum + (dailyRate * days);
    }, 0);
    const totalSick = sickLeaves.reduce((sum: number, l: any) => {
      const days = l.end_date && l.start_date 
        ? Math.ceil((new Date(l.end_date).getTime() - new Date(l.start_date).getTime()) / (1000 * 60 * 60 * 24)) + 1
        : 0;
      const payroll = payrollData?.find(p => p.employee_id === l.employee_id);
      const dailyRate = payroll ? (payroll.base_salary || 0) / 30 : 0;
      return sum + (dailyRate * days * 0.7);
    }, 0);
    const totalOvertime = (overtimeData || []).reduce((sum, o: any) => {
      const employeePayroll = payrollData?.find(p => p.employee_id === o.employee_id);
      const baseSalary = employeePayroll?.base_salary || 0;
      const hourlyRate = baseSalary / 160;
      return sum + ((o.hours || 0) * hourlyRate);
    }, 0);
    const totalPension = (pensionData || []).reduce((sum, p) => sum + (p.total_amount || 0), 0);
    const totalBudget = (budgetData || []).reduce((sum, b) => sum + (b.amount || 0), 0);
    const totalCompensation = (compensationData || []).reduce((sum, c) => sum + (c.amount || 0), 0);

    const summaryData = [
      { 'კატეგორია': 'ხელფასები (წმინდა)', 'თანხა (₾)': totalPayroll.toFixed(2) },
      { 'კატეგორია': 'დეკრეტული გადახდები', 'თანხა (₾)': totalMaternity.toFixed(2) },
      { 'კატეგორია': 'ავადმყოფობის კომპენსაცია', 'თანხა (₾)': totalSick.toFixed(2) },
      { 'კატეგორია': 'ზეგანაკვეთური გადახდები', 'თანხა (₾)': totalOvertime.toFixed(2) },
      { 'კატეგორია': 'პენსიის გადახდები', 'თანხა (₾)': totalPension.toFixed(2) },
      { 'კატეგორია': 'ბიუჯეტის ხარჯები', 'თანხა (₾)': totalBudget.toFixed(2) },
      { 'კატეგორია': 'კომპენსაციები/ბონუსები', 'თანხა (₾)': totalCompensation.toFixed(2) },
      { 'კატეგორია': '════════════════', 'თანხა (₾)': '══════════' },
      { 'კატეგორია': 'სულ ხარჯები', 'თანხა (₾)': (totalPayroll + totalMaternity + totalSick + totalOvertime + totalPension + totalBudget + totalCompensation).toFixed(2) }
    ];

    const summarySheet = workbook.addWorksheet('შეჯამება');
    summarySheet.columns = [
      { header: 'კატეგორია', key: 'კატეგორია', width: 30 },
      { header: 'თანხა (₾)', key: 'თანხა (₾)', width: 20 }
    ];
    summaryData.forEach(row => summarySheet.addRow(row));
    summarySheet.getRow(1).font = { bold: true };
    summarySheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    // Write file
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `სრული_ფინანსური_ანგარიში_${month}_${year}.xlsx`;
    link.click();
    window.URL.revokeObjectURL(url);

    return { success: true };
  } catch (error) {
    console.error('Error exporting financial report:', error);
    throw error;
  }
};
