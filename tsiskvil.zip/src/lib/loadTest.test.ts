import { describe, it, expect } from "vitest";
import { verdictFor, percentile, splitBatches } from "./loadTest";

describe("load test verdict", () => {
  it("passes when p95 under 1000ms and errors under 1%", () => {
    expect(verdictFor(999, 0.009)).toBe("pass");
  });
  it("is not pass at p95 exactly 1000ms", () => {
    expect(verdictFor(1000, 0)).toBe("borderline");
  });
  it("is not pass at 1% errors", () => {
    expect(verdictFor(200, 0.01)).toBe("borderline");
  });
  it("fails at p95 2000ms or 5% errors", () => {
    expect(verdictFor(2000, 0)).toBe("fail");
    expect(verdictFor(100, 0.05)).toBe("fail");
  });
  it("computes percentiles", () => {
    const a = Array.from({ length: 100 }, (_, i) => i + 1);
    expect(percentile(a, 95)).toBe(95);
  });
  it("splits 400 users into 8 batches of 50", () => {
    expect(splitBatches(400)).toEqual(Array(8).fill(50));
  });
});

import { equivalentRealUsers } from "./loadTest";
describe("real user equivalent", () => {
  it("229.6 req/s equals about 3444 real users at one request per 15s", () => {
    expect(equivalentRealUsers(229.6)).toBe(3444);
  });
});

import { initialDelayMs } from "./loadTest";
describe("staggered start", () => {
  it("realistic users start within 0-15s", () => {
    expect(initialDelayMs("realistic", 0)).toBe(0);
    expect(initialDelayMs("realistic", 0.9999999)).toBeLessThan(15000);
  });
  it("stress users start within 0-1s", () => {
    expect(initialDelayMs("stress", 0.5)).toBe(500);
    expect(initialDelayMs("stress", 1)).toBeLessThan(1000);
  });
});

import { overallVerdict } from "./loadTest";
describe("overallVerdict stress", () => {
  it("stress passes with 0 errors and capacity above users despite high p95", () => {
    expect(overallVerdict("stress", 2844, 0, 164.2, 200)).toBe("pass");
  });
  it("stress fails with 2% errors", () => {
    expect(overallVerdict("stress", 2844, 0.02, 164.2, 200)).not.toBe("pass");
  });
  it("realistic still uses p95", () => {
    expect(overallVerdict("realistic", 2844, 0, 164.2, 200)).toBe("fail");
  });
});
