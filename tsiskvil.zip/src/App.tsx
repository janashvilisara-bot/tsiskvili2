import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, HashRouter, Routes, Route, Navigate } from "react-router-dom";
// @ts-ignore - ThemeProvider exists at runtime
import { ThemeProvider } from "next-themes";
import ErrorBoundary from "./components/ErrorBoundary";
import Layout from "./components/Layout";
import Auth from "./pages/Auth";
import OfflineAuth from "./offline/OfflineAuth";
import { isOfflineStandalone } from "./offline/localStore";
import NotFound from "./pages/NotFound";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import { DemoProvider } from "./contexts/DemoContext";
import { SkinProvider } from "./contexts/SkinContext";
import { BranchProvider } from "./contexts/BranchContext";
import { PasswordChangePrompt } from "./components/PasswordChangePrompt";
import { PointsRealtimeToast } from "./components/gamification/PointsRealtimeToast";
const NinaChatWidget = lazy(() => import("./components/NinaChatWidget"));
const CursorFx = lazy(() => import("./components/CursorFx"));

// Lazy-loaded pages
const Setup = lazy(() => import("./pages/Setup"));
const OAuthConsent = lazy(() => import("./pages/OAuthConsent"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Employees = lazy(() => import("./pages/Employees"));
const EmployeeDetails = lazy(() => import("./pages/EmployeeDetails"));
const EmployeeEvaluations = lazy(() => import("./pages/EmployeeEvaluations"));
const Evaluations = lazy(() => import("./pages/Evaluations"));
const Contacts = lazy(() => import("./pages/Contacts"));
const Deals = lazy(() => import("./pages/Deals"));
const Settings = lazy(() => import("./pages/Settings"));
const OrganizationalStructure = lazy(() => import("./pages/OrganizationalStructure"));
const DepartmentDetails = lazy(() => import("./pages/DepartmentDetails"));
const Vacancies = lazy(() => import("./pages/Vacancies"));
const JobApplications = lazy(() => import("./pages/JobApplications"));
const VehicleRequests = lazy(() => import("./pages/VehicleRequests"));
const LeaveRequests = lazy(() => import("./pages/LeaveRequests"));
const Attendance = lazy(() => import("./pages/Attendance"));
const CalendarView = lazy(() => import("./pages/CalendarView"));
const Payroll = lazy(() => import("./pages/Payroll"));
const PayrollRunHistory = lazy(() => import("./pages/PayrollRunHistory"));
const PensionPayments = lazy(() => import("./pages/PensionPayments"));
const WorkTimeTracking = lazy(() => import("./pages/WorkTimeTracking"));
const Documents = lazy(() => import("./pages/Documents"));
const Notifications = lazy(() => import("./pages/Notifications"));
const WorkSchedules = lazy(() => import("./pages/WorkSchedules"));
const ShiftSchedules = lazy(() => import("./pages/ShiftSchedules"));
const PublicHolidays = lazy(() => import("./pages/PublicHolidays"));
const Reports = lazy(() => import("./pages/Reports"));
const Candidates = lazy(() => import("./pages/Candidates"));
const Recruitment = lazy(() => import("./pages/Recruitment"));
const Development = lazy(() => import("./pages/Development"));
const Organization = lazy(() => import("./pages/Organization"));
const System = lazy(() => import("./pages/System"));
const Finance = lazy(() => import("./pages/Finance"));
const Personnel = lazy(() => import("./pages/Personnel"));
const EmployeeDirectory = lazy(() => import("./pages/EmployeeDirectory"));
const AdminPanel = lazy(() => import("./pages/AdminPanel"));
const Chat = lazy(() => import("./pages/Chat"));
const Security = lazy(() => import("./pages/Security"));
const MobileAttendance = lazy(() => import("./pages/MobileAttendance"));
const InstallPWA = lazy(() => import("./pages/InstallPWA"));
const ResetPassword = lazy(() => import("./pages/ResetPassword"));
const Index = lazy(() => import("./pages/Index"));
const PricingInquiry = lazy(() => import("./pages/PricingInquiry"));
const PricingInquiryList = lazy(() => import("./pages/PricingInquiryList"));
const EmployeePortal = lazy(() => import("./pages/EmployeePortal"));
const EmployeeProfile = lazy(() => import("./pages/EmployeeProfile"));
const LeaveStatistics = lazy(() => import("./pages/LeaveStatistics"));
const Tasks = lazy(() => import("./pages/Tasks"));
const Help = lazy(() => import("./pages/Help"));
const Simulator = lazy(() => import("./pages/Simulator"));
const Disciplinary = lazy(() => import("./pages/Disciplinary"));
const Feedback = lazy(() => import("./pages/Feedback"));
const Training = lazy(() => import("./pages/Training"));
const Onboarding = lazy(() => import("./pages/Onboarding"));
const OnboardingTemplates = lazy(() => import("./pages/OnboardingTemplates"));
const Benefits = lazy(() => import("./pages/Benefits"));
const Compensation = lazy(() => import("./pages/Compensation"));
const FinancialDashboard = lazy(() => import("./pages/FinancialDashboard"));
const FinancialAnalytics = lazy(() => import("./pages/FinancialAnalytics"));
const OKRManagement = lazy(() => import("./pages/OKRManagement"));
const BranchManagement = lazy(() => import("./pages/BranchManagement"));
const BranchHiringStatsPage = lazy(() => import("./pages/BranchHiringStatsPage"));
const TravelDesk = lazy(() => import("./pages/TravelDesk"));
const SalaryBenchmarking = lazy(() => import("./pages/SalaryBenchmarking"));
const GrantedBenefits = lazy(() => import("./pages/GrantedBenefits"));
const BranchTransfers = lazy(() => import("./pages/BranchTransfers"));
const Recognition = lazy(() => import("./pages/Recognition"));
const GamificationAdmin = lazy(() => import("./pages/admin/GamificationAdmin"));
const CurrencyExchange = lazy(() => import("./pages/CurrencyExchange"));
const AssetManagement = lazy(() => import("./pages/AssetManagement"));
const BenefitsAdmin = lazy(() => import("./pages/BenefitsAdmin"));
const PulseSurveys = lazy(() => import("./pages/PulseSurveys"));
const BudgetPlanning = lazy(() => import("./pages/BudgetPlanning"));
const BudgetExpenses = lazy(() => import("./pages/BudgetExpenses"));
const RoleManagement = lazy(() => import("./pages/RoleManagement"));
const CustomRoleManagement = lazy(() => import("./pages/CustomRoleManagement"));
const SMSSettings = lazy(() => import("./pages/SMSSettings"));
const SMSReports = lazy(() => import("./pages/SMSReports"));
const AuthorizationReport = lazy(() => import("./pages/AuthorizationReport"));
const AutoLogoutReport = lazy(() => import("./pages/AutoLogoutReport"));
const WorkTimeReport = lazy(() => import("./pages/WorkTimeReport"));
const IdealAttendanceReport = lazy(() => import("./pages/IdealAttendanceReport"));
const UnscheduledAttendanceReport = lazy(() => import("./pages/UnscheduledAttendanceReport"));
const ScheduleTemplates = lazy(() => import("./pages/ScheduleTemplates"));
const CompanySettings = lazy(() => import("./pages/CompanySettings"));
const JobDescriptions = lazy(() => import("./pages/JobDescriptions"));
const AuditLogs = lazy(() => import("./pages/AuditLogs"));
const ServiceTrips = lazy(() => import("./pages/ServiceTrips"));
const BusinessTripRequests = lazy(() => import("./pages/BusinessTripRequests"));
const AttendanceAnalytics = lazy(() => import("./pages/AttendanceAnalytics"));
const VideoTutorialManagement = lazy(() => import("./pages/VideoTutorialManagement"));
const ContractTemplates = lazy(() => import("./pages/ContractTemplates"));
const FinancialReports = lazy(() => import("./pages/FinancialReports"));
const WorkTimeFormGenerator = lazy(() => import("./pages/WorkTimeFormGenerator"));
const ChillOutReport = lazy(() => import("./pages/ChillOutReport"));
const TestDataGenerator = lazy(() => import("./pages/TestDataGenerator"));
const Announcements = lazy(() => import("./pages/Announcements"));
const OvertimeRequests = lazy(() => import("./pages/OvertimeRequests"));
const OvertimeReports = lazy(() => import("./pages/OvertimeReports"));
const DocumentReports = lazy(() => import("./pages/DocumentReports"));
const FinancialDocumentation = lazy(() => import("./pages/FinancialDocumentation"));
const LeaveTypes = lazy(() => import("./pages/LeaveTypes"));
const UserActivityMonitoring = lazy(() => import("./pages/UserActivityMonitoring"));
const PrivacyPolicy = lazy(() => import("./pages/PrivacyPolicy"));
const TermsOfService = lazy(() => import("./pages/TermsOfService"));
const CookiePolicy = lazy(() => import("./pages/CookiePolicy"));
const DataProtection = lazy(() => import("./pages/DataProtection"));
const AIDPO = lazy(() => import("./pages/AIDPO"));
const AdvertisementManagement = lazy(() => import("./pages/AdvertisementManagement"));
const DeletedRecords = lazy(() => import("./pages/DeletedRecords"));
const LoginHistory = lazy(() => import("./pages/LoginHistory"));
const Demo = lazy(() => import("./pages/Demo"));
const DemoLanding = lazy(() => import("./pages/DemoLanding"));
const SupportTickets = lazy(() => import("./pages/SupportTickets"));
const DatabaseBackup = lazy(() => import("./pages/DatabaseBackup"));
const LaborInspectionReport = lazy(() => import("./pages/LaborInspectionReport"));
const RsgeRegistry = lazy(() => import("./pages/RsgeRegistry"));
const ComplianceDashboard = lazy(() => import("./pages/ComplianceDashboard"));
const KnowledgeBase = lazy(() => import("./pages/KnowledgeBase"));
const Wiki = lazy(() => import("./pages/Wiki"));
const AIDocuments = lazy(() => import("./pages/AIDocuments"));
const SignifyIntegration = lazy(() => import("./pages/SignifyIntegration"));
const Integrations = lazy(() => import("./pages/Integrations"));
const SignifyCallback = lazy(() => import("./pages/SignifyCallback"));
const ClientAdminPanel = lazy(() => import("./pages/ClientAdminPanel"));
const Changelog = lazy(() => import("./pages/Changelog"));
const HRAnalytics = lazy(() => import("./pages/HRAnalytics"));
const EmployeeWellness = lazy(() => import("./pages/EmployeeWellness"));
const EngagementAnalytics = lazy(() => import("./pages/EngagementAnalytics"));
const InternalMobility = lazy(() => import("./pages/InternalMobility"));
const HeadcountPlanning = lazy(() => import("./pages/HeadcountPlanning"));
const SkillsMatrix = lazy(() => import("./pages/SkillsMatrix"));
const TalentMap = lazy(() => import("./pages/TalentMap"));
const LoadTest = lazy(() => import("./pages/LoadTest"));
const ExitInterview = lazy(() => import("./pages/ExitInterview"));
const LicenseManagement = lazy(() => import("./pages/LicenseManagement"));
const FeatureToggles = lazy(() => import("./pages/FeatureToggles"));
const HRTools = lazy(() => import("./pages/HRTools"));
const ReportBuilder = lazy(() => import("./pages/ReportBuilder"));
const WorkflowBuilder = lazy(() => import("./pages/WorkflowBuilder"));
const ApprovalChains = lazy(() => import("./pages/ApprovalChains"));
const Offboarding = lazy(() => import("./pages/Offboarding"));
const DepartmentManagerDashboard = lazy(() => import("./pages/DepartmentManagerDashboard"));
const AttendanceWithoutSchedule = lazy(() => import("./pages/AttendanceWithoutSchedule"));
const ManagerHeadcount = lazy(() => import("./pages/ManagerHeadcount"));
const GoogleDriveReturn = lazy(() => import("./pages/oauth/GoogleDriveReturn"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: 60_000,
    },
  },
});
const Router = window.location.protocol === "file:" ? HashRouter : BrowserRouter;
const offlineStandalone = isOfflineStandalone();
const AuthPage = offlineStandalone ? OfflineAuth : Auth;
const HomeRoute = offlineStandalone ? <Navigate to="/employees" replace /> : <ProtectedRoute><Layout><EmployeePortal /></Layout></ProtectedRoute>;

const PageLoader = () => (
  <div className="flex h-screen items-center justify-center bg-gradient-to-br from-background via-background to-primary/5">
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        <div className="h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin" />
        <div className="absolute inset-0 h-16 w-16 rounded-full bg-primary/10 blur-xl animate-pulse" />
      </div>
      <p className="text-lg font-medium text-muted-foreground animate-pulse">იტვირთება...</p>
    </div>
  </div>
);

function ProtectedRoute({ children, requireRole, strictRole }: { children: React.ReactNode; requireRole?: 'admin' | 'hr_manager' | 'department_manager' | 'employee'; strictRole?: boolean }) {
  const { user, loading, userRole } = useAuth();
  
  if (loading || (user && requireRole && userRole === null)) {
    return <PageLoader />;
  }
  
  if (!user) {
    return <Navigate to="/auth" replace />;
  }
  
  if (requireRole) {
    // strictRole means ONLY that exact role can access
    if (strictRole) {
      if (userRole !== requireRole) {
        return <Navigate to="/" replace />;
      }
    } else {
      const canManage = userRole === 'admin' || userRole === 'hr_manager' || userRole === 'department_manager';
      
      if (requireRole === 'employee') {
        return <>{children}</>;
      } else if (requireRole === 'admin' || requireRole === 'hr_manager' || requireRole === 'department_manager') {
        if (!canManage) {
          return <Navigate to="/" replace />;
        }
      }
    }
  }
  
  return <>{children}</>;
}

const App = () => (
  <ErrorBoundary>
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
    <SkinProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <Router
          future={{
            v7_startTransition: true,
            v7_relativeSplatPath: true,
          }}
        >
          <LanguageProvider>
            <DemoProvider>
              <AuthProvider>
              <BranchProvider>
              <PasswordChangePrompt />
              <PointsRealtimeToast />
              <Suspense fallback={null}><CursorFx /></Suspense>
              <Suspense fallback={<PageLoader />}>
              <Routes>
            <Route path="/auth" element={<AuthPage />} />
            <Route path="/setup" element={<Setup />} />
            <Route path="/.lovable/oauth/consent" element={<OAuthConsent />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/demo" element={<Demo />} />
            <Route path="/demo-landing" element={<DemoLanding />} />
            <Route path="/jobs" element={<JobApplications />} />
            <Route path="/pricing-inquiry" element={<PricingInquiry />} />
            <Route path="/get-quote" element={<PricingInquiry />} />
            <Route path="/pricing-inquiries" element={<ProtectedRoute requireRole="admin"><Layout><PricingInquiryList /></Layout></ProtectedRoute>} />
            <Route path="/mobile-attendance" element={<ProtectedRoute><MobileAttendance /></ProtectedRoute>} />
            <Route path="/employee-portal" element={HomeRoute} />
            <Route path="/employee-profile" element={<ProtectedRoute><Layout><EmployeeProfile /></Layout></ProtectedRoute>} />
            <Route path="/install" element={<InstallPWA />} />
            <Route path="/index" element={<Index />} />
            <Route path="/" element={HomeRoute} />
            <Route path="/dashboard" element={<ProtectedRoute><Layout><Dashboard /></Layout></ProtectedRoute>} />
            <Route path="/employees" element={<ProtectedRoute><Layout><Employees /></Layout></ProtectedRoute>} />
            <Route path="/personnel" element={<ProtectedRoute><Layout><Personnel /></Layout></ProtectedRoute>} />
            <Route path="/employee-directory" element={<ProtectedRoute><Layout><EmployeeDirectory /></Layout></ProtectedRoute>} />
            <Route path="/employees/:id" element={<ProtectedRoute><Layout><EmployeeDetails /></Layout></ProtectedRoute>} />
            <Route path="/employee-evaluations" element={<ProtectedRoute><Layout><Evaluations /></Layout></ProtectedRoute>} />
            <Route path="/employee-evaluations/:id" element={<ProtectedRoute><Layout><EmployeeEvaluations /></Layout></ProtectedRoute>} />
            <Route path="/employees/:id/evaluations" element={<ProtectedRoute><Layout><EmployeeEvaluations /></Layout></ProtectedRoute>} />
            <Route path="/contacts" element={<ProtectedRoute><Layout><Contacts /></Layout></ProtectedRoute>} />
            <Route path="/deals" element={<ProtectedRoute><Layout><Deals /></Layout></ProtectedRoute>} />
            <Route path="/leave-requests" element={<ProtectedRoute><Layout><LeaveRequests /></Layout></ProtectedRoute>} />
            <Route path="/attendance" element={<ProtectedRoute><Layout><Attendance /></Layout></ProtectedRoute>} />
            <Route path="/calendar" element={<ProtectedRoute><Layout><CalendarView /></Layout></ProtectedRoute>} />
            <Route path="/payroll" element={<ProtectedRoute><Layout><Payroll /></Layout></ProtectedRoute>} />
            <Route path="/payroll/history" element={<ProtectedRoute><Layout><PayrollRunHistory /></Layout></ProtectedRoute>} />
            <Route path="/finance" element={<ProtectedRoute><Layout><Finance /></Layout></ProtectedRoute>} />
            <Route path="/pension-payments" element={<ProtectedRoute><Layout><PensionPayments /></Layout></ProtectedRoute>} />
            <Route path="/work-time-tracking" element={<ProtectedRoute><Layout><WorkTimeTracking /></Layout></ProtectedRoute>} />
            <Route path="/documents" element={<ProtectedRoute><Layout><Documents /></Layout></ProtectedRoute>} />
            <Route path="/notifications" element={<ProtectedRoute><Layout><Notifications /></Layout></ProtectedRoute>} />
            <Route path="/work-schedules" element={<ProtectedRoute><Layout><WorkSchedules /></Layout></ProtectedRoute>} />
            <Route path="/shift-schedules" element={<ProtectedRoute><Layout><ShiftSchedules /></Layout></ProtectedRoute>} />
            <Route path="/public-holidays" element={<ProtectedRoute><Layout><PublicHolidays /></Layout></ProtectedRoute>} />
            <Route path="/reports" element={<ProtectedRoute><Layout><Reports /></Layout></ProtectedRoute>} />
            <Route path="/financial-reports" element={<ProtectedRoute><Layout><FinancialReports /></Layout></ProtectedRoute>} />
            <Route path="/leave-statistics" element={<ProtectedRoute><Layout><LeaveStatistics /></Layout></ProtectedRoute>} />
            <Route path="/vacancies" element={<ProtectedRoute><Layout><Vacancies /></Layout></ProtectedRoute>} />
            <Route path="/candidates" element={<ProtectedRoute><Layout><Candidates /></Layout></ProtectedRoute>} />
            <Route path="/recruitment" element={<ProtectedRoute><Layout><Recruitment /></Layout></ProtectedRoute>} />
            <Route path="/chat" element={<ProtectedRoute><Layout><Chat /></Layout></ProtectedRoute>} />
            <Route path="/vehicle-requests" element={<ProtectedRoute><Layout><VehicleRequests /></Layout></ProtectedRoute>} />
            
            <Route path="/organizational-structure" element={<ProtectedRoute><Layout><OrganizationalStructure /></Layout></ProtectedRoute>} />
            <Route path="/organization" element={<ProtectedRoute><Layout><Organization /></Layout></ProtectedRoute>} />
            <Route path="/department/:id" element={<ProtectedRoute><Layout><DepartmentDetails /></Layout></ProtectedRoute>} />
            <Route path="/disciplinary" element={<ProtectedRoute><Layout><Disciplinary /></Layout></ProtectedRoute>} />
            <Route path="/feedback" element={<ProtectedRoute><Layout><Feedback /></Layout></ProtectedRoute>} />
            <Route path="/admin-panel" element={<ProtectedRoute><Layout><AdminPanel /></Layout></ProtectedRoute>} />
            <Route path="/security" element={<ProtectedRoute><Layout><Security /></Layout></ProtectedRoute>} />
            <Route path="/tasks" element={<ProtectedRoute><Layout><Tasks /></Layout></ProtectedRoute>} />
            <Route path="/settings" element={<ProtectedRoute><Layout><Settings /></Layout></ProtectedRoute>} />
            <Route path="/system" element={<ProtectedRoute><Layout><System /></Layout></ProtectedRoute>} />
            <Route path="/help" element={<ProtectedRoute><Layout><Help /></Layout></ProtectedRoute>} />
            <Route path="/simulator" element={<ProtectedRoute><Layout><Simulator /></Layout></ProtectedRoute>} />
            <Route path="/training" element={<ProtectedRoute><Layout><Training /></Layout></ProtectedRoute>} />
            <Route path="/development" element={<ProtectedRoute><Layout><Development /></Layout></ProtectedRoute>} />
            <Route path="/onboarding" element={<ProtectedRoute><Layout><Onboarding /></Layout></ProtectedRoute>} />
            <Route path="/onboarding-templates" element={<ProtectedRoute><Layout><OnboardingTemplates /></Layout></ProtectedRoute>} />
            <Route path="/benefits" element={<ProtectedRoute><Layout><Benefits /></Layout></ProtectedRoute>} />
            <Route path="/benefits-admin" element={<ProtectedRoute><Layout><BenefitsAdmin /></Layout></ProtectedRoute>} />
            <Route path="/compensation" element={<ProtectedRoute><Layout><Compensation /></Layout></ProtectedRoute>} />
            <Route path="/financial-dashboard" element={<ProtectedRoute><Layout><FinancialDashboard /></Layout></ProtectedRoute>} />
            <Route path="/financial-analytics" element={<ProtectedRoute><Layout><FinancialAnalytics /></Layout></ProtectedRoute>} />
            <Route path="/okr" element={<ProtectedRoute><Layout><OKRManagement /></Layout></ProtectedRoute>} />
            <Route path="/recognition" element={<ProtectedRoute><Layout><Recognition /></Layout></ProtectedRoute>} />
            <Route path="/admin/gamification" element={<ProtectedRoute requireRole="admin"><Layout><GamificationAdmin /></Layout></ProtectedRoute>} />
            <Route path="/currency-exchange" element={<ProtectedRoute requireRole="admin"><Layout><CurrencyExchange /></Layout></ProtectedRoute>} />
            <Route path="/pulse-surveys" element={<ProtectedRoute><Layout><PulseSurveys /></Layout></ProtectedRoute>} />
            <Route path="/assets" element={<ProtectedRoute><Layout><AssetManagement /></Layout></ProtectedRoute>} />
            <Route path="/budget-planning" element={<ProtectedRoute><Layout><BudgetPlanning /></Layout></ProtectedRoute>} />
            <Route path="/budget-expenses" element={<ProtectedRoute><Layout><BudgetExpenses /></Layout></ProtectedRoute>} />
            <Route path="/budget" element={<Navigate to="/budget-planning" replace />} />
            <Route path="/role-management" element={<ProtectedRoute requireRole="admin"><Layout><RoleManagement /></Layout></ProtectedRoute>} />
            <Route path="/custom-role-management" element={<ProtectedRoute requireRole="admin"><Layout><CustomRoleManagement /></Layout></ProtectedRoute>} />
            <Route path="/sms-settings" element={<ProtectedRoute><Layout><SMSSettings /></Layout></ProtectedRoute>} />
            <Route path="/sms-reports" element={<ProtectedRoute requireRole="admin"><Layout><SMSReports /></Layout></ProtectedRoute>} />
            <Route path="/authorization-report" element={<ProtectedRoute requireRole="admin"><Layout><AuthorizationReport /></Layout></ProtectedRoute>} />
            <Route path="/auto-logout-report" element={<ProtectedRoute requireRole="admin"><Layout><AutoLogoutReport /></Layout></ProtectedRoute>} />
            <Route path="/schedule-templates" element={<ProtectedRoute requireRole="admin"><Layout><ScheduleTemplates /></Layout></ProtectedRoute>} />
            <Route path="/company-settings" element={<ProtectedRoute requireRole="admin"><Layout><CompanySettings /></Layout></ProtectedRoute>} />
            <Route path="/job-descriptions" element={<ProtectedRoute><Layout><JobDescriptions /></Layout></ProtectedRoute>} />
            <Route path="/audit-logs" element={<ProtectedRoute requireRole="admin"><Layout><AuditLogs /></Layout></ProtectedRoute>} />
            <Route path="/service-trips" element={<ProtectedRoute><Layout><ServiceTrips /></Layout></ProtectedRoute>} />
            <Route path="/business-trip-requests" element={<ProtectedRoute><Layout><BusinessTripRequests /></Layout></ProtectedRoute>} />
            <Route path="/attendance-analytics" element={<ProtectedRoute requireRole="admin"><Layout><AttendanceAnalytics /></Layout></ProtectedRoute>} />
            <Route path="/video-tutorial-management" element={<ProtectedRoute requireRole="admin"><Layout><VideoTutorialManagement /></Layout></ProtectedRoute>} />
            
            <Route path="/work-time-form-generator" element={<ProtectedRoute requireRole="admin"><Layout><WorkTimeFormGenerator /></Layout></ProtectedRoute>} />
            <Route path="/announcements" element={<ProtectedRoute><Layout><Announcements /></Layout></ProtectedRoute>} />
            <Route path="/overtime-requests" element={<ProtectedRoute><Layout><OvertimeRequests /></Layout></ProtectedRoute>} />
            <Route path="/overtime-reports" element={<ProtectedRoute requireRole="admin"><Layout><OvertimeReports /></Layout></ProtectedRoute>} />
            <Route path="/document-reports" element={<ProtectedRoute requireRole="admin"><Layout><DocumentReports /></Layout></ProtectedRoute>} />
            <Route path="/financial-documentation" element={<ProtectedRoute><Layout><FinancialDocumentation /></Layout></ProtectedRoute>} />
            <Route path="/work-time-report" element={<ProtectedRoute requireRole="admin"><Layout><WorkTimeReport /></Layout></ProtectedRoute>} />
            <Route path="/ideal-attendance-report" element={<ProtectedRoute requireRole="admin"><Layout><IdealAttendanceReport /></Layout></ProtectedRoute>} />
            <Route path="/unscheduled-attendance-report" element={<ProtectedRoute requireRole="admin"><Layout><UnscheduledAttendanceReport /></Layout></ProtectedRoute>} />
            <Route path="/chill-out-report" element={<ProtectedRoute requireRole="admin"><Layout><ChillOutReport /></Layout></ProtectedRoute>} />
            <Route path="/contract-templates" element={<ProtectedRoute requireRole="admin"><Layout><ContractTemplates /></Layout></ProtectedRoute>} />
            <Route path="/test-data-generator" element={<ProtectedRoute requireRole="admin"><Layout><TestDataGenerator /></Layout></ProtectedRoute>} />
            <Route path="/leave-types" element={<ProtectedRoute requireRole="admin"><Layout><LeaveTypes /></Layout></ProtectedRoute>} />
            <Route path="/user-activity-monitoring" element={<ProtectedRoute requireRole="admin"><Layout><UserActivityMonitoring /></Layout></ProtectedRoute>} />
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route path="/terms-of-service" element={<TermsOfService />} />
            <Route path="/cookie-policy" element={<CookiePolicy />} />
            <Route path="/data-protection" element={<ProtectedRoute><Layout><DataProtection /></Layout></ProtectedRoute>} />
            <Route path="/ai-dpo" element={<ProtectedRoute requireRole="admin"><Layout><AIDPO /></Layout></ProtectedRoute>} />
            <Route path="/advertisement-management" element={<ProtectedRoute requireRole="admin"><Layout><AdvertisementManagement /></Layout></ProtectedRoute>} />
            <Route path="/deleted-records" element={<ProtectedRoute requireRole="admin"><Layout><DeletedRecords /></Layout></ProtectedRoute>} />
            <Route path="/login-history" element={<ProtectedRoute requireRole="admin"><Layout><LoginHistory /></Layout></ProtectedRoute>} />
            <Route path="/support-tickets" element={<ProtectedRoute><Layout><SupportTickets /></Layout></ProtectedRoute>} />
            <Route path="/database-backup" element={<ProtectedRoute requireRole="admin"><Layout><DatabaseBackup /></Layout></ProtectedRoute>} />
            <Route path="/rsge-registry" element={<ProtectedRoute requireRole="admin"><Layout><RsgeRegistry /></Layout></ProtectedRoute>} />
            <Route path="/labor-inspection-report" element={<ProtectedRoute requireRole="admin"><Layout><LaborInspectionReport /></Layout></ProtectedRoute>} />
            <Route path="/compliance-dashboard" element={<ProtectedRoute requireRole="admin"><Layout><ComplianceDashboard /></Layout></ProtectedRoute>} />
            <Route path="/knowledge-base" element={<ProtectedRoute requireRole="admin"><Layout><KnowledgeBase /></Layout></ProtectedRoute>} />
            <Route path="/wiki" element={<ProtectedRoute><Layout><Wiki /></Layout></ProtectedRoute>} />
            <Route path="/wiki/:spaceKey" element={<ProtectedRoute><Layout><Wiki /></Layout></ProtectedRoute>} />
            <Route path="/wiki/:spaceKey/:pageSlug" element={<ProtectedRoute><Layout><Wiki /></Layout></ProtectedRoute>} />
            <Route path="/ai-documents" element={<ProtectedRoute><Layout><AIDocuments /></Layout></ProtectedRoute>} />
            <Route path="/signify-integration" element={<ProtectedRoute><Layout><SignifyIntegration /></Layout></ProtectedRoute>} />
            <Route path="/integrations" element={<ProtectedRoute requireRole="admin"><Layout><Integrations /></Layout></ProtectedRoute>} />
            <Route path="/signify-callback" element={<ProtectedRoute><SignifyCallback /></ProtectedRoute>} />
            <Route path="/client-admin" element={<ProtectedRoute requireRole="admin"><Layout><ClientAdminPanel /></Layout></ProtectedRoute>} />
            <Route path="/changelog" element={<ProtectedRoute><Layout><Changelog /></Layout></ProtectedRoute>} />
            <Route path="/hr-analytics" element={<ProtectedRoute requireRole="admin"><Layout><HRAnalytics /></Layout></ProtectedRoute>} />
            <Route path="/employee-wellness" element={<ProtectedRoute><Layout><EmployeeWellness /></Layout></ProtectedRoute>} />
            <Route path="/engagement-analytics" element={<ProtectedRoute requireRole="admin"><Layout><EngagementAnalytics /></Layout></ProtectedRoute>} />
            <Route path="/internal-mobility" element={<ProtectedRoute><Layout><InternalMobility /></Layout></ProtectedRoute>} />
            <Route path="/headcount-planning" element={<ProtectedRoute requireRole="admin"><Layout><HeadcountPlanning /></Layout></ProtectedRoute>} />
            <Route path="/skills-matrix" element={<ProtectedRoute><Layout><SkillsMatrix /></Layout></ProtectedRoute>} />
            <Route path="/talent-map" element={<ProtectedRoute><Layout><TalentMap /></Layout></ProtectedRoute>} />
            <Route path="/load-test" element={<ProtectedRoute requireRole="admin"><Layout><LoadTest /></Layout></ProtectedRoute>} />
            <Route path="/exit-interview" element={<ProtectedRoute requireRole="admin"><Layout><ExitInterview /></Layout></ProtectedRoute>} />
            <Route path="/hr-tools" element={<ProtectedRoute><Layout><HRTools /></Layout></ProtectedRoute>} />
            <Route path="/report-builder" element={<ProtectedRoute requireRole="admin"><Layout><ReportBuilder /></Layout></ProtectedRoute>} />
            <Route path="/workflow-builder" element={<ProtectedRoute requireRole="admin"><Layout><WorkflowBuilder /></Layout></ProtectedRoute>} />
            <Route path="/approval-chains" element={<ProtectedRoute requireRole="admin"><Layout><ApprovalChains /></Layout></ProtectedRoute>} />
            <Route path="/offboarding" element={<ProtectedRoute requireRole="admin"><Layout><Offboarding /></Layout></ProtectedRoute>} />
            <Route path="/license-management" element={<ProtectedRoute requireRole="admin" strictRole><Layout><LicenseManagement /></Layout></ProtectedRoute>} />
            <Route path="/feature-toggles" element={<ProtectedRoute requireRole="admin" strictRole><Layout><FeatureToggles /></Layout></ProtectedRoute>} />
            <Route path="/branch-hiring-stats" element={<ProtectedRoute><Layout><BranchHiringStatsPage /></Layout></ProtectedRoute>} />
            <Route path="/granted-benefits" element={<ProtectedRoute><Layout><GrantedBenefits /></Layout></ProtectedRoute>} />
            <Route path="/travel-desk" element={<ProtectedRoute><Layout><TravelDesk /></Layout></ProtectedRoute>} />
            <Route path="/salary-benchmarking" element={<ProtectedRoute><Layout><SalaryBenchmarking /></Layout></ProtectedRoute>} />

            <Route path="/branches" element={<ProtectedRoute requireRole="admin"><Layout><BranchManagement /></Layout></ProtectedRoute>} />
            <Route path="/branch-transfers" element={<ProtectedRoute requireRole="admin"><Layout><BranchTransfers /></Layout></ProtectedRoute>} />
            <Route path="/manager-dashboard" element={<ProtectedRoute><Layout><DepartmentManagerDashboard /></Layout></ProtectedRoute>} />
            <Route path="/manager-headcount" element={<ProtectedRoute><Layout><ManagerHeadcount /></Layout></ProtectedRoute>} />
            <Route path="/attendance-without-schedule" element={<ProtectedRoute><Layout><AttendanceWithoutSchedule /></Layout></ProtectedRoute>} />
            <Route path="/oauth/google-drive/return" element={<GoogleDriveReturn />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
          </Suspense>
          <Suspense fallback={null}><NinaChatWidget /></Suspense>
          </BranchProvider>
          </AuthProvider>
          </DemoProvider>
        </LanguageProvider>
      </Router>
    </TooltipProvider>
  </QueryClientProvider>
  </SkinProvider>
  </ThemeProvider>
  </ErrorBoundary>
);

export default App;
