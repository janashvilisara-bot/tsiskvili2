import { useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface SessionTimeoutConfig {
  timeoutMinutes?: number;      // Time until session expires (default: 30 minutes)
  warningMinutes?: number;      // Time before timeout to show warning (default: 5 minutes)
  onTimeout?: () => void;       // Callback when session times out
  onWarning?: () => void;       // Callback when warning is shown
  enabled?: boolean;            // Whether session timeout is enabled
}

const DEFAULT_TIMEOUT_MINUTES = 30;
const DEFAULT_WARNING_MINUTES = 5;

export function useSessionTimeout(config: SessionTimeoutConfig = {}) {
  const {
    timeoutMinutes = DEFAULT_TIMEOUT_MINUTES,
    warningMinutes = DEFAULT_WARNING_MINUTES,
    onTimeout,
    onWarning,
    enabled = true,
  } = config;

  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const warningRef = useRef<NodeJS.Timeout | null>(null);
  const lastActivityRef = useRef<number>(Date.now());
  const warningShownRef = useRef<boolean>(false);

  const handleTimeout = useCallback(async () => {
    
    if (onTimeout) {
      onTimeout();
    } else {
      toast.error('სესია ამოიწურა უმოქმედობის გამო. გთხოვთ შეხვიდეთ თავიდან.', {
        duration: 5000,
      });
      await supabase.auth.signOut();
      window.location.href = '/auth';
    }
  }, [onTimeout]);

  const handleWarning = useCallback(() => {
    if (warningShownRef.current) return;
    warningShownRef.current = true;

    if (onWarning) {
      onWarning();
    } else {
      toast.warning(`სესია ამოიწურება ${warningMinutes} წუთში უმოქმედობის გამო`, {
        duration: 10000,
        action: {
          label: 'გაგრძელება',
          onClick: () => {
            resetTimer();
          },
        },
      });
    }
  }, [onWarning, warningMinutes]);

  const resetTimer = useCallback(() => {
    if (!enabled) return;

    lastActivityRef.current = Date.now();
    warningShownRef.current = false;

    // Clear existing timers
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    if (warningRef.current) {
      clearTimeout(warningRef.current);
    }

    // Set warning timer
    const warningTime = (timeoutMinutes - warningMinutes) * 60 * 1000;
    warningRef.current = setTimeout(handleWarning, warningTime);

    // Set timeout timer
    const timeoutTime = timeoutMinutes * 60 * 1000;
    timeoutRef.current = setTimeout(handleTimeout, timeoutTime);
  }, [enabled, timeoutMinutes, warningMinutes, handleWarning, handleTimeout]);

  useEffect(() => {
    if (!enabled) return;

    // Activity events to track
    const events = [
      'mousedown',
      'mousemove',
      'keydown',
      'scroll',
      'touchstart',
      'click',
    ];

    // Throttle reset to avoid excessive timer resets
    let throttleTimer: NodeJS.Timeout | null = null;
    const throttledReset = () => {
      if (throttleTimer) return;
      throttleTimer = setTimeout(() => {
        throttleTimer = null;
        resetTimer();
      }, 1000); // Throttle to once per second
    };

    // Add event listeners
    events.forEach((event) => {
      document.addEventListener(event, throttledReset, { passive: true });
    });

    // Initial timer start
    resetTimer();

    // Cleanup
    return () => {
      events.forEach((event) => {
        document.removeEventListener(event, throttledReset);
      });
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      if (warningRef.current) {
        clearTimeout(warningRef.current);
      }
      if (throttleTimer) {
        clearTimeout(throttleTimer);
      }
    };
  }, [enabled, resetTimer]);

  return {
    resetTimer,
    getLastActivity: () => lastActivityRef.current,
    getRemainingTime: () => {
      const elapsed = Date.now() - lastActivityRef.current;
      const remaining = (timeoutMinutes * 60 * 1000) - elapsed;
      return Math.max(0, remaining);
    },
  };
}
