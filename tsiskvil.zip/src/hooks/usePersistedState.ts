import { useEffect, useState } from "react";

/**
 * useState that persists to localStorage under a namespaced key,
 * so search/filter state survives page navigation.
 */
export function usePersistedState<T>(
  key: string,
  initial: T
): [T, React.Dispatch<React.SetStateAction<T>>] {
  const storageKey = `talentos-ui:${key}`;
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw !== null) return JSON.parse(raw) as T;
    } catch {
      // ignore malformed stored values
    }
    return initial;
  });

  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(value));
    } catch {
      // storage unavailable
    }
  }, [storageKey, value]);

  return [value, setValue];
}
