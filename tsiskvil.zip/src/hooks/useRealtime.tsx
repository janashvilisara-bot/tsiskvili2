import { useEffect, useState, useRef, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { RealtimeChannel } from '@supabase/supabase-js';
import { isOfflineStandalone } from '@/offline/localStore';

interface UseRealtimeOptions {
  table: string;
  event?: 'INSERT' | 'UPDATE' | 'DELETE' | '*';
  schema?: string;
  filter?: string;
  onInsert?: (payload: any) => void;
  onUpdate?: (payload: any) => void;
  onDelete?: (payload: any) => void;
  onChange?: (payload: any) => void;
}

/**
 * Custom hook for managing Supabase Realtime subscriptions
 * Automatically handles subscription setup, cleanup, and loading states
 * 
 * @example
 * ```tsx
 * const { isSubscribed, error } = useRealtime({
 *   table: 'tasks',
 *   event: '*',
 *   onChange: (payload) => {
 *     fetchTasks();
 *   }
 * });
 * ```
 */
export function useRealtime({
  table,
  event = '*',
  schema = 'public',
  filter,
  onInsert,
  onUpdate,
  onDelete,
  onChange,
}: UseRealtimeOptions) {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [channel, setChannel] = useState<RealtimeChannel | null>(null);

  // Use refs to store callbacks to avoid re-subscription on every render
  const onInsertRef = useRef(onInsert);
  const onUpdateRef = useRef(onUpdate);
  const onDeleteRef = useRef(onDelete);
  const onChangeRef = useRef(onChange);

  // Update refs when callbacks change
  useEffect(() => {
    onInsertRef.current = onInsert;
    onUpdateRef.current = onUpdate;
    onDeleteRef.current = onDelete;
    onChangeRef.current = onChange;
  }, [onInsert, onUpdate, onDelete, onChange]);

  useEffect(() => {
    if (isOfflineStandalone()) {
      setIsSubscribed(true);
      setError(null);
      return;
    }

    
    // Create unique channel name
    const channelName = `${table}-${event}-${Date.now()}`;
    
    // Create channel
    const realtimeChannel = supabase.channel(channelName);

    // Configure postgres changes listener
    const config: any = {
      event,
      schema,
      table,
    };

    if (filter) {
      config.filter = filter;
    }

    realtimeChannel.on(
      'postgres_changes',
      config,
      (payload) => {

        // Call specific event handlers using refs
        if (payload.eventType === 'INSERT' && onInsertRef.current) {
          onInsertRef.current(payload);
        } else if (payload.eventType === 'UPDATE' && onUpdateRef.current) {
          onUpdateRef.current(payload);
        } else if (payload.eventType === 'DELETE' && onDeleteRef.current) {
          onDeleteRef.current(payload);
        }

        // Call generic change handler using ref
        if (onChangeRef.current) {
          onChangeRef.current(payload);
        }
      }
    );

    // Subscribe to channel
    realtimeChannel
      .subscribe((status) => {
        
        if (status === 'SUBSCRIBED') {
          setIsSubscribed(true);
          setError(null);
        } else if (status === 'CHANNEL_ERROR') {
          setError(new Error(`Failed to subscribe to ${table} changes`));
          setIsSubscribed(false);
        } else if (status === 'TIMED_OUT') {
          setError(new Error(`Subscription to ${table} timed out`));
          setIsSubscribed(false);
        }
      });

    setChannel(realtimeChannel);

    // Cleanup function
    return () => {
      realtimeChannel.unsubscribe();
      supabase.removeChannel(realtimeChannel);
      setIsSubscribed(false);
    };
  }, [table, event, schema, filter]); // Only depend on stable values, not functions

  return {
    isSubscribed,
    error,
    channel,
  };
}

/**
 * Hook for subscribing to multiple tables at once
 * 
 * @example
 * ```tsx
 * useMultipleRealtime([
 *   { table: 'tasks', onChange: fetchTasks },
 *   { table: 'notifications', onChange: fetchNotifications }
 * ]);
 * ```
 */
export function useMultipleRealtime(subscriptions: UseRealtimeOptions[]) {
  const results = subscriptions.map((subscription) => 
    useRealtime(subscription)
  );

  return {
    allSubscribed: results.every((r) => r.isSubscribed),
    anyError: results.find((r) => r.error)?.error || null,
    subscriptions: results,
  };
}
