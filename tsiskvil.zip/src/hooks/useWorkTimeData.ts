import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface DailyAttendance {
  date: string;
  check_in: string | null;
  check_out: string | null;
  hours: number;
  status: string;
  regular_hours?: number;
  overtime_hours?: number;
  night_hours?: number;
  rest_holiday_hours?: number;
}

export interface WorkTimeRecord {
  employee_id: string;
  employee_name: string;
  employee_number: string;
  personal_id: string;
  position: string;
  department: string;
  salary: number;
  total_hours: number;
  regular_hours: number;
  overtime_hours: number;
  night_overtime_hours: number;
  rest_holiday_hours: number;
  vacation_days: number;
  absence_days: number;
  worked_days: number;
  other: number;
  daily_records: { [key: string]: DailyAttendance };
  planned_hours: number;
  paid_maternity_leave_days: number;
  unpaid_maternity_leave_days: number;
  business_trip_days: number;
  weekend_business_trip_days: number;
  total_business_trip_days: number;
  night_work_hours: number;
  rest_day_work_hours: number;
  paid_overtime_hours: number;
  unpaid_overtime_hours: number;
}

interface PublicHoliday {
  id: string;
  name: string;
  holiday_date: string;
  is_recurring: boolean;
  is_active: boolean;
}

export const useWorkTimeData = (
  startDate: string,
  endDate: string,
  selectedDepartment: string = 'all',
  selectedEmployee: string = 'all',
  branchId: string | null = null
) => {
  const { toast } = useToast();
  const [records, setRecords] = useState<WorkTimeRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [publicHolidays, setPublicHolidays] = useState<PublicHoliday[]>([]);


  const isWeekend = (date: Date) => {
    const day = date.getDay();
    return day === 0 || day === 6;
  };

  const isHoliday = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return publicHolidays.some(holiday => {
      if (holiday.is_recurring) {
        const holidayMonthDay = holiday.holiday_date.substring(5);
        const checkMonthDay = dateStr.substring(5);
        return holidayMonthDay === checkMonthDay;
      }
      return holiday.holiday_date === dateStr;
    });
  };

  const calculateHours = (checkIn: string | null, checkOut: string | null, breakDuration: number = 0) => {
    if (!checkIn || !checkOut) return 0;
    
    const [inHours, inMinutes] = checkIn.split(':').map(Number);
    const [outHours, outMinutes] = checkOut.split(':').map(Number);
    
    const totalMinutes = (outHours * 60 + outMinutes) - (inHours * 60 + inMinutes) - breakDuration;
    return totalMinutes / 60;
  };

  const calculateNightHours = (checkIn: string | null, checkOut: string | null) => {
    if (!checkIn || !checkOut) return 0;
    
    const [inHours, inMinutes] = checkIn.split(':').map(Number);
    const [outHours, outMinutes] = checkOut.split(':').map(Number);
    
    let nightMinutes = 0;
    
    const checkInMinutes = inHours * 60 + inMinutes;
    const checkOutMinutes = outHours * 60 + outMinutes;
    
    const nightStartMinutes = 22 * 60;
    const nightEndMinutes = 6 * 60;
    
    if (checkOutMinutes < checkInMinutes) {
      if (checkInMinutes >= nightStartMinutes) {
        nightMinutes += (24 * 60) - checkInMinutes;
      } else if (checkInMinutes < nightEndMinutes) {
        nightMinutes += nightEndMinutes - checkInMinutes;
      }
      
      if (checkOutMinutes <= nightEndMinutes) {
        nightMinutes += checkOutMinutes;
      } else {
        nightMinutes += nightEndMinutes;
      }
    } else {
      if (checkInMinutes < nightStartMinutes && checkOutMinutes > nightStartMinutes) {
        nightMinutes += Math.min(checkOutMinutes, 24 * 60) - nightStartMinutes;
      } else if (checkInMinutes >= nightStartMinutes) {
        nightMinutes += Math.min(checkOutMinutes, 24 * 60) - checkInMinutes;
      }
      
      if (checkInMinutes < nightEndMinutes) {
        nightMinutes += Math.min(checkOutMinutes, nightEndMinutes) - checkInMinutes;
      }
    }
    
    return nightMinutes / 60;
  };

  useEffect(() => {
    fetchPublicHolidays();
  }, []);

  useEffect(() => {
    if (publicHolidays.length > 0) {
      fetchData();
    }
  }, [startDate, endDate, selectedDepartment, selectedEmployee, branchId, publicHolidays]);


  const fetchPublicHolidays = async () => {
    try {
      const { data, error } = await supabase
        .from("public_holidays")
        .select("*")
        .eq("is_active", true);

      if (error) throw error;
      setPublicHolidays(data || []);
    } catch (error: any) {
      console.error("Error fetching public holidays:", error);
      toast({
        title: "შეცდომა",
        description: "დასვენების დღეების ჩატვირთვა ვერ მოხერხდა",
        variant: "destructive",
      });
    }
  };

  const fetchData = async () => {
    try {
      setLoading(true);

      const { data: scheduleTemplatesData, error: templatesError } = await supabase
        .from("schedule_templates")
        .select("*");
      
      if (templatesError) console.error("Error fetching schedule templates:", templatesError);
      
      const scheduleTemplatesById = new Map(
        (scheduleTemplatesData || []).map(t => [t.id, t])
      );

      let employeesQuery = supabase
        .from("employees")
        .select("id, full_name, employee_number, position, department, personal_id, salary")
        .eq("status", "active")
        .order("full_name");

      if (selectedDepartment !== "all") {
        employeesQuery = employeesQuery.eq("department", selectedDepartment);
      }
      if (branchId) {
        employeesQuery = employeesQuery.eq("branch_id", branchId);
      }

      const { data: employeesData, error: employeesError } = await employeesQuery;
      if (employeesError) throw employeesError;


      const { data: workSchedulesData, error: workSchedulesError } = await supabase
        .from("work_schedules")
        .select(`
          *,
          schedule_templates (
            id,
            schedule_type,
            name,
            weekly_hours,
            start_time,
            end_time,
            break_duration,
            work_days
          )
        `)
        .or(`effective_to.gte.${startDate},effective_to.is.null`)
        .lte("effective_from", endDate);

      if (workSchedulesError) console.error("Error fetching work schedules:", workSchedulesError);

      const { data: shiftSchedulesData, error: shiftSchedulesError } = await supabase
        .from("shift_schedules")
        .select("*")
        .gte("shift_date", startDate)
        .lte("shift_date", endDate);

      if (shiftSchedulesError) console.error("Error fetching shift schedules:", shiftSchedulesError);

      let attendanceQuery = supabase
        .from("attendance")
        .select(`
          id,
          employee_id,
          date,
          check_in,
          check_out,
          status,
          overtime_hours,
          break_duration,
          employees!attendance_employee_id_fkey(full_name, employee_number, position, department, personal_id, salary)
        `)
        .gte("date", startDate)
        .lte("date", endDate);

      if (selectedEmployee !== "all") {
        attendanceQuery = attendanceQuery.eq("employee_id", selectedEmployee);
      }

      if (branchId) {
        attendanceQuery = attendanceQuery.eq("branch_id", branchId);
      }

      if (selectedDepartment !== "all" || branchId) {
        const scopedEmployeeIds = employeesData?.map(e => e.id) || [];
        if (scopedEmployeeIds.length > 0) {
          attendanceQuery = attendanceQuery.in("employee_id", scopedEmployeeIds);
        } else {
          setRecords([]);
          setLoading(false);
          return;
        }
      }

      const { data: attendanceData, error: attendanceError } = await attendanceQuery;
      if (attendanceError) throw attendanceError;


      let leaveQuery = supabase
        .from("leave_requests")
        .select(`
          employee_id,
          start_date,
          end_date,
          status,
          employees!leave_requests_employee_id_fkey(full_name)
        `)
        .eq("status", "approved")
        .gte("end_date", startDate)
        .lte("start_date", endDate);

      if (selectedEmployee !== "all") {
        leaveQuery = leaveQuery.eq("employee_id", selectedEmployee);
      }
      if (branchId) {
        leaveQuery = leaveQuery.eq("branch_id", branchId);
      }

      const { data: leaveData, error: leaveError } = await leaveQuery;
      if (leaveError) throw leaveError;


      // Fetch business trip requests
      let businessTripQuery = supabase
        .from("business_trip_requests")
        .select("*")
        .eq("status", "approved")
        .gte("end_date", startDate)
        .lte("start_date", endDate);

      if (selectedEmployee !== "all") {
        businessTripQuery = businessTripQuery.eq("employee_id", selectedEmployee);
      }
      if (branchId) {
        businessTripQuery = businessTripQuery.eq("branch_id", branchId);
      }

      const { data: businessTripData, error: businessTripError } = await businessTripQuery;
      if (businessTripError) throw businessTripError;

      const employeeMap = new Map<string, WorkTimeRecord>();

      let overtimeQuery = supabase
        .from("overtime_requests")
        .select("*")
        .eq("status", "approved")
        .gte("work_date", startDate)
        .lte("work_date", endDate);

      if (selectedEmployee !== "all") {
        overtimeQuery = overtimeQuery.eq("employee_id", selectedEmployee);
      }
      if (branchId) {
        overtimeQuery = overtimeQuery.eq("branch_id", branchId);
      }


      const { data: overtimeData, error: overtimeError } = await overtimeQuery;
      if (overtimeError) throw overtimeError;

      attendanceData?.forEach((att: any) => {
        const empId = att.employee_id;
        if (!employeeMap.has(empId)) {
          employeeMap.set(empId, {
            employee_id: empId,
            employee_name: att.employees.full_name,
            employee_number: att.employees.employee_number || '',
            personal_id: att.employees.personal_id || '',
            position: att.employees.position || '',
            department: att.employees.department || '',
            salary: att.employees.salary || 0,
            total_hours: 0,
            regular_hours: 0,
            overtime_hours: 0,
            night_overtime_hours: 0,
            rest_holiday_hours: 0,
            vacation_days: 0,
            absence_days: 0,
            worked_days: 0,
            other: 0,
            daily_records: {},
            planned_hours: 0,
            paid_maternity_leave_days: 0,
            unpaid_maternity_leave_days: 0,
            business_trip_days: 0,
            weekend_business_trip_days: 0,
            total_business_trip_days: 0,
            night_work_hours: 0,
            rest_day_work_hours: 0,
            paid_overtime_hours: 0,
            unpaid_overtime_hours: 0
          });
        }

        const record = employeeMap.get(empId)!;
        const attDate = new Date(att.date);
        
        const shiftSchedule = shiftSchedulesData?.find(
          (s: any) => s.employee_id === empId && s.shift_date === att.date
        );
        
        const workSchedule = workSchedulesData?.find(
          (ws: any) => 
            ws.employee_id === empId && 
            ws.effective_from <= att.date &&
            (!ws.effective_to || ws.effective_to >= att.date)
        );

        const template = workSchedule?.schedule_templates || 
                        (workSchedule?.template_id ? scheduleTemplatesById.get(workSchedule.template_id) : null);
        
        let workingHoursPerDay = 8;
        if (template) {
          const effectiveStartTime = workSchedule?.start_time || template.start_time;
          const effectiveEndTime = workSchedule?.end_time || template.end_time;
          const effectiveBreakDuration = workSchedule?.break_duration ?? template.break_duration ?? 0;

          if (effectiveStartTime && effectiveEndTime) {
            workingHoursPerDay = calculateHours(effectiveStartTime, effectiveEndTime, Number(effectiveBreakDuration));
          } else if (template.weekly_hours) {
            const workDays = template.work_days || 5;
            workingHoursPerDay = Number(template.weekly_hours) / Number(workDays);
          }
        }

        const breakDuration = shiftSchedule?.break_duration || 
                             template?.break_duration ||
                             (workSchedule?.no_break ? 0 : workSchedule?.break_duration) || 
                             att.break_duration || 0;
        
        const hours = calculateHours(att.check_in, att.check_out, breakDuration);
        const nightHours = calculateNightHours(att.check_in, att.check_out);

        if (att.status === 'present' && hours > 0) {
          record.worked_days++;
          record.night_overtime_hours += nightHours;
          record.night_work_hours += nightHours;

          // Calculate scheduled hours for this day
          const scheduledHours = shiftSchedule ? 
            calculateHours(shiftSchedule.start_time, shiftSchedule.end_time, shiftSchedule.break_duration || 0) :
            workingHoursPerDay;

          if (isHoliday(attDate) || isWeekend(attDate)) {
            // Weekend/Holiday work - count as regular hours (overtime tracked separately in overtime_requests)
            const regularHoursForDay = Math.min(hours, scheduledHours);
            record.regular_hours += regularHoursForDay;
            record.total_hours += regularHoursForDay;
            record.rest_holiday_hours += regularHoursForDay;
            record.rest_day_work_hours += regularHoursForDay;
          } else {
            // Regular work hours - only count up to scheduled hours
            // Overtime beyond scheduled hours is tracked in overtime_requests table
            const regularHoursForDay = Math.min(hours, scheduledHours);
            record.regular_hours += regularHoursForDay;
            record.total_hours += regularHoursForDay;
          }
        } else if (att.status === 'absent') {
          record.absence_days++;
        }
        
        if (att.status === 'present') {
          record.worked_days += 1;
        }

        record.daily_records[att.date] = {
          date: att.date,
          check_in: att.check_in,
          check_out: att.check_out,
          hours: hours,
          status: att.status
        };
      });

      leaveData?.forEach((leave: any) => {
        const empId = leave.employee_id;
        if (!employeeMap.has(empId)) {
          const employee = employeesData?.find((e: any) => e.id === empId);
          if (employee) {
            employeeMap.set(empId, {
              employee_id: empId,
              employee_name: employee.full_name,
              employee_number: employee.employee_number || '',
              personal_id: employee.personal_id || '',
              position: employee.position || '',
              department: employee.department || '',
              salary: employee.salary || 0,
              total_hours: 0,
              regular_hours: 0,
              overtime_hours: 0,
              night_overtime_hours: 0,
              rest_holiday_hours: 0,
              vacation_days: 0,
              absence_days: 0,
              worked_days: 0,
              other: 0,
              daily_records: {},
              planned_hours: 0,
              paid_maternity_leave_days: 0,
              unpaid_maternity_leave_days: 0,
              business_trip_days: 0,
              weekend_business_trip_days: 0,
              total_business_trip_days: 0,
              night_work_hours: 0,
              rest_day_work_hours: 0,
              paid_overtime_hours: 0,
              unpaid_overtime_hours: 0
            });
          }
        }

        const record = employeeMap.get(empId);
        if (record) {
          const leaveStart = new Date(leave.start_date);
          const leaveEnd = new Date(leave.end_date);
          const diffTime = Math.abs(leaveEnd.getTime() - leaveStart.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
          record.vacation_days += diffDays;
        }
      });

      // Process business trips
      businessTripData?.forEach((trip: any) => {
        const empId = trip.employee_id;
        const record = employeeMap.get(empId);
        if (record) {
          const tripStart = new Date(trip.start_date);
          const tripEnd = new Date(trip.end_date);
          const diffTime = Math.abs(tripEnd.getTime() - tripStart.getTime());
          const tripDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
          
          record.business_trip_days += tripDays;
          record.total_business_trip_days += tripDays;
          
          // Check for weekend business trips
          let weekendDays = 0;
          const tempDate = new Date(tripStart);
          while (tempDate <= tripEnd) {
            if (isWeekend(tempDate)) {
              weekendDays++;
            }
            tempDate.setDate(tempDate.getDate() + 1);
          }
          record.weekend_business_trip_days += weekendDays;
        }
      });

      // Process overtime requests (separate from attendance to avoid duplication)
      overtimeData?.forEach((overtime: any) => {
        const empId = overtime.employee_id;
        if (!employeeMap.has(empId)) {
          const emp = employeesData?.find(e => e.id === empId);
          if (emp) {
            employeeMap.set(empId, {
              employee_id: empId,
              employee_name: emp.full_name,
              employee_number: emp.employee_number || '',
              personal_id: emp.personal_id || '',
              position: emp.position || '',
              department: emp.department || '',
              salary: emp.salary || 0,
              total_hours: 0,
              regular_hours: 0,
              overtime_hours: 0,
              night_overtime_hours: 0,
              rest_holiday_hours: 0,
              vacation_days: 0,
              absence_days: 0,
              worked_days: 0,
              other: 0,
              daily_records: {},
              planned_hours: 0,
              paid_maternity_leave_days: 0,
              unpaid_maternity_leave_days: 0,
              business_trip_days: 0,
              weekend_business_trip_days: 0,
              total_business_trip_days: 0,
              night_work_hours: 0,
              rest_day_work_hours: 0,
              paid_overtime_hours: 0,
              unpaid_overtime_hours: 0
            });
          }
        }

        const record = employeeMap.get(empId);
        if (record) {
          const overtimeHours = overtime.hours || 0;
          // Add to overtime_hours (not to total_hours yet - will be added at the end)
          record.overtime_hours += overtimeHours;
          record.paid_overtime_hours += overtimeHours;
          
          // Classify overtime by type for rest_holiday_hours tracking
          if (overtime.overtime_type === 'weekend' || overtime.overtime_type === 'holiday') {
            record.rest_holiday_hours += overtimeHours;
          }
        }
      });

      // Add overtime_hours to total_hours for all records
      employeeMap.forEach((record) => {
        record.total_hours += record.overtime_hours;
      });

      const currentDate = new Date(startDate);
      const endDateObj = new Date(endDate);
      
      employeeMap.forEach((record) => {
        const workSchedule = workSchedulesData?.find(
          (ws: any) => 
            ws.employee_id === record.employee_id && 
            ws.effective_from <= endDate &&
            (!ws.effective_to || ws.effective_to >= startDate)
        );

        const template = workSchedule?.schedule_templates || 
                        (workSchedule?.template_id ? scheduleTemplatesById.get(workSchedule.template_id) : null);

        let workingHoursPerDay = 8;
        if (template) {
          const effectiveStartTime = workSchedule?.start_time || template.start_time;
          const effectiveEndTime = workSchedule?.end_time || template.end_time;
          const effectiveBreakDuration = workSchedule?.break_duration ?? template.break_duration ?? 0;

          if (effectiveStartTime && effectiveEndTime) {
            workingHoursPerDay = calculateHours(effectiveStartTime, effectiveEndTime, Number(effectiveBreakDuration));
          } else if (template.weekly_hours) {
            const workDays = template.work_days || 5;
            workingHoursPerDay = Number(template.weekly_hours) / Number(workDays);
          }
        }

        let plannedDays = 0;
        const tempDate = new Date(currentDate);
        while (tempDate <= endDateObj) {
          if (!isWeekend(tempDate) && !isHoliday(tempDate)) {
            plannedDays++;
          }
          tempDate.setDate(tempDate.getDate() + 1);
        }

        record.planned_hours = Number(plannedDays) * Number(workingHoursPerDay);
      });

      setRecords(Array.from(employeeMap.values()));
    } catch (error: any) {
      console.error("Error fetching work time data:", error);
      toast({
        title: "შეცდომა",
        description: "მონაცემების ჩატვირთვა ვერ მოხერხდა",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return { records, loading, publicHolidays };
};
