import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { isOfflineStandalone } from "@/offline/localStore";

interface FeatureAccess {
  enabledFeatures: string[];
  isLoading: boolean;
  hasFeature: (featureKey: string) => boolean;
  refreshFeatures: () => void;
}

// Map route paths to feature keys
export const routeFeatureMap: Record<string, string> = {
  '/personnel': 'core_hr',
  '/employees': 'employees',
  '/employee-details': 'employees',
  '/organizational-structure': 'org_structure',
  '/documents': 'documents',
  '/contract-templates': 'contracts',
  '/contacts': 'contacts',
  '/attendance': 'attendance',
  '/mobile-attendance': 'attendance',
  '/work-schedules': 'work_schedules',
  '/shift-schedules': 'shifts',
  '/work-time-tracking': 'work_time',
  '/work-time-report': 'work_time',
  '/leave-requests': 'leave',
  '/leave-statistics': 'leave',
  '/leave-types': 'leave_types',
  '/public-holidays': 'public_holidays',
  '/payroll': 'payroll',
  '/pension-payments': 'payroll',
  '/finance': 'payroll',
  '/recruitment': 'recruitment',
  '/vacancies': 'vacancies',
  '/candidates': 'candidates',
  '/job-applications': 'candidates',
  '/job-descriptions': 'recruitment',
  '/sms-settings': 'sms',
  '/sms-reports': 'sms',
  '/okr-management': 'okr',
  '/training': 'training',
  '/budget-planning': 'budget',
  '/budget-expenses': 'budget',
  '/overtime-requests': 'overtime',
  '/overtime-reports': 'overtime',
  '/benefits': 'benefits',
  '/benefits-admin': 'benefits',
  '/compensation': 'compensation',
  '/employee-wellness': 'wellness',
  '/hr-analytics': 'hr_analytics',
  '/engagement-analytics': 'engagement',
  '/headcount-planning': 'headcount',
  '/skills-matrix': 'skills_matrix',
  '/exit-interview': 'exit_interview',
  '/internal-mobility': 'internal_mobility',
  '/hr-tools': 'wellness',
  '/compliance-dashboard': 'compliance',
  '/data-protection': 'data_protection',
  '/audit-logs': 'audit_logs',
};

// Map sidebar item URLs to feature keys
export const sidebarFeatureMap: Record<string, string> = {
  ...routeFeatureMap,
};

export function useFeatureAccess(): FeatureAccess {
  const { user, userRole } = useAuth();
  const [enabledFeatures, setEnabledFeatures] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchFeatures = useCallback(async () => {
    if (isOfflineStandalone()) {
      setEnabledFeatures(['__all__']);
      setIsLoading(false);
      return;
    }

    if (!user) {
      setEnabledFeatures([]);
      setIsLoading(false);
      return;
    }

    try {
      // Single-tenant: get the first active company
      const { data: company } = await supabase
        .from('companies')
        .select('id')
        .eq('is_active', true)
        .limit(1)
        .maybeSingle();

      const companyId = company?.id;

      if (!companyId) {
        // No company = all features enabled (superadmin or unassigned)
        setEnabledFeatures(['__all__']);
        setIsLoading(false);
        return;
      }

      // Check company features
      const { data: features } = await supabase
        .from('company_features')
        .select('feature_key')
        .eq('company_id', companyId)
        .eq('is_enabled', true);

      if (!features || features.length === 0) {
        // No features configured = all features enabled (default)
        setEnabledFeatures(['__all__']);
      } else {
        setEnabledFeatures(features.map(f => f.feature_key));
      }
    } catch (error) {
      console.error('Error fetching features:', error);
      setEnabledFeatures(['__all__']);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchFeatures();
  }, [fetchFeatures]);

  const hasFeature = useCallback((featureKey: string): boolean => {
    // Admins always have access
    if (userRole === 'admin') return true;
    // If all features enabled
    if (enabledFeatures.includes('__all__')) return true;
    return enabledFeatures.includes(featureKey);
  }, [enabledFeatures, userRole]);

  return {
    enabledFeatures,
    isLoading,
    hasFeature,
    refreshFeatures: fetchFeatures,
  };
}
