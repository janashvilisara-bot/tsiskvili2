import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { 
  maskSensitiveData, 
  canViewDecryptedData, 
  formatDecryptedValue,
  SensitiveField,
  DecryptedEmployeeData 
} from "@/lib/encryption";

interface UseEncryptedDataOptions {
  employeeId: string;
}

interface UseEncryptedDataReturn {
  decryptedData: DecryptedEmployeeData | null;
  isDecrypting: boolean;
  isDecrypted: boolean;
  canDecrypt: boolean;
  decryptData: () => Promise<void>;
  encryptAndSave: (data: Partial<DecryptedEmployeeData>) => Promise<boolean>;
  getMaskedValue: (field: SensitiveField, rawValue?: string | number) => string;
  getDisplayValue: (field: SensitiveField) => string;
}

export function useEncryptedData({ employeeId }: UseEncryptedDataOptions): UseEncryptedDataReturn {
  const { userRole } = useAuth();
  const [decryptedData, setDecryptedData] = useState<DecryptedEmployeeData | null>(null);
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [isDecrypted, setIsDecrypted] = useState(false);

  const canDecrypt = canViewDecryptedData(userRole);

  const decryptData = useCallback(async () => {
    if (!canDecrypt || !employeeId) {
      toast.error("არ გაქვთ გაშიფვრის უფლება");
      return;
    }

    setIsDecrypting(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error("Not authenticated");
      }

      // First try to get encrypted data
      const response = await supabase.functions.invoke("encrypt-sensitive-data", {
        body: {
          action: "decrypt",
          employee_id: employeeId
        }
      });

      if (response.error) {
        throw response.error;
      }

      // If we got decrypted data from encrypted storage, use it
      if (response.data?.data && Object.keys(response.data.data).length > 0) {
        setDecryptedData(response.data.data);
        setIsDecrypted(true);
        toast.success("მონაცემები გაშიფრულია");
        return;
      }

      // Fallback: If no encrypted data exists, fetch directly from employees table (for admin only)
      const { data: employeeData, error: employeeError } = await supabase
        .from("employees")
        .select("personal_id, phone, email, actual_address, legal_address, salary, bank_account_number")
        .eq("id", employeeId)
        .single();

      if (employeeError) {
        throw employeeError;
      }

      if (employeeData) {
        setDecryptedData({
          personal_id: employeeData.personal_id || undefined,
          phone: employeeData.phone || undefined,
          email: employeeData.email || undefined,
          address: employeeData.actual_address || employeeData.legal_address || undefined,
          salary: employeeData.salary ? Number(employeeData.salary) : undefined,
          bank_account: employeeData.bank_account_number || undefined,
        });
        setIsDecrypted(true);
        toast.success("მონაცემები ნაჩვენებია");
      }
    } catch (error: any) {
      console.error("Decryption error:", error);
      toast.error("გაშიფვრის შეცდომა: " + (error.message || "Unknown error"));
    } finally {
      setIsDecrypting(false);
    }
  }, [canDecrypt, employeeId]);

  const encryptAndSave = useCallback(async (data: Partial<DecryptedEmployeeData>): Promise<boolean> => {
    if (!canDecrypt || !employeeId) {
      toast.error("არ გაქვთ დაშიფვრის უფლება");
      return false;
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error("Not authenticated");
      }

      const response = await supabase.functions.invoke("encrypt-sensitive-data", {
        body: {
          action: "encrypt",
          employee_id: employeeId,
          data
        }
      });

      if (response.error) {
        throw response.error;
      }

      toast.success("მონაცემები დაშიფრულია და შენახულია");
      return true;
    } catch (error: any) {
      console.error("Encryption error:", error);
      toast.error("დაშიფვრის შეცდომა: " + (error.message || "Unknown error"));
      return false;
    }
  }, [canDecrypt, employeeId]);

  const getMaskedValue = useCallback((field: SensitiveField, rawValue?: string | number): string => {
    if (isDecrypted && decryptedData) {
      const value = decryptedData[field as keyof DecryptedEmployeeData];
      if (value !== undefined) {
        return formatDecryptedValue(value, field);
      }
    }
    return maskSensitiveData(rawValue, field);
  }, [isDecrypted, decryptedData]);

  const getDisplayValue = useCallback((field: SensitiveField): string => {
    if (isDecrypted && decryptedData) {
      const value = decryptedData[field as keyof DecryptedEmployeeData];
      return formatDecryptedValue(value, field);
    }
    return "***";
  }, [isDecrypted, decryptedData]);

  return {
    decryptedData,
    isDecrypting,
    isDecrypted,
    canDecrypt,
    decryptData,
    encryptAndSave,
    getMaskedValue,
    getDisplayValue
  };
}
