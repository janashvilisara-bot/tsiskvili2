import { supabase } from "@/integrations/supabase/client";
import type { PerformanceInput } from "@/lib/performanceScore";

const since90 = () => new Date(Date.now() - 90 * 86400000).toISOString().slice(0, 10);

/** Loads performance inputs for many employees at once (keyed by employee id). */
export async function loadPerformanceInputs(employees: { id: string; user_id?: string | null }[]) {
  const ids = employees.map((e) => e.id);
  const userIds = employees.map((e) => e.user_id).filter(Boolean) as string[];
  const result: Record<string, PerformanceInput> = {};
  ids.forEach((id) => {
    result[id] = { evaluations: [], lateCount90d: 0, tasksCompleted: 0, tasksOverdue: 0, goalProgress: [], trainingsTotal: 0, trainingsCompleted: 0, skillLevels: [] };
  });
  if (!ids.length) return result;
  const today = new Date().toISOString().slice(0, 10);

  // latenessUsed: if the lateness_records table has no rows at all, attendance is
  // not being tracked — treat it as "no data" (null) instead of a free 100 score.
  const [ev, late, goals, tr, sk, tasks, latenessUsed] = await Promise.all([
    supabase.from("employee_evaluations").select("employee_id, evaluation_date, overall_rating, performance_rating, teamwork_rating, communication_rating, leadership_rating").in("employee_id", ids),
    supabase.from("lateness_records").select("employee_id").in("employee_id", ids).gte("date", since90()),
    supabase.from("employee_goals").select("employee_id, progress_percentage").in("employee_id", ids),
    supabase.from("training_enrollments").select("employee_id, status").in("employee_id", ids),
    supabase.from("employee_skills").select("employee_id, level").in("employee_id", ids),
    userIds.length
      ? supabase.from("tasks").select("assigned_to, status, due_date").in("assigned_to", userIds)
      : Promise.resolve({ data: [] as any[] }),
    supabase.from("lateness_records").select("employee_id", { count: "exact", head: true }),
  ]);

  (ev.data || []).forEach((r: any) => result[r.employee_id]?.evaluations.push(r));
  (late.data || []).forEach((r: any) => { if (result[r.employee_id]) result[r.employee_id].lateCount90d! += 1; });
  if ((latenessUsed as any).count === 0) ids.forEach((id) => { result[id].lateCount90d = null; });
  (goals.data || []).forEach((r: any) => { if (typeof r.progress_percentage === "number") result[r.employee_id]?.goalProgress.push(r.progress_percentage); });
  (tr.data || []).forEach((r: any) => {
    const x = result[r.employee_id]; if (!x) return;
    x.trainingsTotal++; if (r.status === "completed") x.trainingsCompleted++;
  });
  (sk.data || []).forEach((r: any) => { if (typeof r.level === "number") result[r.employee_id]?.skillLevels.push(r.level); });
  const byUser = new Map(employees.filter((e) => e.user_id).map((e) => [e.user_id!, e.id]));
  ((tasks as any).data || []).forEach((t: any) => {
    const x = result[byUser.get(t.assigned_to) || ""]; if (!x) return;
    if (t.status === "completed" || t.status === "done") x.tasksCompleted++;
    else if (t.due_date && t.due_date < today) x.tasksOverdue++;
  });
  return result;
}
