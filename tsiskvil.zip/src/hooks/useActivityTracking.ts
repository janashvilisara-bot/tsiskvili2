import { useEffect, useRef, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export const useActivityTracking = () => {
  const { user } = useAuth();
  const location = useLocation();
  const sessionIdRef = useRef<string | null>(null);
  const lastPageRef = useRef<string | null>(null);
  const pageStartTimeRef = useRef<number>(Date.now());

  // Start a new session
  const startSession = useCallback(async () => {
    if (!user) return;

    try {
      const userAgent = navigator.userAgent;
      const deviceType = /Mobile|Android|iPhone|iPad/.test(userAgent) ? 'mobile' : 'desktop';
      const browser = getBrowserName(userAgent);
      const os = getOSName(userAgent);

      const { data, error } = await supabase
        .from('user_sessions' as any)
        .insert({
          user_id: user.id,
          user_agent: userAgent,
          device_type: deviceType,
          browser,
          os,
          is_active: true
        })
        .select('id')
        .single();

      if (!error && data) {
        sessionIdRef.current = (data as any).id;
      }
    } catch (err) {
      console.error('Failed to start session:', err);
    }
  }, [user]);

  // End the current session
  const endSession = useCallback(async () => {
    if (!sessionIdRef.current) return;

    try {
      await supabase
        .from('user_sessions' as any)
        .update({
          is_active: false,
          session_end: new Date().toISOString()
        })
        .eq('id', sessionIdRef.current);

      sessionIdRef.current = null;
    } catch (err) {
      console.error('Failed to end session:', err);
    }
  }, []);

  // Track page view
  const trackPageView = useCallback(async (path: string, title?: string) => {
    if (!user) return;

    try {
      await supabase
        .from('page_views' as any)
        .insert({
          user_id: user.id,
          session_id: sessionIdRef.current,
          page_path: path,
          page_title: title || document.title,
          referrer: lastPageRef.current
        });

      lastPageRef.current = path;
      pageStartTimeRef.current = Date.now();
    } catch (err) {
      console.error('Failed to track page view:', err);
    }
  }, [user]);

  // Update user presence
  const updatePresence = useCallback(async () => {
    if (!user) return;

    try {
      await supabase
        .from('user_presence')
        .upsert({
          user_id: user.id,
          status: 'online',
          last_seen: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        });
    } catch (err) {
      // Silently fail - presence is not critical
    }
  }, [user]);

  // Set user offline
  const setOffline = useCallback(async () => {
    if (!user) return;

    try {
      await supabase
        .from('user_presence')
        .upsert({
          user_id: user.id,
          status: 'offline',
          last_seen: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        });
    } catch (err) {
      // Silently fail
    }
  }, [user]);

  // Track page changes
  useEffect(() => {
    if (user) {
      trackPageView(location.pathname);
    }
  }, [location.pathname, user, trackPageView]);

  // Session management
  useEffect(() => {
    if (!user) return;

    startSession();
    updatePresence();

    // Update presence every 30 seconds
    const presenceInterval = setInterval(updatePresence, 30000);

    // Handle visibility change
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        setOffline();
      } else {
        updatePresence();
      }
    };

    // Handle before unload
    const handleBeforeUnload = () => {
      endSession();
      setOffline();
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      clearInterval(presenceInterval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      endSession();
      setOffline();
    };
  }, [user, startSession, endSession, updatePresence, setOffline]);

  return { trackPageView };
};

// Helper functions
function getBrowserName(userAgent: string): string {
  if (userAgent.includes('Firefox')) return 'Firefox';
  if (userAgent.includes('Chrome')) return 'Chrome';
  if (userAgent.includes('Safari')) return 'Safari';
  if (userAgent.includes('Edge')) return 'Edge';
  if (userAgent.includes('Opera')) return 'Opera';
  return 'Unknown';
}

function getOSName(userAgent: string): string {
  if (userAgent.includes('Windows')) return 'Windows';
  if (userAgent.includes('Mac')) return 'macOS';
  if (userAgent.includes('Linux')) return 'Linux';
  if (userAgent.includes('Android')) return 'Android';
  if (userAgent.includes('iOS') || userAgent.includes('iPhone') || userAgent.includes('iPad')) return 'iOS';
  return 'Unknown';
}
