import { useBranch } from "@/contexts/BranchContext";

/**
 * Returns the currently active branch id (or null when "all branches" is selected).
 * Use to narrow a Supabase query to a specific branch:
 *
 *   const branchId = useBranchFilter();
 *   let q = supabase.from('employees').select('*');
 *   if (branchId) q = q.eq('branch_id', branchId);
 *
 * Note: RLS already isolates branches the user is NOT a member of; this hook
 * is purely a presentation-layer narrowing for admins/HR who can see many
 * branches and want to focus on one at a time.
 */
export function useBranchFilter(): string | null {
  const { activeBranch } = useBranch();
  return activeBranch?.id ?? null;
}
