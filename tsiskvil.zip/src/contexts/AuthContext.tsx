import { resolveRegistrationPassword } from '@/lib/tempPassword';
import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { isValidScheduleType } from '@/lib/scheduleUtils';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { logLoginAttempt, logSecurityEvent } from '@/lib/securityLogger';
import { trackLoginWithAnomalyCheck } from '@/lib/loginAnomalyDetection';
import { clearOfflineSession, connectCloudForHybridFeatures, getOfflineSession, isOfflineStandalone, syncOfflineChangesToCloud, validateOfflineLogin } from '@/offline/localStore';
import { initPushNotifications } from '@/lib/pushNotifications';
import { AnonymousCheckinDialog } from '@/components/AnonymousCheckinDialog';
import { hasCheckedInToday } from '@/lib/dailyCheckin';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  userRole: string | null;
  signUp: (email: string, password: string, fullName: string, role?: 'admin' | 'hr_manager' | 'department_manager' | 'employee', department?: string, position?: string, phone?: string, gender?: string, workScheduleId?: string, educationLevel?: string, personalId?: string) => Promise<void>;
  registerEmployee: (email: string, fullName: string, role: 'admin' | 'hr_manager' | 'department_manager' | 'employee', department?: string, position?: string, phone?: string, gender?: string, workScheduleId?: string, customPassword?: string, educationLevel?: string, personalId?: string) => Promise<{ password: string; error?: any }>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  requestSignOut: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const [checkinOpen, setCheckinOpen] = useState(false);

  useEffect(() => {
    if (isOfflineStandalone()) {
      const offlineSession = getOfflineSession();
      if (offlineSession) {
        const offlineUser = { id: offlineSession.id, email: offlineSession.email, user_metadata: { full_name: offlineSession.fullName } } as unknown as User;
        setUser(offlineUser);
        setSession({ user: offlineUser } as unknown as Session);
        setUserRole('admin');
      }
      setLoading(false);
      return;
    }

    let isMounted = true;

    // Set up auth state listener (for ongoing changes, NOT initial load)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!isMounted) return;
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          // Fire and forget for ongoing changes
          fetchUserRole(session.user.id);

          // Auto-create employee record for Google OAuth users
          if (event === 'SIGNED_IN' && session.user.app_metadata?.provider === 'google') {
            ensureEmployeeRecord(session.user);
          }
        } else {
          setUserRole(null);
        }
      }
    );

    // INITIAL load - wait for role before setting loading false
    const initializeAuth = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!isMounted) return;
        
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          await fetchUserRole(session.user.id);
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    initializeAuth();

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  // Register for push notifications once a user is signed in (native app only)
  useEffect(() => {
    if (user?.id && !isOfflineStandalone()) {
      void initPushNotifications(user.id);
    }
  }, [user?.id]);

  const ensureEmployeeRecord = async (authUser: User) => {
    try {
      // Check if employee record already exists
      const { data: existing } = await supabase
        .from('employees')
        .select('id')
        .eq('user_id', authUser.id)
        .maybeSingle();

      if (existing) return; // Already has employee record

      const fullName = authUser.user_metadata?.full_name || authUser.user_metadata?.name || authUser.email?.split('@')[0] || 'Unknown';
      const email = authUser.email || '';

      // Create employee record
      await supabase.from('employees').insert({
        user_id: authUser.id,
        email,
        full_name: fullName,
        department: 'არ არის მითითებული',
        position: 'არ არის მითითებული',
        hire_date: new Date().toISOString().split('T')[0],
        created_by: authUser.id,
      });

      // Assign employee role
      const { data: existingRole } = await supabase
        .from('user_roles')
        .select('id')
        .eq('user_id', authUser.id)
        .maybeSingle();

      if (!existingRole) {
        await supabase.from('user_roles').insert({
          user_id: authUser.id,
          role: 'employee',
        });
      }

    } catch (error) {
      console.error('Error auto-creating employee record:', error);
    }
  };

  const fetchUserRole = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId);

      if (error) throw error;
      const roles = (data || []).map((r: { role: string }) => r.role);
      const effective = roles.includes('admin')
        ? 'admin'
        : roles.includes('hr_manager')
        ? 'hr_manager'
        : roles.includes('department_manager')
        ? 'department_manager'
        : roles.includes('employee')
        ? 'employee'
        : null;
      setUserRole(effective);
    } catch (error) {
      console.error('Error fetching user role:', error);
      setUserRole('employee');
    }
  };

  const registerEmployee = async (email: string, fullName: string, role: 'admin' | 'hr_manager' | 'department_manager' | 'employee' = 'employee', department?: string, position?: string, phone?: string, gender?: string, workScheduleId?: string, customPassword?: string, educationLevel?: string, personalId?: string) => {
    const resolved = resolveRegistrationPassword(customPassword);
    if (resolved.error) {
      toast.error(resolved.error);
      return { password: '', error: resolved.error };
    }
    const defaultPassword = resolved.password as string;

    // Call edge function to register employee without affecting current session
    const { data, error } = await supabase.functions.invoke('register-employee', {
      body: {
        email,
        password: defaultPassword,
        fullName,
        role,
        department,
        position,
        phone,
        gender,
        workScheduleId,
        educationLevel,
        personalId,
        createdBy: user?.id,
      },
    });

    // If edge function returned non-2xx, try to read friendly error message from response body
    if (error) {
      console.error('Employee registration edge error:', error);
      let friendlyMessage = 'რეგისტრაცია ვერ მოხერხდა';

      const anyError: any = error as any;
      const response = anyError?.context?.response;

      if (response && typeof response.json === 'function') {
        try {
          const body = await response.json();
          if (body?.error && typeof body.error === 'string') {
            friendlyMessage = body.error;
          }
        } catch (parseErr) {
          console.error('Failed to parse edge function error body:', parseErr);
        }
      } else if (anyError.message) {
        friendlyMessage = anyError.message;
      }

      toast.error(friendlyMessage);
      return { password: defaultPassword, error: friendlyMessage };
    }

    // Edge function responded with 2xx but included error field in body
    if (data?.error) {
      console.error('Employee registration error from body:', data.error);
      toast.error(data.error);
      return { password: defaultPassword, error: data.error };
    }

    return { password: (data?.password as string) || defaultPassword };
  };

  const signUp = async (email: string, password: string, fullName: string, role: 'admin' | 'hr_manager' | 'department_manager' | 'employee' = 'employee', department?: string, position?: string, phone?: string, gender?: string, workScheduleId?: string, educationLevel?: string, personalId?: string) => {
    try {
      // Check for duplicates - personal_id or phone
      if (personalId || phone) {
        const { data: existingEmployee, error: checkError } = await supabase
          .from('employees')
          .select('id, full_name, personal_id, phone')
          .or(`personal_id.eq.${personalId || ''},phone.eq.${phone || ''}`)
          .limit(1);

        if (checkError) {
          console.error('Error checking for duplicates:', checkError);
        }

        if (existingEmployee && existingEmployee.length > 0) {
          const duplicate = existingEmployee[0];
          let duplicateMessage = 'თანამშრომელი უკვე არსებობს: ';
          
          if (duplicate.personal_id === personalId) {
            duplicateMessage += `პირადი ნომერი "${personalId}" უკვე გამოყენებულია`;
          }
          if (duplicate.phone === phone) {
            if (duplicate.personal_id === personalId) {
              duplicateMessage += ' და ';
            }
            duplicateMessage += `ტელეფონის ნომერი "${phone}" უკვე გამოყენებულია`;
          }
          
          toast.error(duplicateMessage);
          throw new Error(duplicateMessage);
        }
      }

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/employee-portal`,
          data: {
            full_name: fullName,
            role: role,
          },
        },
      });

      if (error) throw error;
      
      // Create employee record if department and position are provided
      if (data.user && department && position) {
        const { data: newEmployee, error: employeeError } = await supabase
          .from('employees')
          .insert([{
            email,
            full_name: fullName,
            department,
            position,
            phone: phone || null,
            gender: gender || null,
            education_level: educationLevel || null,
            personal_id: personalId || null,
            hire_date: new Date().toISOString().split('T')[0],
            created_by: data.user.id,
            work_schedule_id: workScheduleId || null,
            user_id: data.user.id
          }])
          .select()
          .single();
        
        if (employeeError) {
          console.error('Error creating employee:', employeeError);
          toast.error('თანამშრომლის შექმნა ვერ მოხერხდა');
        } else if (newEmployee && workScheduleId) {
          // Check if the selected schedule is a "fixed" type
          const { data: scheduleTemplate, error: templateError } = await supabase
            .from('schedule_templates')
            .select('schedule_type, name, start_time, end_time, weekly_hours, break_duration, no_break')
            .eq('id', workScheduleId)
            .single();

          if (templateError) {
            console.error('Error fetching schedule template:', templateError);
          } else if (scheduleTemplate && ['fixed_1', 'fixed_2'].includes(scheduleTemplate.schedule_type)) {
            // Create work_schedule entry for fixed schedule
            const { error: workScheduleError } = await supabase
              .from('work_schedules')
              .insert({
                employee_id: newEmployee.id,
                schedule_type: scheduleTemplate.schedule_type,
                start_time: scheduleTemplate.start_time,
                end_time: scheduleTemplate.end_time,
                working_hours_per_week: scheduleTemplate.weekly_hours,
                break_duration: scheduleTemplate.break_duration || 0,
                no_break: scheduleTemplate.no_break || false,
                effective_from: new Date().toISOString().split('T')[0],
                effective_to: null,
                created_by: data.user.id
              });

            if (workScheduleError) {
              console.error('Error creating work schedule:', workScheduleError);
              toast.error('სამუშაო გრაფიკის შექმნა ვერ მოხერხდა');
            } else {
            }
          }
        }

        // Create notification for department manager, admins and HR
        if (department && position) {
          const { data: deptData } = await supabase
            .from('departments')
            .select('manager_id')
            .eq('name', department)
            .maybeSingle();

          const { data: adminHrUsers } = await supabase
            .from('user_roles')
            .select('user_id')
            .in('role', ['admin', 'hr_manager']);

          const notificationRecipients: string[] = [];
          
          if (deptData?.manager_id) {
            const { data: managerEmployee } = await supabase
              .from('employees')
              .select('email')
              .eq('id', deptData.manager_id)
              .maybeSingle();
            
            if (managerEmployee?.email) {
              const { data: authUsers } = await supabase
                .from('profiles')
                .select('id')
                .limit(1000);
              
              if (authUsers) {
                for (const profile of authUsers) {
                  const { data: authData } = await supabase.auth.admin.getUserById(profile.id);
                  if (authData?.user?.email === managerEmployee.email) {
                    notificationRecipients.push(authData.user.id);
                    break;
                  }
                }
              }
            }
          }

          if (adminHrUsers) {
            notificationRecipients.push(...adminHrUsers.map(u => u.user_id));
          }

          if (notificationRecipients.length > 0) {
            await supabase
              .from('notifications')
              .insert([{
                title: 'ახალი თანამშრომელი დარეგისტრირდა',
                message: `${fullName} დარეგისტრირდა დეპარტამენტში: ${department}, პოზიცია: ${position}`,
                type: 'new_employee',
                target_audience: 'specific',
                employee_ids: notificationRecipients,
                created_by: data.user.id
              }]);
          }
        }
      }
      
      toast.success('რეგისტრაცია წარმატებულია!');
      navigate('/');
    } catch (error: any) {
      toast.error(error.message || 'რეგისტრაცია ვერ მოხერხდა');
      throw error;
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      if (isOfflineStandalone()) {
        const offlineSession = await validateOfflineLogin(email, password);
        if (!offlineSession) throw new Error('ელ.ფოსტა ან პაროლი არასწორია');
        const offlineUser = { id: offlineSession.id, email: offlineSession.email, user_metadata: { full_name: offlineSession.fullName } } as unknown as User;
        setUser(offlineUser);
        setSession({ user: offlineUser } as unknown as Session);
        setUserRole('admin');
        connectCloudForHybridFeatures(email, password)
          .then((result) => result.ok ? syncOfflineChangesToCloud() : null)
          .catch(() => null);
        toast.success('offline რეჟიმში შეხვედით');
        navigate('/employees');
        return;
      }
      const { data: authData, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        // Log failed login attempt
        await logLoginAttempt(email, false, error.message);
        throw error;
      }
      
      // Get the user data after successful login
      const { data: userData } = await supabase.auth.getUser();
      
      // ===== CHECK EMPLOYEE STATUS BEFORE ALLOWING ACCESS =====
      if (userData?.user) {
        // First check if user has privileged role (admin/hr can login without employee record)
        const { data: userRoles } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', userData.user.id);
        
        const isPrivileged = userRoles?.some(r => 
          ['admin', 'hr_manager'].includes(r.role)
        );
        
        // If not privileged, check employee status
        if (!isPrivileged) {
          let { data: employee, error: empError } = await supabase
            .from('employees')
            .select('id, status, full_name, deleted_at')
            .eq('user_id', userData.user.id)
            .maybeSingle();

          // Fallback: employee record created by HR before the account existed
          // is matched by email and linked to the account automatically.
          if (!employee && !empError) {
            const { data: byEmail } = await supabase
              .from('employees')
              .select('id, status, full_name, deleted_at, user_id')
              .ilike('email', userData.user.email ?? '')
              .is('user_id', null)
              .maybeSingle();

            if (byEmail) {
              await supabase
                .from('employees')
                .update({ user_id: userData.user.id })
                .eq('id', byEmail.id);
              employee = byEmail;
            }
          }
          
          
          // If employee exists but is soft-deleted, block login
          if (employee && employee.deleted_at) {
            await logLoginAttempt(email, false, 'Blocked: Employee is deleted');
            await logSecurityEvent({
              eventType: 'login_blocked',
              resourceType: 'authentication',
              details: {
                reason: 'deleted_employee',
                employee_id: employee.id,
              },
              riskLevel: 'high'
            });
            await supabase.auth.signOut();
            throw new Error('თქვენი ანგარიში წაშლილია. დაუკავშირდით HR დეპარტამენტს.');
          }

          // If employee exists and is inactive/terminated, block login
          if (employee && employee.status !== 'active') {
            await logLoginAttempt(email, false, `Blocked: Employee status is ${employee.status}`);
            await logSecurityEvent({
              eventType: 'login_blocked',
              resourceType: 'authentication',
              details: {
                reason: 'inactive_employee',
                employee_id: employee.id,
                status: employee.status
              },
              riskLevel: 'high'
            });
            await supabase.auth.signOut();
            throw new Error('თქვენი ანგარიში გაუქმებულია. დაუკავშირდით HR დეპარტამენტს.');
          }
          
          // If no employee record found for non-privileged user, block access
          if (!employee && !empError) {
            await logLoginAttempt(email, false, 'No employee record found');
            await supabase.auth.signOut();
            throw new Error('თანამშრომლის ჩანაწერი ვერ მოიძებნა. დაუკავშირდით HR დეპარტამენტს.');
          }
        }
      }
      
      // Log successful login
      await logLoginAttempt(email, true);
      
      // Track login with anomaly detection
      if (userData?.user) {
        const anomalyResult = await trackLoginWithAnomalyCheck(userData.user.id, email);
        if (anomalyResult?.is_suspicious) {
          toast.warning('შესვლა დაფიქსირდა ახალი მდებარეობიდან. უსაფრთხოების ჯგუფი შეტყობინებულია.');
        }
      }
      
      toast.success('შესვლა წარმატებულია!');
      navigate('/');
    } catch (error: any) {
      toast.error(error.message || 'შესვლა ვერ მოხერხდა');
      throw error;
    }
  };

  const signOut = async () => {
    try {
      if (isOfflineStandalone()) {
        clearOfflineSession();
        setUser(null);
        setSession(null);
        setUserRole(null);
        toast.success('წარმატებით გახვედით სისტემიდან');
        navigate('/auth');
        return;
      }

      // Log logout event
      await logSecurityEvent({
        eventType: 'logout',
        resourceType: 'authentication',
      });
      
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      toast.success('წარმატებით გახვედით სისტემიდან');
      navigate('/auth');
    } catch (error: any) {
      toast.error(error.message || 'გასვლა ვერ მოხერხდა');
    }
  };

  // Logout entry point for buttons: asks the anonymous well-being check-in first (once per day).
  const requestSignOut = () => {
    if (!user || isOfflineStandalone() || hasCheckedInToday()) {
      void signOut();
      return;
    }
    setCheckinOpen(true);
  };

  return (
    <AuthContext.Provider value={{ user, session, userRole, signUp, registerEmployee, signIn, signOut, requestSignOut, loading }}>
      {children}
      <AnonymousCheckinDialog
        open={checkinOpen && !!user}
        onCancel={() => setCheckinOpen(false)}
        onDone={() => {
          setCheckinOpen(false);
          void signOut();
        }}
      />
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
