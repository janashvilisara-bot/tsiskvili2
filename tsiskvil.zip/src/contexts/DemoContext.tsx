import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface DemoContextType {
  isDemoMode: boolean;
  setDemoMode: (value: boolean) => void;
}

const DemoContext = createContext<DemoContextType | undefined>(undefined);

export function DemoProvider({ children }: { children: ReactNode }) {
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const checkDemoMode = async () => {
      const urlParams = new URLSearchParams(window.location.search);
      const isDemoPath = window.location.pathname === '/demo';
      const hasDemoParam = urlParams.get('demo') === 'true';
      
      if (isDemoPath || hasDemoParam) {
        setIsDemoMode(true);
        
        // Check if already logged in
        const { data: { session } } = await supabase.auth.getSession();
        if (!session && !isLoggingIn) {
          await loginDemoUser();
        }
      }
    };

    checkDemoMode();
  }, []);

  const loginDemoUser = async () => {
    if (isLoggingIn) return;
    
    setIsLoggingIn(true);
    try {
      // Check if already logged in first
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        setIsLoggingIn(false);
        return;
      }

      const { error } = await supabase.auth.signInWithPassword({
        email: "demo@talentos.ge",
        password: "Demo123!@#"
      });

      if (error) {
        console.error("Demo login error:", error);
        toast({
          title: "დემო რეჟიმის შეცდომა",
          description: "დემო მომხმარებლის შესვლა ვერ მოხერხდა",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Demo login error:", error);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const setDemoMode = async (value: boolean) => {
    setIsDemoMode(value);
    if (value && !isLoggingIn) {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        await loginDemoUser();
      }
    }
  };

  return (
    <DemoContext.Provider value={{ isDemoMode, setDemoMode }}>
      {children}
    </DemoContext.Provider>
  );
}

export function useDemoMode() {
  const context = useContext(DemoContext);
  if (context === undefined) {
    throw new Error("useDemoMode must be used within a DemoProvider");
  }
  return context;
}
