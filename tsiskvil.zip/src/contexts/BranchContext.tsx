import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./AuthContext";

export interface Branch {
  id: string;
  name: string;
  name_en: string | null;
  code: string;
  city: string | null;
  address: string | null;
  phone: string | null;
  email: string | null;
  manager_id: string | null;
  timezone: string;
  currency: string;
  logo_url: string | null;
  description: string | null;
  is_active: boolean;
  is_primary: boolean;
}

interface BranchContextValue {
  /** All branches the user has access to */
  branches: Branch[];
  /** Currently selected branch (null = "all branches" view, only for admin/HR) */
  activeBranch: Branch | null;
  /** True when user can view all branches at once (admin/hr_manager) */
  canViewAll: boolean;
  /** True when user has access to multiple branches */
  hasMultipleBranches: boolean;
  setActiveBranchId: (branchId: string | null) => void;
  isLoading: boolean;
  refresh: () => Promise<void>;
}

const BranchContext = createContext<BranchContextValue | undefined>(undefined);

const ACTIVE_BRANCH_STORAGE_KEY = "active_branch_id";

export function BranchProvider({ children }: { children: ReactNode }) {
  const { user, userRole } = useAuth();
  const [branches, setBranches] = useState<Branch[]>([]);
  const [activeBranch, setActiveBranch] = useState<Branch | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [roleOverride, setRoleOverride] = useState<string | null>(null);

  const effectiveRole = userRole || roleOverride;
  const canViewAll = effectiveRole === "admin" || effectiveRole === "hr_manager";

  const loadBranches = useCallback(async () => {
    if (!user) {
      setBranches([]);
      setActiveBranch(null);
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    try {
      let list: Branch[] = [];
      let resolvedRole = userRole;

      if (!resolvedRole) {
        const { data: roleRows, error: roleError } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id);
        if (roleError) throw roleError;
        const roles = (roleRows || []).map((row: any) => row.role);
        resolvedRole = roles.includes("admin")
          ? "admin"
          : roles.includes("hr_manager")
          ? "hr_manager"
          : roles.includes("department_manager")
          ? "department_manager"
          : roles.includes("employee")
          ? "employee"
          : null;
        setRoleOverride(resolvedRole);
      }

      if (resolvedRole === "admin" || resolvedRole === "hr_manager") {
        // Admins/HR see all active branches
        const { data, error } = await supabase
          .from("branches")
          .select("*")
          .order("is_primary", { ascending: false })
          .order("name", { ascending: true });
        if (error) throw error;
        list = (data || []) as Branch[];
      } else {
        // Regular users see only their assigned branches
        const { data, error } = await supabase
          .from("user_branch_access")
          .select("branch_id, is_primary, branches(*)")
          .eq("user_id", user.id);
        if (error) throw error;
        list = (data || [])
          .map((row: any) => row.branches)
          .filter(Boolean)
          .filter((b: Branch) => b.is_active);
      }
      setBranches(list);

      // Restore previous selection or fall back to primary/first
      const storedId = localStorage.getItem(ACTIVE_BRANCH_STORAGE_KEY);
      const stored = storedId ? list.find((b) => b.id === storedId) : null;
      const primary = list.find((b) => b.is_primary);
      setActiveBranch(resolvedRole === "admin" || resolvedRole === "hr_manager" ? stored || null : stored || primary || list[0] || null);
    } catch (err) {
      console.error("Failed to load branches", err);
      setBranches([]);
      setActiveBranch(null);
    } finally {
      setIsLoading(false);
    }
  }, [user, userRole]);

  useEffect(() => {
    loadBranches();
  }, [loadBranches]);

  const setActiveBranchId = useCallback(
    (branchId: string | null) => {
      if (branchId === null) {
        setActiveBranch(null);
        localStorage.removeItem(ACTIVE_BRANCH_STORAGE_KEY);
        return;
      }
      const found = branches.find((b) => b.id === branchId);
      if (found) {
        setActiveBranch(found);
        localStorage.setItem(ACTIVE_BRANCH_STORAGE_KEY, branchId);
      }
    },
    [branches]
  );

  return (
    <BranchContext.Provider
      value={{
        branches,
        activeBranch,
        canViewAll,
        hasMultipleBranches: branches.length > 1,
        setActiveBranchId,
        isLoading,
        refresh: loadBranches,
      }}
    >
      {children}
    </BranchContext.Provider>
  );
}

export function useBranch() {
  const ctx = useContext(BranchContext);
  if (!ctx) throw new Error("useBranch must be used within BranchProvider");
  return ctx;
}
