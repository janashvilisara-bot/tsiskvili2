import { createContext, useContext, useEffect, useState, ReactNode } from "react";

export type SkinId = "cyan" | "indigo" | "emerald" | "rose" | "amber" | "violet";

interface SkinDef {
  id: SkinId;
  label: string;
  swatch: string; // hex for picker swatch
  vars: Record<string, string>; // CSS variable overrides (HSL components)
}

// Each skin overrides primary palette + accent + ring + sidebar + gradients
export const SKINS: SkinDef[] = [
  {
    id: "cyan",
    label: "ციანი",
    swatch: "#06b6d4",
    vars: {
      "--primary": "192 95% 45%",
      "--primary-glow": "188 100% 55%",
      "--accent": "188 100% 50%",
      "--ring": "188 100% 55%",
      "--sidebar-background": "210 60% 10%",
      "--sidebar-primary": "188 100% 55%",
      "--sidebar-accent": "200 50% 16%",
      "--sidebar-border": "200 50% 18%",
      "--sidebar-ring": "188 100% 55%",
      "--gradient-primary": "linear-gradient(135deg, hsl(192 95% 45%), hsl(188 100% 55%))",
    },
  },
  {
    id: "indigo",
    label: "ინდიგო",
    swatch: "#6366f1",
    vars: {
      "--primary": "239 84% 60%",
      "--primary-glow": "250 85% 70%",
      "--accent": "250 85% 65%",
      "--ring": "239 84% 60%",
      "--sidebar-background": "240 45% 12%",
      "--sidebar-primary": "239 84% 60%",
      "--sidebar-accent": "240 35% 18%",
      "--sidebar-border": "240 30% 22%",
      "--sidebar-ring": "239 84% 60%",
      "--gradient-primary": "linear-gradient(135deg, hsl(239 84% 60%), hsl(250 85% 70%))",
    },
  },
  {
    id: "emerald",
    label: "ზურმუხტი",
    swatch: "#10b981",
    vars: {
      "--primary": "160 84% 39%",
      "--primary-glow": "152 76% 50%",
      "--accent": "152 76% 50%",
      "--ring": "160 84% 39%",
      "--sidebar-background": "165 50% 10%",
      "--sidebar-primary": "152 76% 50%",
      "--sidebar-accent": "160 35% 16%",
      "--sidebar-border": "160 30% 20%",
      "--sidebar-ring": "152 76% 50%",
      "--gradient-primary": "linear-gradient(135deg, hsl(160 84% 39%), hsl(152 76% 50%))",
    },
  },
  {
    id: "rose",
    label: "ვარდისფერი",
    swatch: "#f43f5e",
    vars: {
      "--primary": "346 77% 50%",
      "--primary-glow": "340 82% 65%",
      "--accent": "340 82% 60%",
      "--ring": "346 77% 50%",
      "--sidebar-background": "345 35% 12%",
      "--sidebar-primary": "346 77% 60%",
      "--sidebar-accent": "345 30% 18%",
      "--sidebar-border": "345 25% 22%",
      "--sidebar-ring": "346 77% 60%",
      "--gradient-primary": "linear-gradient(135deg, hsl(346 77% 50%), hsl(340 82% 65%))",
    },
  },
  {
    id: "amber",
    label: "ქარვისფერი",
    swatch: "#f59e0b",
    vars: {
      "--primary": "32 95% 50%",
      "--primary-glow": "38 92% 60%",
      "--accent": "38 92% 55%",
      "--ring": "32 95% 50%",
      "--sidebar-background": "30 35% 11%",
      "--sidebar-primary": "38 92% 60%",
      "--sidebar-accent": "32 30% 17%",
      "--sidebar-border": "32 25% 21%",
      "--sidebar-ring": "38 92% 60%",
      "--gradient-primary": "linear-gradient(135deg, hsl(32 95% 50%), hsl(38 92% 60%))",
    },
  },
  {
    id: "violet",
    label: "იისფერი",
    swatch: "#8b5cf6",
    vars: {
      "--primary": "262 83% 58%",
      "--primary-glow": "270 91% 70%",
      "--accent": "270 91% 65%",
      "--ring": "262 83% 58%",
      "--sidebar-background": "265 45% 12%",
      "--sidebar-primary": "262 83% 65%",
      "--sidebar-accent": "265 35% 18%",
      "--sidebar-border": "265 30% 22%",
      "--sidebar-ring": "262 83% 65%",
      "--gradient-primary": "linear-gradient(135deg, hsl(262 83% 58%), hsl(270 91% 70%))",
    },
  },
];

const STORAGE_KEY = "talentos-skin";

interface SkinContextValue {
  skin: SkinId;
  setSkin: (s: SkinId) => void;
}

const SkinContext = createContext<SkinContextValue>({ skin: "cyan", setSkin: () => {} });

function applySkin(id: SkinId) {
  const def = SKINS.find((s) => s.id === id) ?? SKINS[0];
  const root = document.documentElement;
  Object.entries(def.vars).forEach(([k, v]) => root.style.setProperty(k, v));
  root.setAttribute("data-skin", id);
}

export function SkinProvider({ children }: { children: ReactNode }) {
  const [skin, setSkinState] = useState<SkinId>(() => {
    if (typeof window === "undefined") return "cyan";
    return ((localStorage.getItem(STORAGE_KEY) as SkinId) || "cyan");
  });

  useEffect(() => {
    applySkin(skin);
    try {
      localStorage.setItem(STORAGE_KEY, skin);
    } catch {}
  }, [skin]);

  return <SkinContext.Provider value={{ skin, setSkin: setSkinState }}>{children}</SkinContext.Provider>;
}

export const useSkin = () => useContext(SkinContext);
