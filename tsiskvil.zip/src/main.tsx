import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { registerSW } from "virtual:pwa-register";
import { toast } from "sonner";

const isInIframe = (() => {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
})();

const isPreviewHost =
  window.location.hostname.includes("id-preview--") ||
  window.location.hostname.includes("lovableproject.com") ||
  window.location.hostname.includes("lovable.app");

if ("serviceWorker" in navigator && !isInIframe && !isPreviewHost && window.location.protocol !== "file:") {
  const updateSW = registerSW({
    immediate: true,
    onNeedRefresh() {
      // Don't auto-reload — ask the user first
      toast("ხელმისაწვდომია ახალი ვერსია", {
        description: "დააჭირეთ განახლებას ცვლილებების სანახავად",
        duration: Infinity,
        action: {
          label: "განახლება",
          onClick: () => updateSW(true),
        },
      });
    },
    onRegistered(registration) {
      if (!registration) return;
      // Check for updates every 30 minutes instead of every minute
      setInterval(() => registration.update(), 30 * 60 * 1000);
    },
  });
} else {
  navigator.serviceWorker?.getRegistrations().then((registrations) => {
    registrations.forEach((registration) => registration.unregister());
  });
}

createRoot(document.getElementById("root")!).render(<App />);

